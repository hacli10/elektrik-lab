"""Yönlü toprak aşırı akım koruması (ANSI 67N) — Easergy P3 «Ioφ>» kademesi: nötr biçimine göre mod, açı, Vo ayarı.

Dayanak: P3U/en M/J006 böl. 5.31 (kutuplama −Vo; modlar RezKap [Rez: aktif bileşen, kompanze ve yüksek dirençli; Kap: kapasitif bileşen, yalıtılmış],
Sektör [küçük dirençli; açı kayması 0° ya da biraz eksi], Yönsüz; Io girişi ölçülen ya da hesaplanan), Çizelge 84 (başlatma 0,005–20 ×I0N,
Vo 1–100 %, açı ±88°, doğruluklar). Arıza akımı modeli: topraklama laboratuvarındaki nötr sayfası ile aynı (−Vo referans)."""
from __future__ import annotations

import cmath
import math

from ..lab.yonlu import toprak_akimlari
from .ortak import A, C, G, K, KABUL, P3U, S, S3, T, URRA, Cizim, aci, ctl, fa, fnum, fz, norm, num, opt
from .roleler import DIGER67N, ROLE67N, aci67n

ID = "yon_toprak"
BASLIK = "Yönlü toprak (67N)"
IKON = "⏚"
GIRIS = ("Toprak arızasında bütün fiderlerden artık akım geçer: arızalı fiderden de, sağlam fiderlerden de. Büyüklük ayırt etmeye yetmez; "
         "röle artık akımın artık gerilime (−Vo) göre açısına bakar. Hangi açının «ileri» olduğu şebekenin nötr topraklamasına bağlıdır: "
         "mod ve açı ayarı buradan çıkar.")

NOTR = {"direnc": "Direnç üzerinden topraklı", "yalitilmis": "Yalıtılmış nötr", "bobin": "Rezonans topraklı (Petersen bobini)"}
MOD = {"sektor": "Sektör (açı kayması ± 88°)", "rez": "RezKap — Rez (Io·cos φ, aktif bileşen)", "kap": "RezKap — Kap (Io·sin φ, kapasitif bileşen)", "yonsuz": "Yönsüz"}
ONERI = {"direnc": "sektor", "yalitilmis": "kap", "bobin": "rez"}
YARI = 88.0

KONTROLLER = [
    ctl("un_kv", "Şebeke gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("notr", "Şebekenin nötr topraklaması", "sec", "direnc", secenek=opt(*NOTR.items()), yardim="Besleyen trafo merkezinin nötr düzeni — dağıtım şirketinden öğrenilir"),
    ctl("ir_a", "Nötr direncinin akım sınırı", "sayi", 1000, min=20, max=2000, adim=10, birim="A", goster={"notr": ["direnc"]}, yardim="Ör. 20 Ω → 34,5 kV'ta 1000 A"),
    ctl("komp", "Bobinin kompanzasyon derecesi", "sayi", 105, min=60, max=140, adim=1, birim="%", goster={"notr": ["bobin"]}),
    ctl("iw_a", "Bobin + şebeke aktif akımı", "sayi", 8, min=1, max=60, adim=1, birim="A", goster={"notr": ["bobin"]}),
    ctl("ic_bu", "Bu fiderin kapasitif akımı (3·Ic0)", "sayi", 3, min=0.1, max=80, adim=0.1, birim="A", yardim="Kablo boyu × birim kapasitif akım (XLPE 34,5 kV ≈ 2–4 A/km)"),
    ctl("ic_diger", "Şebekenin geri kalanının kapasitif akımı", "sayi", 60, min=0.5, max=400, adim=0.5, birim="A"),
    ctl("rf", "Arıza direnci", "sayi", 0, min=0, max=5000, adim=10, birim="Ω"),
    ctl("yer", "Arıza yeri", "sec", "ileri", secenek=opt(("ileri", "Bu fiderde (rölenin önünde)"), ("geri", "Başka fiderde (rölenin arkasında)"))),
    ctl("giris", "Röle › Io girişi", "sec", "io1", secenek=opt(("io1", "Io1 — toroid (ölçülen)"), ("hes", "IoHes — faz akımlarının toplamı"))),
    ctl("io_p", "Toroidin primeri", "sayi", 50, min=1, max=1000, adim=1, birim="A", goster={"giris": ["io1"]}),
    ctl("ct_p", "Faz akım trafosu primeri", "sayi", 200, min=5, max=3000, adim=5, birim="A", goster={"giris": ["hes"]}),
    ctl("rol", "Röle › Marka / model", "sec", "p3", secenek=opt(*[(k, v["ad"]) for k, v in ROLE67N.items()]), yardim="Açının işareti markaya göre değişir: P3 ve MiCOM'da artı = −Vo'dan ileride; ABB 615'te artı = geride"),
    ctl("mod", "Röle › Yön modu", "sec", "sektor", secenek=opt(*MOD.items())),
    ctl("aci", "Röle › Açı kayması", "sayi", 0, min=-180, max=179, adim=1, birim="°", goster={"mod": ["sektor"]}),
    ctl("baslatma", "Röle › Başlatma", "sayi", 0.60, min=0.01, max=20, adim=0.01, birim="pu"),
    ctl("vo", "Röle › Vo ayarı", "sayi", 3, min=1, max=100, adim=1, birim="%"),
    ctl("t_s", "Röle › Çalışma süresi", "sayi", 0.30, min=0.04, max=10, adim=0.01, birim="s"),
    ctl("ters", "Toroid ters takılmış ya da açık üçgen sargı ters bağlı", "onay", False),
]


def durum(p: dict, yer: str, rf: float | None = None) -> dict:
    """Rölenin gördüğü artık akım (A, −Vo'ya göre fazör) ve artık gerilim (%). Arıza direnci Vo'yu ve akımı birlikte küçültür."""
    notr = p.get("notr") if p.get("notr") in NOTR else "direnc"
    e = num(p, "un_kv", 34.5) * 1000 / S3
    ic_bu, ic_d = num(p, "ic_bu", 3), num(p, "ic_diger", 60)
    kw = dict(ir=num(p, "ir_a", 1000), komp=num(p, "komp", 105), iw=num(p, "iw_a", 8))
    f1, s1 = toprak_akimlari(notr, ic_bu, ic_d, v0=1.0, **kw)                          # katı arızada (Vo = %100)
    i_top = f1 - s1                                                                    # arıza yerindeki toplam akım (bu fiderin kapasitif akımı dâhil)
    r = num(p, "rf", 0) if rf is None else rf
    z = e / i_top if abs(i_top) > 1e-9 else complex(1e9, 0)
    v0 = abs(z / (z + r))
    i = (f1 if yer == "ileri" else s1) * v0
    if p.get("ters"):
        i = -i
    return {"i": i, "v0": v0 * 100, "notr": notr, "i_top": abs(i_top) * v0, "f1": f1, "s1": s1, "e": e, "z": z}


def karar(p: dict, d: dict) -> dict:
    mod = p.get("mod") if p.get("mod") in MOD else "sektor"
    taban = num(p, "io_p", 50) if p.get("giris") != "hes" else num(p, "ct_p", 200)
    esik = num(p, "baslatma", 0.6) * taban
    phi = norm(aci(d["i"])); mag = abs(d["i"])
    v_ok = d["v0"] >= num(p, "vo", 3)
    base = num(p, "aci", 0)
    if mod == "sektor":
        olcu, icinde = mag, abs(norm(phi - base)) < YARI
        ad = "|Io|"
    elif mod == "rez":
        olcu, icinde = mag * math.cos(math.radians(phi)), math.cos(math.radians(phi)) > 0; ad = "Io·cos φ"
    elif mod == "kap":
        olcu, icinde = mag * math.sin(math.radians(phi)), math.sin(math.radians(phi)) > 0; ad = "Io·sin φ"
    else:
        olcu, icinde, v_ok, ad = mag, True, True, "|Io|"
    acar = v_ok and icinde and olcu >= esik
    neden = ("Vo ayarın altında" if not v_ok else "akım ters yönde / bölgenin dışında" if not icinde else f"{ad} eşiğin altında" if olcu < esik else "yön ve eşik sağlandı")
    return {"acar": acar, "neden": neden, "phi": phi, "mag": mag, "olcu": olcu, "esik": esik, "taban": taban, "v_ok": v_ok, "icinde": icinde, "mod": mod, "base": base, "ad": ad}


def rf_sinir(p: dict) -> float:
    """Arızalı fiderde kademenin hâlâ açtığı en büyük arıza direnci (Ω) — ikiye bölerek."""
    q = dict(p); q["ters"] = False
    if not karar(q, durum(q, "ileri", 0.0))["acar"]:
        return 0.0
    lo, hi = 0.0, 50000.0
    for _ in range(40):
        mid = (lo + hi) / 2
        if karar(q, durum(q, "ileri", mid))["acar"]:
            lo = mid
        else:
            hi = mid
    return lo


def run(p: dict) -> dict:
    yer = p.get("yer") if p.get("yer") in ("ileri", "geri") else "ileri"
    d = durum(p, yer); k = karar(p, d)
    notr = d["notr"]; oneri = ONERI[notr]
    beklenen = yer == "ileri"
    kat = durum(p, "ileri", 0.0); saglam = durum(p, "geri", 0.0)
    rmax = rf_sinir(p)
    taban = k["taban"]
    rol = p.get("rol") if p.get("rol") in ROLE67N else "p3"; RN = ROLE67N[rol]
    merkez_p3 = {"sektor": k["base"], "rez": 0.0, "kap": 90.0, "yonsuz": 0.0}[k["mod"]]          # açma bölgesinin merkezi (artı: −Vo'dan ileride)
    AN = aci67n(rol, merkez_p3)
    # önerilen eşik: arızalı fiderin katı arızada verdiği ölçünün yarısı; en az sağlam fider akımının 1,5 katı (yönsüz yedek düşüncesiyle)
    olcu_kat = {"sektor": abs(kat["i"]), "rez": kat["i"].real, "kap": kat["i"].imag}[oneri]
    oneri_esik = {"direnc": 30.0, "yalitilmis": max(0.5 * kat["i"].imag, 1.0), "bobin": max(0.5 * kat["i"].real, 0.5)}[notr]
    vo_rf = durum(p, "ileri", rmax)["v0"] if rmax > 0 else 0.0

    # ---- şema ----
    c = Cizim(900, 320)
    c.kutu(20, 50, 120, 50, "Besleyen trafo", NOTR[notr].split(" (")[0])
    c.hat("M80,100 V128", "cizgi")
    if notr == "direnc":
        c.direnc(80, 128, f"{fnum(num(p, 'ir_a', 1000), 0)} A", hot=True, h=28); c.hat("M80,156 V172", "cizgi"); c.toprak(80, 172)
    elif notr == "bobin":
        c.bobin(80, 128, 4, ad="bobin"); c.hat("M80,168 V176", "cizgi"); c.toprak(80, 176)
    else:
        c.yazi(92, 140, "nötr yalıtılmış", "#64748b", 10)
    c.hat("M140,75 H200", "L1", w=3); c.hat("M200,40 V250", "cizgi", w=5); c.yazi(200, 32, "OG bara", "#475569", 10, anchor="middle")
    bu_hot = True
    c.hat("M200,80 H830", "L1", hot=bu_hot and yer == "ileri", w=3); c.yazi(836, 84, "bu fider", "#334155", 10.5, kalin=True)
    c.hat("M200,220 H830", "L1", hot=yer == "geri", w=3); c.yazi(836, 224, "diğer", "#334155", 10.5); c.yazi(836, 237, "fiderler", "#334155", 10.5)
    c.toroid(280, 80, 7, 17); c.yazi(280, 56, "toroid" if p.get("giris") != "hes" else "faz AT (toplam)", "#475569", 10, anchor="middle")
    c.hat("M280,98 V128", "cizgi", kesik=True, w=1.4)
    c.kutu(215, 128, 185, 52, "67N  Ioφ>", ("AÇTI" if k["acar"] else "açmadı") + f" — φ = {fnum(k['phi'], 0)}°", "acti" if k["acar"] else ("gecersiz" if k["acar"] != beklenen else "normal"))
    c.kap(720, 80, 130, ad=f"Ic {fnum(num(p, 'ic_bu', 3), 1)} A"); c.toprak(720, 130)
    c.kap(720, 220, 270, ad=f"Ic {fnum(num(p, 'ic_diger', 60), 0)} A"); c.toprak(720, 270)
    yf = 80 if yer == "ileri" else 220
    c.simsek(554, yf - 8, 1.1); c.hat(f"M560,{yf} V{yf + 40}", "ariza", hot=True); c.toprak(560, yf + 42, "ariza")
    c.yazi(572, yf + 30, f"Rf = {fnum(num(p, 'rf', 0), 0)} Ω", "#b91c1c", 10.5)
    c.ok(300, 66, 350, 66, "ok", 2); c.yazi(356, 70, "ileri", "#15803d", 10, kalin=True)
    c.yazi(420, 142, f"Io = {fa(k['mag'])} ({fnum(k['mag'] / taban, 2)} pu) ∠ {fnum(k['phi'], 0)}°   ·   Vo = %{fnum(d['v0'], 1)}", "#b91c1c", 11.5, kalin=True)
    c.yazi(420, 160, f"{k['ad']} = {fa(k['olcu'])} · eşik {fa(k['esik'])} — {k['neden']}", "#334155", 11)
    c.yazi(20, 300, "Arızalı fiderden: nötr akımı + öbür fiderlerin kapasitif akımı geçer. Sağlam fiderden: yalnız kendi kapasitif akımı, ters yönde.", "#475569", 10.5)

    bolge = {"sektor": {"aci": k["base"], "yari": YARI, "ad": "açma bölgesi"}, "rez": {"aci": 0, "yari": 90, "ad": "cos φ > 0"},
             "kap": {"aci": 90, "yari": 90, "ad": "sin φ > 0"}, "yonsuz": {"aci": 0, "yari": 179.9, "ad": "yönsüz"}}[k["mod"]]
    mx = max(abs(kat["i"]), abs(saglam["i"]), 1e-9)
    boy = lambda z: 0.25 + 0.65 * abs(z) / mx                                           # noqa: E731
    vek = [fz("−Vo", d["v0"], 0, 1.0, "#1d4ed8"), fz("Io", k["mag"], k["phi"], boy(d["i"]), "#dc2626"),
           fz("Io arızalı fider (katı arıza)", abs(kat["i"]), aci(kat["i"]), boy(kat["i"]), "#f59e0b", kesik=True),
           fz("Io sağlam fider", abs(saglam["i"]), aci(saglam["i"]), boy(saglam["i"]), "#64748b", kesik=True)]
    fazor = {"baslik": "−Vo 0°'de; artık akımın açısı φ", "vektorler": vek, "bolge": {**bolge, "renk": "#15803d"},
             "not": "Açı artı ise akım −Vo'dan ileridedir (kapasitif). Büyüklükler: Vo %, akımlar A."}

    ozet = [
        K("Röle kararı", "AÇAR" if k["acar"] else "AÇMAZ", "ok" if k["acar"] == beklenen else "bad", ("doğru" if k["acar"] == beklenen else "YANLIŞ") + " — arıza " + ("bu fiderde" if beklenen else "başka fiderde")),
        K("Artık akım", f"{fa(k['mag'])} ∠ {fnum(k['phi'], 0)}°", "info", f"{fnum(k['mag'] / taban, 2)} pu (taban {taban:g} A)"),
        K("Artık gerilim Vo", f"%{fnum(d['v0'], 1)}", "ok" if k["v_ok"] else "warn", f"ayar %{fnum(num(p, 'vo', 3), 0)}"),
        K("Görülen en büyük arıza direnci", f"{fnum(rmax, 0)} Ω", "info" if rmax > 0 else "bad", f"o noktada Vo = %{fnum(vo_rf, 1)}"),
        K("Bu şebeke için mod", MOD[oneri].split(" (")[0], "ok" if k["mod"] == oneri else "warn", "seçili: " + MOD[k["mod"]].split(" (")[0]),
    ]
    saglam_k = karar({**p, "ters": False}, saglam)
    kontroller = [
        C("Röle bu durumda doğru karar veriyor mu?", ("açar" if k["acar"] else "açmaz") + f" ({k['neden']})", "arıza bu fiderdeyse açar, başka fiderdeyse açmaz", k["acar"] == beklenen,
          "Kutuplama −Vo; açma koşulu: Vo ≥ ayar, açı bölgede, akım ≥ başlatma — " + P3U + " böl. 5.31", "resmi"),
        C("Bu rölede açı nasıl tanımlı?", f"{RN['param']}: artı açı = akım −Vo'dan {'ileride (kapasitif)' if RN['isaret'] > 0 else 'geride (endüktif)'} → bu durumda {AN['metin']}", "tanım rölenin kendi kılavuzundan okunmuş olmalı",
          True if RN["durum"] == "resmi" else None, RN["kaynak"], RN["durum"]),
        C("Yön modu nötr biçimine uygun mu?", MOD[k["mod"]], f"{NOTR[notr]} → {MOD[oneri]}", k["mod"] == oneri,
          "Rez: kompanze ve yüksek dirençli; Kap: yalıtılmış; Sektör: küçük dirençli şebeke (açı kayması 0° ya da biraz eksi) — " + P3U + " böl. 5.31", "resmi"),
        C("Sağlam fiderde (arıza başka yerde) kademe susuyor mu?", f"Io = {fa(abs(saglam['i']))} ∠ {fnum(aci(saglam['i']), 0)}° → " + ("açar" if saglam_k["acar"] else "açmaz"), "açmaz", not saglam_k["acar"],
          "Sağlam fiderin akımı kendi kapasitif akımıdır ve −Vo'dan 90° geridedir", "resmi"),
        C("Katı arızada ölçü eşiğin en az 2 katı mı?", f"{fa({'sektor': abs(kat['i']), 'rez': kat['i'].real, 'kap': kat['i'].imag, 'yonsuz': abs(kat['i'])}[k['mod']])} / {fa(k['esik'])}", "≥ 2", {'sektor': abs(kat['i']), 'rez': kat['i'].real, 'kap': kat['i'].imag, 'yonsuz': abs(kat['i'])}[k["mod"]] >= 2 * k["esik"],
          "Duyarlılık payı saha pratiği: " + URRA, "ikincil"),
        C("Vo ayarı doğal dengesizliğin üstünde mi?", f"%{fnum(num(p, 'vo', 3), 0)}", "≥ %2–3 (kablo şebekesi) — işletmede ölçülen artık gerilimin üstünde", num(p, "vo", 3) >= 2,
          "Ayar aralığı %1 … %100: " + P3U + " Çizelge 84; alt sınır önerisi saha pratiği", "ikincil"),
        C("Hesaplanan Io ile çalışılıyorsa eşik AT hatasının üstünde mi?", f"{fnum(k['esik'] / taban * 100, 0)} % In(AT)" if p.get("giris") == "hes" else "toroid kullanılıyor",
          "faz toplamında ≥ %10 In(AT)", (k["esik"] >= 0.1 * taban) if p.get("giris") == "hes" else None,
          "IoHes = IL1 + IL2 + IL3 katı ve küçük empedanslı şebekeler içindir (" + P3U + " böl. 5.21); %10 sınırı: " + URRA, "ikincil"),
        C("Toroid ve açık üçgen polaritesi", "ters" if p.get("ters") else "doğru", "primer enjeksiyonla doğrulanır", not p.get("ters"), KABUL, "resmi"),
    ]
    girdiler = [
        G("Şebekenin nötr topraklama biçimi ve akım sınırı", NOTR[notr] + (f", {fnum(num(p, 'ir_a', 1000), 0)} A" if notr == "direnc" else ""), "Dağıtım şirketi (besleyen trafo merkezinin nötr direnci / bobini)",
          "Arıza akımının açısını belirler: direnç → −Vo ile aynı fazda, yalıtılmış → 90° ileride", "Yön modu ve açı kayması"),
        G("Bu fiderin kapasitif akımı", fa(num(p, "ic_bu", 3)), "Kablo tipi ve boyu; kablo kataloğu", "Başka fiderdeki arızada rölenin göreceği (ters yönlü) akım", "Yönsüz yedek kademe bunun 1,5 katının üstünde olmalı"),
        G("Şebekenin toplam kapasitif akımı", fa(num(p, "ic_bu", 3) + num(p, "ic_diger", 60)), "Dağıtım şirketi; şebeke kablo uzunlukları", "Yalıtılmış şebekede arızalı fiderin tek akımı budur", "Kap modunda başlatma ≤ yarısı"),
        G("Toprak akımı girişi", ("toroid " + f"{num(p, 'io_p', 50):g}/1 A") if p.get("giris") != "hes" else f"faz AT toplamı ({num(p, 'ct_p', 200):g} A)", "Hücre etiketi; röle bağlantı şeması",
          "Ayar «pu» bu girişin primerine göredir; toroid küçük akımları doğru ölçer", "Io (pu) = A / giriş primeri"),
        G("Artık gerilimin kaynağı", "açık üçgen sargı ya da faz–toprak gerilimlerinden hesap", "GT etiketi; röle «gerilim ölçme modu»", "Vo ayarının tabanı ve polaritesi buna bağlı", "3LN: taban GT/√3; «+Vo»: açık üçgen sekonderi"),
        G("İstenen en büyük arıza direnci duyarlılığı", f"{fnum(rmax, 0)} Ω (bu ayarla)", "Dağıtım şirketi uygulaması", "Başlatma ve Vo ayarı birlikte belirler", "Rf arttıkça Vo ve Io birlikte düşer"),
    ]
    adimlar = [
        A("Katı arızada arızalı fiderin akımı", "Io = I nötr + j·Ic (öbür fiderler)", f"{fnum(kat['i'].real, 0)} + j{fnum(kat['i'].imag, 0)} A", f"{fa(abs(kat['i']))} ∠ {fnum(aci(kat['i']), 0)}°", "nötr akımı −Vo ile aynı fazda, kapasitif akım 90° ileride", "resmi", ["Şebekenin nötr topraklama biçimi ve akım sınırı", "Şebekenin toplam kapasitif akımı"]),
        A("Sağlam fiderin akımı", "Io = −j·Ic (bu fider)", f"−j{fnum(num(p, 'ic_bu', 3), 1)} A", f"{fa(abs(saglam['i']))} ∠ −90°", "kendi kapasitif akımı, ters yönde", "resmi", ["Bu fiderin kapasitif akımı"]),
        A("Yön modu", "nötr biçimi → mod", NOTR[notr], MOD[oneri], P3U + " böl. 5.31", "resmi", ["Şebekenin nötr topraklama biçimi ve akım sınırı"], "Yön modu"),
        A("Başlatma", {"direnc": "dağıtım uygulaması (30 A) ya da ≤ 0,5 × katı arıza akımı", "yalitilmis": "≤ 0,5 × Ic (öbür fiderler)", "bobin": "≤ 0,5 × aktif akım"}[notr], f"0,5 × {fnum(olcu_kat, 1)} A üst sınır", f"{fa(oneri_esik)} = {fnum(oneri_esik / taban, 2)} pu",
          URRA if notr == "direnc" else "duyarlılık payı (saha pratiği)", "ikincil", ["Toprak akımı girişi"], "Başlatma"),
        A("Vo ayarı", "Vo = E · Z / (Z + Rf); Z = E / I arıza", f"Rf = {fnum(rmax, 0)} Ω'da Vo = %{fnum(vo_rf, 1)}", f"%{fnum(max(2.0, min(vo_rf, 10)), 0) if rmax > 0 else '3'} dolayı", "Arıza direnci Vo'yu ve akımı aynı oranda küçültür; Vo ayarı akım eşiğiyle aynı Rf'yi görmeli", "resmi", ["İstenen en büyük arıza direnci duyarlılığı"], "Vo ayarı"),
        A("Açma bölgesi", "Sektör: açı kayması ± 88°; Rez: cos φ > 0; Kap: sin φ > 0", f"açı kayması {fnum(k['base'], 0)}°" if k["mod"] == "sektor" else MOD[k["mod"]], f"{fnum(k['base'] - 88, 0)}° … {fnum(k['base'] + 88, 0)}°" if k["mod"] == "sektor" else "yarım düzlem", P3U + " Çizelge 84", "resmi", [], "Açı kayması"),
    ]
    ek_ayar = [] if rol == "p3" else [
        S(RN["param"] + " — " + RN["ad"], AN["metin"].split(" = ")[1], "—", f"Aynı açma bölgesi (merkez {fnum(merkez_p3, 0)}°, artı: −Vo'dan ileride) bu rölede bu sayıyla girilir", RN["kaynak"], RN["durum"]),
        S("Çalışma modu / kutuplama — " + RN["ad"], RN["mod"], "—", "Öneri: " + RN["oneri"], RN["kaynak"], RN["durum"]),
        S("Açma bölgesi — " + RN["ad"], RN["bolge"], "—", "Benzetim Easergy P3'ün ± 88° bölgesini kullanır", RN["kaynak"], RN["durum"]),
    ]
    ayarlar = ek_ayar + [
        S("Io girişi", "Io1" if p.get("giris") != "hes" else "IoHes", "Io1 / Io2 / IoHes", "Toroid varsa ölçülen giriş; yoksa faz toplamı (yalnız büyük akımlı şebekede)", P3U + " böl. 5.31"),
        S("Yön modu", MOD[oneri].split(" —")[0].split(" (")[0], "RezKap / Sektör / Yönsüz", "Nötr biçimine göre", P3U + " böl. 5.31"),
        S("İzole hat için Sin/cos seçimi", {"sektor": "— (Sektör modunda kullanılmaz)", "rez": "Rez", "kap": "Kap", "yonsuz": "—"}[oneri], "Rez / Kap / I/O", "Rez: aktif bileşen; Kap: kapasitif bileşen; I/O: dijital girişle seçilir (bobin geçici devre dışıyken Kap'a geçmek için)", P3U + " böl. 5.31"),
        S("Başlatma", f"{fnum(oneri_esik / taban, 2)} pu (şu an {fnum(num(p, 'baslatma', 0.6), 2)})", "0,005 … 20 pu (kademe 1)", f"= {fa(oneri_esik)} primer", P3U + " Çizelge 84"),
        S("Vo ayarı", f"%{fnum(num(p, 'vo', 3), 0)}", "%1 … %100", "Artık gerilim bunun altındaysa kademe çalışmaz (yanlış açmaya karşı kilit)", P3U + " Çizelge 84"),
        S("Açı kayması", "0°" if oneri == "sektor" else "—", "−180° … +179°", "Dirençli şebekede akım −Vo ile aynı fazdadır: 0° (ya da biraz eksi)", P3U + " böl. 5.31"),
        S("Gecikme eğrisi / Çalışma süresi", f"SZ, {fnum(num(p, 't_s', 0.3), 2)} s", "0,10 … 300 s", "Seçicilik zamanla değil yönle sağlanır; süre üst kademeyle uyumlu", P3U + " Çizelge 84"),
        S("Kesinti süresi (aralıklı arıza)", "0,00 s", "0 … 300 s", "Aralıklı toprak arızalarında sayacın sıfırlanmasını geciktirir", P3U + " böl. 5.31"),
    ]
    i_t = 2 * oneri_esik / taban                     # toroid sekonderi 1 A varsayımıyla pu = A sekonder
    merkez = {"sektor": k["base"], "rez": 0.0, "kap": 90.0, "yonsuz": 0.0}[k["mod"]]
    test = [
        T("Düzen", "Vo girişine (ya da üç faz gerilimle bir fazı çökerterek) artık gerilim; Io girişine akım", "Röle −Vo'yu referans alır: test cihazındaki Vo'ya göre 180° dönmüş akım, «−Vo ile aynı fazda» demektir", "—"),
        T("Merkez açıda açma", f"Vo = %{fnum(2 * num(p, 'vo', 3), 0)}, Io = {fnum(i_t, 2)} pu (2 × eşik), açı −Vo'ya göre {fnum(merkez, 0)}°", f"Başlatma ≈ 60 ms, açma {fnum(num(p, 't_s', 0.3), 2)} s", "±%1 ya da ±30 ms"),
        T("Sınır açıları", "Akımı sabit tutup açıyı iki yöne çevirin", (f"Bırakma {fnum(merkez - 88, 0)}° ve {fnum(merkez + 88, 0)}°" if k["mod"] == "sektor" else "Açı büyüdükçe gereken akım 1/cos kadar artar: 60°'de 2 × eşik; 90°'de açmaz"), "±2° (U > 1 V ve Io > %5); küçük işarette ±20°"),
        T("Ters yön", f"Açı {fnum(norm(merkez + 180), 0)}°", "Başlatma yok", "—"),
        T("Vo kilidi", f"Akım 2 × eşik, Vo'yu %{fnum(num(p, 'vo', 3), 0)}'ın altına indirin", "Başlatma yok; Vo eşiği geçince başlar", "±%3 dolayı"),
        T("Başlatma eşiği", "Merkez açıda akımı yavaşça yükseltin", f"Başlatma {fnum(oneri_esik / taban, 3)} pu; bırakma oranı 0,95", "±%3 ya da anma değerinin ±%0,3'ü"),
        T("Bu sayfadaki durum", f"Vo = %{fnum(d['v0'], 1)}, Io = {fnum(k['mag'] / taban, 3)} pu, açı {fnum(k['phi'], 0)}°", "AÇAR" if k["acar"] else "AÇMAZ", k["neden"]),
    ]
    rs = [0, 5, 10, 20, 50, 100, 200, 300, 500, 700, 1000, 1500, 2000, 3000, 5000]
    g = {"baslik": "Arıza direnci büyüdükçe: akım ve artık gerilim birlikte düşer", "x_ad": "Arıza direnci (Ω)", "y_ad": "eşiğin katı", "logy": True,
         "seriler": [{"ad": f"{k['ad']} / başlatma", "renk": "#dc2626", "pts": [[r, max(karar({**p, 'ters': False}, durum(p, 'ileri', r))['olcu'] / k['esik'], 1e-3)] for r in rs]},
                     {"ad": "Vo / Vo ayarı", "renk": "#1d4ed8", "pts": [[r, max(durum(p, 'ileri', r)['v0'] / num(p, 'vo', 3), 1e-3)] for r in rs]}],
         "yatay": [{"y": 1.0, "etiket": "eşik"}], "isaretler": [{"x": rmax, "etiket": f"sınır {fnum(rmax, 0)} Ω"}] if 0 < rmax < 5000 else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["67n"],
        "sahne": c.sahne(fazor=fazor), "grafikler": [g],
        "anlatim": [
            "Bir faz toprağa değdiğinde nötr noktası kayar; bütün şebekede artık gerilim (Vo) oluşur. Röle bu gerilimin tersini (−Vo) referans alır.",
            "Arızalı fiderden iki akım geçer: nötr direncinin (ya da bobinin) akımı ve öbür fiderlerin kapasitif akımı. Nötr akımı −Vo ile aynı fazdadır (0°); kapasitif akım 90° ileridedir.",
            "Sağlam fiderlerden yalnız kendi kapasitif akımları geçer ve yönü terstir: −Vo'dan 90° geride. Röle arızalıyı sağlamdan bu açı farkıyla ayırır.",
            {"direnc": "Dirençli şebekede arızalı fiderin akımı neredeyse saf aktiftir: açma bölgesi 0° çevresine konur (Sektör, açı kayması 0°).",
             "yalitilmis": "Yalıtılmış şebekede nötr akımı yoktur; arızalı fiderin tek akımı öbür fiderlerin kapasitif akımıdır (+90°). Röle kapasitif bileşene bakar (Kap).",
             "bobin": "Bobin kapasitif akımı yok eder; geriye küçük bir aktif akım kalır. Röle yalnız aktif bileşene bakar (Rez); kapasitif bileşenin yönü kompanzasyon derecesine göre değiştiğinden güvenilmez."}[notr],
            f"Arıza direnci büyüdükçe hem akım hem Vo küçülür. Bu ayarla kademe {fnum(rmax, 0)} Ω'a kadar olan arızaları görür; o noktada Vo %{fnum(vo_rf, 1)}'dir.",
            "Vo ayarı kilit görevi yapar: artık gerilim yokken (ör. AT hatasından doğan sahte artık akımda) kademeyi susturur.",
        ],
        "dersler": [
            "Açı nötr biçiminden gelir: direnç → 0°, yalıtılmış → +90°, bobin → 0° (yalnız aktif bileşen).",
            "Referans −Vo'dur. Test cihazında Vo'yu 0° verdiyseniz «ileri» akım 180° çevresindedir.",
            "Açının işareti markaya göre değişir: Easergy P3 ve MiCOM'da artı açı akımın −Vo'dan ileride olduğunu, ABB 615'te geride olduğunu gösterir. Yalıtılmış şebekede P3 / MiCOM +90°, ABB −90° ister.",
            "Başlatma, Vo ayarı ve görülen en büyük arıza direnci birbirine bağlıdır; birini değiştirince ötekine bakın.",
            "Toroid ters takılırsa röle sağlam fiderde açar, arızalı fiderde susar.",
            "Santral bağlantı hücresinde, yükseltici trafonun OG sargısı üçgense santral toprak arızasına sıfır bileşen akımı vermez: şebeke tarafındaki toprak arızasını 67N değil 59N (Vo>) görür.",
        ],
        "tablolar": [
            {"baslik": "Nötr biçimine göre arızalı fiderin akımı ve ayar", "cols": ["Nötr", "Arızalı fiderin akımı (−Vo'ya göre)", "Sağlam fider", "P3 modu", "Açı"], "rows": [
                ["Direnç üzerinden", "I direnç ∠0° + Ic ∠+90° → 0…+20°", "Ic ∠−90°", "Sektör (ya da RezKap–Rez)", "0° (biraz eksi olabilir)"],
                ["Yalıtılmış", "Ic (öbür fiderler) ∠+90°", "Ic ∠−90°", "RezKap–Kap", "— (sin φ)"],
                ["Rezonans (bobin)", "I aktif ∠0° ± artık reaktif", "Ic ∠−90°", "RezKap–Rez", "— (cos φ)"],
                ["Doğrudan / küçük empedans", "Ik1 ∠ −60…−80° (hat empedansı)", "—", "Sektör", "−60° dolayı"]],
             "not": "Dayanak: " + P3U + " böl. 5.31. ABB 615 ailesinde açı işareti terstir (artı = −Vo'dan geride)."},
            {"baslik": "Röle marka ve modeline göre 67N açısı", "cols": ["Röle", "Parametre", "Artı açı", f"Bu durumda (merkez {fnum(merkez_p3, 0)}°)", "Mod / kutuplama", "Üreticinin önerisi", "Durum"],
             "rows": [[v["ad"] + (" ◀ seçili" if kk == rol else ""), v["param"], "−Vo'dan ileride (kapasitif)" if v["isaret"] > 0 else "−Vo'dan geride (endüktif)", aci67n(kk, merkez_p3)["metin"].split(" = ")[1], v["mod"], v["oneri"], v["durum"]] for kk, v in ROLE67N.items()],
             "not": "Kaynaklar: " + "; ".join(v["kaynak"] for v in ROLE67N.values()) + ". " + DIGER67N},
            {"baslik": "Santral bağlantı hücresinde toprak koruması", "cols": ["Arıza yeri", "Sıfır bileşen akımını kim verir", "Röle ne görür", "Hangi koruma"], "rows": [
                ["Santralin içinde (OG kablosu, trafo OG sargısı)", "Şebekenin nötr direnci", "Büyük artık akım, şebekeden santrale doğru", "67N (santral yönü) ya da 50N/51N"],
                ["Şebeke hattında", "Şebekenin nötr direnci — santralden geçmez", "Yalnız santral kablolarının küçük kapasitif akımı", "59N (Vo>): santral adada toprak arızasını beslemesin"],
                ["Şebeke kesicisi açtıktan sonra (ada)", "Kaynak kalmaz; nötr yalıtılmış olur", "Vo yüksek, akım yok", "59N + 27/59/81"]],
             "not": "Yükseltici trafonun OG sargısı üçgen (ya da yıldız noktası yalıtılmış) kabulüyle. 59N ayarı: Lisanssız Üretim Tebliği Ek-2 Tablo-2 dipnot d — dağıtım şirketi belirler."},
        ],
    }
