"""Röle laboratuvarı — dalga biçimi yardımcıları: anlık değerler, bir periyotluk Fourier süzgeci, etkin değer, kısa devre akımının doğru akım bileşeni.

Sayısal koruma rölesi akımı ve gerilimi örnekler (periyot başına N örnek) ve her örnekte son bir periyodun örneklerinden temel bileşeni çıkarır.
Buradaki süzgeç yalın «tam periyot Fourier» süzgecidir; gerçek rölelerde buna ek süzgeçler (doğru akım bileşeni için) bulunur — bu yüzden
aşırı erişim değerleri öğretim amaçlıdır (tahmini), üreticinin bildirdiği değerin yerini tutmaz."""
from __future__ import annotations

import cmath
import math

F = 50.0
W = 2 * math.pi * F
KOK2 = math.sqrt(2)


_CARPAN: dict = {}


def _carpan(N: int, h: int) -> list:
    """Süzgecin çarpanları e^(−j2πhk/N) — her (N, h) için bir kez hesaplanır."""
    if (N, h) not in _CARPAN:
        _CARPAN[(N, h)] = [cmath.exp(-2j * math.pi * h * k / N) for k in range(N)]
    return _CARPAN[(N, h)]


def dft(x: list, n: int, N: int, h: int = 1) -> complex:
    """n. örnekte biten bir periyotluk pencerede h. harmoniğin fazörü (tepe değer)."""
    c = _carpan(N, h); b = n - N + 1
    return sum(x[b + k] * c[k] for k in range(N)) * 2 / N


def temel(x: list, N: int, h: int = 1) -> list:
    """Her örnek için h. harmoniğin etkin değeri (ilk N−1 örnekte pencere dolmadığından eksik örnekler sıfır sayılır)."""
    y = [0.0] * (N - 1) + list(x)
    return [abs(dft(y, n + N - 1, N, h)) / KOK2 for n in range(len(x))]


def etkin(x: list, N: int) -> list:
    """Her örnek için son bir periyodun gerçek etkin değeri (bütün harmonikler ve doğru akım bileşeni dahil)."""
    y = [0.0] * (N - 1) + list(x)
    return [math.sqrt(sum(v * v for v in y[n:n + N]) / N) for n in range(len(x))]


def tepe_tepe(x: list, N: int) -> list:
    """Her örnek için son bir periyottaki (en büyük − en küçük) / 2√2: doğru akım bileşeninden etkilenmeyen yalın ölçü."""
    y = [0.0] * (N - 1) + list(x)
    return [(max(y[n:n + N]) - min(y[n:n + N])) / (2 * KOK2) for n in range(len(x))]


def tau(xr: float) -> float:
    """Doğru akım bileşeninin sönme zaman sabiti (s): τ = L/R = (X/R)/ω."""
    return max(xr, 0.0) / W


def kd_akim(i_ef: float, xr: float, alfa: float, t: float) -> float:
    """Kısa devre akımının anlık değeri. Gerilim u = Û·sin(ωt + α); akım i = √2·I·[sin(ωt + α − φ) − sin(α − φ)·e^(−t/τ)], φ = atan(X/R).
    İkinci terim doğru akım bileşenidir: akım endüktif devrede sıçrayamadığı için t = 0'da toplamı sıfır yapar."""
    fi = math.atan(xr) if xr > 0 else 0.0
    a = math.radians(alfa)
    dc = -math.sin(a - fi) * math.exp(-t / tau(xr)) if xr > 0 else 0.0
    return KOK2 * i_ef * (math.sin(W * t + a - fi) + dc)


def kappa(xr: float) -> float:
    """Tepe akım katsayısı κ = 1,02 + 0,98·e^(−3R/X); ip = κ·√2·Ik″ (TS EN 60909-0)."""
    return 1.02 + 0.98 * math.exp(-3.0 / xr) if xr > 0 else 1.02


def seri(ts: list, vs: list, adim: int = 1, n: int = 3) -> list:
    """Grafik noktaları [[t, v], …] (adim: her kaç örnekte bir)."""
    return [[round(t, 3), round(v, n)] for t, v in list(zip(ts, vs))[::adim]]
