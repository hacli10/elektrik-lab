"""Frekans korumaları: aşırı frekans (ANSI 81 / 81O) ve düşük frekans (ANSI 81U) — Easergy P3 «fX», «fXX», «f<», «f<<».

Dayanak: Lisanssız Elektrik Üretimi Yön. Uygulama Tebliği m.17, Ek-2 Tablo-2 (aşırı frekans 51 Hz → 0,2 s; düşük frekans 47 Hz → 0,2 s; düşük frekans dağıtım
şirketi görüşüyle 47–49,5 Hz ve 0,2–300 s aralığında ayarlanabilir; süreler kesici dâhil); P3U/en M/J006 böl. 5.37 (frekans ilk iki gerilim girişinden ölçülür;
81-1 ve 81-2 kademeleri aşırı ya da düşük frekans için ayarlanabilir; düşük frekans kademeleri en büyük faz arası gerilim «düşük gerilim kilitleme» sınırının
altındayken kilitlenir), Çizelge 91–92 (ayar 40–70 Hz, kilit %10–100 Un, süre 0,08–300 s, doğruluk ±20 mHz). Ada işletmesinde frekansın değişim hızı
df/dt = ΔP · fn / (2·H) salınım denkleminden gelir; atalet sabiti H üretici verisidir."""
from __future__ import annotations

from .ortak import A, C, G, K, LUY, P3U, S, T, ctl, fnum, kademe_test, num, opt, sz_kademe, tek_hat

ID = "frekans"
BASLIK = "Frekans (81 · 81U)"
IKON = "🎚"
GIRIS = ("Şebekeye bağlıyken frekansı şebeke belirler; santral onu değiştiremez. Frekans sınırların dışına çıkıyorsa ya şebekede büyük bir olay vardır "
         "ya da santral şebekeden kopmuş, kendi yüküyle adada kalmıştır. Frekans rölesi iki durumda da santrali ayırır.")

OLAY = {"eksik": "Ada: yük üretimden fazla (frekans düşer)", "fazla": "Ada: üretim yükten fazla (frekans yükselir)", "sebeke": "Şebekede küçük frekans salınımı", "gerilimsiz": "Enerji kesildi (gerilim yok, frekans ölçülemiyor)"}

KONTROLLER = [
    ctl("olay", "Olay", "sec", "eksik", secenek=opt(*OLAY.items())),
    ctl("dp", "Üretim ile yük arasındaki fark", "sayi", 30, min=1, max=100, adim=1, birim="% Sn", goster={"olay": ["eksik", "fazla"]}),
    ctl("h", "Santralin atalet sabiti H", "sayi", 1.5, min=0.3, max=8, adim=0.1, birim="s", yardim="Jeneratör + tahrik makinesi; gaz motorlu gruplarda 1–2 s dolayı (üretici)"),
    ctl("t_kesici", "Kesicinin açma süresi", "sayi", 60, min=20, max=120, adim=5, birim="ms"),
    ctl("f_ust", "Röle › fX (aşırı frekans, mod «>»)", "sayi", 51.0, min=50.1, max=55, adim=0.05, birim="Hz"),
    ctl("t_ust", "Röle › t fX", "sayi", 0.10, min=0.08, max=10, adim=0.02, birim="s"),
    ctl("f_alt", "Röle › f< (düşük frekans)", "sayi", 47.0, min=45, max=49.9, adim=0.05, birim="Hz"),
    ctl("t_alt", "Röle › t f<", "sayi", 0.10, min=0.08, max=300, adim=0.02, birim="s"),
    ctl("lv", "Röle › Düşük gerilim kilitleme", "sayi", 40, min=10, max=100, adim=1, birim="%Un"),
]


def run(p: dict) -> dict:
    o = p.get("olay") if p.get("olay") in OLAY else "eksik"
    dp, h, tk = num(p, "dp", 30) / 100, num(p, "h", 1.5), num(p, "t_kesici", 60) / 1000
    hiz = {"eksik": -dp * 50 / (2 * h), "fazla": dp * 50 / (2 * h)}.get(o, 0.0)          # Hz/s
    T0, dt = 0.3, 0.01
    ts = [j * dt for j in range(601)]
    import math
    fs, us = [], []
    for t in ts:
        if t < T0:
            fs.append(50.0); us.append(100.0)
        elif o == "sebeke":
            fs.append(50.0 - 0.35 * math.sin(2 * math.pi * (t - T0) / 4.0)); us.append(100.0)
        elif o == "gerilimsiz":
            fs.append(50.0 * math.exp(-(t - T0) / 0.8)); us.append(100.0 * math.exp(-(t - T0) / 0.15))
        else:
            fs.append(min(60.0, max(40.0, 50.0 + hiz * (t - T0)))); us.append(100.0)
    lv = num(p, "lv", 40)
    kilit = [u < lv for u in us]
    ust = sz_kademe(ts, fs, num(p, "f_ust", 51.0), num(p, "t_ust", 0.1), True, 0.002)
    alt = sz_kademe(ts, fs, num(p, "f_alt", 47.0), num(p, "t_alt", 0.1), False, 0.002, kilit=kilit)
    acan = min(((r["acma"], ad, r["basla"]) for ad, r in (("fX", ust), ("f<", alt)) if r["acma"] is not None), default=(None, "", None))
    beklenen = o in ("eksik", "fazla")
    t_esik = None if acan[2] is None else acan[2] - T0
    t_tem = None if acan[0] is None else acan[0] - acan[2] + tk          # eşiğin aşılmasından kesicinin açmasına
    c = tek_hat(("Santral", f"H = {fnum(h, 1)} s"), ("Dağıtım şebekesi", OLAY[o].split(":")[0]), ("81 · 81U", (f"{acan[1]} AÇTI") if acan[0] is not None else "açmadı"),
                "acti" if acan[0] is not None else ("gecersiz" if beklenen else "normal"), None, "sag", ileri=False, kesici_acik=acan[0] is not None)
    c.yazi(500, 190, f"Frekansın değişim hızı: {fnum(hiz, 2)} Hz/s" if o in ("eksik", "fazla") else OLAY[o], "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, (f"Eşiğe {fnum(t_esik, 2)} s'de ulaşıldı; {fnum(t_tem, 2)} s sonra ayrıldı") if acan[0] is not None else "Frekans sınırların içinde kaldı ya da kademe kilitli", "#334155", 11)
    c.yazi(500, 226, f"Düşük gerilim kilitleme %{fnum(lv, 0)}: altında f< kademesi çalışmaz", "#334155", 11)
    ozet = [
        K("Sonuç", (f"{acan[1]} açtı") if acan[0] is not None else "bağlı kaldı", "ok" if (acan[0] is not None) == beklenen else "bad", ("adada kalmadı" if acan[0] is not None else "ada sürüyor!") if beklenen else ("gereksiz açma" if acan[0] is not None else "doğru: açma gerekmez")),
        K("Eşiği aştıktan sonra temizleme", f"{fnum(t_tem, 2)} s" if t_tem is not None else "—", "info" if t_tem is None else ("ok" if t_tem <= 0.2 + 1e-9 else "bad"), "Tebliğ sınırı 0,2 s"),
        K("Frekansın değişim hızı", f"{fnum(hiz, 2)} Hz/s", "info", "ΔP · fn / (2H)"),
        K("Adanın tespit süresi", f"{fnum((acan[0] - T0 + tk), 2)} s" if acan[0] is not None else "—", "info", "olay başından kesicinin açmasına"),
        K("Ayarlar", f"{fnum(num(p, 'f_alt', 47.0), 2)} – {fnum(num(p, 'f_ust', 51.0), 2)} Hz", "ok" if num(p, "f_ust", 51.0) <= 51.0 and 47.0 <= num(p, "f_alt", 47.0) <= 49.5 else "bad", "Tebliğ: 47 (…49,5) ve 51 Hz"),
    ]
    kontroller = [
        C("Bu olayda davranış doğru mu?", (f"{acan[1]} açtı") if acan[0] is not None else "açmadı", "adada ayrılır; küçük şebeke salınımında ve enerjisiz barada açmaz", (acan[0] is not None) == beklenen, LUY + "; " + P3U + " böl. 5.37", "resmi"),
        C("Aşırı frekans ayarı", f"{fnum(num(p, 'f_ust', 51.0), 2)} Hz · röle {fnum(num(p, 't_ust', 0.1), 2)} s + kesici = {fnum(num(p, 't_ust', 0.1) + tk, 2)} s", "51 Hz → temizleme ≤ 0,2 s", num(p, "f_ust", 51.0) <= 51.0 + 1e-9 and num(p, "t_ust", 0.1) + tk <= 0.2 + 1e-9, LUY, "resmi"),
        C("Düşük frekans ayarı", f"{fnum(num(p, 'f_alt', 47.0), 2)} Hz · {fnum(num(p, 't_alt', 0.1) + tk, 2)} s", "47 Hz → 0,2 s; dağıtım şirketi görüşüyle 47–49,5 Hz ve 0,2–300 s", 47.0 - 1e-9 <= num(p, "f_alt", 47.0) <= 49.5 and (num(p, "t_alt", 0.1) + tk <= 0.2 + 1e-9 or num(p, "f_alt", 47.0) > 47.0), LUY, "resmi"),
        C("Düşük gerilim kilitleme", f"%{fnum(lv, 0)} Un", "%10 … %100; enerjisiz barada yanlış açmayı önler", 10 <= lv <= 100, P3U + " Çizelge 91 (kilit, en büyük faz arası gerilime bakar; 45–65 Hz aralığında geçerli)", "resmi"),
        C("Rölenin en kısa süresi 0,2 s'ye sığıyor mu?", f"0,08 s + kesici {fnum(tk, 2)} s = {fnum(0.08 + tk, 2)} s", "≤ 0,2 s", 0.08 + tk <= 0.2, P3U + " Çizelge 91 (süre 0,08 … 300 s; başlatma süresi < 100 ms)", "resmi"),
    ]
    girdiler = [
        G("Dağıtım şirketinin frekans koruma ayarları", "51 Hz / 47 Hz (düşük frekans 47–49,5 Hz arasında istenebilir)", "Bağlantı görüşü; koruma tutanağı", "Sınırlar Tebliğ'dedir; tesise özel değeri dağıtım şirketi verir", "fX, f< ve süreleri"),
        G("Kesicinin açma süresi", f"{fnum(tk * 1000, 0)} ms", "Kesici etiketi", "0,2 s temizleme süresine kesici dâhildir", "röle süresi ≤ 0,2 − kesici"),
        G("Santralin atalet sabiti", f"H = {fnum(h, 1)} s", "Jeneratör ve tahrik makinesi verisi", "Adada frekansın ne kadar hızlı kayacağını belirler: tespit süresi buna bağlıdır", "df/dt = ΔP · fn / (2H)"),
        G("Frekansın ölçüldüğü gerilim girişleri", "ilk iki gerilim girişi", "Röle bağlantı şeması", "Bu girişlerden en az birinde gerilim yoksa frekans ölçülemez", "Düşük gerilim kilitleme"),
        G("Adada beklenen üretim–yük farkı", f"%{fnum(dp * 100, 0)}", "İşletme senaryosu (ihracat / ithalat düzeyi)", "Fark küçükse frekans yavaş kayar: frekans rölesi adayı geç görür ya da hiç görmez", "bkz. ROCOF sayfası (kör bölge)"),
    ]
    adimlar = [
        A("Röle süresi", "t röle = 0,2 s − kesici süresi", f"0,2 − {fnum(tk, 2)}", f"≤ {fnum(0.2 - tk, 2)} s", LUY, "resmi", ["Kesicinin açma süresi"], "fX ve f< çalışma süresi"),
        A("Adada frekansın değişim hızı", "df/dt = ΔP · fn / (2 · H)", f"{fnum(dp, 2)} × 50 / (2 × {fnum(h, 1)})", f"{fnum(dp * 50 / (2 * h), 2)} Hz/s", "salınım denklemi (ΔP: santral gücünün katı)", "resmi", ["Santralin atalet sabiti", "Adada beklenen üretim–yük farkı"]),
        A("Eşiğe ulaşma süresi", "t = Δf / (df/dt)", f"{fnum(50 - num(p, 'f_alt', 47.0), 2)} Hz / {fnum(dp * 50 / (2 * h), 2)} Hz/s (düşük frekans)", f"{fnum((50 - num(p, 'f_alt', 47.0)) / max(dp * 50 / (2 * h), 1e-9), 2)} s", "doğrusal kayma kabulü (regülatör etkisi yok)", "ikincil"),
    ]
    ayarlar = [
        S("fX › Karşılaştırma modu", ">", "> / <", "81-1 ve 81-2 kademeleri aşırı ya da düşük frekans için kullanılabilir", P3U + " böl. 5.37"),
        S("fX › Başlatma · Çalışma süresi", f"{fnum(num(p, 'f_ust', 51.0), 2)} Hz · {fnum(num(p, 't_ust', 0.1), 2)} s", "40,0 … 70,0 Hz · 0,08 … 300 s; ekrandaki örnek 51,00 Hz / 0,20 s", "Tebliğ: 51 Hz → 0,2 s (kesici dâhil): röle süresi kısaltılır", P3U + " Çizelge 91; " + LUY),
        S("f< › Başlatma · Çalışma süresi", f"{fnum(num(p, 'f_alt', 47.0), 2)} Hz · {fnum(num(p, 't_alt', 0.1), 2)} s", "40,0 … 64,0 Hz; ekrandaki örnek 48,00 Hz / 3,00 s", "Tebliğ: 47 Hz → 0,2 s; dağıtım şirketi 47–49,5 Hz ve 0,2–300 s isteyebilir", P3U + " Çizelge 92; " + LUY),
        S("Düşük gerilim kilitleme", f"%{fnum(lv, 0)} Un", "%10 … %100; ekrandaki örnek %40", "Gerilim yokken (kesici açık, bara enerjisiz) düşük frekans kademesini susturur", P3U + " Çizelge 91"),
        S("fXX, f<< kademeleri", "ikinci eşik (ör. alarm ya da daha geniş sınır)", "toplam 5 kademe", "Dağıtım şirketi iki kademeli düşük frekans isterse", P3U + " böl. 5.37"),
    ]
    test = (kademe_test("fX (aşırı frekans)", num(p, "f_ust", 51.0), "Hz", num(p, "t_ust", 0.1), True, "±20 mHz", "±%1 ya da ±30 ms", 0.998, 2)
            + kademe_test("f< (düşük frekans)", num(p, "f_alt", 47.0), "Hz", num(p, "t_alt", 0.1), False, "±20 mHz", "±%1 ya da ±30 ms", 1.002, 2)
            + [T("Düşük gerilim kilitleme", f"Frekans {fnum(num(p, 'f_alt', 47.0) - 0.5, 1)} Hz; gerilimi %{fnum(lv, 0)}'ın altına indirin", "f< başlamaz; gerilim eşiğin üstüne çıkınca başlar", "±%3 ya da ±0,5 V"),
               T("Röle yeniden başlatma", "Röleyi düşük frekans varken enerjilendirin", "Frekans eşiğin üstüne çıkana kadar başlatma ve açma kilitlidir", P3U + " Çizelge 91 notu")])
    g = {"baslik": "Frekans ve kademelerin başlaması", "x_ad": "Zaman (s)", "y_ad": "Frekans (Hz)", "zaman": True, "ymin": 44, "ymax": 54,
         "seriler": [{"ad": "frekans", "renk": "#dc2626", "pts": [[round(t, 2), round(min(54, max(44, f)), 3)] for t, f in zip(ts, fs)]}],
         "yatay": [{"y": num(p, "f_ust", 51.0), "etiket": "fX", "renk": "#1a4d8f"}, {"y": num(p, "f_alt", 47.0), "etiket": "f<", "renk": "#1a4d8f"}],
         "isaretler": ([{"x": acan[2], "etiket": "başlatma"}, {"x": acan[0] + tk, "etiket": "kesici açtı"}] if acan[0] is not None else [])}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["_81_", "81u"],
        "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Şebekeye bağlı bir santral frekansı değiştiremez; binlerce MW'lık sistemin frekansına kilitlidir. Frekans sınırların dışına çıktıysa ya sistemde büyük bir olay vardır ya da bağlantı kopmuştur.",
            "Bağlantı koptuğunda santral kendi bölgesindeki yükle baş başa kalır (ada). Üretim yüke eşit değilse aradaki fark dönen kütleleri hızlandırır ya da yavaşlatır: frekans kayar.",
            f"Kayma hızı farkın büyüklüğüne ve ataletle ters orantılıdır: df/dt = ΔP · fn / (2H). Şu an {fnum(abs(hiz), 2)} Hz/s.",
            "Frekans eşiği geçince kademe başlar; süre dolunca açar. Tebliğ'deki 0,2 s kesiciyi de içerir: röleye en çok 0,2 − kesici süresi girilir.",
            "Bara enerjisizken frekans ölçülemez ve «sıfır» gibi görünür. Düşük gerilim kilitleme, gerilim yokken düşük frekans kademesini susturur.",
        ],
        "dersler": [
            "Ayarlar Tebliğ'den: 51 Hz ve 47 Hz, temizleme 0,2 s. Düşük frekans dağıtım şirketi görüşüyle 49,5 Hz'e kadar çıkabilir.",
            "Röle süresi = 0,2 s − kesici süresi; rölenin en kısa süresi 0,08 s'dir.",
            "Üretim yüke yakınsa frekans yavaş kayar: adayı frekans rölesi tek başına göremeyebilir (ROCOF / vektör kayması bunun içindir).",
        ],
        "tablolar": [{"baslik": "Tebliğ Ek-2 Tablo-2: frekans", "cols": ["Parametre", "Açma ayarı", "Temizleme süresi", "Röle süresi (kesici " + fnum(tk * 1000, 0) + " ms)"], "rows": [
            ["Aşırı frekans (81/O)", "51 Hz", "0,2 s", f"≤ {fnum(0.2 - tk, 2)} s"], ["Düşük frekans (81/U)", "47 Hz", "0,2 s", f"≤ {fnum(0.2 - tk, 2)} s"],
            ["Düşük frekans (81/U) — dağıtım şirketi görüşüyle", "47 – 49,5 Hz", "0,2 – 300 s", "istenen süre − kesici"]], "not": LUY + ". AG'den bağlanan tesislerde (Tablo-1) süreler 0,5 s'dir."}],
    }
