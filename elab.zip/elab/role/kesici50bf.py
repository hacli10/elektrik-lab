"""Kesici arıza koruması (ANSI 50BF, CBFP) — Easergy P3 «Breaker failure» kademeleri.

Dayanak: P3U/en M/J006 böl. 5.17 (kademe, seçilen açma çıkışına giden işareti izler; işaret kademenin süresinden uzun sürerse çıkış matrisinde tanımlı başka bir çıkışı —
üst kesiciyi — çalıştırır), Çizelge 61 (izlenen röle T1–T7; süre 0,1–10,0 s; doğruluk ±20 ms); böl. 5.18 (iki özdeş kademe: birincisi yeniden açma — kesicinin ikinci bobini —,
ikincisi üst kesiciye açma; dört koşul seçici; sıfır akım dedektörü: bütün faz akımları eşiğin altına inince sıfırlar — kutuplardan biri kısmen iletirken koruma kademesi
bırakabilir, ayrı düşük akım koşulu bunu önler; sıfır akım eşiği her zaman AT anma akımına göredir; gecikme = kesici açma süresi + koruma kademesinin bırakma süresi +
emniyet payı — Şekil 86), Çizelge 63 (sıfır akım 0,05–0,2 ×In; süre 0,04–0,2 s; doğruluk ±20 ms)."""
from __future__ import annotations

from .ortak import A, C, G, K, P3U, S, T, URRA, Cizim, ctl, fnum, num, opt

ID = "kesici50bf"
BASLIK = "Kesici arıza (50BF)"
IKON = "🧱"
GIRIS = ("Koruma açma verdi ama kesici açmadı: bobin yanık, mekanizma sıkışmış ya da bir kutup hâlâ iletiyor. Kesici arıza koruması bunu bekler; açma işareti "
         "verildikten belirli bir süre sonra akım hâlâ akıyorsa bir üstteki kesiciyi açtırır. Bütün iş o sürenin doğru seçilmesindedir.")

DURUM = {"acti": "Kesici açtı (normal)", "tutuk": "Kesici hiç açmadı", "kismi": "Bir kutup kısmen iletiyor (akım küçüldü ama kesilmedi)", "gec": "Kesici geç açtı"}

KONTROLLER = [
    ctl("durum", "Kesicinin davranışı", "sec", "tutuk", secenek=opt(*DURUM.items())),
    ctl("t_role", "Koruma kademesinin gecikmesi", "sayi", 0.30, min=0.0, max=2.0, adim=0.01, birim="s"),
    ctl("t_kesici", "Kesicinin açma süresi", "sayi", 60, min=20, max=120, adim=5, birim="ms"),
    ctl("t_birak", "Koruma kademesinin bırakma süresi", "sayi", 95, min=20, max=150, adim=5, birim="ms", yardim="Easergy P3 aşırı akım kademelerinde < 95 ms"),
    ctl("pay", "Emniyet payı", "sayi", 40, min=0, max=150, adim=5, birim="ms"),
    ctl("t_bf", "Röle › 50BF çalışma süresi", "sayi", 0.20, min=0.04, max=10.0, adim=0.01, birim="s"),
    ctl("i0", "Röle › Sıfır akım eşiği", "sayi", 0.10, min=0.05, max=0.20, adim=0.01, birim="×In"),
    ctl("sifir", "Röle › Sıfır akım denetimi açık", "onay", True),
    ctl("i_kismi", "Kısmen ileten kutuptan geçen akım", "sayi", 0.40, min=0.02, max=2.0, adim=0.02, birim="×In", goster={"durum": ["kismi"]}),
    ctl("i_esik", "Koruma kademesinin başlatma eşiği", "sayi", 1.20, min=0.1, max=5.0, adim=0.05, birim="×In", goster={"durum": ["kismi"]}),
    ctl("t_gec", "Geç açan kesicinin süresi", "sayi", 180, min=60, max=600, adim=10, birim="ms", goster={"durum": ["gec"]}),
    ctl("t_ust", "Üst kesicinin açma süresi", "sayi", 60, min=20, max=120, adim=5, birim="ms"),
]


def run(p: dict) -> dict:
    d = p.get("durum") if p.get("durum") in DURUM else "tutuk"
    tr, tk, tb, pay = num(p, "t_role", 0.3), num(p, "t_kesici", 60) / 1000, num(p, "t_birak", 95) / 1000, num(p, "pay", 40) / 1000
    tbf, tu = num(p, "t_bf", 0.2), num(p, "t_ust", 60) / 1000
    gerek = tk + tb + pay
    t_acma = tr                                                    # koruma açma verir; 50BF sayacı başlar
    t_kes = {"acti": tr + tk, "gec": tr + num(p, "t_gec", 180) / 1000}.get(d)     # akımın gerçekten kesildiği an (yoksa None)
    i_son = {"kismi": num(p, "i_kismi", 0.4)}.get(d, 6.0)          # açma komutundan sonra akan akım (×In)
    # 50BF'nin sıfırlanması: akım kesildiyse; ya da sıfır akım denetimi kapalıyken koruma kademesi bıraktıysa (kısmi iletimde akım eşiğin altına iner)
    if t_kes is not None:
        sifirlanir = t_kes + (0.0 if p.get("sifir") else tb)
    elif d == "kismi" and not p.get("sifir") and i_son < num(p, "i_esik", 1.2):
        sifirlanir = tr + tk + tb                                  # koruma kademesi bıraktı: 50BF işareti de düştü
    elif d == "kismi" and p.get("sifir") and i_son < num(p, "i0", 0.1):
        sifirlanir = tr + tk
    else:
        sifirlanir = None
    bf = sifirlanir is None or sifirlanir > t_acma + tbf
    t_bf_acma = t_acma + tbf if bf else None
    t_son = (t_bf_acma + tu) if bf else t_kes
    beklenen = d in ("tutuk", "kismi")
    c = Cizim(900, 300)
    c.kutu(20, 51, 110, 54, "Besleme", "")
    c.hat("M130,78 H190", "L1", hot=not (bf and True) or True, w=3)
    c.dikdortgen(190, 68, 20, 20, "ariza" if bf else "cizgi", dolgu="#fee2e2" if bf else "#fff"); c.yazi(200, 60, "üst kesici" + (" (50BF açtırdı)" if bf else ""), "#b91c1c" if bf else "#475569", 10, anchor="middle")
    c.hat("M210,78 H300", "L1", hot=True, w=3); c.hat("M300,40 V116", "cizgi", w=5)
    c.hat("M300,78 H380", "L1", hot=True, w=3)
    renk = {"acti": ("ok", "#dcfce7"), "gec": ("uyari", "#fef3c7")}.get(d, ("ariza", "#fee2e2"))
    c.dikdortgen(380, 68, 20, 20, renk[0], dolgu=renk[1]); c.yazi(390, 60, {"acti": "kesici (açtı)", "gec": "kesici (geç açtı)", "tutuk": "kesici (AÇMADI)", "kismi": "kesici (kutup iletiyor)"}[d], "#475569" if d == "acti" else "#b91c1c", 10, anchor="middle")
    c.toroid(450, 78, 7, 17); c.hat("M400,78 H640", "L1", hot=True, w=3); c.simsek(634, 70, 1.1); c.hat("M640,78 V122", "ariza", hot=True); c.toprak(640, 124, "ariza")
    c.hat("M450,96 V160", "cizgi", kesik=True, w=1.4)
    c.kutu(360, 160, 200, 58, "Koruma + 50BF", ("50BF AÇTI — üst kesiciye") if bf else "50BF sıfırlandı", "acti" if bf else "normal")
    c.hat("M380,160 V92", "ariza", kesik=True, w=1.4); c.yazi(330, 140, "açma", "#b91c1c", 10)
    if bf:
        c.hat("M360,190 H200 V92", "ariza", kesik=True, w=1.6); c.yazi(215, 184, "50BF açma", "#b91c1c", 10)
    c.yazi(590, 176, f"Açma komutu {fnum(tr * 1000, 0)} ms'de · 50BF süresi {fnum(tbf * 1000, 0)} ms", "#334155", 11)
    c.yazi(590, 194, f"Gereken en kısa süre: {fnum(gerek * 1000, 0)} ms", "#b91c1c" if tbf < gerek else "#334155", 11.5, kalin=True)
    c.yazi(590, 212, f"Arıza toplam {fnum(t_son * 1000, 0)} ms sürdü" if t_son is not None else "Arıza temizlenmedi", "#334155", 11)
    ozet = [
        K("50BF", "AÇTI" if bf else "sıfırlandı", "ok" if bf == beklenen else "bad", ("doğru" if bf == beklenen else "YANLIŞ") + " — kesici " + ("arızalı" if beklenen else "sağlam")),
        K("Toplam temizleme", f"{fnum(t_son * 1000, 0)} ms" if t_son is not None else "temizlenmedi", "info" if t_son is not None else "bad", "arıza başlangıcından akımın kesilmesine"),
        K("50BF süresi", f"{fnum(tbf * 1000, 0)} ms", "ok" if tbf >= gerek - 1e-9 else "bad", f"gereken ≥ {fnum(gerek * 1000, 0)} ms"),
        K("Sıfırlama payı", f"{fnum((tbf - (tk + (0 if p.get('sifir') else tb))) * 1000, 0)} ms", "ok" if tbf - (tk + (0 if p.get("sifir") else tb)) >= pay - 1e-9 else "bad", "sağlam kesicide 50BF'nin sıfırlanmasına kalan"),
        K("Açma komutundan sonra akım", f"{fnum(i_son if t_kes is None else 0, 2)} ×In", "info", "sıfır akım eşiği " + fnum(num(p, "i0", 0.1), 2) + " ×In"),
    ]
    kontroller = [
        C("Bu durumda davranış doğru mu?", "50BF açtı" if bf else "50BF sıfırlandı", "kesici açmadıysa üst kesiciyi açtırır; açtıysa sıfırlanır", bf == beklenen, P3U + " böl. 5.17–5.18", "resmi"),
        C("50BF süresi yeterince uzun mu? (sağlam kesicide yanlış açmasın)", f"{fnum(tbf * 1000, 0)} ms", f"≥ kesici {fnum(tk * 1000, 0)} + bırakma {fnum(tb * 1000, 0)} + pay {fnum(pay * 1000, 0)} = {fnum(gerek * 1000, 0)} ms", tbf >= gerek - 1e-9,
          "CBFP gecikmesi = kesici açma süresi + koruma kademesinin bırakma süresi + emniyet payı — " + P3U + " böl. 5.18 Şekil 86", "resmi"),
        C("Üst korumadan önce mi?", f"koruma {fnum(tr * 1000, 0)} + 50BF {fnum(tbf * 1000, 0)} + üst kesici {fnum(tu * 1000, 0)} = {fnum((tr + tbf + tu) * 1000, 0)} ms", "üst rölenin kendi gecikmesinden kısa olmalı (yoksa 50BF'nin yararı kalmaz)", None,
          "Yerel yedek koruma: üst rölenin zaman kademesini beklemeden temizler — " + P3U + " böl. 5.18; kademe aralığı: " + URRA, "ikincil"),
        C("Kısmen ileten kutup görülüyor mu?", "sıfır akım denetimi " + ("açık" if p.get("sifir") else "kapalı"), "açık; eşik 0,05 … 0,2 ×In", bool(p.get("sifir")),
          "Kutup kısmen iletirken akım koruma kademesini bırakacak kadar küçülebilir; ayrı düşük akım koşulu olmadan 50BF çalışmaz — " + P3U + " böl. 5.18 «Zero-current detector», Çizelge 63", "resmi"),
        C("Çıkış matrisi", "50BF → üst kesicinin açma çıkışı (ayrı röle)", "izlenen açma rölesinden farklı bir çıkış kullanılmalı", None, P3U + " böl. 5.17", "resmi"),
    ]
    girdiler = [
        G("Kesicinin açma süresi", f"{fnum(tk * 1000, 0)} ms", "Kesici etiketi; deney raporu (ana kontak süresi)", "50BF süresinin en büyük bileşeni", "t(50BF) ≥ t kesici + t bırakma + pay"),
        G("Koruma kademesinin bırakma süresi", f"{fnum(tb * 1000, 0)} ms", "Röle kılavuzu (Easergy P3 aşırı akım: < 95 ms)", "Akım kesildikten sonra koruma işaretinin düşmesi için geçen süre", "sıfır akım denetimi varsa bu bileşen kısalır"),
        G("Üst kesici ve onu açtıracak çıkış", "ayrı açma rölesi / GOOSE", "Tek hat şeması; sekonder şema", "50BF kendi kesicisini değil, arızayı besleyen bütün üst kesicileri açtırmalı", "çıkış matrisi"),
        G("Üst rölenin zaman kademesi", "ör. 0,6 s", "Koordinasyon çalışması", "50BF toplam süresi bunun altında kalırsa arıza daha erken temizlenir", "t koruma + t(50BF) + t üst kesici"),
        G("Kesicinin ikinci açma bobini var mı", "varsa yeniden açma (1. kademe)", "Kesici şeması", "İki kademe: önce kendi kesicisinin ikinci bobinine yeniden açma, sonra üst kesiciye", "50BF-1 / 50BF-2"),
    ]
    adimlar = [
        A("En kısa 50BF süresi", "t ≥ t kesici + t bırakma + emniyet payı", f"{fnum(tk * 1000, 0)} + {fnum(tb * 1000, 0)} + {fnum(pay * 1000, 0)} ms", f"{fnum(gerek * 1000, 0)} ms", P3U + " böl. 5.18 Şekil 86", "resmi", ["Kesicinin açma süresi", "Koruma kademesinin bırakma süresi"], "50BF Çalışma süresi"),
        A("Kesici arızasında toplam temizleme", "t koruma + t(50BF) + t üst kesici", f"{fnum(tr * 1000, 0)} + {fnum(tbf * 1000, 0)} + {fnum(tu * 1000, 0)} ms", f"{fnum((tr + tbf + tu) * 1000, 0)} ms", "zaman zinciri", "hesap", ["Üst kesici ve onu açtıracak çıkış"]),
        A("Sıfır akım eşiği", "en küçük ölçülebilir akımın üstü, en küçük arıza akımının altı", "0,05 … 0,2 ×In (AT anma akımı)", f"{fnum(num(p, 'i0', 0.1), 2)} ×In", P3U + " Çizelge 63 (eşik her zaman AT anma akımına göredir)", "resmi", [], "Sıfır akım eşiği"),
    ]
    ayarlar = [
        S("Breaker failure 2 — Etkin", "Açık", "—", "Koşul seçicili, sıfır akım denetimli kademe", P3U + " böl. 5.18"),
        S("Koşul 1 › başlatma işaretleri", "50/51, 67, 46, 49 … kademeleri", "—", "Faz akımı kademeleri; sıfır akım denetiminden yararlanır", P3U + " Çizelge 62"),
        S("Koşul 2 › başlatma işaretleri", "50N/51N, 67N kademeleri", "—", "Toprak akımı kademeleri; ayrı sıfır akım eşiği", P3U + " Çizelge 62"),
        S("Koşul 3 › başlatma işaretleri", "27, 59, 59N, 81, 81R, 32 …", "—", "Akımla sıfırlanamayan korumalar: kesici konum kontağıyla sıfırlanır", P3U + " Çizelge 62"),
        S("Sıfır akım denetimi · eşik", ("Açık" if p.get("sifir") else "Kapalı") + f" · {fnum(num(p, 'i0', 0.1), 2)} ×In", "0,05 … 0,2 ×In", "Bütün faz akımları bu değerin altına inince 50BF sıfırlanır", P3U + " Çizelge 63"),
        S("Çalışma süresi", f"{fnum(tbf, 2)} s", "0,04 … 0,2 s (kademe 2); 0,1 … 10,0 s (böl. 5.17'deki kademe)", "Kesici süresi + bırakma + pay", P3U + " Çizelge 61, 63"),
        S("Çıkış matrisi › 50BF açma → üst kesici", "bağlı («Connected»)", "—", "İzlenen açma rölesinden başka bir çıkış", P3U + " böl. 5.17"),
    ]
    test = [
        T("Sağlam kesici", f"Arıza akımını verin; koruma açma verdikten {fnum(tk * 1000, 0)} ms sonra akımı kesin", "50BF başlar ve sıfırlanır; üst kesici çıkışı çalışmaz", "—"),
        T("Tutuk kesici", "Arıza akımını kesmeyin", f"Koruma açmasından {fnum(tbf * 1000, 0)} ms sonra 50BF çıkışı çalışır", "±20 ms"),
        T("Sıfır akım eşiği", f"Açma komutundan sonra akımı {fnum(num(p, 'i0', 0.1) * 1.5, 2)} ×In'e düşürün (koruma eşiğinin altı, sıfır akım eşiğinin üstü)", "Sıfır akım denetimi açıkken 50BF açar; kapalıyken sıfırlanır", "—"),
        T("Kesici konumuyla sıfırlama (Koşul 3)", "Gerilim korumasından açma verin; kesici açık bilgisini dijital girişe verin", "50BF sıfırlanır", "—"),
    ]
    tmax = max((t_son or (tr + tbf + tu)) * 1.25, 0.6)
    olay = [[0, 0], [0, 6.0]]
    if t_kes is not None and not bf:
        olay += [[t_kes, 6.0], [t_kes, 0], [tmax, 0]]
    elif d == "kismi":
        olay += [[tr + tk, 6.0], [tr + tk, i_son], [t_son or tmax, i_son], [t_son or tmax, 0 if t_son else i_son], [tmax, 0 if t_son else i_son]]
    else:
        olay += [[t_son or tmax, 6.0], [t_son or tmax, 0 if t_son else 6.0], [tmax, 0 if t_son else 6.0]]
    g = {"baslik": "Zaman çizgisi: arıza akımı ve komutlar", "x_ad": "Zaman (s)", "y_ad": "Akım (×In)", "ymin": 0, "ymax": 7.5,
         "seriler": [{"ad": "arıza akımı", "renk": "#dc2626", "pts": [[round(x, 3), y] for x, y in olay]}],
         "yatay": [{"y": num(p, "i0", 0.1), "etiket": "sıfır akım eşiği", "renk": "#1a4d8f"}],
         "isaretler": [{"x": tr, "etiket": "koruma açma verdi"}] + ([{"x": t_bf_acma, "etiket": "50BF açma verdi"}, {"x": t_bf_acma + tu, "etiket": "üst kesici açtı"}] if bf else [{"x": tr + tbf, "etiket": "50BF süresi dolardı"}])}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["50bf"],
        "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Koruma kademesi açma komutunu verdiği anda 50BF sayacı da başlar. Kademe aynı açma çıkışına giden bütün işaretleri izler.",
            f"Kesici sağlamsa {fnum(tk * 1000, 0)} ms içinde akımı keser; koruma kademesi bırakır ve 50BF sıfırlanır. Süre, bu olağan zincirin (kesici + bırakma) üstünde bir payla seçilir: {fnum(gerek * 1000, 0)} ms.",
            "Süre dolduğunda akım hâlâ akıyorsa kesici açamamıştır. 50BF başka bir çıkıştan üst kesiciyi açtırır; arıza, üst rölenin zaman kademesi beklenmeden temizlenir.",
            "İki kademe varsa birincisi önce kendi kesicisinin ikinci bobinine yeniden açma verir, ikincisi üst kesiciye gider.",
            "Kesicinin bir kutbu kısmen iletirse akım küçülür ama kesilmez. Koruma kademesi eşiğin altına inen akımla bırakır ve 50BF işaretini de düşürür. Bunu önlemek için 50BF kendi düşük akım eşiğine bakar: akım gerçekten sıfıra inmedikçe sıfırlanmaz.",
            "Gerilim ve frekans korumalarında akımla sıfırlama olmaz; orada kesici konum kontağı kullanılır.",
        ],
        "dersler": [
            "t(50BF) = kesici açma süresi + koruma bırakma süresi + emniyet payı. Kısaysa sağlam kesicide üst kesiciyi açtırır.",
            "50BF çıkışı izlenen açma rölesinden farklı olmalı ve arızayı besleyen bütün üst kesicilere gitmelidir.",
            "Sıfır akım denetimini açık tutun: kısmen ileten kutbu başka hiçbir şey göremez.",
            "Sıfır akım eşiği trafo ve motor rölelerinde de AT anma akımına göredir.",
        ],
        "tablolar": [{"baslik": "Dört durumda sonuç (bu ayarlarla)", "cols": ["Kesici", "50BF", "Toplam temizleme"], "rows": [
            (lambda r, ad: [ad, r["ozet"][0]["deger"], r["ozet"][1]["deger"]])(run({**p, "durum": dd, "_ic": True}), DURUM[dd]) for dd in DURUM] if not p.get("_ic") else []}],
    }
