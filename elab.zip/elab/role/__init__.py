"""Röle laboratuvarı: koruma fonksiyonlarının ayar hesabı, röle ekranı eşlemesi, canlı benzetimi ve test planı.

Proje verisi okumaz, yazmaz. Her fonksiyon bir modüldür: ID, BASLIK, IKON, GIRIS,
KONTROLLER ve run(params). Sonuç, laboratuvarın ortak anahtarlarına ek olarak girdiler / adimlar / ayarlar / test / gorsel taşır (bkz. ortak.py)."""
from __future__ import annotations

import importlib
import json
from pathlib import Path

# trafo demerajı (demeraj_trafo) ve arızanın trafodan geçişi (trafo_gecis) sayfaları güç sistemi laboratuvarının «Dağıtım trafosu» grubunda gösterilir (elab/guc)
GRUPLAR = [
    ("Hazırlık", ["hazirlik"]),
    ("Temeller", ["olcme", "bilesen", "at_doyma"]),
    ("Kısa devre ve kaynaklar", ["kisa_devre", "evirici"]),
    ("Yol alma", ["yolalma_motor"]),
    ("Yönlü koruma", ["yon_faz", "yon_toprak", "toprak_fider", "guc32"]),
    ("Diferansiyel", ["dif87t", "dif_dalga", "ref64", "dif_yuksek"]),
    ("Mesafe ve mantık", ["mesafe21", "ters_kilit"]),
    ("Aşırı akım", ["asiri_akim", "toprak_akim", "soguk_yuk", "harmonik_kilit", "sotf50hs", "gerilim51v", "negatif", "termik", "isinma", "ark"]),
    ("Gerilim ve frekans", ["gerilim", "v2_47", "vf_24", "vo_59n", "frekans", "frekans_dinamik", "rocof", "vektor78"]),
    ("Kesici ve bağlantı", ["kesici50bf", "kesici_ark", "tekrar79", "senkron25"]),
    ("Ölçü ve yardımcı devreler", ["denetim60", "at_vi", "dc_kacak", "sayac_baglanti"]),
    ("Araçlar", ["vaka"]),
    ("Saha araçları", ["gepa_roc"]),
]
KONU_MODULLERI = [k for _, ks in GRUPLAR for k in ks]
GRUP_OF = {k: g for g, ks in GRUPLAR for k in ks}
GORSEL_KOK = Path(__file__).resolve().parents[2] / "gorseller"            # uygulama klasöründeki «gorseller» (kullanıcı yeni klasör / görüntü ekleyebilir)
GORSEL_DIZIN = Path(__file__).resolve().parent / "gorsel_dizin.json"      # tarayıcı motorunda klasör yoktur; derlemede yazılan dizin okunur (araclar/derle.py)
# «resmi» durumunun koşulu: dayanakta bir mevzuat / şartname / üretici kılavuzu / üretici yazılımı ekranı anılması. Yoksa satır «hesap»tır.
RESMI_IZ = ("kılavuz", "Tebliğ", "TEDAŞ", "Yön.", "Çizelge", "böl.", "kanıt", "eSetup")
UZANTI = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif"}


def _mods() -> list:
    out = []
    for name in KONU_MODULLERI:
        try:
            out.append(importlib.import_module(f"{__name__}.{name}"))
        except ModuleNotFoundError as e:
            if e.name != f"{__name__}.{name}":
                raise
    return out


def spec() -> list[dict]:
    return [{"id": m.ID, "baslik": m.BASLIK, "ikon": m.IKON, "giris": m.GIRIS, "kontroller": m.KONTROLLER, "grup": GRUP_OF.get(m.ID, "")} for m in _mods()]


def _find(topic: str):
    for m in _mods():
        if m.ID == topic:
            return m
    raise KeyError(f"Bilinmeyen röle laboratuvarı konusu: {topic}")


def defaults(topic: str) -> dict:
    return {c["key"]: c["vars"] for c in _find(topic).KONTROLLER}


def run(topic: str, params: dict | None = None) -> dict:
    m = _find(topic)
    p = defaults(topic)
    p.update({k: v for k, v in (params or {}).items() if v is not None})
    out = m.run(p)
    for k in ("ozet", "kontroller", "anlatim", "dersler", "grafikler", "tablolar", "girdiler", "adimlar", "ayarlar", "test", "gorsel"):
        out.setdefault(k, [])
    out.setdefault("sahne", {})
    for satir in out["adimlar"] + out["kontroller"] + out["ayarlar"]:
        if satir.get("durum") == "resmi" and not any(m in satir.get("kaynak", "") for m in RESMI_IZ):
            satir["durum"] = "hesap"
    out["gorsel"] = gorsel_bul(out["gorsel"])
    out["konu"] = topic
    out["params"] = p
    out["bolum"] = "role"
    return out


# ---------------- röle ekran görüntüleri (kullanıcının klasörü) ----------------
def gorseller() -> list[dict]:
    """gorseller altındaki röle ailesi klasörleri ve içlerindeki görüntüler. Klasör yoksa (tarayıcı motoru) derlemede yazılan dizin kullanılır."""
    out = []
    if not GORSEL_KOK.is_dir():
        try:
            return json.loads(GORSEL_DIZIN.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return out
    for d in sorted(x for x in GORSEL_KOK.iterdir() if x.is_dir()):
        fs = sorted(f.name for f in d.iterdir() if f.suffix.lower() in UZANTI)
        if fs:
            out.append({"aile": d.name, "dosyalar": fs})
    return out


def gorsel_bul(anahtarlar: list) -> list[dict]:
    """Bir konunun ekran görüntüleri: dosya adında verilen anahtarlardan biri geçen bütün görüntüler (her röle ailesi klasöründe aranır)."""
    keys = [str(a).lower() for a in (anahtarlar or []) if isinstance(a, str)]
    out = []
    if not keys:
        return out
    for g in gorseller():
        for f in g["dosyalar"]:
            ad = f.lower()
            if any(k in ad for k in keys):
                out.append({"aile": g["aile"], "dosya": f})
    return out


def gorsel_yolu(aile: str, dosya: str) -> Path | None:
    """Görüntünün diskteki yolu; klasörün dışına çıkan ya da görüntü olmayan istekler reddedilir."""
    try:
        p = (GORSEL_KOK / aile / dosya).resolve()
        p.relative_to(GORSEL_KOK.resolve())
    except (ValueError, OSError):
        return None
    return p if p.is_file() and p.suffix.lower() in UZANTI else None
