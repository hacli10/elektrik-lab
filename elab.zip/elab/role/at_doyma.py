"""Akım trafosu doyması korumayı nasıl etkiler: doymuş çekirdeğin sekonder akımı, rölenin ondan ölçtüğü değer ve bunun ani kademeye, ters zamanlı
kademeye ve diferansiyele etkisi.

Dayanak: P3U/en M/J006 böl. 5.1 (aşırı akım elemanları için akım trafosu koşulu) — Çizelge 40 (sabit zamanlı: Isat > 1,5 × ayar; ters zamanlı:
Isat > 1,5 × en küçük(Isc max, 20 × ayar)), Denklem 2 (gerçek doğruluk sınır katsayısı = ALF × (Rct·Ins² + VA) / ((Rct + Rw)·Ins²)), Çizelge 41
(ayarlar bilinmiyorsa 5P20, 1 A: 2,5 VA, 5 A: 7,5 VA) ve not (röle akım girişinin empedansı 0,004 Ω). Zaman bölgesi benzetimi: lab/zaman.at_sim (iki parçalı
mıknatıslanma eğrisi; öğretim amaçlı). Geçici doyma için gereken büyütme (1 + X/R) temel bağıntıdır; TS EN 61869-2 TP sınıfları asıl metinden teyit edilmedi."""
from __future__ import annotations

import math

from . import dalga as D
from ..lab import zaman
from .dif87t import KONTROLLER as K87, esik
from .ortak import A, C, G, IEC, K, P3T, P3U, S, T, ctl, fnum, iec_sure, num, opt, tek_hat

ID = "at_doyma"
BASLIK = "Akım trafosu doyması ve koruma"
IKON = "🫧"
GIRIS = ("Akım trafosu doyduğunda sekonder akımı arıza akımını izlemeyi bırakır: dalga kırpılır, röle akımı eksik ölçer. Sonuç korumaya göre değişir — ani kademe "
         "gecikir, ters zamanlı kademe yavaşlar, diferansiyel dış arızada fark akımı görür. Akım trafosunu, yükünü ve arıza akımını değiştirin; rölenin "
         "gördüğünü izleyin.")
SINIF = {"5P10": (5, 10), "5P20": (5, 20), "10P10": (10, 10), "10P20": (10, 20)}
M = 100                 # at_sim'in kaydettiği örnek / periyot

KONTROLLER = [
    ctl("ik", "Arıza akımı", "sayi", 15, min=1, max=60, adim=0.5, birim="×In(AT)"),
    ctl("xr", "Arıza yolunun X/R oranı", "sayi", 15, min=0, max=60, adim=1, yardim="0: doğru akım bileşeni yok (simetrik akım)"),
    ctl("rem", "Çekirdekte kalan akı", "sayi", 0, min=0, max=80, adim=5, birim="%", yardim="Önceki arızadan ya da doğru akımla yapılan testten kalır; doymayı öne çeker"),
    ctl("sinif", "Akım trafosu sınıfı", "sec", "5P20", secenek=opt(*[(k, k) for k in SINIF])),
    ctl("va", "Anma yükü", "sec", 15, secenek=opt(*[(v, f"{v:g} VA") for v in (2.5, 5, 7.5, 10, 15, 30)])),
    ctl("ins", "Sekonder anma akımı", "sec", 5, secenek=opt((1, "1 A"), (5, "5 A"))),
    ctl("rct", "Sekonder sargı direnci Rct", "sayi", 0.3, min=0.05, max=10, adim=0.05, birim="Ω", yardim="AT test raporu; 1 A'lik trafoda birkaç ohm"),
    ctl("l_m", "AT–röle arası kablo (tek yön)", "sayi", 30, min=1, max=300, adim=1, birim="m"),
    ctl("kesit", "Kablo kesiti", "sec", 2.5, secenek=opt((1.5, "1,5 mm²"), (2.5, "2,5 mm²"), (4, "4 mm²"), (6, "6 mm²"))),
    ctl("i_ani", "Röle › I>> (ani kademe)", "sayi", 10, min=1, max=40, adim=0.5, birim="×In"),
    ctl("i_51", "Röle › I> (ters zamanlı, IEC NI)", "sayi", 1.0, min=0.2, max=4, adim=0.05, birim="×In"),
    ctl("k_51", "Röle › zaman çarpanı k", "sayi", 0.20, min=0.05, max=1.5, adim=0.01),
]


def hesap(p: dict) -> dict:
    hata, alf = SINIF.get(p.get("sinif"), SINIF["5P20"])
    ins, va, rct = num(p, "ins", 5), num(p, "va", 15), num(p, "rct", 0.3)
    rw = 2 * num(p, "l_m", 30) / (56 * num(p, "kesit", 2.5))                 # gidiş + dönüş (faz–toprak arızasında dönüş iletkeni de akım taşır)
    r2 = rct + rw + 0.004
    alf_g = alf * (rct * ins * ins + va) / (r2 * ins * ins)                    # P3U Denklem 2
    vk = alf * ins * (rct + va / (ins * ins))
    ik, xr = num(p, "ik", 15), num(p, "xr", 15)
    s = zaman.at_sim(round(ik * ins, 4), round(r2, 5), round(vk, 4), round(alf * ins, 4), float(xr), num(p, "rem", 0) / 100, False, 0.0, 6)
    ideal = [v / ins for v in s["ideal"]]; gercek = [v / ins for v in s["gercek"]]            # ×In
    # at_sim'in doğru akım bileşenli akımı kosinüsle başlar; ölçü için ilk N−1 örnek sıfır sayılır
    return {"alf": alf, "hata": hata, "alf_g": alf_g, "vk": vk, "rw": rw, "r2": r2, "t": s["t"], "ideal": ideal, "gercek": gercek, "aki": s["aki"], "t_doy": s["t_doy"],
            "m_i": D.temel(ideal, M), "m_g": D.temel(gercek, M), "h2": D.temel([a - b for a, b in zip(ideal, gercek)], M, 2), "fark": D.temel([a - b for a, b in zip(ideal, gercek)], M)}


def run(p: dict) -> dict:
    h = hesap(p)
    ik, xr, i_ani, i51, k51 = num(p, "ik", 15), num(p, "xr", 15), num(p, "i_ani", 10), num(p, "i_51", 1.0), num(p, "k_51", 0.2)
    ins = num(p, "ins", 5)
    t = h["t"]
    t_ideal = next((tt for tt, v in zip(t, h["m_i"]) if v >= i_ani), None)
    t_gercek = next((tt for tt, v in zip(t, h["m_g"]) if v >= i_ani), None)
    gecikme = (t_gercek - t_ideal) if (t_ideal is not None and t_gercek is not None) else None
    # periyot ortalamaları (rölenin «gördüğü» kalıcıya yakın değer): 2.–6. periyot
    ort = sum(h["m_g"][M:]) / len(h["m_g"][M:]); ort_i = sum(h["m_i"][M:]) / len(h["m_i"][M:])
    en_dusuk = min(h["m_g"][M:])
    t51_i, t51_g = iec_sure(ik / i51, k51, "NI"), iec_sure(max(ort, 1e-9) / i51, k51, "NI")
    # diferansiyel: dış arızada öbür ucun AT'si doğru ölçüyor sayılır → fark akımı = ideal − gerçek
    p87 = {c["key"]: c["vars"] for c in K87}
    j_max = max(range(M, len(t)), key=lambda j: h["fark"][j])
    idf = h["fark"][j_max]; ib = (h["m_i"][j_max] + h["m_g"][j_max]) / 2
    es = esik(ib, p87)
    o2 = h["h2"][j_max] / max(idf, 1e-9)
    dif_acar = idf > es and o2 < 0.15
    doydu = h["t_doy"] is not None
    sim_ok = ik <= h["alf_g"]
    kural = h["alf_g"] > 1.5 * i_ani

    c = tek_hat(("Kaynak", ""), ("Arıza", f"{fnum(ik, 1)} ×In(AT)"), ("Aşırı akım rölesi", "I>> " + ("açmıyor" if t_gercek is None else f"{fnum(t_gercek, 0)} ms'de başladı")), "normal" if t_gercek is None else "acti",
                640, "sag", gt=False, ileri=False, h=310, at_ad=f"AT {p.get('sinif') or '5P20'}", kesici_acik=t_gercek is not None)
    c.yazi(500, 150, f"Gerçek doğruluk sınır katsayısı {fnum(h['alf_g'], 1)} (etikette {h['alf']})", "#1a4d8f", 12, kalin=True)
    c.yazi(500, 172, ("Doyma " + f"{fnum(h['t_doy'], 1)} ms'de başlıyor" if doydu else "Çekirdek doymuyor"), "#b91c1c" if doydu else "#15803d", 12.5, kalin=True)
    c.yazi(500, 192, f"Röle ortalama {fnum(ort, 1)} ×In görüyor (gerçek {fnum(ik, 1)} ×In) — %{fnum(ort / ik * 100, 0)}", "#334155", 11.5)
    c.yazi(500, 212, f"Ani kademe gecikmesi: " + (f"{fnum(gecikme, 0)} ms" if gecikme is not None else "ölçü ayara ulaşmıyor" if t_ideal is not None else "arıza akımı ayarın altında"), "#334155", 11.5)
    c.yazi(500, 232, f"Ters zamanlı kademe: {fnum(t51_g, 2)} s (doymasaydı {fnum(t51_i, 2)} s)", "#334155", 11.5)
    c.yazi(500, 258, f"87 (dış arıza): fark {fnum(idf, 1)}, eşik {fnum(es, 1)} ×In → " + ("AÇAR (yanlış)" if dif_acar else "harmonik kilidi tutar" if idf > es else "kararlı"), "#b91c1c" if dif_acar else "#15803d", 12, kalin=True)

    ozet = [
        K("Gerçek doğruluk sınır katsayısı", fnum(h["alf_g"], 1), "ok" if sim_ok else "bad", f"etiket {h['alf']} · bağlı yük {fnum(h['r2'], 2)} Ω · simetrik {fnum(ik, 0)} ×In'de " + ("doymaz" if sim_ok else "doyar")),
        K("Doymaya girme anı", f"{fnum(h['t_doy'], 1)} ms" if doydu else "doymuyor", "warn" if doydu else "ok", "doğru akım bileşeni akıyı tek yöne iter" if doydu and xr > 0 else ""),
        K("Rölenin gördüğü", f"{fnum(ort, 1)} ×In", "ok" if ort / ik > 0.9 else "warn", f"gerçeğin %{fnum(ort / ik * 100, 0)}'i · en düşük periyotta {fnum(en_dusuk, 1)} ×In"),
        K("Ani kademe", f"+{fnum(gecikme, 0)} ms" if gecikme is not None else ("açmaz" if t_ideal is not None else "—"), "ok" if (gecikme is not None and gecikme <= 20) or t_ideal is None else "warn", "doyma yüzünden gecikme"),
        K("Diferansiyelde fark akımı", f"{fnum(idf, 2)} ×In", "bad" if dif_acar else "ok", f"dış arızada · eşik {fnum(es, 2)} ×In · 2. harmonik %{fnum(o2 * 100, 0)}"),
    ]
    kontroller = [
        C("Akım trafosu ani kademe için yeterli mi?", f"Isat = {fnum(h['alf_g'], 1)} ×In", f"> 1,5 × I>> = {fnum(1.5 * i_ani, 1)} ×In", kural,
          "Sabit zamanlı kademede doyma akımı ayarın 1,5 katından büyük olmalı — " + P3U + " Çizelge 40", "resmi"),
        C("Simetrik arıza akımında doyuyor mu?", f"arıza {fnum(ik, 1)} ×In; gerçek sınır katsayısı {fnum(h['alf_g'], 1)}", "arıza akımı ≤ gerçek sınır katsayısı × In", sim_ok,
          "Gerçek doğruluk sınır katsayısı bağlı yüke göre değişir: ALF × (Rct·Ins² + VA) / ((Rct + Rw)·Ins²) — " + P3U + " Denklem 2", "resmi"),
        C("Doğru akım bileşeniyle geçici doyma", f"gereken büyütme (1 + X/R) = {fnum(1 + xr, 0)} kat → {fnum(ik * (1 + xr), 0)} ×In'e eşdeğer", f"gerçek sınır katsayısı {fnum(h['alf_g'], 1)}", None,
          "Doğru akım bileşeni akıyı tek yönde biriktirir; hiç doymaması için çekirdek (1 + X/R) kat büyük olmalıdır. P sınıfı trafolar bunun için boyutlandırılmaz: ilk periyotlarda doyma olağandır", "hesap"),
        C("Diferansiyel dış arızada kararlı mı?", f"fark {fnum(idf, 2)} ×In; tutucu {fnum(ib, 1)} ×In; eşik {fnum(es, 2)} ×In; 2. harmonik %{fnum(o2 * 100, 0)}", "fark < eşik ya da 2. harmonik kilidi", not dif_acar,
          "Bir uçtaki akım trafosu doyarsa iki ucun akımı eşit ölçülmez; eğimli karakteristik ve 2. harmonik kilidi bu yüzden vardır — " + P3T + " böl. 6.30 (bu sayfada varsayılan 87T ayarlarıyla)", "resmi"),
    ]
    girdiler = [
        G("Akım trafosunun sınıfı, anma yükü, Rct", f"{p.get('sinif') or '5P20'} · {num(p, 'va', 15):g} VA · {fnum(num(p, 'rct', 0.3), 2)} Ω", "AT etiketi ve fabrika test raporu", "Çekirdeğin ne kadar gerilim üretebildiğini belirler", f"diz gerilimi ≈ ALF·Ins·(Rct + VA/Ins²) = {fnum(h['vk'], 0)} V"),
        G("Sekonder devrenin gerçek yükü", f"kablo {fnum(h['rw'], 2)} Ω + röle 0,004 Ω", "Kablo boyu ve kesiti; röle kılavuzu", "Yük anma yükünden küçükse trafo etiketindekinden büyük akıma kadar doğru ölçer; büyükse erken doyar", "gerçek doğruluk sınır katsayısı"),
        G("En büyük arıza akımı ve X/R", f"{fnum(ik, 1)} ×In · X/R {fnum(xr, 0)}", "Kısa devre hesabı", "Simetrik bileşen çekirdeği her periyotta, doğru akım bileşeni birikerek doyurur", "geçici büyütme 1 + X/R"),
        G("Kademe ayarları", f"I>> {fnum(i_ani, 1)} ×In", "Ayar föyü", "Koşul ayara göre konur: doyma akımı ayarın 1,5 katından büyük olmalı", "Çizelge 40"),
    ]
    adimlar = [
        A("Kablo direnci", "Rw = 2·ℓ / (56·A)", f"2 × {fnum(num(p, 'l_m', 30), 0)} / (56 × {num(p, 'kesit', 2.5):g})", f"{fnum(h['rw'], 2)} Ω", "bakır, 20 °C; gidiş ve dönüş", "hesap", ["Sekonder devrenin gerçek yükü"]),
        A("Gerçek doğruluk sınır katsayısı", "ALF × (Rct·Ins² + VA) / ((Rct + Rw)·Ins²)", f"{h['alf']} × ({fnum(num(p, 'rct', 0.3), 2)}×{ins:g}² + {num(p, 'va', 15):g}) / ({fnum(h['r2'], 3)}×{ins:g}²)", fnum(h["alf_g"], 1), P3U + " Denklem 2", "resmi", ["Akım trafosunun sınıfı, anma yükü, Rct", "Sekonder devrenin gerçek yükü"]),
        A("Doyma akımı", "Isat = gerçek ALF × In", "—", f"{fnum(h['alf_g'], 1)} ×In", P3U + " böl. 5.1.2", "resmi", [], "I>> koşulu"),
        A("Geçici doyma", "akı = ∫ (sekonder gerilim) dt; doğru akım bileşeni birikir", f"X/R = {fnum(xr, 0)}", (f"{fnum(h['t_doy'], 1)} ms'de doyar" if doydu else "doymaz"), "zaman bölgesi benzetimi (iki parçalı mıknatıslanma eğrisi)", "tahmini", ["En büyük arıza akımı ve X/R"]),
        A("Rölenin ölçtüğü", "bir periyotluk Fourier süzgeci, kırpılmış dalgadan", "—", f"ortalama {fnum(ort, 1)} ×In (gerçek {fnum(ik, 1)})", "bkz. Röle nasıl ölçer sayfası", "hesap"),
    ]
    ayarlar = [
        S("I>> (ani kademe)", f"{fnum(i_ani, 1)} ×In", "—", "Akım trafosunun doyma akımı bu ayarın 1,5 katından büyük olmalı; değilse kademe büyük arızada gecikir ya da hiç başlamaz", P3U + " Çizelge 40"),
        S("Ayarlar bilinmiyorsa akım trafosu", "5P20 · 1 A: 2,5 VA · 5 A: 7,5 VA", "Rct < 3 Ω (1 A), < 0,2 Ω (5 A); kablo < 0,075 Ω", "Çoğu uygulama için yeterli sayılan değerler", P3U + " Çizelge 41"),
        S("87T › 2. harmonik kilidi · eğim 2", "%15 · %150", "—", "Doymuş akım trafosunun yarattığı sahte fark akımı 2. harmonik içerir ve büyük tutucu akımda ortaya çıkar", P3T + " böl. 6.30"),
    ]
    test = [
        T("Mıknatıslanma eğrisi", "Sekonderden gerilim uygula, akımı ölç", f"Diz gerilimi ≈ {fnum(h['vk'], 0)} V dolayında", "bkz. AT mıknatıslanma testi sayfası"),
        T("Sekonder devre direnci", "Röle uçlarından AT'ye kadar çevrim direnci", f"≈ {fnum(h['r2'], 2)} Ω", "hesapla karşılaştır"),
        T("Arıza kaydı", "Büyük akımlı gerçek arızanın dalga kaydı", "Kırpılmış, sivri yarım dalgalar doymayı gösterir", "ilk periyotlarda, doğru akım bileşeni yönünde"),
    ]
    g1 = {"baslik": "Sekonder akım: olması gereken ve doymuş çekirdeğin verdiği", "x_ad": "Zaman (ms)", "y_ad": "Akım (×In, anlık)", "zaman": True,
          "seriler": [{"ad": "olması gereken", "renk": "#94a3b8", "kesik": True, "pts": D.seri(t, h["ideal"], 2)}, {"ad": "röleye giden", "renk": "#dc2626", "pts": D.seri(t, h["gercek"], 2)}],
          "isaretler": [{"x": round(h["t_doy"], 1), "etiket": "doyma"}] if doydu else []}
    g2 = {"baslik": "Rölenin ölçtüğü temel bileşen", "x_ad": "Zaman (ms)", "y_ad": "Akım (×In, etkin)", "ymin": 0,
          "seriler": [{"ad": "doymasaydı", "renk": "#94a3b8", "kesik": True, "pts": D.seri(t, h["m_i"], 4)}, {"ad": "doymuş akım trafosuyla", "renk": "#1a4d8f", "pts": D.seri(t, h["m_g"], 4)},
                      {"ad": "fark akımı (87)", "renk": "#b45309", "pts": D.seri(t, h["fark"], 4)}],
          "yatay": [{"y": i_ani, "etiket": f"I>> = {fnum(i_ani, 1)} ×In", "renk": "#15803d"}]}
    g3 = {"baslik": "Çekirdekteki akı (doyma akısının katı)", "x_ad": "Zaman (ms)", "y_ad": "Akı (pu)", "zaman": True,
          "seriler": [{"ad": "akı", "renk": "#1a4d8f", "pts": D.seri(t, h["aki"], 2)}], "yatay": [{"y": 1, "etiket": "doyma", "renk": "#dc2626"}, {"y": -1, "etiket": "doyma", "renk": "#dc2626"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["50-51", "87t"], "sahne": c.sahne(), "grafikler": [g1, g2, g3],
        "cubuklar": [{"baslik": "Periyot periyot: rölenin gördüğü akım, gerçeğin yüzdesi", "kategoriler": [f"{j + 1}." for j in range(1, 6)], "alt": ["periyot"] * 5, "y_ad": "%",
                      "seriler": [{"ad": "ölçülen / gerçek", "renk": "#1a4d8f", "deger": [round(h["m_g"][(j + 1) * M - 1] / max(h["m_i"][(j + 1) * M - 1], 1e-9) * 100, 1) for j in range(1, 6)]}]}],
        "anlatim": [
            "Akım trafosu sekonder akımı akıtabilmek için gerilim üretir: gerilim = akım × (sargı direnci + kablo + röle). Bu gerilimi çekirdekteki akının değişimi sağlar.",
            "Akım büyüdükçe gereken gerilim ve akı salınımı büyür. Akı çekirdeğin taşıyabileceği değere ulaşınca çekirdek doyar: primer akımın fazlası mıknatıslanma akımı olarak harcanır, sekondere geçmez. Dalga her yarım periyodun sonunda kırpılır.",
            f"Doğru akım bileşeni daha sinsidir: akıyı her periyotta aynı yöne iter. Simetrik akımda doymayan çekirdek bile {fnum(1 + xr, 0)} kat büyük olmadıkça ilk periyotlarda doyar; bileşen sönünce kendine gelir.",
            f"Röle kırpılmış dalganın temel bileşenini ölçer: {fnum(ik, 1)} ×In yerine {fnum(ort, 1)} ×In. Ani kademe ayarı bunun üstündeyse kademe gecikir; ters zamanlı kademe daha küçük akım gördüğü için daha geç açar.",
            "Diferansiyel korumada iki ucun akım trafosu aynı akımı farklı ölçerse fark akımı oluşur. Dış arızada bir uç doyarsa röle bunu iç arıza sanabilir; eğimli karakteristik ve 2. harmonik kilidi bu durumu tutar.",
            "Kablo uzadıkça ya da kesit küçüldükçe yük artar, gerçek doğruluk sınır katsayısı düşer. 1 A sekonderli trafoda aynı kablo 25 kat daha az yük demektir.",
        ],
        "dersler": [
            "Etiketteki 5P20 yalnız anma yükünde geçerlidir; gerçek sınır katsayısı bağlı yükle değişir ve hesaplanır.",
            "Doyma arıza akımını küçültmez, rölenin gördüğünü küçültür: büyük arızada koruma en çok burada yanılır.",
            "Kalıcı akı doymayı öne çeker: doğru akımla yapılan polarite testinden sonra çekirdek mıknatıslığı giderilir.",
            "Arıza kaydında sivri, kırpılmış yarım dalgalar doymanın imzasıdır.",
        ],
        "tablolar": [{"baslik": "Kablo ve sekonder akıma göre gerçek doğruluk sınır katsayısı (bu akım trafosu)", "cols": ["Kablo (tek yön)", "Kesit", "Yük (Ω)", "Gerçek sınır katsayısı", f"{fnum(ik, 0)} ×In'de"],
                      "rows": [[f"{l} m", f"{fnum(a, 1)} mm²", fnum(hh["r2"], 2), fnum(hh["alf_g"], 1), "doymaz" if ik <= hh["alf_g"] else "doyar"]
                               for l, a in ((10, 2.5), (30, 2.5), (60, 2.5), (60, 4), (100, 4), (100, 6)) for hh in [{"r2": num(p, "rct", 0.3) + 2 * l / (56 * a) + 0.004}]
                               for hh in [{**hh, "alf_g": h["alf"] * (num(p, "rct", 0.3) * ins * ins + num(p, "va", 15)) / (hh["r2"] * ins * ins)}]],
                      "not": "Simetrik akım için. Doğru akım bileşeniyle geçici doyma bu değerlerin çok altında başlar."}],
    }
