"""Frekans değişim hızı koruması (ANSI 81R, ROCOF, df/dt) — Easergy P3 «df/dt» kademesi.

Dayanak: P3U/en M/J006 böl. 5.38 (|df/dt| ayarı 80 ms boyunca aşarsa kademe başlar, 60 ms daha sonra başlatma işareti verir; gecikme dolduğunda başlangıçtan
beri ortalama eğim hâlâ ayarın üstündeyse açar; t = tMin ise sabit zamanlı, tMin < t ise ters zamanlı; 0,7 Hz/s'nin altındaki ayarlarda en kısa süre
sınırlıdır; üreticinin notu: «ROCOF'u yalnız yük atma için kullanın; şebeke kaybı tespiti için kullanmayın»), Çizelge 93 (ayar 0,2–10,0 Hz/s; süre 0,14–10 s;
doğruluk %10 ya da ±0,1 Hz/s); Lisanssız Üretim Tebliği Ek-2 Tablo-2 (ROCOF 0,5–2,5 Hz/s, 0,2 s; dağıtım şirketi etüdüne göre vektör kayması ya da
ROCOF'tan biri istenebilir). Ada işletmesinde df/dt = ΔP · fn / (2·H) (salınım denklemi)."""
from __future__ import annotations

from .ortak import A, C, G, K, LUY, P3U, S, T, ctl, fnum, num, opt, tek_hat

ID = "rocof"
BASLIK = "Frekans değişim hızı (81R)"
IKON = "📉"
GIRIS = ("Santral adada kaldığında frekans bir anda değil, bir eğimle kayar. Frekans rölesi eşiğe varılmasını bekler; ROCOF rölesi eğimin kendisine bakar "
         "ve daha erken davranır. Bedeli: üretim yüke yakınsa eğim küçüktür ve röle adayı göremez — kör bölge.")

OLAY = {"ada": "Ada: şebeke bağlantısı koptu", "sistem": "Şebeke genelinde frekans düşüşü (büyük santral kaybı)", "sicrama": "Şebekede anahtarlama: kısa süreli frekans oynaması"}

KONTROLLER = [
    ctl("olay", "Olay", "sec", "ada", secenek=opt(*OLAY.items())),
    ctl("dp", "Adada üretim ile yük arasındaki fark", "sayi", 20, min=0, max=100, adim=1, birim="% Sn", goster={"olay": ["ada"]}),
    ctl("h", "Santralin atalet sabiti H", "sayi", 1.5, min=0.3, max=8, adim=0.1, birim="s"),
    ctl("sis", "Şebeke genelindeki eğim", "sayi", 0.3, min=0.05, max=2.0, adim=0.05, birim="Hz/s", goster={"olay": ["sistem"]}),
    ctl("ayar", "Röle › df/dt başlatma", "sayi", 1.0, min=0.2, max=10.0, adim=0.1, birim="Hz/s"),
    ctl("t", "Röle › Çalışma süresi t", "sayi", 0.14, min=0.14, max=10, adim=0.02, birim="s"),
    ctl("tmin", "Röle › Min gecikme tMin", "sayi", 0.14, min=0.14, max=10, adim=0.02, birim="s"),
    ctl("t_kesici", "Kesicinin açma süresi", "sayi", 60, min=20, max=120, adim=5, birim="ms"),
]


def run(p: dict) -> dict:
    import math
    o = p.get("olay") if p.get("olay") in OLAY else "ada"
    h, ayar, t, tk = num(p, "h", 1.5), num(p, "ayar", 1.0), num(p, "t", 0.14), num(p, "t_kesici", 60) / 1000
    egim_ada = num(p, "dp", 20) / 100 * 50 / (2 * h)
    T0, dt = 0.3, 0.01
    ts = [j * dt for j in range(401)]
    def egim(tt):
        if tt < T0:
            return 0.0
        if o == "ada":
            return -egim_ada
        if o == "sistem":
            return -num(p, "sis", 0.3) * math.exp(-(tt - T0) / 3.0)
        return -3.0 if tt - T0 < 0.05 else (3.0 if tt - T0 < 0.10 else 0.0)                # 50 ms'lik sıçrama ve geri dönüş
    es = [egim(x) for x in ts]
    fs = [50.0]
    for j in range(1, len(ts)):
        fs.append(fs[-1] + es[j] * dt)
    # röle: |df/dt| > ayar 80 ms sürerse başlar; 60 ms sonra başlatma işareti; t sonunda ortalama eğim hâlâ üstündeyse açar
    ustsure, basla, acma = 0.0, None, None
    for j, x in enumerate(ts):
        ustsure = ustsure + dt if abs(es[j]) > ayar else 0.0
        if basla is None and ustsure >= 0.08 - 1e-9:
            basla = x + 0.06
            f0, t0 = fs[j], x
        if basla is not None and acma is None and x >= t0 + max(t, 0.14) - 1e-9:
            ort = abs((fs[j] - f0) / max(x - t0, 1e-9))
            if ort > ayar:
                acma = x
            else:
                basla = None; ustsure = 0.0
    beklenen = o == "ada"
    kor = 2 * h * ayar / 50 * 100                                                     # kör bölge: bu farkın altında eğim ayara ulaşmaz (% Sn)
    c = tek_hat(("Santral", f"H = {fnum(h, 1)} s"), ("Dağıtım şebekesi", OLAY[o].split(":")[0]), ("81R  df/dt", "AÇTI" if acma is not None else "açmadı"),
                "acti" if acma is not None else ("gecersiz" if beklenen else "normal"), None, "sag", ileri=False, kesici_acik=acma is not None)
    c.yazi(500, 190, (f"Adada eğim = ΔP · fn / (2H) = {fnum(egim_ada, 2)} Hz/s" if o == "ada" else OLAY[o].split(" (")[0]) + f" · ayar {fnum(ayar, 1)} Hz/s", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, f"Kör bölge: üretim–yük farkı %{fnum(kor, 0)} Sn'in altındaysa eğim ayara ulaşmaz", "#334155", 11)
    c.yazi(500, 226, (f"Olaydan {fnum(acma - T0 + tk, 2)} s sonra ayrıldı (röle + kesici)") if acma is not None else "Kademe açmadı", "#334155", 11)
    ozet = [
        K("Sonuç", "AÇTI" if acma is not None else "açmadı", "ok" if (acma is not None) == beklenen else "bad", ("ada tespit edildi" if acma is not None else "ada görülmedi (kör bölge)") if beklenen else ("gereksiz açma" if acma is not None else "doğru: şebeke olayında bağlı kaldı")),
        K("Eğim", f"{fnum(egim_ada if o == 'ada' else (num(p, 'sis', 0.3) if o == 'sistem' else 3.0), 2)} Hz/s", "info", f"ayar {fnum(ayar, 1)} Hz/s"),
        K("Kör bölge", f"± %{fnum(kor, 0)} Sn", "ok" if kor <= 10 else "warn", "2·H·ayar / fn"),
        K("Tespit süresi", f"{fnum(acma - T0 + tk, 2)} s" if acma is not None else "—", "info", "olay başından kesicinin açmasına"),
        K("Aynı adada frekans rölesi", f"{fnum((50 - 47) / max(egim_ada, 1e-9) + 0.1 + tk, 2)} s" if o == "ada" and egim_ada > 0 else "—", "info", "47 Hz'e inip açması"),
    ]
    kontroller = [
        C("Bu olayda davranış doğru mu?", "açtı" if acma is not None else "açmadı", "adada ayrılır; şebeke genelindeki olayda ve anahtarlamada bağlı kalır", (acma is not None) == beklenen, P3U + " böl. 5.38", "resmi"),
        C("Ayar Tebliğ aralığında mı?", f"{fnum(ayar, 1)} Hz/s · röle {fnum(max(t, 0.14), 2)} s + kesici = {fnum(max(t, 0.14) + tk, 2)} s", "0,5 … 2,5 Hz/s; temizleme 0,2 s", 0.5 <= ayar <= 2.5 and max(t, 0.14) + tk <= 0.2 + 1e-9,
          LUY + " (dipnot c: dağıtım şirketinin etüdüne göre vektör kayması ya da ROCOF'tan biri istenebilir)", "resmi"),
        C("Şebeke genelindeki olaylarda açmıyor mu?", f"ayar {fnum(ayar, 1)} Hz/s", "şebekede görülebilecek en büyük eğimin üstü (dağıtım / iletim şirketinden)", ayar >= 0.5,
          "Büyük bir santralin devre dışı kalması bütün sistemde eğim oluşturur; ROCOF bunu adadan ayıramaz. Alt sınır 0,5 Hz/s: " + LUY, "resmi"),
        C("Kör bölge kabul edilebilir mi?", f"± %{fnum(kor, 0)} Sn", "üretim ile yerel yük arasındaki olağan farkın altında olmalı", kor <= num(p, "dp", 20) if o == "ada" else None,
          "df/dt = ΔP · fn / (2H): fark küçükse eğim ayara ulaşmaz (hesap). Bu bölgede adayı frekans / gerilim korumaları ya da uzaktan açtırma yakalar", "resmi"),
        C("Üreticinin kullanım notu", "ROCOF yalnız yük atma için; şebeke kaybı tespiti için kullanılmamalı", "şebeke kaybı için vektör kayması (78V) kademesi", None,
          P3U + " böl. 5.38 notu ve böl. 5.35 (vektör kayması, şebeke kaybı koruması). Tebliğ iki korumadan birini ister: hangisinin kullanılacağı dağıtım şirketiyle kararlaştırılır", "resmi"),
    ]
    girdiler = [
        G("Dağıtım şirketinin ada koruması isteği", "ROCOF 0,5–2,5 Hz/s ya da vektör kayması 6–9°; 0,2 s", "Bağlantı görüşü", "Tebliğ ikisinden birini ister; değer dağıtım şirketinindir", "df/dt ayarı ve süre"),
        G("Santralin atalet sabiti H", f"{fnum(h, 1)} s", "Jeneratör + tahrik makinesi verisi", "Aynı güç farkında eğim ataletle ters orantılıdır", "df/dt = ΔP · fn / (2H)"),
        G("Adada beklenen üretim–yük farkı", f"%{fnum(num(p, 'dp', 20), 0)} Sn", "İhracat / ithalat düzeyi; yerel yük", "Fark küçükse röle adayı göremez", "kör bölge = 2·H·ayar / fn"),
        G("Şebekede görülen en büyük eğim", "≈ 0,1–0,5 Hz/s (sistem olayları)", "İletim / dağıtım şirketi", "Ayar bunun üstünde olmalı; yoksa sistem olayında santral de düşer ve olayı büyütür", "alt sınır"),
        G("Kesicinin açma süresi", f"{fnum(tk * 1000, 0)} ms", "Kesici etiketi", "0,2 s'ye kesici dâhil", "röle süresi ≤ 0,2 − kesici"),
    ]
    adimlar = [
        A("Adadaki eğim", "df/dt = ΔP · fn / (2 · H)", f"{fnum(num(p, 'dp', 20) / 100, 2)} × 50 / (2 × {fnum(h, 1)})", f"{fnum(egim_ada, 2)} Hz/s", "salınım denklemi", "resmi", ["Santralin atalet sabiti H", "Adada beklenen üretim–yük farkı"]),
        A("Kör bölge", "ΔP min = 2 · H · ayar / fn", f"2 × {fnum(h, 1)} × {fnum(ayar, 1)} / 50", f"%{fnum(kor, 0)} Sn", "aynı bağıntı", "resmi", [], "df/dt Başlatma"),
        A("Röle süresi", "≤ 0,2 s − kesici; rölenin en kısa süresi 0,14 s", f"0,2 − {fnum(tk, 2)} = {fnum(0.2 - tk, 2)} s", "0,14 s (en kısa)", P3U + " Çizelge 93; " + LUY, "resmi", ["Kesicinin açma süresi"], "Çalışma süresi · Min gecikme"),
    ]
    ayarlar = [
        S("df/dt › Başlatma", f"{fnum(ayar, 1)} Hz/s", "0,2 … 10,0 Hz/s; ekrandaki örnek 5,0 Hz/s", "Tebliğ: 0,5–2,5 Hz/s. 5 Hz/s ile kör bölge çok geniştir", P3U + " Çizelge 93; " + LUY),
        S("df/dt › Çalışma süresi", f"{fnum(t, 2)} s", "0,14 … 10,00 s; ekrandaki örnek 0,50 s", "Eğimin ortalaması bu süre boyunca ayarın üstünde kalmalı", P3U + " Çizelge 93"),
        S("df/dt › Min gecikme", f"{fnum(num(p, 'tmin', 0.14), 2)} s", "0,14 … 10,00 s; ekrandaki örnek 0,50 s", "t ile eşitse sabit zamanlı; küçükse eğim büyüdükçe süre kısalır (ters zamanlı)", P3U + " böl. 5.38"),
        S("Vektör kayması (78V) kademesi", "seçenek: 6–9°", "—", "Üretici şebeke kaybı için bunu önerir; Tebliğ de alternatif olarak sayar", P3U + " böl. 5.35; " + LUY),
    ]
    test = [
        T("Başlatma", f"Frekansı 50 Hz'ten doğrusal rampayla düşürün; eğimi {fnum(ayar, 1)} Hz/s'ye doğru artırın", f"Başlatma {fnum(ayar, 1)} Hz/s'de", "%10 ya da ±0,1 Hz/s"),
        T("Süre", f"{fnum(1.5 * ayar, 1)} Hz/s rampa", f"Açma ≈ {fnum(max(t, 0.14), 2)} s (başlatma süresi ≈ 140 ms dâhil)", "±35 ms (0,2–1,0 Hz/s aralığında)"),
        T("Kısa oynama", "50 ms süren 3 Hz/s'lik oynama, sonra geri dönüş", "Açmaz (ortalama eğim ayarın altına iner)", "—"),
        T("Yön", "Rampayı yukarı doğru verin", "Açar (kademe eğimin mutlak değerine bakar)", P3U + " böl. 5.38"),
    ]
    g = {"baslik": "Frekans ve eğim", "x_ad": "Zaman (s)", "y_ad": "Frekans (Hz)", "zaman": True, "ymin": 46, "ymax": 50.5,
         "seriler": [{"ad": "frekans", "renk": "#dc2626", "pts": [[round(x, 2), round(max(46, f), 3)] for x, f in zip(ts, fs)]}],
         "yatay": [{"y": 47.0, "etiket": "düşük frekans rölesi 47 Hz", "renk": "#1a4d8f"}], "isaretler": ([{"x": acma, "etiket": "81R açma"}, {"x": acma + tk, "etiket": "kesici açtı"}] if acma is not None else [])}
    hs = [0.3 + j * 0.1 for j in range(78)]
    g2 = {"baslik": "Kör bölge: ROCOF'un adayı görebilmesi için gereken en küçük üretim–yük farkı", "x_ad": "Atalet sabiti H (s)", "y_ad": "Fark (% Sn)", "ymin": 0, "ymax": 100,
          "seriler": [{"ad": f"ayar {fnum(a_, 1)} Hz/s", "renk": r_, "kesik": a_ != ayar, "pts": [[x, min(100, 2 * x * a_ / 50 * 100)] for x in hs]} for a_, r_ in ((0.5, "#15803d"), (ayar, "#dc2626"), (2.5, "#7c3aed"))],
          "isaretler": [{"x": h, "etiket": "bu santral"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["81r"],
        "sahne": c.sahne(), "grafikler": [g, g2],
        "anlatim": [
            "Santral adada kaldığında üretim ile yük arasındaki fark dönen kütleleri hızlandırır ya da yavaşlatır. Frekansın değişim hızı farkla doğru, ataletle ters orantılıdır.",
            f"Bu santralde %{fnum(num(p, 'dp', 20), 0)} fark {fnum(egim_ada, 2)} Hz/s eğim verir. Frekans rölesi 47 Hz'e inilmesini beklerdi; ROCOF eğimi birkaç periyotta görür.",
            "Röle eğimi 80 ms izler, sonra başlar; gecikme sonunda başlangıçtan beri ortalama eğim hâlâ ayarın üstündeyse açar. Kısa oynamalar ortalamayı düşürdüğü için açtırmaz.",
            f"Zayıf yanı kör bölgedir: fark %{fnum(kor, 0)}'in altındaysa eğim ayara ulaşmaz ve ada görülmez. Ayarı küçültmek kör bölgeyi daraltır ama şebeke genelindeki olaylarda yanlış açma riskini büyütür.",
            "Büyük bir santral devre dışı kaldığında bütün sistemin frekansı bir eğimle düşer. ROCOF bunu adadan ayıramaz; ayarın alt sınırını bu belirler.",
            "Üretici ROCOF'u yük atma için önerir, şebeke kaybı için vektör kaymasını (78V). Tebliğ ikisinden birini ister; seçimi dağıtım şirketi yapar.",
        ],
        "dersler": [
            "df/dt = ΔP · fn / (2H). H küçük (gaz motoru, evirici) → aynı farkta büyük eğim.",
            "Kör bölge = 2·H·ayar / fn. Ekrandaki 5 Hz/s ile H = 1,5 s'lik santralde fark %30'un altındaysa ada görülmez.",
            "ROCOF tek başına ada koruması değildir; 27/59/81 ile birlikte çalışır.",
            "Rölenin en kısa süresi 0,14 s'dir; 60 ms'lik kesiciyle 0,2 s'ye ancak sığar.",
        ],
        "tablolar": [{"baslik": "Farka göre adanın tespiti (bu santral ve ayarla)", "cols": ["Üretim–yük farkı", "Eğim", "ROCOF", "Frekans rölesi (47 Hz)"], "rows": [
            [f"%{d}", f"{fnum(d / 100 * 50 / (2 * h), 2)} Hz/s", "görür" if d / 100 * 50 / (2 * h) > ayar else "GÖRMEZ", f"{fnum(3 / (d / 100 * 50 / (2 * h)), 1)} s sonra" if d > 0 else "görmez"] for d in (2, 5, 10, 20, 40, 80)]}],
    }
