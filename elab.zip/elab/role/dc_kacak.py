"""DC yardımcı besleme ve toprak kaçağı: topraktan yalıtılmış kumanda geriliminde ilk toprak arızası neden bir şey yapmaz, ikincisi neden kesiciyi
kendiliğinden açtırır; uzun kablonun kapasitesi ikili girişi nasıl yanıltır.

Model: doğrusal direnç devresi (düğüm gerilimleri). Akü topraktan yalıtılmıştır; yalıtım izleme düzeni her kutbu eşit bir dirençle toprağa bağlar
(orta nokta). Açma kontağı açıkken bobinin üst ucu (kontak ile bobin arası) yalnız bobin üzerinden eksi kutba bağlıdır. Toprak arızaları seçilen
düğümü bir dirençle toprağa bağlar. İkili girişte kapasitif darbe: eksi kutbun toprağa kapasitesi U/2'ye yüklüdür; kontak–giriş arası iletken toprağa
değdiğinde bu yük giriş direnci üzerinden boşalır: u(t) = (U/2)·e^(−t/(Rg·C)). Değerler (izleme direnci, bobin direnci, çekme eşiği, giriş direnci)
tipiktir (tahmini). Açma devresi denetimi: P3U/en M/J006 böl. 6.18 (denetim devrenin sürekliliğini izler; toprak kaçağını ayrı bir düzen izler)."""
from __future__ import annotations

import math

from .ortak import A, C, Cizim, G, K, P3U, S, T, ctl, fnum, num, opt

ID = "dc_kacak"
BASLIK = "DC kumanda devresinde toprak kaçağı"
IKON = "🔋"
GIRIS = ("Koruma ve kumanda devreleri aküden beslenir ve akü bilerek topraklanmaz: tek bir toprak arızası devreyi durdurmasın diye. Ama o ilk arıza giderilmezse "
         "ikinci arıza açma kontağını köprüler ve kesici kendiliğinden açar. Arızaların yerini ve direncini değiştirin; bobinin gördüğü gerilimi izleyin.")
YER = {"yok": "Yok", "p": "Artı kutupta", "n": "Eksi kutupta", "x": "Açma kontağı ile bobin / giriş arasındaki iletkende"}
YUK = {"bobin": "Açma bobini", "giris": "Rölenin ikili girişi"}

KONTROLLER = [
    ctl("u", "Kumanda gerilimi", "sec", 110, secenek=opt((24, "24 V"), (48, "48 V"), (110, "110 V"), (220, "220 V"))),
    ctl("yuk", "Kontağın sürdüğü eleman", "sec", "bobin", secenek=opt(*YUK.items())),
    ctl("rc", "Bobin direnci", "sayi", 200, min=10, max=2000, adim=10, birim="Ω", goster={"yuk": ["bobin"]}),
    ctl("rg", "İkili giriş direnci", "sayi", 40, min=5, max=300, adim=5, birim="kΩ", goster={"yuk": ["giris"]}),
    ctl("esik", "Çekme / algılama eşiği", "sayi", 60, min=20, max=90, adim=1, birim="% Un", yardim="Bobin anma geriliminin %70'inde çalışmak zorundadır; çoğu daha düşükte de çeker. İkili girişlerde eşik seçilebilir"),
    ctl("rm", "Yalıtım izleme direnci (her kutup – toprak)", "sayi", 50, min=5, max=500, adim=5, birim="kΩ"),
    ctl("f1", "1. toprak arızası", "sec", "p", secenek=opt(*YER.items())),
    ctl("r1", "1. arızanın direnci", "sayi", 0, min=0, max=200, adim=1, birim="kΩ"),
    ctl("f2", "2. toprak arızası", "sec", "yok", secenek=opt(*YER.items())),
    ctl("r2", "2. arızanın direnci", "sayi", 0, min=0, max=200, adim=1, birim="kΩ"),
    ctl("c", "Kumanda kablolarının toprağa kapasitesi (kutup başına)", "sayi", 2.0, min=0.05, max=30, adim=0.05, birim="µF", goster={"yuk": ["giris"]}, yardim="Geniş şalt sahasında kilometrelerce kumanda kablosu: birkaç µF"),
    ctl("t_f", "İkili girişin süzme süresi", "sayi", 5, min=0, max=50, adim=1, birim="ms", goster={"yuk": ["giris"]}),
]


def coz(p: dict) -> dict:
    """Düğüm gerilimleri: toprak (ve) ve kontak–yük arası düğüm (vx), eksi kutba göre (V)."""
    u = num(p, "u", 110); rm = num(p, "rm", 50) * 1000
    ry = num(p, "rc", 200) if p.get("yuk") != "giris" else num(p, "rg", 40) * 1000
    ar = [(p.get(k), max(num(p, r, 0) * 1000, 0.5)) for k, r in (("f1", "r1"), ("f2", "r2")) if p.get(k) in ("p", "n", "x")]
    gp = 1 / rm + sum(1 / r for y, r in ar if y == "p")                   # toprak – artı kutup iletkenliği
    gn = 1 / rm + sum(1 / r for y, r in ar if y == "n")
    gx = sum(1 / r for y, r in ar if y == "x")                             # toprak – x düğümü
    gy = 1 / ry
    # ve·(gp + gn + gx) − vx·gx = u·gp ;  −ve·gx + vx·(gx + gy) = 0
    if gx > 0:
        vx_oran = gx / (gx + gy)
        ve = u * gp / (gp + gn + gx - gx * vx_oran)
        vx = ve * vx_oran
    else:
        ve = u * gp / (gp + gn); vx = 0.0
    return {"u": u, "ve": ve, "vx": vx, "ry": ry, "n_ariza": len(ar), "x_var": gx > 0}


def run(p: dict) -> dict:
    s = coz(p); u, ve, vx = s["u"], s["ve"], s["vx"]
    giris = p.get("yuk") == "giris"
    esik = num(p, "esik", 60) / 100 * u
    yanlis = vx >= esik
    dengesiz = abs((u - ve) - ve) / u                                       # iki kutbun toprağa geriliminin farkı
    kisa = {p.get("f1"), p.get("f2")} >= {"p", "n"}                      # iki kutup birden toprakta: akü toprak üzerinden kısa devre
    alarm = dengesiz > 0.2 or kisa
    # kapasitif darbe (ikili giriş): tek arıza x düğümünde
    cap = num(p, "c", 2.0) * 1e-6; rg = num(p, "rg", 40) * 1000; t_f = num(p, "t_f", 5) / 1000
    darbe_var = giris and s["x_var"]
    v0 = ve_once(p)                                                          # arızadan hemen önce toprağın eksi kutba göre gerilimi (kapasite bu gerilime yüklü)
    tau = rg * cap
    t_ust = tau * math.log(v0 / esik) if (darbe_var and v0 > esik) else 0.0
    darbe_yanlis = darbe_var and t_ust > t_f

    c = Cizim(900, 320)
    yp, yn = 56, 262
    c.kutu(24, 130, 86, 58, "Akü", f"{u:g} V DC")
    c.hat(f"M67,130 V{yp} H820", "L1", w=2.6); c.hat(f"M67,188 V{yn} H820", "N", w=2.6)
    c.yazi(120, yp - 8, "+", "#8a4b12", 14, kalin=True); c.yazi(120, yn + 18, "−", "#1d4ed8", 14, kalin=True)
    # yalıtım izleme
    c.hat(f"M230,{yp} V84", "cizgi", w=1.6); c.direnc(230, 84, "Rm", False, False, 44); c.hat("M230,128 V190", "cizgi", w=1.6); c.direnc(230, 190, "Rm", False, False, 44); c.hat(f"M230,234 V{yn}", "cizgi", w=1.6)
    c.hat("M230,159 H300", "cizgi", w=1.6); c.toprak(300, 159, "ariza" if alarm else "toprak")
    c.kutu(316, 138, 130, 42, "Yalıtım izleme", "ALARM" if alarm else "olağan", "gecersiz" if alarm else "normal")
    c.yazi(244, 78, f"+ → toprak {fnum(u - ve, 0)} V", "#475569", 10); c.yazi(244, 252, f"− → toprak {fnum(ve, 0)} V", "#475569", 10)
    # açma kolu
    xk = 640
    c.hat(f"M{xk},{yp} V92", "L1", w=2.2); c.dikdortgen(xk - 16, 92, 32, 22, "cizgi", "#fff"); c.yazi(xk + 24, 107, "açma kontağı (açık)", "#475569", 10)
    c.hat(f"M{xk},114 V170", "L1", hot=yanlis, w=2.2)
    c.direnc(xk, 170, "bobin" if not giris else "ikili giriş", yanlis, False, 46); c.hat(f"M{xk},216 V{yn}", "N", hot=yanlis, w=2.2)
    c.yazi(xk + 24, 150, f"{fnum(vx, 0)} V = %{fnum(vx / u * 100, 0)} Un", "#b91c1c" if yanlis else "#334155", 12, kalin=True)
    # arızalar
    konum = {"p": (480, yp), "n": (480, yn), "x": (xk, 140)}
    for j, key in enumerate(("f1", "f2")):
        y_ = p.get(key)
        if y_ in konum:
            x, y = konum[y_]
            dx = 60 + 34 * j
            c.simsek(x - 8, y - 12, 1.0)
            c.hat(f"M{x},{y} H{x + dx}" if y_ == "x" else f"M{x + 20 * j},{y} V{y + (50 if y_ == 'p' else -50)}", "ariza", hot=True, w=1.8)
            (c.toprak(x + dx, y - 5, "ariza") if y_ == "x" else c.toprak(x + 20 * j, y + (52 if y_ == "p" else -62), "ariza"))
            c.yazi((x + dx + 16) if y_ == "x" else (x + 20 * j + 16), (y + 4) if y_ == "x" else (y + (62 if y_ == "p" else -50)), f"{j + 1}. arıza", "#b91c1c", 10.5, kalin=True)
    c.yazi(24, 306, ("YANLIŞ ÇALIŞMA: " + ("bobin" if not giris else "giriş") + " eşiğin üstünde gerilim görüyor" if yanlis else "Kapasitif darbe girişi yanıltıyor" if darbe_yanlis else "Yanlış çalışma yok") + f" (eşik {fnum(esik, 0)} V)",
           "#b91c1c" if (yanlis or darbe_yanlis) else "#15803d", 12.5, kalin=True)

    ozet = [
        K("Bobin / giriş gerilimi", f"{fnum(vx, 0)} V", "bad" if yanlis else "ok", f"%{fnum(vx / u * 100, 0)} Un · eşik %{fnum(num(p, 'esik', 60), 0)}"),
        K("Sonuç", "AKÜ KISA DEVRE" if kisa else "YANLIŞ ÇALIŞMA" if (yanlis or darbe_yanlis) else "yok", "bad" if (yanlis or darbe_yanlis or kisa) else "ok", "kontak açıkken eleman enerjilendi" if yanlis else "kapasitif darbe" if darbe_yanlis else "kontak açık, eleman enerjisiz"),
        K("Yalıtım izleme", "ALARM" if alarm else "olağan", "ok" if alarm or s["n_ariza"] == 0 else "warn", f"+ {fnum(u - ve, 0)} V · − {fnum(ve, 0)} V (toprağa göre)"),
        K("Toprak arızası sayısı", str(s["n_ariza"]), "ok" if s["n_ariza"] == 0 else "warn" if s["n_ariza"] == 1 else "bad", "tek arıza akım akıtmaz; ikincisi devreyi tamamlar"),
        K("Kapasitif darbe", f"{fnum(t_ust * 1000, 1)} ms" if darbe_var else "—", "bad" if darbe_yanlis else "ok", f"eşiğin üstünde kalma süresi · süzme {fnum(t_f * 1000, 0)} ms" if darbe_var else "yalnız ikili girişte ve kontak sonrası arızada"),
    ]
    kontroller = [
        C("Kontak açıkken eleman enerjisiz mi?", f"{fnum(vx, 0)} V (%{fnum(vx / u * 100, 0)} Un)", f"< eşik {fnum(esik, 0)} V", not yanlis,
          "İki toprak arızası toprağı iletken olarak kullanıp açma kontağını köprüler: artı kutup → 1. arıza → toprak → 2. arıza → bobin → eksi kutup", "hesap"),
        C("İlk arıza bildiriliyor mu?", f"kutupların toprağa gerilimi +{fnum(u - ve, 0)} V / −{fnum(ve, 0)} V", "arıza varsa dengesizlik alarmı", alarm if s["n_ariza"] >= 1 else None,
          "Yalıtılmış sistemde ilk arıza akım akıtmaz; yalnız kutupların toprağa göre gerilimi kayar. Onu bulup gidermek ikinci arızadan önceki tek fırsattır", "hesap"),
        C("Kapasitif darbe ikili girişi yanıltıyor mu?", (f"başlangıç {fnum(v0, 0)} V, τ = Rg·C = {fnum(tau * 1000, 0)} ms → eşiğin üstünde {fnum(t_ust * 1000, 1)} ms" if darbe_var else "bu durumda darbe yok"), f"< süzme süresi {fnum(t_f * 1000, 0)} ms", (not darbe_yanlis) if darbe_var else None,
          "Kablo kapasitesi kutup–toprak gerilimine yüklüdür; kontak sonrası iletken toprağa değince giriş üzerinden boşalır. Yüksek eşikli ve süzmeli giriş bunun içindir", "hesap"),
        C("Akü toprak üzerinden kısa devre mi?", "artı ve eksi kutup birlikte toprakta" if kisa else "hayır", "iki kutup aynı anda toprağa değmemeli", not kisa,
          "İki arıza farklı kutuplardaysa toprak, aküyü kısa devre eden iletken olur: sigorta ya da otomat açar, kumanda gerilimi kaybolur", "hesap"),
        C("Açma devresi denetimi kaçağı görür mü?", "görmez", "denetim devrenin sürekliliğini izler", None,
          "Açma devresi denetimi (74) bobin devresinin kopukluğunu yakalar; toprak kaçağını yalıtım izleme düzeni yakalar: ikisi birbirinin yerini tutmaz — " + P3U + " böl. 6.18", "resmi"),
    ]
    girdiler = [
        G("Kumanda gerilimi ve akünün topraklama biçimi", f"{u:g} V · yalıtılmış", "Yardımcı servis projesi; akü–redresör kılavuzu", "Yalıtılmış sistemde tek arıza zararsızdır; bir kutbu topraklı sistemde aynı arıza sigorta attırır", "yalıtım izleme gerekir"),
        G("Yalıtım izleme düzeninin türü ve alarm düzeyi", f"her kutup {fnum(num(p, 'rm', 50), 0)} kΩ", "Redresör / izleme cihazı kılavuzu", "İzleme direnci küçükse arıza akımı büyür, büyükse gerilim kayması duyarlı olur", "alarm eşiği"),
        G("Bobinin / girişin çalışma eşiği", f"%{fnum(num(p, 'esik', 60), 0)} Un", "Kesici test raporu (en düşük açma gerilimi); röle kılavuzu (ikili giriş eşiği)", "Eşik ne kadar düşükse yanlış çalışma o kadar kolaydır", "eşik seçimi"),
        G("Kumanda kablolarının boyu", f"kutup başına {fnum(num(p, 'c', 2), 2)} µF" if giris else "—", "Kablo listesi", "Toplam kapasite ilk arızadaki darbenin enerjisini belirler", "τ = Rg·C"),
    ]
    adimlar = [
        A("Toprağın potansiyeli", "düğüm denklemi: Σ iletkenlik × gerilim farkı = 0", f"artı kutba {fnum((u - ve), 0)} V, eksi kutba {fnum(ve, 0)} V", f"eksi kutba göre {fnum(ve, 0)} V", "Kirchhoff akım yasası", "hesap", ["Yalıtım izleme düzeninin türü ve alarm düzeyi"]),
        A("Bobin / giriş gerilimi", "Vx = Ve · Ry / (Ry + R2) — kontak sonrası arıza varsa", f"Ry = {fnum(s['ry'], 0)} Ω", f"{fnum(vx, 1)} V", "gerilim bölücü", "hesap", ["Bobinin / girişin çalışma eşiği"]),
        A("Eşikle karşılaştırma", "Vx ≥ eşik → çalışır", f"{fnum(vx, 0)} V ile {fnum(esik, 0)} V", "çalışır" if yanlis else "çalışmaz", "çekme eşiği (tipik)", "tahmini"),
    ]
    if giris:
        adimlar.append(A("Kapasitif darbenin süresi", "t = Rg·C · ln(U0 / eşik)", f"{fnum(rg / 1000, 0)} kΩ × {fnum(cap * 1e6, 2)} µF × ln({fnum(v0, 0)}/{fnum(esik, 0)})", f"{fnum(t_ust * 1000, 1)} ms" if t_ust else "eşiğe ulaşmaz", "kapasite boşalması", "hesap", ["Kumanda kablolarının boyu"], "süzme süresi"))
    ayarlar = [
        S("İkili giriş › eşik gerilimi", "kumanda geriliminin %70–80'i dolayı", "—", "Düşük eşikli giriş kapasitif darbede ve yarım gerilimde çalışır", "röle kılavuzundaki giriş seçenekleri", "ikincil"),
        S("İkili giriş › süzme (gecikme) süresi", f"{fnum(t_f * 1000, 0)} ms", "—", "Kapasitif darbenin süresinden uzun; koruma işaretlerinde gereğinden uzun olmamalı", "bu sayfadaki hesap", "hesap"),
        S("Açma devresi denetimi (74)", "etkin", "—", "Bobin devresinin kopukluğunu izler; toprak kaçağını izlemez", P3U + " böl. 6.18"),
    ]
    test = [
        T("Yalıtım izleme", "Artı kutup bir dirençle toprağa bağlanır", "Alarm verir; kutup–toprak gerilimleri kayar", "sonra eksi kutup için yinelenir"),
        T("Kutup–toprak gerilimleri", "Voltmetreyle + → toprak ve − → toprak", f"Sağlam sistemde ikisi de {fnum(u / 2, 0)} V dolayında", "biri sıfıra yakınsa o kutupta arıza var"),
        T("Arızanın yerinin bulunması", "Çıkışlar sırayla ayrılır ya da kaçak akım pensiyle izlenir", "Arızalı çıkış ayrılınca gerilimler dengelenir", "koruma devreleri ayrılırken dikkat: açma yapılabilir"),
    ]
    rler = [0.1, 0.3, 1, 3, 10, 30, 100, 200]
    g = {"baslik": "İkinci arızanın direncine göre bobin / giriş gerilimi (1. arıza artı kutupta, 2. arıza kontak sonrasında)", "x_ad": "2. arızanın direnci (kΩ)", "y_ad": "Gerilim (% Un)", "logx": True, "ymin": 0,
         "seriler": [{"ad": "açma bobini", "renk": "#dc2626", "pts": [[r, round(coz({**p, "yuk": "bobin", "f1": "p", "f2": "x", "r2": r})["vx"] / u * 100, 2)] for r in rler]},
                     {"ad": "ikili giriş", "renk": "#1a4d8f", "pts": [[r, round(coz({**p, "yuk": "giris", "f1": "p", "f2": "x", "r2": r})["vx"] / u * 100, 2)] for r in rler]}],
         "yatay": [{"y": num(p, "esik", 60), "etiket": f"eşik %{fnum(num(p, 'esik', 60), 0)}", "renk": "#15803d"}]}
    grafikler = [g]
    if giris:
        ts = [j * 0.5 for j in range(0, 121)]
        grafikler.append({"baslik": "Kontak sonrası iletken toprağa değdiği anda ikili girişteki darbe", "x_ad": "Zaman (ms)", "y_ad": "Giriş gerilimi (% Un)", "ymin": 0, "zaman": True,
                          "seriler": [{"ad": "giriş gerilimi", "renk": "#dc2626", "pts": [[t, round(v0 / u * 100 * math.exp(-t / 1000 / max(tau, 1e-6)), 2)] for t in ts]}],
                          "yatay": [{"y": num(p, "esik", 60), "etiket": "eşik", "renk": "#15803d"}], "isaretler": [{"x": t_f * 1000, "etiket": "süzme süresi"}]})
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": [], "sahne": c.sahne(), "grafikler": grafikler,
        "anlatim": [
            "Kumanda aküsü toprağa bağlı değildir. Bir iletken toprağa değdiğinde akımın dönecek yolu olmadığı için akım akmaz: devre çalışmaya devam eder. Yalıtılmış sistemin amacı budur.",
            "İlk arıza yine de bir şeyi değiştirir: toprağın potansiyeli arızalı kutba çekilir. Artı kutup toprağa değmişse artı kutup–toprak gerilimi sıfıra iner, eksi kutup–toprak gerilimi tam kumanda gerilimine çıkar. Yalıtım izleme düzeni bu kaymadan alarm verir.",
            "İkinci arıza başka bir noktada olursa iki arıza ve aralarındaki toprak, kumanda devresinde yeni bir iletken oluşturur. Bu iletken açma kontağının iki yanını birbirine bağlarsa, kontak açık olduğu halde bobin gerilim görür.",
            f"Şu an bobinin / girişin gördüğü gerilim {fnum(vx, 0)} V; çekme eşiği {fnum(esik, 0)} V. " + ("Eleman çalışır: kesici, hiçbir röle açma vermeden açar." if yanlis else "Eleman çalışmaz."),
            "Bobin birkaç yüz ohmluk küçük bir dirençtir: arıza dirençleri küçük olmadıkça yeterli gerilimi göremez. İkili giriş ise onlarca kiloohmdur: yüksek dirençli kaçaklarda bile gerilim görür. Yanlış işaretler çoğunlukla ikili girişlerden gelir.",
            "Geniş tesislerde kumanda kablolarının toprağa kapasitesi büyüktür ve kutup–toprak gerilimine yüklüdür. Kontak sonrası bir iletken toprağa değdiğinde bu yük giriş üzerinden boşalır: tek arızayla bile kısa bir darbe oluşur. Eşiği yüksek, süzmeli girişler bu darbeyi yok sayar.",
        ],
        "dersler": [
            "Yalıtılmış kumanda devresinde tek toprak arızası zararsızdır, ama zamana karşı bir yarıştır: ikincisi gelmeden bulunmalıdır.",
            "«Kendiliğinden açan kesici» şikâyetinde ilk bakılacak yer akünün kutup–toprak gerilimleridir.",
            "İkili girişler bobinlerden çok daha duyarlıdır: eşik ve süzme süresi tesisin kablo boyuna göre seçilir.",
            "Açma devresi denetimi ile yalıtım izleme ayrı şeyleri izler; ikisi de gerekir.",
        ],
        "tablolar": [{"baslik": "Arıza birleşimleri (bu değerlerle)", "cols": ["1. arıza", "2. arıza", "Bobin / giriş gerilimi", "Yanlış çalışma", "İzleme"],
                      "rows": [[YER[a_], YER[b_], f"%{fnum(q['vx'] / u * 100, 0)} Un", "VAR" if q["vx"] >= esik else "yok", "alarm" if abs((u - q["ve"]) - q["ve"]) / u > 0.2 else "olağan"]
                               for a_, b_ in (("yok", "yok"), ("p", "yok"), ("n", "yok"), ("x", "yok"), ("p", "x"), ("n", "x"), ("p", "n")) for q in [coz({**p, "f1": a_, "f2": b_})]],
                      "not": "Artı ve eksi kutbun ikisi birden toprağa değerse akü kısa devre olur; sigorta ya da otomat açar."}],
    }


def ve_once(p: dict) -> float:
    """Kontak sonrası arızadan hemen önce toprağın eksi kutba göre gerilimi (kablo kapasitesi bu gerilime yüklüdür)."""
    q = dict(p)
    for k in ("f1", "f2"):
        if q.get(k) == "x":
            q[k] = "yok"
    return coz(q)["ve"]
