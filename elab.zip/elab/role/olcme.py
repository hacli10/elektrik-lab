"""Röle nasıl ölçer: örnekleme, bir periyotluk Fourier süzgeci, doğru akım bileşeni ve ani kademenin geçici aşırı erişimi.

Dayanak: P3U/en M/J006 böl. 3.2 (doğrudan ölçmelerin ve koruma işlevlerinin çoğu temel bileşen değerine dayanır; Şekil 4: demeraj akımında
temel bileşen, 2. harmonik ve etkin değer), böl. 5.32 ve kayıt cihazı (32 örnek/periyot), I>> / I>>> çizelgeleri («Transient overreach, any τ < 10 %»);
P14DEd2-TM-EN-11.2 böl. 5.1–5.3 (24 örnek/periyot, frekans izleme, bir periyotluk Fourier; koruma işlevlerinin çoğu temel bileşeni kullanır);
GE F60 böl. 2 (64 örnek/periyot, örnekleme hızı frekansa uyarlanır); ABB 1MRS756887 böl. 3.8 (ölçme modu: RMS / DFT / Peak-to-Peak).
Buradaki süzgeç yalın tam periyot Fourier süzgecidir; rölelerdeki ek süzgeçler modellenmedi (aşırı erişim yüzdeleri tahmini)."""
from __future__ import annotations

import math

from . import dalga as D
from .ortak import A, C, Cizim, G, K, P3U, S, T, URRA, ctl, fnum, num, opt, sz_kademe
from .roleler import ABB, F60, P14D

ID = "olcme"
BASLIK = "Röle nasıl ölçer"
IKON = "📈"
GIRIS = ("Röle akımı sürekli izlemez: periyot başına belli sayıda örnek alır ve son bir periyodun örneklerinden 50 Hz bileşenini hesaplar. "
         "Bu sayfada kısa devre akımının doğru akım bileşeniyle nasıl başladığını, rölenin onu ne kadar sürede ve ne kadar yanlış ölçtüğünü, "
         "ani kademenin bu yüzden neden «aşırı eriştiğini» dalga üzerinde görürsünüz.")

AKIM = {"ariza": "Kısa devre (doğru akım bileşenli)", "harmonik": "Harmonikli yük akımı (3. ve 5. harmonik)", "demeraj": "Trafo demerajı (tek yönlü darbeler)"}
YONTEM = {"dft": "Temel bileşen (bir periyotluk Fourier)", "rms": "Gerçek etkin değer (RMS)", "tt": "Tepeden tepeye"}

KONTROLLER = [
    ctl("akim", "Akımın türü", "sec", "ariza", secenek=opt(*AKIM.items())),
    ctl("i", "Akımın kalıcı etkin değeri", "sayi", 8.5, min=0.5, max=30, adim=0.1, birim="×In"),
    ctl("xr", "Arıza yolunun X/R oranı", "sayi", 14, min=0.5, max=60, adim=0.5, goster={"akim": ["ariza"]}, yardim="OG barasında 10–20, trafo AG çıkışında 3–6, uzun AG kablosunun sonunda 1'in altında"),
    ctl("alfa", "Arıza anında gerilimin açısı", "sayi", 0, min=0, max=180, adim=5, birim="°", goster={"akim": ["ariza"]}, yardim="0°: gerilim sıfırdan geçerken — doğru akım bileşeni en büyük; 90° dolayı: bileşen yok"),
    ctl("n", "Röle › periyot başına örnek", "sec", 32, secenek=opt((16, "16"), (24, "24 (MiCOM P14D)"), (32, "32 (Easergy P3)"), (64, "64 (GE F60)"))),
    ctl("yontem", "Röle › ölçme yöntemi", "sec", "dft", secenek=opt(*YONTEM.items())),
    ctl("ayar", "Röle › ani kademe (I>>) başlatma", "sayi", 10.0, min=0.5, max=40, adim=0.1, birim="×In"),
    ctl("tk", "Röle › ani kademe gecikmesi", "sayi", 0, min=0, max=200, adim=10, birim="ms"),
]
ON, SON = 2, 8            # arızadan önceki ve sonraki periyot sayısı


def dalga(p: dict, N: int) -> tuple[list, list]:
    """(zaman ms, akım ×In anlık). Arıza t = 0'da başlar; öncesinde 0,3 ×In yük akımı."""
    tip = p.get("akim") if p.get("akim") in AKIM else "ariza"
    i, xr, alfa = num(p, "i", 8.5), num(p, "xr", 14), num(p, "alfa", 0)
    ts, xs = [], []
    for k in range(-ON * N, SON * N + 1):
        t = k * 0.02 / N
        if tip == "ariza":
            v = D.KOK2 * 0.3 * math.sin(D.W * t) if t < 0 else D.kd_akim(i, xr, alfa, t)
        elif tip == "harmonik":
            v = D.KOK2 * i * (math.sin(D.W * t) + 0.20 * math.sin(3 * D.W * t) + 0.15 * math.sin(5 * D.W * t))
        else:
            v = 0.0 if t < 0 else i * 4.0 * max(0.0, math.sin(D.W * t) - 0.2) / 0.8 * math.exp(-t / 0.25)      # tek yönlü darbe, yavaş sönen
        ts.append(t * 1000); xs.append(v)
    return ts, xs


def olc(p: dict, N: int | None = None) -> dict:
    N = N or int(num(p, "n", 32))
    ts, xs = dalga(p, N)
    m = {"dft": D.temel(xs, N), "rms": D.etkin(xs, N), "tt": D.tepe_tepe(xs, N)}
    son = {k: v[-1] for k, v in m.items()}                                     # kalıcı duruma en yakın değer
    i0 = ON * N
    asim = {k: (max(v[i0:]) - son[k]) / max(son[k], 1e-9) for k, v in m.items()}
    return {"N": N, "t": ts, "x": xs, "m": m, "son": son, "asim": asim}


def run(p: dict) -> dict:
    tip = p.get("akim") if p.get("akim") in AKIM else "ariza"
    yon = p.get("yontem") if p.get("yontem") in YONTEM else "dft"
    i, xr, alfa, ayar, tk = num(p, "i", 8.5), num(p, "xr", 14), num(p, "alfa", 0), num(p, "ayar", 10), num(p, "tk", 0) / 1000
    o = olc(p); N = o["N"]; ts, xs, olcu = o["t"], o["x"], o["m"][yon]
    i0 = ON * N
    tau = D.tau(xr); fi = math.degrees(math.atan(xr))
    dc0 = -math.sin(math.radians(alfa - fi)) if tip == "ariza" else 0.0          # doğru akım bileşeninin başlangıcı (tepe değerin oranı)
    kalici = o["son"][yon]
    k = sz_kademe([t / 1000 for t in ts], olcu, ayar, tk, True, 0.03)
    acti = k["acma"] is not None
    beklenen = kalici >= ayar                                                   # kalıcı değer ayarın üstündeyse açması doğrudur
    dogru = acti == beklenen
    tepe = max(abs(v) for v in xs[i0:])
    t95 = next((ts[j] for j in range(i0, len(ts)) if o["m"]["dft"][j] >= 0.95 * o["son"]["dft"]), None)
    dt_ms = 20 / N

    c = Cizim(900, 300)
    kutular = [("Akım trafosu", f"sekonder akım"), ("Süzgeç", "yüksek frekansı atar"), ("Örnekleyici", f"{N} örnek / periyot"), ("Pencere", "son 20 ms"),
               ("Ölçü", {"dft": "50 Hz bileşeni", "rms": "etkin değer", "tt": "tepeden tepeye"}[yon]), ("I>> karşılaştırma", f"≥ {fnum(ayar, 1)} ×In ?"), ("Açma", "AÇTI" if acti else "açmadı")]
    for j, (ad, alt) in enumerate(kutular):
        x = 12 + j * 127
        c.kutu(x, 46, 114, 54, ad, alt, ("acti" if dogru else "gecersiz") if j == 6 and acti else "vurgu" if j == 4 else "normal")
        if j < 6:
            c.ok(x + 114, 73, x + 127, 73, "cizgi", 1.6)
    c.yazi(450, 30, "Akımın röle içindeki yolu", "#475569", 11, anchor="middle")
    c.yazi(266 + 57, 118, f"her {fnum(dt_ms, 3)} ms'de bir", "#64748b", 10, anchor="middle")
    c.yazi(393 + 57, 118, f"{N} örnek birlikte", "#64748b", 10, anchor="middle")
    c.yazi(40, 160, f"Gerçek akım: kalıcı {fnum(i, 2)} ×In etkin · en büyük anlık değer {fnum(tepe, 1)} ×In" + (f" · doğru akım bileşeni başlangıçta tepe değerin %{fnum(abs(dc0) * 100, 0)}'i, τ = {fnum(tau * 1000, 0)} ms" if tip == "ariza" else ""), "#334155", 11.5)
    c.yazi(40, 182, f"Rölenin ölçtüğü ({YONTEM[yon].split(' (')[0].lower()}): en büyük {fnum(max(olcu[i0:]), 2)} ×In → kalıcı {fnum(kalici, 2)} ×In", "#1a4d8f", 12, kalin=True)
    c.yazi(40, 204, f"Geçici aşırı ölçme: %{fnum(o['asim'][yon] * 100, 0)}  (Fourier %{fnum(o['asim']['dft'] * 100, 0)} · etkin değer %{fnum(o['asim']['rms'] * 100, 0)} · tepeden tepeye %{fnum(o['asim']['tt'] * 100, 0)})", "#334155", 11.5)
    c.yazi(40, 232, ("Ani kademe AÇTI" + (f" — arızadan {fnum(k['acma'], 3).replace('0,', '0,')} s sonra" if acti else "")) if acti else "Ani kademe açmadı",
           ("#15803d" if dogru else "#b91c1c"), 13, kalin=True)
    c.yazi(40, 252, ("Doğru: kalıcı akım ayarın üstünde." if beklenen else "YANLIŞ: kalıcı akım ayarın altında; röle doğru akım bileşeni yüzünden fazla ölçtü (geçici aşırı erişim).") if acti
           else ("Doğru: kalıcı akım ayarın altında." if not beklenen else "Eksik: kalıcı akım ayarın üstünde ama ölçü ayara ulaşmadı."), "#15803d" if dogru else "#b91c1c", 11.5)

    ozet = [
        K("Ani kademe", "AÇTI" if acti else "açmadı", "ok" if dogru else "bad", ("doğru" if dogru else "YANLIŞ") + (" — arıza erişim içinde" if beklenen else " — arıza erişim dışında")),
        K("Rölenin gördüğü en büyük değer", f"{fnum(max(olcu[i0:]), 2)} ×In", "info", f"kalıcı {fnum(kalici, 2)} ×In"),
        K("Geçici aşırı ölçme", f"%{fnum(o['asim'][yon] * 100, 0)}", "ok" if o["asim"][yon] < 0.10 else "warn", YONTEM[yon].split(" (")[0]),
        K("Doğru akım bileşeni", f"%{fnum(abs(dc0) * 100, 0)}" if tip == "ariza" else "—", "info", f"τ = {fnum(tau * 1000, 0)} ms (X/R = {fnum(xr, 1)})" if tip == "ariza" else "bu akımda yok"),
        K("Ölçünün oturma süresi", f"{fnum(t95 if t95 is not None else 0, 0)} ms" if t95 is not None else "—", "info", "kalıcı değerin %95'ine ulaşma"),
    ]
    kontroller = [
        C("Ani kademe doğru karar veriyor mu?", f"en büyük ölçü {fnum(max(olcu[i0:]), 2)} ×In; kalıcı {fnum(kalici, 2)} ×In; ayar {fnum(ayar, 1)} ×In", "yalnız kalıcı akım ayarı aşıyorsa açmalı", dogru,
          "Kademe, ölçülen değeri ayarla karşılaştırır; ölçü geçici olarak büyürse erişim dışındaki arızada da açar (geçici aşırı erişim)", "hesap"),
        C("Bu yöntemin geçici aşırı ölçmesi", f"%{fnum(o['asim'][yon] * 100, 0)} (yalın süzgeç modeli)", "üretici verisi: < %10 (her τ için)", None,
          "Easergy P3 I>> ve I>>> kademelerinde «Transient overreach, any τ < 10 %» — " + P3U + " böl. 5.20 çizelgeleri. Bu sayfadaki yüzde yalın Fourier süzgecinindir", "tahmini"),
        C("Örnekleme hızı yeterli mi?", f"{N} örnek/periyot → {fnum(N * 50, 0)} Hz; ölçülebilen en yüksek frekans {fnum(N * 25, 0)} Hz ({N // 2}. harmonik)", "≥ 5. harmonik (250 Hz) için 500 Hz", N * 25 >= 250,
          "Örnekleme kuramı: örnekleme hızının yarısından yüksek frekanslar ayırt edilemez; bu yüzden örnekleyiciden önce süzgeç bulunur", "hesap"),
        C("Ani kademenin en kısa açma süresi", f"ölçü kalıcı değerin %95'ine {fnum(t95 or 0, 0)} ms'de ulaşıyor", "bir periyot dolayı (20 ms)", None,
          "Fourier süzgeci bir periyotluk örnek ister: arıza akımı ayarın çok üstündeyse pencere dolmadan da eşik aşılır, ayara yakınsa bir periyot beklenir", "hesap"),
    ]
    girdiler = [
        G("Arıza yerindeki X/R oranı", f"{fnum(xr, 1)}" if tip == "ariza" else "—", "Kısa devre hesabı (kaynak, trafo, hat empedanslarının R ve X toplamları)", "Doğru akım bileşeninin ne kadar sürdüğünü belirler: τ = (X/R)/ω", "τ uzunsa ani kademe ayarına pay eklenir"),
        G("Rölenin örnekleme hızı ve ölçme yöntemi", f"{N} örnek/periyot · {YONTEM[yon].split(' (')[0]}", "Röle kılavuzu (ölçme / sinyal işleme bölümü)", "Aynı akımı farklı röleler farklı ölçer: harmonikte, demerajda ve doğru akım bileşeninde okuma değişir", "Test cihazındaki değerle röle okumasını karşılaştırırken"),
        G("Ani kademenin erişmesi istenen nokta", f"I>> = {fnum(ayar, 1)} ×In", "Koruma koordinasyon çalışması: bölge sonundaki en büyük arıza akımı", "Ani kademe bölge sonundaki arızada açmamalı; aşırı erişim payı bırakılmazsa seçicilik bozulur", "I>> ≥ 1,2–1,3 × bölge sonu arıza akımı"),
    ]
    adimlar = [
        A("Örnekleme aralığı", "Δt = 20 ms / N", f"20 / {N}", f"{fnum(dt_ms, 3)} ms ({fnum(N * 50, 0)} Hz)", "Periyot başına örnek sayısı — röle kılavuzu", "hesap", ["Rölenin örnekleme hızı ve ölçme yöntemi"]),
        A("Doğru akım bileşeninin zaman sabiti", "τ = (X/R) / (2π·f)", f"{fnum(xr, 1)} / 314", f"{fnum(tau * 1000, 0)} ms", "R–L devresinin zaman sabiti L/R", "hesap", ["Arıza yerindeki X/R oranı"]),
        A("Doğru akım bileşeninin başlangıç değeri", "−sin(α − φ) · √2·I ,  φ = atan(X/R)", f"−sin({fnum(alfa, 0)}° − {fnum(fi, 0)}°)", f"tepe değerin %{fnum(abs(dc0) * 100, 0)}'i", "Endüktif devrede akım sıçrayamaz: t = 0'da toplam akım sıfır olmalı", "hesap", ["Arıza yerindeki X/R oranı"]),
        A("Temel bileşen (rölenin hesabı)", "I1 = (2/N) · |Σ i(k) · e^(−j2πk/N)| / √2", "son bir periyodun örnekleri", f"kalıcı {fnum(o['son']['dft'], 2)} ×In", "Bir periyotluk Fourier süzgeci — " + P14D + " böl. 5.3", "resmi"),
        A("Geçici aşırı ölçme", "(en büyük ölçü − kalıcı ölçü) / kalıcı ölçü", f"({fnum(max(olcu[i0:]), 2)} − {fnum(kalici, 2)}) / {fnum(kalici, 2)}", f"%{fnum(o['asim'][yon] * 100, 0)}", "Yalın süzgeç modeli (bu sayfa)", "tahmini", [], "I>> payı"),
    ]
    ayarlar = [
        S("ABB 615 › Measurement mode", "DFT", "RMS / DFT / Peak-to-Peak", "DFT harmonikleri ve doğru akım bileşenini bastırır; RMS ısıl etkiyi ölçer, kısa devrede fazla okur", ABB + " böl. 3.8 (ölçme modu ayarı)"),
        S("Easergy P3 › ölçme", "temel bileşen (ayar yok)", "—", "Doğrudan ölçmeler ve koruma işlevlerinin çoğu temel bileşen değerine dayanır", P3U + " böl. 3.2"),
        S("I>> başlatma", f"{fnum(ayar, 1)} ×In", "—", "Bölge sonundaki en büyük arıza akımının 1,2–1,3 katı: aşırı erişim ve akım trafosu hatası payı", URRA, "ikincil"),
    ]
    test = [
        T("Saf sinüs", f"50 Hz, {fnum(i, 2)} ×In", f"Röle {fnum(i, 2)} ×In okur (her yöntemde)", "±%1 ya da kılavuzdaki doğruluk"),
        T("Doğru akım bileşenli arıza", f"Test cihazında X/R = {fnum(xr, 0)} (ya da τ = {fnum(tau * 1000, 0)} ms), akım I>> ayarının %90'ı", "Ani kademe açmamalı", "aşırı erişim < %10 — " + P3U),
        T("Harmonikli akım", "50 Hz 1,00 ×In + 150 Hz %20 + 250 Hz %15", "Temel bileşen ölçen röle 1,00 ×In; etkin değer ölçen 1,03 ×In okur", "√(1 + 0,2² + 0,15²) = 1,03"),
        T("Açma süresi", "Ayarın 2 katı akımı basamak olarak uygula", "Ani kademe bir periyodun altında başlar; açma kontağı süresi eklenir", "kılavuzdaki «start time»"),
    ]
    env = D.KOK2
    g1 = {"baslik": "Akımın dalga biçimi ve rölenin ölçtüğü değer", "x_ad": "Zaman (ms) — arıza t = 0'da", "y_ad": "Akım (×In, anlık)", "zaman": True,
          "seriler": [{"ad": "akım (anlık)", "renk": "#dc2626", "pts": D.seri(ts, xs, max(1, N // 32))},
                      {"ad": "rölenin ölçtüğü × √2", "renk": "#1a4d8f", "pts": D.seri(ts, [v * env for v in olcu], max(1, N // 32))}]
          + ([{"ad": "doğru akım bileşeni", "renk": "#b45309", "kesik": True, "pts": [[round(t, 2), round(D.KOK2 * i * dc0 * math.exp(-t / 1000 / tau), 3)] for t in ts[i0::max(1, N // 16)]]}] if tip == "ariza" and tau > 0 else []),
          "yatay": [{"y": ayar * env, "etiket": f"I>> ayarı × √2", "renk": "#15803d"}], "isaretler": [{"x": 0, "etiket": "arıza"}] + ([{"x": k["acma"] * 1000, "etiket": "açma"}] if acti else [])}
    g2 = {"baslik": "Aynı akımı üç ölçme yöntemi nasıl görür", "x_ad": "Zaman (ms)", "y_ad": "Ölçülen etkin değer (×In)", "ymin": 0,
          "seriler": [{"ad": "temel bileşen (Fourier)", "renk": "#1a4d8f", "pts": D.seri(ts, o["m"]["dft"], max(1, N // 16))}, {"ad": "gerçek etkin değer", "renk": "#dc2626", "pts": D.seri(ts, o["m"]["rms"], max(1, N // 16))},
                      {"ad": "tepeden tepeye", "renk": "#15803d", "kesik": True, "pts": D.seri(ts, o["m"]["tt"], max(1, N // 16))}],
          "yatay": [{"y": ayar, "etiket": f"I>> = {fnum(ayar, 1)} ×In", "renk": "#64748b"}]}
    grafikler = [g1, g2]
    if tip == "ariza":
        taular = [5, 10, 20, 30, 45, 60, 80, 100, 130, 160]
        egri = {kk: [] for kk in YONTEM}
        for tm in taular:
            oo = olc({**p, "xr": tm / 1000 * D.W, "alfa": math.degrees(math.atan(tm / 1000 * D.W)) - 90 + 180}, 24)      # her τ'da en büyük doğru akım bileşeni
            for kk in YONTEM:
                egri[kk].append([tm, round(oo["asim"][kk] * 100, 1)])
        grafikler.append({"baslik": "Geçici aşırı ölçme, doğru akım bileşeninin zaman sabitine göre (en kötü kapama anı)", "x_ad": "τ (ms)", "y_ad": "Aşırı ölçme (%)", "ymin": 0,
                          "seriler": [{"ad": "temel bileşen (Fourier)", "renk": "#1a4d8f", "pts": egri["dft"]}, {"ad": "gerçek etkin değer", "renk": "#dc2626", "pts": egri["rms"]}, {"ad": "tepeden tepeye", "renk": "#15803d", "kesik": True, "pts": egri["tt"]}],
                          "yatay": [{"y": 10, "etiket": "üretici sınırı %10", "renk": "#64748b"}], "isaretler": [{"x": round(tau * 1000), "etiket": "şu an"}] if 5 <= tau * 1000 <= 160 else []})
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["50-51"], "sahne": c.sahne(), "grafikler": grafikler,
        "anlatim": [
            f"Röle akımı her {fnum(dt_ms, 3)} ms'de bir örnekler (periyot başına {N} örnek). Örnekleyiciden önceki süzgeç, örnekleme hızının yarısından ({fnum(N * 25, 0)} Hz) yüksek frekansları atar; yoksa bunlar yanlış frekans gibi görünür.",
            "Her yeni örnekte son 20 ms'nin örnekleri bir sinüs ve bir kosinüsle çarpılıp toplanır. Çıkan sayı 50 Hz bileşeninin büyüklüğü ve açısıdır: harmonikler ve sabit bir doğru akım bu toplamda sıfırlanır.",
            "Arıza anında akım sıçrayamaz. Gerilim sıfırdan geçerken arıza olursa akımın sinüs kısmı tepe değerinden başlamak ister; aradaki fark doğru akım bileşeni olarak ortaya çıkar ve τ = (X/R)/ω ile söner.",
            "Doğru akım bileşeni sabit değil, sönen bir eğridir. Bir periyotluk pencere içinde eğimi olduğu için Fourier toplamı onu tam sıfırlayamaz: ölçü ilk periyotlarda kalıcı değerin üstüne çıkar.",
            "Ani kademe bu fazla ölçüyle ayarı aşarsa, erişmesi istenmeyen bir arızada açar. Buna geçici aşırı erişim denir; ani kademe ayarına bu yüzden pay bırakılır.",
            "Etkin değer ölçen röle doğru akım bileşenini ve harmonikleri de sayar: kısa devrede çok daha fazla okur, ama ısınmayı doğru ölçer. Hangi kademenin neyi ölçtüğü kılavuzda yazılıdır.",
        ],
        "dersler": [
            "Röle 50 Hz bileşenini ölçer; multimetre ya da pens ampermetre etkin değeri. Harmonikli akımda ikisi farklı okur — ikisi de doğrudur.",
            "Ölçü bir periyotta oturur: ani kademe 20 ms'den hızlı «görmez»; açma kontağının süresi buna eklenir.",
            "X/R büyüdükçe (barada, trafo yakınında) doğru akım bileşeni uzun sürer; hem aşırı erişim hem akım trafosu doyması artar.",
            "Sekonder testte yalnız saf sinüs verilirse aşırı erişim görülmez; test cihazının doğru akım bileşeni seçeneği bunun içindir.",
        ],
        "tablolar": [{"baslik": "Rölelerde örnekleme ve ölçme", "cols": ["Röle", "Örnek / periyot", "Ölçme", "Dayanak"], "rows": [
            ["Schneider Easergy P3", "32", "Koruma işlevlerinin çoğu temel bileşen değeriyle; ısıl kademe etkin değerle", P3U + " böl. 3.2, 5.32"],
            ["GE MiCOM P14D", "24 (frekansı izler)", "Bir periyotluk Fourier; iki periyotluk örnek belleği", P14D + " böl. 5.1–5.3"],
            ["GE Multilin F60", "64 (frekansı izler)", "Fazör kestirimi; örnekleme hızı şebeke frekansına uyarlanır", F60 + " böl. 2 (UR sinyal işleme)"],
            ["ABB REF615 / REF620", "—", "Kademe başına seçilir: RMS, DFT ya da Peak-to-Peak", ABB + " böl. 3.8"],
        ], "not": "ABB 615 serisinin örnekleme hızı incelenen kılavuz bölümünde aranmadı; boş bırakıldı."}],
    }
