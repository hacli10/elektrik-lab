"""Senkron kontrol (ANSI 25) — Easergy P3 «Synchronism check» kademesi.

Dayanak: P3U/en M/J006 böl. 5.7 (kesici kapama komutundan önce iki gerilimin genlik, frekans ve faz açısı farkı denetlenir; iki ölçüt: yalnız gerilim — ölü / canlı —
ve gerilim + frekans + faz; «Sync» modunda kapama sıfır faz farkı anına hedeflenir ve komut kesici kapama süresi kadar öne alınır; «Async» modunda faz farkı sınırın içine
girdiğinde kapatılır; istek zaman aşımı içinde koşul oluşmazsa 200 ms'lik «fail» darbesi; frekans farkı 0,1 Hz ise koşul on saniyede bir oluşur), Çizelge 49 (mod Off / Async /
Sync; gerilim modu DD, DL, LD ve birleşimleri; kesici kapama süresi 0,04–0,6 s; Vdead ve Vlive %10–120 Un; frekans farkı 0,01–1,00 Hz; gerilim farkı %1–60 Un; faz açısı farkı
2°–90°; istek zaman aşımı 0,1–600 s; doğruluk: gerilim ±%3, frekans ±20 mHz, açı ±2° — Δf < 0,2 Hz iken). Jeneratör senkronlamasındaki sınır önerileri saha pratiğidir."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, P3U, S, T, ctl, fnum, fz, num, opt, tek_hat

ID = "senkron25"
BASLIK = "Senkron kontrol (25)"
IKON = "🔗"
GIRIS = ("İki ayrı kaynağı birbirine bağlayan kesici, iki tarafın gerilimi aynı büyüklükte, aynı frekansta ve aynı fazdayken kapatılmalıdır. Değilse kapama anında büyük "
         "bir dengeleme akımı ve mil üzerinde darbe oluşur. Senkron kontrol kapama komutunu bu üç farka bakarak verir ya da engeller.")

MOD = {"sync": "Sync — sıfır faz farkı anına hedefle", "async": "Async — sınırın içine girince kapat", "off": "Off — yalnız gerilim denetimi"}

KONTROLLER = [
    ctl("du", "Gerilim farkı (jeneratör − şebeke)", "sayi", 3.0, min=-30, max=30, adim=0.5, birim="% Un"),
    ctl("df", "Frekans farkı (kayma)", "sayi", 0.10, min=0.0, max=1.5, adim=0.01, birim="Hz"),
    ctl("fi0", "Kapama isteği anındaki faz farkı", "sayi", 120, min=-180, max=180, adim=5, birim="°"),
    ctl("canli", "Şebeke tarafı enerjili", "onay", True),
    ctl("mod", "Röle › Senkron kontrol modu", "sec", "sync", secenek=opt(*MOD.items())),
    ctl("du_max", "Röle › Gerilim farkı", "sayi", 5, min=1, max=60, adim=1, birim="% Un"),
    ctl("df_max", "Röle › Frekans farkı", "sayi", 0.20, min=0.01, max=1.00, adim=0.01, birim="Hz"),
    ctl("fi_max", "Röle › Faz açısı farkı", "sayi", 10, min=2, max=90, adim=1, birim="°"),
    ctl("t_cb", "Röle › Kesici kapama süresi", "sayi", 0.06, min=0.04, max=0.6, adim=0.01, birim="s"),
    ctl("t_out", "Röle › İstek zaman aşımı", "sayi", 30.0, min=0.1, max=600, adim=0.5, birim="s"),
    ctl("vmode", "Röle › Gerilim denetim modu", "sec", "ll", secenek=opt(("ll", "yalnız iki taraf da canlıyken (senkron)"), ("dl", "DL / LD — bir taraf ölüyken de kapat"))),
]


def run(p: dict) -> dict:
    mod = p.get("mod") if p.get("mod") in MOD else "sync"
    du, df, fi0 = num(p, "du", 3.0), num(p, "df", 0.1), num(p, "fi0", 120)
    du_max, df_max, fi_max, tcb, tout = num(p, "du_max", 5), num(p, "df_max", 0.2), num(p, "fi_max", 10), num(p, "t_cb", 0.06), num(p, "t_out", 30.0)
    canli = bool(p.get("canli"))
    hiz = 360 * df                                                # °/s: faz farkının dönme hızı
    olu_kapat = (not canli) and p.get("vmode") == "dl"
    u_ok, f_ok = abs(du) <= du_max, df <= df_max
    t_kom, fi_kapama, neden = None, None, ""
    if olu_kapat:
        t_kom, fi_kapama, neden = 0.0, 0.0, "şebeke tarafı ölü: gerilim denetimiyle kapatıldı"
    elif not canli:
        neden = "şebeke tarafı ölü; gerilim modu ölü baraya kapamaya izin vermiyor"
    elif mod == "off":
        t_kom, fi_kapama, neden = 0.0, fi0, "frekans ve faz denetimi kapalı: faz farkına bakılmadan kapatıldı"
    elif not u_ok or not f_ok:
        neden = ("gerilim farkı sınırın dışında" if not u_ok else "frekans farkı sınırın dışında")
    else:
        # faz farkı fi(t) = fi0 − hiz·t (jeneratör hızlıysa fark kapanır); hedef: Sync → kontak anında 0°; Async → komut anında |fi| ≤ fi_max
        if hiz < 1e-9:
            if abs(fi0) <= fi_max:
                t_kom, fi_kapama = 0.0, fi0
            else:
                neden = "frekans farkı sıfır ve faz farkı sınırın dışında: koşul hiç oluşmaz"
        else:
            f0 = fi0 % 360                                        # 0…360: sıfıra kalan açı
            if mod == "sync":
                t_sifir = f0 / hiz                                # faz farkının sıfır olacağı an
                t_kom = t_sifir - tcb
                if t_kom < 0:
                    t_kom += 360 / hiz
                fi_kapama = 0.0
            else:
                t_kom = max(0.0, (f0 - fi_max) / hiz) if f0 > fi_max and f0 < 360 - fi_max else 0.0
                fi_k = (f0 - hiz * (t_kom + tcb)) % 360
                fi_kapama = fi_k if fi_k <= 180 else fi_k - 360
            if t_kom > tout:
                neden = f"koşul {fnum(t_kom, 1)} s sonra oluşacaktı; istek zaman aşımı {fnum(tout, 1)} s: «fail»"; t_kom = None; fi_kapama = None
    kapadi = t_kom is not None
    du_kontak = 2 * math.sin(math.radians(abs(fi_kapama or 0)) / 2) * 100 if kapadi else None      # kontaklar arasındaki gerilim (% Un), açı farkından
    uygun = (not kapadi) or (abs(fi_kapama) <= fi_max + 1e-6 and (olu_kapat or mod == "off" or (u_ok and f_ok)))
    guvenli = (not kapadi) or abs(fi_kapama) <= 20 or olu_kapat
    c = tek_hat(("Jeneratör", f"f = {fnum(50 + df, 2)} Hz"), ("Şebeke barası", "50,00 Hz" if canli else "enerjisiz"), ("25  senkron kontrol", ("KAPAT — " + fnum(t_kom, 2) + " s sonra") if kapadi else "kapama engellendi"),
                "acti" if kapadi and guvenli else ("gecersiz" if kapadi else "normal"), None, "", ileri=False, gt_ad="GT (iki taraf)")
    c.yazi(500, 190, f"ΔU = %{fnum(du, 1)} · Δf = {fnum(df, 2)} Hz · faz farkı {fnum(fi0, 0)}° (dönme hızı {fnum(hiz, 0)}°/s)", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, (f"Kontaklar {fnum(fi_kapama, 1)}° faz farkında kapandı; kontaklar arası gerilim %{fnum(du_kontak, 0)} Un") if kapadi else neden, "#334155", 11)
    c.yazi(500, 226, f"Koşul {fnum(1 / df, 1)} s'de bir oluşur" if df > 1e-6 and canli else "", "#334155", 11)
    fazor = {"baslik": "İki tarafın gerilimi (kapama isteği anında)", "vektorler": [fz("U şebeke", 100 if canli else 0, 0, 1.0 if canli else 0.02, "#1d4ed8"), fz("U jeneratör", 100 + du, fi0, min(1.2, (100 + du) / 100), "#dc2626")],
             "bolge": {"aci": 0, "yari": fi_max, "renk": "#15803d", "ad": "izin"}, "not": f"Jeneratör fazörü şebekeye göre {fnum(hiz, 0)}°/s hızla döner. Yeşil: faz açısı farkı sınırı ± {fnum(fi_max, 0)}°."}
    ozet = [
        K("Kapama", ("verildi — " + fnum(t_kom, 2) + " s sonra") if kapadi else "engellendi", "ok" if (kapadi and guvenli) or (not kapadi and not (u_ok and f_ok and canli)) else ("bad" if kapadi else "warn"), neden or "senkron koşulu oluştu"),
        K("Kontak anındaki faz farkı", f"{fnum(fi_kapama, 1)}°" if kapadi else "—", "info" if not kapadi else ("ok" if abs(fi_kapama) <= fi_max else "bad"), f"sınır ± {fnum(fi_max, 0)}°"),
        K("Kontaklar arası gerilim", f"%{fnum(du_kontak, 0)} Un" if kapadi else "—", "info" if not kapadi else ("ok" if du_kontak <= 35 else "bad"), "2·sin(Δφ/2)"),
        K("Faz farkının dönme hızı", f"{fnum(hiz, 0)}°/s", "info", f"kesici süresinde {fnum(hiz * tcb, 1)}° döner"),
        K("Koşulun yinelenme süresi", f"{fnum(1 / df, 1)} s" if df > 1e-6 else "∞", "ok" if df < 1e-6 or 1 / df <= tout else "warn", f"istek zaman aşımı {fnum(tout, 1)} s"),
    ]
    kontroller = [
        C("Kapama güvenli koşulda mı yapıldı?", (f"kontak anında {fnum(fi_kapama, 1)}°" if kapadi else "kapama yapılmadı: " + neden), "kontak anındaki faz farkı ≤ ayar; gerilim ve frekans farkı sınırın içinde", uygun and guvenli,
          P3U + " böl. 5.7 (senkron ölçütleri)", "resmi"),
        C("Kesici kapama süresi hesaba katılıyor mu?", f"kesici süresinde faz {fnum(hiz * tcb, 1)}° döner; mod: {MOD[mod].split(' —')[0]}", "Sync modunda komut kesici süresi kadar öne alınır", mod == "sync" or hiz * tcb <= fi_max / 2,
          "«Sync» modunda kapama sıfır faz farkı anına hedeflenir ve komut «CB close time» kadar öne alınır — " + P3U + " böl. 5.7, Çizelge 49", "resmi"),
        C("İstek zaman aşımı koşulun yinelenme süresinden uzun mu?", f"zaman aşımı {fnum(tout, 1)} s; koşul {fnum(1 / df, 1) if df > 1e-6 else '∞'} s'de bir", "zaman aşımı ≥ 1 / Δf", df < 1e-6 or tout >= 1 / df,
          "Frekans farkı 0,1 Hz ise senkron koşulu on saniyede bir oluşur — " + P3U + " böl. 5.7", "resmi"),
        C("Sınırlar jeneratör senkronlaması için uygun mu?", f"ΔU ≤ %{fnum(du_max, 0)} · Δf ≤ {fnum(df_max, 2)} Hz · Δφ ≤ {fnum(fi_max, 0)}°", "ΔU ≤ %5–10 · Δf ≤ 0,1–0,2 Hz · Δφ ≤ 10°", du_max <= 10 and df_max <= 0.2 and fi_max <= 10,
          "Ayar aralıkları: " + P3U + " Çizelge 49. Sınır önerileri saha pratiğidir; jeneratör üreticisinin izin verdiği değerler esas alınır", "ikincil"),
        C("Ayrı kaynaklarda yalnız gerilim denetimi kullanılıyor mu?", MOD[mod], "ayrı kaynak / jeneratörde frekans ve faz denetimi şart", mod != "off", "İki bölüm ayrı kaynaklardan besleniyorsa yalnız gerilim ölçütü güvenli değildir — " + P3U + " böl. 5.7", "resmi"),
    ]
    girdiler = [
        G("Kesicinin kapama süresi", f"{fnum(tcb * 1000, 0)} ms", "Kesici etiketi; deney raporu (kapama süresi)", "Komut ile kontakların kapanması arasında faz dönmeyi sürdürür", "öne alma açısı = 360 · Δf · t kesici"),
        G("Jeneratörün izin verdiği senkronlama sınırları", "ΔU, Δf, Δφ", "Jeneratör / tahrik makinesi üreticisi", "Hatalı senkronlama mil ve sargı üzerinde darbe yapar", "gerilim, frekans ve faz açısı farkı ayarları"),
        G("İki tarafın gerilim trafoları ve hangi gerilimlerin karşılaştırıldığı", "U12 ile U12y (aynı faz arası gerilim)", "Tek hat şeması; röle gerilim ölçme modu (…/LLy, …/LNy)", "İki tarafın aynı gerilimi ölçmesi gerekir; trafo üzerinden senkronlamada faz kayması hesaba katılır", "gerilim ölçme modu"),
        G("Ölü baraya kapama gerekip gerekmediği", "DD / DL / LD", "İşletme senaryosu (ada işletmesi, kara başlatma)", "Bir taraf enerjisizken senkron aranmaz; hangi birleşimlere izin verileceği seçilir", "gerilim denetim modu"),
        G("Otomatik senkronlayıcı / regülatörün ayar hızı", f"Δf ≈ {fnum(df, 2)} Hz", "Jeneratör kumanda panosu", "Kayma küçüldükçe koşul daha seyrek oluşur; zaman aşımı buna göre seçilir", "istek zaman aşımı ≥ 1 / Δf"),
    ]
    adimlar = [
        A("Faz farkının dönme hızı", "dφ/dt = 360° · Δf", f"360 × {fnum(df, 2)}", f"{fnum(hiz, 0)}°/s", "iki frekans arasındaki kayma", "hesap"),
        A("Kesici süresindeki dönme (öne alma)", "Δφ = 360° · Δf · t kesici", f"{fnum(hiz, 0)} × {fnum(tcb, 2)}", f"{fnum(hiz * tcb, 1)}°", P3U + " böl. 5.7 («Sync» modunda komut bu kadar öne alınır)", "resmi", ["Kesicinin kapama süresi"], "Kesici kapama süresi"),
        A("Koşulun yinelenme süresi", "T = 1 / Δf", f"1 / {fnum(df, 2)}", f"{fnum(1 / df, 1)} s" if df > 1e-6 else "∞", P3U + " böl. 5.7", "resmi", ["Otomatik senkronlayıcı / regülatörün ayar hızı"], "İstek zaman aşımı"),
        A("Kontaklar arası gerilim", "ΔU = 2 · U · sin(Δφ / 2)", f"Δφ = {fnum(abs(fi_kapama), 1)}°" if kapadi else "—", f"%{fnum(du_kontak, 0)} Un" if kapadi else "—", "iki fazörün farkı", "hesap"),
    ]
    ayarlar = [
        S("Senkron kontrol modu (SMODE)", MOD[mod].split(" —")[0], "Off / Async / Sync", "Sync: sıfır faz farkına hedefler; Async: sınırın içine girince kapatır; Off: frekans ve faz ölçütü yok", P3U + " Çizelge 49"),
        S("Gerilim denetim modu (VMODE)", "DL / LD izinli" if p.get("vmode") == "dl" else "yalnız canlı–canlı", "DD, DL, LD ve birleşimleri", "İlk harf referans gerilim, ikincisi karşılaştırılan gerilim; D: ölü, L: canlı", P3U + " Çizelge 49"),
        S("Kesici kapama süresi", f"{fnum(tcb, 2)} s", "0,04 … 0,6 s", "Kapama komutunun öne alınacağı süre", P3U + " Çizelge 49"),
        S("Vdead · Vlive sınırı", "%20 · %80 Un (örnek)", "%10 … %120 Un", "Bunun altı «ölü», üstü «canlı» sayılır", P3U + " Çizelge 49"),
        S("Frekans farkı", f"{fnum(df_max, 2)} Hz", "0,01 … 1,00 Hz", "İzin verilen en büyük kayma", P3U + " Çizelge 49"),
        S("Gerilim farkı", f"%{fnum(du_max, 0)} Un", "%1 … %60 Un", "İzin verilen en büyük genlik farkı", P3U + " Çizelge 49"),
        S("Faz açısı farkı", f"{fnum(fi_max, 0)}°", "2° … 90°", "İzin verilen en büyük faz farkı", P3U + " Çizelge 49"),
        S("İstek zaman aşımı", f"{fnum(tout, 1)} s", "0,1 … 600 s", "Bu sürede koşul oluşmazsa 200 ms'lik «fail» darbesi", P3U + " Çizelge 49"),
    ]
    test = [
        T("Gerilim farkı", f"İki tarafa aynı frekans ve faz; bir tarafın gerilimini %{fnum(du_max + 2, 0)} fark olacak biçimde değiştirin", "Kapama izni yok; fark sınırın içine girince izin", "±%3 Un"),
        T("Frekans farkı", f"Bir tarafı {fnum(50 + df_max + 0.05, 2)} Hz yapın", "İzin yok; fark sınırın içine girince izin", "±20 mHz"),
        T("Faz açısı farkı", f"Aynı frekansta bir tarafı {fnum(fi_max + 5, 0)}° kaydırın", "İzin yok", "±2° (Δf < 0,2 Hz)"),
        T("Öne alma (Sync)", f"Δf = 0,10 Hz kayma verin; kapama komutunun verildiği andaki faz farkını ölçün", f"Komut sıfırdan {fnum(36 * tcb, 1)}° önce (36°/s × {fnum(tcb, 2)} s) gelir", "—"),
        T("Zaman aşımı", "Koşulun hiç oluşmayacağı fark verin", f"{fnum(tout, 1)} s sonra «Sync fail» darbesi (200 ms)", "±%1 ya da ±30 ms"),
        T("Ölü bara", "Bir tarafın gerilimini kesin", "Gerilim modu izin veriyorsa hemen kapama; vermiyorsa izin yok", "—"),
    ]
    fs = [x * 2 for x in range(0, 91)]
    g = {"baslik": "Kapama anındaki faz farkına göre kontaklar arası gerilim", "x_ad": "Faz farkı (°)", "y_ad": "Kontaklar arası gerilim (% Un)", "ymin": 0,
         "seriler": [{"ad": "ΔU = 2·sin(Δφ/2)", "renk": "#dc2626", "pts": [[x, round(2 * math.sin(math.radians(x) / 2) * 100, 1)] for x in fs]}],
         "isaretler": [{"x": fi_max, "etiket": f"ayar {fnum(fi_max, 0)}°"}] + ([{"x": abs(fi_kapama), "etiket": "kontak anı"}] if kapadi and abs(fi_kapama) > 0.5 else [])}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["_25_", "senkron"],
        "sahne": c.sahne(fazor=fazor), "grafikler": [g],
        "anlatim": [
            "Röle kesicinin iki yanındaki gerilimi ölçer ve üç farkı izler: genlik, frekans, faz açısı.",
            f"Frekanslar farklıysa iki gerilim fazörü birbirine göre döner: her saniyede 360° × Δf. Şu an {fnum(hiz, 0)}°/s. Faz farkı her {fnum(1 / df, 1) if df > 1e-6 else '∞'} s'de bir sıfırdan geçer.",
            "Kapama komutu verildikten sonra kontaklar kesicinin kapama süresi kadar sonra kapanır; bu arada fazör dönmeyi sürdürür. «Sync» modunda röle komutu bu kadar öne alır ve kontaklar tam sıfır faz farkında birleşir.",
            "Kontaklar faz farkı varken kapanırsa aralarındaki gerilim 2·sin(Δφ/2) kadardır: 60°'de anma geriliminin tamamı, 180°'de iki katı. Bu gerilim iki sistemin toplam reaktansı üzerinden bir darbe akımı akıtır.",
            "Bir taraf enerjisizse senkron aranmaz; röle «ölü / canlı» birleşimlerinden hangilerine izin verildiğine bakar.",
            "Koşul istek zaman aşımı içinde oluşmazsa röle kapamaz ve «fail» işareti verir. Kayma çok küçükse koşul seyrek oluşur: zaman aşımı buna göre uzun tutulur.",
        ],
        "dersler": [
            "Üç fark: gerilim, frekans, faz. Ayrı kaynaklarda üçü de denetlenmeli.",
            "Kesici kapama süresini doğru girin: 0,2 Hz kaymada 60 ms'lik kesici 4° döndürür.",
            "İstek zaman aşımı ≥ 1 / Δf olmalı; 0,05 Hz kaymada koşul 20 s'de bir oluşur.",
            "Tekrar kapamalı fiderde üretim tesisi varsa kapama, «DI to block AR» üzerinden senkron kontrolle koşullanır.",
        ],
        "tablolar": [{"baslik": "Frekans farkına göre", "cols": ["Δf", "Dönme hızı", "Koşulun yinelenmesi", f"Kesici süresinde ({fnum(tcb * 1000, 0)} ms) dönme"], "rows": [
            [f"{fnum(x, 2)} Hz", f"{fnum(360 * x, 0)}°/s", f"{fnum(1 / x, 1)} s", f"{fnum(360 * x * tcb, 1)}°"] for x in (0.02, 0.05, 0.1, 0.2, 0.5, 1.0)]}],
    }
