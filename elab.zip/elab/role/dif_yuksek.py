"""Yüksek empedanslı diferansiyel (sınırlı toprak arızası 64REF / bara): doyan akım trafosuna karşı kararlılık direnci, diz gerilimi ve gerilim sınırlayıcı.

Dayanak: GE MiCOM P14D teknik kılavuzu (P14DEd2-TM-EN-11.2) Bölüm 7 «Restricted Earth Fault Protection» — böl. 2.4.2 (ilke: dış arızada bir akım trafosu
tümüyle doymuş sayılır; röle kolundaki gerilim Vs = IF·(RCT + 2·RL); kararlılık direnci RST = Vs/Is − RR), böl. 4.3.2 (çözümlü örnek: Vs = K·IF·(RCT + 2RL),
VK/VS = 4 önerisi, birincil çalışma akımı IP = N·(Is + n·Ie) sargı anma akımının %10–60'ı), Bölüm 9 böl. 2.8 (iç arızada tepe gerilim Vp = 2·√(2·VK·(VF − VK)),
VF = I'f·(RCT + 2RL + RST); 3000 V'u aşarsa doğrusal olmayan direnç — Metrosil). Easergy P3: kararlılık direnci ve gerilim sınırlayıcı dışarıdan Io girişine
bağlanır, hesap ayrı uygulama notundadır (P3U/en M/J006 böl. 5.28). Mıknatıslanma akımının diz altında gerilimle doğrusal değiştiği kabul edilmiştir (tahmini)."""
from __future__ import annotations

import math

from .ortak import A, C, Cizim, G, K, P3U, S, S3, T, ctl, fa, fnum, num, opt
from .roleler import P14D

ID = "dif_yuksek"
BASLIK = "Yüksek empedanslı diferansiyel"
IKON = "🧱"
GIRIS = ("Yüksek empedanslı diferansiyelde akım trafoları paralel bağlanır ve röle bu bağlantıya büyük bir dirençle seri girer. Dış arızada bir akım trafosu doysa bile "
         "dengesizlik akımı röleye değil, doymuş trafonun sargısına akar. Bu sayfada kararlılık direncinin, diz geriliminin ve gerilim sınırlayıcının nereden "
         "çıktığını görürsünüz.")
P14 = P14D + " Bölüm 7"
RR = 0.02            # Ω — röle kolunun kendi yükü (ihmal edilecek kadar küçük)

KONTROLLER = [
    ctl("durum", "Gösterilen durum", "sec", "dis", secenek=opt(("dis", "Dış arıza: bir akım trafosu tümüyle doymuş"), ("ic", "İç arıza (korunan bölgede)"))),
    ctl("sn", "Trafo gücü", "sayi", 2000, min=250, max=100000, adim=50, birim="kVA"),
    ctl("u", "Korunan sargının gerilimi", "sec", 0.4, secenek=opt((0.4, "0,4 kV"), (6.3, "6,3 kV"), (10.5, "10,5 kV"), (34.5, "34,5 kV"), (132, "132 kV"))),
    ctl("uk", "Trafo uk", "sayi", 6, min=3, max=15, adim=0.5, birim="%"),
    ctl("ct_p", "Akım trafosu primeri", "sayi", 3000, min=50, max=6000, adim=50, birim="A"),
    ctl("ct_s", "Akım trafosu sekonderi", "sec", 1, secenek=opt((1, "1 A"), (5, "5 A"))),
    ctl("rct", "Akım trafosu sargı direnci RCT", "sayi", 8.0, min=0.1, max=20, adim=0.1, birim="Ω"),
    ctl("l_m", "AT–röle kablosu (tek yön)", "sayi", 25, min=1, max=300, adim=1, birim="m"),
    ctl("kesit", "Kablo kesiti", "sec", 2.5, secenek=opt((2.5, "2,5 mm²"), (4, "4 mm²"), (6, "6 mm²"))),
    ctl("vk", "Akım trafosunun diz gerilimi VK", "sayi", 900, min=20, max=3000, adim=10, birim="V"),
    ctl("ie", "Diz noktasında mıknatıslanma akımı", "sayi", 30, min=5, max=300, adim=5, birim="mA"),
    ctl("n_at", "Paralel bağlı akım trafosu sayısı", "sec", 4, secenek=opt((2, "2"), (3, "3"), (4, "4 (üç faz + nötr)"), (6, "6"), (8, "8"))),
    ctl("is", "Röle ayarı Is (sekonder)", "sayi", 0.10, min=0.02, max=1.0, adim=0.01, birim="A"),
    ctl("kf", "Kararlılık katsayısı K", "sayi", 1.0, min=0.5, max=1.0, adim=0.05, yardim="Kılavuz X/R ve arıza akımına göre 0,5–1 arası bir eğri verir; 1,0 en güvenli yandır"),
    ctl("rst", "Seçilen kararlılık direnci (0: hesaplanan)", "sayi", 0, min=0, max=5000, adim=10, birim="Ω"),
]


def hesap(p: dict) -> dict:
    sn, u, uk = num(p, "sn", 2000), num(p, "u", 0.4), num(p, "uk", 6) / 100
    n = num(p, "ct_p", 3000) / num(p, "ct_s", 1)
    rct = num(p, "rct", 8.0); rl = num(p, "l_m", 25) / (56 * num(p, "kesit", 2.5))
    iflc = sn / (S3 * u); i_f = iflc / uk; i_fs = i_f / n
    rsat = rct + 2 * rl
    vs = num(p, "kf", 1.0) * i_fs * rsat
    is_ = num(p, "is", 0.10)
    rst_g = max(vs / is_ - RR, 0.0)
    rst = num(p, "rst", 0) or math.ceil(rst_g / 10) * 10
    vset = is_ * (rst + RR)
    i_rel = i_fs * rsat / (rsat + rst + RR)                                 # dış arıza: dengesizlik akımı doymuş AT kolu ile röle kolu arasında bölünür
    vk = num(p, "vk", 900); ie_k = num(p, "ie", 30) / 1000
    ie = ie_k * min(vset / vk, 1.0) if vset <= vk else ie_k * (vset / vk) ** 8
    ip = n * (is_ + num(p, "n_at", 4) * ie)
    vf = i_fs * (rsat + rst)
    vp = 2 * math.sqrt(2 * vk * (vf - vk)) if vf > vk else D2 * vf
    return {"iflc": iflc, "i_f": i_f, "i_fs": i_fs, "n": n, "rl": rl, "rsat": rsat, "vs": vs, "rst_g": rst_g, "rst": rst, "vset": vset, "i_rel": i_rel, "vk": vk, "ie": ie, "ip": ip, "vf": vf, "vp": vp, "is": is_}


D2 = math.sqrt(2)


def run(p: dict) -> dict:
    h = hesap(p)
    dis = p.get("durum") != "ic"
    kararli = h["i_rel"] < h["is"]
    vk_ok = h["vk"] >= 4 * h["vs"]
    ip_pct = h["ip"] / h["iflc"] * 100
    metrosil = h["vp"] > 3000
    ic_acar = h["i_f"] >= h["ip"] and h["vk"] >= 2 * h["vset"]

    c = Cizim(900, 320)
    # sol: sağlam AT, sağ: doymuş AT; ortada röle kolu
    c.toroid(110, 90, 9, 22); c.yazi(110, 58, "sağlam akım trafosu", "#475569", 10, anchor="middle")
    c.toroid(790, 90, 9, 22); c.yazi(790, 58, "doymuş akım trafosu" if dis else "akım trafosu", "#b91c1c" if dis else "#475569", 10, anchor="middle")
    c.hat("M110,112 V150 H200", "L1", hot=True, w=2.2); c.direnc(200, 150, "", False, True, 34); c.yazi(217, 140, "RCT", "#64748b", 9.5, anchor="middle")
    c.hat("M234,150 H300", "L1", hot=True, w=2.2); c.direnc(300, 150, "", False, True, 34); c.yazi(317, 140, "2·RL", "#64748b", 9.5, anchor="middle")
    c.hat("M334,150 H450", "L1", hot=True, w=2.2)
    c.hat("M450,150 H566", "L1", hot=dis, w=2.2, hot_renk="uyari"); c.direnc(566, 150, "", dis, True, 34); c.yazi(583, 140, "2·RL", "#64748b", 9.5, anchor="middle")
    c.hat("M600,150 H666", "L1", hot=dis, w=2.2, hot_renk="uyari"); c.direnc(666, 150, "", dis, True, 34); c.yazi(683, 140, "RCT", "#64748b", 9.5, anchor="middle")
    c.hat("M700,150 H790 V112", "L1", hot=dis, w=2.2, hot_renk="uyari")
    c.hat("M110,68 V40 H790 V68", "cizgi", w=1.6)
    # röle kolu
    rel_hot = (not kararli) if dis else True
    c.hat("M450,150 V176", "ariza", hot=rel_hot, w=2); c.direnc(450, 176, f"RST = {fnum(h['rst'], 0)} Ω", rel_hot, False, 40)
    c.hat("M450,216 V232", "ariza", hot=rel_hot, w=2); c.kutu(400, 232, 100, 40, "64 (REF)", ("AÇAR" if not kararli else "kararlı") if dis else ("AÇAR" if ic_acar else "açmaz"), ("gecersiz" if not kararli else "normal") if dis else ("acti" if ic_acar else "normal"))
    c.hat("M450,272 V290 H870 V40 H790", "cizgi", w=1.6)
    c.hat("M450,160 H540 V190", "cizgi", w=1.4, kesik=True); c.dikdortgen(526, 190, 28, 44, "mor", "#f5f3ff"); c.yazi(540, 250, "gerilim sınırlayıcı", "#6d28d9", 9.5, anchor="middle")
    c.hat("M540,234 V280 H450", "cizgi", w=1.4, kesik=True)
    c.yazi(20, 200, f"Dış arıza akımı {fnum(h['i_f'] / 1000, 1)} kA → sekonderde {fnum(h['i_fs'], 1)} A", "#334155", 11.5)
    c.yazi(20, 220, f"Doymuş kolda gerilim Vs = {fnum(h['vs'], 1)} V", "#1a4d8f", 12, kalin=True)
    c.yazi(20, 240, f"Röleden geçen {fnum(h['i_rel'], 3)} A (ayar {fnum(h['is'], 2)} A)", "#15803d" if kararli else "#b91c1c", 12, kalin=True)
    c.yazi(20, 262, f"Birincil çalışma akımı {fa(h['ip'])} = %{fnum(ip_pct, 0)} In", "#334155", 11.5)
    c.yazi(600, 220, f"Diz gerilimi {fnum(h['vk'], 0)} V; gereken ≥ {fnum(4 * h['vs'], 0)} V", "#15803d" if vk_ok else "#b91c1c", 11.5)
    c.yazi(600, 240, f"İç arızada tepe gerilim {fnum(h['vp'] / 1000, 1)} kV", "#b91c1c" if metrosil else "#334155", 11.5)
    c.yazi(600, 260, "→ gerilim sınırlayıcı gerekli" if metrosil else "→ sınırlayıcı gerekmez (< 3 kV)", "#6d28d9" if metrosil else "#64748b", 11)

    ozet = [
        K("Kararlılık gerilimi Vs", f"{fnum(h['vs'], 1)} V", "info", f"dış arıza {fnum(h['i_fs'], 1)} A × ({fnum(num(p, 'rct', 8), 1)} + 2 × {fnum(h['rl'], 2)}) Ω"),
        K("Kararlılık direnci", f"{fnum(h['rst'], 0)} Ω", "ok" if kararli else "bad", f"gereken ≥ {fnum(h['rst_g'], 0)} Ω (Vs / Is)"),
        K("Dış arızada röle akımı", f"{fnum(h['i_rel'], 3)} A", "ok" if kararli else "bad", f"ayar {fnum(h['is'], 2)} A · " + ("kararlı" if kararli else "AÇAR (yanlış)")),
        K("Diz gerilimi", f"{fnum(h['vk'], 0)} V", "ok" if vk_ok else "bad", f"gereken ≥ 4 × Vs = {fnum(4 * h['vs'], 0)} V"),
        K("Birincil çalışma akımı", fa(h["ip"]), "ok" if 10 <= ip_pct <= 60 else "warn", f"sargı anma akımının %{fnum(ip_pct, 0)}'i (öneri %10–60)"),
    ]
    kontroller = [
        C("Dış arızada kararlı mı?", f"röle kolundan {fnum(h['i_rel'], 3)} A", f"< Is = {fnum(h['is'], 2)} A", kararli,
          "Bir akım trafosu tümüyle doymuş sayılır; dengesizlik akımının çoğu onun sargı ve kablo direncinden akar, röle kolundaki direnç bunu sağlar: RST = Vs/Is − RR — " + P14 + " böl. 2.4.2", "resmi"),
        C("Akım trafosunun diz gerilimi yeterli mi?", f"VK = {fnum(h['vk'], 0)} V", f"≥ 4 × Vs = {fnum(4 * h['vs'], 0)} V", vk_ok,
          "İç arızada röleyi çalıştıracak gerilimi akım trafosu üretir; ortalama 40 ms'lik açma süresi için VK/VS = 4 önerilir — " + P14 + " böl. 4.3.2", "resmi"),
        C("Duyarlılık uygun aralıkta mı?", f"IP = N·(Is + n·Ie) = {fa(h['ip'])} = %{fnum(ip_pct, 0)} In", "sargı anma akımının %10–60'ı", 10 <= ip_pct <= 60,
          "Paralel bağlı her akım trafosunun mıknatıslanma akımı röle akımına eklenir: trafo sayısı arttıkça duyarlılık düşer — " + P14 + " böl. 4.3.2", "resmi"),
        C("İç arızada sekonder devre gerilimi", f"Vp = 2·√(2·VK·(VF − VK)) = {fnum(h['vp'] / 1000, 1)} kV (VF = {fnum(h['vf'] / 1000, 1)} kV)", "3 kV'u aşarsa doğrusal olmayan direnç bağlanır", None,
          "Yüksek empedanslı devrede iç arıza akım trafolarını doyuruncaya kadar gerilimi yükseltir; sekonder devrenin dayanımı genellikle 3 kV'tur — " + P14D + " Bölüm 9 böl. 2.8", "resmi"),
    ]
    girdiler = [
        G("En büyük dış (geçiş) arıza akımı", f"{fnum(h['i_f'] / 1000, 1)} kA", "Kısa devre hesabı; yoksa In / uk (şebeke empedansı sayılmaz, güvenli yan)", "Kararlılık bu akımda sınanır", "Vs = K·IF·(RCT + 2RL)"),
        G("Akım trafosu: oran, RCT, diz gerilimi, mıknatıslanma akımı", f"{num(p, 'ct_p', 3000):g}/{num(p, 'ct_s', 1):g} A · {fnum(num(p, 'rct', 8), 1)} Ω · {fnum(h['vk'], 0)} V · {fnum(num(p, 'ie', 30), 0)} mA", "AT test raporu (PX sınıfı); mıknatıslanma eğrisi", "Bütün akım trafoları aynı oran ve benzer eğride olmalı; diz gerilimi ve mıknatıslanma akımı hesabın girdisidir", "VK ≥ 4·Vs ; IP"),
        G("Kablo boyu ve kesiti", f"{fnum(num(p, 'l_m', 25), 0)} m · {num(p, 'kesit', 2.5):g} mm² → RL = {fnum(h['rl'], 2)} Ω", "Kablo listesi; ölçülerek doğrulanır", "Doymuş kolun direncine girer: uzun kablo kararlılık gerilimini büyütür", "RCT + 2·RL"),
        G("Paralel akım trafosu sayısı", f"{num(p, 'n_at', 4):g}", "Tek hat ve bağlantı şeması", "Her biri mıknatıslanma akımı çeker", "n·Ie"),
    ]
    adimlar = [
        A("Sargı anma akımı ve dış arıza akımı", "In = Sn/(√3·U) ;  IF = In / uk", f"{fnum(h['iflc'], 0)} A / {fnum(num(p, 'uk', 6) / 100, 3)}", f"{fnum(h['i_f'] / 1000, 1)} kA → sekonder {fnum(h['i_fs'], 1)} A", P14 + " böl. 4.3.2.1", "resmi", ["En büyük dış (geçiş) arıza akımı"]),
        A("Kararlılık gerilimi", "Vs = K·IF·(RCT + 2·RL)", f"{fnum(num(p, 'kf', 1), 2)} × {fnum(h['i_fs'], 1)} × ({fnum(num(p, 'rct', 8), 1)} + 2×{fnum(h['rl'], 2)})", f"{fnum(h['vs'], 1)} V", P14 + " böl. 4.3.2.1", "resmi", ["Akım trafosu: oran, RCT, diz gerilimi, mıknatıslanma akımı", "Kablo boyu ve kesiti"]),
        A("Kararlılık direnci", "RST = Vs / Is − RR", f"{fnum(h['vs'], 1)} / {fnum(h['is'], 2)}", f"≥ {fnum(h['rst_g'], 0)} Ω → seçilen {fnum(h['rst'], 0)} Ω", P14 + " böl. 4.3.2.3", "resmi", [], "kararlılık direnci"),
        A("Gereken diz gerilimi", "VK ≥ 4·Vs", f"4 × {fnum(h['vs'], 1)}", f"{fnum(4 * h['vs'], 0)} V", P14 + " böl. 4.3.2.1", "resmi"),
        A("Birincil çalışma akımı", "IP = N·(Is + n·Ie)", f"{fnum(h['n'], 0)} × ({fnum(h['is'], 2)} + {num(p, 'n_at', 4):g} × {fnum(h['ie'], 4)})", f"{fa(h['ip'])} = %{fnum(ip_pct, 0)} In", P14 + " böl. 4.3.2.4", "resmi", ["Paralel akım trafosu sayısı"], "Is"),
        A("İç arızada tepe gerilim", "Vp = 2·√(2·VK·(VF − VK)) ;  VF = I'f·(RCT + 2RL + RST)", f"VF = {fnum(h['i_fs'], 1)} × {fnum(h['rsat'] + h['rst'], 0)}", f"{fnum(h['vp'] / 1000, 1)} kV", P14D + " Bölüm 9 böl. 2.8", "resmi", [], "gerilim sınırlayıcı"),
    ]
    ayarlar = [
        S("Röle ayarı Is", f"{fnum(h['is'], 2)} A sekonder", "—", "Birincil çalışma akımı sargı anma akımının %10–60'ı olacak biçimde", P14 + " böl. 4.3.2.2"),
        S("Kararlılık direnci (dış donanım)", f"{fnum(h['rst'], 0)} Ω", "—", "Röle içinde değildir: panoya ayrı takılır, gücü kısa süreli gerilime göre seçilir", P14 + " böl. 2.4.2"),
        S("Gerilim sınırlayıcı (Metrosil / varistör)", "gerekli" if metrosil else "gerekmez", "—", "Tepe gerilim 3 kV'u aşıyorsa röle koluna paralel bağlanır", P14D + " Bölüm 9 böl. 2.8"),
        S("Easergy P3 › 64REF yüksek empedanslı", "direnç ve varistör Io girişine dışarıdan", "—", "Hesap ayrı uygulama notundadır (P3APS17016EN)", P3U + " böl. 5.28"),
    ]
    test = [
        T("Kararlılık (primer)", "Bir faz ve nötr akım trafosundan aynı akım geçirilir (dış arıza benzetimi)", "Röle kolunda akım ≈ 0; röle açmaz", "akım trafolarından biri ters bağlıysa röle açar"),
        T("Duyarlılık (primer)", "Yalnız bir akım trafosundan akım artırılır", f"Açma ≈ {fa(h['ip'])} dolayında", "IP = N·(Is + n·Ie)"),
        T("Sekonder gerilimle", "Röle koluna gerilim uygulanır", f"Açma {fnum(h['vset'], 0)} V dolayında (Is × RST)", "akım trafoları bağlıyken mıknatıslanma akımı eklenir"),
    ]
    dirler = [10, 20, 50, 100, 200, 500, 1000, 2000, 5000]
    g = {"baslik": "Dış arızada röle kolundan geçen akım, kararlılık direncine göre", "x_ad": "Kararlılık direnci RST (Ω)", "y_ad": "Röle akımı (A)", "logx": True, "logy": True,
         "seriler": [{"ad": "röle akımı", "renk": "#dc2626", "pts": [[r, round(h["i_fs"] * h["rsat"] / (h["rsat"] + r + RR), 4)] for r in dirler]}],
         "yatay": [{"y": h["is"], "etiket": f"Is = {fnum(h['is'], 2)} A", "renk": "#15803d"}], "isaretler": [{"x": h["rst"], "etiket": "seçilen"}]}
    ornek = hesap({"sn": 90000, "u": 132, "uk": 5, "ct_p": 400, "ct_s": 1, "rct": 0.5, "l_m": 0.98 * 56 * 2.5, "kesit": 2.5, "vk": 182, "ie": 50, "n_at": 4, "is": 0.1, "kf": 0.9})
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["64ref"], "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Korunan bölgenin bütün akım trafoları paralel bağlanır. Sağlam durumda ve dış arızada giren akım çıkan akıma eşittir: sekonder akımlar akım trafolarının arasında dolaşır, röle koluna bir şey kalmaz.",
            "Sorun dış arızada bir akım trafosunun doymasıdır. Doymuş akım trafosu akım üretemez; sekonder sargısı yalnız bir direnç gibi kalır. Sağlam trafonun bastığı akım iki yoldan birine gider: doymuş trafonun sargısı ya da röle kolu.",
            f"Röle koluna büyük bir direnç konursa akım kolay yolu seçer: doymuş trafonun {fnum(h['rsat'], 1)} Ω'luk sargı ve kablo direncini. O yolda düşen gerilim Vs = {fnum(h['vs'], 1)} V'tur; röle kolundaki akım bu gerilimin dirence bölümüdür.",
            "İç arızada durum tersine döner: bütün akım trafoları aynı yöne akım basar ve bu akımın gideceği tek yer yüksek dirençli röle koludur. Gerilim hızla yükselir, röle açar. Bu gerilimi üretebilmek için akım trafolarının diz gerilimi yeterince yüksek olmalıdır.",
            "Yükselen gerilim sekonder devrenin yalıtımını zorlar. Hesaplanan tepe 3 kV'u aşıyorsa röle koluna paralel, gerilimle direnci düşen bir eleman bağlanır.",
            "Her paralel akım trafosu, ayar geriliminde bir miktar mıknatıslanma akımı çeker. Bu akım röleden çalınır: bara diferansiyeli gibi çok trafolu düzenlerde duyarlılık buna göre hesaplanır.",
        ],
        "dersler": [
            "Yüksek empedanslı koruma akım trafosu doymasını yok saymaz; doymayı en kötü biçimiyle kabul edip direnci ona göre seçer.",
            "Bütün akım trafoları aynı oranda ve PX sınıfında olmalı: diz gerilimi, sargı direnci ve mıknatıslanma akımı hesabın girdisidir.",
            "Kararlılık direnci ve gerilim sınırlayıcı röleye değil panoya aittir; devreye almada ölçülmeden geçilmez.",
            "Bir akım trafosu ters bağlıysa sağlam durumda bile röle koluna akım gider: kararlılık primer enjeksiyonla doğrulanır.",
        ],
        "tablolar": [{"baslik": "Kılavuzdaki çözümlü örnekle karşılaştırma (90 MVA, 33/132 kV, uk %5, 400/1 A, RCT 0,5 Ω, RL 0,98 Ω, K = 0,9, Is = 0,1 A)", "cols": ["Büyüklük", "Bu sayfanın hesabı", "Kılavuzdaki değer"], "rows": [
            ["Sargı anma akımı", fa(ornek["iflc"]), "394 A"], ["Dış arıza akımı", fa(ornek["i_f"]), "7.873 A"], ["Kararlılık gerilimi Vs", f"{fnum(ornek['vs'], 1)} V", "45,5 V"],
            ["Kararlılık direnci", f"{fnum(ornek['rst_g'], 0)} Ω", "455 Ω"], ["Gereken diz gerilimi (4·Vs)", f"{fnum(4 * ornek['vs'], 0)} V", "182 V"]],
            "not": P14 + " böl. 4.3.2. Kılavuz Vs için 45,5 V yazar; verdiği sayılarla çarpım (0,9 × 7.873 × 2,46 / 400) 43,6 V eder. Aradaki %4'lük fark kılavuzun kendi yuvarlamasından gelir; bağıntılar aynıdır."}],
    }
