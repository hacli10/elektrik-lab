"""Termik aşırı yük koruması (ANSI 49 / 49T) — Easergy P3 «T>» kademesi.

Dayanak: P3U/en M/J006 böl. 5.16 (ısıl model IEC 60255-149'a göre, 15. harmoniğe kadar etkin değer; açma süresi t = τ·ln[(I² − Ip²)/(I² − a²)],
a = k·kΘ·I_MODE; alarm a = k·kΘ·I_MODE·√alarm; soğuma I < 0,3·In iken Cτ katsayısıyla; ortam sıcaklığı düzeltmesi IMAX40 ve IMAX70 ile, Şekil 79;
örnek: τ = 30 dk, k = 1,06), Çizelge 60 (aralıklar; süre doğruluğu ±%5 ya da 1 s). Ortam düzeltme eğrisinin 40 °C altı ve 70 °C üstü burada sabit
alınmıştır — «dogrulanacak». Trafonun zaman sabiti ve aşırı yüklenebilirliği üretici verisidir."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, P3T, P3U, S, S3, T, ctl, fa, fnum, num, opt, tek_hat

ID = "termik"
BASLIK = "Termik aşırı yük (49T)"
IKON = "🌡"
GIRIS = ("Aşırı akım rölesi akımın o anki değerine bakar; termik koruma geçmişini de hesaba katar. Röle akımın karesinden bir sıcaklık hesaplar: "
         "yük artınca yavaşça ısınan, azalınca yavaşça soğuyan bir model. Ayarları trafonun ne kadar akıma sürekli dayandığı ve ne kadar çabuk ısındığıdır.")

KONTROLLER = [
    ctl("s_kva", "Trafo gücü", "sayi", 2000, min=100, max=40000, adim=50, birim="kVA"),
    ctl("un_kv", "Rölenin bağlı olduğu tarafın gerilimi", "sec", 34.5, secenek=opt((0.4, "0,4 kV"), (6.3, "6,3 kV"), (10.5, "10,5 kV"), (34.5, "34,5 kV"))),
    ctl("ct_p", "Akım trafosu primeri", "sayi", 50, min=5, max=6000, adim=5, birim="A"),
    ctl("taban", "Rölede «×In»in anlamı", "sec", "nesne", secenek=opt(("nesne", "Trafonun anma akımı (trafo / motor modu)"), ("at", "AT primeri (fider modu)")), yardim="Ölçekleme sayfasında korunan nesnenin anma akımı girildiyse «trafo modu»"),
    ctl("k", "Röle › Max sürekli akım", "sayi", 1.06, min=0.10, max=2.40, adim=0.01, birim="×In"),
    ctl("tau", "Röle › Zaman sabiti tau", "sayi", 60, min=2, max=180, adim=1, birim="dk"),
    ctl("ctau", "Röle › Soğuma zaman sabiti", "sayi", 1.0, min=1.0, max=10.0, adim=0.1, birim="× tau"),
    ctl("alarm", "Röle › Alarm", "sayi", 90, min=60, max=99, adim=1, birim="%"),
    ctl("imax40", "Röle › +40 °C'de max aşırı yük", "sayi", 100, min=70, max=120, adim=1, birim="%In"),
    ctl("imax70", "Röle › +70 °C'de max aşırı yük", "sayi", 78, min=50, max=100, adim=1, birim="%In"),
    ctl("ortam", "Röle › Ortam sıcaklığı", "sayi", 40, min=-20, max=80, adim=1, birim="°C"),
    ctl("i_once", "Benzetim: önceki yük", "sayi", 80, min=0, max=120, adim=5, birim="% In(trafo)"),
    ctl("i_yuk", "Benzetim: aşırı yük", "sayi", 130, min=50, max=400, adim=5, birim="% In(trafo)"),
]


def k_ortam(p: dict) -> float:
    """Ortam sıcaklığı düzeltme katsayısı kΘ (Şekil 79): 40 °C'de IMAX40, 70 °C'de IMAX70; arası doğrusal."""
    t = num(p, "ortam", 40); a, b = num(p, "imax40", 100) / 100, num(p, "imax70", 78) / 100
    return a if t <= 40 else b if t >= 70 else a + (b - a) * (t - 40) / 30


def run(p: dict) -> dict:
    i_tr = num(p, "s_kva", 2000) / (S3 * num(p, "un_kv", 34.5)); ct_p = num(p, "ct_p", 50)
    i_mod = i_tr if p.get("taban") != "at" else ct_p
    kt = k_ortam(p); k = num(p, "k", 1.06); tau = num(p, "tau", 60); ct = num(p, "ctau", 1.0); al = num(p, "alarm", 90) / 100
    a = k * kt * i_mod                                          # %100 sıcaklığa karşılık gelen akım (A)
    ip, i = num(p, "i_once", 80) / 100 * i_tr, num(p, "i_yuk", 130) / 100 * i_tr
    th0, th_s = (ip / a) ** 2, (i / a) ** 2
    t_acma = tau * math.log((i * i - ip * ip) / (i * i - a * a)) if i > a and ip < a else (0.0 if ip >= a else math.inf)
    t_alarm = tau * math.log((i * i - ip * ip) / (i * i - al * a * a)) if i * i > al * a * a and th0 < al else (0.0 if th0 >= al else math.inf)
    t_soguk = tau * math.log(i * i / (i * i - a * a)) if i > a else math.inf
    o_k = 1.06 * (1.0 if p.get("taban") != "at" else i_tr / ct_p)
    acar = t_acma < math.inf
    c = tek_hat(("Şebeke", ""), ("Trafo", f"{fnum(num(p, 's_kva', 2000), 0)} kVA"), ("49T  T>", ("AÇAR " + fnum(t_acma, 0) + " dk sonra") if acar else f"kararlı: %{fnum(th_s * 100, 0)}"), "acti" if acar else "normal", None, "sag", gt=False, ileri=False, at_ad=f"AT {ct_p:g}/1")
    c.yazi(500, 190, f"Açma düzeyi a = k·kΘ·In = {fnum(k, 2)} × {fnum(kt, 2)} × {fnum(i_mod, 1)} = {fa(a)}", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, f"Yük {fa(i)} → kararlı sıcaklık %{fnum(th_s * 100, 0)} · başlangıç %{fnum(th0 * 100, 0)}", "#334155", 11)
    c.yazi(500, 226, f"Alarm (%{fnum(al * 100, 0)}): " + (fnum(t_alarm, 0) + " dk" if t_alarm < math.inf else "ulaşılmaz") + " · soğuk durumdan açma: " + (fnum(t_soguk, 0) + " dk" if t_soguk < math.inf else "—"), "#334155", 11)
    ozet = [
        K("Açma", (fnum(t_acma, 0) + " dk sonra") if acar else "açmaz", "warn" if acar else "ok", f"yük %{fnum(num(p, 'i_yuk', 130), 0)} In(trafo)"),
        K("Kararlı sıcaklık", f"%{fnum(th_s * 100, 0)}", "bad" if th_s >= 1 else "warn" if th_s >= al else "ok", "(I / a)²"),
        K("Açma düzeyi akımı", fa(a), "ok" if 1.0 <= a / i_tr <= 1.15 else "bad", f"{fnum(a / i_tr, 2)} × In(trafo)"),
        K("Ortam katsayısı kΘ", fnum(kt, 2), "info", f"{fnum(num(p, 'ortam', 40), 0)} °C"),
        K("Alarm akımı", fa(a * math.sqrt(al)), "info", f"sürekli bu akımda %{fnum(al * 100, 0)}"),
    ]
    kontroller = [
        C("Açma düzeyi trafonun sürekli dayanımına uygun mu?", f"a = {fa(a)} = {fnum(a / i_tr, 2)} × In(trafo)", "1,00 … 1,15 × In(trafo)", 1.0 <= a / i_tr <= 1.15,
          "a = k · kΘ · I_MODE — " + P3U + " böl. 5.16. İzin verilen sürekli aşırı yük üretici verisidir (yağlı trafolarda %5–10 dolayı)", "ikincil"),
        C("«×In» tabanı doğru mu?", ("trafo anma akımı" if p.get("taban") != "at" else f"AT primeri {ct_p:g} A") + f" → k = {fnum(k, 2)}", f"bu taban için k ≈ {fnum(o_k, 2)}", abs(k - o_k) / o_k <= 0.1,
          "Fider rölesinde (P3U) In AT primeridir: k = 1,06 × In(trafo) / In(AT) girilmelidir — P3U böl. 5.16 (I_MODE). Trafo rölesinde (P3T32) a = k · kΘ · ITN, ITN trafonun anma akımıdır — " + P3T + " böl. 6.12", "resmi"),
        C("Anma yükünde alarm vermiyor mu?", f"anma yükünde sıcaklık %{fnum((i_tr / a) ** 2 * 100, 0)}", f"< alarm %{fnum(al * 100, 0)}", (i_tr / a) ** 2 < al, "Kararlı sıcaklık = (I / a)² — " + P3U + " böl. 5.16 (örnek: 0,85/1,06 → %64)", "resmi"),
        C("Zaman sabiti", f"{fnum(tau, 0)} dk", "2 … 180 dk; trafonun ısıl zaman sabiti (üretici)", None, P3U + " Çizelge 60. Kuru tip trafolar onlarca dakika, yağlı trafolar saat mertebesindedir (üretici verisi)", "ikincil"),
        C("Ortam sıcaklığı düzeltmesi", f"kΘ = {fnum(kt, 2)}", "IMAX40 = %100 ve ortam 40 °C ise düzeltme yok (kΘ = 1)", None, P3U + " böl. 5.16, Şekil 79", "resmi"),
    ]
    girdiler = [
        G("Trafonun anma akımı", fa(i_tr), "Etiket (S, U)", "Isıl model akımı buna (ya da AT primerine) oranlar", "a = k · kΘ · In"),
        G("İzin verilen sürekli aşırı yük", "%5–10 (üretici)", "Trafo veri föyü; yükleme kılavuzu", "k bunu ifade eder: 1,06 → anma akımının %6 üstünde açma düzeyi", "Max sürekli akım"),
        G("Isıl zaman sabiti", f"{fnum(tau, 0)} dk", "Trafo üreticisi (sargı / yağ zaman sabiti)", "Aşırı yükte ne kadar çabuk ısınacağını belirler: açma süresi doğrudan τ ile orantılıdır", "Zaman sabiti tau"),
        G("Soğutma biçimi (fan duruyorsa)", f"Cτ = {fnum(ct, 1)}", "Trafo / motor verisi", "Akım 0,3 × In'in altındayken soğuma daha yavaş olabilir", "Soğuma zaman sabiti"),
        G("Ortam sıcaklığı ve yüksek sıcaklıktaki yüklenebilirlik", f"{fnum(num(p, 'ortam', 40), 0)} °C; +70 °C'de %{fnum(num(p, 'imax70', 78), 0)}", "Tesis koşulu; üretici", "Sıcak ortamda aynı akım daha çok ısıtır: açma düzeyi düşürülür", "kΘ"),
        G("Rölede «×In»in tabanı", "trafo anma akımı" if p.get("taban") != "at" else "AT primeri", "Röle ölçekleme sayfası (korunan nesnenin anma akımı girilmiş mi)", "Aynı k iki tabanda farklı ampere karşılık gelir", "I_MODE"),
    ]
    adimlar = [
        A("Trafonun anma akımı", "In = S / (√3 · U)", f"{fnum(num(p, 's_kva', 2000), 0)} / (1,732 × {fnum(num(p, 'un_kv', 34.5), 1)})", fa(i_tr), "temel bağıntı", "resmi", ["Trafonun anma akımı"]),
        A("Max sürekli akım k", "k = 1,06 × In(trafo) / I_MODE", f"1,06 × {fnum(i_tr, 1)} / {fnum(i_mod, 1)}", f"{fnum(o_k, 2)} ×In", P3U + " böl. 5.16", "resmi", ["İzin verilen sürekli aşırı yük", "Rölede «×In»in tabanı"], "Max sürekli akım"),
        A("Ortam katsayısı", "kΘ: 40 °C'de IMAX40, 70 °C'de IMAX70, arası doğrusal", f"{fnum(num(p, 'ortam', 40), 0)} °C", fnum(kt, 2), P3U + " Şekil 79", "resmi", ["Ortam sıcaklığı ve yüksek sıcaklıktaki yüklenebilirlik"]),
        A("Açma düzeyi akımı", "a = k · kΘ · I_MODE", f"{fnum(k, 2)} × {fnum(kt, 2)} × {fnum(i_mod, 1)}", fa(a), P3U + " böl. 5.16", "resmi"),
        A("Açma süresi", "t = τ · ln[(I² − Ip²) / (I² − a²)]", f"{fnum(tau, 0)} × ln[({fnum(i, 1)}² − {fnum(ip, 1)}²) / ({fnum(i, 1)}² − {fnum(a, 1)}²)]", (fnum(t_acma, 1) + " dk") if acar else "açmaz (I ≤ a)", P3U + " böl. 5.16", "resmi", ["Isıl zaman sabiti"]),
    ]
    ayarlar = [
        S("Max sürekli akım", f"{fnum(o_k, 2)} ×In (şu an {fnum(k, 2)})", "0,10 … 2,40 ×In; ekrandaki örnek 1,06", "Sıcaklığın %100'e ulaştığı sürekli akım", P3U + " Çizelge 60"),
        S("Alarm", f"%{fnum(al * 100, 0)}", "%60 … %99; ekrandaki örnek %90", "Açmadan önce uyarı; yük atmaya zaman bırakır", P3U + " Çizelge 60"),
        S("Zaman sabiti tau", f"{fnum(tau, 0)} dk", "2 … 180 dk; ekrandaki örnek 60", "Trafonun ısıl zaman sabiti", P3U + " Çizelge 60"),
        S("Soğuma zaman sabiti", f"{fnum(ct, 1)} × tau", "1,0 … 10,0 × tau", "Akım 0,3 × In altındayken soğuma bu katsayıyla yavaşlatılır", P3U + " böl. 5.16"),
        S("+40 °C'de max aşırı yük · +70 °C'de max aşırı yük", f"%{fnum(num(p, 'imax40', 100), 0)} · %{fnum(num(p, 'imax70', 78), 0)}", "%70 … %120 · %50 … %100", "Ortam sıcaklığı düzeltme eğrisinin iki ucu", P3U + " Çizelge 60"),
        S("Ortam sıcaklığı · kaynağı", f"{fnum(num(p, 'ortam', 40), 0)} °C · Kullanıcı girişi", "−55 … +125 °C; sensör ya da elle", "Sensör yoksa sabit değer girilir", P3U + " Çizelge 60"),
        S("Thermal level reset input", "—", "dijital giriş", "Isıl belleği sıfırlamak için (deneyden sonra)", "eSetup Easergy Pro ekranı", "dogrulanacak"),
    ]
    sn = a / ct_p
    test = [
        T("Açma düzeyi", f"Üç faza {fnum(1.0 * sn, 3)} A (a'nın tam değeri) uzun süre", "Sıcaklık %100'e yaklaşır ama açmaz; biraz üstünde açar", "açma düzeyinin %95'inde bırakır (bırakma oranı 0,95)"),
        T("Soğuk durumdan açma süresi", f"Isıl belleği sıfırlayın; üç faza {fnum(2 * sn, 3)} A (2 × a)", f"Açma {fnum(tau * math.log(4 / 3) * 60, 0)} s sonra (τ · ln(4/3))", "±%5 ya da 1 s"),
        T("Ön yüklü açma süresi", f"Önce {fnum(0.8 * sn, 3)} A ile kararlı duruma (%64) gelin, sonra 2 × a", f"Açma {fnum(tau * math.log((4 - 0.64) / 3) * 60, 0)} s sonra", "±%5 ya da 1 s"),
        T("Alarm", f"2 × a akımda", f"Alarm {fnum(tau * math.log(4 / (4 - al)) * 60, 0)} s sonra (soğuk durumdan)", "±%5 ya da 1 s"),
        T("Bu sayfadaki durum", f"%{fnum(num(p, 'i_once', 80), 0)} → %{fnum(num(p, 'i_yuk', 130), 0)} In(trafo)", ("AÇAR " + fnum(t_acma, 1) + " dk") if acar else "AÇMAZ", f"kararlı sıcaklık %{fnum(th_s * 100, 0)}"),
    ]
    T_son = max(4 * tau, 60); n = 160
    ts = [T_son * j / n for j in range(n + 1)]
    isinma = []
    for t in ts:
        if acar and t > t_acma:
            isinma.append([round(t, 1), round(100 * math.exp(-(t - t_acma) / (tau * ct)), 1)])
        else:
            isinma.append([round(t, 1), round((th_s + (th0 - th_s) * math.exp(-t / tau)) * 100, 1)])
    g1 = {"baslik": "Hesaplanan sıcaklık: aşırı yük başladıktan sonra", "x_ad": "Zaman (dk)", "y_ad": "Isıl düzey (%)", "zaman": True, "ymin": 0,
          "seriler": [{"ad": "ısıl düzey", "renk": "#dc2626", "pts": isinma}], "yatay": [{"y": 100, "etiket": "açma %100"}, {"y": al * 100, "etiket": f"alarm %{fnum(al * 100, 0)}", "renk": "#d97706"}],
          "isaretler": [{"x": t_acma, "etiket": "AÇMA"}] if acar and t_acma <= T_son else []}
    ms = [1.02 + 0.02 * j for j in range(0, 150)]
    g2 = {"baslik": "Açma süresi – akım (soğuk ve ön yüklü)", "x_ad": "Akım (× açma düzeyi a)", "y_ad": "Açma süresi (dk)", "logy": True,
          "seriler": [{"ad": "soğuk durumdan", "renk": "#1a4d8f", "pts": [[round(m, 2), tau * math.log(m * m / (m * m - 1))] for m in ms]},
                      {"ad": f"ön yük %{fnum(num(p, 'i_once', 80), 0)}", "renk": "#dc2626", "pts": [[round(m, 2), max(tau * math.log((m * m - th0) / (m * m - 1)), 1e-3)] for m in ms if th0 < 1]}],
          "isaretler": [{"x": i / a, "etiket": "şu an"}] if 1.02 <= i / a <= 4 else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["49t"],
        "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Isınma akımın karesiyle orantılıdır. Röle, akımın etkin değerinden bir «ısıl düzey» hesaplar: sürekli akım a iken %100, daha küçük akımda (I/a)² kadar.",
            f"Açma düzeyi akımı a = k · kΘ · In. Burada {fa(a)}: trafonun anma akımının {fnum(a / i_tr, 2)} katı.",
            f"Yük değişince ısıl düzey yeni değerine üstel olarak yaklaşır; hızını zaman sabiti τ ({fnum(tau, 0)} dk) belirler. Bir τ sonra yolun %63'ü, üç τ sonra %95'i alınmıştır.",
            "Trafo önceden yüklüyse ısıl düzey sıfırdan başlamaz: aynı aşırı yükte açma daha erken gelir. Röle bunu «ısıl bellek» olarak tutar.",
            "Akım açma düzeyinin altındaysa ısıl düzey %100'e hiç ulaşmaz: açma yok, yalnız alarm olabilir.",
            "Sıcak ortamda soğutma zayıflar; ortam katsayısı kΘ açma düzeyini düşürür.",
        ],
        "dersler": [
            "49T aşırı yüke karşıdır, kısa devreye karşı değil: dakikalar mertebesinde çalışır.",
            "k'nin tabanına dikkat: fider modunda ×In AT primeridir. 2000 kVA / 50 A AT'de k = 1,06 × 33,5 / 50 = 0,71 girilir.",
            "Zaman sabiti üreticiden alınır; tahmini değerle açma süresi iki kat şaşabilir.",
            "Deneyden sonra ısıl belleği sıfırlayın; yoksa röle trafoyu sıcak sanar.",
        ],
        "tablolar": [{"baslik": "Yüke göre kararlı ısıl düzey ve açma süresi (bu ayarlarla)", "cols": ["Yük (× In trafo)", "Kararlı düzey", "Soğuktan açma", f"%{fnum(num(p, 'i_once', 80), 0)} ön yükten açma"], "rows": [
            [fnum(m, 2), f"%{fnum((m * i_tr / a) ** 2 * 100, 0)}", (fnum(tau * math.log((m * i_tr) ** 2 / ((m * i_tr) ** 2 - a * a)), 0) + " dk") if m * i_tr > a else "açmaz",
             (fnum(tau * math.log(((m * i_tr) ** 2 - ip * ip) / ((m * i_tr) ** 2 - a * a)), 0) + " dk") if m * i_tr > a and ip < a else "açmaz"] for m in (0.8, 1.0, 1.1, 1.2, 1.5, 2.0, 3.0)]}],
    }
