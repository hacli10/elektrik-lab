"""Tekrar kapama (ANSI 79) — Easergy P3 «Auto-recloser» işlevi.

Dayanak: P3U/en M/J006 böl. 5.36 (beş atış; her atış ölü zaman + ayırt etme süresinden oluşur; dört tekrar kapama hattı AR1–AR4, AR1 en öncelikli; başlatma gecikmesinden
sonra kesici açılır, ölü zaman sonunda kapatılır ve ayırt etme süresi başlar; ayırt etme ya da geri kazanma süresinde yeni istek gelirse bir sonraki atışa geçilir; geri kazanma
süresi dolarsa dizi başarıyla biter; kritik istek ayırt etme süresinde gelirse son açma yapılır ve dizi kilitlenir; koruma kademesinin gecikmesi başlatma gecikmesi ile
ayırt etme süresinden uzun olmalıdır; kritik işaret kullanılıyorsa ayırt etme süresi en az 100 ms; elle kapamada geri kazanma durumu başlar ve bu sürede istekler yok sayılır;
zamanlayıcılar 0 … 300 s — Şekil 126; «DI to block AR» harici senkron kontrol rölesiyle kullanılır). Üretim tesisi bağlı fiderde ölü zamanın santralin ayrılma süresinden uzun
olması gereği: Lisanssız Üretim Tebliği Ek-2 temizleme süreleriyle birlikte okunur — süre payı öğretim amaçlı öneridir."""
from __future__ import annotations

from .ortak import A, C, G, K, LUY, P3U, S, T, ctl, fnum, num, opt, tek_hat

ID = "tekrar79"
BASLIK = "Tekrar kapama (79)"
IKON = "🔁"
GIRIS = ("Havai hat arızalarının çoğu geçicidir: dal değer, yıldırım atlar, ark söner. Kesici açılıp kısa bir süre beklenir ve yeniden kapatılırsa hat çoğu zaman "
         "sağlam bulunur. Tekrar kapama bunu kendiliğinden yapar; yapılacak iş bekleme sürelerini ve kaç kez deneneceğini seçmektir.")

ARIZA = {"gecici": "Geçici arıza (ilk beklemede söner)", "yari": "Yarı kalıcı arıza (uzun beklemede söner)", "kalici": "Kalıcı arıza"}

KONTROLLER = [
    ctl("ariza", "Arıza", "sec", "gecici", secenek=opt(*ARIZA.items())),
    ctl("t_son", "Geçici arızanın sönme süresi (kesici açıkken)", "sayi", 0.20, min=0.05, max=30, adim=0.05, birim="s", yardim="Arkın iyonlaşmış havasının dağılması için gereken süre"),
    ctl("atis", "Röle › Atış sayısı", "sec", 2, secenek=opt((1, "1 atış"), (2, "2 atış"), (3, "3 atış"))),
    ctl("t_bas", "Röle › Başlatma gecikmesi", "sayi", 0.05, min=0.0, max=2.0, adim=0.01, birim="s"),
    ctl("t_olu1", "Röle › Atış 1 ölü zamanı", "sayi", 0.50, min=0.1, max=300, adim=0.05, birim="s"),
    ctl("t_olu2", "Röle › Atış 2 (ve 3) ölü zamanı", "sayi", 15.0, min=0.1, max=300, adim=0.5, birim="s", goster={"atis": [2, 3]}),
    ctl("t_ayirt", "Röle › Ayırt etme süresi", "sayi", 0.20, min=0.0, max=10, adim=0.01, birim="s"),
    ctl("t_geri", "Röle › Geri kazanma süresi", "sayi", 10.0, min=0.5, max=300, adim=0.5, birim="s"),
    ctl("t_51", "Koruma kademesinin gecikmesi", "sayi", 0.40, min=0.03, max=3.0, adim=0.01, birim="s"),
    ctl("t_kesici", "Kesicinin açma / kapama süresi", "sayi", 60, min=20, max=120, adim=5, birim="ms"),
    ctl("santral", "Fidere üretim tesisi bağlı", "onay", True),
    ctl("t_santral", "Santralin şebekeden ayrılma süresi", "sayi", 0.20, min=0.1, max=5.0, adim=0.05, birim="s", goster={"santral": [True]}, yardim="Ada korumasının temizleme süresi (Tebliğ: 0,2 s)"),
]


def dizi(p: dict) -> dict:
    """Tekrar kapama dizisinin zaman çizgisi: (t, kesici kapalı mı, akım var mı) olayları."""
    tur = p.get("ariza") if p.get("ariza") in ARIZA else "gecici"
    n = int(num(p, "atis", 2)); tk = num(p, "t_kesici", 60) / 1000
    olu = [num(p, "t_olu1", 0.5)] + [num(p, "t_olu2", 15.0)] * 2
    soner = {"gecici": num(p, "t_son", 0.2), "yari": max(num(p, "t_son", 0.2), 5.0), "kalici": float("inf")}[tur]
    t = 0.0; olay = [(0.0, "arıza")]; acik_toplam = 0.0; atis = 0; sonuc = None
    while True:
        t += num(p, "t_bas", 0.05) + tk if atis == 0 else num(p, "t_ayirt", 0.2) + tk       # açma: ilkinde başlatma gecikmesi, sonrakilerde ayırt etme süresi
        olay.append((t, "açtı"))
        if atis >= n:
            sonuc = "son açma (kilit)"; break
        atis += 1
        acik = olu[atis - 1]; t += acik + tk; acik_toplam = acik
        olay.append((t, f"kapadı (atış {atis})"))
        if acik >= soner:
            sonuc = f"başarılı (atış {atis})"; olay.append((t + num(p, "t_geri", 10.0), "geri kazanma bitti")); break
    return {"olay": olay, "sonuc": sonuc, "atis": atis, "t_son": t, "basarili": sonuc.startswith("başarılı"), "tur": tur, "soner": soner, "olu": olu}


def run(p: dict) -> dict:
    d = dizi(p); tk = num(p, "t_kesici", 60) / 1000
    santral = bool(p.get("santral")); ts = num(p, "t_santral", 0.2)
    olu1 = num(p, "t_olu1", 0.5)
    beklenen = d["tur"] != "kalici"
    c = tek_hat(("Besleme", ""), ("Havai hat", ARIZA[d["tur"]].split(" (")[0]), ("79  tekrar kapama", d["sonuc"]), "acti" if d["basarili"] else "gecersiz", 620, "sag", gt=False, ileri=False, kesici_acik=not d["basarili"])
    c.yazi(500, 190, f"Sonuç: {d['sonuc']} · {d['atis']} atış · {fnum(d['t_son'], 2)} s", "#15803d" if d["basarili"] else "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, f"Ölü zamanlar: {fnum(olu1, 2)} s" + (f" · {fnum(num(p, 't_olu2', 15.0), 1)} s" if num(p, "atis", 2) >= 2 else "") + f" · arızanın sönmesi için gereken {fnum(d['soner'], 2) if d['soner'] < 1e9 else '∞'} s", "#334155", 11)
    c.yazi(500, 226, ("Santral ilk ölü zamandan önce ayrılmalı: " + (f"{fnum(ts, 2)} s < {fnum(olu1, 2)} s ✓" if ts + 0.1 <= olu1 else f"{fnum(ts, 2)} s — ölü zaman YETERSİZ")) if santral else "Fiderde üretim tesisi yok", "#b91c1c" if santral and ts + 0.1 > olu1 else "#334155", 11)
    ozet = [
        K("Sonuç", d["sonuc"], "ok" if d["basarili"] == beklenen else "bad", "hat " + ("yeniden enerjili" if d["basarili"] else "enerjisiz, dizi kilitli")),
        K("Atış sayısı", str(d["atis"]), "info", f"ayar {int(num(p, 'atis', 2))}"),
        K("Toplam süre", f"{fnum(d['t_son'], 2)} s", "info", "arızadan son kapama / son açmaya"),
        K("Müşterinin gördüğü kesinti", f"{fnum(sum(d['olu'][:d['atis']]) + d['atis'] * tk, 2)} s" if d["basarili"] else "kalıcı", "ok" if d["basarili"] else "warn", "ölü zamanların toplamı"),
        K("Santral – ölü zaman payı", f"{fnum(olu1 - ts, 2)} s" if santral else "—", ("ok" if olu1 - ts >= 0.1 else "bad") if santral else "info", "ölü zaman − santralin ayrılma süresi"),
    ]
    kontroller = [
        C("Dizi arıza türüne uygun sonuçlandı mı?", d["sonuc"], "geçici arızada başarılı kapama; kalıcı arızada son açma ve kilit", d["basarili"] == beklenen, P3U + " böl. 5.36", "resmi"),
        C("İlk ölü zaman arkın sönmesine yetiyor mu?", f"{fnum(olu1, 2)} s; sönme süresi {fnum(num(p, 't_son', 0.2), 2)} s", "ölü zaman ≥ sönme süresi", olu1 >= num(p, "t_son", 0.2),
          "Arkın iyonlaşmış yolunun yalıtkanlığını geri kazanması için gereken süre gerilim düzeyine bağlıdır (OG'de onda birkaç saniye; tipik)", "tahmini"),
        C("Üretim tesisi ilk kapamadan önce ayrılmış oluyor mu?", f"santral {fnum(ts, 2)} s'de ayrılır; ölü zaman {fnum(olu1, 2)} s" if santral else "üretim tesisi yok", "ölü zaman ≥ santralin ayrılma süresi + 0,1 s", (olu1 >= ts + 0.1) if santral else None,
          "Santral hâlâ bağlıyken kapama, senkron olmayan iki sistemi birleştirir. Santralin ayrılma süresi: " + LUY + " (gerilim / frekans / ada korumaları 0,2 s). 0,1 s pay öğretim amaçlı", "ikincil"),
        C("Koruma kademesinin gecikmesi yeterli mi?", f"koruma {fnum(num(p, 't_51', 0.4), 2)} s; başlatma gecikmesi {fnum(num(p, 't_bas', 0.05), 2)} s; ayırt etme {fnum(num(p, 't_ayirt', 0.2), 2)} s", "koruma gecikmesi > başlatma gecikmesi ve > ayırt etme süresi",
          num(p, "t_51", 0.4) > num(p, "t_bas", 0.05) and num(p, "t_51", 0.4) > num(p, "t_ayirt", 0.2), "Dizi koruma kademesinin BAŞLATMA işaretiyle tetiklenir; AÇMA işareti yedektir — " + P3U + " böl. 5.36", "resmi"),
        C("Ayırt etme süresi", f"{fnum(num(p, 't_ayirt', 0.2), 2)} s", "kritik işaret kullanılıyorsa ≥ 100 ms", num(p, "t_ayirt", 0.2) >= 0.1, P3U + " böl. 5.36", "resmi"),
        C("Kablo fiderinde tekrar kapama", "bu sayfa havai hat içindir", "kabloda arıza kalıcıdır: tekrar kapama kullanılmaz", None, "Tekrar kapama havai hatları koruyan fider rölelerinde kullanılır — " + P3U + " böl. 5.36", "resmi"),
    ]
    girdiler = [
        G("Hattın türü", "havai hat", "Tek hat şeması", "Tekrar kapama yalnız geçici arızanın olası olduğu havai hatta anlamlıdır", "etkin / kapalı"),
        G("Dağıtım şirketinin tekrar kapama uygulaması", "atış sayısı ve ölü zamanlar", "Dağıtım şirketi", "Fider üst merkezden tekrar kapamalıysa santral bu sürelere göre ayrılmalı", "ölü zamanlar"),
        G("Fiderdeki üretim tesisleri ve ayrılma süreleri", f"{fnum(ts, 2)} s" if santral else "yok", "Bağlantı görüşü; ada koruması ayarları", "Ölü zamanın alt sınırı", "ölü zaman ≥ ayrılma süresi + pay"),
        G("Tetikleyecek koruma kademeleri", "I>> → AR1, I> → AR2, toprak → AR3 / AR4", "Ayar föyü", "Her hattın önceliği ve hangi atışlarda etkin olduğu", "tekrar kapama matrisi"),
        G("Kesicinin tekrar kapama çevrimi", "O – 0,3 s – CO – 3 dk – CO (tipik)", "Kesici etiketi", "Kesici bu çevrimi yapabilecek sınıfta olmalı; ölü zaman kesicinin en kısa bekleme süresinden kısa olamaz", "atış sayısı, ölü zaman"),
    ]
    adimlar = [
        A("İlk ölü zaman", "≥ max(ark sönme süresi, santralin ayrılma süresi + 0,1 s)", f"max({fnum(num(p, 't_son', 0.2), 2)}; {fnum(ts + 0.1, 2) if santral else '—'}) s", f"{fnum(max(num(p, 't_son', 0.2), (ts + 0.1) if santral else 0, 0.3), 2)} s", "sönme süresi tipik; santral süresi: " + LUY, "ikincil", ["Fiderdeki üretim tesisleri ve ayrılma süreleri"], "Atış 1 ölü zamanı"),
        A("Koruma gecikmesi koşulu", "t koruma > t başlatma ve > t ayırt etme", f"{fnum(num(p, 't_51', 0.4), 2)} > {fnum(num(p, 't_bas', 0.05), 2)} ve > {fnum(num(p, 't_ayirt', 0.2), 2)}", "sağlanıyor" if num(p, "t_51", 0.4) > max(num(p, "t_bas", 0.05), num(p, "t_ayirt", 0.2)) else "sağlanmıyor", P3U + " böl. 5.36", "resmi"),
        A("Dizinin toplam süresi", "Σ (açma + ölü zaman + kapama + ayırt etme)", " → ".join(f"{fnum(t_, 2)} s {ad}" for t_, ad in d["olay"][:7]), f"{fnum(d['t_son'], 2)} s", "zaman zinciri", "hesap"),
    ]
    ayarlar = [
        S("AR — Etkin", "Açık", "—", "Tekrar kapama nesne denetimini kullanır; kesici denetimi başarısız olursa dizi durur", P3U + " böl. 5.36"),
        S("Tekrar kapama matrisi › AR1 … AR4", "I>> başlatma → AR1; I> başlatma → AR2; Io> → AR3", "4 hat × 5 atış", "Hangi koruma işareti hangi atışları tetikler; AR1 en öncelikli", P3U + " böl. 5.36 Şekil 126"),
        S("Başlatma gecikmesi", f"{fnum(num(p, 't_bas', 0.05), 2)} s", "0 … 300 s", "İstek geldikten sonra kesicinin açılmasına kadar", P3U + " Şekil 126"),
        S("Ölü zaman (atış 1 · atış 2)", f"{fnum(olu1, 2)} s · {fnum(num(p, 't_olu2', 15.0), 1)} s", "0 … 300 s (her atış ayrı)", "Kesicinin açık bekleyeceği süre; hızlı atışta 1 s'nin altı", P3U + " böl. 5.36"),
        S("Ayırt etme süresi", f"{fnum(num(p, 't_ayirt', 0.2), 2)} s", "0 … 300 s (her atış ayrı)", "Kapamadan sonra arızanın sürüp sürmediğine bakılan süre; bu sürede kritik işaret gelirse son açma", P3U + " böl. 5.36"),
        S("Geri kazanma süresi", f"{fnum(num(p, 't_geri', 10.0), 1)} s", "0 … 300 s", "Bu süre arızasız geçerse dizi başarıyla biter ve 1. atışa döner; elle kapamadan sonra da bu süre boyunca istekler yok sayılır", P3U + " böl. 5.36"),
        S("DI to block AR", "harici senkron kontrol / santral bağlı bilgisi", "dijital giriş", "Giriş etkinken kesici kapatılmaz; kalkınca hemen kapatılır", P3U + " böl. 5.36"),
    ]
    test = [
        T("Geçici arıza", f"Arıza akımını verin; kesici açınca akımı kesin ve kapamadan sonra vermeyin", f"Kesici {fnum(olu1, 2)} s sonra kapanır; {fnum(num(p, 't_geri', 10.0), 0)} s sonra dizi biter", "zamanlar ±%1 ya da ±30 ms dolayı"),
        T("Kalıcı arıza", "Her kapamadan sonra arıza akımını yeniden verin", f"{int(num(p, 'atis', 2))} atıştan sonra son açma; dizi kilitli; elle kapama kilidi çözer", "—"),
        T("Geri kazanma süresinde yeni arıza", "İlk başarılı kapamadan sonra geri kazanma süresi dolmadan arıza verin", "Dizi bir sonraki atıştan sürer", "—"),
        T("Elle kapama", "Kesiciyi elle kapatın ve hemen arıza verin", "Tekrar kapama yapılmaz (geri kazanma durumu); koruma açar", "—"),
        T("Kapama engeli", "«DI to block AR» girişini etkin tutun", "Ölü zaman dolsa da kesici kapanmaz; giriş kalkınca kapanır", "—"),
    ]
    pts = [[-0.3, 1], [0, 1]]
    kapali = True
    for t_, ad in d["olay"][1:]:
        if ad == "açtı":
            pts += [[round(t_, 3), 1], [round(t_, 3), 0]]; kapali = False
        elif ad.startswith("kapadı"):
            pts += [[round(t_, 3), 0], [round(t_, 3), 1]]; kapali = True
    son = d["olay"][-1][0] + 1.0
    pts.append([round(son, 3), 1 if kapali else 0])
    g = {"baslik": "Tekrar kapama dizisi: kesicinin konumu", "x_ad": "Zaman (s)", "y_ad": "kesici (1: kapalı)", "ymin": -0.1, "ymax": 1.4,
         "seriler": [{"ad": "kesici", "renk": "#1a4d8f", "pts": pts}], "isaretler": [{"x": t_, "etiket": ad} for t_, ad in d["olay"] if ad != "arıza"][:6]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["_79_", "tekrar_kapama"],
        "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Koruma kademesi başladığında tekrar kapama işlevi tetiklenir. Başlatma gecikmesinden sonra kesici açılır ve ölü zaman sayılır.",
            "Ölü zaman sonunda kesici kapatılır ve kısa bir ayırt etme süresi başlar. Arıza sönmüşse akım olağandır; geri kazanma süresi arızasız geçerse dizi başarıyla biter.",
            "Arıza sürüyorsa bir sonraki atışa geçilir: kesici yeniden açılır, bu kez daha uzun beklenir. Atışlar tükenince son açma yapılır ve dizi kilitlenir; kesici ancak elle kapatılır.",
            "İlk ölü zaman kısa tutulur ki tüketici kesintiyi fark etmesin; ama arkın söndüğü yolun yeniden yalıtkan olmasına yetecek kadar da uzun olmalıdır.",
            "Fiderde üretim tesisi varsa bir koşul daha gelir: şebeke kesicisi açıldığında santral adada kalır ve kendi korumalarıyla ayrılır. Kapama, santral ayrılmadan yapılırsa iki eşzamansız sistem birleşir. Ölü zaman santralin ayrılma süresinden uzun olmalıdır.",
            "Kesici elle kapatıldığında tekrar kapama bir süre devre dışıdır: arızalı hatta elle kapamada dizi başlamaz, koruma doğrudan açar.",
        ],
        "dersler": [
            "Tekrar kapama havai hat içindir; kabloda kullanılmaz.",
            "Koruma kademesinin gecikmesi, başlatma gecikmesinden ve ayırt etme süresinden uzun olmalıdır: dizi başlatma işaretiyle, açma işareti yedek olarak çalışır.",
            "Üretim tesisi olan fiderde ilk ölü zaman ≥ santralin ayrılma süresi + pay.",
            "Geri kazanma süresi kesicinin çevrim sınıfına uygun olmalıdır.",
        ],
        "tablolar": [{"baslik": "Zaman çizgisi", "cols": ["Zaman", "Olay"], "rows": [[f"{fnum(t_, 2)} s", ad] for t_, ad in d["olay"]]}],
    }
