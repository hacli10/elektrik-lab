"""Yönlü faz aşırı akım koruması (ANSI 67) — Easergy P3 «Iφ>» kademesi üzerinden: açı, sınırlar ve yön nereden çıkar.

Dayanak: P3U/en M/J006 böl. 5.30 (kutuplama: faz arası ve üç fazlı arızada pozitif bileşen U1/I1; açma bölgesi açı kayması ± 88°; yön modları;
açı hafızası 0,2–3,2 s; yön çözümü için en az 2 V sekonder) ve Çizelge 82; URRA yönlü koruma kanıt dosyası (röle ailelerine göre açı tanımı);
TEDAŞ-MLZ/96-027.D m.(60). Örnek: biyogaz santralinin dağıtım şebekesine bağlandığı hücre (1870 kVA, 34,5 kV, AT 50/1)."""
from __future__ import annotations

import math

from .ortak import (A, C, G, IEC, K, KABUL, KANIT, P3U, S, S3, SART, T, URRA, aci, ariza, at_ctl, at_girdi, ctl, fa, fnum, fz, iec_sure, kutup, norm, num, opt, sek, tek_hat)
from .roleler import ALAN, ROLE67, YONSUZ, aci67, alan_cizelgesi

ID = "yon_faz"
BASLIK = "Yönlü faz (67)"
IKON = "🧭"
GIRIS = ("Yönlü röle iki soruya birden bakar: akım eşiği aştı mı, ve akım hangi yöne akıyor? Yönü, akımın gerilime göre açısından çıkarır. "
         "Bu sayfada açının nereden geldiğini (arıza yolunun R ve X'i), açma bölgesinin sınırlarını ve yönün neye göre «ileri» olduğunu, "
         "bir biyogaz santralinin şebeke bağlantı hücresi üzerinde görürsünüz.")

DURUM = {"3f": "Üç fazlı kısa devre", "2f": "İki fazlı kısa devre (L2–L3)", "1f": "Faz–toprak kısa devre (L1; kaynak tarafı topraklı kabulü)", "ihracat": "Arıza yok — santral şebekeye güç veriyor", "ithalat": "Arıza yok — tesis şebekeden güç çekiyor"}
MOD = {"yon": "Yön (yalnız ileri)", "yon_artci": "Yön + Artçı (gerilim yoksa yönsüz çalışır)", "yonsuz": "Yönsüz (51 gibi)"}
YARI = 88.0          # açma bölgesinin yarı genişliği (°) — P3U Çizelge 82 «Operate angle ±88°»
U_MIN_SEK = 2.0      # yön çözümü için en küçük sekonder gerilim (V) — P3U Çizelge 82

KONTROLLER = at_ctl() + [
    ctl("s_kva", "Santralin gücü", "sayi", 1870, min=100, max=20000, adim=10, birim="kVA", yardim="Jeneratör etiketi; ihracat akımını verir"),
    ctl("xd", "Jeneratörün başlangıç reaktansı x″d", "sayi", 18, min=8, max=35, adim=1, birim="%", yardim="Jeneratör veri föyü; santralin arızaya katkısını belirler"),
    ctl("uk", "Yükseltici trafonun uk'sı", "sayi", 6, min=4, max=12, adim=0.5, birim="%"),
    ctl("r_km", "Şebeke hattının direnci R′", "sayi", 0.34, min=0.03, max=1.5, adim=0.01, birim="Ω/km", yardim="İletken çizelgesi (ör. 3/0 AWG Pigeon ≈ 0,34)"),
    ctl("x_km", "Şebeke hattının reaktansı X′", "sayi", 0.37, min=0.08, max=0.45, adim=0.01, birim="Ω/km", yardim="Havai hat ≈ 0,35–0,40; XLPE kablo ≈ 0,10–0,15"),
    ctl("l_km", "Arıza yerinin uzaklığı", "sayi", 5.0, min=0.0, max=40, adim=0.5, birim="km", yardim="0 km: rölenin dibinde arıza — gerilim çöker"),
    ctl("rf", "Ark / arıza direnci", "sayi", 0.0, min=0, max=30, adim=0.5, birim="Ω"),
    ctl("ik_seb", "Şebekenin baradaki kısa devre akımı", "sayi", 6.0, min=0.5, max=25, adim=0.5, birim="kA", yardim="Geri yöndeki (santral içi) arızayı şebeke besler"),
    ctl("durum", "Durum", "sec", "3f", secenek=opt(*DURUM.items())),
    ctl("yer", "Arıza yeri", "sec", "ileri", secenek=opt(("ileri", "İleride — şebeke hattında"), ("geri", "Geride — santralin içinde (AT'nin arkasında)")), goster={"durum": ["3f", "2f", "1f"]}),
    ctl("rol", "Röle › Marka / model", "sec", "p3", secenek=opt(*[(k, v["ad"]) for k, v in ROLE67.items()]), yardim="Fizik aynıdır; röleye girilen açı sayısı, bölge genişliği ve gerilim hafızası markaya göre değişir"),
    ctl("mod", "Röle › Yön modu", "sec", "yon", secenek=opt(*MOD.items())),
    ctl("aci", "Röle › Açma bölgesinin merkezi", "sayi", -60, min=-180, max=179, adim=1, birim="°", yardim="Akımın faz gerilimine göre açısı (eksi: geride). Easergy P3'te «Açı kayması» bu sayıdır; başka rölede karşılığı aşağıda hesaplanır"),
    ctl("baslatma", "Röle › Başlatma", "sayi", 0.75, min=0.10, max=4.00, adim=0.01, birim="×In"),
    ctl("egri", "Röle › Gecikme eğrisi", "sec", "sz", secenek=opt(("sz", "SZ — sabit zamanlı"), *[(kk, "IEC " + v[2]) for kk, v in IEC.items()]), yardim="Kademe 1 ve 2 sabit ya da ters zamanlı olabilir; kademe 3 ve 4 yalnız sabit zamanlı"),
    ctl("t_s", "Röle › Çalışma süresi (sabit zamanlı)", "sayi", 0.30, min=0.04, max=5.0, adim=0.01, birim="s", goster={"egri": ["sz"]}),
    ctl("k", "Röle › Zaman çarpanı k", "sayi", 0.05, min=0.025, max=2.0, adim=0.005, goster={"egri": list(IEC)}),
    ctl("hafiza", "Röle › Gerilim (açı) hafızası süresi", "sayi", 0.5, min=0.04, max=5.0, adim=0.02, birim="s", yardim="P3: 0,2–3,2 s; ABB 615: 0–3 s (varsayılan 40 ms). Hafızası sabit olan rölelerde (P5 5 s, F60 1 s, P14D 3,2 s) bu ayar kullanılmaz"),
    ctl("at_ters", "Akım trafosu ters bağlı (P1–P2 ya da S1–S2)", "onay", False),
    ctl("gt_yok", "Gerilim trafosu sigortası atmış (röleye gerilim gelmiyor)", "onay", False),
]


def olc(p: dict, durum: str, yer: str) -> dict:
    """Verilen durumda rölenin gördüğü pozitif bileşen gerilimi ve akımı (primer; gerilim faz–nötr V)."""
    un = num(p, "un_kv", 34.5) * 1000; e = un / S3
    s = num(p, "s_kva", 1870) * 1000; i_n = s / (S3 * un)
    zg = 1j * (num(p, "xd", 18) + num(p, "uk", 6)) / 100 * un * un / s                # santral (jeneratör + trafo), Ω
    zs = kutup(e / (num(p, "ik_seb", 6) * 1000), 80)                                  # şebeke eşdeğeri, Ω
    zh = complex(num(p, "r_km", 0.34), num(p, "x_km", 0.37)) * num(p, "l_km", 5.0)    # röle ile arıza arası hat
    rf = num(p, "rf", 0.0)
    if durum == "ihracat":
        i1, u1 = kutup(i_n, -math.degrees(math.acos(0.98))), complex(e, 0)
        ll = un
    elif durum == "ithalat":
        i1, u1 = kutup(0.6 * i_n, 180 - math.degrees(math.acos(0.9))), complex(e, 0)
        ll = un
    else:
        if yer == "ileri":
            r = ariza(durum, ic_gerilim(e, zg, i_n), zg, zg, zh, 3 * zh, rf)
            i1, u1 = r["i1"], r["u1"]
        else:                                               # santralin içinde arıza: şebeke besler, akım röleden ters geçer
            zic = complex(0.02, 0.015)
            r = ariza(durum, e, zs, zs, zic, 3 * zic, rf)
            i1, u1 = -r["i1"], r["u1"]
        U = r["U"]
        ll = max(abs(U[0] - U[1]), abs(U[1] - U[2]), abs(U[2] - U[0]))
        i_faz = max(abs(x) for x in r["I"])
        if durum == "1f":                                   # çapraz kutuplama: arızalı fazın akımı, sağlam faz arası gerilimin 90° döndürülmüşüne göre (P3U böl. 5.30)
            i1 = r["I"][0] if yer == "ileri" else -r["I"][0]
            u1 = 1j * (U[1] - U[2]) / S3
        return {"i1": i1, "u1": u1, "ll": ll, "i": i_faz, "in": i_n, "zh": zh, "zg": zg, "e": e, "un": un, "capraz": durum == "1f"}
    return {"i1": i1, "u1": u1, "ll": ll, "i": abs(i1), "in": i_n, "zh": zh, "zg": zg, "e": e, "un": un, "capraz": False}


def gecikme(p: dict, i_a: float, esik: float) -> float:
    """Kademenin sabit akımdaki çalışma süresi (s): sabit zamanlı ya da IEC ters zamanlı."""
    egri = p.get("egri") if p.get("egri") in IEC else "sz"
    if i_a < esik:
        return math.inf
    return num(p, "t_s", 0.3) if egri == "sz" else iec_sure(i_a / esik, num(p, "k", 0.05), egri)


def santral_akimi(p: dict, tt: float) -> float:
    """Bara dibindeki üç fazlı arızada santralin katkısı (A): başlangıç → geçici → sürekli (tipik zaman sabitleri 0,03 s ve 0,6 s)."""
    un = num(p, "un_kv", 34.5) * 1000; i_n = num(p, "s_kva", 1870) * 1000 / (S3 * un)
    xd2 = (num(p, "xd", 18) + num(p, "uk", 6)) / 100; xd1 = (1.6 * num(p, "xd", 18) + num(p, "uk", 6)) / 100; xds = (180 + num(p, "uk", 6)) / 100
    return i_n * ((1 / xd2 - 1 / xd1) * math.exp(-tt / 0.03) + (1 / xd1 - 1 / xds) * math.exp(-tt / 0.6) + 1 / xds)


def sonen_sure(p: dict, esik: float) -> float | None:
    """Sönen santral akımında kademenin açma anı (s); süresini dolduramıyorsa None. Ters zamanlıda sayaç 1/t(I) hızıyla ilerler; akım eşiğin altına inince sıfırlanır."""
    egri = p.get("egri") if p.get("egri") in IEC else "sz"
    say, dt = 0.0, 0.005
    for n in range(1, 2001):
        tt = n * dt; i = santral_akimi(p, tt)
        if i < esik:
            say = 0.0
            if tt > 3.0:
                return None
            continue
        say += dt / (num(p, "t_s", 0.3) if egri == "sz" else iec_sure(i / esik, num(p, "k", 0.05), egri))
        if say >= 1.0:
            return tt
    return None


def ic_gerilim(e: float, zg: complex, i_n: float) -> complex:
    """Santralin arıza öncesi iç gerilimi: bara gerilimi (0°) + yük akımının santral empedansındaki düşümü. Arıza akımı bu gerilime göre akar;
    röle ise hafızasında bara gerilimini tutar — aradaki fark yük açısıdır."""
    return e + zg * kutup(i_n, -math.degrees(math.acos(0.98)))


def aci_uclari(p: dict) -> tuple[float, float]:
    """Üç fazlı ileri arızada akımın açısının iki ucu: (gerilim ölçülebiliyorsa: hattın açısı, hafızayla: santral + hat döngüsünün açısı)."""
    un = num(p, "un_kv", 34.5) * 1000; e = un / S3; s = num(p, "s_kva", 1870) * 1000; i_n = s / (S3 * un)
    zg = 1j * (num(p, "xd", 18) + num(p, "uk", 6)) / 100 * un * un / s
    zh = complex(num(p, "r_km", 0.34), num(p, "x_km", 0.37)) * num(p, "l_km", 5.0)
    return -aci(complex(num(p, "r_km", 0.34), num(p, "x_km", 0.37))), aci(ic_gerilim(e, zg, i_n) / (zg + zh))


def karar(p: dict, m: dict) -> dict:
    """Yönlü faz kademesinin kararı: açma bölgesinin merkezi fiziksel açıdır; bölge genişliği ve gerilim hafızası seçilen röleye göredir."""
    ct_p = num(p, "ct_p", 50); vt_s = num(p, "vt_s", 100)
    mod = p.get("mod") if p.get("mod") in MOD else "yon"
    rol = p.get("rol") if p.get("rol") in ROLE67 else "p3"
    yari = ROLE67[rol]["yari"]
    haf = ROLE67[rol]["hafiza_s"] if ROLE67[rol]["hafiza_s"] is not None else num(p, "hafiza", 0.5)
    if rol == "p3":
        haf = min(max(haf, 0.2), 3.2)
    elif rol == "abb615":
        haf = min(haf, 3.0)
    i1 = -m["i1"] if p.get("at_ters") else m["i1"]
    u_sek = 0.0 if p.get("gt_yok") else m["ll"] / m["un"] * vt_s
    esik = num(p, "baslatma", 0.75) * ct_p
    ustunde = m["i"] >= esik
    t = gecikme(p, m["i"], esik)
    if u_sek >= U_MIN_SEK:
        kut, theta = "ölçülen gerilim", norm(aci(i1) - aci(m["u1"]))
    elif not p.get("gt_yok") and t <= haf:
        kut, theta = "hafıza (arıza öncesi)", norm(aci(i1) - 0.0)
    else:
        kut, theta = "yok", None
    base = aci67(rol, num(p, "aci", -60))["merkez"]                     # yalnız belirli açıları kabul eden rölede (Sepam) en yakın geçerli merkez
    icinde = theta is not None and abs(norm(theta - base)) < yari
    if mod == "yonsuz":
        acar, neden = ustunde, "yönsüz mod: yalnız akım eşiğine bakılır"
    elif theta is None:
        acar = ustunde and mod == "yon_artci"
        neden = "yön çözülemiyor (gerilim yok" + (", hafıza süresi doldu" if not p.get("gt_yok") else "") + "): " + ("artçı devrede, yönsüz çalışır" if mod == "yon_artci" else "kademe kilitli")
    else:
        acar = ustunde and icinde
        neden = ("akım açma bölgesinde" if icinde else "akım açma bölgesinin dışında (ters yön)") + ("" if ustunde else "; akım eşiğin altında")
    return {"acar": acar, "neden": neden, "theta": theta, "kut": kut, "icinde": icinde, "ustunde": ustunde, "esik": esik, "u_sek": u_sek, "base": base, "mod": mod, "rol": rol, "yari": yari, "haf": haf, "t": t,
            "pay": None if theta is None else yari - abs(norm(theta - base))}


def run(p: dict) -> dict:
    durum = p.get("durum") if p.get("durum") in DURUM else "3f"
    yer = p.get("yer") if p.get("yer") in ("ileri", "geri") else "ileri"
    ct_p, ct_s, vt_s = num(p, "ct_p", 50), num(p, "ct_s", 1), num(p, "vt_s", 100)
    m = olc(p, durum, yer); k = karar(p, m)
    i_n = m["in"]; un = m["un"]
    ariza_var = durum in ("3f", "2f", "1f")
    ileri_ariza = ariza_var and yer == "ileri"
    beklenen = ileri_ariza
    # önerilen ayarlar
    zh = m["zh"] + num(p, "rf", 0.0)
    phi = aci(complex(num(p, "r_km", 0.34), num(p, "x_km", 0.37)))                    # hattın kendi açısı
    th_olc, th_haf = aci_uclari(p)                                                      # açının iki ucu (°, eksi: geride)
    oneri_aci = 5 * round((th_olc + th_haf) / 2 / 5)
    R = ROLE67[k["rol"]]; yari = k["yari"]; p3 = k["rol"] == "p3"
    O67 = aci67(k["rol"], oneri_aci)                                                    # önerilen merkezin bu röledeki karşılığı
    A67 = aci67(k["rol"], num(p, "aci", -60))                                           # şu anki merkezin bu röledeki karşılığı
    oneri_aci = O67["merkez"]
    oneri_bas = 1.2 * i_n
    ik_s = i_n / ((num(p, "xd", 18) + num(p, "uk", 6)) / 100)                          # santralin başlangıç katkısı (bara dibinde üç fazlı)
    duyar = ik_s / k["esik"]
    egri = p.get("egri") if p.get("egri") in IEC else "sz"
    t = k["t"] if k["t"] < math.inf else gecikme(p, 2 * k["esik"], k["esik"])            # gösterim: akım eşiğin altındaysa 2 × eşikteki süre
    t_son = sonen_sure(p, k["esik"])                                                    # sönen santral akımında açma anı
    egri_ad = "SZ (sabit zamanlı)" if egri == "sz" else f"IEC {egri}, k = {fnum(num(p, 'k', 0.05), 3)}"
    if durum == "3f" and yer == "ileri" and k["acar"] and k["mod"] != "yonsuz" and t_son is None:      # santralin üç fazlı arıza akımı süre dolmadan eşiğin altına iniyor
        k["acar"] = False; k["neden"] = "akım, süre dolmadan başlatma eşiğinin altına sönüyor"

    # ---- şema ----
    rol_alt = ("AÇTI — " if k["acar"] else "açmadı — ") + (f"θ = {fnum(k['theta'], 0)}°" if k["theta"] is not None else "yön yok")
    c = tek_hat(("Santral", f"{fnum(num(p, 's_kva', 1870), 0)} kVA"), ("Dağıtım şebekesi", f"Ik = {fnum(num(p, 'ik_seb', 6), 1)} kA"), ("67  Iφ>" if p3 else "67 — " + R["ad"].split(" (")[0][:22], rol_alt),
                "acti" if k["acar"] else ("gecersiz" if (k["acar"] != beklenen) else "normal"),
                (620 if yer == "ileri" else 175) if ariza_var else None, "sag" if (ileri_ariza or durum == "ihracat") else "sol", kesici_acik=k["acar"],
                at_ad=f"AT {ct_p:g}/{ct_s:g}" + (" (TERS)" if p.get("at_ters") else ""), gt_ad="GT" + (" — sigorta atık" if p.get("gt_yok") else ""))
    c.yazi(500, 190, f"Rölenin gördüğü: I = {fa(m['i'])} = {fnum(m['i'] / ct_p, 2)} ×In", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, f"U = %{fnum(m['ll'] / un * 100, 0)} Un ({fnum(k['u_sek'], 1)} V sek.) · kutuplama: {k['kut']}", "#1d4ed8", 11)
    c.yazi(500, 226, k["neden"], "#334155", 11)
    if ariza_var:
        c.yazi(620 if yer == "ileri" else 175, 148, "arıza", "#b91c1c", 10.5, kalin=True, anchor="middle")
    # ---- fazör ----
    vek = [fz("j·U23" if m.get("capraz") else "U1", m["ll"] / un * 100, 0, 1.0 if k["kut"] != "yok" else 0.02, "#1d4ed8", kesik=k["kut"].startswith("hafıza"))]
    if k["theta"] is not None:
        vek.append(fz("I1", m["i"], k["theta"], 0.82, "#dc2626"))
    fazor = {"baslik": "Röle içi fazör: gerilim 0°'de, akım θ açısında", "vektorler": vek,
             "bolge": {"aci": k["base"], "yari": yari, "renk": "#15803d", "ad": "açma bölgesi"},
             "not": f"Yeşil: açma bölgesi ({fnum(k['base'], 0)}° ± {yari:g}°). Gerilim 0°'de (faz / pozitif bileşen gerilimi, %Un); akım I1 (A). Kesik gerilim: hafızadan. Bu rölede: {A67['metin']}."}

    ozet = [
        K("Röle kararı", "AÇAR" if k["acar"] else "AÇMAZ", ("ok" if k["acar"] == beklenen else "bad"), ("doğru" if k["acar"] == beklenen else "YANLIŞ") + " — " + ("ileride arıza var" if beklenen else "ileride arıza yok")),
        K("Ölçülen açı θ", "—" if k["theta"] is None else f"{fnum(k['theta'], 0)}°", "info", "akımın gerilime göre açısı (eksi: geride)"),
        K("Sınıra kalan pay", "—" if k["pay"] is None else f"{fnum(k['pay'], 0)}°", "info" if k["pay"] is None else ("ok" if k["pay"] > 25 else "warn" if k["pay"] > 0 else "bad"), f"bölge {fnum(k['base'] - yari, 0)}° … {fnum(k['base'] + yari, 0)}°"),
        K("Akım / eşik", f"{fnum(m['i'] / k['esik'], 2)} kat", "ok" if k["ustunde"] else "info", f"eşik {fa(k['esik'])} = {fnum(k['esik'] / ct_p, 2)} ×In"),
        K("Bu rölede girilecek açı", O67["metin"].split(" = ")[1], "ok" if not O67["not"] and R["durum"] == "resmi" else "warn", f"{R['param']} · merkez {oneri_aci:g}° · hat açısı φ = {fnum(phi, 0)}°"),
    ]
    kontroller = [
        C("Röle bu durumda doğru karar veriyor mu?", ("açar" if k["acar"] else "açmaz") + f" ({k['neden']})", "ileride arıza varsa açar, yoksa açmaz", k["acar"] == beklenen,
          "Açma bölgesi: " + R["bolge"] + " — " + R["kaynak"], R["durum"]),
        C("Başlatma yük (ihracat) akımının üstünde mi?", f"{fa(k['esik'])} / {fa(i_n)} = {fnum(k['esik'] / i_n, 2)}", "≥ 1,2 × azami ihracat akımı", k["esik"] >= 1.2 * i_n * 0.995,
          "İhracat akımı da ileri yöndedir (açma bölgesinin içinde): yön tek başına yükü arızadan ayırmaz, eşik ayırır — " + URRA, "ikincil"),
        C("Santralin katkısı eşiği yeterince aşıyor mu?", f"I″k ≈ In / (x″d + uk) = {fa(ik_s, 0)} → {fnum(duyar, 1)} × eşik", "≥ 1,5 kat", duyar >= 1.5,
          "Başlangıç kısa devre akımı (TS EN 60909-0 yaklaşımı); duyarlılık payı saha pratiği", "dogrulanacak"),
        C("Açma bölgesi arıza açısının iki ucunu da kapsıyor mu?", f"merkez {fnum(k['base'], 0)}° ({A67['metin']}); gerilim ölçülürken θ = {fnum(th_olc, 0)}° (pay {fnum(yari - abs(norm(th_olc - k['base'])), 0)}°), hafızayla θ = {fnum(th_haf, 0)}° (pay {fnum(yari - abs(norm(th_haf - k['base'])), 0)}°)",
          "iki uçta da sınıra en az 30° pay", min(yari - abs(norm(th_olc - k["base"])), yari - abs(norm(th_haf - k["base"]))) >= 30,
          "30° pay öğretim amaçlı öneridir. Easergy P3'te açı doğruluğu ±2° (U > 5 V), ±30° (U = 0,1 … 5 V) — " + P3U + " Çizelge 82; öbür rölelerde kendi kılavuzundaki doğruluk", "ikincil"),
        C("Bu rölede açı nasıl tanımlı?", f"{R['param']} = {R['formul']} · {R['kutup']}", "tanım rölenin kendi kılavuzundan okunmuş olmalı", True if R["durum"] == "resmi" else None, R["kaynak"], R["durum"]),
        C("Gerilim yön çözümüne yetiyor mu?", f"{fnum(k['u_sek'], 1)} V sekonder", f"≥ {U_MIN_SEK:g} V; değilse hafıza ({fnum(k['haf'], 1)} s) kullanılır", True if k["u_sek"] >= U_MIN_SEK else (None if k["kut"].startswith("hafıza") else False),
          (P3U + " Çizelge 82 (yön çözümü için en az 2 V sekonder; açı hafızası 0,2 … 3,2 s)") if p3 else ("Bu rölede en küçük kutuplama gerilimi: " + R["min_u"] + "; gerilim hafızası: " + R["hafiza"] + " — " + R["kaynak"] + ". Benzetim 2 V sekonder eşiğini kullanır"), "resmi" if p3 else R["durum"]),
        C("Kademe sönen santral akımında süresini doldurabiliyor mu?", (f"açma {fnum(t_son, 2)} s'de" if t_son is not None else "akım süre dolmadan eşiğin altına iniyor: AÇMAZ") + f" ({egri_ad})", "süre dolana kadar akım eşiğin üstünde kalmalı", t_son is not None,
          "Ters zamanlı kademe 1 ve 2'de kullanılabilir (" + P3U + " Çizelge 82). Santral akımının sönme eğrisi tipik zaman sabitleriyle çizilmiştir; ters eğri, küçülen akımda süresini uzatır", "tahmini"),
        C("Faz–toprak arızasında kutuplama", "arızalı fazın akımı ↔ sağlam faz arası gerilim (90° döndürülmüş)" if m.get("capraz") else "bu durumda pozitif bileşen kutuplaması", "faz–nötr arızada çapraz kutuplama; faz arası ve üç fazlı arızada pozitif bileşen", None,
          "Sağlam faz arası gerilim arızadan etkilenmez: dipteki faz–toprak arızasında bile yön çözülür — " + P3U + " böl. 5.30", "resmi"),
        C("Çalışma süresi hafıza süresinin içinde mi? (dipte arıza için)", f"t = {fnum(t, 2)} s; hafıza {fnum(k['haf'], 1)} s", "t ≤ hafıza; değilse «Yön + Artçı»", t <= k["haf"] or k["mod"] != "yon",
          (P3U + " böl. 5.30 (artçı: çalışma süresi hafızadan uzunsa ya da başka yönsüz yedek yoksa)") if p3 else ("Hafıza bittiğinde: " + R["sonra"] + " — " + R["kaynak"]), "resmi" if p3 else R["durum"]),
        C("Açı bu rölenin ayar aralığında mı?", A67["metin"] + (" — " + A67["not"] if A67["not"] else ""), (f"{R['aralik'][0]}° … {R['aralik'][1]}°" if not R.get("secenek") else "yalnız " + ", ".join(f"{x}°" for x in R["secenek"])) + "; şartname: en büyük moment açısı ±90° aralığında ayarlanabilir olmalı",
          not A67["not"], SART + " m.(60); " + R["kaynak"], R["durum"]),
        C("Akım ve gerilim trafosu polaritesi", "ters" if p.get("at_ters") else "doğru", "primer enjeksiyonla doğrulanır", not p.get("at_ters"), KABUL, "resmi"),
    ]

    girdiler = at_girdi(p) + [
        G("Santralin gücü ve azami ihracat akımı", f"{fnum(num(p, 's_kva', 1870), 0)} kVA → {fa(i_n)}", "Jeneratör etiketi; bağlantı anlaşmasındaki kurulu güç",
          "Başlatma eşiğinin alt sınırı: ihracat akımı ileri yöndedir, eşik bunun üstünde olmalı", "Başlatma = 1,2 × In(santral)"),
        G("Jeneratör x″d ve yükseltici trafo uk", f"%{fnum(num(p, 'xd', 18), 0)} ve %{fnum(num(p, 'uk', 6), 1)}", "Jeneratör veri föyü, trafo etiketi",
          "Santralin şebekedeki arızaya vereceği akım küçüktür ve hızla söner; eşiğin üst sınırını ve süreyi bu belirler", "I″k ≈ In / (x″d + uk)"),
        G("Şebeke hattının R′ ve X′ değeri (ya da kablo tipi)", f"{fnum(num(p, 'r_km', 0.34), 2)} + j{fnum(num(p, 'x_km', 0.37), 2)} Ω/km", "Dağıtım şirketinin hat verisi; iletken çizelgesi",
          "Arıza akımının gerilime göre açısı arıza yolunun empedans açısıdır", "φ = atan(X′/R′) → açı kayması = −φ"),
        G("Rölenin «ileri» saydığı yön", "baradan hatta (AT'nin P1'i baraya bakıyor)", "Tek hat şeması, AT etiketi, röle kılavuzundaki bağlantı şeması",
          "Aynı açı ayarı AT ters bağlıysa tam ters yönü korur", "Yük altında güç işaretiyle doğrulanır"),
        G("İstenen temizleme süresi", f"{fnum(t, 2)} s", "Dağıtım şirketinin bağlantı görüşü / koruma tutanağı",
          "Süre, jeneratör katkısı sönmeden ve gerilim hafızası bitmeden dolmalı; üstteki yönsüz korumalardan önce açmalı", "Sabit zamanlı gecikme"),
        G("Rölenin kutuplama yöntemi", "pozitif bileşen gerilimi U1 (faz arası ve üç fazlı arızada)", "Röle kılavuzu",
          "Açı ayarının işareti ve referansı röle ailesine göre değişir", "Aşağıdaki «röle ailesine göre» çizelgesi"),
    ]
    adimlar = [
        A("İhracat akımı", "In = S / (√3 · U)", f"{fnum(num(p, 's_kva', 1870), 0)} / (1,732 × {fnum(un / 1000, 1)})", fa(i_n), "temel bağıntı", "resmi", ["Santralin gücü"]),
        A("Başlatma eşiği", "I> = 1,2 × In(santral)", f"1,2 × {fnum(i_n, 1)} = {fnum(oneri_bas, 1)} A → / {ct_p:g}", f"{fnum(oneri_bas / ct_p, 2)} ×In ({fnum(sek(oneri_bas, ct_p, ct_s), 3)} A sekonder)", URRA, "ikincil", ["Santralin gücü", "Akım trafosu oranı"], "Başlatma"),
        A("Santralin arıza katkısı", "I″k ≈ In / (x″d + uk)", f"{fnum(i_n, 1)} / ({fnum(num(p, 'xd', 18) / 100, 2)} + {fnum(num(p, 'uk', 6) / 100, 2)})", f"{fa(ik_s, 0)} = {fnum(ik_s / oneri_bas, 1)} × önerilen eşik", "TS EN 60909-0 yaklaşımı", "dogrulanacak", ["Jeneratör x″d ve yükseltici trafo uk"]),
        A("Arıza açısı", "φ = atan(X′ / R′)", f"atan({fnum(num(p, 'x_km', 0.37), 2)} / {fnum(num(p, 'r_km', 0.34), 2)})", f"{fnum(phi, 0)}° (akım gerilimden bu kadar geride)", "U = I · Z: gerilimle akım arasındaki açı arıza yolunun empedans açısıdır", "resmi", ["Şebeke hattının R′ ve X′ değeri"]),
        A("Zayıf kaynak düzeltmesi", "θ(hafıza) = açı[ E″ / (Z santral + Z hat) ]", f"santral {fnum(abs(m['zg']), 0)} Ω (neredeyse saf reaktans) + hat {fnum(abs(m['zh']), 1)} Ω; yük açısı düşülür", f"{fnum(th_haf, 0)}°",
          "Santral zayıf kaynaktır: kendi hattındaki arızada röledeki gerilim birkaç yüzdeye düşer, röle arıza öncesi gerilimi (hafıza) kullanır; o zaman açı bütün döngünün açısıdır", "resmi", ["Jeneratör x″d ve yükseltici trafo uk"]),
        A("Açma bölgesinin merkezi", "θc = iki ucun ortası", f"({fnum(th_olc, 0)}° + {fnum(th_haf, 0)}°) / 2 → 5°'ye yuvarla", f"{5 * round((th_olc + th_haf) / 2 / 5):g}° (akım gerilimden {abs(5 * round((th_olc + th_haf) / 2 / 5)):g}° geride)", "bölge iki uca da eşit pay bıraksın", "hesap", ["Şebeke hattının R′ ve X′ değeri (ya da kablo tipi)", "Jeneratör x″d ve yükseltici trafo uk"]),
        A("Röledeki açı ayarı — " + R["ad"], f"{R['param']} = {R['formul']}", f"φ = {-5 * round((th_olc + th_haf) / 2 / 5):g}°" + (f" — {O67['not']}" if O67["not"] else ""), O67["metin"].split(" = ")[1], R["kaynak"] + ("; " + KANIT if p3 else ""), R["durum"], ["Rölenin kutuplama yöntemi"], R["param"]),
        A("Açma bölgesinin sınırları", R["bolge"], f"{oneri_aci:g}° − {yari:g}° … {oneri_aci:g}° + {yari:g}°", f"{oneri_aci - yari:g}° … {oneri_aci + yari:g}° (akımın gerilime göre açısı)", R["kaynak"], R["durum"], [], "(sabit)" if p3 else "bölge genişliği"),
        A("Çalışma süresi", "t ≤ hafıza süresi ve jeneratör katkısı sönmeden", f"istenen {fnum(t, 2)} s", f"{fnum(t, 2)} s", "Dağıtım şirketi görüşü; " + P3U + " böl. 5.30", "ikincil", ["İstenen temizleme süresi"], "Çalışma süresi"),
    ]
    ayarlar_p3 = [
        S("Akım giriş", "Ifaz", "—", "Faz akımlarından çalışır", ),
        S("Başlatma", f"{fnum(oneri_bas / ct_p, 2)} ×In (şu an {fnum(num(p, 'baslatma', 0.75), 2)})", "0,10 … 4,00 ×In", "1,2 × ihracat akımı: yükte açmaz, santral katkısında açar", P3U + " Çizelge 82"),
        S("Yön modu", MOD[k["mod"]], "Yön / Yön + Artçı / Yönsüz", "Yön: yalnız ileri arızada açar. Artçı: gerilim kaybolursa yönsüz çalışır — süre hafızadan uzunsa gerekir", P3U + " böl. 5.30"),
        S("Açı kayması", f"{oneri_aci:g}° (şu an {fnum(k['base'], 0)}°)", "−180° … +179°", "Açma bölgesinin merkezi: akımın gerilime göre açısı (geride ise eksi)", P3U + " Çizelge 82; " + KANIT),
        S("Gecikme eğrisi ailesi / tipi", egri_ad, "SZ, IEC, IEEE, RI, Prg (ekrandaki örnek: IEC NI, k = 0,200)", "Santral katkısı küçük ve sönümlü olduğundan sabit süre önerilir; ters zamanlı seçilirse sönen akımda sürenin dolup dolmadığı denetlenir", P3U + " Çizelge 82"),
        S("Kademe 3 ve 4 (Iφ>>>, Iφ>>>>)", "isteğe bağlı: ters yön ya da ikinci eşik", "yalnız sabit zamanlı; başlatma 0,10 … 20,0 ×In", "İki yönlü korumada ikinci çift ters yöne bakar (açı kayması 180° kaydırılır)", P3U + " Çizelge 83; böl. 5.30 (iki yönlü örnek: 0° ve −180°)"),
        S("Çalışma süresi", f"{fnum(t, 2)} s", "0,04 … 300 s", "Dağıtım şirketinin istediği temizleme süresi − kesici süresi", P3U + " Çizelge 82"),
        S("Açı hafızası süresi", f"{fnum(k['haf'], 1)} s", "0,2 … 3,2 s", "Dipteki arızada gerilim çöker; röle bu süre boyunca arıza öncesi gerilimi kullanır. Süre ≥ çalışma süresi", P3U + " Çizelge 82"),
    ]
    ayarlar = ayarlar_p3 if p3 else [
        S(R["param"], O67["metin"].split(" = ")[1] + f" (şu anki merkez için {A67['metin'].split(' = ')[1]})", (f"{R['aralik'][0]}° … {R['aralik'][1]}°" if not R.get("secenek") else ", ".join(f"{x}°" for x in R["secenek"])),
          f"Açma bölgesinin merkezi {oneri_aci:g}°; bu rölede bağıntı: {R['formul']}" + (f". Uyarı: {O67['not']}" if O67["not"] else ""), R["kaynak"], R["durum"]),
        S("Kutuplama (referans) gerilimi", R["kutup"], "—", "Açının hangi gerilime göre ölçüldüğünü belirler; açı ayarındaki 90° farkı buradan gelir", R["kaynak"], R["durum"]),
        S("Açma bölgesinin genişliği", R["bolge"], "—", f"Benzetimde merkez ± {yari:g}° alındı", R["kaynak"], R["durum"]),
        S("Gerilim hafızası", R["hafiza"], "—", "Dipteki arızada gerilim çöker; röle bu süre boyunca arıza öncesi gerilimi kullanır. Çalışma süresi bunun içinde kalmalı", R["kaynak"], R["durum"]),
        S("En küçük kutuplama gerilimi", R["min_u"], "—", "Bunun altında yön çözülemez; hafıza devreye girer", R["kaynak"], R["durum"]),
        S("Hafıza bittiğinde / gerilim yokken", R["sonra"], "—", "Sayfadaki «Yön» ve «Yön + Artçı» modlarının bu röledeki karşılığı", R["kaynak"], R["durum"]),
        S(ALAN[k["rol"]]["basla"], f"{fa(oneri_bas)} primer ({fnum(sek(oneri_bas, ct_p, ct_s), 3)} A sekonder)", "—", "Başlatma: 1,2 × ihracat akımı. Birim rölenin kendi tabanına çevrilir (×In ya da pu)", ALAN[k["rol"]]["kaynak"], ALAN[k["rol"]]["durum"]),
        S(ALAN[k["rol"]]["egri"] + " · " + ALAN[k["rol"]]["sure"], f"sabit zamanlı · {fnum(t, 2)} s", "—", "Santral katkısı sönümlü olduğundan sabit süre", ALAN[k["rol"]]["kaynak"], ALAN[k["rol"]]["durum"]),
        S(ALAN[k["rol"]]["yon"], "ileri (baradan hatta)", "—", "Yön seçimi ve gerilim yokken davranış", ALAN[k["rol"]]["kaynak"], ALAN[k["rol"]]["durum"]),
    ]
    i_t = 2 * sek(oneri_bas, ct_p, ct_s); u_t = vt_s / S3
    test = [
        T("Düzen", f"Üç faza {fnum(u_t, 1)} V (faz–nötr), 0° / −120° / +120°; üç faza dengeli akım. Açılar her rölede aynı verilir: akımın kendi faz gerilimine göre açısı", f"Rölede U = %100, faz sırası doğru. Röleye girilmiş açı: {O67['metin']}", "—"),
        T("Merkez açıda açma", f"I = {fnum(i_t, 3)} A (2 × eşik), akım gerilimden {abs(oneri_aci):g}° {'geride' if oneri_aci < 0 else 'ileride'} ({oneri_aci:g}°)", f"Başlatma ≈ 30 ms, açma {fnum(gecikme(p, 2 * k['esik'], k['esik']), 2)} s", "±%1 ya da ±25 ms" if egri == "sz" else "±%5 ya da en az ±30 ms"),
        T("Üst sınır", "Akımı sabit tutup açıyı artı yönde yavaşça çevirin", f"Bırakma {oneri_aci + yari:g}° dolayında", "±2° (U > 5 V)" if p3 else "rölenin kılavuzundaki açı doğruluğu"),
        T("Alt sınır", "Açıyı eksi yönde çevirin", f"Bırakma {oneri_aci - yari:g}° dolayında", "±2°" if p3 else "rölenin kılavuzundaki açı doğruluğu"),
        T("Ters yön", f"Açı {norm(oneri_aci + 180):g}° (merkezin tam karşısı), I = 2 × eşik", "«Yön» modunda başlatma yok; «Yönsüz»de açar", "—"),
        T("Başlatma eşiği", "Merkez açıda akımı yavaşça yükseltin", f"Başlatma {fnum(sek(oneri_bas, ct_p, ct_s), 3)} A; bırakma ≈ {fnum(0.95 * sek(oneri_bas, ct_p, ct_s), 3)} A (oran 0,95)", "±%3 ya da anma değerinin ±%0,5'i"),
        T("Gerilim hafızası", "Gerilimleri sıfıra indirip aynı anda akımı verin", f"Süre ≤ hafıza ise açar ({fnum(k['haf'], 1)} s); uzunsa «Yön»de açmaz, «Yön + Artçı»da açar", "—"),
        T("Bu sayfadaki durum", f"I = {fnum(sek(m['i'], ct_p, ct_s), 3)} A, U = {fnum(k['u_sek'] / S3, 1)} V faz–nötr, açı {('—' if k['theta'] is None else fnum(k['theta'], 0) + '°')}", "AÇAR" if k["acar"] else "AÇMAZ", k["neden"]),
    ]

    # ---- grafikler ----
    g1 = {"baslik": "Açı nereden gelir: iki uç ve arıza direncinin etkisi", "x_ad": "Ark / arıza direnci (Ω)", "y_ad": "θ: akımın gerilime göre açısı (°)", "ymin": -180, "ymax": 60, "seriler": [], "yatay": [
        {"y": k["base"], "etiket": f"merkez {fnum(k['base'], 0)}° ({A67['metin']})", "renk": "#15803d"}, {"y": k["base"] + yari, "etiket": "üst sınır", "renk": "#dc2626"}, {"y": k["base"] - yari, "etiket": "alt sınır", "renk": "#dc2626"}]}
    L = max(num(p, "l_km", 5.0), 0.5); eic = ic_gerilim(m["e"], m["zg"], i_n); zkm = complex(num(p, "r_km", 0.34), num(p, "x_km", 0.37))
    rs = [x * 0.5 for x in range(0, 61)]
    g1["seriler"] = [{"ad": "gerilim ölçülürken (hattın açısı)", "renk": "#1a4d8f", "pts": [[r, round(-aci(zkm * L + r), 1)] for r in rs]},
                     {"ad": "hafızayla (santral + hat döngüsü)", "renk": "#dc2626", "pts": [[r, round(aci(eic / (m["zg"] + zkm * L + r)), 1)] for r in rs]},
                     {"ad": "XLPE kabloda, gerilim ölçülürken", "renk": "#7c3aed", "kesik": True, "pts": [[r, round(-aci(complex(0.32, 0.13) * L + r), 1)] for r in rs]}]
    # santral katkısının zamanla sönmesi (tipik zaman sabitleri — öğretim amaçlı)
    pts = [[n * 0.01, round(santral_akimi(p, n * 0.01), 1)] for n in range(0, 151)]
    g2 = {"baslik": "Süre neden kısa: santralin arıza katkısı hızla söner (üç fazlı, bara dibi)", "x_ad": "Zaman (s)", "y_ad": "Akım (A)", "zaman": True,
          "seriler": [{"ad": "santral katkısı", "renk": "#dc2626", "pts": pts}], "yatay": [{"y": k["esik"], "etiket": f"başlatma {fa(k['esik'])}", "renk": "#1a4d8f"}],
          "isaretler": [{"x": t_son, "etiket": f"açma {fnum(t_son, 2)} s ({egri_ad})"}] if t_son is not None and t_son <= 1.5 else []}

    # ---- çizelgeler ----
    satir = []
    for d, y_, ad in (("3f", "ileri", "Üç fazlı, ileride"), ("2f", "ileri", "İki fazlı, ileride"), ("1f", "ileri", "Faz–toprak, ileride (çapraz kutuplama)"), ("1f", "geri", "Faz–toprak, geride"), ("3f", "geri", "Üç fazlı, geride (santral içi)"), ("2f", "geri", "İki fazlı, geride"), ("ihracat", "ileri", "Yük: ihracat"), ("ithalat", "ileri", "Yük: ithalat")):
        mm = olc(p, d, y_); kk = karar(p, mm)
        satir.append([ad, f"{fa(mm['i'], 0)} ({fnum(mm['i'] / ct_p, 2)} ×In)", f"%{fnum(mm['ll'] / un * 100, 0)}", "—" if kk["theta"] is None else f"{fnum(kk['theta'], 0)}°",
                      "içinde" if kk["icinde"] else "dışında", "evet" if kk["ustunde"] else "hayır", "AÇAR" if kk["acar"] else "açmaz"])
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["_67_"],
        "sahne": c.sahne(fazor=fazor), "grafikler": [g1, g2],
        "anlatim": [
            "Röle «ileri»yi kendi akım trafosuna göre tanımlar: akım baradan hatta doğru akıyorsa ileridir. Bu hücrede ileri, şebeke tarafıdır.",
            f"Şebeke hattında bir kısa devre olduğunda santral arızayı besler. Rölenin ölçtüğü gerilim, akımın röle ile arıza arasındaki empedansta düşürdüğü gerilimdir (U = I · Z). "
            f"Bu yüzden akım gerilimden hattın empedans açısı kadar geri kalır: φ = atan(X′/R′) = {fnum(phi, 0)}°.",
            f"Ama santral zayıf bir kaynaktır: iç empedansı ({fnum(abs(m['zg']), 0)} Ω) hattınkinden ({fnum(abs(m['zh']), 1)} Ω) çok büyüktür. Kendi hattındaki arızada röledeki gerilim %{fnum(abs(m['zh']) / abs(m['zg'] + m['zh']) * 100, 0)} dolayına düşer; "
            f"röle arıza öncesi gerilimi hafızadan kullanır ve o zaman ölçtüğü açı bütün döngünün açısıdır: {fnum(th_haf, 0)}°.",
            f"Easergy P3 gerilimi 0° kabul eder ve akımın açısını ölçer; geride kalan akım eksi açıdır. Açma bölgesinin merkezi «açı kayması»dır; iki ucun ({fnum(th_olc, 0)}° ve {fnum(th_haf, 0)}°) ortasına konur: {oneri_aci:g}°. Bölge bu merkezin iki yanına 88° açılır.",
            "Röleye girilen sayı markaya göre değişir, çünkü her röle açıyı başka bir gerilime göre ve başka bir işaretle tanımlar: Easergy P3 pozitif bileşen gerilimine göre ve geride kalan akımı eksi sayar (−60°); "
            "ABB 615 geride kalanı artı sayar (+60°); dik bağlantılı röleler (P5, F60, MiCOM, Sepam, 7SR) akımı ona 90° dik duran sağlam faz arası gerilimle karşılaştırır ve 90° − φ ister (30°). Üçü de aynı açma bölgesini anlatır.",
            "Arıza direnci (ark) açıyı küçültür; arıza yolu trafodan geçiyorsa büyütür. Bölge ±88° geniş olduğu için bunların hepsi içeride kalır — açı ayarını «tam» tutturmak değil, merkezi doğru çeyreğe koymak önemlidir.",
            "Faz–toprak arızasında röle başka bir referans kullanır: arızalı fazın akımını, arızadan etkilenmeyen iki sağlam fazın arasındaki gerilimle (90° döndürerek) karşılaştırır. Bu gerilim dipteki arızada bile çökmez; hafıza gerekmez.",
            "Arıza santralin içindeyse şebeke besler; akım röleden ters yönde geçer ve 180° döner: bölgenin dışında kalır, kademe açmaz. O arızayı yönsüz kademeler (50/51) temizler.",
            "Santralin normal ihracat akımı da ileri yöndedir ve bölgenin içindedir. Onu arızadan ayıran yön değil eşiktir: başlatma 1,2 × ihracat akımının üstüne konur.",
            "Arıza rölenin dibindeyse gerilim sıfıra yakın düşer, açı ölçülemez. Röle arıza öncesindeki gerilimi kısa bir süre hafızada tutar ve yönü ona göre çözer.",
        ],
        "dersler": [
            "Açı = arıza yolunun empedans açısı. Havai hatta 45–70°, kabloda 15–35°, trafo arkasında 80° üstü.",
            "Easergy P3'te akım geride ise açı eksidir. Güçlü kaynakta açı kayması = −φ(hat); santral gibi zayıf kaynakta −60° … −75°. Başka röle ailesinde aynı arıza için başka sayı girilir; çizelgeye bakın.",
            "Zayıf kaynakta gerilim çöker: açı hafızası ve kısa çalışma süresi yönlü korumanın çalışma koşuludur.",
            "Açı markaya göre değişmez; açının röleye yazılışı değişir. Test cihazına her rölede aynı açıyı verirsiniz: akım kendi faz geriliminden φ kadar geride.",
            "Sınırlar hesapla bulunmaz, rölenin özelliğidir: P3'te merkez ± 88° (sabit), P5 / F60 / Sepam'da ± 90°, ABB 615'te ayarlanır (varsayılan ± 80°), MiCOM P14D'de «Trip Angle» ile ayarlanır.",
            "Gerilim hafızası da markaya göre değişir: P3 0,2–3,2 s, ABB 615 varsayılan 40 ms (!), F60 1 s, P14D 3,2 s, P5 5 s. Süreniz hafızadan uzunsa dipteki arızada kademe susar.",
            "Yön, yükü arızadan ayırmaz; eşik ayırır. İhracat akımı her zaman ileridir.",
            "AT ters bağlıysa röle tam ters yönü korur; yük altında güç işaretine bakarak yakalanır.",
            "Çalışma süresi açı hafızasından uzunsa dipteki arızada kademe susar: ya süreyi kısaltın ya «Yön + Artçı» seçin.",
        ],
        "tablolar": [
            {"baslik": "Bu ayarlarla her durumda röle ne ölçer, ne yapar", "cols": ["Durum", "Akım", "Gerilim", "Açı θ", "Bölge", "Eşik üstü", "Karar"], "rows": satir,
             "not": "Akım: en büyük faz akımı. Açı: pozitif bileşen akımının pozitif bileşen gerilimine göre açısı (P3 kutuplaması). Yük durumlarında güç katsayısı 0,98 / 0,90 alınmıştır."},
            {"baslik": f"Aynı açma bölgesi (merkez {oneri_aci:g}°: akım gerilimden {abs(oneri_aci):g}° geride) röle marka ve modeline göre nasıl girilir",
             "cols": ["Röle", "Parametre", "Bağıntı", "Girilecek değer", "Kutuplama gerilimi", "Açma bölgesi", "Gerilim hafızası", "Durum"],
             "rows": [[v["ad"] + (" ◀ seçili" if kk == k["rol"] else ""), v["param"], v["formul"], aci67(kk, oneri_aci)["metin"].split(" = ")[1] + (" (!)" if aci67(kk, oneri_aci)["not"] else ""), v["kutup"], v["bolge"], v["hafiza"], v["durum"]] for kk, v in ROLE67.items()],
             "not": "Her satır o rölenin kendi kılavuzundan okunmuştur: " + "; ".join(sorted({v["kaynak"].split(" böl.")[0].split(" «")[0].split(": ")[0] for v in ROLE67.values()})) + ". «ikincil» ve «dogrulanacak» satırlarda kılavuz yerel arşivde yoktur; bölge genişliği ± 90° varsayılmıştır. " + YONSUZ},
            alan_cizelgesi(),
            {"baslik": "Arıza yolu türüne göre tipik açı", "cols": ["Arıza yolu", "R′ + jX′ (Ω/km)", "φ", "P3 açı kayması"], "rows": [
                ["XLPE kablo (95 mm² Al dolayı)", "0,32 + j0,13", "22°", "−20° … −25°"], ["İnce havai hat (Swallow)", "1,07 + j0,40", "20°", "−20°"],
                ["Orta havai hat (Pigeon 3/0)", "0,34 + j0,37", "47°", "−45°"], ["Kalın havai hat (Hawk 477)", "0,12 + j0,35", "71°", "−70°"], ["Trafo arkası arıza", "X ≫ R", "80–87°", "−80°"]],
             "not": "Tipik katalog değerleridir (tahmini); kendi hattınızın değerini soldaki ayarlara girin. Bölge ±88° geniş olduğundan −45° ile −60° arası bir ayar bu yolların hepsini içeride tutar."},
        ],
    }
