"""Simetrili bileşenler tezgâhı: dengesiz üç fazör pozitif, negatif ve sıfır bileşene ayrılır; her arıza tipinde bileşen devrelerinin
nasıl bağlandığı ve hangi korumanın hangi bileşeni izlediği görülür.

Dayanak: dönüşüm ve bileşen devrelerinin bağlantısı temel bağıntıdır (Fortescue); arıza akımları ortak.ariza() ile (negatif bileşen empedansı
pozitife eşit alınır). Korumaların izlediği büyüklükler: P3U/en M/J006 (46: I2, 47: V2, 50N/51N ve 67N: Io, 59N: Vo) ve P3T/en M/L007
(64REF: I0Calc = faz akımlarından hesaplanan sıfır bileşen). Örnek başlatma değerleri ayarlanabilir; öneri değildir."""
from __future__ import annotations

import cmath
import math

from .ortak import A, A120, C, Cizim, G, K, P3T, P3U, S, T, aci, ariza, ctl, fazor, fnum, kutup, num, opt, simetrik

ID = "bilesen"
BASLIK = "Simetrili bileşenler"
IKON = "🔱"
GIRIS = ("Dengesiz üç akım, üç dengeli takımın toplamı olarak yazılabilir: pozitif (doğru sıra), negatif (ters sıra) ve sıfır bileşen. Koruma rölelerinin "
         "çoğu bu bileşenlerden birini izler. Bir durum seçin ya da fazörleri elle verin: ayrışmayı, bileşen devrelerinin bağlantısını ve hangi korumanın "
         "neyi gördüğünü izleyin.")

DURUM = {"dengeli": "Dengeli yük", "f3": "Üç fazlı kısa devre", "f2": "İki fazlı kısa devre (L2–L3)", "f1": "Faz–toprak kısa devre (L1)", "f2t": "İki faz–toprak kısa devre (L2–L3–toprak)",
         "kopuk": "Kopuk faz (L1 açık, yük altında)", "ters_sira": "Faz sırası ters (L2 ile L3 yer değişmiş)", "at_ters": "L2 akım trafosu ters bağlı", "tek_enj": "Sekonder test: yalnız L1'e akım", "ozel": "Elle: fazörleri ben vereceğim"}
ARIZA = ("f3", "f2", "f1", "f2t")
RENK = {"L1": "#8a4b12", "L2": "#111827", "L3": "#6b7280"}

KONTROLLER = [
    ctl("durum", "Durum", "sec", "f1", secenek=opt(*DURUM.items())),
    ctl("yuk", "Yük akımı", "sayi", 0.6, min=0.05, max=1.5, adim=0.05, birim="×In", goster={"durum": ["dengeli", "kopuk", "ters_sira", "at_ters"]}),
    ctl("i3", "Üç fazlı kısa devre akımı", "sayi", 8.0, min=1, max=30, adim=0.5, birim="×In", goster={"durum": list(ARIZA)}),
    ctl("k0", "Sıfır bileşen empedansı / pozitif (Z0/Z1)", "sayi", 3.0, min=0.3, max=10, adim=0.1, goster={"durum": ["f1", "f2t"]}, yardim="Havai hat ≈ 3; trafo AG çıkışı (Dyn) ≈ 1; direnç üzerinden topraklı şebekede çok büyük"),
    ctl("notr", "Şebekenin / yükün yıldız noktası", "sec", "toprakli", secenek=opt(("toprakli", "Topraklı (sıfır bileşen akabilir)"), ("yalitilmis", "Yalıtılmış (sıfır bileşenin yolu yok)")), goster={"durum": ["f1", "f2t", "kopuk"]}),
    ctl("ia", "IL1 büyüklüğü", "sayi", 1.0, min=0, max=10, adim=0.05, birim="×In", goster={"durum": ["ozel"]}),
    ctl("aa", "IL1 açısı", "sayi", 0, min=-180, max=180, adim=5, birim="°", goster={"durum": ["ozel"]}),
    ctl("ib", "IL2 büyüklüğü", "sayi", 1.0, min=0, max=10, adim=0.05, birim="×In", goster={"durum": ["ozel"]}),
    ctl("ab", "IL2 açısı", "sayi", -120, min=-180, max=180, adim=5, birim="°", goster={"durum": ["ozel"]}),
    ctl("ic", "IL3 büyüklüğü", "sayi", 0.5, min=0, max=10, adim=0.05, birim="×In", goster={"durum": ["ozel"]}),
    ctl("ac", "IL3 açısı", "sayi", 120, min=-180, max=180, adim=5, birim="°", goster={"durum": ["ozel"]}),
    ctl("s_i", "Örnek ayar › I> (50/51)", "sayi", 1.2, min=0.1, max=10, adim=0.05, birim="×In"),
    ctl("s_i2", "Örnek ayar › I2> (46)", "sayi", 0.20, min=0.02, max=2, adim=0.01, birim="×In"),
    ctl("s_io", "Örnek ayar › Io> (50N/51N)", "sayi", 0.10, min=0.01, max=2, adim=0.01, birim="×In"),
]


def akimlar(p: dict) -> dict:
    """Faz akımları (×In, karmaşık) ve — arıza durumlarında — röle noktasındaki faz gerilimleri (pu)."""
    d = p.get("durum") if p.get("durum") in DURUM else "f1"
    y = num(p, "yuk", 0.6)
    yal = p.get("notr") == "yalitilmis"
    U = None
    if d in ARIZA:
        z1 = 1j / num(p, "i3", 8.0)
        z0 = 1e6j if (yal and d in ("f1", "f2t")) else num(p, "k0", 3.0) * z1
        r = ariza({"f3": "3f", "f2": "2f", "f1": "1f", "f2t": "2ft"}[d], 1.0, z1 / 2, z0 / 2, z1 / 2, z0 / 2)
        I, U = r["I"], r["U"]
    elif d == "ozel":
        I = (kutup(num(p, "ia", 1), num(p, "aa", 0)), kutup(num(p, "ib", 1), num(p, "ab", -120)), kutup(num(p, "ic", 0.5), num(p, "ac", 120)))
    elif d == "tek_enj":
        I = (1 + 0j, 0j, 0j)
    else:
        b = [kutup(y, -25), kutup(y, -145), kutup(y, 95)]                       # dengeli yük, cos φ ≈ 0,9 geri
        if d == "kopuk":
            # topraklı yıldız yükte öbür iki faz değişmez; yıldız noktası yalıtılmış yükte (motor, üçgen) kalan iki faz seri kalır: √3/2 katı, zıt yönlü
            b = [0j, b[1], b[2]] if not yal else [0j, (b[1] - b[2]) / 2, (b[2] - b[1]) / 2]
        elif d == "ters_sira":
            b = [b[0], b[2], b[1]]
        elif d == "at_ters":
            b = [b[0], -b[1], b[2]]
        I = tuple(b)
    return {"d": d, "I": I, "U": U}


def run(p: dict) -> dict:
    o = akimlar(p); d, I, U = o["d"], o["I"], o["U"]
    i0, i1, i2 = simetrik(*I)
    m0, m1, m2 = abs(i0), abs(i1), abs(i2)
    imax = max(abs(x) for x in I)
    v0 = v2 = None
    if U:
        v0, _, v2 = (abs(x) for x in simetrik(*U))
    s_i, s_i2, s_io = num(p, "s_i", 1.2), num(p, "s_i2", 0.2), num(p, "s_io", 0.1)
    toplam_ok = abs((i0 + i1 + i2) - I[0]) < 1e-9
    a = A120

    # --- şema: bileşen devreleri ve bağlantıları ---
    c = Cizim(900, 320)
    ad = {"f3": "yalnız pozitif devre (arıza noktası kısa devre)", "f2": "pozitif ve negatif devre paralel", "f1": "üç devre seri", "f2t": "üç devre paralel"}
    yy = {"p": 44, "n": 132, "s": 220}
    etk = {"f3": ("p",), "f2": ("p", "n"), "f1": ("p", "n", "s"), "f2t": ("p", "n", "s")}.get(d, ())
    for k, baslik, alt in (("p", "Pozitif bileşen devresi", "E ve Z1"), ("n", "Negatif bileşen devresi", "Z2 (kaynak yok)"), ("s", "Sıfır bileşen devresi", "Z0 (kaynak yok)")):
        y = yy[k]
        c.kutu(60, y, 250, 56, baslik, alt, "vurgu" if k in etk else "pasif" if d in ARIZA else "normal")
        c.daire(330, y + 12, 3.5, "cizgi", dolgu="#334155"); c.daire(330, y + 44, 3.5, "cizgi", dolgu="#334155")
        c.hat(f"M310,{y + 12} H330", "cizgi", w=1.6); c.hat(f"M310,{y + 44} H330", "cizgi", w=1.6)
        c.yazi(338, y + 9, "F", "#64748b", 9); c.yazi(338, y + 55, "N", "#64748b", 9)
    c.yazi(185, 30, "Bileşen devreleri (F: arıza noktası, N: referans)", "#475569", 10.5, anchor="middle")
    hot = dict(hot=True, w=2.4)
    if d == "f3":
        c.hat(f"M330,{yy['p'] + 12} H372 V{yy['p'] + 44} H330", "ariza", **hot)
    elif d == "f2":
        c.hat(f"M330,{yy['p'] + 12} H372 V{yy['n'] + 12} H330", "ariza", **hot); c.hat(f"M330,{yy['p'] + 44} H356 V{yy['n'] + 44} H330", "ariza", **hot)
    elif d == "f1":
        c.hat(f"M330,{yy['p'] + 44} H356 V{yy['n'] + 12} H330", "ariza", **hot); c.hat(f"M330,{yy['n'] + 44} H356 V{yy['s'] + 12} H330", "ariza", **hot)
        c.hat(f"M330,{yy['s'] + 44} H384 V{yy['p'] + 12} H330", "ariza", **hot)
    elif d == "f2t":
        c.hat(f"M330,{yy['p'] + 12} H384 V{yy['s'] + 12} H330", "ariza", **hot); c.hat(f"M330,{yy['n'] + 12} H384", "ariza", **hot)
        c.hat(f"M330,{yy['p'] + 44} H362 V{yy['s'] + 44} H330", "ariza", **hot); c.hat(f"M330,{yy['n'] + 44} H362", "ariza", **hot)
    x0 = 430
    c.yazi(x0, 50, DURUM[d], "#1e293b", 13, kalin=True)
    c.yazi(x0, 70, ("Bağlantı: " + ad[d]) if d in ARIZA else "Arıza yok: bileşenler yalnız fazörlerden hesaplanır", "#b91c1c" if d in ARIZA else "#475569", 11.5)
    c.yazi(x0, 104, f"Pozitif bileşen  I1 = {fnum(m1, 2)} ×In ∠{fnum(aci(i1), 0)}°", "#1a4d8f", 12.5, kalin=True)
    c.yazi(x0, 128, f"Negatif bileşen  I2 = {fnum(m2, 2)} ×In ∠{fnum(aci(i2), 0)}°" + (f"   (I2/I1 = %{fnum(m2 / m1 * 100, 0)})" if m1 > 1e-6 else ""), "#b45309", 12.5, kalin=True)
    c.yazi(x0, 152, f"Sıfır bileşen  I0 = {fnum(m0, 2)} ×In ∠{fnum(aci(i0), 0)}°  (3·I0 = {fnum(3 * m0, 2)} ×In: toprak akımı)", "#15803d", 12.5, kalin=True)
    c.yazi(x0, 186, f"Faz akımları: IL1 {fnum(abs(I[0]), 2)} · IL2 {fnum(abs(I[1]), 2)} · IL3 {fnum(abs(I[2]), 2)} ×In", "#334155", 11.5)
    if U:
        c.yazi(x0, 206, f"Röle noktasında: V2 = %{fnum(v2 * 100, 0)} · V0 = %{fnum(v0 * 100, 0)} (faz gerilimine göre)", "#334155", 11.5)
    gorur = [("50/51", imax >= s_i), ("46", m2 >= s_i2), ("50N/51N", 3 * m0 >= s_io)]
    c.yazi(x0, 240, "Bu ayarlarla başlayan: " + (", ".join(k for k, v in gorur if v) or "hiçbiri"), "#1e293b", 12, kalin=True)
    c.yazi(x0, 260, "Başlamayan: " + (", ".join(k for k, v in gorur if not v) or "—"), "#64748b", 11.5)

    olcek = max(imax, 1e-9)
    f_faz = {"baslik": "Faz akımları (×In)", "vektorler": [fazor("L1", I[0], RENK["L1"]), fazor("L2", I[1], RENK["L2"]), fazor("L3", I[2], RENK["L3"])]}
    f_bil = {"baslik": "L1'in kuruluşu: I1 + I2 + I0", "vektorler": [fazor("I1", i1, "#1a4d8f"), fazor("I2", i2, "#b45309", bas=i1), fazor("I0", i0, "#15803d", bas=i1 + i2), fazor("IL1", I[0], RENK["L1"], kesik=True)],
             "not": "Uç uca eklenen üç bileşen L1 akımını verir. L2 için I1 ve I2 ters yönlerde 120° döndürülür."}
    f_tak = {"baslik": "Üç bileşen takımı", "vektorler": [fazor("1a", i1, "#1a4d8f"), fazor("1b", a * a * i1, "#1a4d8f", kesik=True), fazor("1c", a * i1, "#1a4d8f", kesik=True),
                                                          fazor("2a", i2, "#b45309"), fazor("2b", a * i2, "#b45309", kesik=True), fazor("2c", a * a * i2, "#b45309", kesik=True), fazor("0", i0, "#15803d")],
             "not": "Pozitif takım L1→L2→L3 sırasıyla, negatif takım ters sırayla döner; sıfır bileşen üç fazda aynıdır."}
    ozet = [
        K("Pozitif bileşen I1", f"{fnum(m1, 2)} ×In", "info", "yükü ve üç fazlı arızayı taşıyan bileşen"),
        K("Negatif bileşen I2", f"{fnum(m2, 2)} ×In", "warn" if m2 >= s_i2 else "ok", (f"I2/I1 = %{fnum(m2 / m1 * 100, 0)}" if m1 > 1e-6 else "pozitif bileşen yok") + " · dengesizliğin ölçüsü"),
        K("Sıfır bileşen 3·I0", f"{fnum(3 * m0, 2)} ×In", "warn" if 3 * m0 >= s_io else "ok", "nötr / toprak akımı = IL1 + IL2 + IL3"),
        K("En büyük faz akımı", f"{fnum(imax, 2)} ×In", "info", "faz aşırı akım kademesinin gördüğü"),
        K("Bileşen devreleri", ad[d].split(" (")[0] if d in ARIZA else "—", "info", "arıza tipine göre bağlantı"),
    ]
    kontroller = [
        C("Bileşenlerin toplamı faz akımını veriyor mu?", f"I0 + I1 + I2 = {fnum(abs(i0 + i1 + i2), 3)} ×In; IL1 = {fnum(abs(I[0]), 3)} ×In", "eşit olmalı", toplam_ok, "Simetrili bileşen dönüşümü (Fortescue): üç dengesiz fazör üç dengeli takımın toplamıdır", "hesap"),
        C("Negatif bileşen oranı", f"I2/I1 = %{fnum(m2 / m1 * 100, 0)}" if m1 > 1e-6 else "I1 = 0", "dengeli sistemde %0", None, "Negatif bileşen yalnız dengesizlikte ortaya çıkar: iki fazlı arıza, kopuk faz, ters bağlantı", "hesap"),
        C("Sıfır bileşenin yolu var mı?", f"3·I0 = {fnum(3 * m0, 2)} ×In", "yalnız toprak (nötr) üzerinden kapanan devrede akar", None, "Üç faz akımının toplamı sıfır değilse fark toprak ya da nötr üzerinden döner; üçgen sargı ve yalıtılmış yıldız noktası bu yolu keser", "hesap"),
    ]
    girdiler = [
        G("Üç faz akımının büyüklüğü ve açısı", " · ".join(f"{fnum(abs(x), 2)}∠{fnum(aci(x), 0)}°" for x in I), "Röle ölçüm ekranı ya da arıza kaydı (fazör görünümü); test cihazının çıkışları", "Bileşenler yalnız büyüklükten hesaplanamaz: açı gerekir", "I1, I2, I0 dönüşümü"),
        G("Şebekenin yıldız noktasının durumu", "topraklı / yalıtılmış / direnç üzerinden", "Tek hat şeması; trafo bağlantı grubu", "Sıfır bileşenin yolunu belirler: Z0 bu yola göre değişir", "Faz–toprak arızasında akımın büyüklüğü"),
        G("Arıza yerine kadar Z1 ve Z0", f"Z0/Z1 = {fnum(num(p, 'k0', 3), 1)}" if d in ("f1", "f2t") else "—", "Kısa devre hesabı; hat ve trafo verileri", "Bileşen devrelerinin empedansları; arıza tipine göre seri ya da paralel bağlanır", "I1 = E / (Z1 + Z2 + Z0) gibi"),
    ]
    adimlar = [
        A("Döndürme işleci", "a = 1∠120° ,  a² = 1∠240°", "—", "a = −0,5 + j0,866", "120°'lik döndürme", "hesap"),
        A("Pozitif bileşen", "I1 = (IL1 + a·IL2 + a²·IL3) / 3", "L2 120° ileri, L3 240° ileri döndürülür", f"{fnum(m1, 2)} ×In ∠{fnum(aci(i1), 0)}°", "Simetrili bileşen dönüşümü", "hesap", ["Üç faz akımının büyüklüğü ve açısı"]),
        A("Negatif bileşen", "I2 = (IL1 + a²·IL2 + a·IL3) / 3", "döndürme yönleri ters", f"{fnum(m2, 2)} ×In ∠{fnum(aci(i2), 0)}°", "Simetrili bileşen dönüşümü", "hesap", ["Üç faz akımının büyüklüğü ve açısı"], "I2> (46)"),
        A("Sıfır bileşen", "I0 = (IL1 + IL2 + IL3) / 3", "döndürme yok", f"{fnum(m0, 2)} ×In → 3·I0 = {fnum(3 * m0, 2)} ×In", "Simetrili bileşen dönüşümü", "hesap", ["Üç faz akımının büyüklüğü ve açısı"], "Io> (50N/51N)"),
    ]
    if d in ARIZA:
        formul = {"f3": "I1 = E / Z1 ;  I2 = I0 = 0", "f2": "I1 = E / (Z1 + Z2) ;  I2 = −I1 ;  I0 = 0", "f1": "I1 = I2 = I0 = E / (Z1 + Z2 + Z0)", "f2t": "I1 = E / (Z1 + Z2∥Z0) ;  I2 ve I0 paralel kolları paylaşır"}[d]
        adimlar.append(A("Bileşen devrelerinin bağlantısı", formul, f"Z1 = Z2 = 1/{fnum(num(p, 'i3', 8), 1)} pu" + (f", Z0 = {fnum(num(p, 'k0', 3), 1)}·Z1" if d in ("f1", "f2t") and p.get("notr") != "yalitilmis" else ""),
                         f"I1 = {fnum(m1, 2)} · I2 = {fnum(m2, 2)} · I0 = {fnum(m0, 2)} ×In", "Arıza noktasındaki sınır koşullarından çıkan bağlantı", "hesap", ["Arıza yerine kadar Z1 ve Z0", "Şebekenin yıldız noktasının durumu"]))
    ayarlar = [
        S("I2> (46) › izlenen büyüklük", "negatif bileşen akımı", "—", "Dengesiz yükü ve iki fazlı arızayı yük akımının altında bile ayırt eder", P3U + " böl. 5.12 (negatif bileşen aşırı akım)"),
        S("Io> › hesaplanan sıfır bileşen (I0Calc)", "IL1 + IL2 + IL3", "—", "Toroid yoksa toprak akımı faz akımlarının toplamından alınır; akım trafosu hataları da toplama girer", P3T + " böl. 6.22 (64REF: I0Calc)"),
        S("V2> (47) · Vo> (59N)", "negatif ve sıfır bileşen gerilimi", "—", "Aynı dönüşüm gerilimlere uygulanır: faz sırası hatası, gerilim trafosu sigortası, toprak arızası", P3U + " böl. 5.14 (47), 5.27 (59N)"),
    ]
    test = [
        T("Tek faza akım", "Yalnız L1'e 1,00 ×In", "Röle I1 = I2 = I0 = 0,33 ×In okur; 3·I0 = 1,00 ×In", "I2> ayarı 0,20 ×In ise başlatma L1 = 0,60 ×In'de"),
        T("İki faza zıt akım", "L2 ve L3'e seri 1,00 ×In (zıt yönlü)", "I1 = I2 = 0,58 ×In; I0 = 0", "1/√3"),
        T("Üç faz ters sıra", "Dengeli 1,00 ×In, L2 ile L3 açıları yer değiştirilmiş", "I2 = 1,00 ×In; I1 = 0", "46 ve 47'nin en yalın testi"),
        T("Bu sayfadaki durum", " · ".join(f"{k} {fnum(abs(x), 2)}∠{fnum(aci(x), 0)}°" for k, x in zip(("L1", "L2", "L3"), I)), f"I1 = {fnum(m1, 2)} · I2 = {fnum(m2, 2)} · 3I0 = {fnum(3 * m0, 2)} ×In", "röle ölçüm ekranında"),
    ]
    satir = lambda ad_, buyukluk, deger, ayar, gor: [ad_, buyukluk, deger, ayar, "başlar" if gor else "başlamaz"]      # noqa: E731
    tablo = [satir("50/51 faz aşırı akım", "en büyük faz akımı", f"{fnum(imax, 2)} ×In", f"{fnum(s_i, 2)} ×In", imax >= s_i),
             satir("46 negatif bileşen", "I2", f"{fnum(m2, 2)} ×In", f"{fnum(s_i2, 2)} ×In", m2 >= s_i2),
             satir("50N/51N toprak aşırı akım", "3·I0", f"{fnum(3 * m0, 2)} ×In", f"{fnum(s_io, 2)} ×In", 3 * m0 >= s_io)]
    if U:
        tablo += [["47 negatif bileşen gerilimi", "V2", f"%{fnum(v2 * 100, 0)}", "—", "arıza süresince görülür" if v2 > 0.05 else "görülmez"],
                  ["59N nötr gerilim kayması", "3·V0", f"%{fnum(3 * v0 * 100, 0)}", "—", "toprak arızasında görülür" if v0 > 0.02 else "görülmez"]]
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["46", "47"],
        "sahne": c.sahne(fazorler=[f_faz, f_bil, f_tak]),
        "cubuklar": [{"baslik": "Faz akımları ve bileşenleri", "kategoriler": ["IL1", "IL2", "IL3", "I1", "I2", "3·I0"], "alt": ["faz", "faz", "faz", "pozitif", "negatif", "toprak"], "y_ad": "×In",
                      "seriler": [{"ad": "büyüklük", "renk": "#1a4d8f", "deger": [round(abs(x), 3) for x in I] + [round(m1, 3), round(m2, 3), round(3 * m0, 3)]}]}],
        "anlatim": [
            "Dengeli üç fazlı akımda üç fazör eşit boyda ve 120° aralıklıdır. Dengesizlikte bu bozulur; ama her dengesiz üçlü, üç dengeli takımın toplamı olarak yazılabilir.",
            "Pozitif takım şebekenin kendi sırasıyla döner (L1→L2→L3): yükü ve motoru çeviren bileşendir. Negatif takım ters sırayla döner: motoru frenler, rotoru ısıtır. Sıfır bileşen üç fazda aynı yöndedir: yalnız toprak ya da nötr üzerinden dönebilir.",
            "Röle bu ayrışmayı her ölçmede yapar: L2 ve L3 fazörlerini 120° ve 240° döndürüp toplar. Döndürme yönü pozitif için bir, negatif için öbür yöndedir.",
            f"Şu an: I1 = {fnum(m1, 2)}, I2 = {fnum(m2, 2)}, 3·I0 = {fnum(3 * m0, 2)} ×In." + (" Arıza tipine göre bileşen devreleri " + ad[d] + " bağlanır." if d in ARIZA else ""),
            "Üç fazlı arızada yalnız pozitif bileşen vardır. İki fazlı arızada pozitif ve negatif eşit, sıfır yoktur. Faz–toprak arızasında üçü de eşittir: bu yüzden toprak akımı 3·I0'dır.",
            "Yıldız noktası yalıtılmışsa ya da arada üçgen sargı varsa sıfır bileşenin yolu kesilir: faz–toprak arızasında akım akmaz, yalnız gerilim kayar (V0). Toprak arızası o zaman gerilimden ya da kapasitif akımdan bulunur.",
        ],
        "dersler": [
            "Tek faza 1 A verince röle I2 = 0,33 A okur: negatif bileşen ayarını test ederken bu üçte bir unutulmaz.",
            "Negatif bileşen yük akımından bağımsızdır: iki fazlı arıza akımı yük akımından küçük olsa bile 46 onu görür.",
            "3·I0 = IL1 + IL2 + IL3. Toroid bunu doğrudan ölçer; üç akım trafosunun toplamı ise akım trafosu hatalarını da toprak akımı gibi gösterir.",
            "Ters faz sırası ve ters akım trafosu arıza değildir ama röleye negatif bileşen olarak görünür: devreye almada fazör kontrolü bu yüzden yapılır.",
        ],
        "tablolar": [{"baslik": "Hangi koruma neyi izler, bu durumda ne görür", "cols": ["Koruma", "İzlediği büyüklük", "Bu durumda", "Örnek ayar", "Sonuç"], "rows": tablo,
                      "not": "Örnek ayarlar soldaki ayarlardan gelir; öneri değildir. Gerilim satırları yalnız arıza durumlarında hesaplanır."}],
    }
