"""Negatif bileşen aşırı gerilim / hatalı faz sırası (ANSI 47) — Easergy P3 «V2>» kademesi.

Dayanak: P3U/en M/J006 böl. 5.14 (gerilim dengesizliği ve faz sırası tersliği; temel frekanstaki negatif bileşen V2; GT sigortası atarsa kilit matrisiyle
kilitlenir), Çizelge 58 (başlatma %2 … %120, süre 0,08 … 300 s, bırakma oranı 0,95, doğruluk ±1 birim, süre ±%5 ya da ±200 ms); böl. 5.13 (akıma dayalı
hatalı faz sırası I2>>: I2/I1 > %80, motor yol alırken). Şebekenin izin verilen gerilim dengesizliği (%2) TS EN 50160'a dayanır — «dogrulanacak»."""
from __future__ import annotations

from .ortak import A, A120, C, G, K, P3U, S, T, aci, ctl, fnum, fz, kademe_test, num, opt, simetrik, tek_hat

ID = "v2_47"
BASLIK = "Negatif bileşen gerilim (47)"
IKON = "🔃"
GIRIS = ("Üç fazın gerilimi eşit değilse ya da fazlar yanlış sırada bağlanmışsa gerilimde negatif bileşen vardır. Röle bunu hesaplar: küçük değerler "
         "dengesizliği, %100'e yakın değerler faz sırasının ters olduğunu gösterir.")

OLAY = {"dengeli": "Dengeli şebeke", "dusuk": "Bir fazın gerilimi düşük", "ters": "Faz sırası ters (iki faz yer değişmiş)", "sigorta": "Bir gerilim trafosu sigortası atmış", "kopuk": "Şebekede bir faz kopuk (yük tarafında)"}

KONTROLLER = [
    ctl("vt_s", "Gerilim trafosu sekonderi (faz arası)", "sec", 100, secenek=opt((100, "100 V"), (110, "110 V"))),
    ctl("olay", "Durum", "sec", "dusuk", secenek=opt(*OLAY.items())),
    ctl("eksik", "Düşük fazın eksiği", "sayi", 15, min=0, max=100, adim=1, birim="%", goster={"olay": ["dusuk"]}),
    ctl("v2", "Röle › V2> başlatma", "sayi", 20, min=2, max=120, adim=1, birim="%"),
    ctl("t", "Röle › Çalışma süresi", "sayi", 20.0, min=0.08, max=300, adim=0.02, birim="s"),
    ctl("xd", "Jeneratörün negatif bileşen reaktansı x2", "sayi", 18, min=8, max=35, adim=1, birim="%", yardim="V2'nin jeneratörde ne kadar I2 doğuracağını gösterir"),
]


def gerilimler(p: dict) -> tuple[complex, complex, complex]:
    o = p.get("olay") if p.get("olay") in OLAY else "dusuk"; a = A120
    if o == "dusuk":
        return (1 - num(p, "eksik", 15) / 100) + 0j, a * a, a
    if o == "ters":
        return 1 + 0j, a, a * a
    if o == "sigorta":
        return 0j, a * a, a
    if o == "kopuk":
        return -0.5 + 0j, a * a, a                           # yük tarafında kopuk faz: öbür iki fazın ortalamasına yakın bir gerilim görülür (motor yükü yokken)
    return 1 + 0j, a * a, a


def run(p: dict) -> dict:
    o = p.get("olay") if p.get("olay") in OLAY else "dusuk"; vt_s = num(p, "vt_s", 100)
    ua, ub, uc = gerilimler(p); u0, u1, u2 = simetrik(ua, ub, uc)
    v2 = abs(u2) * 100; esik = num(p, "v2", 20); basla = v2 >= esik
    i2 = v2 / max(num(p, "xd", 18), 1) * 100
    c = tek_hat(("Santral / motor", ""), ("Şebeke", OLAY[o]), ("47  V2>", ("BAŞLADI — " + fnum(num(p, "t", 20.0), 1) + " s sonra açar") if basla else "başlamadı"), "acti" if basla else "normal", None, "", ileri=False, gt_ad=f"GT …/{vt_s:g} V")
    c.yazi(500, 190, f"V2 = %{fnum(v2, 1)} · V1 = %{fnum(abs(u1) * 100, 0)} · V0 = %{fnum(abs(u0) * 100, 0)}", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, f"Bu dengesizlik jeneratörde yaklaşık I2 ≈ V2 / x2 = %{fnum(i2, 0)} In akıtır", "#334155", 11)
    fazor = {"baslik": "Faz gerilimleri ve bileşenleri", "vektorler": [fz("UL1", abs(ua) * 100, aci(ua), abs(ua), "#8a4b12"), fz("UL2", abs(ub) * 100, aci(ub), abs(ub), "#111827"), fz("UL3", abs(uc) * 100, aci(uc), abs(uc), "#6b7280"),
                                                                 fz("V2", v2, aci(u2), abs(u2), "#dc2626", kesik=True), fz("V1", abs(u1) * 100, aci(u1), abs(u1), "#15803d", kesik=True)], "not": "V2 = (UL1 + a²·UL2 + a·UL3) / 3; büyüklükler % Un."}
    ozet = [
        K("Kademe", "BAŞLADI" if basla else "başlamadı", "warn" if basla else "ok", f"{fnum(num(p, 't', 20.0), 1)} s sonra açar" if basla else f"eşik %{fnum(esik, 0)}"),
        K("Negatif bileşen V2", f"%{fnum(v2, 1)}", "bad" if v2 > 2 else "ok", f"{fnum(v2 / 100 * vt_s / 1.732, 1)} V sekonder (faz–nötr)"),
        K("Pozitif bileşen V1", f"%{fnum(abs(u1) * 100, 0)}", "info", ""),
        K("Jeneratörde doğacak I2", f"≈ %{fnum(i2, 0)} In", "bad" if i2 > 8 else "ok", "V2 / x2"),
        K("Dengesizlik oranı V2/V1", f"%{fnum(v2 / max(abs(u1) * 100, 1e-6) * 100, 1)}" if abs(u1) > 1e-6 else "∞", "info", "şebekede izin verilen ≈ %2"),
    ]
    kontroller = [
        C("Faz sırası tersliği görülüyor mu?", "ters sırada V2 = %100", f"eşik %{fnum(esik, 0)} < %100", esik < 100, "Faz sırası tersse bütün gerilim negatif bileşendir — " + P3U + " böl. 5.14", "resmi"),
        C("Eşik şebekenin doğal dengesizliğinin üstünde mi?", f"%{fnum(esik, 0)}", "> %2–3", esik >= 3, "Aralık %2 … %120: " + P3U + " Çizelge 58. Şebekede izin verilen dengesizlik ≈ %2 (TS EN 50160)", "dogrulanacak"),
        C("GT sigortası atınca yanlış açma önleniyor mu?", "bir sigorta atınca V2 = %33", "60FL işaretiyle kilit matrisinden kilitlenmeli" if esik <= 33.3 else "eşik %33'ün üstünde: kendiliğinden başlamaz", None,
          "Gerilim kademeleri GT denetimi (60FL) işaretiyle kilitlenebilir — " + P3U + " böl. 5.14, 6.8", "resmi"),
        C("Jeneratörü dengesizliğe karşı koruyan bu kademe mi?", f"V2 = %{fnum(esik, 0)}'de I2 ≈ %{fnum(esik / max(num(p, 'xd', 18), 1) * 100, 0)} In olur", "hayır — ısıl koruma 46 (I2>) ile yapılır", None,
          "I2 ≈ V2 / x2 (jeneratörün negatif bileşen reaktansı küçüktür): %2 gerilim dengesizliği %10 akım dengesizliği demektir (hesap)", "resmi"),
    ]
    girdiler = [
        G("Faz sırası ve GT bağlantısı", "L1-L2-L3", "Devreye alma ölçümü (faz sırası göstergesi)", "Ters sıra motoru ters döndürür; jeneratörü senkronlayamazsınız", "V2 ≈ %100 ise sıra ters"),
        G("Şebekenin gerilim dengesizliği", "≈ %1–2", "Ölçüm (röle ölçüm sayfası: V2)", "Eşik bunun rahatça üstünde olmalı", "V2> ≥ %3–5 (alarm) / %20 (açma)"),
        G("GT sigorta / MCB düzeni", "60FL etkin mi?", "Tek hat şeması; röle ayarı", "Sigorta atınca V2 = %33 görünür: gerçek dengesizlik değildir", "Kilit matrisi"),
        G("Korunan makinenin dengesizlik dayanımı", f"x2 = %{fnum(num(p, 'xd', 18), 0)}", "Jeneratör / motor veri föyü", "Küçük gerilim dengesizliği büyük akım dengesizliği doğurur", "46 ile birlikte düşünülür"),
    ]
    adimlar = [
        A("Negatif bileşen gerilim", "V2 = (UL1 + a²·UL2 + a·UL3) / 3", f"{fnum(abs(ua) * 100, 0)}∠{fnum(aci(ua), 0)}°, {fnum(abs(ub) * 100, 0)}∠{fnum(aci(ub), 0)}°, {fnum(abs(uc) * 100, 0)}∠{fnum(aci(uc), 0)}°", f"%{fnum(v2, 1)}", P3U + " böl. 3.10", "resmi"),
        A("Bir faz %x düşükse", "V2 = x / 3", f"{fnum(num(p, 'eksik', 15), 0)} / 3", f"%{fnum(num(p, 'eksik', 15) / 3, 1)}", "simetrili bileşenler", "resmi"),
        A("Başlatma", "doğal dengesizlik < V2> < %100", "faz sırası ve ağır dengesizlik için", f"%{fnum(esik, 0)}", "ekrandaki örnek %20", "ikincil", ["Şebekenin gerilim dengesizliği"], "V2> Başlatma"),
        A("Jeneratördeki akım dengesizliği", "I2 ≈ V2 / x2", f"{fnum(v2, 1)} / {fnum(num(p, 'xd', 18), 0)}", f"%{fnum(i2, 0)} In", "eşdeğer devre", "resmi", ["Korunan makinenin dengesizlik dayanımı"]),
    ]
    ayarlar = [
        S("V2> › Başlatma", f"%{fnum(esik, 0)}", "%2 … %120; ekrandaki örnek %20", "Faz sırası tersliği ve ağır dengesizlik", P3U + " Çizelge 58"),
        S("V2> › Çalışma süresi", f"{fnum(num(p, 't', 20.0), 2)} s", "0,08 … 300 s; ekrandaki örnek 20,00 s", "Geçici olaylarda (tek fazlı arıza) açmasın", P3U + " Çizelge 58"),
        S("V2>> · V2>>> kademeleri", "isteğe bağlı", "üç kademe", "Ör. düşük eşikli uzun süreli alarm + yüksek eşikli hızlı açma (faz sırası)", P3U + " böl. 5.14"),
        S("Kilit matrisi › GT denetimi (60FL) → V2>", "bağlı", "—", "Sigorta atmasında yanlış açmayı önler", P3U + " böl. 6.8"),
    ]
    test = kademe_test("V2>", esik, "% (tek fazı düşürerek: eksik = 3 × V2)", num(p, "t", 20.0), True, "±%1 birim", "±%5 ya da ±200 ms", 0.95, 1) + [
        T("Tek faz düşürme", f"Üç faza anma gerilimi; bir fazı %{fnum(min(3 * esik, 100), 0)} düşürün ({fnum(vt_s / 1.732 * (1 - min(3 * esik, 100) / 100), 1)} V)", f"V2 = %{fnum(min(esik, 33.3), 1)}: başlatma", "±%1 birim"),
        T("Faz sırası", "İki faz geriliminin yerini değiştirin", "V2 ≈ %100: başlar", "—"),
        T("Bu sayfadaki durum", OLAY[o], "BAŞLAR" if basla else "başlamaz", f"V2 = %{fnum(v2, 1)}"),
    ]
    g = {"baslik": "Bir fazın gerilimi düştükçe negatif bileşen", "x_ad": "Düşük fazın eksiği (%)", "y_ad": "V2 (%)", "ymin": 0,
         "seriler": [{"ad": "V2 = eksik / 3", "renk": "#dc2626", "pts": [[x, x / 3] for x in range(0, 101, 2)]}], "yatay": [{"y": esik, "etiket": f"V2> %{fnum(esik, 0)}"}, {"y": 2, "etiket": "şebeke sınırı ≈ %2", "renk": "#15803d"}],
         "isaretler": [{"x": num(p, "eksik", 15), "etiket": "şu an"}] if o == "dusuk" else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["_47_"],
        "sahne": c.sahne(fazor=fazor), "grafikler": [g],
        "anlatim": [
            "Röle üç faz gerilimini simetrili bileşenlerine ayırır. Dengeli ve doğru sıralı şebekede yalnız pozitif bileşen vardır; negatif bileşen sıfırdır.",
            "Bir fazın gerilimi düşerse negatif bileşen eksikliğin üçte biri kadar olur: %15 düşük bir faz, %5 V2 demektir.",
            "İki faz yer değiştirmişse (ters sıra) gerilimin tamamı negatif bileşen görünür: V2 ≈ %100. Devreye almada bu kademe hemen başlıyorsa önce faz sırasına bakın.",
            "Küçük bir gerilim dengesizliği makinede büyük akım dengesizliği doğurur, çünkü makinenin negatif bileşene gösterdiği reaktans küçüktür. Bu yüzden ısıl koruma akımdan (46) yapılır; 47 kaba bir denetimdir.",
            "Gerilim trafosunun bir sigortası atarsa röle bir fazı sıfır görür: V2 = %33. Bu gerçek bir dengesizlik değildir; 60FL işaretiyle kilitlenir.",
        ],
        "dersler": [
            "V2 ≈ %100 → faz sırası ters. V2 ≈ %33 → bir GT sigortası atık. V2 birkaç yüzde → gerçek dengesizlik.",
            "Bir fazın %x eksikliği V2 = x/3 verir: %20'lik eşik için bir fazı %60 düşürmeniz gerekir.",
            "47 jeneratörü dengesiz yüke karşı korumaz; onu 46 yapar.",
        ],
        "tablolar": [{"baslik": "Duruma göre bileşenler", "cols": ["Durum", "V1", "V2", "V0", "Kademe"], "rows": [
            (lambda t3, ad: [ad, f"%{fnum(abs(t3[1]) * 100, 0)}", f"%{fnum(abs(t3[2]) * 100, 1)}", f"%{fnum(abs(t3[0]) * 100, 0)}", "başlar" if abs(t3[2]) * 100 >= esik else "—"])(simetrik(*gerilimler({**p, "olay": oo})), OLAY[oo]) for oo in OLAY]}],
    }
