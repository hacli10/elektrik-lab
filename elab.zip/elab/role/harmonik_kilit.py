"""2. harmonikle demeraj tespiti (ANSI 68F2) ve 5. harmonikle aşırı uyarma tespiti (ANSI 68H5).

Dayanak: P3U/en M/J006 böl. 5.33 (2. harmoniğin temel bileşene oranı bütün faz akımlarında ölçülür; herhangi bir fazda ayarı aşarsa başlatma; başlatma
ve açma işaretleri başka kademeleri kilitlemek için kullanılır; kilitlenecek kademenin gecikmesi 60 ms'den uzun olmalı), Çizelge 87 (10–100 %, 0,03–300 s;
2. harmonik genliği AT anma akımının en az %2'si olmalı), böl. 5.34 ve Çizelge 88 (5. harmonik: aşırı uyarma; 10–100 %). Dalga biçimleri öğretim
amaçlı yalın modellerdir: demeraj tek yönlü kesik sinüs darbesi, aşırı uyarma akı diz noktasını aşınca iki yönde akan darbeler."""
from __future__ import annotations

import cmath
import math

from .ortak import A, C, G, K, P3U, S, T, URRA, ctl, fnum, num, opt, tek_hat

ID = "harmonik_kilit"
BASLIK = "Harmonik kilit (68F2 · 68H5)"
IKON = "〰"
GIRIS = ("Trafo demerajı ve aşırı uyarma, aşırı akım ve diferansiyel röleye arıza gibi görünür. İkisini arızadan ayıran dalga biçimidir: demeraj akımı "
         "2. harmonik, aşırı uyarma akımı 5. harmonik bakımından zengindir. Röle oranı ölçer, ayarı aşınca ilgili kademeyi kilitler.")

DALGA = {"demeraj": "Trafo demerajı (tek yönlü darbeler)", "ariza": "Kısa devre (doğru akım bileşenli sinüs)", "doymus": "Kısa devre, akım trafosu doymuş", "asiri": "Aşırı uyarma (gerilim yüksek)"}
N = 128

KONTROLLER = [
    ctl("dalga", "Akımın türü", "sec", "demeraj", secenek=opt(*DALGA.items())),
    ctl("tepe", "Tepe akım", "sayi", 6.0, min=0.2, max=20, adim=0.1, birim="×In"),
    ctl("alfa", "Demeraj darbesinin iletim açısı (yarım)", "sayi", 90, min=40, max=175, adim=5, birim="°", goster={"dalga": ["demeraj"]}, yardim="Çekirdek ne kadar derin doyarsa darbe o kadar geniş; geniş darbede 2. harmonik oranı düşer"),
    ctl("doy_aci", "AT'nin doyduğu açı (pozitif yarım dalgada)", "sayi", 70, min=20, max=170, adim=5, birim="°", goster={"dalga": ["doymus"]}),
    ctl("v_pct", "Gerilim", "sayi", 125, min=100, max=145, adim=1, birim="%Un", goster={"dalga": ["asiri"]}),
    ctl("f2", "Röle › 68F2 başlatma (If2/If1)", "sayi", 15, min=10, max=100, adim=1, birim="%"),
    ctl("f5", "Röle › 68H5 başlatma (If5/If1)", "sayi", 35, min=10, max=100, adim=1, birim="%"),
    ctl("t_k", "Kilitlenen kademenin gecikmesi", "sayi", 0.10, min=0.0, max=2.0, adim=0.01, birim="s"),
]


def dalga(p: dict) -> list[float]:
    """Bir periyotluk akım (×In); N örnek."""
    tip = p.get("dalga") if p.get("dalga") in DALGA else "demeraj"
    tepe = num(p, "tepe", 6.0)
    out = []
    for n in range(N):
        th = 2 * math.pi * n / N
        if tip == "demeraj":
            a = math.radians(num(p, "alfa", 90))
            v = max(0.0, math.cos(th - math.pi) - math.cos(a)) / (1 - math.cos(a))            # darbe periyodun ortasında
        elif tip == "ariza":
            v = (math.sin(th - math.pi / 2) + math.exp(-n / N / 2.5)) / 2                      # sinüs + sönen doğru akım bileşeni
        elif tip == "doymus":
            s = math.sin(th)
            v = 0.0 if (s > 0 and th > math.radians(num(p, "doy_aci", 70))) else s
        else:
            vv = num(p, "v_pct", 125) / 100; diz = 1.05                                       # çekirdeğin diz noktası ≈ %105 Un (öğretim amaçlı)
            f = vv * math.sin(th)
            v = (math.copysign(abs(f) - diz, f) / max(vv - diz, 1e-6)) if abs(f) > diz else 0.0   # akı dizi aşınca iki yönde darbe
        out.append(tepe * v)
    return out


def harmonik(x: list[float], h: int) -> float:
    """h. harmoniğin genliği (tepe)."""
    return abs(sum(v * cmath.exp(-2j * math.pi * h * n / N) for n, v in enumerate(x))) * 2 / N


def run(p: dict) -> dict:
    tip = p.get("dalga") if p.get("dalga") in DALGA else "demeraj"
    x = dalga(p)
    H = [harmonik(x, h) for h in range(1, 8)]
    h1 = max(H[0], 1e-9); o2, o5 = H[1] / h1, H[4] / h1
    f2, f5, tk = num(p, "f2", 15) / 100, num(p, "f5", 35) / 100, num(p, "t_k", 0.1)
    genlik_ok = H[1] / math.sqrt(2) >= 0.02
    s2 = o2 >= f2 and genlik_ok; s5 = o5 >= f5
    bek2, bek5 = tip == "demeraj", tip == "asiri"
    c = tek_hat(("Besleme", ""), ("Trafo", DALGA[tip].split(" (")[0]), ("68F2 · 68H5", ("2. harm. kilidi" if s2 else "") + (" " if s2 and s5 else "") + ("5. harm. kilidi" if s5 else "") or "kilit yok"),
                "acti" if (s2 or s5) else "normal", 620 if tip in ("ariza", "doymus") else None, "sag", gt=False, ileri=False)
    c.yazi(500, 190, f"2. harmonik / temel = %{fnum(o2 * 100, 0)} (ayar %{fnum(f2 * 100, 0)}) → " + ("BAŞLADI" if s2 else "başlamadı"), "#1a4d8f" if s2 else "#334155", 11.5, kalin=True)
    c.yazi(500, 208, f"5. harmonik / temel = %{fnum(o5 * 100, 0)} (ayar %{fnum(f5 * 100, 0)}) → " + ("BAŞLADI" if s5 else "başlamadı"), "#b45309" if s5 else "#334155", 11.5, kalin=True)
    c.yazi(500, 226, f"Temel bileşen {fnum(h1 / math.sqrt(2), 2)} ×In (etkin)", "#334155", 11)
    ozet = [
        K("68F2 (demeraj)", "BAŞLADI" if s2 else "başlamadı", "ok" if s2 == bek2 else "bad", ("doğru" if s2 == bek2 else "YANLIŞ") + " — " + ("demeraj" if bek2 else "demeraj değil")),
        K("68H5 (aşırı uyarma)", "BAŞLADI" if s5 else "başlamadı", "ok" if s5 == bek5 else "bad", ("doğru" if s5 == bek5 else "YANLIŞ") + " — " + ("aşırı uyarma" if bek5 else "aşırı uyarma değil")),
        K("2. harmonik oranı", f"%{fnum(o2 * 100, 0)}", "info", f"genlik {fnum(H[1] / math.sqrt(2), 2)} ×In"),
        K("5. harmonik oranı", f"%{fnum(o5 * 100, 0)}", "info", f"3. harmonik %{fnum(H[2] / h1 * 100, 0)}"),
        K("Temel bileşen", f"{fnum(h1 / math.sqrt(2), 2)} ×In", "info", "aşırı akım kademesinin gördüğü"),
    ]
    kontroller = [
        C("Demeraj doğru tanınıyor mu?", f"If2/If1 = %{fnum(o2 * 100, 0)} → " + ("başladı" if s2 else "başlamadı"), "demerajda başlar, arızada başlamaz", s2 == bek2,
          "Oran bütün fazlarda ölçülür; herhangi birinde ayarı aşarsa başlar — " + P3U + " böl. 5.33", "resmi"),
        C("Aşırı uyarma doğru tanınıyor mu?", f"If5/If1 = %{fnum(o5 * 100, 0)} → " + ("başladı" if s5 else "başlamadı"), "aşırı uyarmada başlar", s5 == bek5, P3U + " böl. 5.34", "resmi"),
        C("Kilitlenen kademenin gecikmesi yeterli mi?", f"{fnum(tk * 1000, 0)} ms", "> 60 ms", tk > 0.06, "Harmonik ölçümü tam bir periyot ister; kilitlenecek kademenin gecikmesi 60 ms'den uzun olmalı — " + P3U + " böl. 5.33, 5.34", "resmi"),
        C("2. harmoniğin genliği ölçülebilir mi?", f"{fnum(H[1] / math.sqrt(2) * 100, 1)} % In", "≥ %2 In(AT)", genlik_ok if tip == "demeraj" else None, P3U + " Çizelge 87 notu (5 A'lik AT'de 100 Hz bileşeni 100 mA'i aşmalı)", "resmi"),
        C("68F2 ayarı", f"%{fnum(f2 * 100, 0)}", "%10 … %100; uygulamada %15–20", 0.10 <= f2 <= 0.25, "Aralık: " + P3U + " Çizelge 87. Uygulama değeri: " + URRA + " (ABB/SEL varsayılanları %15–20)", "ikincil"),
    ]
    girdiler = [
        G("Hangi kademe kilitlenecek ve gecikmesi", f"gecikme {fnum(tk * 1000, 0)} ms", "Ayar föyü; kilit matrisi", "68F2 kendisi açmaz; başka kademeyi kilitler. Gecikmesiz kademe kilit yetişmeden açar", "Gecikme > 60 ms"),
        G("Trafonun demeraj akımı ve 2. harmonik oranı", "tipik 6–10 ×In; %15–60", "Üretici verisi; önceki enerjilendirme kayıtları (arıza kaydedici)", "Ayar bu oranın altında, arızadaki oranın üstünde olmalı", "68F2 başlatma"),
        G("Trafonun aşırı uyarma dayanımı", "V/f sınırı (ör. %110 sürekli)", "Trafo etiketi / üretici", "5. harmonik kilidi yalnız diferansiyel kademenin yanlış açmasını önler; trafoyu aşırı uyarmaya karşı 24 korur", "68H5 başlatma"),
        G("Akım trafosunun doyma olasılığı", "büyük arıza akımı + doğru akım bileşeni", "AT sınıfı ve yükü; kısa devre hesabı", "Doymuş AT'nin sekonder akımında da 2. harmonik vardır: gerçek arızada kilit oluşabilir", "Kilitsiz ani kademe bırakılır"),
    ]
    adimlar = [
        A("Temel bileşen", "I1 = (2/N) · |Σ i(n) · e^(−j2πn/N)|", "bir periyotluk örneklerden", f"{fnum(h1 / math.sqrt(2), 2)} ×In etkin", "Fourier ayrıştırması (röle temel bileşeni böyle hesaplar)", "resmi"),
        A("2. harmonik oranı", "If2 / If1", f"{fnum(H[1], 2)} / {fnum(h1, 2)}", f"%{fnum(o2 * 100, 0)}", P3U + " böl. 5.33", "resmi", ["Trafonun demeraj akımı ve 2. harmonik oranı"], "68F2 başlatma"),
        A("5. harmonik oranı", "If5 / If1", f"{fnum(H[4], 2)} / {fnum(h1, 2)}", f"%{fnum(o5 * 100, 0)}", P3U + " böl. 5.34", "resmi", ["Trafonun aşırı uyarma dayanımı"], "68H5 başlatma"),
        A("Kilit süresi koşulu", "kilitlenen kademenin gecikmesi > 60 ms", f"{fnum(tk * 1000, 0)} ms", "uygun" if tk > 0.06 else "yetersiz", P3U + " böl. 5.33", "resmi", ["Hangi kademe kilitlenecek ve gecikmesi"]),
    ]
    ayarlar = [
        S("68F2 › Başlatma (2. harmonik / temel)", f"%{fnum(f2 * 100, 0)}", "%10 … %100", "Demerajın en düşük 2. harmonik oranının altı", P3U + " Çizelge 87"),
        S("68F2 › Çalışma süresi", "0,03 s", "0,03 … 300 s", "Yalnız başlatma işareti kilit için kullanılıyorsa önemsizdir", P3U + " böl. 5.33"),
        S("68H5 › Başlatma (5. harmonik / temel)", f"%{fnum(f5 * 100, 0)}", "%10 … %100", "Aşırı uyarmada diferansiyeli ya da duyarlı aşırı akımı kilitlemek için", P3U + " Çizelge 88"),
        S("Kilit matrisi › 68F2 başlatma → I> (gecikmeli kademe)", "bağlı", "—", "İşaret bir kademeye bağlanmadıkça hiçbir etkisi olmaz", P3U + " böl. 5.33"),
        S("Akım giriş", "IL", "IL / I'L", "Hangi sargı tarafının akımı", P3U + " Çizelge 87"),
    ]
    test = [
        T("68F2 başlatma", f"50 Hz 1,00 ×In + 100 Hz bileşen; 100 Hz'i yavaşça artırın", f"Başlatma 100 Hz = %{fnum(f2 * 100, 0)} × 50 Hz bileşeninde", "±%1 birim"),
        T("Genlik koşulu", "50 Hz 0,05 ×In + 100 Hz %50", "100 Hz genliği %2 In'in altındaysa başlamaz", P3U + " Çizelge 87"),
        T("Kilit", f"I> eşiğinin üstünde 50 Hz + %{fnum(f2 * 100 + 5, 0)} 100 Hz", "I> başlar ama açmaz; 100 Hz kaldırılınca gecikme sonunda açar", "—"),
        T("68H5 başlatma", "50 Hz 1,00 ×In + 250 Hz bileşen", f"Başlatma 250 Hz = %{fnum(f5 * 100, 0)}'de", "±%2 birim"),
        T("Bu sayfadaki dalga", DALGA[tip], ("68F2 başlar" if s2 else "68F2 başlamaz") + "; " + ("68H5 başlar" if s5 else "68H5 başlamaz"), f"If2/If1 %{fnum(o2 * 100, 0)}, If5/If1 %{fnum(o5 * 100, 0)}"),
    ]
    g = {"baslik": "Akımın dalga biçimi (iki periyot)", "x_ad": "Zaman (ms)", "y_ad": "Akım (×In)", "zaman": True,
         "seriler": [{"ad": "akım", "renk": "#dc2626", "pts": [[round(n * 20 / N, 2), round(x[n % N], 3)] for n in range(2 * N + 1)]},
                     {"ad": "temel bileşen (50 Hz)", "renk": "#1a4d8f", "kesik": True, "pts": [[round(n * 20 / N, 2), round(h1 * math.cos(2 * math.pi * n / N - cmath.phase(sum(v * cmath.exp(-2j * math.pi * k / N) for k, v in enumerate(x))) * -1), 3)] for n in range(2 * N + 1)]}]}
    alfalar = list(range(40, 180, 5))
    g2 = {"baslik": "Demeraj darbesi genişledikçe 2. harmonik oranı düşer", "x_ad": "İletim açısı (yarım, °)", "y_ad": "If2 / If1 (%)", "ymin": 0,
          "seriler": [{"ad": "2. harmonik oranı", "renk": "#1a4d8f", "pts": [[a, round((lambda xx: harmonik(xx, 2) / max(harmonik(xx, 1), 1e-9) * 100)(dalga({"dalga": "demeraj", "tepe": 1, "alfa": a})), 1)] for a in alfalar]}],
          "yatay": [{"y": f2 * 100, "etiket": f"68F2 ayarı %{fnum(f2 * 100, 0)}"}], "isaretler": [{"x": num(p, "alfa", 90), "etiket": "şu an"}] if tip == "demeraj" else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["68f2", "68h5", "soguk_yuk", "87t"],
        "sahne": c.sahne(), "grafikler": [g, g2],
        "cubuklar": [{"baslik": "Harmonik bileşenler (temel bileşenin yüzdesi)", "kategoriler": [f"{h}." for h in range(1, 8)], "alt": ["50 Hz", "100", "150", "200", "250", "300", "350"], "y_ad": "%",
                      "seriler": [{"ad": "ölçülen", "renk": "#dc2626", "deger": [round(v / h1 * 100, 1) for v in H]}]}],
        "anlatim": [
            "Trafo enerjilendiğinde çekirdek bir yöne doyar; mıknatıslanma akımı yalnız o yönde, darbeler halinde akar. Bu akım AT anma akımının birkaç katıdır ve aşırı akım kademesini başlatır.",
            "Tek yönlü darbe dizisi simetrik değildir: çift harmonikleri, en çok da 2. harmoniği (100 Hz) içerir. Kısa devre akımı ise sinüs biçimlidir; 2. harmoniği yok denecek kadar azdır.",
            f"Röle her fazda 2. harmoniğin temel bileşene oranını ölçer. Şu anki dalgada oran %{fnum(o2 * 100, 0)}; ayar %{fnum(f2 * 100, 0)}.",
            "Çekirdek ne kadar derin doyarsa darbe o kadar geniş olur ve 2. harmonik oranı düşer. Düşük kayıplı yeni trafolarda oran %10'a kadar inebilir: ayar çok yüksekse demeraj tanınmaz.",
            "Gerilim yükselince (ya da frekans düşünce) çekirdek iki yönde birden doyar: akım simetrik ama sivri olur; tek harmonikler, özellikle 5. harmonik büyür. 68H5 bunu tanır.",
            "Doymuş bir akım trafosunun sekonder akımı da bozuktur ve 2. harmonik içerir. Gerçek bir arızada kilit oluşmasın diye kilitsiz bir ani kademe bırakılır.",
        ],
        "dersler": [
            "68F2 ve 68H5 açma yapmaz; başka kademeleri kilitler. Kilit matrisinde bağlanmadıysa etkisizdir.",
            "Kilitlenen kademenin gecikmesi 60 ms'den uzun olmalı: harmonik ölçümü bir periyot sürer.",
            "2. harmonik ayarı: çok yüksek → demerajda açma; çok düşük → AT doymuş arızada gecikme. Uygulama %15–20.",
            "Aşırı uyarmaya karşı trafoyu 24 (V/f) korur; 68H5 yalnız yanlış açmayı önler.",
        ],
        "tablolar": [{"baslik": "Dalga türüne göre harmonik oranları (bu modelle)", "cols": ["Dalga", "If2/If1", "If3/If1", "If5/If1", "68F2", "68H5"], "rows": [
            (lambda xx, ad: [ad, f"%{fnum(harmonik(xx, 2) / harmonik(xx, 1) * 100, 0)}", f"%{fnum(harmonik(xx, 3) / harmonik(xx, 1) * 100, 0)}", f"%{fnum(harmonik(xx, 5) / harmonik(xx, 1) * 100, 0)}",
                             "başlar" if harmonik(xx, 2) / harmonik(xx, 1) >= f2 else "—", "başlar" if harmonik(xx, 5) / harmonik(xx, 1) >= f5 else "—"])(dalga({**p, **q}), ad)
            for q, ad in (({"dalga": "demeraj", "alfa": 60}, "Demeraj, dar darbe (60°)"), ({"dalga": "demeraj", "alfa": 90}, "Demeraj, yarım dalga (90°)"), ({"dalga": "demeraj", "alfa": 150}, "Demeraj, geniş darbe (150°)"),
                          ({"dalga": "ariza"}, "Kısa devre"), ({"dalga": "doymus", "doy_aci": 70}, "Kısa devre, AT doymuş"), ({"dalga": "asiri", "v_pct": 115}, "Aşırı uyarma %115"), ({"dalga": "asiri", "v_pct": 135}, "Aşırı uyarma %135"))],
            "not": "Dalga modelleri öğretim amaçlıdır (tahmini); gerçek oranlar trafonun yapısına, artık akıya ve kapama anına bağlıdır."}],
    }
