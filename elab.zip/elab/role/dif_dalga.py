"""87T dalga görünümü: trafo diferansiyel rölesinin iki ucun akımından ne hesapladığı, dalga üzerinde — dış arızada akım trafosu doyması,
demeraj, iç arıza, doymuş akım trafosuyla iç arıza ve sarımlar arası kısa devre.

Röle modeli P3T32'ninkidir (P3T/en M/L007 böl. 6.30): fark akımı Id = |IW + I'W| (burada iki uç aynı yönde ölçülüp çıkarılır), tutucu akım
Ib = (|IW| + |I'W|)/2; karakteristik: başlatma (Ib < 0,5 In), eğim 1, eğim 2; 2. harmonik kilidi %5–30; kilitsiz dI>> kademesi 5–40 × In.
Büyüklükler bir periyotluk Fourier süzgeciyle anlık örneklerden hesaplanır. Dalga biçimleri: akım trafosu doyması lab/zaman.at_sim, demeraj
role/demeraj_trafo (ikisi de öğretim amaçlı, tahmini). Sarımlar arası kısa devrede uç akımındaki değişim ΔI ≈ f²/uk kabaca bir kabuldür (tahmini):
amaç, küçük sarım arızalarının uç akımında neden görünmediğini göstermektir."""
from __future__ import annotations

import math

from . import dalga as D
from . import demeraj_trafo as DM
from ..lab import zaman
from .dif87t import esik
from .ortak import A, C, Cizim, G, K, P3T, S, T, ctl, fnum, num, opt

ID = "dif_dalga"
BASLIK = "87T: dalga üzerinde"
IKON = "🪞"
GIRIS = ("Diferansiyel röle trafoya giren ve çıkan akımı örnek örnek karşılaştırır. Bu sayfada beş durumu dalga üzerinde görürsünüz: akım trafosu doyan dış arıza, "
         "demeraj, iç arıza, doymuş akım trafosuyla iç arıza ve sarımlar arası kısa devre. Her birinde fark akımının, tutucu akımın ve 2. harmoniğin nasıl "
         "oluştuğunu ve rölenin kararını izleyin.")
DURUM = {"dis": "Dış arıza, AG akım trafosu doyuyor", "demeraj": "Enerjilendirme (demeraj)", "ic": "İç arıza", "ic_doy": "İç arıza, OG akım trafosu doyuyor", "sarim": "Sarımlar arası kısa devre"}
M = 100
PER = 6

KONTROLLER = [
    ctl("durum", "Durum", "sec", "dis", secenek=opt(*DURUM.items())),
    ctl("i", "Arıza akımı", "sayi", 8, min=0.5, max=30, adim=0.5, birim="×In", goster={"durum": ["dis", "ic", "ic_doy"]}),
    ctl("xr", "X/R oranı", "sayi", 12, min=0, max=40, adim=1, goster={"durum": ["dis", "ic", "ic_doy"]}),
    ctl("alf", "Doyan akım trafosunun gerçek doğruluk sınır katsayısı", "sayi", 10, min=2, max=40, adim=1, goster={"durum": ["dis", "ic_doy"]}, yardim="Bkz. Akım trafosu doyması sayfası"),
    ctl("sarim", "Kısa devre olan sarımların oranı", "sayi", 5, min=1, max=40, adim=1, birim="%", goster={"durum": ["sarim"]}),
    ctl("uk", "Trafo uk", "sayi", 6, min=4, max=12, adim=0.5, birim="%", goster={"durum": ["sarim"]}),
    ctl("yuk", "Yük akımı", "sayi", 0.7, min=0, max=1.2, adim=0.05, birim="×In", goster={"durum": ["sarim"]}),
    ctl("id_min", "Röle › dI> başlatma", "sayi", 25, min=5, max=50, adim=1, birim="%In"),
    ctl("egim1", "Röle › Eğim 1", "sayi", 50, min=5, max=100, adim=5, birim="%"),
    ctl("ib2", "Röle › Eğim 2 başlangıcı", "sayi", 2.0, min=1.0, max=3.0, adim=0.1, birim="×In"),
    ctl("egim2", "Röle › Eğim 2", "sayi", 150, min=100, max=200, adim=5, birim="%"),
    ctl("h2_blok", "Röle › 2. harmonik kilidi etkin", "onay", True),
    ctl("h2", "Röle › 2. harmonik başlatma", "sayi", 15, min=5, max=30, adim=1, birim="%", goster={"h2_blok": [True]}),
    ctl("id2", "Röle › dI>> (kilitsiz kademe)", "sayi", 10, min=5, max=40, adim=0.5, birim="×In"),
]


def _doymus(i_ef: float, xr: float, alf: float) -> tuple[list, list]:
    """(ideal, doymuş) sekonder akım — ×In, 100 örnek/periyot. Doyma akımı alf × In olacak biçimde ölçeklenir."""
    s = zaman.at_sim(round(i_ef, 4), 1.0, round(alf, 4), round(alf, 4), float(xr), 0.0, False, 0.0, PER)
    return s["ideal"], s["gercek"]


def dalgalar(p: dict) -> dict:
    """İki ucun akımı (×In, anlık; aynı yönde ölçülmüş): i1 OG (trafoya giren), i2 AG (trafodan çıkan, OG'ye indirgenmiş)."""
    d = p.get("durum") if p.get("durum") in DURUM else "dis"
    i, xr, alf = num(p, "i", 8), num(p, "xr", 12), num(p, "alf", 10)
    n = PER * M + 1
    ts = [k * 20 / M for k in range(n)]
    if d == "dis":
        ideal, doy = _doymus(i, xr, alf)
        i1, i2 = ideal[:n], doy[:n]
    elif d == "ic":
        ideal, _ = _doymus(i, xr, 1e6)
        i1, i2 = ideal[:n], [0.0] * n
    elif d == "ic_doy":
        _, doy = _doymus(i, xr, alf)
        i1, i2 = doy[:n], [0.0] * n
    elif d == "demeraj":
        b = DM.benzet(0, 0.6, 1.2, 0.25, 0.008, PER)                      # en kötü kapama, %60 kalıcı akı (Trafo demerajı sayfasının varsayılanı)
        N = DM.N
        i1 = [D.KOK2 * (b["i"][int(k * N / M)] + (b["i"][min(int(k * N / M) + 1, len(b["i"]) - 1)] - b["i"][int(k * N / M)]) * (k * N / M - int(k * N / M))) for k in range(n)]
        i2 = [0.0] * n
    else:
        f, uk, y = num(p, "sarim", 5) / 100, num(p, "uk", 6) / 100, num(p, "yuk", 0.7)
        di = f * f / uk                                                      # uç akımındaki artış (×In) — kaba kabul
        i1 = [D.KOK2 * (y * math.sin(D.W * t / 1000 - 0.45) + di * math.sin(D.W * t / 1000 - 1.4)) for t in ts]
        i2 = [D.KOK2 * y * math.sin(D.W * t / 1000 - 0.45) for t in ts]
    return {"d": d, "t": ts, "i1": i1, "i2": i2}


def run(p: dict) -> dict:
    w = dalgalar(p); d, ts, i1, i2 = w["d"], w["t"], w["i1"], w["i2"]
    fark = [a - b for a, b in zip(i1, i2)]
    m1, m2, md = D.temel(i1, M), D.temel(i2, M), D.temel(fark, M)
    h2 = D.temel(fark, M, 2)
    ib = [(a + b) / 2 for a, b in zip(m1, m2)]
    es = [esik(x, p) for x in ib]
    kilit_var = bool(p.get("h2_blok", True)); f2 = num(p, "h2", 15) / 100; id2 = num(p, "id2", 10)
    j0 = M                                                                    # ilk periyot dolduktan sonrası değerlendirilir
    ustte = [md[j] > es[j] for j in range(len(ts))]
    kilitli = [kilit_var and md[j] > 1e-6 and h2[j] / md[j] >= f2 for j in range(len(ts))]
    j_ac = next((j for j in range(j0, len(ts)) if ustte[j] and not kilitli[j]), None)
    j_ac2 = next((j for j in range(j0 // 2, len(ts)) if md[j] >= id2), None)
    acti = j_ac is not None or j_ac2 is not None
    t_ac = min(ts[j] for j in (j_ac, j_ac2) if j is not None) if acti else None
    beklenen = d in ("ic", "ic_doy", "sarim")
    jm = max(range(j0, len(ts)), key=lambda j: md[j] - es[j])                # eşiğe en çok yaklaşılan / en çok aşılan an
    o2 = h2[jm] / md[jm] if md[jm] > 1e-6 else 0.0
    dogru = acti == beklenen if d != "sarim" else True                       # sarım arızasını görememek 87T'nin sınırıdır: «yanlış» değil
    neden = ("kilitsiz kademe dI>>" if (j_ac2 is not None and (j_ac is None or j_ac2 <= j_ac)) else "dI>") if acti else ("2. harmonik kilidi" if any(ustte[j] and kilitli[j] for j in range(j0, len(ts))) else "fark akımı eşiğin altında")

    c = Cizim(900, 300)
    y = 84
    c.kutu(20, y - 27, 110, 54, "OG şebeke", "")
    c.kutu(770, y - 27, 110, 54, "AG bara", "yük" if d == "sarim" else "")
    sicak1 = True; sicak2 = d in ("dis", "sarim")
    c.hat(f"M130,{y} H398", "L1", hot=sicak1, w=3); c.hat(f"M502,{y} H770", "L1", hot=sicak2, w=3)
    c.daire(430, y, 34, "cizgi", dolgu="#fff"); c.daire(470, y, 34, "cizgi", dolgu="#fff"); c.sarim(430, y, "ucgen", "#334155", 14); c.sarim(470, y, "yildiz", "#334155", 14)
    c.dikdortgen(360, y - 50, 180, 100, "soluk", None, 1.2, True); c.yazi(450, y - 56, "korunan bölge", "#64748b", 10, anchor="middle")
    c.toroid(330, y, 7, 17); c.toroid(570, y, 7, 17); c.yazi(330, y - 24, "AT (OG)", "#475569", 10, anchor="middle"); c.yazi(570, y - 24, "AT (AG)" + (" — doyuyor" if d == "dis" else ""), "#b91c1c" if d == "dis" else "#475569", 10, anchor="middle")
    if d == "ic_doy":
        c.yazi(330, y - 36, "doyuyor", "#b91c1c", 10, anchor="middle")
    c.hat(f"M330,{y + 18} V168 H360", "cizgi", kesik=True, w=1.4); c.hat(f"M570,{y + 18} V168 H540", "cizgi", kesik=True, w=1.4)
    c.kutu(360, 148, 180, 44, "87T", ("AÇTI — " + neden) if acti else "açmadı", ("acti" if dogru else "gecersiz") if acti else "normal")
    if d == "dis":
        c.simsek(690, y - 10, 1.2); c.yazi(700, y + 30, "dış arıza", "#b91c1c", 11, kalin=True, anchor="middle")
    elif d in ("ic", "ic_doy", "sarim"):
        c.simsek(446, y - 12, 1.2 if d != "sarim" else 0.8); c.yazi(450, y + 48, "sarım arızası" if d == "sarim" else "iç arıza", "#b91c1c", 10.5, kalin=True, anchor="middle")
    c.yazi(20, 222, f"En kritik anda: fark Id = {fnum(md[jm], 2)} ×In · tutucu Ib = {fnum(ib[jm], 2)} ×In · eşik {fnum(es[jm], 2)} ×In · 2. harmonik %{fnum(o2 * 100, 0)}", "#1e293b", 12, kalin=True)
    c.yazi(20, 244, (f"Röle {fnum(t_ac, 0)} ms'de açtı ({neden})." if acti else f"Röle açmadı: {neden}."), "#15803d" if dogru else "#b91c1c", 12.5, kalin=True)
    c.yazi(20, 266, {"dis": "Doğrusu: açmamak — arıza korunan bölgenin dışında.", "demeraj": "Doğrusu: açmamak — arıza yok, trafo mıknatıslanıyor.", "ic": "Doğrusu: açmak.", "ic_doy": "Doğrusu: açmak — doyma 2. harmonik üretse de.",
                     "sarim": "Küçük sarım arızası uç akımında görünmez: bu, diferansiyel korumanın sınırıdır; gaz rölesi ve basınç emniyeti bunun içindir."}[d], "#475569", 11.5)

    ozet = [
        K("87T", "AÇTI" if acti else "açmadı", "ok" if dogru and (acti == beklenen) else "warn" if d == "sarim" else "bad", (neden + (f" · {fnum(t_ac, 0)} ms" if acti else "")) + (" — doğru" if acti == beklenen else " — sınır" if d == "sarim" else " — YANLIŞ")),
        K("Fark akımı Id", f"{fnum(md[jm], 2)} ×In", "info", f"en büyük {fnum(max(md[j0:]), 2)} ×In"),
        K("Tutucu akım Ib", f"{fnum(ib[jm], 2)} ×In", "info", "(|IW| + |I'W|) / 2"),
        K("Eşik (o andaki)", f"{fnum(es[jm], 2)} ×In", "info", "tutucu akım büyüdükçe yükselir"),
        K("2. harmonik / temel", f"%{fnum(o2 * 100, 0)}", "ok" if (o2 >= f2) == (d in ("demeraj", "dis")) or not kilit_var else "warn", f"kilit ayarı %{fnum(f2 * 100, 0)}" if kilit_var else "kilit kapalı"),
    ]
    kontroller = [
        C("Röle doğru karar veriyor mu?", ("açtı" if acti else "açmadı") + f" — {neden}", "dış arıza ve demerajda açmaz; iç arızada açar", (acti == beklenen) if d != "sarim" else None,
          "Fark akımı karakteristiğin üstünde ve kilit yoksa dI> açar; fark akımı dI>> ayarını aşarsa kilit dinlenmeden açılır — " + P3T + " böl. 6.30", "resmi"),
        C("2. harmonik kilidi", f"oran %{fnum(o2 * 100, 0)}; ayar %{fnum(f2 * 100, 0)}" if kilit_var else "kapalı", "demerajda ve doymuş akım trafosunda ayarın üstünde", None if not kilit_var else ((o2 >= f2) if d in ("demeraj", "dis") else None),
          "2. harmonik oranı ayarı aşınca dI> kademesi kilitlenir (ayar %5–30); kilitsiz dI>> kademesi bundan etkilenmez — " + P3T + " böl. 6.30", "resmi"),
        C("Kilitsiz kademe demerajda açmıyor mu?", f"fark akımının en büyüğü {fnum(max(md[j0 // 2:]), 2)} ×In", f"< dI>> = {fnum(id2, 1)} ×In", (max(md[j0 // 2:]) < id2) if d in ("demeraj", "dis") else None,
          "dI>> ayarı en büyük demeraj temel bileşeninin ve dış arızadaki sahte fark akımının üstünde seçilir (5–40 × In)", "resmi"),
    ]
    if d == "sarim":
        kontroller.append(C("Sarım arızası uç akımında görünüyor mu?", f"ΔI ≈ f²/uk = {fnum(md[jm], 2)} ×In (sarımların %{fnum(num(p, 'sarim', 5), 0)}'i)", f"dI> başlatma {fnum(num(p, 'id_min', 25), 0)} %In", True if acti else None,
                            "Kısa devre olan birkaç sarımda büyük akım dolaşır ama sargının geri kalanına göre sarım sayısı küçük olduğundan uçlardaki akım az değişir. Değer kaba bir kabuldür", "tahmini"))
    girdiler = [
        G("İki tarafın akım trafosu verileri", "sınıf, yük, gerçek doğruluk sınır katsayısı", "AT etiketleri ve test raporları; kablo boyları", "Dış arızada iki uç aynı akımı farklı ölçerse sahte fark akımı doğar", "eğim 2 ve dI>> ayarı"),
        G("En büyük dış arıza akımı ve X/R", f"{fnum(num(p, 'i', 8), 1)} ×In · X/R {fnum(num(p, 'xr', 12), 0)}", "Kısa devre hesabı (AG barası arızası)", "Doğru akım bileşeni akım trafosunu ilk periyotlarda doyurur", "bkz. Kısa devre ve AT doyması sayfaları"),
        G("Trafonun demeraj verisi", "tepe × In, 2. harmonik oranı", "Üretici; önceki enerjilendirme kayıtları", "Kilit ayarı demerajın en düşük 2. harmonik oranının altında, dI>> en büyük darbenin üstünde olmalı", "2. harm. başlatma · dI>>"),
        G("Mekanik korumalar", "gaz (Buchholz) rölesi, basınç emniyeti, sıcaklık", "Trafo donanım listesi", "Sarımlar arası küçük arızayı elektriksel koruma göremez: bunlar tamamlar", "açma devresine bağlı olmalı"),
    ]
    adimlar = [
        A("Fark akımı", "Id = | I(OG) − I(AG) | — temel bileşen", "örnek örnek fark, sonra Fourier süzgeci", f"{fnum(md[jm], 2)} ×In", P3T + " böl. 6.30", "resmi"),
        A("Tutucu akım", "Ib = (|I(OG)| + |I(AG)|) / 2", f"({fnum(m1[jm], 2)} + {fnum(m2[jm], 2)}) / 2", f"{fnum(ib[jm], 2)} ×In", P3T + " böl. 6.30", "resmi"),
        A("Eşik", "başlatma + eğim 1 · (Ib − 0,5) + eğim 2 · (Ib − Ib2)", f"Ib = {fnum(ib[jm], 2)} ×In", f"{fnum(es[jm], 2)} ×In", P3T + " böl. 6.30 (karakteristik)", "resmi", [], "dI> · eğim 1 · eğim 2"),
        A("2. harmonik oranı", "Id(100 Hz) / Id(50 Hz)", f"{fnum(h2[jm], 2)} / {fnum(md[jm], 2)}", f"%{fnum(o2 * 100, 0)}", P3T + " böl. 6.30", "resmi", [], "2. harm. başlatma"),
    ]
    ayarlar = [
        S("dI> başlatma", f"{fnum(num(p, 'id_min', 25), 0)} %In", "%5 … %50 (varsayılan 25)", "Kademe değiştirici, akım trafosu hatası ve mıknatıslanma akımının toplamının üstünde", P3T + " böl. 6.30"),
        S("Eğim 1 · Eğim 2 başlangıcı · Eğim 2", f"%{fnum(num(p, 'egim1', 50), 0)} · {fnum(num(p, 'ib2', 2), 1)} ×In · %{fnum(num(p, 'egim2', 150), 0)}", "%5–100 · 1–3 ×In · %100–200", "Büyük dış arızada akım trafosu doymasının yarattığı sahte fark akımını tutar", P3T + " böl. 6.30"),
        S("2. harmonik kilidi", f"%{fnum(f2 * 100, 0)}" if kilit_var else "kapalı", "%5 … %30", "Demerajı ve doymuş akım trafosunu iç arızadan ayırır", P3T + " böl. 6.30"),
        S("dI>> (kilitsiz kademe)", f"{fnum(id2, 1)} ×In", "5 … 40 ×In", "Büyük iç arızada akım trafosu doyup 2. harmonik üretse bile açmayı güvenceye alır", P3T + " böl. 6.30"),
    ]
    test = [
        T("Karakteristik", "İki uca zıt fazlı akım; birini değiştir", "Açma, hesaplanan eşik çizgisinde", "bkz. Trafo diferansiyeli sayfası"),
        T("2. harmonik kilidi", f"Tek uca 50 Hz + %{fnum(f2 * 100 + 5, 0)} 100 Hz", "dI> açmaz; 100 Hz kaldırılınca açar", "kilit yalnız dI>'yi tutar"),
        T("Kilitsiz kademe", f"Tek uca {fnum(id2 * 1.1, 1)} ×In + %30 100 Hz", "dI>> açar", "< 40 ms"),
        T("Gerçek enerjilendirme", "Trafo boşta enerjilenir, kayıt alınır", "Fark akımı = demeraj akımı; 2. harmonik oranı ayarın üstünde; açma yok", "birkaç kapama"),
    ]
    g1 = {"baslik": "İki ucun akımı ve fark akımı (anlık)", "x_ad": "Zaman (ms)", "y_ad": "Akım (×In)", "zaman": True,
          "seriler": [{"ad": "OG tarafı", "renk": "#1a4d8f", "pts": D.seri(ts, i1, 2)}, {"ad": "AG tarafı (indirgenmiş)", "renk": "#15803d", "kesik": True, "pts": D.seri(ts, i2, 2)}, {"ad": "fark", "renk": "#dc2626", "pts": D.seri(ts, fark, 2)}]}
    g2 = {"baslik": "Rölenin hesapladıkları", "x_ad": "Zaman (ms)", "y_ad": "×In (etkin)", "ymin": 0,
          "seriler": [{"ad": "fark akımı Id", "renk": "#dc2626", "pts": D.seri(ts, md, 4)}, {"ad": "eşik", "renk": "#15803d", "kesik": True, "pts": D.seri(ts, es, 4)}, {"ad": "tutucu akım Ib", "renk": "#64748b", "pts": D.seri(ts, ib, 4)}],
          "isaretler": [{"x": t_ac, "etiket": "açma"}] if acti else []}
    g3 = {"baslik": "Fark akımındaki 2. harmonik oranı", "x_ad": "Zaman (ms)", "y_ad": "%", "ymin": 0, "ymax": 100,
          "seriler": [{"ad": "If2 / If1", "renk": "#b45309", "pts": [[round(ts[j], 1), round(min(h2[j] / md[j], 1.0) * 100 if md[j] > 0.02 else 0.0, 1)] for j in range(j0 // 2, len(ts), 4)]}],
          "yatay": [{"y": f2 * 100, "etiket": f"kilit ayarı %{fnum(f2 * 100, 0)}", "renk": "#dc2626"}] if kilit_var else []}
    ibs = [j / 10 for j in range(0, 81)]
    g4 = {"baslik": "Karakteristik ve çalışma noktasının izi", "x_ad": "Tutucu akım Ib (×In)", "y_ad": "Fark akımı Id (×In)", "ymin": 0,
          "seriler": [{"ad": "açma eşiği", "renk": "#15803d", "pts": [[x, round(esik(x, p), 3)] for x in ibs]},
                      {"ad": "çalışma noktası (zaman içinde)", "renk": "#dc2626", "nokta": True, "pts": [[round(min(ib[j], 8.0), 3), round(md[j], 3)] for j in range(j0 // 2, len(ts), 5)]}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["87t"], "sahne": c.sahne(), "grafikler": [g1, g2, g3, g4],
        "anlatim": [
            "Sağlam trafoda giren akım çıkan akıma eşittir (çevirme oranı ve bağlantı grubu düzeltildikten sonra). Röle iki ucun örneklerini çıkarır: fark sıfıra yakınsa arıza dışarıdadır ya da yoktur.",
            "Dış arızada iki uçtan aynı büyük akım geçer. Bir uçtaki akım trafosu doğru akım bileşeniyle doyarsa o ucun akımı kırpılır: aradaki fark, gerçekte olmayan bir fark akımıdır. Tutucu akım büyük olduğu için eşik de yüksektir; kırpılmış dalga ayrıca 2. harmonik içerir.",
            "Demerajda akım yalnız enerjilenen taraftan akar: bütün akım fark akımıdır ve karakteristiğin çok üstündedir. Röleyi tutan tek şey dalganın biçimidir — tek yönlü darbeler 2. harmonik bakımından zengindir.",
            "İç arızada da akım tek taraftan girer, ama sinüs biçimlidir: 2. harmonik yoktur, röle bir periyot içinde açar.",
            "İç arıza çok büyükse akım trafosu doyar ve kırpılmış dalga 2. harmonik üretir: kilit, tam da açılması gereken anda devreye girer. Kilitsiz dI>> kademesi bu yüzden vardır.",
            "Sarımlar arası kısa devrede arızalı birkaç sarımda çok büyük akım dolaşır; ama bu akım sargının bütününe göre çok az amper-sarım demektir. Uçlardaki akım neredeyse değişmez: diferansiyel röle arıza büyüyene kadar göremez.",
        ],
        "dersler": [
            "87T'nin iki düşmanı vardır: demeraj (tek taraflı akım) ve akım trafosu doyması (yanlış ölçülen akım). İkisi de 2. harmonikle tanınır.",
            "Eğim 2, büyük dış arızalardaki sahte fark akımı içindir; düşük bırakılırsa bara arızasında trafo açar.",
            "dI>> kilit dinlemez: demerajın üstünde, büyük iç arızanın altında bir yere konur.",
            "Küçük sarım arızasını elektriksel koruma göremez; gaz rölesi görür. İkisi birbirinin yerini tutmaz.",
        ],
        "tablolar": [{"baslik": "Beş durumda rölenin gördüğü", "cols": ["Durum", "Fark akımı", "Tutucu akım", "2. harmonik", "Doğru davranış"], "rows": [
            ["Dış arıza, akım trafosu doymuş", "sahte, orta", "büyük", "yüksek", "açmaz (eğim 2 + kilit)"],
            ["Demeraj", "büyük, tek taraflı", "farkın yarısı", "yüksek (%15–60)", "açmaz (kilit)"],
            ["İç arıza", "büyük", "farkın yarısı", "yok", "açar (dI>)"],
            ["İç arıza, akım trafosu doymuş", "büyük", "farkın yarısı", "yüksek", "açar (dI>>)"],
            ["Sarımlar arası kısa devre", "çok küçük", "yük akımı", "yok", "göremez → gaz rölesi"],
        ]}],
    }
