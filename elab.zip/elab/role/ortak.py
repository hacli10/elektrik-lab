"""Röle laboratuvarı — ortak yardımcılar.

Topraklama laboratuvarının altyapısını (ayar tanımı, sonuç kalıpları, şema tarifi) kullanır; her koruma fonksiyonu sayfası buna ek olarak
şu dört bölümü üretir:
  girdiler : [{ad, deger, nereden, neden, nasil}]                    — "röleye giderken elinizde olması gerekenler"
  adimlar  : [{ad, formul, hesap, sonuc, kaynak, durum, girdi, ayar}] — hangi veri hangi hesapla hangi ayara dönüşüyor
  ayarlar  : [{alan, deger, aralik, neden, kaynak, durum}]            — röle ekranındaki alanlar (Easergy P3 / eSetup Easergy Pro adlarıyla)
  test     : [{ad, uygula, beklenen, tolerans}]                       — sekonder enjeksiyonda verilecek ve yakalanacak değerler
Laboratuvar proje verisinden bağımsızdır: okumaz, yazmaz."""
from __future__ import annotations

import cmath
import math

from ..lab.cizim import Cizim
from ..lab.core import A120, C, K, ctl, fazor, fnum, num, opt  # noqa: F401  (konu modülleri buradan alır)

S3 = math.sqrt(3)

# ---------------- dayanak adları ----------------
P3U = "Schneider Easergy P3U kılavuzu (P3U/en M/J006)"
P5 = "Schneider PowerLogic P5 kılavuzu (P5/EN M/02-503A)"
P3T = "Schneider PowerLogic P3T32 kılavuzu (P3T/en M/L007)"
EKRAN = "eSetup Easergy Pro ekranı (gorseller/Easergy_P3_eSetup)"
LUY = "Lisanssız Elektrik Üretimi Yön. Uygulama Tebliği m.17, Ek-2 Tablo-2 (YG'den bağlanan üretim tesisi)"
SART = "TEDAŞ-MLZ/96-027.D sekonder koruma röleleri şartnamesi"
URRA = "URRA mühendislik esasları (saha pratiği derlemesi; ABB DA Handbook, EMO, EDAŞ uygulamaları)"
KANIT = "URRA yönlü koruma kanıt dosyası (ABB 1MRS756887 s.244, P3U/en M/J006 s.207–208, GE F60, Siemens 7SR, P5)"
IEC151 = "TS EN 60255-151 (aşırı akım rölelerinin işlevsel kuralları)"
KABUL = "Elektrik Tesisleri Kabul Yön. m.28-D-6c (primer enjeksiyon: oran, polarite, sekonder bağlantı)"

IEC = {"NI": (0.14, 0.02, "Normal ters (NI)"), "VI": (13.5, 1.0, "Çok ters (VI)"), "EI": (80.0, 2.0, "Aşırı ters (EI)"), "LTI": (120.0, 1.0, "Uzun süreli ters (LTI)")}


# ---------------- sonuç kalıpları ----------------
def G(ad: str, deger: str, nereden: str, neden: str, nasil: str = "") -> dict:
    """Röleye giderken elde olması gereken bir veri: değeri, nereden bulunacağı, neden gerektiği, hesapta nasıl kullanıldığı."""
    return {"ad": ad, "deger": deger, "nereden": nereden, "neden": neden, "nasil": nasil}


def A(ad: str, formul: str, hesap: str, sonuc: str, kaynak: str, durum: str = "resmi", girdi: list | None = None, ayar: str = "") -> dict:
    """Hesap adımı. girdi: kullanılan verilerin adları; ayar: bu adımın belirlediği röle alanı."""
    return {"ad": ad, "formul": formul, "hesap": hesap, "sonuc": sonuc, "kaynak": kaynak, "durum": durum, "girdi": girdi or [], "ayar": ayar}


def S(alan: str, deger: str, aralik: str, neden: str, kaynak: str = EKRAN, durum: str = "resmi") -> dict:
    """Röle ekranındaki bir alan: girilecek değer, ayar aralığı, gerekçe."""
    return {"alan": alan, "deger": deger, "aralik": aralik, "neden": neden, "kaynak": kaynak, "durum": durum}


def T(ad: str, uygula: str, beklenen: str, tolerans: str = "") -> dict:
    return {"ad": ad, "uygula": uygula, "beklenen": beklenen, "tolerans": tolerans}


# ---------------- birim dönüşümleri ----------------
def sek(i_prim: float, ct_p: float, ct_s: float) -> float:
    """Primer akım (A) → rölenin girişindeki sekonder akım (A)."""
    return i_prim / ct_p * ct_s


def fa(x: float, n: int = 1) -> str:
    return f"{fnum(x, n)} A"


def aci(z: complex) -> float:
    return math.degrees(cmath.phase(z)) if abs(z) > 1e-12 else 0.0


def norm(a: float) -> float:
    while a > 180:
        a -= 360
    while a <= -180:
        a += 360
    return a


def kutup(mod: float, derece: float) -> complex:
    return cmath.rect(mod, math.radians(derece))


def iec_sure(m: float, k: float, tip: str = "NI") -> float:
    """IEC ters zamanlı eğri: t = k·A / (M^B − 1); M = I / I>. M ≤ 1 ise açmaz. Röle M > 20'de eğriyi düzleştirir (dinamik aralık)."""
    a, b, _ = IEC.get(tip, IEC["NI"])
    if m <= 1.0:
        return math.inf
    return k * a / (min(m, 20.0) ** b - 1.0)


def simetrik(ia: complex, ib: complex, ic: complex) -> tuple[complex, complex, complex]:
    """Faz büyüklüklerinden sıfır, pozitif ve negatif bileşen (L1 referans)."""
    a = A120
    return (ia + ib + ic) / 3, (ia + a * ib + a * a * ic) / 3, (ia + a * a * ib + a * ic) / 3


def ariza(tip: str, e: float, z1s: complex, z0s: complex, z1h: complex, z0h: complex, rf: float = 0.0) -> dict:
    """Röle noktasındaki gerilim ve akımlar: rölenin arkasında kaynak (e, z1s, z0s), önünde hat (z1h, z0h), hattın sonunda arıza.
    tip: 3f | 2f (L2–L3) | 1f (L1–toprak) | 2ft (L2–L3–toprak). Simetrili bileşenlerle; negatif bileşen empedansı pozitife eşit alınır."""
    a = A120
    z1 = z1s + z1h; z2 = z1; z0 = z0s + z0h
    if tip == "3f":
        i1 = e / (z1 + rf); i2 = i0 = 0j
    elif tip == "2f":
        i1 = e / (z1 + z2 + rf); i2 = -i1; i0 = 0j
    elif tip == "2ft":
        zp = z2 * (z0 + 3 * rf) / (z2 + z0 + 3 * rf)
        i1 = e / (z1 + zp); i2 = -i1 * (z0 + 3 * rf) / (z2 + z0 + 3 * rf); i0 = -i1 * z2 / (z2 + z0 + 3 * rf)
    else:
        i1 = i2 = i0 = e / (z1 + z2 + z0 + 3 * rf)
    u1 = e - i1 * z1s; u2 = -i2 * z1s; u0 = -i0 * z0s
    I = (i0 + i1 + i2, i0 + a * a * i1 + a * i2, i0 + a * i1 + a * a * i2)
    U = (u0 + u1 + u2, u0 + a * a * u1 + a * u2, u0 + a * u1 + a * a * u2)
    return {"I": I, "U": U, "i1": i1, "i2": i2, "i0": i0, "u1": u1, "u2": u2, "u0": u0}


# ---------------- ortak ayarlar ----------------
def at_ctl(ct_p: float = 50, ct_s: int = 1, un: float = 34.5, gt: bool = True) -> list:
    out = [ctl("un_kv", "Bara anma gerilimi", "sec", un, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV")), yardim="Tek hat şemasından"),
           ctl("ct_p", "Akım trafosu primeri", "sayi", ct_p, min=5, max=3000, adim=5, birim="A", yardim="Hücre etiketi ya da tek hat şeması; röle ayarı «×In» bu değere göredir"),
           ctl("ct_s", "Akım trafosu sekonderi", "sec", ct_s, secenek=opt((1, "1 A"), (5, "5 A")))]
    if gt:
        out.append(ctl("vt_s", "Gerilim trafosu sekonderi (faz arası)", "sec", 100, secenek=opt((100, "100 V"), (110, "110 V"))))
    return out


def at_girdi(p: dict, gt: bool = True) -> list:
    ct_p, ct_s, un = num(p, "ct_p", 50), num(p, "ct_s", 1), num(p, "un_kv", 34.5)
    out = [G("Akım trafosu oranı", f"{ct_p:g}/{ct_s:g} A", "Hücre etiketi, tek hat şeması; röle içinde «Ölçekleme» sayfasındaki oran aynı olmalı",
             "Röledeki bütün akım ayarları «×In» ya da sekonder amper cinsindendir; In burada AT primeridir, tesisin anma akımı değildir",
             f"Ayar (×In) = primer akım / {ct_p:g}; sekonder = primer × {ct_s:g}/{ct_p:g}")]
    if gt:
        out.append(G("Gerilim trafosu oranı ve bağlantı biçimi", f"{fnum(un, 1)} kV / {num(p, 'vt_s', 100):g} V", "Hücre etiketi; röle «Gerilim ölçme modu» (3LN, 2LL+Vo …)",
                     "Gerilim ayarları «%Un» cinsindendir; yön kararı için gerilimin hangi sargıdan, hangi sırayla geldiği bilinmelidir",
                     "Röle açı ve gerilimi sekonder değerlerden hesaplar; test cihazına da sekonder değer verilir"))
    return out


# ---------------- şema ----------------
def tek_hat(sol: tuple, sag: tuple, role: tuple, durum: str = "normal", ariza_x: float | None = None, akim: str = "", gt: bool = True, ileri: bool = True,
            at_ad: str = "AT", gt_ad: str = "GT", h: int = 300, kesici_acik: bool = False) -> Cizim:
    """Bir hücrenin tek hat şeması: sol blok — bara — kesici — akım trafosu — hat — sağ blok; altında röle.
    sol/sag: (ad, alt); role: (ad, alt); akim: '' | 'sag' (soldan sağa röleden geçer) | 'sol' (sağdan sola); ariza_x: arıza yerinin x'i."""
    c = Cizim(900, h)
    y = 78
    c.kutu(20, y - 27, 130, 54, sol[0], sol[1])
    c.kutu(750, y - 27, 130, 54, sag[0], sag[1])
    xf = ariza_x if ariza_x is not None else (750 if akim == "sag" else 150)
    if akim == "sag":                                       # akım soldan sağa: röleden geçer
        c.hat(f"M150,{y} H250", "L1", hot=True, w=3); c.hat(f"M270,{y} H{xf}", "L1", hot=True, w=3)
        if xf < 750:
            c.hat(f"M750,{y} H{xf}", "L1", hot=True, w=3, hot_renk="uyari")          # öbür kaynağın katkısı: bu röle görmez
    elif akim == "sol":                                     # akım sağdan sola: röleden ters yönde geçer
        c.hat(f"M750,{y} H270", "L1", hot=True, w=3); c.hat(f"M250,{y} H{max(xf, 150)}", "L1", hot=True, w=3)
        if xf > 150:
            c.hat(f"M150,{y} H{xf}", "L1", hot=True, w=3, hot_renk="uyari")
    else:
        c.hat(f"M150,{y} H250", "L1", w=3); c.hat(f"M270,{y} H750", "L1", w=3)
    c.hat("M200,40 V116", "cizgi", w=5); c.yazi(200, 32, "OG bara", "#475569", 10, anchor="middle")
    c.dikdortgen(250, y - 10, 20, 20, "ariza" if kesici_acik else "cizgi", dolgu="#fee2e2" if kesici_acik else "#fff")
    c.yazi(260, y + 26, "kesici" + (" (açtı)" if kesici_acik else ""), "#b91c1c" if kesici_acik else "#475569", 10, anchor="middle")
    c.toroid(340, y, 7, 17); c.yazi(340, y - 24, at_ad, "#475569", 10, anchor="middle")
    c.yazi(352, y + 34, "P1 → P2", "#64748b", 9)
    c.hat(f"M340,{y + 18} V172", "cizgi", kesik=True, w=1.4)
    if gt:
        c.hat(f"M215,{y} V118", "cizgi", w=1.6); c.daire(215, 128, 10, "cizgi", w=1.6); c.daire(215, 142, 10, "cizgi", w=1.6)
        c.yazi(232, 138, gt_ad, "#475569", 10)
        c.hat("M215,152 V200 H280", "cizgi", kesik=True, w=1.4)
    c.kutu(280, 172, 190, 58, role[0], role[1], durum)
    if durum == "acti":
        c.hat(f"M300,172 V{y + 12} H262", "ariza", w=1.6, kesik=True); c.yazi(304, 160, "açma", "#b91c1c", 10)
    if ileri:
        c.ok(385, y - 34, 430, y - 34, "ok", 2); c.yazi(438, y - 30, "İLERİ (baradan hatta)", "#15803d", 10, kalin=True)
    if ariza_x is not None:
        c.simsek(xf - 6, y - 8, 1.1); c.hat(f"M{xf},{y} V{y + 44}", "ariza", hot=True, w=2); c.toprak(xf, y + 46, "ariza")
    return c


def kademe_test(ad: str, esik_sek: float, birim: str, t_s: float, ust: bool = True, tol: str = "±3 %", tol_t: str = "±1 % ya da ±30 ms", oran: float = 0.97, n: int = 2) -> list:
    """Sabit zamanlı bir kademenin üç temel testi: başlatma, bırakma, süre."""
    yon = "yükselt" if ust else "düşür"
    return [T(f"{ad} — başlatma", f"Değeri eşiğin {'altından' if ust else 'üstünden'} başlatıp yavaşça {yon}", f"Başlatma {fnum(esik_sek, n)} {birim} dolayında", tol),
            T(f"{ad} — bırakma", "Başlattıktan sonra değeri geri çek", f"Bırakma ≈ {fnum(esik_sek * oran, n)} {birim} (bırakma oranı {fnum(oran, 2)})", tol),
            T(f"{ad} — süre", f"Eşiğin {'1,2' if ust else '0,8'} katını basamak olarak uygula", f"Açma {fnum(t_s, 2)} s sonra", tol_t)]


def fz(ad: str, mod: float, derece: float, boy: float, renk: str, kesik: bool = False) -> dict:
    """Fazör diyagramı için vektör: çizim boyu `boy` (0…1), tabloda gösterilen büyüklük `mod`."""
    z = cmath.rect(boy, math.radians(derece))
    return {"ad": ad, "re": round(z.real, 4), "im": round(z.imag, 4), "renk": renk, "kesik": kesik, "bas_re": 0.0, "bas_im": 0.0, "mod": round(mod, 2), "aci": round(norm(derece), 1)}


def sz_kademe(ts: list, vs: list, esik: float, t_gecikme: float, ust: bool = True, hist: float = 0.03, birakma: float = 0.0, kilit: list | None = None) -> dict:
    """Sabit zamanlı bir kademenin zaman benzetimi. ts: zamanlar (s), vs: izlenen büyüklük, esik: başlatma; ust=True ise aşınca (>), değilse altına inince (<).
    hist: histerezis (oran); birakma: bırakma gecikmesi (s) — bu süre dolmadan arıza geri gelirse sayaç kaldığı yerden sürer; kilit: her örnek için True ise kademe kilitli.
    Dönen: {basla: ilk başlatma anı | None, acma: açma anı | None, durum: [0 yok | 1 başladı | 2 açtı]}."""
    say, bos, basla, acma, etkin, durum = 0.0, 0.0, None, None, False, []
    for j, (t, v) in enumerate(zip(ts, vs)):
        dt = ts[j] - ts[j - 1] if j else 0.0
        kil = bool(kilit[j]) if kilit else False
        if kil:
            etkin = False
        elif not etkin:
            etkin = (v > esik) if ust else (v < esik)
        else:
            etkin = (v > esik * (1 - hist)) if ust else (v < esik * (1 + hist))
        if etkin:
            if basla is None:
                basla = t
            say += dt; bos = 0.0
            if say >= t_gecikme - 1e-9 and acma is None:
                acma = t
        else:
            bos += dt
            if bos > birakma + 1e-9 or kil:
                say = 0.0
        durum.append(2 if acma is not None else 1 if etkin else 0)
    return {"basla": basla, "acma": acma, "durum": durum}
