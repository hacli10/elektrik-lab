"""Aşırı akı / volt-bölü-hertz koruması (ANSI 24) — PowerLogic / Easergy P3T32 «Vf>» (Uf>) kademesi.

Dayanak: P3T32 kılavuzu P3T/en M/L007 böl. 6.7 (kademe gerilim/frekans oranına duyarlıdır; ölçme modundan bağımsız olarak üç faz arası gerilimin en büyüğü kullanılır;
şebeke frekansı 50 / 60 Hz kendiliğinden benimsenir; uygulama: yol alırken ve dururken uyartımlı jeneratörler ve onların blok trafoları, akı payı olmayan yeni trafolar),
Çizelge 59 (başlatma %100–200, süre 0,3–300 s, başlatma süresi ≈ 200 ms, bırakma oranı 0,995, doğruluk U < %0,5 birim ve f < 0,05 Hz, süre ±%1 ya da ±150 ms).
Akı yoğunluğu bağıntısı için PowerLogic P5 kılavuzu P5/EN M/02-503A. Trafonun aşırı akı dayanım eğrisi üretici verisidir; buradaki eğri öğretim amaçlı tipik biçimdir."""
from __future__ import annotations

import math

from ..lab.core import interp
from .ortak import A, C, EKRAN, G, K, P3T, P5, S, T, ctl, fnum, kademe_test, num, opt, tek_hat

ID = "vf_24"
BASLIK = "Aşırı akı V/f (24)"
IKON = "🧲"
GIRIS = ("Trafo çekirdeğindeki akı, gerilimin frekansa oranıyla orantılıdır. Gerilim yükselirse ya da frekans düşerse çekirdek doyar: mıknatıslanma "
         "akımı fırlar, çekirdek ve bağlantı parçaları ısınır. Aşırı gerilim rölesi frekans düşüşünü görmez; V/f rölesi ikisini birlikte izler.")

OLAY = {"ada": "Ada işletmesi: frekans düşüyor, gerilim regülatörü gerilimi tutuyor", "yuksek": "Şebeke gerilimi yüksek", "yolalma": "Jeneratör düşük hızda, uyartım açık", "normal": "Normal işletme"}
DAYANIM = [(106, 3600), (110, 1200), (115, 300), (120, 60), (125, 20), (130, 8), (140, 3), (150, 1.5)]      # (V/f %, saniye) — tipik biçim (tahmini)

KONTROLLER = [
    ctl("olay", "Durum", "sec", "ada", secenek=opt(*OLAY.items())),
    ctl("u", "Gerilim", "sayi", 105, min=50, max=140, adim=1, birim="%Un"),
    ctl("f", "Frekans", "sayi", 46.0, min=35, max=55, adim=0.1, birim="Hz"),
    ctl("vf", "Röle › Vf> başlatma", "sayi", 110, min=100, max=200, adim=1, birim="%"),
    ctl("t", "Röle › Çalışma süresi", "sayi", 5.0, min=0.3, max=300, adim=0.1, birim="s"),
    ctl("v59", "Karşılaştırma: aşırı gerilim rölesi V>", "sayi", 120, min=100, max=150, adim=1, birim="%Un"),
]


def dayanim(n: float) -> float:
    """Trafonun aşırı akı dayanma süresi (s) — tipik eğri, logaritmik ara değer; %105'e kadar sürekli."""
    return math.inf if n <= 105 else interp(DAYANIM, n, logy=True)


def run(p: dict) -> dict:
    o = p.get("olay") if p.get("olay") in OLAY else "ada"
    u, f = num(p, "u", 105), num(p, "f", 46.0)
    n = u / (f / 50)                                             # % cinsinden aşırı uyarma katı
    esik, t = num(p, "vf", 110), num(p, "t", 5.0)
    basla = n >= esik; td = dayanim(n)
    v59 = u >= num(p, "v59", 120)
    c = tek_hat(("Jeneratör", f"{fnum(f, 1)} Hz"), ("Trafo", f"V/f = %{fnum(n, 0)}"), ("24  Vf>", ("AÇAR " + fnum(t, 1) + " s") if basla else "başlamadı"), "acti" if basla else "normal", None, "sag", ileri=False)
    c.yazi(500, 190, f"V/f = (U/Un) / (f/fn) = {fnum(u / 100, 2)} / {fnum(f / 50, 3)} = %{fnum(n, 1)}", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, "Aşırı gerilim rölesi (59): " + ("başlar" if v59 else f"başlamaz — gerilim %{fnum(u, 0)}, eşik %{fnum(num(p, 'v59', 120), 0)}"), "#334155", 11)
    c.yazi(500, 226, "Trafo bu akıya " + (f"yaklaşık {fnum(td, 0)} s dayanır" if td < math.inf else "sürekli dayanır") + " (tipik eğri)", "#334155", 11)
    ozet = [
        K("Kademe", ("AÇAR " + fnum(t, 1) + " s") if basla else "başlamadı", "ok" if (basla and t <= td) or (not basla and td == math.inf) else "bad", "trafo dayanımı " + (fnum(td, 0) + " s" if td < math.inf else "sürekli")),
        K("Aşırı uyarma katı V/f", f"%{fnum(n, 1)}", "bad" if n > 110 else "warn" if n > 105 else "ok", "anma akısına göre"),
        K("Gerilim", f"%{fnum(u, 0)} Un", "info", "59 " + ("görür" if v59 else "görmez")),
        K("Frekans", f"{fnum(f, 1)} Hz", "info", f"%{fnum(f / 50 * 100, 0)} fn"),
        K("Aynı akıyı veren gerilim (50 Hz'de)", f"%{fnum(n, 0)} Un", "info", "frekans düşüşü gerilim yükselmesi gibi etkir"),
    ]
    kontroller = [
        C("Kademe trafonun dayanma süresinden önce açıyor mu?", f"röle {fnum(t, 1) + ' s' if basla else 'başlamaz'}; dayanım {fnum(td, 0) + ' s' if td < math.inf else 'sürekli'}", "röle süresi ≤ dayanım süresi", (basla and t <= td) if td < math.inf else True,
          "Dayanım eğrisi üretici verisidir; buradaki eğri tipik biçimdir", "tahmini"),
        C("Başlatma sürekli çalışma sınırının üstünde mi?", f"%{fnum(esik, 0)}", "%105 … %110 (üretici)", 105 <= esik <= 115, "Trafo anma yükünde %105, boşta %110 akıya sürekli dayanacak biçimde tasarlanır (TS EN 60076-1) — asıl metinle doğrulanacak", "dogrulanacak"),
        C("Aşırı gerilim rölesi bu durumu görüyor mu?", f"U = %{fnum(u, 0)}; V> = %{fnum(num(p, 'v59', 120), 0)} → " + ("görür" if v59 else "görmez"), "görmüyorsa V/f kademesi şart", None,
          "Kademe gerilim/frekans oranına duyarlıdır, yalnız gerilime değil — " + P3T + " böl. 6.7 (Şekil 82)", "resmi"),
        C("Frekans ölçme aralığı", f"{fnum(f, 1)} Hz", "45 … 55 Hz (PowerLogic P5'te kademe yalnız bu aralıkta çalışır)", 45 <= f <= 55, P5 + " (fn = 50 Hz için 45–55 Hz). P3T32 kılavuzunda (böl. 6.7) alt frekans sınırı verilmemiş; karakteristik şekli 30 Hz'e kadar çizilmiştir", "dogrulanacak"),
    ]
    girdiler = [
        G("Trafonun aşırı akı dayanım eğrisi", "sürekli %105–110; %120'de ≈ 1 dk (tipik)", "Trafo üreticisi", "Başlatma ve süre bu eğrinin altında kalmalı", "Vf> ve çalışma süresi"),
        G("Gerilim trafosunun bağlı olduğu taraf", "korunan sargının gerilimi", "Tek hat şeması", "Akıyı o sargının gerilimi belirler; kademe değiştirici konumu hesaba katılır", "%Un tabanı"),
        G("Ada işletmesi / yol alma olasılığı", "frekans düşerken gerilim regülatörü gerilimi tutar", "İşletme senaryoları; jeneratör AVR'sinin V/f sınırlayıcısı", "Aşırı akının en olası nedeni düşük frekansta anma gerilimidir", "Kademenin gerekçesi"),
        G("Aşırı gerilim koruması ayarları", f"V> = %{fnum(num(p, 'v59', 120), 0)}", "Ayar föyü", "59 yalnız gerilime bakar; frekans düşükken aynı akı daha düşük gerilimde oluşur", "24 bu boşluğu kapatır"),
    ]
    adimlar = [
        A("Aşırı uyarma katı", "V/f = (U / Un) / (f / fn)", f"{fnum(u / 100, 2)} / ({fnum(f, 1)} / 50)", f"%{fnum(n, 1)}", P5 + " «Transformer Overfluxing Protection (ANSI 24)» (B = K·U/f)", "resmi"),
        A("Başlatma", "sürekli dayanımın biraz üstü", "%105–110 → %110", f"%{fnum(esik, 0)}", "üretici verisi; ekrandaki örnek %100", "ikincil", ["Trafonun aşırı akı dayanım eğrisi"], "Vf> Başlatma"),
        A("Süre", "t ≤ dayanım süresi (başlatma düzeyinde)", f"%{fnum(esik, 0)} akıda dayanım ≈ {fnum(dayanim(esik + 5), 0)} s (%{fnum(esik + 5, 0)}'te)", f"{fnum(t, 1)} s", "tipik eğri", "tahmini", ["Trafonun aşırı akı dayanım eğrisi"], "Çalışma süresi"),
    ]
    ayarlar = [
        S("Vf> › Başlatma", f"%{fnum(esik, 0)}", "%100 … %200; ekrandaki örnek %100", "Anma akısının yüzdesi. %100 normal işletmede sürekli başlatır: sürekli dayanımın üstüne alınır", P3T + " Çizelge 59"),
        S("Vf> › Çalışma süresi", f"{fnum(t, 1)} s", "0,3 … 300 s; ekrandaki örnek 1,0 s", "Dayanım eğrisinin altında; geçici olaylarda açmasın", P3T + " Çizelge 59"),
        S("Ayar grubu", "1", "1 … 4", "Her kademe için dört ayar grubu", P3T + " böl. 6.7"),
        S("İkinci kademe", "yüksek akı için kısa süre (ör. %125 / 2 s) — programlanabilir kademeyle", "—", "Sabit zamanlı iki kademe ters eğriye yaklaştırır", EKRAN, "dogrulanacak"),
    ]
    test = kademe_test("Vf>", esik, "% (50 Hz'de gerilimi yükselterek)", t, True, "U < %0,5 birim; f < 0,05 Hz", "±%1 ya da ±150 ms", 0.995, 1) + [
        T("Frekansı düşürerek", f"Gerilim %100 sabit; frekansı {fnum(50 * 100 / esik, 1)} Hz'e doğru düşürün", f"Başlatma {fnum(50 * 100 / esik, 1)} Hz dolayında (V/f = %{fnum(esik, 0)})", "—"),
        T("Birlikte", "Gerilimi ve frekansı aynı oranda düşürün (%90 Un, 45 Hz)", "V/f = %100: başlamaz", "—"),
        T("Bu sayfadaki durum", f"%{fnum(u, 0)} Un, {fnum(f, 1)} Hz", ("AÇAR " + fnum(t, 1) + " s") if basla else "başlamaz", f"V/f = %{fnum(n, 1)}"),
    ]
    fs = [35 + j * 0.25 for j in range(81)]
    g = {"baslik": "Gerilim – frekans düzlemi: sabit akı doğruları", "x_ad": "Frekans (Hz)", "y_ad": "Gerilim (% Un)", "ymin": 60, "ymax": 140,
         "seriler": [{"ad": f"Vf> = %{fnum(esik, 0)} (üstü: başlatma)", "renk": "#dc2626", "pts": [[x, esik * x / 50] for x in fs]}, {"ad": "anma akısı %100", "renk": "#15803d", "kesik": True, "pts": [[x, 100 * x / 50] for x in fs]},
                     {"ad": "çalışma noktası", "renk": "#1a4d8f", "nokta": True, "r": 6, "pts": [[f, u]]}], "yatay": [{"y": num(p, "v59", 120), "etiket": "aşırı gerilim rölesi V>", "renk": "#7c3aed"}]}
    ns = [106 + j for j in range(45)]
    g2 = {"baslik": "Trafonun dayanma süresi ve röle", "x_ad": "V/f (%)", "y_ad": "Süre (s)", "logy": True, "ymin": 1, "ymax": 2000,
          "seriler": [{"ad": "trafo dayanımı (tipik)", "renk": "#1a4d8f", "pts": [[x, min(dayanim(x), 2000)] for x in ns if dayanim(x) < math.inf]}, {"ad": "röle (sabit zamanlı)", "renk": "#dc2626", "pts": [[x, t] for x in ns if x >= esik]}],
          "isaretler": [{"x": n, "etiket": "şu an"}] if 106 <= n <= 150 else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["_24_"],
        "sahne": c.sahne(), "grafikler": [g, g2],
        "anlatim": [
            "Sargıya uygulanan gerilim, çekirdekteki akının değişim hızına eşittir. Aynı gerilimde frekans düşerse akı her yarım periyotta daha uzun süre büyür: tepe değeri artar. Akı ∝ U / f.",
            f"Şu an U/Un = {fnum(u / 100, 2)}, f/fn = {fnum(f / 50, 3)}: akı anma değerinin %{fnum(n, 0)}'i. Bu, 50 Hz'de %{fnum(n, 0)} gerilim uygulamakla aynıdır.",
            "Çekirdek anma akısının %105–110'una kadar tasarlanır. Üstünde doyar: mıknatıslanma akımı ve kaçak akı hızla büyür; çekirdek saclarını, tankı ve bağlantı parçalarını ısıtır.",
            "Aşırı gerilim rölesi yalnız gerilime bakar. Ada işletmesinde frekans düşerken gerilim regülatörü gerilimi anma değerinde tutarsa 59 hiçbir şey görmez; V/f rölesi görür.",
            "Dayanım akıya çok duyarlıdır: %110'da dakikalar, %130'da saniyeler. Bu yüzden iki kademe (ya da ters zamanlı eğri) kullanılır.",
        ],
        "dersler": [
            "V/f = (U/Un) / (f/fn). 45 Hz'de %100 gerilim = %111 akı.",
            "%100'lük başlatma normal işletmede sürekli başlatır; ekrandaki değer örnek/varsayılandır, ayar değildir.",
            "Röle ölçme modundan bağımsız olarak en büyük faz arası gerilimi kullanır: toprak arızasındaki faz–toprak gerilim yükselmesi kademeyi etkilemez.",
            "59 ile 24 birbirinin yerine geçmez: biri yalıtımı, öteki çekirdeği korur.",
        ],
        "tablolar": [{"baslik": "Aynı akıyı veren gerilim–frekans çiftleri", "cols": ["Frekans", "%100 akı", f"%{fnum(esik, 0)} akı (başlatma)", "%120 akı"], "rows": [
            [f"{x} Hz", f"%{fnum(100 * x / 50, 0)} Un", f"%{fnum(esik * x / 50, 0)} Un", f"%{fnum(120 * x / 50, 0)} Un"] for x in (42, 45, 47, 48, 50, 51)]}],
    }
