"""Arıza üzerine kapama koruması (ANSI 50HS, SOTF) — Easergy P3 «Switch-on-to-fault» kademesi.

Dayanak: P3U/en M/J006 böl. 5.19 (kesici arızalı hatta elle kapatıldığında gecikmesiz açma; kesicinin açık olduğu, en büyük faz akımının sabit alt sınırın — 0,02 ×In —
altında olmasından ya da dijital girişten anlaşılır; «ölü hat tespit gecikmesi» kesicinin ne kadar süre açık kalmış olması gerektiğini, «kapamadan sonra etkin kalma süresi»
kademenin kapamadan sonra ne kadar süre hazır bekleyeceğini belirler; kesici arızadan önce açık değilse kademe etkinleşmez), Çizelge 64 (akım girişi IL ya da I'L; başlatma
1,00–3,00 ×In; ölü hat gecikmesi 0–60 s; etkin kalma 0,10–60 s; çalışma < 30 ms — akım ayarın 1,5 katından büyükken; bırakma oranı 0,97; doğruluk ±%3 ya da 5 mA)."""
from __future__ import annotations

from .ortak import A, C, G, K, P3U, S, T, URRA, ctl, fa, fnum, num, opt, tek_hat

ID = "sotf50hs"
BASLIK = "Arıza üzerine kapama (50HS)"
IKON = "🔌"
GIRIS = ("Bakımdan sonra topraklama bıçağı unutulmuş bir hatta kesici kapatılırsa aşırı akım rölesi seçicilik süresini bekler; o sürede arıza tam şiddetiyle sürer. "
         "Arıza üzerine kapama koruması «hat az önce enerjisizdi, kapatır kapatmaz büyük akım geldi» durumunu tanır ve beklemeden açar.")

OLAY = {"sotf": "Arızalı hatta kapama (topraklama bıçağı kapalı unutulmuş)", "demeraj": "Sağlam hatta kapama: trafo demerajı", "sonra": "Kapamadan bir süre sonra arıza", "kisa": "Kısa süreli açma-kapama sonrası arıza (hat az önce enerjiliydi)"}

KONTROLLER = [
    ctl("ct_p", "Akım trafosu primeri", "sayi", 150, min=5, max=3000, adim=5, birim="A"),
    ctl("olay", "Olay", "sec", "sotf", secenek=opt(*OLAY.items())),
    ctl("i_ar", "Arıza akımı", "sayi", 8.0, min=0.5, max=30, adim=0.5, birim="×In", goster={"olay": ["sotf", "sonra", "kisa"]}),
    ctl("i_dem", "Demeraj akımının temel bileşeni (ilk periyotlar)", "sayi", 2.5, min=0.5, max=12, adim=0.1, birim="×In", goster={"olay": ["demeraj"]}),
    ctl("t_acik", "Kapamadan önce hattın enerjisiz kaldığı süre", "sayi", 30.0, min=0.0, max=600, adim=0.5, birim="s"),
    ctl("t_ariza", "Arızanın kapamadan sonra geldiği an", "sayi", 3.0, min=0.2, max=60, adim=0.1, birim="s", goster={"olay": ["sonra"]}),
    ctl("bas", "Röle › SOTF başlatma", "sayi", 2.00, min=1.00, max=3.00, adim=0.01, birim="×In"),
    ctl("t_olu", "Röle › Ölü hat tespit gecikmesi", "sayi", 0.20, min=0.0, max=60, adim=0.01, birim="s"),
    ctl("t_etkin", "Röle › Kapamadan sonra etkin kalma süresi", "sayi", 1.00, min=0.10, max=60, adim=0.01, birim="s"),
    ctl("h2", "SOTF kademesi 2. harmonikle kilitli (kilit matrisi)", "onay", True),
    ctl("t51", "Karşılaştırma: aşırı akım kademesinin süresi", "sayi", 0.50, min=0.05, max=3.0, adim=0.05, birim="s"),
    ctl("t_kesici", "Kesicinin açma süresi", "sayi", 60, min=20, max=120, adim=5, birim="ms"),
]


def run(p: dict) -> dict:
    o = p.get("olay") if p.get("olay") in OLAY else "sotf"
    ct_p = num(p, "ct_p", 150); bas = num(p, "bas", 2.0); tk = num(p, "t_kesici", 60) / 1000
    t_acik = num(p, "t_acik", 30.0) if o != "kisa" else 0.1
    hazir = t_acik >= num(p, "t_olu", 0.2)                              # kesici yeterince uzun süre açık kaldı: kademe kurulu
    akim = {"demeraj": num(p, "i_dem", 2.5)}.get(o, num(p, "i_ar", 8.0))
    t_gelis = num(p, "t_ariza", 3.0) if o == "sonra" else 0.0           # akımın kapamadan sonra eşiği aştığı an
    pencerede = t_gelis <= num(p, "t_etkin", 1.0)
    kilit = o == "demeraj" and bool(p.get("h2"))
    acar = hazir and pencerede and akim >= bas and not kilit
    beklenen = o == "sotf"
    t_sotf = 0.03 + tk; t_51 = num(p, "t51", 0.5) + tk
    c = tek_hat(("Besleme", ""), ("Hat / trafo", OLAY[o].split(":")[0].split(" (")[0]), ("50HS  SOTF", "AÇTI — < 30 ms" if acar else "açmadı"), "acti" if acar else ("gecersiz" if acar != beklenen else "normal"),
                620 if o != "demeraj" else None, "sag", gt=False, ileri=False, at_ad=f"AT {ct_p:g}/1", kesici_acik=acar)
    c.yazi(500, 190, f"Kapamadan sonra akım {fnum(akim, 1)} ×In = {fa(akim * ct_p, 0)} · SOTF başlatma {fnum(bas, 2)} ×In", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, "Kademe kurulu: " + ("evet" if hazir else f"HAYIR ({fnum(t_acik, 1)} s enerjisiz)") + " · etkin pencere: " + ("içinde" if pencerede else "DIŞINDA"), "#334155", 11)
    c.yazi(500, 226, (f"SOTF ile temizleme {fnum(t_sotf * 1000, 0)} ms; aşırı akım kademesiyle {fnum(t_51 * 1000, 0)} ms olurdu") if o != "demeraj" else ("2. harmonik kilidi: " + ("açık" if p.get("h2") else "yok")), "#334155", 11)
    ozet = [
        K("SOTF", "AÇTI" if acar else "açmadı", "ok" if acar == beklenen else "bad", ("doğru" if acar == beklenen else "YANLIŞ") + " — " + ("arızalı hatta kapama" if beklenen else "arıza üzerine kapama değil")),
        K("Temizleme süresi", f"{fnum(t_sotf * 1000, 0)} ms" if acar else (f"{fnum((t_gelis + t_51) * 1000 - t_gelis * 1000, 0)} ms (51)" if o in ("sonra", "kisa") else "—"), "ok" if acar else "info", "SOTF: < 30 ms + kesici"),
        K("Aşırı akım kademesiyle", f"{fnum(t_51 * 1000, 0)} ms", "info", "seçicilik gecikmesi + kesici"),
        K("Kazanç", f"{fnum((t_51 - t_sotf) * 1000, 0)} ms" if acar else "—", "ok" if acar else "info", f"arıza enerjisi %{fnum(t_sotf / t_51 * 100, 0)}'e iner" if acar else ""),
        K("Akım / başlatma", f"{fnum(akim / bas, 2)} kat", "ok" if akim >= 1.5 * bas else "warn", "< 30 ms için ≥ 1,5 kat gerekir"),
    ]
    kontroller = [
        C("Bu olayda davranış doğru mu?", "açtı" if acar else "açmadı", "yalnız arızalı hatta kapamada açar", acar == beklenen, P3U + " böl. 5.19 (Şekil 87)", "resmi"),
        C("Başlatma demeraj akımının üstünde mi (ya da kademe kilitli mi)?", f"başlatma {fnum(bas, 2)} ×In; demeraj temel bileşeni {fnum(num(p, 'i_dem', 2.5), 1)} ×In" + (" · 2. harmonik kilidi açık" if p.get("h2") else ""), "başlatma > demeraj ya da 2. harmonik kilidi",
          bas > num(p, "i_dem", 2.5) or bool(p.get("h2")), "Başlatma en çok 3,00 ×In'dir (" + P3U + " Çizelge 64); trafo fiderinde demeraj bunu aşabilir. Kilit matrisiyle 2. harmonik kilidi önerisi saha pratiği: " + URRA, "ikincil"),
        C("Başlatma en büyük yük akımının üstünde mi?", f"{fnum(bas, 2)} ×In", "≥ 1,2 × kapama sonrası yük akımı (soğuk yük dâhil)", bas >= 1.2, "Aralık 1,00–3,00 ×In: " + P3U + " Çizelge 64. Pay önerisi saha pratiği", "ikincil"),
        C("Arıza akımı hızlı açma için yeterli mi?", f"{fnum(num(p, 'i_ar', 8.0) / bas, 1)} × başlatma", "≥ 1,5 kat (< 30 ms)", num(p, "i_ar", 8.0) >= 1.5 * bas, P3U + " Çizelge 64 (çalışma < 30 ms, akım ayarın 1,5 katından büyükken)", "resmi"),
        C("Ölü hat gecikmesi tekrar kapama ölü zamanından uzun mu?", f"{fnum(num(p, 't_olu', 0.2), 2)} s", "tekrar kapama kullanılıyorsa: ölü zamandan uzun (ya da SOTF tekrar kapamayla eşgüdümlü)", None,
          "Kesici arızadan önce yeterince uzun süre açık değilse kademe etkinleşmez — " + P3U + " böl. 5.19. Tekrar kapama eşgüdümü öğretim amaçlı not", "ikincil"),
    ]
    girdiler = [
        G("Kesicinin açık olduğunun nasıl anlaşılacağı", "akım < 0,02 ×In (varsayılan) ya da dijital giriş", "Röle ayarı; sekonder şema", "Kademe ancak hat enerjisizken kurulur", "Ölü hat tespit girişi"),
        G("Kapama sonrası en büyük normal akım", f"demeraj {fnum(num(p, 'i_dem', 2.5), 1)} ×In", "Trafo güçleri; önceki enerjilendirme kayıtları", "Başlatma bunun üstünde olmalı ya da kademe 2. harmonikle kilitlenmeli", "SOTF başlatma"),
        G("En küçük arıza akımı (hat başı)", f"{fnum(num(p, 'i_ar', 8.0), 1)} ×In", "Kısa devre hesabı", "Başlatmanın en az 1,5 katı olmalı ki açma 30 ms'nin altında kalsın", "akım / başlatma ≥ 1,5"),
        G("Aşırı akım kademesinin süresi", f"{fnum(num(p, 't51', 0.5), 2)} s", "Ayar föyü", "SOTF'un kazandırdığı süre", "karşılaştırma"),
        G("Tekrar kapama kullanılıyor mu", "ölü zamanlar", "Ayar föyü", "Ölü hat gecikmesi kısa ise her tekrar kapamada SOTF kurulur", "ölü hat tespit gecikmesi"),
    ]
    adimlar = [
        A("SOTF başlatma", "kapama sonrası en büyük normal akım < başlatma ≤ arıza akımı / 1,5", f"{fnum(num(p, 'i_dem', 2.5), 1)} ×In < başlatma ≤ {fnum(num(p, 'i_ar', 8.0) / 1.5, 1)} ×In; üst sınır 3,00", f"{fnum(min(3.0, max(1.2, num(p, 'i_dem', 2.5) * 1.2)), 2)} ×In", P3U + " Çizelge 64", "ikincil", ["Kapama sonrası en büyük normal akım", "En küçük arıza akımı (hat başı)"], "SOTF başlatma"),
        A("Temizleme süresi", "t = < 30 ms + t kesici", f"30 + {fnum(tk * 1000, 0)} ms", f"{fnum(t_sotf * 1000, 0)} ms", P3U + " Çizelge 64", "resmi"),
        A("Kazanılan süre", "t(51) − t(SOTF)", f"{fnum(t_51 * 1000, 0)} − {fnum(t_sotf * 1000, 0)} ms", f"{fnum((t_51 - t_sotf) * 1000, 0)} ms", "karşılaştırma", "hesap", ["Aşırı akım kademesinin süresi"]),
    ]
    ayarlar = [
        S("SOTF — Etkin", "Açık", "—", "Tek ayar grubu", P3U + " böl. 5.19"),
        S("Akım giriş", "IL", "IL / I'L", "Hangi tarafın akımı", P3U + " Çizelge 64"),
        S("Başlatma", f"{fnum(bas, 2)} ×In", "1,00 … 3,00 ×In", "Kapama sonrası normal akımın üstü", P3U + " Çizelge 64"),
        S("Ölü hat tespit gecikmesi", f"{fnum(num(p, 't_olu', 0.2), 2)} s", "0,00 … 60,00 s", "Kesicinin kademenin kurulması için açık kalması gereken en kısa süre", P3U + " Çizelge 64"),
        S("Kapamadan sonra etkin kalma süresi", f"{fnum(num(p, 't_etkin', 1.0), 2)} s", "0,10 … 60,00 s", "Kapamadan sonra bu süre içinde akım eşiği aşarsa açar; sonra kademe devreden çıkar", P3U + " Çizelge 64"),
        S("Ölü hat tespit girişi", "— (akımla: en büyük faz akımı < 0,02 ×In)", "—, DI1 … DIx, VI1 … VIx", "Kesici konumu dijital girişten de alınabilir", P3U + " böl. 5.19"),
    ]
    test = [
        T("Kurulma ve açma", f"Akım 0 iken {fnum(num(p, 't_olu', 0.2) + 0.5, 1)} s bekleyin; sonra {fnum(1.6 * bas, 2)} ×In basamak", "Açma < 30 ms", "±%3 ya da 5 mA sekonder"),
        T("Ölü hat gecikmesi", f"Akımı keser kesmez ({fnum(num(p, 't_olu', 0.2) / 2, 2)} s sonra) aynı basamağı verin", "SOTF açmaz", "—"),
        T("Etkin pencere", f"Akım 0 iken bekleyin; önce {fnum(0.5 * bas, 2)} ×In verin, {fnum(num(p, 't_etkin', 1.0) + 0.5, 1)} s sonra {fnum(1.6 * bas, 2)} ×In'e çıkarın", "SOTF açmaz (pencere kapandı); aşırı akım kademesi kendi süresinde açar", "—"),
        T("Başlatma değeri", "Kurulu kademede basamağı yükselterek deneyin", f"Açma {fnum(bas, 2)} ×In'de; bırakma oranı 0,97", "±%3"),
    ]
    T_son = max(1.6, t_gelis + t_51 + 0.4)
    pts = [[-0.4, 0], [0, 0]]
    if o == "demeraj":
        import math
        pts += [[round(x * 0.02, 3), round(0.3 + (akim - 0.3) * math.exp(-x * 0.02 / 0.25), 2)] for x in range(0, 80)] if not acar else [[0, akim], [t_sotf, akim], [t_sotf, 0], [T_son, 0]]
    else:
        if t_gelis > 0:
            pts += [[0, 0.4], [t_gelis, 0.4]]
        son = t_gelis + (t_sotf if acar else t_51)
        pts += [[t_gelis, akim], [son, akim], [son, 0], [T_son, 0]]
    g = {"baslik": "Kapamadan sonra akım ve SOTF penceresi", "x_ad": "Zaman (s; 0 = kesicinin kapandığı an)", "y_ad": "Akım (×In)", "ymin": 0,
         "seriler": [{"ad": "akım", "renk": "#dc2626", "pts": pts}], "yatay": [{"y": bas, "etiket": f"SOTF başlatma {fnum(bas, 2)} ×In", "renk": "#1a4d8f"}],
         "isaretler": [{"x": num(p, "t_etkin", 1.0), "etiket": "etkin pencere biter"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["50hs", "sotf"],
        "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Röle hattın enerjisiz olduğunu en büyük faz akımının çok küçük olmasından (0,02 ×In'in altı) ya da kesici konum girişinden anlar. Hat «ölü hat gecikmesi» kadar enerjisiz kaldıysa kademe kurulur.",
            "Kesici kapandıktan sonra kademe «etkin kalma süresi» boyunca hazır bekler. Bu pencerede akım başlatma değerini aşarsa gecikmesiz açma verir (< 30 ms).",
            "Pencere kapandıktan sonra gelen arıza SOTF'un işi değildir; onu aşırı akım kademeleri kendi süreleriyle temizler.",
            "Hat arızadan hemen önce enerjiliyse (kesici yeterince uzun açık kalmadıysa) kademe kurulmaz. Böylece işletme sırasındaki arızalarda seçicilik bozulmaz.",
            "Sağlam bir trafo fideri kapatıldığında da akım sıfırdan fırlar: demeraj. Başlatma en çok 3 ×In'e ayarlanabildiğinden demeraj bunu aşıyorsa kademe 2. harmonik işaretiyle kilitlenmelidir.",
        ],
        "dersler": [
            "SOTF bir zaman penceresidir: «hat enerjisizdi» + «kapandı» + «hemen büyük akım».",
            "Başlatma 1–3 ×In ile sınırlıdır; trafo fiderinde 2. harmonik kilidi olmadan demerajda açar.",
            "< 30 ms yalnız akım ayarın 1,5 katından büyükken geçerlidir.",
            "Seçiciliği bozmaz: pencere dışındaki arızalar olağan kademelere kalır.",
        ],
        "tablolar": [{"baslik": "Dört olayda SOTF (bu ayarlarla)", "cols": ["Olay", "Kademe kurulu", "Pencerede", "Akım ≥ başlatma", "SOTF"], "rows": [
            ["Arızalı hatta kapama", "evet" if num(p, "t_acik", 30.0) >= num(p, "t_olu", 0.2) else "hayır", "evet", "evet" if num(p, "i_ar", 8.0) >= bas else "hayır", "AÇAR" if num(p, "t_acik", 30.0) >= num(p, "t_olu", 0.2) and num(p, "i_ar", 8.0) >= bas else "açmaz"],
            ["Sağlam trafoda kapama (demeraj)", "evet", "evet", "evet" if num(p, "i_dem", 2.5) >= bas else "hayır", ("açmaz — kilitli" if p.get("h2") else "AÇAR — yanlış açma") if num(p, "i_dem", 2.5) >= bas else "açmaz"],
            ["Kapamadan sonra arıza", "evet", "evet" if num(p, "t_ariza", 3.0) <= num(p, "t_etkin", 1.0) else "hayır", "evet", "AÇAR" if num(p, "t_ariza", 3.0) <= num(p, "t_etkin", 1.0) and num(p, "i_ar", 8.0) >= bas else "açmaz — 51 temizler"],
            ["Hat az önce enerjiliydi", "hayır" if 0.1 < num(p, "t_olu", 0.2) else "evet", "evet", "evet", "açmaz — 51 temizler" if 0.1 < num(p, "t_olu", 0.2) else "AÇAR"]]}],
    }
