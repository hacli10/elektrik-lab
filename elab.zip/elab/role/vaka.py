"""Röle laboratuvarı — vaka çalışmaları: sahadan bir olay anlatılır, gözlemler verilir; nedeni dört seçenekten bulunur. Cevaptan sonra açıklama ve
ilgili sayfanın o duruma ait kontrol tablosu açılır; «kendi sayfasında aç» ile ayarlar değiştirilerek denenir.

Her vaka başka bir sayfanın belirli ayarlarla çalıştırılmasıdır: sonuçlar o sayfanın kendi hesabıdır, burada yeni bir bağıntı yoktur.
Olay anlatımları kurgudur (gerçek bir tesise ait değildir); amaç belirtiden nedene gitmeyi çalışmaktır."""
from __future__ import annotations

import random

from .ortak import Cizim, ctl

ID = "vaka"
BASLIK = "Vaka çalışmaları"
IKON = "🕵"
GIRIS = ("Sahadan bir olay: ne oldu, röle ne yaptı, kayıtlarda ne var. Nedenini bulun. Cevaptan sonra açıklama ve ilgili sayfanın kontrol tablosu açılır; "
         "«Bu senaryoyu kendi sayfasında aç» ile aynı durumu ayarlarını değiştirerek inceleyebilirsiniz.")

# (kimlik, neden — seçenek metni, sayfa, ayarlar, olay anlatımı, açıklama, ders)
VAKALAR = [
    ("at_ters_67", "Akım trafosunun sekonder uçları ters bağlı", "yon_faz", {"at_ters": True},
     "Santral çıkış hücresinin önündeki şebeke hattında üç fazlı arıza oldu. Yönlü aşırı akım rölesi başlamadı; arızayı indirici merkezdeki röle temizledi. Röle devreye alındığından beri ilk kez arıza görüyor.",
     "Akım trafosu ters bağlıyken röle ileri yöndeki arızayı geri yönde görür: açma bölgesinin tam karşısına düşer.", "Yön, devreye almada yük akımıyla ya da primer enjeksiyonla doğrulanır; ilk gerçek arızaya bırakılmaz."),
    ("gt_yok_67", "Gerilim trafosu sigortası atık: röle kutuplama gerilimi göremiyor", "yon_faz", {"gt_yok": True},
     "Hat arızasında yönlü aşırı akım rölesi akımı gördü ama açmadı. Olay kaydında üç faz gerilimi arızadan önce de sıfıra yakın.",
     "Yön kararı gerilime göre verilir. Gerilim yoksa ve kip «yalnız yönlü» ise kademe çalışamaz.", "Gerilim devresi denetimi (60) etkin olmalı; gerilim kaybında kademenin yönsüz çalışması istenip istenmediği bilinçli seçilir."),
    ("ters_guc", "Ters güç rölesinin akım trafosu ters bağlı", "guc32", {"olay": "uretim", "ters": True},
     "Jeneratör şebekeye bağlanıp yük almaya başladıktan birkaç saniye sonra ters güç korumasından açıyor. Boşta senkron olurken sorun yok.",
     "Akım ters ölçülünce üretilen güç röleye «şebekeden çekilen güç» gibi görünür: üretim arttıkça ters güç artar.", "Güç yönü, yük altında ölçüm ekranından doğrulanır: üretimde aktif gücün işareti beklenen yönde olmalıdır."),
    ("grup_87t", "Diferansiyel rölede trafonun bağlantı grubu yanlış girilmiş", "dif87t", {"hata": "grup"},
     "Yeni devreye alınan trafo boşta sorunsuz enerjilendi. Yük alındıkça diferansiyel röle fark akımı göstermeye başladı ve yükün yarısında açtı. Trafo ve kablolar sağlam.",
     "Röle iki tarafın akımını karşılaştırmadan önce açıyı bağlantı grubuna göre düzeltir. Grup yanlışsa sağlam trafoda yük akımıyla orantılı fark akımı oluşur.", "Devreye almada yük altında fark akımı okunur: sıfıra yakın değilse ayar ya da bağlantı yanlıştır."),
    ("demeraj", "Demeraj: 2. harmonik kilidi gecikmeli kademeye bağlanmamış", "demeraj_trafo", {"kilit": False, "r": 0.2},
     "Büyük bir trafo her enerjilendirmede değil, bazı kapamalarda aşırı akımdan açıyor. Açmadan sonra yapılan yalıtım ve sargı deneyleri temiz. Arıza kaydında akım tek yönlü darbeler halinde.",
     "Demeraj akımı kapama anına ve çekirdekte kalan akıya göre her seferinde farklıdır. Büyük trafoda yavaş söner; gecikmeli kademe kilitlenmezse süresini doldurur.", "Tek yönlü, 2. harmoniği yüksek akım arıza değildir. Kilit işareti matriste ilgili kademeye bağlanmadıkça etkisizdir."),
    ("kip_67n", "Söndürme bobinli şebekede toprak rölesi kapasitif kipte", "toprak_fider", {"notr": "bobin", "kip": "sin"},
     "İndirici merkeze söndürme bobini takıldıktan sonra kablo fiderlerindeki toprak arızalarında fider rölesi açmıyor; arıza yalnız nötr gerilim korumasıyla, bütün barayı boşaltarak temizleniyor.",
     "Bobin, arızalı fiderin kapasitif bileşenini söndürür. Kapasitif kipte röle bakacak bir şey bulamaz; arızalı fider yalnız aktif bileşenden tanınır.", "Yıldız noktasının biçimi değişince toprak korumasının kipi de değişir."),
    ("rms_erisim", "Ani kademe etkin değerle ölçüyor: doğru akım bileşeninde aşırı erişim", "olcme", {"yontem": "rms"},
     "Fiderin ani kademesi, erişim bölgesinin dışındaki bir arızada açtı ve seçiciliği bozdu. Arıza akımının kalıcı değeri ayarın %15 altında; arıza baraya yakın ve gerilim sıfır geçişinde başlamış.",
     "Etkin değer, doğru akım bileşenini de sayar: ilk periyotlarda kalıcı değerin çok üstünde okur ve ayarı aşar.", "Ani kademenin ölçme yöntemi ve aşırı erişim payı, X/R'nin büyük olduğu noktalarda belirleyicidir."),
    ("dc_iki", "Kumanda devresinde iki toprak arızası açma kontağını köprülüyor", "dc_kacak", {"f1": "p", "f2": "x"},
     "Kesici, hiçbir röle açma vermeden açtı. Olay kayıtlarında koruma başlatması yok. Akü redresöründe haftalardır «toprak kaçağı» alarmı duruyor.",
     "İlk toprak arızası (artı kutup) alarm vermiş ama giderilmemiş. İkincisi kontak ile bobin arasında oluşunca toprak, kontağın iki yanını birbirine bağladı.", "Yalıtılmış kumanda devresinde ilk toprak kaçağı bekletilmez."),
    ("kilit_kopuk", "Ters kilitleme kablosu kopuk", "ters_kilit", {"yer": "fider", "hata": "kopuk"},
     "Bir çıkış fiderindeki kablo arızasında fider rölesi başladı, ama giriş kesicisi 190 ms'de açtı ve bütün bara enerjisiz kaldı. Fider kesicisi hiç açmadı.",
     "Fider rölesinin başlatma işareti giriş rölesine ulaşmadığı için giriş rölesi arızayı barada sandı ve hızlı kademeyle açtı.", "Kilit devresi her fider için ayrı ayrı denenir; kablo koptuğunda düzen kendiliğinden haber vermez."),
    ("sayac_ters", "Bir fazın akım trafosu ters: sayaç üçte bir yazıyor", "sayac_baglanti", {"hata": "at_ters"},
     "Yeni devreye alınan tesisin aylık tüketimi, trafo AG tarafındaki analizörün gösterdiğinin üçte biri çıkıyor. Sayaç çalışıyor, hata vermiyor.",
     "Bir eleman aynı gücü eksi işaretle ölçüyor: +1 +1 −1 = toplamın üçte biri.", "Sayaçta faz bazında güç yönüne bakılır; devreye almada yük altında fazör kontrolü yapılır."),
    ("at_kablo", "Akım trafosu ile röle arasındaki kablo uzun: trafo büyük arızada doyuyor", "at_doyma", {"l_m": 150},
     "Baraya yakın bir arızada fiderin ani kademesi açmadı; arızayı üstteki röle gecikmeyle temizledi. Daha uzaktaki küçük arızalarda aynı röle sorunsuz açıyor. Arıza kaydında akım sivri ve kırpık.",
     "Uzun kablo yükü artırır, gerçek doğruluk sınır katsayısı düşer. Akım büyüdükçe çekirdek doyar ve röle akımı ayarın altında ölçer.", "Akım trafosu ayara ve bağlı yüke göre sınanır; büyük arızada koruma en çok burada yanılır."),
    ("motor_yd", "Yıldız–üçgen yol vermede kalkış momenti yükü kaldırmıyor", "yolalma_motor", {"yuk": "sabit", "m_yuk": 1.1, "yontem": "yd"},
     "Konveyör motoru yıldızda dönmeye başlıyor ama hızlanmıyor; zaman rölesi üçgene geçirince şalter atıyor. Aynı motor boşta sorunsuz yol alıyor.",
     "Yıldızda moment üçte bire iner. Sabit momentli yükte motor momenti yük momentinin altında kalır: motor hızlanamaz, üçgene düşük hızda geçilince tam kalkış akımı çekilir.", "Yıldız–üçgen yalnız hafif kalkışlı yüklerde (fan, pompa) işe yarar."),
    ("motor_ani", "Verimli motorun ilk tepesi ani açtırıcı ayarını aşıyor", "yolalma_motor", {"ia": 8, "cosk": 0.15, "i_ani": 12},
     "Eski motorun yerine aynı güçte yüksek verimli motor takıldı. Motor koruma şalteri yol vermelerin bir bölümünde, daha ilk anda atıyor; motor ve kablo sağlam.",
     "Verimli motorun kalkış akımı büyük, kalkış güç katsayısı düşüktür: doğru akım bileşeni ilk tepeyi ani açtırıcı ayarının üstüne çıkarır. Kapama anına bağlı olduğu için her seferinde olmaz.", "Motor değişince koruma şalterinin ani ayarı yeniden denetlenir."),
    ("bf_kisa", "Kesici arıza koruması süresi kesicinin kesme süresinden kısa", "kesici50bf", {"t_bf": 0.1},
     "Bir fider arızasında fider kesicisi doğru açtı, ama aynı anda bütün bara boşaldı. Kesici test raporunda açma süresi olağan.",
     "50BF süresi, kesicinin açma süresi ile kademenin bırakma süresinin toplamından kısa: kesici sağlam olduğu halde arızalı sayıldı.", "50BF süresi kesicinin gerçek kesme süresine ve rölenin bırakma süresine göre hesaplanır."),
    ("senkron", "Senkron denetimi devre dışı: kesici faz farkı varken kapatıldı", "senkron25", {"mod": "off"},
     "Jeneratör şebekeye bağlanırken şiddetli bir darbe oldu; kaplin ve sargı başları zarar gördü. Operatör, senkronoskop tam üstte değilken kapama verdiğini söylüyor.",
     "Kontaklar arasındaki gerilim, faz farkıyla birlikte büyür; 120°'de faz geriliminin 1,7 katıdır. Senkron denetimi bu kapamayı engellemek içindir.", "Senkron denetimi yalnız otomatik kapamada değil, elle kapamada da devrede olmalıdır."),
    ("mesafe_asiri", "Mesafe rölesinin 1. bölgesi hat boyundan uzun ayarlanmış", "mesafe21", {"konum": 104, "z1": 108},
     "Komşu hattın başındaki bir arızada bu hattın rölesi gecikmesiz açtı. İki hat birden devre dışı kaldı. Arıza kaydına göre arıza karşı baranın 2 km ötesinde.",
     "1. bölge karşı baranın ötesine taşıyor. Gecikmesiz bölge ölçme hatalarına pay bırakılarak hattın %80–85'ine ayarlanır.", "1. bölge hiçbir koşulda karşı barayı görmemelidir."),
    ("ref_direnc", "Yüksek empedanslı REF'te kararlılık direnci küçük seçilmiş", "dif_yuksek", {"rst": 50},
     "AG barasındaki bir kısa devrede trafonun sınırlı toprak arızası koruması açtı. Arıza trafonun dışında; trafo deneyleri temiz.",
     "Dış arızada bir akım trafosu doyunca dengesizlik akımının bir bölümü röle kolundan geçti: kararlılık direnci bunu engelleyecek kadar büyük değil.", "Kararlılık direnci, en büyük dış arıza akımı ve doymuş akım trafosu kabulüyle hesaplanır; primer enjeksiyonla doğrulanır."),
    ("termik_tekrar", "Motor soğumadan yeniden yol verildi", "isinma", {"t1": 30, "dur": 2},
     "Motor aşırı yükten termik korumayla açtı. Operatör iki dakika sonra yeniden yol verdi; motor yol alırken tekrar açtı. Üçüncü denemede de aynı.",
     "Duran motor yavaş soğur. Isıl düzey hâlâ yüksekken yol alma akımının eklediği pay açma düzeyini aşar.", "Termik açmadan sonra beklenir; yeniden yol verme izni ısıl düzeye bağlanır."),
    ("ag_hat_sonu", "Uzun ve ince AG hattının sonunda arıza akımı şalterin ani eşiğinin altında", "kisa_devre", {"yer": "ag_son", "l_m": 250, "kesit": 16},
     "250 m uzaktaki bir panoda kablo arızası oldu. Besleyen şalter ancak onlarca saniye sonra açtı; kablo ve pano yandı. Şalterin kesme kapasitesi fazlasıyla yeterli.",
     "Hat sonundaki en küçük kısa devre akımı şalterin ani açma eşiğinin altında kaldı; şalter yalnız ısıl açtırıcısıyla, geç açtı.", "Koruma en büyük akıma değil en küçük akıma göre sınanır: hat sonu, sıcak iletken, faz–toprak."),
    ("rocof_sebeke", "ROCOF ayarı düşük: şebeke genelindeki frekans düşüşünde santral ayrıldı", "frekans_dinamik", {"rocof": 0.5, "ev": 60, "dp": 10},
     "Uzak bir bölgede büyük bir santral devre dışı kaldı. Aynı anda bölgedeki küçük santrallerin çoğu df/dt korumasından açtı; frekans daha da düştü ve yük atma çalıştı. Santrallerin hiçbiri adada kalmamıştı.",
     "Ataleti düşük şebekede, şebeke genelindeki düşme hızı santralin ada algılama ayarını aştı.", "ROCOF ayarı ada durumu ile şebeke olayını ayıracak kadar yüksek seçilir; atalet azaldıkça bu daha da önem kazanır."),
]

# Her vakanın üç çeldiricisi: aynı belirtiyi ilk bakışta açıklayabilecek ama gözlemlerle bağdaşmayan nedenler
CELDIRICI = {
    "at_ters_67": ["Başlatma ayarı arıza akımının üstünde kalmış", "Kesicinin açma bobini arızalı", "Gerilim hafızası süresi kısa ayarlanmış"],
    "gt_yok_67": ["Akım trafosunun sekonder uçları ters bağlı", "Başlatma ayarı arıza akımının üstünde kalmış", "Açma bölgesinin merkezi yanlış açıya ayarlanmış"],
    "ters_guc": ["Ters güç başlatma ayarı gereğinden duyarlı", "Çalışma süresi çok kısa ayarlanmış", "Tahrik makinesi güç üretmiyor (motor çalışma)"],
    "grup_87t": ["Trafoda sarımlar arası kısa devre var", "2. harmonik kilidi kapalı bırakılmış", "Kademe değiştirici uç konumda"],
    "demeraj": ["Trafoda iç arıza var", "Akım trafosu oranı röleye yanlış girilmiş", "Ani kademe ayarı yük akımına yakın"],
    "kip_67n": ["Fider toroidleri ters takılmış", "Toprak rölesinin başlatma ayarı yüksek", "Nötr gerilimi ölçüsü röleye gelmiyor"],
    "rms_erisim": ["Akım trafosu doymuş", "Kademenin yön elemanı devre dışı", "Ayar grubu yanlış seçilmiş"],
    "dc_iki": ["Rölenin açma kontağı yapışmış", "Kesici mekanizması titreşimle çözülmüş", "Açma bobininde sarım kısa devresi"],
    "kilit_kopuk": ["Giriş rölesinin hızlı kademe ayarı yük akımına yakın", "Fider rölesinin süresi gereğinden uzun", "Fider akım trafosu doymuş"],
    "sayac_ters": ["Bir fazın gerilim sigortası atık", "Akım trafosu oranı sayaca yanlış girilmiş", "Sayaç iki elemanlı bağlanmış"],
    "at_kablo": ["Ani kademe ayarı baradaki arıza akımının üstünde", "2. harmonik kilidi ani kademeyi tutmuş", "Rölenin akım girişi arızalı"],
    "motor_yd": ["Üçgene geçiş süresi kısa ayarlanmış", "Besleme gerilimi düşük", "Motor sargılarından biri kopuk"],
    "motor_ani": ["Motorda sarımlar arası kısa devre", "Besleme kablosunun kesiti yetersiz", "Isıl açtırıcı ayarı düşük"],
    "bf_kisa": ["Fider kesicisinin kutuplarından biri geç açtı", "Bara diferansiyel koruması açtı", "Giriş rölesinin süresi fiderle aynı ayarlanmış"],
    "senkron": ["Jeneratör gerilimi şebekeden yüksekti", "Kesicinin kapama süresi uzun", "İki tarafın frekansı arasındaki fark büyüktü"],
    "mesafe_asiri": ["Gerilim trafosu sigortası atık", "Ağır yükte yük empedansı bölgeye girdi", "Akım trafosu polaritesi ters"],
    "ref_direnc": ["Trafoda gerçek bir sargı–toprak arızası var", "Yıldız noktası akım trafosunun oranı farklı", "Gerilim sınırlayıcı takılmamış"],
    "termik_tekrar": ["Termik ayar motor anma akımının altında", "Motor sargısı arızalı", "Soğuma fanı ters dönüyor"],
    "ag_hat_sonu": ["Şalterin kesme kapasitesi yetersiz", "Şalterin ısıl açtırıcısı arızalı", "Trafonun kısa devre gerilimi düşük"],
    "rocof_sebeke": ["Santraller gerçekten adada kaldı", "Düşük frekans kademesi 49,5 Hz'e ayarlı", "Gerilim koruması açtı"],
}

KONTROLLER = [
    ctl("soru", "Vaka numarası", "sayi", 1, min=1, max=999, adim=1),
]


def run(p: dict) -> dict:
    from . import run as role_run, spec
    no = max(1, int(float(p.get("soru", 1) or 1)))
    rng = random.Random(4000 + no)
    sira = list(range(len(VAKALAR)))
    random.Random(11).shuffle(sira)                    # her vaka bir kez gelir; sonra aynı sırayla yinelenir
    v = VAKALAR[sira[(no - 1) % len(sira)]]
    secenekler = list(CELDIRICI[v[0]]) + [v[1]]
    rng.shuffle(secenekler)
    out = role_run(v[2], v[3])
    sp = next(k for k in spec() if k["id"] == v[2])
    c = Cizim(900, 190)
    c.kutu(20, 20, 860, 44, f"Vaka {no}", "olay ve kayıtlar")
    satir, y = "", 92
    for kelime in v[4].split(" "):                      # olay anlatımı satırlara bölünür
        if len(satir) + len(kelime) > 118:
            c.yazi(30, y, satir, "#1e293b", 12); y += 20; satir = ""
        satir += kelime + " "
    c.yazi(30, y, satir.strip(), "#1e293b", 12)
    out["sahne"] = c.sahne()
    out["soru"] = {"no": no, "konu": f"Vaka {no}", "metin": v[4] + " En olası neden hangisi?", "veriler": [],          # gözlemler olay anlatımındadır; sayfanın kendi sonuç kutuları nedeni ele vereceğinden cevaptan sonra açılır
                   "secenekler": secenekler, "dogru": secenekler.index(v[1]), "aciklama": v[5] + " " + v[6] + f" (İlgili sayfa: {sp['baslik']}.)"}
    out["git"] = {"konu": v[2], "params": out["params"], "baslik": v[1]}
    out["senaryo"] = {"id": v[0], "dogru": False}
    out["dersler"] = [v[6]] + out["dersler"][:3]
    out["gorsel"] = []
    out["grafikler"] = []; out["cubuklar"] = []; out["tablolar"] = []
    return out
