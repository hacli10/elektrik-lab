"""Yönlü güç / ters güç / düşük güç koruması (ANSI 32) — Easergy P3 «P<», «P<<» kademeleri.

Dayanak: P3U/en M/J006 böl. 5.9 (kademe aktif güce duyarlıdır; yönlü — ters — güç için başlatma değeri eksi, düşük güç için artı girilir; aktif güç başlatma değerinin
altına inince kademe başlar; taban PM: anma mil gücü, bilinmiyorsa makinenin anma gücü; iki özdeş kademe), Çizelge 53 (başlatma −200 … +200 % PM; süre 0,3 … 300 s;
başlatma süresi ≈ 200 ms; bırakma oranı 1,05; doğruluk ±%3 ya da anma değerinin ±%0,5'i; artı ayarlarda en büyük faz gerilimi %5'in altına düşerse iç kilit),
böl. 3.9 (güç yönü ve işareti: akım gerilimle aynı yöndeyse ileri güç). Tahrik makinesinin motor çalışmadaki gücü üretici verisidir; tipik değerler — «tahmini»."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, KABUL, P3U, S, S3, T, ctl, fa, fnum, fz, num, opt, tek_hat

ID = "guc32"
BASLIK = "Yönlü güç (32)"
IKON = "⇄"
GIRIS = ("Aşırı akım rölesi akımın büyüklüğüne, yönlü röle arıza akımının yönüne bakar; güç rölesi ise aktif gücün işaretine ve büyüklüğüne. Jeneratör motor gibi çalışmaya "
         "başladığında ya da tesisin şebekeye güç vermesi istenmediğinde akım küçüktür ama gücün yönü yanlıştır: bunu yalnız 32 görür.")

OLAY = {"uretim": "Jeneratör üretiyor (güç şebekeye)", "motor": "Tahrik durdu: jeneratör şebekeden güç çekiyor (motor çalışma)", "bos": "Boşta / sıfıra yakın güç", "reaktif": "Yalnız reaktif güç alışverişi (cos φ ≈ 0)"}
UYG = {"ters": "Ters güç (jeneratörün motor çalışması)", "ihracat": "İhracat sınırı (şebekeye güç verilmesin)", "dusuk": "Düşük güç (yük kaybı)"}

KONTROLLER = [
    ctl("s_kva", "Makinenin anma gücü (PM tabanı)", "sayi", 1870, min=100, max=40000, adim=10, birim="kVA"),
    ctl("un_kv", "Gerilim", "sec", 34.5, secenek=opt((0.4, "0,4 kV"), (6.3, "6,3 kV"), (10.5, "10,5 kV"), (34.5, "34,5 kV"))),
    ctl("ct_p", "Akım trafosu primeri", "sayi", 50, min=5, max=6000, adim=5, birim="A"),
    ctl("uyg", "Uygulama", "sec", "ters", secenek=opt(*UYG.items())),
    ctl("olay", "Durum", "sec", "motor", secenek=opt(*OLAY.items())),
    ctl("p_motor", "Motor çalışmada çekilen güç", "sayi", 8, min=1, max=50, adim=1, birim="% PM", goster={"olay": ["motor"]}, yardim="Tahrik makinesi verisi: gaz / dizel motoru %5–25, buhar türbini %1–3 (tipik)"),
    ctl("p_ur", "Üretilen güç", "sayi", 80, min=0, max=120, adim=1, birim="% PM", goster={"olay": ["uretim"]}),
    ctl("ayar", "Röle › P< başlatma", "sayi", -4.0, min=-200, max=200, adim=0.5, birim="% PM", yardim="Eksi: ters güç. Artı: düşük güç"),
    ctl("t", "Röle › Çalışma süresi", "sayi", 5.0, min=0.3, max=300, adim=0.1, birim="s"),
    ctl("ters", "Akım trafosu ters bağlı", "onay", False),
]


def run(p: dict) -> dict:
    o = p.get("olay") if p.get("olay") in OLAY else "motor"
    uyg = p.get("uyg") if p.get("uyg") in UYG else "ters"
    pm = num(p, "s_kva", 1870); un = num(p, "un_kv", 34.5); ct_p = num(p, "ct_p", 50)
    i_n = pm / (S3 * un)
    # rölenin ileri yönü: uygulamaya göre. Ters güç ve düşük güçte ileri = jeneratörden şebekeye; ihracat sınırında ileri = şebekeden tesise (ihracat eksi görünür)
    P, Q = {"uretim": (num(p, "p_ur", 80), 30.0), "motor": (-num(p, "p_motor", 8), 20.0), "bos": (1.0, 5.0), "reaktif": (0.5, 60.0)}[o]
    if uyg == "ihracat":
        P = -P
    if p.get("ters"):
        P, Q = -P, -Q
    ayar, t = num(p, "ayar", -4.0), num(p, "t", 5.0)
    basla = P < ayar
    s_ = math.hypot(P, Q); phi = math.degrees(math.atan2(Q, P))
    beklenen = {"ters": o == "motor", "ihracat": o == "uretim", "dusuk": o in ("bos", "reaktif", "motor")}[uyg]
    oneri = {"ters": -0.5 * num(p, "p_motor", 8), "ihracat": -5.0, "dusuk": 20.0}[uyg]
    c = tek_hat(("Jeneratör", f"PM = {fnum(pm, 0)} kVA") if uyg != "ihracat" else ("Şebeke", ""), ("Dağıtım şebekesi", "") if uyg != "ihracat" else ("Tesis + santral", "ihracat istenmiyor"),
                ("32  P<", ("AÇAR " + fnum(t, 1) + " s") if basla else "başlamadı"), "acti" if basla else ("gecersiz" if beklenen else "normal"), None, "sag" if P >= 0 else "sol", kesici_acik=False,
                at_ad=f"AT {ct_p:g}/1" + (" (TERS)" if p.get("ters") else ""))
    c.yazi(500, 190, f"Röledeki aktif güç P = %{fnum(P, 1)} PM = {fnum(P / 100 * pm, 0)} kW · ayar %{fnum(ayar, 1)}", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, f"Akım {fa(s_ / 100 * i_n)} ({fnum(s_ / 100 * i_n / ct_p, 2)} ×In) · açı {fnum(phi, 0)}° — aşırı akım kademesi bunu görmez", "#334155", 11)
    c.yazi(500, 226, "P başlatma değerinin altında: kademe başlar" if basla else "P başlatma değerinin üstünde", "#334155", 11)
    fazor = {"baslik": "Gerilim 0°'de; akımın gerilim yönündeki bileşeni aktif güçtür", "vektorler": [fz("U", 100, 0, 1.0, "#1d4ed8"), fz("I", s_, -phi, max(0.12, min(0.9, s_ / 100)), "#dc2626"),
                                                                                              fz("I·cos φ (aktif)", abs(P), 0 if P >= 0 else 180, max(0.05, min(0.9, abs(P) / 100)), "#15803d", kesik=True)],
             "not": "Büyüklükler anma değerinin yüzdesi. Aktif bileşen gerilimle aynı yöndeyse güç ileri (artı), ters yöndeyse geri (eksi)."}
    ozet = [
        K("Kademe", ("AÇAR " + fnum(t, 1) + " s") if basla else "başlamadı", "ok" if basla == beklenen else "bad", ("doğru" if basla == beklenen else "YANLIŞ") + " — " + UYG[uyg].split(" (")[0].lower()),
        K("Aktif güç P", f"%{fnum(P, 1)} PM", "bad" if P < 0 else "info", f"{fnum(P / 100 * pm, 0)} kW · " + ("geri" if P < 0 else "ileri")),
        K("Akım", f"{fnum(s_ / 100 * i_n / ct_p, 2)} ×In", "info", f"{fa(s_ / 100 * i_n)} — eşiklerin çok altında"),
        K("Önerilen başlatma", f"%{fnum(oneri, 1)} PM", "info", {"ters": "motor çalışma gücünün yarısı", "ihracat": "ölçme hatasının üstü", "dusuk": "en küçük işletme gücünün altı"}[uyg]),
        K("Sekonder karşılığı", f"{fnum(abs(ayar) / 100 * i_n / ct_p, 3)} A", "info", "anma geriliminde, cos φ = ±1'de"),
    ]
    kontroller = [
        C("Bu durumda davranış doğru mu?", ("başladı" if basla else "başlamadı") + f" (P = %{fnum(P, 1)})", "yalnız korunmak istenen durumda başlar", basla == beklenen, "Aktif güç başlatma değerinin altına inince kademe başlar — " + P3U + " böl. 5.9", "resmi"),
        C("Başlatma motor çalışma gücünün altında mı?", f"|ayar| = %{fnum(abs(ayar), 1)}; motor çalışma gücü %{fnum(num(p, 'p_motor', 8), 0)}", "|ayar| ≤ 0,5 × motor çalışma gücü", (abs(ayar) <= 0.5 * num(p, "p_motor", 8) + 1e-9 and ayar < 0) if uyg == "ters" else None,
          "Motor çalışmada çekilen güç tahrik makinesine bağlıdır (üretici verisi; tipik: gaz / dizel motoru %5–25, buhar türbini %1–3)", "tahmini"),
        C("Başlatma ölçme doğruluğunun üstünde mi?", f"|ayar| = %{fnum(abs(ayar), 1)} PM", "≥ %1 (doğruluk: ayarın ±%3'ü ya da anma değerinin ±%0,5'i)", abs(ayar) >= 1.0, P3U + " Çizelge 53", "resmi"),
        C("Süre geçici güç salınımlarından uzun mu?", f"{fnum(t, 1)} s", "0,3 … 300 s; senkronlama ve yük atma sırasındaki kısa ters güç için birkaç saniye", t >= 1.0, "Aralık: " + P3U + " Çizelge 53 (başlatma süresi ≈ 200 ms). Süre önerisi saha pratiği", "ikincil"),
        C("Akım trafosunun yönü", "ters" if p.get("ters") else "doğru", "üretimde rölede güç artı okunmalı", not p.get("ters"), P3U + " böl. 3.9 (güç yönü); " + KABUL, "resmi"),
    ]
    girdiler = [
        G("Makinenin anma gücü (PM)", f"{fnum(pm, 0)} kVA", "Jeneratör / tahrik makinesi etiketi", "Ayar bu gücün yüzdesidir; rölede «PM» olarak girilir", "1,00 pu = PM"),
        G("Motor çalışmada çekilen güç", f"%{fnum(num(p, 'p_motor', 8), 0)} PM", "Tahrik makinesi üreticisi", "Ters güç ayarının üst sınırı: röle bu gücün yarısında başlamalı", "ayar = −0,5 × motor gücü"),
        G("Rölenin ileri yönü", "akım gerilimle aynı yönde iken güç artı", "AT yönü; röle ölçüm sayfasında üretimdeki P işareti", "Yanlış yönde ters güç kademesi üretimde açar", "yük altında doğrulama"),
        G("İhracat / ithalat koşulu", "sıfır ihracat istenip istenmediği", "Bağlantı anlaşması", "İhracat sınırı uygulamasında röle bağlantı noktasında, yönü şebekeden tesise bakacak biçimde kullanılır", "uygulama"),
        G("Geçici ters güç olayları", "senkronlama, yük atma: birkaç saniye", "İşletme deneyimi", "Süre bunlardan uzun olmalı", "çalışma süresi"),
    ]
    adimlar = [
        A("Makinenin anma akımı", "In = PM / (√3 · U)", f"{fnum(pm, 0)} / (1,732 × {fnum(un, 1)})", fa(i_n), "temel bağıntı", "hesap", ["Makinenin anma gücü (PM)"]),
        A("Aktif güç", "P = √3 · U · I · cos φ", f"I = %{fnum(s_, 0)}, φ = {fnum(phi, 0)}°", f"%{fnum(P, 1)} PM", P3U + " böl. 3.9", "resmi"),
        A("Başlatma", {"ters": "ayar = −0,5 × motor çalışma gücü", "ihracat": "ayar = −(ölçme hatasının üstü)", "dusuk": "ayar = +(en küçük işletme gücünün altı)"}[uyg], {"ters": f"−0,5 × %{fnum(num(p, 'p_motor', 8), 0)}", "ihracat": "−%5", "dusuk": "+%20"}[uyg], f"%{fnum(oneri, 1)} PM",
          "öneri (saha pratiği); işaret kuralı: " + P3U + " böl. 5.9", "ikincil", ["Motor çalışmada çekilen güç"], "P< Başlatma"),
        A("Test akımı", "I = |ayar| × In × AT sekonderi / AT primeri (anma geriliminde, akım 180°)", f"{fnum(abs(ayar) / 100, 3)} × {fnum(i_n, 1)} / {ct_p:g}", f"{fnum(abs(ayar) / 100 * i_n / ct_p, 3)} A", "P = √3·U·I", "hesap"),
    ]
    ayarlar = [
        S("P< › Başlatma", f"%{fnum(ayar, 1)} PM", "−200,0 … +200,0 % PM (adım 0,5)", "Eksi: ters güç. Artı: düşük güç. Güç bu değerin altına inince başlar", P3U + " Çizelge 53"),
        S("P< › Çalışma süresi", f"{fnum(t, 1)} s", "0,3 … 300,0 s", "Geçici güç salınımlarını bekler", P3U + " Çizelge 53"),
        S("P<< kademesi", "isteğe bağlı (ör. alarm)", "aynı aralık", "İki özdeş kademe", P3U + " böl. 5.9"),
        S("Ölçekleme › anma mil gücü PM", f"{fnum(pm, 0)} kVA", "—", "Bilinmiyorsa makinenin anma gücü girilir; ayarların tabanı", P3U + " böl. 5.9"),
    ]
    test = [
        T("Düzen", "Üç faza anma gerilimi; üç faza dengeli akım. Önce akımı gerilimle aynı fazda verin", "Rölede P artı okunur", "—"),
        T("Ters güç başlatma", f"Akımı 180° çevirin; {fnum(abs(ayar) / 100 * i_n / ct_p, 3)} A'e doğru yükseltin", f"Başlatma P = %{fnum(ayar, 1)} PM'de; {fnum(t, 1)} s sonra açma", "±%3 ya da anma değerinin ±%0,5'i; süre ±%1 ya da ±150 ms"),
        T("Açıya bağlılık", "Aynı akımı 90°'ye (saf reaktif) çevirin", "P ≈ 0: başlamaz. 120°'de aktif bileşen yarısıdır: iki kat akım gerekir", "—"),
        T("Bırakma", "Başladıktan sonra akımı azaltın", "Bırakma oranı 1,05", "—"),
        T("Gerilim kilidi (artı ayarda)", "Düşük güç ayarında gerilimi %5'in altına indirin", "İç kilit: başlamaz", P3U + " Çizelge 53 notu"),
    ]
    ps = [x for x in range(-30, 121, 2)]
    g = {"baslik": "Güç eksenine göre kademenin çalışma bölgesi", "x_ad": "Aktif güç P (% PM; eksi: geri)", "y_ad": "kademe (1: başladı)", "ymin": -0.1, "ymax": 1.3,
         "seriler": [{"ad": "P< kademesi", "renk": "#dc2626", "pts": [[x, 1.0 if x < ayar else 0.0] for x in ps]}], "isaretler": [{"x": max(-30, min(120, P)), "etiket": "şu an"}, {"x": ayar, "etiket": "ayar"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["_32_", "ters_guc"],
        "sahne": c.sahne(fazor=fazor), "grafikler": [g],
        "anlatim": [
            "Röle üç fazın gerilimini ve akımını ölçer, aktif gücü hesaplar: akımın gerilimle aynı yöndeki bileşeni. Bu bileşen gerilimle aynı yöndeyse güç ileri, ters yöndeyse geridir.",
            "Jeneratörün tahriki durursa (yakıt kesildi, gaz motoru durdu) makine şebekeden güç çekip motor gibi döner. Akım anma akımının küçük bir bölümüdür: aşırı akım kademeleri görmez. Ama gücün işareti dönmüştür.",
            f"Ters güç kademesinde başlatma eksi girilir. Motor çalışmada çekilen güç %{fnum(num(p, 'p_motor', 8), 0)} ise ayar bunun yarısı dolayında seçilir ki kademe kesin başlasın.",
            "Senkronlama anında ve ani yük atmada güç kısa süre ters dönebilir; süre bu olaylardan uzun tutulur.",
            "Aynı kademe artı ayarla düşük güç koruması olur: güç ayarın altına inerse (yük kaybı, kayış kopması) başlar. Bu durumda gerilim yokken yanlış başlamasın diye iç kilit vardır.",
            "İhracat istenmeyen tesislerde röle bağlantı noktasına, yönü şebekeden tesise bakacak biçimde konur: ihracat eksi güç olarak görünür ve aynı «P<» mantığıyla yakalanır.",
        ],
        "dersler": [
            "32, akımın küçük ama yönünün yanlış olduğu durumlar içindir; 50/51 ve 67 bunları göremez.",
            "Ayar %PM'dir; ters güçte eksi, düşük güçte artı. Kademe güç ayarın ALTINA inince başlar.",
            "Testte akımı 180° verirsiniz; 90°'de (saf reaktif) kademe başlamaz.",
            "AT ters bağlıysa ters güç kademesi tam üretimde açar: devreye almada üretimdeki P işaretine bakın.",
        ],
        "tablolar": [{"baslik": "Tahrik makinesine göre motor çalışma gücü ve ters güç ayarı (tipik)", "cols": ["Tahrik", "Motor çalışmada çekilen güç", "Ters güç ayarı", "Süre"], "rows": [
            ["Gaz / biyogaz motoru", "%5 – 25", "−%3 … −%10", "2 – 10 s"], ["Dizel motoru", "%5 – 25", "−%3 … −%10", "2 – 10 s"], ["Buhar türbini", "%1 – 3", "−%0,5 … −%1,5", "10 – 30 s"], ["Su türbini", "%0,2 – 2", "−%0,2 … −%1", "5 – 20 s"]],
            "not": "Tipik değerlerdir (tahmini); gerçek değer tahrik makinesi üreticisinden alınır. Çok küçük ayarlarda ölçme doğruluğu (anma değerinin ±%0,5'i) sınır koyar."}],
    }
