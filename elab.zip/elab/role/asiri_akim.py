"""Faz aşırı akım koruması (ANSI 50/51) — Easergy P3 «I>», «I>>» kademeleri: eşik, eğri, zaman çarpanı ve üst röleyle seçicilik.

Dayanak: P3U/en M/J006 böl. 5.20 Çizelge 65–67 (ayar aralıkları, doğruluk), böl. 5.6 Çizelge 45 (IEC eğri sabitleri: NI 0,14/0,02 — VI 13,5/1 — EI 80/2 —
LTI 120/1; t = k·A/(M^B − 1)), böl. 5.1 Çizelge 40 (AT doyma koşulu), böl. 6.3 (demerajda gecikmeli kademe kilitlenir, ani kademe demerajın %20
üstüne konur); URRA mühendislik esasları (1,2 × azami yük; I>> = ⌊üst I>> / 1,1⌋; seçicilik payı; trafo demerajı 10·In'de ≥ 0,2 s)."""
from __future__ import annotations

import math

from .ortak import A, C, G, IEC, IEC151, K, P3T, P3U, S, T, URRA, at_ctl, at_girdi, ctl, fa, fnum, iec_sure, num, opt, sek, tek_hat
from .roleler import alan_cizelgesi

ID = "asiri_akim"
BASLIK = "Faz aşırı akım (50/51)"
IKON = "📈"
GIRIS = ("Aşırı akım rölesinin üç ayarı vardır: ne zaman başlasın (eşik), ne kadar beklesin (eğri ve zaman çarpanı), ne zaman beklemeden açsın (ani kademe). "
         "Eşiği yük ve en küçük arıza akımı, süreyi üstteki rölenin eğrisi belirler.")

KONTROLLER = at_ctl(ct_p=150, gt=False) + [
    ctl("i_yuk", "Azami yük akımı", "sayi", 60, min=5, max=2000, adim=1, birim="A", yardim="Bağlı güç ya da ölçülen en büyük akım"),
    ctl("ik_min", "Korunan bölgenin sonunda en küçük kısa devre (iki fazlı)", "sayi", 900, min=50, max=20000, adim=10, birim="A"),
    ctl("ik_max", "Rölenin bulunduğu barada en büyük kısa devre", "sayi", 6000, min=200, max=31500, adim=50, birim="A"),
    ctl("trafo_kva", "Fiderdeki trafoların toplam gücü", "sayi", 1600, min=0, max=20000, adim=50, birim="kVA", yardim="Birlikte enerjilenen trafolar; demeraj akımı için"),
    ctl("ref_i1", "Üst (referans) röle › I>", "sayi", 240, min=20, max=3000, adim=5, birim="A", yardim="Röleden okunan ayar; dağıtım şirketinden"),
    ctl("ref_k", "Üst röle › zaman çarpanı k (IEC NI)", "sayi", 0.20, min=0.05, max=1.5, adim=0.01),
    ctl("ref_i2", "Üst röle › I>>", "sayi", 3000, min=100, max=20000, adim=50, birim="A"),
    ctl("ref_t2", "Üst röle › tI>>", "sayi", 0.40, min=0.05, max=2.0, adim=0.05, birim="s"),
    ctl("dt", "Seçicilik payı Δt", "sayi", 0.20, min=0.10, max=0.50, adim=0.05, birim="s", yardim="Kesici açma süresi + röle toleransları + emniyet"),
    ctl("i1", "Röle › I> başlatma", "sayi", 0.48, min=0.05, max=5.0, adim=0.01, birim="×In"),
    ctl("egri", "Röle › Gecikme tipi (IEC ailesi)", "sec", "NI", secenek=opt(*[(k, v[2]) for k, v in IEC.items()])),
    ctl("k", "Röle › zaman çarpanı k", "sayi", 0.16, min=0.025, max=2.0, adim=0.005),
    ctl("i2", "Röle › I>> başlatma", "sayi", 18.0, min=0.10, max=40.0, adim=0.1, birim="×In"),
    ctl("t2", "Röle › tI>>", "sayi", 0.20, min=0.03, max=2.0, adim=0.01, birim="s"),
    ctl("h2", "Röle › I> kademesi 2. harmonikle kilitli (68F2)", "onay", False),
    ctl("i_ar", "Benzetim: arıza akımı", "sayi", 1500, min=20, max=31500, adim=10, birim="A"),
    ctl("alf", "Akım trafosunun doğruluk sınır katsayısı", "sec", 20, secenek=opt((10, "5P10"), (20, "5P20"), (30, "5P30"))),
]


def sure(i: float, i1: float, k: float, egri: str, i2: float, t2: float) -> float:
    """Kademelerin bileşik açma süresi (s): ters zamanlı I> ile sabit zamanlı I>>'nin küçüğü."""
    t = iec_sure(i / i1, k, egri) if i1 > 0 else math.inf
    return min(t, t2) if i >= i2 else t


def run(p: dict) -> dict:
    ct_p, ct_s = num(p, "ct_p", 150), num(p, "ct_s", 1)
    i_yuk, ik_min, ik_max = num(p, "i_yuk", 60), num(p, "ik_min", 900), num(p, "ik_max", 6000)
    i1, i2 = num(p, "i1", 0.48) * ct_p, num(p, "i2", 18.0) * ct_p
    k, egri, t2 = num(p, "k", 0.16), (p.get("egri") if p.get("egri") in IEC else "NI"), num(p, "t2", 0.2)
    r1, rk, r2, rt2, dt = num(p, "ref_i1", 240), num(p, "ref_k", 0.2), num(p, "ref_i2", 3000), num(p, "ref_t2", 0.4), num(p, "dt", 0.2)
    i_ar = num(p, "i_ar", 1500)
    biz = lambda i: sure(i, i1, k, egri, i2, t2)                       # noqa: E731
    ref = lambda i: sure(i, r1, rk, "NI", r2, rt2)                     # noqa: E731
    t_biz, t_ref = biz(i_ar), ref(i_ar)
    # önerilen ayarlar
    o_i1 = 1.2 * i_yuk
    o_i2 = math.floor(r2 / 1.1 / 10) * 10
    o_t2 = max(0.05, rt2 - dt)
    akimlar = [o_i1 * 1.2 * (ik_max / (o_i1 * 1.2)) ** (j / 60) for j in range(61)]
    o_k = 0.025
    for kk in [x * 0.005 for x in range(5, 401)]:                      # üst eğrinin Δt altında kalan en büyük çarpan
        if all(sure(i, o_i1, kk, egri, o_i2, o_t2) <= ref(i) - dt + 1e-9 for i in akimlar if ref(i) < math.inf):
            o_k = kk
        else:
            break
    xs = [max(i1, 1.0) * 1.03 * (ik_max * 1.3 / (max(i1, 1.0) * 1.03)) ** (j / 80) for j in range(81)]
    pay = min((ref(i) - biz(i) for i in xs if ref(i) < math.inf and biz(i) < math.inf), default=math.inf)
    i_dem = 10 * num(p, "trafo_kva", 1600) / (math.sqrt(3) * num(p, "un_kv", 34.5))      # demeraj: 10 × ΣIn
    t_dem = biz(i_dem) if i_dem > 0 else math.inf
    isat = num(p, "alf", 20) * ct_p
    ihtiyac = 1.5 * min(ik_max, 20 * i1)

    acar = t_biz < math.inf
    c = tek_hat(("Üst merkez", f"I> {fnum(r1, 0)} A · k {fnum(rk, 2)}"), ("Fider / yük", f"azami {fnum(i_yuk, 0)} A"), ("50/51  I> · I>>", ("AÇAR — " + fnum(t_biz, 2) + " s") if acar else "başlamadı"),
                "acti" if acar else "normal", 600, "sag", gt=False, ileri=False, at_ad=f"AT {ct_p:g}/{ct_s:g}")
    c.yazi(500, 190, f"Arıza akımı {fa(i_ar, 0)} = {fnum(i_ar / ct_p, 2)} ×In = {fnum(i_ar / i1, 2)} × I>", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, f"Bu röle {fnum(t_biz, 2) if acar else '—'} s · üst röle {fnum(t_ref, 2) if t_ref < math.inf else '—'} s · aradaki pay {fnum(t_ref - t_biz, 2) if acar and t_ref < math.inf else '—'} s", "#334155", 11)
    c.yazi(500, 226, ("Kademe: I>> (sabit zamanlı)" if i_ar >= i2 else "Kademe: I> (ters zamanlı)") if acar else "Akım I> eşiğinin altında", "#334155", 11)

    ozet = [
        K("Açma süresi", f"{fnum(t_biz, 2)} s" if acar else "açmaz", "ok" if acar else "info", f"{fa(i_ar, 0)}'de"),
        K("Üst röleyle pay", f"{fnum(t_ref - t_biz, 2)} s" if acar and t_ref < math.inf else "—", "ok" if (acar and t_ref - t_biz >= dt - 1e-9) else "bad" if acar and t_ref < math.inf else "info", f"istenen Δt = {fnum(dt, 2)} s"),
        K("En dar pay (bütün akımlarda)", f"{fnum(pay, 2)} s" if pay < math.inf else "—", "ok" if pay >= dt - 1e-9 else "bad", "iki eğri arasındaki en küçük aralık"),
        K("Duyarlılık", f"{fnum(ik_min / i1, 1)} kat", "ok" if ik_min / i1 >= 1.5 else "bad", "en küçük arıza / I>"),
        K("Önerilen k", fnum(o_k, 3), "info", f"I> {fnum(o_i1 / ct_p, 2)} ×In · {egri}"),
    ]
    kontroller = [
        C("I> yük akımının üstünde mi?", f"{fa(i1, 0)} / {fa(i_yuk, 0)} = {fnum(i1 / i_yuk, 2)}", "≥ 1,2 × azami yük", i1 >= 1.2 * i_yuk * 0.995, URRA + "; bırakma oranı 0,97 — " + P3U + " Çizelge 65", "ikincil"),
        C("En küçük arıza akımında kesin başlıyor mu?", f"Ik min / I> = {fnum(ik_min, 0)} / {fnum(i1, 0)} = {fnum(ik_min / i1, 1)}", "≥ 1,5", ik_min / i1 >= 1.5, "Duyarlılık payı saha pratiği; başlatma doğruluğu ±%3 — " + P3U + " Çizelge 65", "ikincil"),
        C("Üst röleyle seçicilik (bütün akım aralığında)", f"en dar pay {fnum(pay, 2)} s" if pay < math.inf else "eğriler kesişmiyor", f"≥ Δt = {fnum(dt, 2)} s", pay >= dt - 1e-9,
          "Her kesici bir üstündekinden önce açar; pay = kesici süresi + tolerans + emniyet — " + URRA, "ikincil"),
        C("I>> üst rölenin I>>'sinden önce mi?", f"{fa(i2, 0)} · {fnum(t2, 2)} s; üst {fa(r2, 0)} · {fnum(rt2, 2)} s", f"eşik ≤ üst / 1,1 = {fa(o_i2, 0)}; süre ≤ üst − Δt = {fnum(o_t2, 2)} s", i2 <= r2 / 1.1 + 1 and t2 <= rt2 - dt + 1e-9, URRA, "ikincil"),
        C("Trafo demerajında açmıyor mu?", f"10 × ΣIn = {fa(i_dem, 0)} → {fnum(t_dem, 2) + ' s' if t_dem < math.inf else 'başlamaz'}" + (" · 2. harmonik kilidi açık" if p.get("h2") else ""), "≥ 0,2 s ya da 2. harmonik kilidi", t_dem >= 0.2 or bool(p.get("h2")),
          "Demeraj 8–12 × In, 0,1–0,2 s (saha pratiği): " + URRA + ". Gecikmeli kademe kilitlenir, kilitsiz ani kademe demerajın %20 üstüne konur — " + P3U + " böl. 6.3", "ikincil"),
        C("Akım trafosu ayar aralığında doymuyor mu?", f"Isat ≈ ALF × In = {fa(isat, 0)}; gereken 1,5 × min(Ik max, 20 × I>) = {fa(ihtiyac, 0)}", "Isat > gereken", isat > ihtiyac,
          P3U + " böl. 5.1 Çizelge 40 (ters zamanlıda Isat > 1,5 × min(Ik max, 20·Is)). Gerçek doyma akımı sekonder yüke bağlıdır; burada anma yükünde ALF alınmıştır", "resmi"),
    ]
    girdiler = at_girdi(p, gt=False) + [
        G("Azami yük akımı", fa(i_yuk, 0), "Bağlı trafo güçleri, sayaç/analizör kayıtları", "Eşik bunun üstünde olmalı; altına inerse yükte açar", "I> = 1,2 × azami yük"),
        G("En küçük kısa devre akımı (bölge sonu, iki fazlı)", fa(ik_min, 0), "Kısa devre hesabı (en zayıf şebeke durumu)", "Eşik bunun yeterince altında olmalı; yoksa uzak arızayı göremez", "Ik min / I> ≥ 1,5"),
        G("En büyük kısa devre akımı (röle barası)", fa(ik_max, 0), "Dağıtım şirketi bağlantı görüşü; kısa devre hesabı", "Seçicilik bu akıma kadar sağlanmalı; AT doyması bu akımda denetlenir", "Eğri karşılaştırmasının üst ucu"),
        G("Üst (referans) rölenin ayarları", f"I> {fnum(r1, 0)} A, NI, k {fnum(rk, 2)}; I>> {fnum(r2, 0)} A / {fnum(rt2, 2)} s", "Dağıtım şirketi; üst merkezdeki röleden okunur", "Bizim röle her akımda ondan Δt kadar önce açmalı", "k ve I>> buradan"),
        G("Seçicilik payı Δt", f"{fnum(dt, 2)} s", "Kesici açma süresi + iki rölenin toleransı + emniyet", "Pay küçükse iki kesici birden açar; büyükse arıza gereksiz uzun sürer", "t(üst) − t(biz) ≥ Δt"),
        G("Fiderdeki trafolar (toplam güç)", f"{fnum(num(p, 'trafo_kva', 1600), 0)} kVA", "Tek hat şeması", "Enerjilendirmede 8–12 × In demeraj akımı çekerler", "Eğri 10·ΣIn'de ≥ 0,2 s ya da 2. harmonik kilidi"),
        G("Akım trafosunun sınıfı", f"5P{num(p, 'alf', 20):g}", "AT etiketi", "Doyan AT akımı eksik gösterir; ters eğride süre uzar", "Isat > 1,5 × min(Ik max, 20·I>)"),
    ]
    adimlar = [
        A("I> başlatma", "I> = 1,2 × azami yük", f"1,2 × {fnum(i_yuk, 0)} A = {fnum(o_i1, 0)} A → / {ct_p:g}", f"{fnum(o_i1 / ct_p, 2)} ×In ({fnum(sek(o_i1, ct_p, ct_s), 3)} A sekonder)", URRA, "ikincil", ["Azami yük akımı", "Akım trafosu oranı"], "I> Başlatma"),
        A("Duyarlılık denetimi", "Ik min / I> ≥ 1,5", f"{fnum(ik_min, 0)} / {fnum(o_i1, 0)}", f"{fnum(ik_min / o_i1, 1)} kat", "saha pratiği", "ikincil", ["En küçük kısa devre akımı (bölge sonu, iki fazlı)"]),
        A("Eğri ailesi", "üst röleyle aynı aile", f"üst röle IEC NI → {IEC[egri][2]}", "IEC " + egri, "aynı aile eğriler birbirini kesmez — " + URRA, "ikincil", ["Üst (referans) rölenin ayarları"], "Gecikme eğrisi ailesi / tipi"),
        A("Zaman çarpanı k", "t = k · A / (M^B − 1);  M = I / I>", f"üst eğrinin Δt = {fnum(dt, 2)} s altında kalan en büyük k (1,2·I> … Ik max arası tarama)", fnum(o_k, 3), "IEC eğri sabitleri: " + P3U + " Çizelge 45; " + IEC151, "resmi", ["Üst (referans) rölenin ayarları", "Seçicilik payı Δt"], "k"),
        A("I>> başlatma", "I>> = ⌊üst I>> / 1,1⌋", f"{fnum(r2, 0)} / 1,1", f"{fa(o_i2, 0)} = {fnum(o_i2 / ct_p, 1)} ×In", URRA + " (başlatma toleransı payı)", "ikincil", ["Üst (referans) rölenin ayarları"], "I>> Başlatma"),
        A("tI>>", "t = üst tI>> − Δt", f"{fnum(rt2, 2)} − {fnum(dt, 2)}", f"{fnum(o_t2, 2)} s", URRA, "ikincil", ["Seçicilik payı Δt"], "I>> Çalışma süresi"),
    ]
    a_, b_, _ = IEC[egri]
    ayarlar = [
        S("I> › Başlatma", f"{fnum(o_i1 / ct_p, 2)} ×In (şu an {fnum(num(p, 'i1', 0.48), 2)})", "0,05 … 5,00 ×In", f"= {fa(o_i1, 0)} primer", P3U + " Çizelge 65"),
        S("I> › Gecikme eğrisi ailesi", "IEC", "SZ, IEC, IEEE, IEEE2, RI, Prg", "Üst röleyle aynı aile", P3U + " Çizelge 65"),
        S("I> › Gecikme tipi", egri, "NI, VI, EI, LTI …", IEC[egri][2], P3U + " Çizelge 45"),
        S("I> › k (zaman çarpanı)", f"{fnum(o_k, 3)} (şu an {fnum(k, 3)})", "0,025 … 20,0", "Üst eğrinin Δt altında kalan en büyük değer", P3U + " Çizelge 65"),
        S("I> › A / B sabitleri", f"{fnum(a_, 3)} / {fnum(b_, 3)}", "eğri tipine göre röle kendisi yazar", "Ekranda görünür; «Prg» seçilmedikçe değiştirilmez", P3U + " Çizelge 45"),
        S("I> › harm.ler dahil (Include harmonics)", "Kapalı (ısıl amaçlı kullanılıyorsa Açık)", "Açık / Kapalı", "Açıkken kademe temel bileşen yerine bütün harmoniklerle gerçek etkin değeri ölçer; çalışma süresi 5 ms uzar. Harmonikli yükte ısıl koruma amacıyla kullanılır", P3U + " böl. 5.20 «Include harmonics setting»"),
        S("I>> › Başlatma", f"{fnum(o_i2 / ct_p, 1)} ×In (şu an {fnum(num(p, 'i2', 18), 1)})", "0,10 … 20,0 ×In (I>>); 0,10 … 40,0 (I>>>)", f"= {fa(o_i2, 0)}; 20 ×In'i aşıyorsa I>>> kademesi kullanılır", P3U + " Çizelge 66–67"),
        S("I>> › Çalışma süresi", f"{fnum(o_t2, 2)} s (şu an {fnum(t2, 2)})", "0,04 … 1800 s", "Üst rölenin I>> süresinden Δt kısa", P3U + " Çizelge 66"),
        S("Ayar grubu", "1", "1 … 4", "Soğuk yük ya da demeraj işaretiyle 2. gruba geçirilebilir (bkz. Soğuk yük sayfası)", P3U + " böl. 6.3"),
        S("I'> · I'>> (AG tarafı kademeleri — trafo rölesi)", "ikinci akım girişi (I'L) kullanılıyorsa", "aynı alanlar", "Trafo rölesinde (P3T32) AG tarafının akımlarıyla çalışan ayrı kademeler; ayar mantığı aynıdır, «×In» o tarafın anma akımıdır", P3T + " böl. 6.14 Çizelge (kesici arıza koşul seçicilerindeki kademe listesi: I'>, I'>>)", "ikincil"),
        S("Hata durumunda aç", "—", "—", "Ekrandaki bu alanın karşılığı P3U ve P3T32 kılavuzlarında bulunamadı", "eSetup Easergy Pro ekranı", "dogrulanacak"),
    ]
    s1 = sek(o_i1, ct_p, ct_s)
    test = [
        T("I> başlatma", "Akımı yavaşça yükseltin", f"Başlatma {fnum(s1, 3)} A; bırakma ≈ {fnum(0.97 * s1, 3)} A (oran 0,97)", "±%3 ya da 5 mA sekonder"),
    ] + [T(f"I> süre — {m:g} × I>", f"{fnum(m * s1, 3)} A basamak", f"{fnum(iec_sure(m, o_k, egri), 2)} s", "±%5 ya da en az ±25 ms") for m in (2, 5, 10)] + [
        T("I>> başlatma", "Akımı hızlı basamaklarla yükseltin (I> süresi dolmadan)", f"Başlatma {fnum(sek(o_i2, ct_p, ct_s), 2)} A", "±%3"),
        T("I>> süre", f"{fnum(1.2 * sek(o_i2, ct_p, ct_s), 2)} A basamak", f"{fnum(o_t2, 2)} s", "±%1 ya da ±25 ms"),
        T("Bu sayfadaki arıza", f"{fnum(sek(i_ar, ct_p, ct_s), 3)} A basamak", f"{fnum(t_biz, 2)} s" if acar else "açmaz", "şu anki ayarlarla"),
    ]
    g = {"baslik": "Zaman–akım eğrileri: bu röle üst rölenin altında kalmalı", "x_ad": "Akım (A, primer)", "y_ad": "Açma süresi (s)", "logx": True, "logy": True, "ymin": 0.01, "ymax": 100,
         "seriler": [{"ad": "bu röle (I> + I>>)", "renk": "#dc2626", "pts": [[i, min(biz(i), 100)] for i in xs if biz(i) < math.inf]},
                     {"ad": "üst röle", "renk": "#1a4d8f", "pts": [[i, min(ref(i), 100)] for i in xs if ref(i) < math.inf]},
                     {"ad": "önerilen ayar", "renk": "#15803d", "kesik": True, "pts": [[i, min(sure(i, o_i1, o_k, egri, o_i2, o_t2), 100)] for i in xs if sure(i, o_i1, o_k, egri, o_i2, o_t2) < math.inf]},
                     {"ad": "trafo demerajı (10·ΣIn, 0,2 s)", "renk": "#d97706", "nokta": True, "r": 5, "pts": [[i_dem, 0.2]] if i_dem > 0 else []}],
         "isaretler": [{"x": i_yuk, "etiket": "azami yük"}, {"x": ik_min, "etiket": "Ik min"}, {"x": i_ar, "etiket": "arıza"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["50-51"],
        "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            f"Eşik iki sınırın arasına konur: azami yükün üstüne ({fa(i_yuk, 0)} × 1,2) ve en küçük arıza akımının yeterince altına ({fa(ik_min, 0)} / 1,5). Röleye «×In» olarak girilir: {fnum(o_i1 / ct_p, 2)} ×In.",
            "Ters zamanlı kademede süre akıma bağlıdır: akım eşiğin kaç katıysa (M) o kadar çabuk açar. Eğrinin biçimini tip (NI, VI, EI), yüksekliğini zaman çarpanı k belirler.",
            f"k'yi üstteki röle belirler: aynı arıza akımında üst röle bizden en az Δt = {fnum(dt, 2)} s sonra açmalıdır. Grafikte kırmızı eğri mavi eğrinin her noktada Δt altında kalmalı.",
            "Büyük akımlarda ters eğri bile yavaş kalır; sabit zamanlı I>> kademesi devreye girer. Eşiği üst rölenin I>> eşiğinin 1,1'e bölünmüşü, süresi onunkinden Δt kısadır.",
            "Trafo enerjilenirken 8–12 × In demeraj akımı geçer. Eğri bu akımda 0,2 s'den kısaysa röle açar: ya k büyütülür ya da kademe 2. harmonikle kilitlenir.",
        ],
        "dersler": [
            "I> = 1,2 × azami yük; ama en küçük arıza akımı bunun en az 1,5 katı olmalı. İkisi birden sağlanmıyorsa akım ölçüsü yetmez (yönlü ya da mesafe gerekir).",
            "k tek başına bir süre değildir: süre = k × A / (M^B − 1). NI eğrisinde 10 × I>'de süre ≈ 3 × k saniyedir.",
            "Seçicilik bütün akım aralığında sağlanmalı; tek bir noktada bakmak yanıltır.",
            "Röle eğriyi 20 × I>'den sonra düzleştirir; AT de o akıma kadar doymadan ölçebilmelidir.",
        ],
        "tablolar": [
            {"baslik": "Akıma göre açma süreleri", "cols": ["Akım", "× I>", "Bu röle", "Üst röle", "Pay"], "rows": [
                [fa(i, 0), fnum(i / i1, 1), (fnum(biz(i), 2) + " s") if biz(i) < math.inf else "açmaz", (fnum(ref(i), 2) + " s") if ref(i) < math.inf else "açmaz", (fnum(ref(i) - biz(i), 2) + " s") if biz(i) < math.inf and ref(i) < math.inf else "—"]
                for i in sorted({round(x) for x in (1.5 * i1, 2 * i1, 5 * i1, ik_min, 10 * i1, i_dem, i2, ik_max) if x > 0})]},
            alan_cizelgesi(),
            {"baslik": "IEC eğri sabitleri", "cols": ["Tip", "A", "B", "10 × I>'de süre (k = 1)", "Nerede kullanılır"], "rows": [
                ["NI — normal ters", "0,14", "0,02", fnum(iec_sure(10, 1, "NI"), 2) + " s", "Genel dağıtım; kaynak empedansı baskınsa"],
                ["VI — çok ters", "13,5", "1", fnum(iec_sure(10, 1, "VI"), 2) + " s", "Arıza akımı uzaklıkla hızlı düşüyorsa"],
                ["EI — aşırı ters", "80", "2", fnum(iec_sure(10, 1, "EI"), 2) + " s", "Sigortayla seçicilik; demeraja dayanım"],
                ["LTI — uzun süreli", "120", "1", fnum(iec_sure(10, 1, "LTI"), 2) + " s", "Aşırı yük benzeri uzun süreli olaylar"]],
             "not": "Dayanak: " + P3U + " böl. 5.6 Çizelge 45. Kullanım notları genel uygulamadır."},
        ],
    }
