"""Ark koruması — PowerLogic / Easergy P3 «ARK» ekranı: I>iç başlatma, Io1>iç başlatma, ark kademeleri (ışık + akım ölçütü).

Dayanak: P3T32 kılavuzu P3T/en M/L007 böl. 6.31 (8 ark kademesi; kademe aşırı akım + ışık ya da yalnız ışık işaretiyle çalışır; akım, ışık ve çıkış matrisleri),
Çizelge 98 (I>int başlatma 0,50–8,00 ×In, varsayılan 1,00; Io>int 0,10–5,00 ×In, varsayılan 1,00; açma gecikmesi 0–255 ms — uyarı: ark kademesi gecikmesi birincil açma
için kullanılmaz, yalnız kesici arıza düzeni içindir; en kısa açma darbesi 2–255 × 10 ms), Çizelge 103 (çalışma süresi: yüksek kesmeli açma röleleri T1, T9–T12 ≤ 9 ms;
açma röleleri T2–T4 ≤ 7 ms; yarı iletken çıkışlar HSO1–HSO2 ≤ 2 ms; akım doğruluğu ±%5), böl. 4 (ark kademesinde 1 pu = akım trafosunun anma akımı).
Uygulama örneği için PowerLogic P5 kılavuzu P5/EN M/02-503A «Arc-flash (ANSI 50ARC)». Ark enerjisi karşılaştırması öğretim amaçlı orantıdır (enerji ∝ akım × süre)."""
from __future__ import annotations

from .ortak import A, C, EKRAN, G, K, P3T, P5, S, T, Cizim, ctl, fa, fnum, num, opt

ID = "ark"
BASLIK = "Ark koruması"
IKON = "⚡"
GIRIS = ("Hücre içindeki ark birkaç yüz milisaniyede baraları ve hücreyi yok eder; aşırı akım koruması seçicilik için beklerken ark büyür. Ark koruması "
         "iki şeye birden bakar: ışık sensörü parladı mı ve akım yükseldi mi? İkisi birlikte varsa beklemeden açar.")

OLAY = {"ark": "Hücrede ark (ışık + akım)", "flas": "Yalnız ışık (kapak açık, fotoğraf flaşı, güneş)", "dis": "Dış kısa devre (akım var, ışık yok)", "kucuk": "Küçük akımlı ark (akım iç başlatmanın altında)"}
MOD = {"isik_akim": "Işık + akım", "isik": "Yalnız ışık"}
CIKIS = {"t": ("Açma rölesi T2–T4", 7.0), "hb": ("Yüksek kesmeli açma rölesi T1, T9–T12", 9.0), "hso": ("Yarı iletken çıkış HSO1–HSO2", 2.0)}      # çalışma süresi üst sınırı (ms) — P3T Çizelge 103

KONTROLLER = [
    ctl("ct_p", "Giriş hücresi akım trafosu primeri", "sayi", 600, min=50, max=4000, adim=50, birim="A"),
    ctl("i_yuk", "Baranın azami yük akımı", "sayi", 400, min=20, max=4000, adim=10, birim="A"),
    ctl("ik_ka", "Baradaki kısa devre akımı", "sayi", 8.0, min=1, max=31.5, adim=0.5, birim="kA"),
    ctl("ark_oran", "Ark akımı / kısa devre akımı", "sayi", 90, min=30, max=100, adim=5, birim="%", yardim="OG'de ark gerilimi küçük kalır: %90 üstü. AG'de %40–60'a düşebilir"),
    ctl("olay", "Olay", "sec", "ark", secenek=opt(*OLAY.items())),
    ctl("mod", "Röle › Kademenin ölçütü (ark matrisi)", "sec", "isik_akim", secenek=opt(*MOD.items())),
    ctl("i_ic", "Röle › I>iç başlatma", "sayi", 1.20, min=0.5, max=8.0, adim=0.05, birim="pu"),
    ctl("io_ic", "Röle › Io1>iç başlatma", "sayi", 1.20, min=0.10, max=5.0, adim=0.05, birim="pu"),
    ctl("cikis", "Açma çıkışının türü", "sec", "t", secenek=opt(*[(k, f"{v[0]} (≤ {v[1]:g} ms)") for k, v in CIKIS.items()])),
    ctl("t_ac", "Röle › Açma zamanı", "sayi", 0, min=0, max=255, adim=1, birim="ms"),
    ctl("t_kesici", "Kesicinin açma süresi", "sayi", 50, min=20, max=100, adim=5, birim="ms"),
    ctl("t_klasik", "Ark koruması olmasaydı: bara arızasının temizlenme süresi", "sayi", 400, min=80, max=1500, adim=10, birim="ms", yardim="Giriş hücresinin I>> süresi + kesici"),
    ctl("sensor", "Ark sensörü arızalı / bağlı değil", "onay", False),
]


def run(p: dict) -> dict:
    olay = p.get("olay") if p.get("olay") in OLAY else "ark"
    mod = p.get("mod") if p.get("mod") in MOD else "isik_akim"
    ct_p = num(p, "ct_p", 600); ik = num(p, "ik_ka", 8.0) * 1000; i_ark = ik * num(p, "ark_oran", 90) / 100
    T_ROLE = CIKIS[p.get("cikis") if p.get("cikis") in CIKIS else "t"][1]
    esik = num(p, "i_ic", 1.2) * ct_p
    isik = olay in ("ark", "flas", "kucuk") and not p.get("sensor")
    akim_a = {"ark": i_ark, "flas": num(p, "i_yuk", 400), "dis": ik, "kucuk": 0.8 * esik}[olay]
    akim = akim_a >= esik
    acar = isik and (akim or mod == "isik")
    beklenen = olay in ("ark", "kucuk")
    t_top = T_ROLE + num(p, "t_ac", 0) + num(p, "t_kesici", 50)
    t_kl = num(p, "t_klasik", 400)
    oran = t_top / t_kl

    c = Cizim(900, 310)
    c.kutu(20, 40, 110, 46, "Besleme", f"Ik {fnum(ik / 1000, 1)} kA")
    c.hat("M130,63 H250", "L1", hot=olay != "flas", w=3); c.dikdortgen(250, 53, 20, 20, "ariza" if acar else "cizgi", dolgu="#fee2e2" if acar else "#fff"); c.yazi(260, 46, "giriş kesicisi" + (" (açtı)" if acar else ""), "#b91c1c" if acar else "#475569", 10, anchor="middle")
    c.toroid(320, 63, 7, 17); c.yazi(320, 36, f"AT {ct_p:g}/1", "#475569", 10, anchor="middle")
    c.hat("M270,63 H420", "L1", hot=olay != "flas", w=3); c.hat("M420,30 V250", "cizgi", w=6); c.yazi(420, 22, "bara", "#475569", 10, anchor="middle")
    for j, y in enumerate((80, 150, 220)):
        c.dikdortgen(470, y - 26, 300, 52, "cizgi", dolgu="#f8fafc", kw=1.2); c.hat(f"M420,{y} H520", "L1", hot=(olay == "dis" and j == 1), w=2.4)
        c.dikdortgen(520, y - 9, 18, 18, "cizgi", dolgu="#fff"); c.hat(f"M538,{y} H770", "L1", hot=(olay == "dis" and j == 1), w=2.4); c.yazi(776, y + 4, f"çıkış {j + 1}", "#475569", 10)
        c.daire(490, y - 16, 5, "uyari" if (isik and j == 0) else "cizgi", dolgu="#fde68a" if (isik and j == 0) else "#fff", w=1.4)
    c.yazi(498, 52, "ark sensörü" + (" — ARIZALI" if p.get("sensor") else ""), "#b91c1c" if p.get("sensor") else "#64748b", 9.5)
    if olay in ("ark", "kucuk"):
        c.simsek(438, 70, 1.5); c.yazi(440, 118, "ARK", "#b91c1c", 11, kalin=True)
    if olay == "flas":
        c.yazi(470, 118, "✦ ışık (ark değil)", "#b45309", 11, kalin=True)
    if olay == "dis":
        c.simsek(694, 138, 1.1); c.yazi(700, 182, "dış arıza", "#b91c1c", 10.5, kalin=True)
    c.kutu(150, 150, 220, 62, "ARK kademesi", ("AÇTI — " + fnum(t_top, 0) + " ms") if acar else "açmadı", "acti" if acar else ("gecersiz" if acar != beklenen else "normal"))
    c.hat("M320,81 V150", "cizgi", kesik=True, w=1.4); c.hat("M485,64 H400 V130 H300 V150", "uyari", kesik=True, w=1.4)
    c.yazi(150, 236, f"ışık: {'VAR' if isik else 'yok'}   ·   akım {fa(akim_a, 0)} {'≥' if akim else '<'} I>iç {fa(esik, 0)}: {'VAR' if akim else 'yok'}", "#334155", 11.5, kalin=True)
    c.yazi(150, 256, f"ölçüt: {MOD[mod]}", "#334155", 11)

    ozet = [
        K("Ark kademesi", "AÇAR" if acar else "AÇMAZ", "ok" if acar == beklenen else "bad", ("doğru" if acar == beklenen else "YANLIŞ") + " — " + ("hücrede ark var" if beklenen else "ark yok")),
        K("Toplam temizleme süresi", f"{fnum(t_top, 0)} ms", "ok", f"röle ≈ {fnum(T_ROLE + num(p, 't_ac', 0), 0)} ms + kesici {fnum(num(p, 't_kesici', 50), 0)} ms"),
        K("Ark koruması olmasaydı", f"{fnum(t_kl, 0)} ms", "warn", "gecikmeli aşırı akım + kesici"),
        K("Ark enerjisi", f"%{fnum(oran * 100, 0)}", "ok" if oran < 0.3 else "warn", "klasik korumaya göre (enerji ∝ akım × süre)"),
        K("I>iç başlatma", fa(esik, 0), "ok" if 1.2 * num(p, "i_yuk", 400) <= esik <= 0.5 * i_ark else "bad", f"yük {fa(num(p, 'i_yuk', 400), 0)} · ark akımı {fa(i_ark, 0)}"),
    ]
    kontroller = [
        C("Kademe bu olayda doğru davranıyor mu?", "açar" if acar else "açmaz", "yalnız hücre içi arkta açar", acar == beklenen, "Kademe aşırı akım + ışık (ya da yalnız ışık) işaretiyle çalışır; eşleme akım, ışık ve çıkış matrislerinde yapılır — " + P3T + " böl. 6.31.1", "resmi"),
        C("I>iç başlatma yükün üstünde mi?", f"{fa(esik, 0)} / {fa(num(p, 'i_yuk', 400), 0)} = {fnum(esik / num(p, 'i_yuk', 400), 2)}", "≥ 1,2 × azami yük (motor yol alma ve demeraj dâhil en büyük normal akımın üstü)", esik >= 1.2 * num(p, "i_yuk", 400),
          "Akım ölçütü yalnız «arıza akımı var» demek içindir; gecikmesiz olduğundan normal işletmenin her akımının üstünde olmalı (öğretim amaçlı öneri)", "ikincil"),
        C("En küçük ark akımında akım ölçütü sağlanıyor mu?", f"ark akımı {fa(i_ark, 0)} / I>iç {fa(esik, 0)} = {fnum(i_ark / esik, 1)}", "≥ 2", i_ark >= 2 * esik,
          "Ark gerilimi akımı düşürür; AG'de ark akımı kısa devre akımının yarısına inebilir (genel bilgi; ark çalışmasıyla doğrulanır)", "ikincil"),
        C("Yalnız ışıkla açma kullanılıyorsa yanlış açma riski", MOD[mod], "ışık + akım önerilir; «yalnız ışık» ancak akımın görülemediği bölgeler için", mod == "isik_akim" or None,
          "Akım ölçütünün görmediği bölgede (ör. kablo başlığı) yalnız ışık ölçütüyle algılama yapılabilir — " + P5 + " (uygulama örneği)", "resmi"),
        C("Sensör sağlığı", "arızalı" if p.get("sensor") else "sağlam", "sensör alarmı izlenmeli", not p.get("sensor"), "Sensör alarm işareti (kopuk, kısa devre, takılı değil) LED ve çıkış matrisinde vardır — " + P5, "resmi"),
        C("Açma zamanı", f"{fnum(num(p, 't_ac', 0), 0)} ms", "0 (gecikmesiz)", num(p, "t_ac", 0) == 0, "Uyarı: ark kademesi gecikmesi birincil açma için kullanılmaz; yalnız ayrı bir ark kademesiyle kurulan kesici arıza düzeni içindir — " + P3T + " böl. 6.31.2", "resmi"),
        C("I>iç başlatma ayar aralığında mı?", f"{fnum(num(p, 'i_ic', 1.2), 2)} ×In (In = AT {ct_p:g} A)", "0,50 … 8,00 ×In", 0.5 <= num(p, "i_ic", 1.2) <= 8.0, P3T + " Çizelge 98, 103; ark kademesinde 1 pu = akım trafosunun anma akımı (böl. 4)", "resmi"),
    ]
    girdiler = [
        G("Hücre dizisi ve koruma bölgeleri", "giriş + çıkış hücreleri; bara bölmesi, kesici bölmesi, kablo bölmesi", "Tek hat şeması; hücre yerleşimi", "Her bölgeye bir sensör; hangi sensör hangi kesiciyi açacak (ark matrisi)", "Işık matrisi · çıkış matrisi"),
        G("Akım ölçütünü verecek röle ve akım trafosu", f"giriş hücresi, AT {ct_p:g}/1", "Tek hat şeması", "Akım, arkı besleyen yoldan ölçülmelidir (giriş). Başka rölede ise GOOSE / dijital girişle aktarılır", "Akım matrisi"),
        G("Baranın azami yük akımı", fa(num(p, "i_yuk", 400), 0), "Yük hesabı; ölçüm", "İç başlatma bunun üstünde olmalı", "I>iç ≥ 1,2 × yük"),
        G("En küçük ark akımı", fa(i_ark, 0), "Kısa devre hesabı (en zayıf besleme) × ark oranı", "İç başlatma bunun yeterince altında olmalı", "I>iç ≤ ark akımı / 2"),
        G("Toprak arkı için artık akım girişi", f"Io1, başlatma {fnum(num(p, 'io_ic', 1.2), 2)} pu", "Röle bağlantı şeması; nötr topraklaması", "Faz–toprak arkında faz akımı ölçütü yetmeyebilir (dirençli şebeke)", "Io1>iç başlatma"),
        G("Kesicinin açma süresi", f"{fnum(num(p, 't_kesici', 50), 0)} ms", "Kesici etiketi / deney raporu", "Toplam ark süresinin büyük bölümü kesicidir", "t toplam = röle + kesici"),
    ]
    adimlar = [
        A("I>iç başlatma (alt sınır)", "≥ 1,2 × azami yük", f"1,2 × {fnum(num(p, 'i_yuk', 400), 0)} A = {fnum(1.2 * num(p, 'i_yuk', 400), 0)} A → / {ct_p:g}", f"≥ {fnum(1.2 * num(p, 'i_yuk', 400) / ct_p, 2)} pu", "öğretim amaçlı öneri", "ikincil", ["Baranın azami yük akımı"], "I>iç başlatma"),
        A("I>iç başlatma (üst sınır)", "≤ en küçük ark akımı / 2", f"{fnum(i_ark, 0)} / 2 → / {ct_p:g}", f"≤ {fnum(i_ark / 2 / ct_p, 2)} pu", "duyarlılık payı", "ikincil", ["En küçük ark akımı"], "I>iç başlatma"),
        A("Toplam temizleme süresi", "t = t röle + t açma zamanı + t kesici", f"{fnum(T_ROLE, 0)} + {fnum(num(p, 't_ac', 0), 0)} + {fnum(num(p, 't_kesici', 50), 0)} ms", f"{fnum(t_top, 0)} ms", "röle süresi üst sınırı çıkış türüne göre: " + P3T + " Çizelge 103", "resmi", ["Kesicinin açma süresi"]),
        A("Ark enerjisindeki azalma", "E ∝ I · t", f"{fnum(t_top, 0)} ms / {fnum(t_kl, 0)} ms", f"%{fnum(oran * 100, 0)} (klasik korumanın)", "orantı; gerçek olay enerjisi ark çalışmasıyla hesaplanır", "tahmini"),
    ]
    ayarlar = [
        S("I>iç başlatma", f"{fnum(num(p, 'i_ic', 1.2), 2)} pu = {fa(esik, 0)}", "0,50 … 8,00 ×In; varsayılan 1,00; ekrandaki örnek 1,20", "Ark kademelerinin faz akımı ölçütü; yükün üstü, ark akımının altı. Birim: akım trafosunun anma akımı", P3T + " Çizelge 98"),
        S("Io1>iç başlatma", f"{fnum(num(p, 'io_ic', 1.2), 2)} pu", "0,10 … 5,00 ×In; varsayılan 1,00; ekrandaki örnek 1,20", "Toprak arkı için artık akım ölçütü (Io girişinin anma değerine göre)", P3T + " Çizelge 98"),
        S("Kurulu lokal ark sensörleri (Install arc sensors)", "Install → Ready", "—", "Bağlı sensörleri röleye tanıtır; sonradan eksilen sensör özdenetim alarmı üretir", P3T + " Çizelge 98"),
        S("Ark kademesi 1…8 › Kademe etkin", "Açık", "8 kademe", "Her kademe bir bölgeyi / bir açma çıkışını temsil eder", P3T + " böl. 6.31.1"),
        S("Ark kademesi › Açma zamanı [×1 ms]", f"{fnum(num(p, 't_ac', 0), 0)}", "0 … 255 ms; varsayılan 0", "Birincil açmada 0. Gecikme yalnız kesici arıza düzenindeki ikinci kademe içindir", P3T + " Çizelge 98 ve uyarı"),
        S("Ark kademesi › Min. hold time [×10 ms]", "2 (= 20 ms)", "2 … 255", "Açma darbesinin en kısa süresi: kesici bobini için yeterli darbe", P3T + " Çizelge 98"),
        S("Ark kademesi › DI to block stage", "—", "dijital giriş", "Bakım sırasında kademeyi kilitlemek için", EKRAN, "dogrulanacak"),
        S("Ark matrisi › akım / ışık / çıkış", "kademe 1: I>iç + sensör 1…n → giriş kesicisi", "—", "Hangi akım ve hangi ışık işareti hangi kademeyi, kademe hangi çıkışı sürecek. Uzak işaretler GOOSE ile alınabilir", P3T + " böl. 6.31.2 Çizelge 99"),
        S("Açma çıkışı", CIKIS[p.get("cikis") if p.get("cikis") in CIKIS else "t"][0], "T2–T4 ≤ 7 ms · T1, T9–T12 ≤ 9 ms · HSO ≤ 2 ms", "Rölenin çalışma süresi çıkış türüne bağlıdır", P3T + " Çizelge 103"),
    ]
    test = [
        T("Yalnız ışık", "Sensöre deney lambası / flaş tutun; akım yok", "«Işık + akım» ölçütünde açmaz; sensör işareti olay kaydında görülür", "—"),
        T("Yalnız akım", f"Akım girişine {fnum(1.2 * num(p, 'i_ic', 1.2), 2)} A (1,2 × I>iç); ışık yok", "I>iç işareti gelir; ark kademesi açmaz", "—"),
        T("Işık + akım", "Akım varken sensöre ışık verin", f"Açma; süre ≤ {fnum(T_ROLE, 0)} ms (röle; 4 × ayar akımı ve ışıkla)", "hızlı zaman ölçer gerekir"),
        T("I>iç başlatma değeri", "Akımı yavaşça yükseltin (ışık sürekli)", f"Açma {fnum(num(p, 'i_ic', 1.2), 2)} A sekonderde (1 A girişte)", "±%5"),
        T("Sensör denetimi", "Bir sensörün bağlantısını çıkarın", "Sensör alarmı", "—"),
        T("Bölge seçiciliği", "Her sensörü ayrı ayrı uyarın", "Yalnız matriste o sensöre bağlı kademe / çıkış çalışır", "—"),
    ]
    g = {"baslik": "Ark süresi: ark koruması ile ve onsuz", "x_ad": "Zaman (ms)", "y_ad": "Ark akımı (kA)", "ymin": 0,
         "seriler": [{"ad": "ark koruması ile", "renk": "#15803d", "pts": [[0, 0], [0, i_ark / 1000], [t_top, i_ark / 1000], [t_top, 0], [t_kl * 1.1, 0]]},
                     {"ad": "yalnız gecikmeli aşırı akım", "renk": "#dc2626", "kesik": True, "pts": [[0, 0], [0, i_ark / 1000 * 1.02], [t_kl, i_ark / 1000 * 1.02], [t_kl, 0], [t_kl * 1.1, 0]]}],
         "isaretler": [{"x": T_ROLE + num(p, "t_ac", 0), "etiket": "röle açma verdi"}, {"x": t_top, "etiket": "kesici açtı"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["ark"],
        "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Hücre içinde ark başladığında iki şey aynı anda olur: çok şiddetli bir ışık çıkar ve akım kısa devre düzeyine yükselir.",
            "Ark sensörü ışığı bir milisaniye içinde algılar. Ama ışık tek başına yanıltabilir: kapak açıkken güneş, fotoğraf flaşı, kaynak. Bu yüzden röle bir de akıma bakar.",
            f"Akım ölçütü «I>iç başlatma»dır: gecikmesiz, kaba bir eşik ({fa(esik, 0)}). Görevi arıza akımını yük akımından ayırmaktır; seçicilik sağlamaz.",
            "Işık VE akım birlikte varsa kademe hemen açma verir. Dış arızada akım vardır ama ışık yoktur: kademe susar, seçicilik bozulmaz.",
            f"Toplam süre röle + kesicidir: {fnum(t_top, 0)} ms. Gecikmeli aşırı akım kademesi aynı arızayı {fnum(t_kl, 0)} ms'de temizlerdi; ark enerjisi süreyle orantılı büyür.",
            "Toprak arkında faz akımı yeterince büyümeyebilir; bunun için ikinci bir ölçüt vardır: Io1>iç başlatma.",
        ],
        "dersler": [
            "Ark koruması = ışık VE akım. Akım ölçütü kaba ve gecikmesizdir; yükün üstünde, ark akımının yarısının altında.",
            "Ayarın büyük bölümü sayı değil eşlemedir: hangi sensör, hangi akım, hangi kesici (ark matrisi).",
            "Toplam süreyi kesici belirler; röle çıkış türüne göre 2–9 ms'dir.",
            "I>iç ve Io1>iç'in birimi akım trafosunun anma akımıdır — trafo rölesinde bile (öbür faz ayarları trafonun anma akımına göreyken).",
            "Sensör arızasını izleyin: kopuk sensör, korumasız bölge demektir.",
        ],
        "tablolar": [{"baslik": "Olaya göre işaretler ve karar", "cols": ["Olay", "Işık", "Akım ≥ I>iç", "Işık + akım", "Yalnız ışık"], "rows": [
            ["Hücrede ark", "var", "var", "AÇAR", "AÇAR"], ["Yalnız ışık (flaş, güneş)", "var", "yok", "açmaz", "AÇAR — yanlış açma"],
            ["Dış kısa devre", "yok", "var", "açmaz", "açmaz"], ["Küçük akımlı ark", "var", "yok", "açmaz — eşik yüksek", "AÇAR"]],
            "not": "«Küçük akımlı ark» satırı I>iç başlatmanın gereğinden yüksek seçilmesinin sonucunu gösterir."}],
    }
