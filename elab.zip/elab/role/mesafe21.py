"""Mesafe koruma (ANSI 21): rölenin gerilim / akım oranından gördüğü empedans, R–X düzleminde bölgeler, arıza direnci, uzak uçtan besleme ve
yük empedansı.

Bu sayfanın dayandığı bir röle kılavuzu yoktur (incelenen kılavuzlar fider röleleridir). İlke temel bağıntıdır: röle Z = V/I ölçer; arıza direnci
ve uzak uç katkısı görünen empedansı direnç yönünde büyütür; faz–toprak çevriminde artık akım telafisi kN = (Z0 − Z1)/(3·Z1) uygulanır. Bölge
erişimleri (1. bölge %80–85, 2. bölge %120, 3. bölge komşu hattı kapsayacak biçimde) ve süreleri yaygın uygulamadır (ikincil); iletim işletmecisinin
ayar esasları ve TS EN 60255-121 asıl metinden teyit edilmedi. Hat birim empedansları tipiktir (tahmini)."""
from __future__ import annotations

import cmath
import math

from .ortak import A, C, Cizim, G, K, S, T, ctl, fnum, kutup, num, opt

ID = "mesafe21"
BASLIK = "Mesafe koruma (21)"
IKON = "📏"
GIRIS = ("Mesafe rölesi akımın büyüklüğüne değil, gerilimin akıma oranına bakar: arıza ne kadar yakınsa bu oran (empedans) o kadar küçüktür. Böylece röle arızanın "
         "uzaklığını ölçer ve yalnız kendi hattındaki arızada gecikmesiz açar. Arızayı hat boyunca gezdirin; arıza direncinin, uzak uçtan beslemenin ve yükün "
         "rölenin gördüğü noktayı nasıl kaydırdığını R–X düzleminde izleyin.")
YAYGIN = "yaygın uygulama (iletim işletmecisinin ayar esasları ve TS EN 60255-121 asıl metinden teyit edilmedi)"
HAT = {"h154": ("154 kV havai hat", 154.0, 0.40, 78.0), "h34": ("34,5 kV havai hat 477 MCM", 34.5, 0.37, 71.0), "k34": ("34,5 kV XLPE kablo 240 mm²", 34.5, 0.147, 48.0)}
TIP = {"3f": "Üç fazlı", "2f": "İki fazlı", "1f": "Faz–toprak"}

KONTROLLER = [
    ctl("hat", "Hat", "sec", "h154", secenek=opt(*[(k, v[0]) for k, v in HAT.items()])),
    ctl("l", "Hat uzunluğu", "sayi", 40, min=1, max=200, adim=1, birim="km"),
    ctl("konum", "Arızanın yeri", "sayi", 60, min=0, max=200, adim=1, birim="% hat boyu", yardim="%100: karşı bara; üstü: komşu hat"),
    ctl("tip", "Arıza tipi", "sec", "3f", secenek=opt(*TIP.items())),
    ctl("rf", "Arıza (ark) direnci", "sayi", 2, min=0, max=60, adim=0.5, birim="Ω"),
    ctl("besleme", "Uzak uçtan gelen arıza akımı / röle akımı", "sayi", 0, min=0, max=4, adim=0.1, yardim="Karşı baradan da arıza besleniyorsa röle arıza direncini ve komşu hattı olduğundan büyük görür"),
    ctl("k0", "Hattın Z0/Z1 oranı", "sayi", 3.0, min=1, max=6, adim=0.1, goster={"tip": ["1f"]}),
    ctl("kar", "Karakteristik", "sec", "mho", secenek=opt(("mho", "Daire (mho)"), ("dortgen", "Dörtgen"))),
    ctl("z1", "1. bölge erişimi", "sayi", 85, min=50, max=110, adim=1, birim="% hat"),
    ctl("z2", "2. bölge erişimi", "sayi", 120, min=100, max=180, adim=1, birim="% hat"),
    ctl("z3", "3. bölge erişimi", "sayi", 200, min=120, max=350, adim=5, birim="% hat"),
    ctl("t2", "2. bölge süresi", "sayi", 0.40, min=0.1, max=1.0, adim=0.05, birim="s"),
    ctl("t3", "3. bölge süresi", "sayi", 1.0, min=0.3, max=3.0, adim=0.1, birim="s"),
    ctl("r_er", "Dörtgen: direnç erişimi", "sayi", 20, min=2, max=120, adim=1, birim="Ω", goster={"kar": ["dortgen"]}),
    ctl("s", "Hattın taşıdığı yük", "sayi", 80, min=1, max=400, adim=1, birim="MVA"),
    ctl("cosfi", "Yükün güç katsayısı", "sayi", 0.95, min=0.7, max=1.0, adim=0.01),
]


def gorunen(p: dict, m: float | None = None) -> complex:
    """Rölenin gördüğü empedans (Ω, primer)."""
    _, _, z, th = HAT.get(p.get("hat"), HAT["h154"])
    zl = kutup(z * num(p, "l", 40), th)
    m = num(p, "konum", 60) / 100 if m is None else m
    bes = num(p, "besleme", 0); rf = num(p, "rf", 2)
    tip = p.get("tip") if p.get("tip") in TIP else "3f"
    r = rf * (1 + bes) * {"3f": 1.0, "2f": 0.5, "1f": 1 / (1 + (num(p, "k0", 3.0) - 1) / 3)}[tip]
    if m <= 1:
        return m * zl + r
    return zl + (m - 1) * zl * (1 + bes) + r                               # karşı baranın ötesi: uzak uç katkısı komşu hattı «uzatır»


def icinde(p: dict, z: complex, erisim_pct: float) -> bool:
    _, _, zb, th = HAT.get(p.get("hat"), HAT["h154"])
    zr = kutup(zb * num(p, "l", 40) * erisim_pct / 100, th)
    if p.get("kar") == "dortgen":
        x_er = zr.imag; r_er = num(p, "r_er", 20)
        return -0.05 * x_er <= z.imag <= x_er and -0.25 * r_er <= z.real - z.imag / math.tan(math.radians(th)) <= r_er
    return abs(z - zr / 2) <= abs(zr) / 2


def bolge(p: dict, z: complex) -> int | None:
    return next((b for b, k in ((1, "z1"), (2, "z2"), (3, "z3")) if icinde(p, z, num(p, k, {"z1": 85, "z2": 120, "z3": 200}[k]))), None)


def run(p: dict) -> dict:
    ad, un, zb, th = HAT.get(p.get("hat"), HAT["h154"])
    L = num(p, "l", 40); zl = kutup(zb * L, th)
    m = num(p, "konum", 60) / 100
    z = gorunen(p); b = bolge(p, z)
    t2, t3 = num(p, "t2", 0.4), num(p, "t3", 1.0)
    sure = {1: 0.0, 2: t2, 3: t3}.get(b)
    fi = math.degrees(math.acos(min(max(num(p, "cosfi", 0.95), 0.0), 1.0)))
    zyuk = kutup(un * un / num(p, "s", 80), fi)
    yuk_bolge = bolge(p, zyuk)
    asiri = m > 1.0 and b == 1
    gormuyor = m <= 1.0 and b is None
    z1p = num(p, "z1", 85)
    # dörtgen/daire için 1. bölgenin arıza direncine göre erişimi
    def erisim(rf_: float) -> float:
        lo = 0.0
        for j in range(0, 131):
            if bolge({**p, "rf": rf_}, gorunen({**p, "rf": rf_}, j / 100)) == 1:
                lo = j
        return lo

    # --- R–X düzlemi ---
    c = Cizim(900, 330)
    ox, oy = 150, 286
    olc = 250 / max(abs(zl) * num(p, "z3", 200) / 100 * 1.05, 1e-9)
    P = lambda w: (round(ox + w.real * olc, 1), round(oy - w.imag * olc, 1))      # noqa: E731
    c.hat(f"M30,{oy} H520", "soluk", w=1.2); c.hat(f"M{ox},320 V24", "soluk", w=1.2)
    c.yazi(516, oy - 6, "R", "#64748b", 11, anchor="end"); c.yazi(ox + 6, 34, "X", "#64748b", 11)
    renkler = {1: "#15803d", 2: "#b45309", 3: "#dc2626"}
    for bb, key in ((3, "z3"), (2, "z2"), (1, "z1")):
        zr = kutup(zb * L * num(p, key, {"z1": 85, "z2": 120, "z3": 200}[key]) / 100, th)
        if p.get("kar") == "dortgen":
            r_er = num(p, "r_er", 20); tt = math.tan(math.radians(th))
            kose = [complex(-0.25 * r_er + (-0.05 * zr.imag) / tt, -0.05 * zr.imag), complex(r_er + (-0.05 * zr.imag) / tt, -0.05 * zr.imag), complex(r_er + zr.imag / tt, zr.imag), complex(-0.25 * r_er + zr.imag / tt, zr.imag)]
            d = "M" + " L".join(f"{P(q)[0]},{P(q)[1]}" for q in kose) + " Z"
            c.alan(d, renkler[bb], 0.10, renkler[bb])
        else:
            cx, cy = P(zr / 2)
            c.daire(cx, cy, round(abs(zr) / 2 * olc, 1), renkler[bb], None, 1.6)
        ex, ey = P(zr)
        c.yazi(ex + 6, ey - 4, f"{bb}. bölge", renkler[bb], 10, kalin=True)
    hx, hy = P(zl)
    c.hat(f"M{ox},{oy} L{hx},{hy}", "L1", w=3.2); c.daire(hx, hy, 4, "L1", dolgu="#8a4b12"); c.yazi(hx - 8, hy - 8, "karşı bara", "#8a4b12", 10, anchor="end")
    fx, fy = P(z)
    if 20 <= fx <= 540 and 16 <= fy <= 322:
        c.simsek(fx - 10, fy - 12, 1.0); c.daire(fx, fy, 5, "ariza", dolgu="#dc2626"); c.yazi(fx + 9, fy + 4, "rölenin gördüğü", "#b91c1c", 10.5, kalin=True)
        ax, ay = P(min(m, 1.0) * zl + (max(m, 1.0) - 1.0) * zl)
        c.hat(f"M{ax},{ay} L{fx},{fy}", "ariza", kesik=True, w=1.4)
    yx, yy = P(zyuk)
    if yx <= 540:
        c.daire(yx, yy, 5, "mavi", dolgu="#1d4ed8"); c.yazi(yx + 8, yy - 6, "yük", "#1d4ed8", 10.5, kalin=True)
    else:
        ye = oy - (520 - ox) * math.tan(math.radians(fi)); xe = 520.0
        if ye < 40:                                                         # dik açıda ok üst kenardan çıkmasın
            ye = 40.0; xe = ox + (oy - 40) / max(math.tan(math.radians(fi)), 1e-6)
        c.ok(ox, oy, round(xe, 1), round(ye, 1), "mavi", 1.4); c.yazi(round(xe, 1) + 4, round(ye, 1) - 6, "yük →", "#1d4ed8", 10.5, anchor="end")
    x0 = 570
    c.yazi(x0, 44, ad + f" · {fnum(L, 0)} km", "#1e293b", 12.5, kalin=True)
    c.yazi(x0, 64, f"Hat empedansı {fnum(abs(zl), 1)} Ω ∠{fnum(th, 0)}°", "#475569", 11)
    c.yazi(x0, 96, f"Arıza: hattın %{fnum(m * 100, 0)}'inde", "#b91c1c", 12, kalin=True)
    c.yazi(x0, 116, f"{TIP[p.get('tip') if p.get('tip') in TIP else '3f']} · direnç {fnum(num(p, 'rf', 2), 1)} Ω", "#475569", 11)
    c.yazi(x0, 148, f"Rölenin gördüğü empedans", "#334155", 11)
    c.yazi(x0, 168, f"{fnum(z.real, 1)} + j{fnum(z.imag, 1)} Ω", "#1a4d8f", 14, kalin=True)
    c.yazi(x0, 188, f"= {fnum(abs(z), 1)} Ω ∠{fnum(math.degrees(cmath.phase(z)), 0)}°", "#1a4d8f", 11.5)
    c.yazi(x0, 222, (f"{b}. bölge → " + ("gecikmesiz açar" if b == 1 else f"{fnum(sure, 2)} s sonra açar")) if b else "Hiçbir bölgede değil: açmaz", renkler.get(b, "#64748b"), 13, kalin=True)
    c.yazi(x0, 244, "YANLIŞ: komşu hattaki arıza 1. bölgede" if asiri else "Eksik: kendi hattındaki arızayı görmüyor" if gormuyor else ("kendi hattı, 1. bölge: doğru" if (m <= 1 and b == 1) else "hat sonu: 2. bölge gecikmeyle açar" if (m <= 1 and b == 2) else "yedek koruma" if b else "arıza erişimin dışında"),
           "#b91c1c" if (asiri or gormuyor) else "#15803d", 11.5)
    c.yazi(x0, 278, f"Yük empedansı {fnum(abs(zyuk), 0)} Ω ∠{fnum(fi, 0)}°" + (f" — {yuk_bolge}. bölgenin içinde!" if yuk_bolge else " — bölgelerin dışında"), "#b91c1c" if yuk_bolge else "#1d4ed8", 11.5)

    er0 = erisim(0.0); er_rf = erisim(num(p, "rf", 2))
    ozet = [
        K("Rölenin kararı", (f"{b}. bölge" if b else "açmaz"), "bad" if (asiri or gormuyor) else "ok", ("gecikmesiz" if b == 1 else f"{fnum(sure, 2)} s" if b else "erişim dışı") + (" — YANLIŞ: aşırı erişim" if asiri else " — görmüyor" if gormuyor else "")),
        K("Görünen empedans", f"{fnum(abs(z), 1)} Ω", "info", f"{fnum(z.real, 1)} + j{fnum(z.imag, 1)} Ω · ∠{fnum(math.degrees(cmath.phase(z)), 0)}°"),
        K("Arızanın gerçek uzaklığı", f"{fnum(m * L, 1)} km", "info", f"hattın %{fnum(m * 100, 0)}'i · reaktanstan okunan %{fnum(z.imag / zl.imag * 100, 0)}"),
        K("1. bölgenin erişimi", f"%{fnum(er_rf, 0)}", "ok" if er_rf >= 0.9 * er0 else "warn", f"bu arıza direncinde · dirençsiz %{fnum(er0, 0)}"),
        K("Yük empedansı", f"{fnum(abs(zyuk), 0)} Ω", "bad" if yuk_bolge else "ok", f"∠{fnum(fi, 0)}° · " + (f"{yuk_bolge}. bölgenin içinde" if yuk_bolge else "bölgelerin dışında")),
    ]
    kontroller = [
        C("1. bölge karşı baranın ötesini görmüyor mu?", f"arıza %{fnum(m * 100, 0)}'de; 1. bölge erişimi %{fnum(z1p, 0)}", "1. bölge < %100: komşu hattaki arızada gecikmesiz açmamalı", not asiri and z1p < 100,
          "Ölçme hataları (akım ve gerilim trafosu, hat verisi) %10–15'i bulduğundan 1. bölge hattın %80–85'ine ayarlanır — " + YAYGIN, "ikincil"),
        C("Kendi hattındaki arızayı görüyor mu?", (f"{b}. bölge" if b else "hiçbir bölge") + f"; görünen {fnum(z.real, 1)} + j{fnum(z.imag, 1)} Ω", "hat içindeki arıza 1. ya da 2. bölgede olmalı", (b in (1, 2)) if m <= 1 else None,
          "Arıza direnci ve uzak uç katkısı görünen noktayı sağa iter; daire karakteristiği direnç yönünde dardır, dörtgen bu yüzden kullanılır", "hesap"),
        C("2. bölge hattın tamamını örtüyor mu?", f"2. bölge erişimi %{fnum(num(p, 'z2', 120), 0)}", "≥ %120 (hat sonu + karşı bara)", num(p, "z2", 120) >= 120,
          "1. bölgenin göremediği son %15–20'yi ve karşı barayı gecikmeyle örter — " + YAYGIN, "ikincil"),
        C("Yük empedansı bölgelerin dışında mı?", f"Zyük = U²/S = {fnum(abs(zyuk), 0)} Ω ∠{fnum(fi, 0)}°", "en geniş bölgenin dışında kalmalı", yuk_bolge is None,
          "Ağır yükte gerilim/akım oranı küçülür; yük noktası 3. bölgeye girerse röle arıza yokken açar (yük bölgesine girme)", "hesap"),
    ]
    k_sek = "AT oranı / GT oranı"
    girdiler = [
        G("Hattın pozitif ve sıfır bileşen empedansı", f"{fnum(abs(zl), 1)} Ω ∠{fnum(th, 0)}° · Z0/Z1 = {fnum(num(p, 'k0', 3), 1)}", "Hat projesi / iletken ve direk tipi; ölçülmüşse hat empedans ölçümü", "Bölge erişimleri hattın empedansının yüzdesidir; toprak arızasında telafi katsayısı Z0'dan çıkar", "kN = (Z0 − Z1) / (3·Z1)"),
        G("Akım ve gerilim trafosu oranları", "ör. 600/1 A · 154.000/100 V", "Tek hat şeması; etiketler", "Röleye empedans sekonder ohm olarak girilir", f"Zsek = Zprim × {k_sek}"),
        G("Komşu hatlar ve uzak uçtaki kaynaklar", f"uzak uç katkısı / röle akımı = {fnum(num(p, 'besleme', 0), 1)}", "Şebeke kısa devre çalışması", "2. ve 3. bölgenin gerçekte nereye kadar yetiştiğini belirler", "ara besleme etkisi"),
        G("En ağır yük ve en düşük işletme gerilimi", f"{fnum(num(p, 's', 80), 0)} MVA · cos φ {fnum(num(p, 'cosfi', 0.95), 2)}", "İşletme kayıtları; hat kapasitesi", "Yük empedansı en geniş bölgeye girmemeli", "Zyük = U² / S"),
    ]
    adimlar = [
        A("Hat empedansı", "ZL = z · ℓ", f"{fnum(zb, 3)} Ω/km × {fnum(L, 0)} km", f"{fnum(abs(zl), 1)} Ω ∠{fnum(th, 0)}° = {fnum(zl.real, 1)} + j{fnum(zl.imag, 1)} Ω", "hat birim empedansı (tipik)", "tahmini", ["Hattın pozitif ve sıfır bileşen empedansı"]),
        A("Rölenin gördüğü empedans", "Z = m·ZL + Rf·(1 + Iuzak/Iröle) · k", f"m = {fnum(m, 2)} ; Rf = {fnum(num(p, 'rf', 2), 1)} Ω ; k = {'1' if p.get('tip') not in ('2f', '1f') else '1/2' if p.get('tip') == '2f' else '1/(1 + kN)'}", f"{fnum(z.real, 1)} + j{fnum(z.imag, 1)} Ω", "Z = V/I; arıza direncinden uzak ucun akımı da geçer", "hesap", ["Komşu hatlar ve uzak uçtaki kaynaklar"]),
        A("Bölge erişimleri", "Zn = (% erişim) · ZL", f"%{fnum(z1p, 0)} · %{fnum(num(p, 'z2', 120), 0)} · %{fnum(num(p, 'z3', 200), 0)}", " · ".join(f"{fnum(abs(zl) * num(p, k_, d_) / 100, 1)} Ω" for k_, d_ in (("z1", 85), ("z2", 120), ("z3", 200))), YAYGIN, "ikincil", [], "Z1 · Z2 · Z3"),
        A("Yük empedansı", "Zyük = U² / S", f"{fnum(un, 1)}² / {fnum(num(p, 's', 80), 0)}", f"{fnum(abs(zyuk), 0)} Ω ∠{fnum(fi, 0)}°", "temel bağıntı", "hesap", ["En ağır yük ve en düşük işletme gerilimi"]),
    ]
    ayarlar = [
        S("1. bölge erişimi · süresi", f"%{fnum(z1p, 0)} hat = {fnum(abs(zl) * z1p / 100, 1)} Ω primer · gecikmesiz", "—", "Karşı baradaki arızayı görmeyecek kadar kısa", YAYGIN, "ikincil"),
        S("2. bölge erişimi · süresi", f"%{fnum(num(p, 'z2', 120), 0)} = {fnum(abs(zl) * num(p, 'z2', 120) / 100, 1)} Ω · {fnum(t2, 2)} s", "—", "Hattın kalanını ve karşı barayı örter; komşu hattın 1. bölgesini bekler", YAYGIN, "ikincil"),
        S("3. bölge erişimi · süresi", f"%{fnum(num(p, 'z3', 200), 0)} = {fnum(abs(zl) * num(p, 'z3', 200) / 100, 1)} Ω · {fnum(t3, 1)} s", "—", "Komşu hat için yedek; yük empedansına girmemeli", YAYGIN, "ikincil"),
        S("Toprak telafi katsayısı kN", f"{fnum((num(p, 'k0', 3) - 1) / 3, 2)}", "—", "Faz–toprak çevriminin de pozitif bileşen empedansını ölçmesi için", "kN = (Z0 − Z1) / (3·Z1) — temel bağıntı", "hesap"),
    ]
    test = [
        T("Bölge sınırı", f"Hat açısında ({fnum(th, 0)}°) 1. bölge erişiminin %95'i ve %105'i", "%95'te gecikmesiz açar; %105'te 2. bölge süresinde açar", "±%5 ya da kılavuzdaki doğruluk"),
        T("Süreler", "Her bölgenin ortasında bir nokta", f"gecikmesiz · {fnum(t2, 2)} s · {fnum(t3, 1)} s", "±%1 ya da ±30 ms dolayı"),
        T("Yük bölgesi", f"Anma gerilimi, {fnum(num(p, 's', 80), 0)} MVA karşılığı akım, cos φ {fnum(num(p, 'cosfi', 0.95), 2)}", "Hiçbir bölge başlamaz", "en ağır yük ve en düşük gerilimde yinelenir"),
        T("Yön", "Empedansı 180° çevir (arkadaki arıza)", "İleri bölgeler başlamaz", "gerilim trafosu polaritesinin doğrulaması"),
    ]
    konumlar = list(range(0, 151, 5))
    g1 = {"baslik": "Arıza hat boyunca ilerledikçe rölenin gördüğü empedans", "x_ad": "Arızanın yeri (% hat boyu)", "y_ad": "Ω", "ymin": 0,
          "seriler": [{"ad": "reaktans X", "renk": "#1a4d8f", "pts": [[k_, round(gorunen(p, k_ / 100).imag, 2)] for k_ in konumlar]}, {"ad": "direnç R", "renk": "#b45309", "pts": [[k_, round(gorunen(p, k_ / 100).real, 2)] for k_ in konumlar]}],
          "yatay": [{"y": zl.imag * z1p / 100, "etiket": "1. bölge X erişimi", "renk": "#15803d"}], "isaretler": [{"x": 100, "etiket": "karşı bara"}, {"x": num(p, "konum", 60), "etiket": "arıza"}]}
    g2 = {"baslik": "Arıza direnci büyüdükçe 1. bölgenin erişimi", "x_ad": "Arıza direnci (Ω)", "y_ad": "Erişim (% hat boyu)", "ymin": 0,
          "seriler": [{"ad": "daire (mho)", "renk": "#dc2626", "pts": [[r_, erisim_k(p, r_, "mho")] for r_ in (0, 1, 2, 4, 6, 10, 15, 20, 30)]}, {"ad": "dörtgen", "renk": "#1a4d8f", "pts": [[r_, erisim_k(p, r_, "dortgen")] for r_ in (0, 1, 2, 4, 6, 10, 15, 20, 30)]}],
          "yatay": [{"y": z1p, "etiket": f"ayar %{fnum(z1p, 0)}", "renk": "#15803d"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": [], "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Röle bulunduğu noktada gerilimi ve akımı ölçer, birini ötekine böler. Sağlam hatta bu oran yük empedansıdır: büyük ve hemen hemen direnç. Arızada oran, röleden arıza yerine kadar olan hat empedansına düşer: küçük ve hemen hemen reaktans.",
            f"Hat empedansı boyla orantılıdır. Hattın %{fnum(m * 100, 0)}'indeki arızada röle {fnum(z.imag, 1)} Ω reaktans görür; bunu hattın toplam reaktansına ({fnum(zl.imag, 1)} Ω) bölerek uzaklığı bulur. Kaynak ne kadar güçlü olursa olsun bu oran değişmez: aşırı akım rölesinden farkı budur.",
            "Ayar bir bölgedir: R–X düzleminde bir daire ya da dörtgen. Ölçülen nokta bölgenin içindeyse röle çalışır. 1. bölge gecikmesizdir ama hattın tamamına ayarlanmaz: ölçme hatası yüzünden karşı baradaki arızayı da görebilir.",
            "Kalan bölümü 2. bölge gecikmeyle örter; 3. bölge komşu hat için yedektir. Aynı arızayı her iki ucun rölesi de görür: hattın ortasındaki arızada iki uç da gecikmesiz açar, uçlara yakın arızada bir uç bekler.",
            "Arıza direnci (ark, direk topraklaması) görünen noktayı sağa kaydırır. Uzak uçtan da akım geliyorsa bu direnç olduğundan büyük görünür. Daire karakteristiği direnç yönünde dardır: dirençli arızada erişim kısalır.",
            "Ağır yükte yük empedansı küçülür ve en geniş bölgeye yaklaşır. İçine girerse röle arıza yokken açar; bunun için yük bölgesi karakteristikten kesilir ya da 3. bölge daraltılır.",
        ],
        "dersler": [
            "Mesafe rölesi kaynak gücünden bağımsızdır: şebeke değişse de 1. bölgenin erişimi aynı kalır.",
            "1. bölge %80–85: geri kalanı gecikmeli. Hattın iki ucunu da gecikmesiz açmak için haberleşmeli düzen gerekir.",
            "Arıza direnci ve uzak uç katkısı röleyi «kısa görür» yapar; komşu hat için yedek koruma göründüğünden zayıftır.",
            "Gerilim trafosu sigortası atarsa röle sıfır gerilim, yani sıfır empedans görür: gerilim devresi denetimi mesafe korumanın ayrılmaz parçasıdır.",
        ],
        "tablolar": [{"baslik": "Arızanın yerine göre röle ne yapar", "cols": ["Arıza yeri", "Görünen empedans", "Bölge", "Açma süresi"],
                      "rows": [[f"%{k_}" + (" (karşı bara)" if k_ == 100 else " (komşu hat)" if k_ > 100 else ""), f"{fnum(q.real, 1)} + j{fnum(q.imag, 1)} Ω", (f"{bb}." if bb else "—"), ("gecikmesiz" if bb == 1 else f"{fnum(t2, 2)} s" if bb == 2 else f"{fnum(t3, 1)} s" if bb == 3 else "açmaz")]
                               for k_ in (10, 50, 80, 90, 100, 110, 150, 190) for q in [gorunen(p, k_ / 100)] for bb in [bolge(p, q)]]}],
    }


def erisim_k(p: dict, rf: float, kar: str) -> float:
    """1. bölgenin hat boyunca erişimi (%), verilen arıza direnci ve karakteristikle."""
    q = {**p, "rf": rf, "kar": kar}
    lo = 0
    for j in range(0, 131, 1):
        if bolge(q, gorunen(q, j / 100)) == 1:
            lo = j
    return lo
