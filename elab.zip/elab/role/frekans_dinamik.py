"""Frekans neden düşer: üretim kaybında frekansın ilk düşme hızı (atalet), en düşük değeri (birincil rezerv ve yük sönümü), düşük frekansla yük atma
ve evirici payı arttıkça olanlar; santralin frekans ve ROCOF korumalarının bu olaydaki davranışı.

Model (şebeke tabanında birim değerler): 2·H·d(Δf)/dt = ΔPm − ΔPL − D·Δf — salınım denklemi; hız regülatörü birinci dereceden gecikmeyle
(eğim %5, zaman sabiti Tg) rezervi devreye alır; yük atma kademeleri eşik frekansında yükün bir bölümünü keser. Atalet yalnız dönen makinelerden gelir:
evirici payı arttıkça etkin H azalır. İlk düşme hızı df/dt = ΔP·f0/(2·H). Bu model öğretim amaçlıdır; H, D, Tg ve yük atma kademeleri tipiktir (tahmini) —
iletim işletmecisinin yük atma planı görülmedi. Santral korumalarının ayar aralıkları: LÜY Uygulama Tebliği Ek-2 Tablo-2 (81U 47 Hz 0,2 s; 81O 51 Hz 0,2 s;
frekans değişim hızı 0,5–2,5 Hz/s, 0,2 s; süreler kesici dahil)."""
from __future__ import annotations

import math

from .ortak import A, C, Cizim, G, K, LUY, P3U, S, T, ctl, fnum, num

ID = "frekans_dinamik"
BASLIK = "Frekans neden düşer (atalet)"
IKON = "🎢"
GIRIS = ("Şebekede büyük bir santral devre dışı kalınca frekans düşer; ne kadar hızlı ve ne kadar derine düşeceğini dönen kütlelerin ataleti, hız regülatörleri ve yük atma "
         "belirler. Evirici payı arttıkça atalet azalır, düşüş hızlanır. Kaybı, ataleti ve evirici payını değiştirin; frekansın izini ve santral korumalarının bu "
         "olayda ne yaptığını izleyin.")
F0 = 50.0

KONTROLLER = [
    ctl("dp", "Kaybedilen üretim", "sayi", 6, min=1, max=40, adim=1, birim="% (şebeke yüküne göre)"),
    ctl("h", "Dönen makinelerin atalet sabiti H", "sayi", 5.0, min=1, max=9, adim=0.1, birim="s", yardim="Buhar ve gaz türbinli gruplar 3–6 s, hidrolik 2–4 s"),
    ctl("ev", "Üretimde evirici payı", "sayi", 20, min=0, max=90, adim=5, birim="%", yardim="Güneş ve rüzgâr eviricileri atalet sağlamaz: etkin H = H × (1 − pay)"),
    ctl("rez", "Birincil rezerv", "sayi", 5, min=0, max=30, adim=1, birim="%"),
    ctl("tg", "Hız regülatörü zaman sabiti", "sayi", 6, min=1, max=20, adim=0.5, birim="s"),
    ctl("d", "Yük sönümü D", "sayi", 1.0, min=0, max=3, adim=0.1, birim="% yük / % frekans"),
    ctl("ufls", "Düşük frekansla yük atma var", "onay", True),
    ctl("uf", "İlk yük atma kademesi", "sayi", 49.0, min=47.5, max=49.6, adim=0.1, birim="Hz", goster={"ufls": [True]}),
    ctl("uy", "Kademe başına atılan yük", "sayi", 5, min=1, max=20, adim=1, birim="%", goster={"ufls": [True]}),
    ctl("rocof", "Santral › df/dt başlatma", "sayi", 1.0, min=0.2, max=5, adim=0.1, birim="Hz/s"),
    ctl("f81", "Santral › f< (düşük frekans)", "sayi", 47.0, min=45, max=49.9, adim=0.1, birim="Hz"),
    ctl("dg", "Aynı ROCOF ayarıyla korunan santrallerin payı", "sayi", 5, min=0, max=30, adim=1, birim="%", yardim="Bu santraller ROCOF ile ayrılırsa kayıp büyür"),
]


def benzet(p: dict) -> dict:
    dp, h = num(p, "dp", 6) / 100, num(p, "h", 5.0) * (1 - num(p, "ev", 20) / 100)
    h = max(h, 0.05)
    rez, tg, d = num(p, "rez", 5) / 100, num(p, "tg", 6), num(p, "d", 1.0)
    ufls, uf, uy = bool(p.get("ufls", True)), num(p, "uf", 49.0), num(p, "uy", 5) / 100
    r_ay, f81, dg = num(p, "rocof", 1.0), num(p, "f81", 47.0), num(p, "dg", 5) / 100
    dt = 0.02
    df, pm, atilan, kayip = 0.0, 0.0, 0.0, dp
    kademe = [(uf - 0.2 * j, uy) for j in range(4)]; calisan = []
    ts, fs, rs = [], [], []
    ustte = 0.0; t_rocof = None; t_f81 = None; alt = 0.0
    for k in range(int(30 / dt) + 1):
        t = k * dt
        hedef = min(rez, max(0.0, -df / 0.05))                              # regülatör: %5 eğim, rezervle sınırlı
        pm += (hedef - pm) * dt / tg
        acc = (pm - kayip + atilan - d * df) / (2 * h)                       # d(Δf pu)/dt
        df += acc * dt
        f = F0 * (1 + df); rr = acc * F0
        if ufls:
            for esik, yuk in kademe:
                if f <= esik and esik not in calisan:
                    calisan.append(esik); atilan += yuk
        ustte = ustte + dt if abs(rr) >= r_ay else 0.0
        if ustte >= 0.14 and t_rocof is None:                               # 0,2 s − kesici 60 ms
            t_rocof = t; kayip += dg
        alt = alt + dt if f <= f81 else 0.0
        if alt >= 0.14 and t_f81 is None:
            t_f81 = t
        if k % 5 == 0:
            ts.append(round(t, 2)); fs.append(f); rs.append(rr)
    return {"t": ts, "f": fs, "r": rs, "h": h, "r0": -dp * F0 / (2 * h), "dip": min(fs), "t_dip": ts[fs.index(min(fs))], "son": fs[-1], "calisan": calisan, "t_rocof": t_rocof, "t_f81": t_f81, "atilan": atilan}


def run(p: dict) -> dict:
    b = benzet(p)
    r_ay, f81, dp = num(p, "rocof", 1.0), num(p, "f81", 47.0), num(p, "dp", 6)
    rocof_acti = b["t_rocof"] is not None; f_acti = b["t_f81"] is not None
    aralik = 0.5 <= r_ay <= 2.5

    c = Cizim(900, 300)
    c.kutu(40, 50, 190, 70, "Üretim", f"%{fnum(100 - dp, 0)} kaldı (−%{fnum(dp, 0)})", "gecersiz")
    c.kutu(670, 50, 190, 70, "Yük", f"%{fnum(100 - b['atilan'] * 100, 0)}" + (f" (−%{fnum(b['atilan'] * 100, 0)} atıldı)" if b["atilan"] else ""), "vurgu" if b["atilan"] else "normal")
    c.hat("M230,85 H670", "L1", hot=True, w=3)
    c.daire(450, 85, 44, "cizgi", dolgu="#fff", w=2.4); c.yazi(450, 80, "dönen kütle", "#334155", 10.5, anchor="middle"); c.yazi(450, 96, f"H = {fnum(b['h'], 1)} s", "#1a4d8f", 12, kalin=True, anchor="middle")
    c.yazi(450, 150, f"evirici payı %{fnum(num(p, 'ev', 20), 0)}: atalet {fnum(num(p, 'h', 5), 1)} → {fnum(b['h'], 1)} s", "#64748b", 10.5, anchor="middle")
    c.yazi(40, 186, f"İlk düşme hızı {fnum(b['r0'], 2)} Hz/s", "#b91c1c", 13, kalin=True)
    c.yazi(40, 208, f"En düşük frekans {fnum(b['dip'], 2)} Hz ({fnum(b['t_dip'], 1)} s'de) · sonunda {fnum(b['son'], 2)} Hz", "#1a4d8f", 12.5, kalin=True)
    c.yazi(40, 230, "Yük atma: " + (", ".join(f"{fnum(x, 1)} Hz" for x in b["calisan"]) if b["calisan"] else "kademe çalışmadı"), "#334155", 11.5)
    c.yazi(40, 258, "Santral ROCOF koruması: " + (f"AÇAR ({fnum(b['t_rocof'], 2)} s) — şebeke olayında gereksiz ayrılma" if rocof_acti else "açmaz"), "#b91c1c" if rocof_acti else "#15803d", 12, kalin=True)
    c.yazi(40, 278, "Santral f< koruması: " + (f"AÇAR ({fnum(b['t_f81'], 1)} s)" if f_acti else "açmaz"), "#b91c1c" if f_acti else "#15803d", 12, kalin=True)

    ozet = [
        K("İlk düşme hızı", f"{fnum(b['r0'], 2)} Hz/s", "ok" if abs(b["r0"]) < r_ay else "warn", f"df/dt = ΔP·f0 / (2·H) · etkin H {fnum(b['h'], 1)} s"),
        K("En düşük frekans", f"{fnum(b['dip'], 2)} Hz", "ok" if b["dip"] > 49.0 else "warn" if b["dip"] > f81 else "bad", f"{fnum(b['t_dip'], 1)} s'de"),
        K("Oturduğu frekans", f"{fnum(b['son'], 2)} Hz", "info", "birincil rezerv ve yük sönümüyle; ikincil denetim sonra 50 Hz'e getirir"),
        K("Atılan yük", f"%{fnum(b['atilan'] * 100, 0)}", "info" if not b["atilan"] else "warn", f"{len(b['calisan'])} kademe" if b["calisan"] else "kademe çalışmadı"),
        K("Santral korumaları", "ayrılmıyor" if not (rocof_acti or f_acti) else ("ROCOF AÇAR" if rocof_acti else "f< AÇAR"), "ok" if not (rocof_acti or f_acti) else "bad", "şebeke olayında bağlı kalmak istenir"),
    ]
    kontroller = [
        C("Santral ROCOF koruması şebeke olayında açmıyor mu?", f"şebekedeki en büyük hız {fnum(max(abs(v) for v in b['r']), 2)} Hz/s; ayar {fnum(r_ay, 1)} Hz/s", "şebeke genelindeki düşüşte açmamalı; yalnız adada açmalı", not rocof_acti,
          "ROCOF koruması ada algılaması içindir. Atalet azaldıkça şebeke olayındaki df/dt, ada durumundakine yaklaşır: düşük ayar gereksiz ayrılmaya, bu da kaybın büyümesine yol açar", "hesap"),
        C("ROCOF ayarı Tebliğ aralığında mı?", f"{fnum(r_ay, 1)} Hz/s", "0,5 … 2,5 Hz/s; süre 0,2 s (kesici dahil)", aralik, LUY, "resmi"),
        C("Frekans santralin f< ayarına inmiyor mu?", f"en düşük {fnum(b['dip'], 2)} Hz", f"> {fnum(f81, 1)} Hz", not f_acti,
          "Düşük frekans kademesi 47 Hz, 0,2 s (dağıtım şirketi 47–49,5 Hz arasında ve 0,2–300 s arasında başka değer isteyebilir) — " + LUY, "resmi"),
        C("Yük atma frekansı toparlıyor mu?", f"oturduğu frekans {fnum(b['son'], 2)} Hz", "≥ 49,0 Hz dolayı (ikincil denetim devralana kadar)", b["son"] >= 48.8,
          "Rezerv kaybı karşılamıyorsa frekans düşmeye devam eder; yük atma kademeleri dengeyi yükten sağlar. Kademe değerleri burada örnektir", "tahmini"),
    ]
    girdiler = [
        G("Şebekenin atalet sabiti ve evirici payı", f"H = {fnum(num(p, 'h', 5), 1)} s · evirici %{fnum(num(p, 'ev', 20), 0)}", "İletim işletmecisinin sistem çalışmaları", "İlk düşme hızını belirler; santralin ROCOF ayarı bunun üstünde kalmalı", "df/dt = ΔP·f0/(2·H)"),
        G("En büyük tek üretim kaybı", f"%{fnum(dp, 0)}", "Sistem planlama ölçütü (en büyük ünite / bağlantı)", "Olayın büyüklüğü: rezerv ve yük atma buna göre kurulur", "ΔP"),
        G("Dağıtım şirketinin istediği koruma ayarları", f"df/dt {fnum(r_ay, 1)} Hz/s · f< {fnum(f81, 1)} Hz", "Bağlantı görüşü; Tebliğ Ek-2", "Santral ada kalmamalı ama şebeke olayında da ayrılmamalı: iki istek birbirini sınırlar", "81R · 81U"),
    ]
    adimlar = [
        A("Etkin atalet", "H(etkin) = H × (1 − evirici payı)", f"{fnum(num(p, 'h', 5), 1)} × (1 − {fnum(num(p, 'ev', 20) / 100, 2)})", f"{fnum(b['h'], 2)} s", "atalet yalnız şebekeye doğrudan bağlı dönen makinelerden gelir", "hesap", ["Şebekenin atalet sabiti ve evirici payı"]),
        A("İlk düşme hızı", "df/dt = −ΔP · f0 / (2·H)", f"−{fnum(dp / 100, 2)} × 50 / (2 × {fnum(b['h'], 2)})", f"{fnum(b['r0'], 2)} Hz/s", "salınım denklemi", "hesap", ["En büyük tek üretim kaybı"], "df/dt"),
        A("En düşük frekans", "regülatör rezervi devreye alana ve yük atılana kadar düşüş sürer", f"rezerv %{fnum(num(p, 'rez', 5), 0)}, Tg = {fnum(num(p, 'tg', 6), 1)} s", f"{fnum(b['dip'], 2)} Hz", "benzetim (bu sayfa)", "tahmini"),
        A("ROCOF kademesinin süresi", "ayarın üstünde 0,2 s − kesici süresi kadar kalırsa açar", f"|df/dt| ≥ {fnum(r_ay, 1)} Hz/s", (f"{fnum(b['t_rocof'], 2)} s'de açar" if rocof_acti else "açmaz"), LUY, "resmi", ["Dağıtım şirketinin istediği koruma ayarları"], "df/dt · t"),
    ]
    ayarlar = [
        S("df/dt › Başlatma", f"{fnum(r_ay, 1)} Hz/s", "Tebliğ: 0,5 … 2,5 Hz/s", "Şebekede beklenen en büyük düşme hızının üstünde, adadaki hızın altında", LUY),
        S("df/dt › Çalışma süresi", "0,2 s − kesici süresi", "—", "Tebliğdeki süre kesiciyi içerir", LUY),
        S("f< › Başlatma · süre", f"{fnum(f81, 1)} Hz · 0,2 s − kesici süresi", "47 … 49,5 Hz", "Yük atma kademelerinin altında kalmalı: santral yük atılmadan ayrılırsa kayıp büyür", LUY),
        S("Ayrıntılı kademe ayarı", "bkz. Frekans (81) ve ROCOF (81R) sayfaları", "—", "Ölçme penceresi, düşük gerilim kilidi, en kısa gecikme", P3U + " böl. 5.37, 5.38"),
    ]
    test = [
        T("ROCOF başlatma", "Frekansı 50 Hz'ten sabit eğimle düşür", f"Başlatma {fnum(r_ay, 1)} Hz/s dolayında", "bkz. ROCOF sayfası"),
        T("Şebeke olayı benzetimi", f"Eğim {fnum(abs(b['r0']), 2)} Hz/s ile {fnum(b['dip'], 1)} Hz'e in, sonra toparlan", "Kademe " + ("açar (gereksiz)" if rocof_acti else "açmaz"), "test cihazında frekans rampası"),
    ]
    g1 = {"baslik": "Frekansın izi", "x_ad": "Zaman (s) — kayıp t = 0'da", "y_ad": "Frekans (Hz)",
          "seriler": [{"ad": "frekans", "renk": "#1a4d8f", "pts": [[t, round(f, 3)] for t, f in zip(b["t"], b["f"])]}],
          "yatay": [{"y": f81, "etiket": f"santral f< {fnum(f81, 1)} Hz", "renk": "#dc2626"}] + ([{"y": num(p, "uf", 49.0), "etiket": "ilk yük atma", "renk": "#b45309"}] if p.get("ufls", True) else []),
          "isaretler": [{"x": b["t_rocof"], "etiket": "ROCOF açtı"}] if rocof_acti else []}
    g2 = {"baslik": "Frekansın değişim hızı", "x_ad": "Zaman (s)", "y_ad": "df/dt (Hz/s)",
          "seriler": [{"ad": "df/dt", "renk": "#dc2626", "pts": [[t, round(r, 3)] for t, r in list(zip(b["t"], b["r"]))[:120]]}],
          "yatay": [{"y": -r_ay, "etiket": f"santral ayarı −{fnum(r_ay, 1)} Hz/s", "renk": "#15803d"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["81", "df-dt"], "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Şebekede her an üretim yüke eşittir. Bir santral devre dışı kalınca eksik güç, ilk anda dönen bütün makinelerin kinetik enerjisinden karşılanır: makineler yavaşlar, frekans düşer.",
            f"İlk düşme hızını atalet belirler: df/dt = ΔP·f0/(2·H). %{fnum(dp, 0)}'lik kayıp ve {fnum(b['h'], 1)} s etkin ataletle {fnum(abs(b['r0']), 2)} Hz/s. Atalet yarıya inerse hız iki katına çıkar.",
            "Birkaç saniye içinde hız regülatörleri devreye girer ve rezervi şebekeye verir; frekans düştükçe yükler de biraz daha az güç çeker. Düşüş yavaşlar, bir dip yapar ve toparlanır.",
            "Rezerv kaybı karşılamıyorsa frekans düşmeye devam eder. O zaman düşük frekans röleleri kademe kademe yük atar: denge üretimi artırarak değil, yükü azaltarak kurulur.",
            "Eviriciler şebekeye bir dönen kütleyle bağlı değildir: atalet sağlamazlar. Güneş ve rüzgâr payı arttıkça aynı kayıp frekansı daha hızlı düşürür; regülatörlerin ve yük atmanın tepki süresi kısalır.",
            "Santrallerin ROCOF koruması adayı algılamak içindir. Şebeke olayındaki düşme hızı ayarı aşarsa santraller gereksiz ayrılır, kayıp büyür ve frekans daha da düşer. Ayar bu yüzden şebekenin ataleti düşünülerek seçilir.",
        ],
        "dersler": [
            "Frekans gücün dengesidir, gerilim gibi yerel değildir: kayıp nerede olursa olsun bütün şebekede aynı düşüş görülür.",
            "İlk saniyeyi atalet, sonraki on saniyeyi rezerv, sonrasını yük atma belirler.",
            "Düşük ROCOF ayarı adayı çabuk yakalar ama şebeke olayında santrali ayırır; atalet azaldıkça bu çelişki büyür.",
            "Santralin f< ayarı yük atma kademelerinin altında olmalı: üretim, yükten önce ayrılmamalı.",
        ],
        "tablolar": [{"baslik": "Evirici payı arttıkça aynı kayıp", "cols": ["Evirici payı", "Etkin H", "İlk düşme hızı", "En düşük frekans", "Santral ROCOF"],
                      "rows": [[f"%{e}", f"{fnum(bb['h'], 1)} s", f"{fnum(bb['r0'], 2)} Hz/s", f"{fnum(bb['dip'], 2)} Hz", "açar" if bb["t_rocof"] is not None else "açmaz"] for e in (0, 20, 40, 60, 80) for bb in [benzet({**p, "ev": e})]]}],
    }
