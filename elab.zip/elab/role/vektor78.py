"""Gerilim vektör kayması (ANSI 78V) — şebeke kaybı (ada) koruması, Easergy P3 «Vector shift» kademesi.

Dayanak: P3U/en M/J006 böl. 5.35 (şebeke kaybı korumasıdır; pozitif bileşen gerilimine dayanır; açı değişimi pozitif bileşen geriliminin faz açısı iki periyot — 40 ms —
öncesiyle karşılaştırılarak bulunur; eşik aşılınca kademe başlar ve kilitlenir, süre dolunca açar; frekans penceresinin ya da U1 gerilim penceresinin dışında kademe
kilitlenir / sıfırlanır; gerilim ölçme modu 3LN ya da 2LL+Uo ve frekans uyarlama modu «Fixed» olmalıdır), Çizelge 90 (vektör kayması 2–30°, varsayılan 10°; frekans penceresi
±1–5 Hz, varsayılan 3; düşük gerilim kilidi %80–95, varsayılan 90; yüksek gerilim kilidi %105–120; gecikme 0,10–60 s, varsayılan 0,20 s);
Lisanssız Üretim Tebliği Ek-2 Tablo-2 (vektör kayması 6°…9°, 0,2 s; dağıtım şirketi etüdüne göre vektör kayması ya da ROCOF'tan biri istenebilir).
Ada anındaki açı sıçraması Δθ = atan[ΔP·x′d / (1 + ΔQ·x′d)] jeneratörün geçici reaktansı üzerindeki gerilim düşümünün değişiminden gelir (hesap)."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, LUY, P3U, S, T, ctl, fnum, num, opt, tek_hat

ID = "vektor78"
BASLIK = "Vektör kayması (78V)"
IKON = "↻"
GIRIS = ("Santral şebekeden koptuğu anda yükü birden değişir; jeneratörün iç gerilimi ile uç gerilimi arasındaki açı da birden değişir. Uç geriliminin fazörü "
         "bir periyot içinde birkaç derece sıçrar. Vektör kayması rölesi bu sıçramayı yakalar: frekansın kaymasını beklemez, ama sıçrama küçükse adayı göremez.")

OLAY = {"ada": "Ada: şebeke bağlantısı koptu", "ariza": "Şebekede kısa devre (gerilim çöküyor, açı sıçrıyor)", "anahtar": "Şebekede anahtarlama (küçük açı sıçraması)", "normal": "Normal işletme"}

KONTROLLER = [
    ctl("olay", "Olay", "sec", "ada", secenek=opt(*OLAY.items())),
    ctl("dp", "Ada anında üretim ile yük arasındaki fark", "sayi", 60, min=0, max=100, adim=1, birim="% Sn", goster={"olay": ["ada"]}),
    ctl("xd", "Jeneratörün geçici reaktansı x′d (+ yükseltici trafo)", "sayi", 28, min=10, max=50, adim=1, birim="%", yardim="Jeneratör veri föyü; açı sıçramasının büyüklüğünü belirler"),
    ctl("h", "Santralin atalet sabiti H", "sayi", 1.5, min=0.3, max=8, adim=0.1, birim="s"),
    ctl("u_ar", "Arıza sırasında pozitif bileşen gerilimi", "sayi", 60, min=5, max=100, adim=1, birim="%Un", goster={"olay": ["ariza"]}),
    ctl("sicrama", "Şebeke olayındaki açı sıçraması", "sayi", 12, min=0, max=40, adim=1, birim="°", goster={"olay": ["ariza", "anahtar"]}),
    ctl("ayar", "Röle › Vektör kayması", "sayi", 8, min=2, max=30, adim=1, birim="°"),
    ctl("t", "Röle › Çalışma gecikmesi", "sayi", 0.10, min=0.10, max=60, adim=0.01, birim="s"),
    ctl("fwin", "Röle › Frekans penceresi", "sayi", 3, min=1, max=5, adim=1, birim="±Hz"),
    ctl("lv", "Röle › Düşük gerilim kilidi", "sayi", 90, min=80, max=95, adim=1, birim="%Un"),
    ctl("t_kesici", "Kesicinin açma süresi", "sayi", 60, min=20, max=120, adim=5, birim="ms"),
]


def sicrama_ada(dp: float, xd: float) -> float:
    """Ada anında uç geriliminin açı sıçraması (°): Δθ = atan(ΔP · x′d); reaktif güç değişimi ihmal."""
    return math.degrees(math.atan(dp * xd))


def run(p: dict) -> dict:
    o = p.get("olay") if p.get("olay") in OLAY else "ada"
    dp, xd, h = num(p, "dp", 60) / 100, num(p, "xd", 28) / 100, num(p, "h", 1.5)
    ayar, t, tk = num(p, "ayar", 8), num(p, "t", 0.1), num(p, "t_kesici", 60) / 1000
    jump = {"ada": sicrama_ada(dp, xd), "ariza": num(p, "sicrama", 12), "anahtar": num(p, "sicrama", 12), "normal": 0.0}[o]
    egim = dp * 50 / (2 * h) if o == "ada" else 0.0                       # Hz/s (frekans düşer)
    u1 = {"ariza": num(p, "u_ar", 60)}.get(o, 100.0)
    T0, dt = 0.2, 0.005
    ts = [j * dt for j in range(141)]
    aci, olc, frek = [], [], []
    for x in ts:
        if x < T0:
            a_, f_ = 0.0, 50.0
        else:
            f_ = 50.0 - egim * (x - T0)
            a_ = -jump                                                 # yalnız ani sıçrama (frekans kaymasının biriktirdiği açı ölçüye katılmadı: bkz. kontrol satırı)
        aci.append(a_); frek.append(f_)
    n40 = int(round(0.04 / dt))
    for j in range(len(ts)):
        olc.append(abs(aci[j] - aci[max(0, j - n40)]))                    # iki periyot öncesine göre açı değişimi
    basla = next((ts[j] for j in range(len(ts)) if olc[j] > ayar), None)
    kilit_u = u1 < num(p, "lv", 90)
    kilit_f = basla is not None and any(abs(frek[j] - 50) > num(p, "fwin", 3) for j in range(len(ts)) if basla <= ts[j] <= basla + t)
    acar = basla is not None and not kilit_u and not kilit_f
    beklenen = o == "ada"
    kor = math.tan(math.radians(ayar)) / xd * 100                         # kör bölge: bu farkın altında sıçrama eşiğe ulaşmaz
    c = tek_hat(("Santral", f"x′d = %{fnum(xd * 100, 0)}"), ("Dağıtım şebekesi", OLAY[o].split(":")[0].split(" (")[0]), ("78V  vektör kayması", "AÇTI" if acar else ("kilitli" if basla is not None else "başlamadı")),
                "acti" if acar else ("gecersiz" if beklenen else "normal"), 620 if o == "ariza" else None, "sag", ileri=False, kesici_acik=acar)
    c.yazi(500, 190, f"Açı sıçraması {fnum(jump, 1)}° · ayar {fnum(ayar, 0)}° · U1 = %{fnum(u1, 0)}", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, ("Kademe başladı; " + ("gerilim penceresi dışında: kilitlendi" if kilit_u else "frekans penceresi dışında: kilitlendi" if kilit_f else f"{fnum(t + tk, 2)} s sonra ayrıldı")) if basla is not None else "Sıçrama eşiğin altında: kademe başlamadı", "#334155", 11)
    c.yazi(500, 226, f"Kör bölge: üretim–yük farkı %{fnum(kor, 0)} Sn'in altındaysa sıçrama {fnum(ayar, 0)}°'ye ulaşmaz", "#334155", 11)
    ozet = [
        K("Sonuç", "AÇTI" if acar else "açmadı", "ok" if acar == beklenen else "bad", ("ada tespit edildi" if acar else "ada görülmedi (kör bölge)") if beklenen else ("gereksiz açma" if acar else "doğru: bağlı kaldı")),
        K("Açı sıçraması", f"{fnum(jump, 1)}°", "info", f"ayar {fnum(ayar, 0)}°"),
        K("Kör bölge", f"± %{fnum(kor, 0)} Sn", "ok" if kor <= 30 else "warn", "tan(ayar) / x′d"),
        K("Temizleme süresi", f"{fnum(t + tk, 2)} s" if acar else "—", "info" if not acar else ("ok" if t + tk <= 0.2 + 1e-9 else "bad"), "Tebliğ sınırı 0,2 s"),
        K("Aynı adada ROCOF", f"{fnum(egim, 2)} Hz/s" if o == "ada" else "—", "info", "frekansın kayma hızı"),
    ]
    kontroller = [
        C("Bu olayda davranış doğru mu?", "açtı" if acar else "açmadı", "adada ayrılır; şebeke arızasında ve anahtarlamada bağlı kalır", acar == beklenen, P3U + " böl. 5.35", "resmi"),
        C("Ayar Tebliğ aralığında mı?", f"{fnum(ayar, 0)}° · röle {fnum(t, 2)} s + kesici = {fnum(t + tk, 2)} s", "6° … 9°; temizleme 0,2 s", 6 <= ayar <= 9 and t + tk <= 0.2 + 1e-9, LUY + " (dipnot c)", "resmi"),
        C("Şebeke arızasında gerilim kilidi çalışıyor mu?", f"düşük gerilim kilidi %{fnum(num(p, 'lv', 90), 0)}; arızada U1 ≈ %{fnum(num(p, 'u_ar', 60), 0)}", "U1 kilit sınırının altındaysa kademe kilitlenir", True,
          "Kısa devrede de açı sıçrar ama gerilim çöker; U1 penceresi (düşük / yüksek gerilim kilidi) bu durumu ayırır — " + P3U + " böl. 5.35, Çizelge 90", "resmi"),
        C("Kör bölge kabul edilebilir mi?", f"± %{fnum(kor, 0)} Sn (bu ayar ve x′d ile)", "adadaki olağan üretim–yük farkının altında olmalı", (kor <= num(p, "dp", 60)) if o == "ada" else None,
          "Δθ = atan(ΔP · x′d): fark küçükse sıçrama eşiğe ulaşmaz (hesap). Kör bölgede adayı 27 / 59 / 81 ya da uzaktan açtırma yakalar", "resmi"),
        C("Yavaş frekans kayması da başlatır mı?", "benzetim yalnız ani sıçramayı ölçer", "kılavuz: açı, iki periyot (40 ms) öncesiyle karşılaştırılır", None,
          "Frekans anma değerinden saptığında da 40 ms'lik pencerede açı farkı oluşur (360° × Δf × 0,04 s: 0,5 Hz'te 7°). Rölenin bunu sıçramadan nasıl ayırdığı kılavuzda açık değildir — " + P3U + " böl. 5.35", "dogrulanacak"),
        C("Ölçme koşulları", "gerilim ölçme modu 3LN ya da 2LL+Uo; frekans uyarlama «Fixed»", "değilse fonksiyon ekranda görünmez", None, P3U + " böl. 5.35", "resmi"),
    ]
    girdiler = [
        G("Dağıtım şirketinin ada koruması isteği", "vektör kayması 6–9° ya da ROCOF 0,5–2,5 Hz/s; 0,2 s", "Bağlantı görüşü", "Tebliğ ikisinden birini ister; değer dağıtım şirketinindir", "Vektör kayması ayarı"),
        G("Jeneratörün geçici reaktansı x′d (ve yükseltici trafo uk)", f"%{fnum(xd * 100, 0)}", "Jeneratör veri föyü; trafo etiketi", "Aynı yük değişiminde açı sıçraması reaktansla orantılıdır", "Δθ = atan(ΔP · x′d)"),
        G("Adada beklenen üretim–yük farkı", f"%{fnum(dp * 100, 0)} Sn", "İhracat / ithalat düzeyi; yerel yük", "Sıçramanın büyüklüğünü belirler; fark küçükse röle kördür", "kör bölge = tan(ayar) / x′d"),
        G("Şebekede olağan anahtarlamalarda görülen açı sıçraması", "birkaç derece", "Dağıtım şirketi; röle olay kayıtları", "Ayar bunun üstünde olmalı; yoksa her anahtarlamada santral düşer", "alt sınır"),
        G("Gerilim trafosu bağlantısı ve ölçme modu", "3LN ya da 2LL+Uo", "Röle ayarı", "Fonksiyon pozitif bileşen gerilimiyle çalışır", "ölçme modu"),
    ]
    adimlar = [
        A("Ada anındaki açı sıçraması", "Δθ = atan(ΔP · x′d)", f"atan({fnum(dp, 2)} × {fnum(xd, 2)})", f"{fnum(sicrama_ada(dp, xd), 1)}°", "jeneratörün geçici reaktansı üzerindeki gerilim düşümünün değişimi", "hesap", ["Jeneratörün geçici reaktansı x′d (ve yükseltici trafo uk)", "Adada beklenen üretim–yük farkı"]),
        A("Vektör kayması ayarı", "6° … 9° (Tebliğ); şebeke anahtarlamalarının üstü", "dağıtım şirketi değeri", f"{fnum(ayar, 0)}°", LUY + "; ayar aralığı 2–30°: " + P3U + " Çizelge 90", "resmi", ["Dağıtım şirketinin ada koruması isteği"], "Vektör kayması"),
        A("Kör bölge", "ΔP min = tan(ayar) / x′d", f"tan({fnum(ayar, 0)}°) / {fnum(xd, 2)}", f"%{fnum(kor, 0)} Sn", "aynı bağıntı", "hesap"),
        A("Röle gecikmesi", "≤ 0,2 s − kesici; rölenin en kısa gecikmesi 0,10 s", f"0,2 − {fnum(tk, 2)} = {fnum(0.2 - tk, 2)} s", "0,10 s", P3U + " Çizelge 90; " + LUY, "resmi", [], "Çalışma gecikmesi"),
    ]
    ayarlar = [
        S("78V — Etkin", "Açık", "Açık / Kapalı (varsayılan Kapalı)", "Fonksiyon varsayılan olarak kapalıdır", P3U + " Çizelge 90"),
        S("Vektör kayması", f"{fnum(ayar, 0)}°", "2 … 30°; varsayılan 10°", "Tebliğ: 6–9°", P3U + " Çizelge 90; " + LUY),
        S("Frekans penceresi", f"± {fnum(num(p, 'fwin', 3), 0)} Hz", "± 1 … 5 Hz; varsayılan 3", "Frekans anma frekansından bu kadar uzaksa kademe kilitlenir", P3U + " Çizelge 90"),
        S("Düşük gerilim kilidi", f"%{fnum(num(p, 'lv', 90), 0)} Un", "%80 … %95; varsayılan %90", "U1 bunun altındaysa (kısa devre) kademe kilitlenir", P3U + " Çizelge 90"),
        S("Yüksek gerilim kilidi", "%110 Un dolayı", "%105 … %120", "U1 bunun üstündeyse kademe kilitlenir", P3U + " Çizelge 90"),
        S("Çalışma gecikmesi · Açma darbesi", f"{fnum(t, 2)} s · 0,20 s", "0,10 … 60 s", "Başlatma kilitlenir; bu süre içinde gerilim / frekans kilidi gelmezse açar", P3U + " Çizelge 90"),
        S("Kilit matrisi › I> başlatma → 78V", "isteğe bağlı", "—", "Aşırı akım başlamışsa (arıza) vektör kaymasını sıfırlar; bu fonksiyonda kilit işareti kademeyi sıfırlar", P3U + " böl. 5.35"),
    ]
    test = [
        T("Başlatma", f"Üç faz gerilimin açısını bir adımda {fnum(ayar, 0)}°'ye doğru artan sıçramalarla değiştirin", f"Başlatma {fnum(ayar, 0)}° sıçramada; {fnum(t, 2)} s sonra açma", "kılavuzda açı doğruluğu verilmemiş"),
        T("Tek faz sıçraması", "Yalnız bir fazın açısını sıçratın", "Pozitif bileşenin sıçraması üçte biri kadardır: başlamayabilir", "—"),
        T("Düşük gerilim kilidi", f"Sıçramayla birlikte gerilimi %{fnum(num(p, 'lv', 90) - 5, 0)}'e düşürün", "Açma yok", "—"),
        T("Frekans penceresi", f"Sıçramadan sonra frekansı {fnum(50 - num(p, 'fwin', 3) - 0.5, 1)} Hz'e götürün", "Açma yok (kademe sıfırlanır)", "—"),
    ]
    g = {"baslik": "Röle ne ölçer: pozitif bileşen geriliminin açısı, iki periyot öncesine göre", "x_ad": "Zaman (s)", "y_ad": "Açı değişimi (°)", "zaman": True, "ymin": 0, "ymax": max(30.0, jump * 1.3),
         "seriler": [{"ad": "ölçülen açı değişimi", "renk": "#dc2626", "pts": [[round(x, 3), round(min(v, max(30.0, jump * 1.3)), 2)] for x, v in zip(ts, olc)]}],
         "yatay": [{"y": ayar, "etiket": f"ayar {fnum(ayar, 0)}°", "renk": "#1a4d8f"}], "isaretler": ([{"x": basla, "etiket": "başlatma"}] + ([{"x": basla + t + tk, "etiket": "kesici açtı"}] if acar else [])) if basla is not None else []}
    xs = [10 + j for j in range(41)]
    g2 = {"baslik": "Kör bölge: adayı görebilmek için gereken en küçük üretim–yük farkı", "x_ad": "x′d (%)", "y_ad": "Fark (% Sn)", "ymin": 0, "ymax": 100,
          "seriler": [{"ad": f"ayar {a_}°", "renk": r_, "kesik": a_ != ayar, "pts": [[x, min(100, math.tan(math.radians(a_)) / (x / 100) * 100)] for x in xs]} for a_, r_ in ((6, "#15803d"), (ayar, "#dc2626"), (9, "#7c3aed"))],
          "isaretler": [{"x": xd * 100, "etiket": "bu santral"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["78v", "vektor"],
        "sahne": c.sahne(), "grafikler": [g, g2],
        "anlatim": [
            "Jeneratörün iç gerilimi ile uç gerilimi arasında, yük akımının geçici reaktansta düşürdüğü gerilim kadar bir açı vardır. Yük birden değişirse bu açı da birden değişir.",
            f"Santral şebekeden koptuğunda yükü, ihracat ya da ithalat kadar değişir. %{fnum(dp * 100, 0)} farkta ve x′d = %{fnum(xd * 100, 0)} ile uç geriliminin fazörü {fnum(sicrama_ada(dp, xd), 1)}° sıçrar.",
            "Röle pozitif bileşen geriliminin açısını iki periyot (40 ms) öncesiyle karşılaştırır. Fark ayarı aşarsa kademe başlar ve kilitlenir: sıçrama bir kerelik bir olaydır, sürmesi beklenmez.",
            "Kısa devrede de açı sıçrar. Ama o zaman gerilim de çöker; röle U1 gerilim penceresinin dışına çıkıldığını görür ve kademeyi kilitler. Frekans pencerenin dışına çıkarsa da öyle.",
            f"Zayıf yanı kör bölgedir: fark %{fnum(kor, 0)}'in altındaysa sıçrama {fnum(ayar, 0)}°'ye ulaşmaz. Santral ürettiğini yerinde tüketiyorsa (ihracat ≈ 0) vektör kayması adayı göremez.",
            "ROCOF aynı olayı frekansın eğiminden yakalar ve atalete duyarlıdır; vektör kayması reaktansa duyarlıdır. Tebliğ ikisinden birini ister; üretici şebeke kaybı için vektör kaymasını önerir.",
        ],
        "dersler": [
            "Δθ = atan(ΔP · x′d). 8°'lik ayar ve %28 reaktansla fark %50'nin altındaysa ada görülmez.",
            "Vektör kayması tek başına ada koruması değildir; 27 / 59 / 81 ile birlikte çalışır.",
            "Gerilim ve frekans kilitleri yanlış açmayı önler; kapatılırsa her şebeke arızasında santral düşer.",
            "Fonksiyon varsayılan olarak kapalıdır ve yalnız 3LN ya da 2LL+Uo ölçme modunda görünür.",
        ],
        "tablolar": [{"baslik": "Farka göre adanın tespiti (bu santral ve ayarlarla)", "cols": ["Üretim–yük farkı", "Açı sıçraması", "Vektör kayması", "Frekans eğimi", "ROCOF (1 Hz/s)"], "rows": [
            [f"%{d}", f"{fnum(sicrama_ada(d / 100, xd), 1)}°", "görür" if sicrama_ada(d / 100, xd) > ayar else "GÖRMEZ", f"{fnum(d / 100 * 50 / (2 * h), 2)} Hz/s", "görür" if d / 100 * 50 / (2 * h) > 1.0 else "GÖRMEZ"] for d in (5, 10, 20, 40, 60, 80)]}],
    }
