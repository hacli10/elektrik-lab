"""Trafo demerajı (enerjilendirme darbesi): akı, kalıcı akı ve kapama anı; çekirdeğin doyması; akımın dalga biçimi, harmonikleri ve sönmesi;
yanında çalışan trafonun sempatik demerajı; korumaya etkisi.

Model (birim değerler, trafo tabanında): sargı gerilimi u = sin(ωt + α); akı dφ/dt = ω·(u − r·i); mıknatıslanma eğrisi iki parçalı doğrudur:
|φ| ≤ φs iken i = i0·φ (boşta akım), üstünde i = i0·φs + (|φ| − φs)/x (x: doymuş sargının hava çekirdek reaktansı + şebeke reaktansı). Üç bacak ayrı ayrı
benzetilir (bacaklar arası manyetik bağ ve üçgen sargının etkisi yoktur). Sempatik demerajda iki trafo ortak hat direncini paylaşır.
Parametreler (doyma akısı, hava çekirdek reaktansı, direnç) tipiktir (tahmini); olgunun kendisi temel bağıntıdır. Rölenin demerajı tanıması:
P3U/en M/J006 böl. 3.2 Şekil 4 (demeraj akımında temel bileşen, 2. harmonik, etkin değer), böl. 5.33 (68F2), böl. 6.3 (soğuk yük ve kapama darbesi)."""
from __future__ import annotations

import math

from . import dalga as D
from .ortak import A, C, G, K, P3T, P3U, S, S3, T, URRA, ctl, fa, fnum, num, opt, tek_hat

ID = "demeraj_trafo"
BASLIK = "Trafo demerajı"
IKON = "🧲"
GIRIS = ("Boştaki bir trafo enerjilendiğinde birkaç periyot boyunca anma akımının katları kadar akım çeker; arıza yoktur. Neden: çekirdekteki akı sıçrayamaz, "
         "kapama anına ve çekirdekte kalan akıya göre bir yöne kayar, çekirdek doyar. Kapama anını ve kalıcı akıyı değiştirin; akıyı, akımı ve rölenin bunu "
         "arızadan nasıl ayırdığını izleyin.")
N = 64
I0 = 0.004            # boşta akım (pu) — dağıtım trafosu mertebesi

KONTROLLER = [
    ctl("sn", "Trafo gücü", "sec", 1600, secenek=opt(*[(v, f"{v} kVA") for v in (250, 400, 630, 1000, 1250, 1600, 2000, 2500, 5000, 10000, 25000)])),
    ctl("un", "Enerjilenen tarafın gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("alfa", "Kapama anında gerilimin açısı", "sayi", 0, min=0, max=180, adim=5, birim="°", yardim="0°: gerilim sıfırdan geçerken (en kötü); 90°: gerilim tepedeyken (kalıcı akı yoksa darbe olmaz)"),
    ctl("fr", "Çekirdekte kalan akı (L1 bacağı)", "sayi", 60, min=-90, max=90, adim=5, birim="%", yardim="Trafo en son hangi anda kesildiyse o andaki akının bir kısmı çekirdekte kalır; öbür iki bacakta yarısı kadar, ters yönde alınır"),
    ctl("fs", "Çekirdeğin doyma akısı", "sayi", 1.20, min=1.05, max=1.40, adim=0.01, birim="pu", yardim="Anma akısının katı; düşük kayıplı çekirdeklerde anma değerine daha yakındır"),
    ctl("xh", "Doymuş sargının reaktansı (hava çekirdek)", "sayi", 0.25, min=0.08, max=0.80, adim=0.01, birim="pu", yardim="Küçük trafoda ve dış sargıdan enerjilendirmede büyük; iç sargıdan enerjilendirmede küçük (darbe büyür)"),
    ctl("r", "Sargı + şebeke direnci", "sayi", 0.8, min=0.1, max=4.0, adim=0.1, birim="%", yardim="Darbenin sönme hızını belirler: büyük trafoda küçüktür, darbe saniyelerce sürer"),
    ctl("sk", "Şebeke kısa devre gücü", "sayi", 350, min=20, max=2500, adim=10, birim="MVA"),
    ctl("i2", "Röle › I>> (ani kademe)", "sayi", 10.0, min=1, max=30, adim=0.5, birim="×In(trafo)"),
    ctl("i1", "Röle › I> (gecikmeli kademe)", "sayi", 1.3, min=0.5, max=5, adim=0.05, birim="×In(trafo)"),
    ctl("t1", "Röle › tI>", "sayi", 0.30, min=0.05, max=3, adim=0.05, birim="s"),
    ctl("kilit", "Röle › 2. harmonik kilidi (68F2) I>'i kilitliyor", "onay", True),
    ctl("f2", "Röle › 68F2 başlatma (If2/If1)", "sayi", 15, min=10, max=50, adim=1, birim="%", goster={"kilit": [True]}),
    ctl("semp", "Yanında çalışan ikinci bir trafo var (sempatik demeraj)", "onay", False),
    ctl("ro", "İki trafonun ortak hat direnci", "sayi", 1.5, min=0.2, max=6, adim=0.1, birim="%", goster={"semp": [True]}, yardim="Uzun hat ya da zayıf şebeke: ortak direnç büyür, sempatik demeraj belirginleşir"),
]


def mik(phi: float, fs: float, x: float) -> float:
    """Mıknatıslanma akımı (pu, anma akımının tepe değerine göre)."""
    a = abs(phi)
    return phi * I0 if a <= fs else math.copysign(fs * I0 + (a - fs) / x, phi)


def benzet(alfa: float, phi0: float, fs: float, x: float, r: float, periyot: int, ro: float = 0.0, ikinci: bool = False) -> dict:
    """Bir bacağın (ve istenirse ortak direnci paylaşan, önceden devrede olan ikinci trafonun) akı ve akımı. Dönen: t (ms), i, phi, i2."""
    w = D.W; dt = 0.02 / N; a = math.radians(alfa)
    phi = phi0
    phi2 = -math.cos(a)                                  # devredeki trafo sürekli rejimde: φ2 = −cos(ωt + α)
    ts, i_, f_, i2_ = [], [], [], []
    for k in range(periyot * N + 1):
        t = k * dt
        i = mik(phi, fs, x); j = mik(phi2, fs, x) if ikinci else 0.0
        ts.append(t * 1000); i_.append(i); f_.append(phi); i2_.append(j)
        # orta nokta (RK2)
        u = math.sin(w * t + a)
        d1 = w * (u - ro * (i + j) - r * i); d2 = w * (u - ro * (i + j) - r * j)
        pm = phi + 0.5 * dt * d1; pm2 = phi2 + 0.5 * dt * d2
        um = math.sin(w * (t + dt / 2) + a); im = mik(pm, fs, x); jm = mik(pm2, fs, x) if ikinci else 0.0
        phi += dt * w * (um - ro * (im + jm) - r * im)
        if ikinci:
            phi2 += dt * w * (um - ro * (im + jm) - r * jm)
    return {"t": ts, "i": i_, "phi": f_, "i2": i2_}


def periyotlar(x: list) -> list:
    """Her periyot için (tepe, temel bileşen, 2. harmonik oranı) — değerler anma akımının etkin değerinin katı."""
    out = []
    for c in range((len(x) - 1) // N):
        seg = x[c * N:(c + 1) * N]
        f1 = abs(D.dft(seg, N - 1, N, 1)); f2 = abs(D.dft(seg, N - 1, N, 2))
        out.append((max(abs(v) for v in seg) * D.KOK2, f1, f2 / f1 if f1 > 1e-9 else 0.0))
    return out


def run(p: dict) -> dict:
    sn, un, alfa = num(p, "sn", 1600), num(p, "un", 34.5), num(p, "alfa", 0)
    fr, fs, r = num(p, "fr", 60) / 100, num(p, "fs", 1.2), num(p, "r", 0.8) / 100
    xs = sn / 1000 / num(p, "sk", 350)
    x = num(p, "xh", 0.25) + xs
    i_n = sn / (S3 * un)
    i2s, i1s, t1, f2s = num(p, "i2", 10), num(p, "i1", 1.3), num(p, "t1", 0.3), num(p, "f2", 15) / 100
    kilit, semp, ro = bool(p.get("kilit", True)), bool(p.get("semp")), num(p, "ro", 1.5) / 100
    PER = 40
    faz = [benzet(alfa - 120 * j, fr * (1 if j == 0 else -0.5), fs, x, r, PER) for j in range(3)]
    pr = [periyotlar(f["i"]) for f in faz]
    j0 = max(range(3), key=lambda j: pr[j][0][0])                       # en büyük darbeyi çeken bacak
    tepe, f1, o2 = pr[j0][0]
    phi_tepe = max(abs(v) for v in faz[j0]["phi"][:N + 1])
    dusuk2 = min((pr[j][0][2] for j in range(3) if pr[j][0][1] > 0.1 * max(f1, 1e-9)), default=0.0)       # akım taşıyan bacaklardaki en düşük 2. harmonik oranı
    yuksek2 = max(pr[j][0][2] for j in range(3))
    t50 = next((c * 0.02 for c, v in enumerate(pr[j0]) if v[0] <= 0.5 * tepe), None)
    # röle: en büyük fazın temel bileşeni periyot periyot
    f1_t = [max(pr[j][c][1] for j in range(3)) for c in range(PER)]
    ani = f1_t[0] >= i2s
    kilitli = kilit and yuksek2 >= f2s                                   # herhangi bir fazda oran ayarı aşarsa başlatma (çapraz kilit)
    ust = 0.0
    for c, v in enumerate(f1_t):
        if v >= i1s:
            ust = (c + 1) * 0.02
        else:
            break
    gec = ust >= t1 and not kilitli
    acti = ani or gec
    dip = xs * tepe / D.KOK2 * 100                                        # şebeke reaktansında düşen gerilim (tepe anında, %)

    c = tek_hat(("Şebeke", f"{fnum(num(p, 'sk', 350), 0)} MVA"), ("Trafo (boşta)", f"{fnum(sn, 0)} kVA · {fa(i_n)}"), ("Aşırı akım rölesi", "AÇTI (yanlış)" if acti else "kilitli — açmadı" if kilitli and ust >= t1 else "açmadı"),
                "gecersiz" if acti else "normal", None, "sag", gt=False, ileri=False, h=310, kesici_acik=acti)
    c.yazi(500, 150, f"Akı en çok {fnum(phi_tepe, 2)} × anma akısına çıkıyor (doyma {fnum(fs, 2)})", "#1a4d8f", 12, kalin=True)
    c.yazi(500, 172, f"Darbe tepesi {fnum(tepe, 1)} × In = {fa(tepe * i_n)} (L{j0 + 1})", "#b91c1c", 12.5, kalin=True)
    c.yazi(500, 192, f"Rölenin gördüğü temel bileşen {fnum(f1, 2)} × In", "#334155", 11.5)
    c.yazi(500, 212, f"2. harmonik oranı %{fnum(o2 * 100, 0)} (fazlar arası %{fnum(dusuk2 * 100, 0)}–%{fnum(yuksek2 * 100, 0)})", "#334155", 11.5)
    c.yazi(500, 232, f"Yarıya inme süresi: {fnum(t50, 2) + ' s' if t50 is not None else '0,8 s içinde inmiyor'}", "#334155", 11.5)
    c.yazi(500, 258, ("Ani kademe açtı: ayar darbenin altında" if ani else "Gecikmeli kademe açtı: kilit yok, darbe süre dolmadan sönmedi" if gec else "Röle açmadı: " + ("2. harmonik kilidi tuttu" if kilitli and ust >= t1 else "darbe eşiklerin altında / süre dolmadan söndü")),
           "#b91c1c" if acti else "#15803d", 12, kalin=True)

    ozet = [
        K("Demeraj tepesi", f"{fnum(tepe, 1)} × In", "warn" if tepe > 2 else "ok", f"{fa(tepe * i_n)} tepe · L{j0 + 1} bacağı"),
        K("Akının en büyük değeri", f"{fnum(phi_tepe, 2)} pu", "info", f"doyma {fnum(fs, 2)} pu · kalıcı akı %{fnum(fr * 100, 0)} · kapama {fnum(alfa, 0)}°"),
        K("Rölenin gördüğü akım", f"{fnum(f1, 2)} × In", "info", "ilk periyodun temel bileşeni (etkin)"),
        K("2. harmonik oranı", f"%{fnum(o2 * 100, 0)}", "ok" if o2 >= f2s else "warn", f"en düşük faz %{fnum(dusuk2 * 100, 0)} · 68F2 ayarı %{fnum(f2s * 100, 0)}"),
        K("Röle", "AÇTI" if acti else "açmadı", "bad" if acti else "ok", "yanlış açma: arıza yok" if acti else ("kilit sayesinde" if kilitli and ust >= t1 else "darbe eşiğin altında")),
    ]
    kontroller = [
        C("Ani kademe demerajda açmıyor mu?", f"temel bileşen {fnum(f1_t[0], 2)} × In", f"< I>> = {fnum(i2s, 1)} × In", not ani,
          "Ani kademe ayarı demeraj darbesinin temel bileşeninin üstünde seçilir; darbenin tepe değeri değil, rölenin ölçtüğü temel bileşen karşılaştırılır — " + P3U + " böl. 3.2 Şekil 4", "resmi"),
        C("Gecikmeli kademe demerajda açmıyor mu?", f"akım {fnum(ust, 2)} s boyunca I> = {fnum(i1s, 2)} × In üstünde; tI> = {fnum(t1, 2)} s" + ("; 68F2 kilidi etkin" if kilitli else ""), "süre dolmadan sönmeli ya da kademe kilitlenmeli", not gec,
          "2. harmonik başlatma işareti gecikmeli kademeyi kilitlemek için kullanılır; kilitlenen kademenin gecikmesi 60 ms'den uzun olmalı — " + P3U + " böl. 5.33", "resmi"),
        C("2. harmonik oranı ayarın üstünde mi?", f"fazlarda %{fnum(dusuk2 * 100, 0)} … %{fnum(yuksek2 * 100, 0)}", f"≥ %{fnum(f2s * 100, 0)} (herhangi bir fazda)", yuksek2 >= f2s if kilit else None,
          "Oran bütün faz akımlarında ölçülür; herhangi birinde ayarı aşarsa başlatma verilir — " + P3U + " böl. 5.33", "resmi"),
        C("Bara gerilimindeki çökme", f"%{fnum(dip, 1)} (darbe tepesinde)", "bilgi", None, "Darbe akımı şebeke reaktansında gerilim düşürür: aynı baradaki tüketiciler bunu gerilim çukuru olarak görür", "hesap"),
    ]
    girdiler = [
        G("Trafo gücü ve enerjilenen sargı", f"{fnum(sn, 0)} kVA · {fnum(un, 1)} kV · In = {fa(i_n)}", "Trafo etiketi", "Darbe anma akımının katı olarak düşünülür; dış (OG) sargıdan enerjilendirmede darbe daha küçüktür", "tepe ≈ (akı fazlası) / (hava çekirdek reaktansı)"),
        G("Üreticinin demeraj verisi", "tepe × In ve yarıya inme süresi", "Trafo veri sayfası / üretici; yoksa önceki enerjilendirmelerin arıza kaydı", "Hesap parametreleri (doyma akısı, hava çekirdek reaktansı) etikette yazmaz: ayar bu veriyle ya da kayıtla doğrulanır", "I>> ve 68F2 ayarı"),
        G("Şebeke kısa devre gücü", f"{fnum(num(p, 'sk', 350), 0)} MVA", "Bağlantı görüşü", "Zayıf şebeke darbeyi küçültür ama gerilim çukurunu büyütür", "x = x(hava) + Sn/Sk″"),
        G("Kilitlenecek kademeler ve gecikmeleri", f"I> {fnum(i1s, 2)} × In, {fnum(t1, 2)} s", "Ayar föyü; kilit matrisi", "68F2 kendisi açmaz; hangi kademeyi kilitlediği matriste tanımlıdır", "gecikme > 60 ms"),
    ]
    adimlar = [
        A("Akının gideceği en büyük değer", "φ(tepe) ≈ φ(kalıcı) + cos α + 1", f"{fnum(fr, 2)} + cos({fnum(alfa, 0)}°) + 1", f"{fnum(fr + math.cos(math.radians(alfa)) + 1, 2)} pu (dirençsiz); benzetimde {fnum(phi_tepe, 2)} pu", "u = dφ/dt: akı gerilimin integralidir ve sıçrayamaz", "hesap"),
        A("Doymanın üstünde kalan akı", "Δφ = φ(tepe) − φ(doyma)", f"{fnum(phi_tepe, 2)} − {fnum(fs, 2)}", f"{fnum(max(phi_tepe - fs, 0), 2)} pu", "çekirdek doyunca sargı hava çekirdekli bobin gibi davranır", "hesap"),
        A("Darbe tepesi", "î ≈ Δφ / (x(hava) + x(şebeke)) · √2", f"{fnum(max(phi_tepe - fs, 0), 2)} / ({fnum(num(p, 'xh', 0.25), 2)} + {fnum(xs, 3)}) × 1,41", f"{fnum(tepe, 1)} × In", "doymuş sargının reaktansı — parametre tipik", "tahmini", ["Trafo gücü ve enerjilenen sargı", "Şebeke kısa devre gücü"]),
        A("Rölenin ölçtüğü", "I1 = bir periyotluk Fourier süzgeci", "ilk periyodun örnekleri", f"temel bileşen {fnum(f1, 2)} × In · 2. harmonik %{fnum(o2 * 100, 0)}", P3U + " böl. 3.2", "resmi", [], "I>> · 68F2"),
        A("Sönme", "her periyotta direnç, akı kaymasının bir kısmını siler", f"r = %{fnum(r * 100, 1)}", f"yarıya inme {fnum(t50, 2) + ' s' if t50 is not None else '> 0,8 s'}", "dφ/dt = ω·(u − r·i): darbe aktıkça kayma azalır", "hesap", ["Üreticinin demeraj verisi"], "tI>"),
    ]
    ayarlar = [
        S("I>> (ani kademe)", f"{fnum(i2s, 1)} × In(trafo)", "—", "Demeraj darbesinin temel bileşeninin ve AG arızasının OG'deki karşılığının üstünde", URRA, "ikincil"),
        S("68F2 › Başlatma (2. harmonik / temel)", f"%{fnum(f2s * 100, 0)}", "%10 … %100", "Demerajın en düşük 2. harmonik oranının altında; düşük kayıplı trafolarda oran düşer", P3U + " Çizelge 87"),
        S("Kilit matrisi › 68F2 başlatma → I>", "bağlı" if kilit else "bağlı değil", "—", "Kilit bağlanmadıysa gecikmeli kademe uzun süren darbede açar", P3U + " böl. 5.33"),
        S("87T › 2. harmonik kilidi", "%15 dolayı", "%5 … %30", "Demeraj akımı yalnız bir taraftan akar: diferansiyel röleye iç arıza gibi görünür", P3T + " böl. 6.30"),
        S("Soğuk yük / kapama darbesi", "ayar grubu değiştirme ya da kademe kilitleme", "—", "Kesici kapandıktan sonra belirli süre daha yüksek ayarlar kullanılır", P3U + " böl. 6.3"),
    ]
    test = [
        T("68F2 başlatma", "50 Hz 1,00 × In + 100 Hz bileşen, yavaşça artır", f"Başlatma 100 Hz = %{fnum(f2s * 100, 0)}'te", "±%1 birim"),
        T("Kilit", f"I> eşiğinin üstünde 50 Hz + %{fnum(f2s * 100 + 5, 0)} 100 Hz", "I> başlar, açmaz", "100 Hz kaldırılınca gecikme sonunda açar"),
        T("Gerçek enerjilendirme kaydı", "Trafo boşta enerjilenir, röle arıza kaydı alınır", f"Kayıtta tek yönlü darbeler; tepe ≈ {fnum(tepe, 0)} × In'e kadar (kapama anına göre değişir)", "birkaç kapamada en büyüğü"),
    ]
    renk = ("#8a4b12", "#111827", "#6b7280")
    n6 = 6 * N
    g1 = {"baslik": "Demeraj akımı (ilk altı periyot, üç bacak)", "x_ad": "Zaman (ms)", "y_ad": "Akım (× In, anlık)", "zaman": True,
          "seriler": [{"ad": f"L{j + 1}", "renk": renk[j], "pts": D.seri(faz[j]["t"][:n6 + 1], [v * D.KOK2 for v in faz[j]["i"][:n6 + 1]], 1)} for j in range(3)]}
    g2 = {"baslik": f"L{j0 + 1} bacağında akı ve gerilim: akı doyma sınırını aşınca akım akar", "x_ad": "Zaman (ms)", "y_ad": "pu", "zaman": True,
          "seriler": [{"ad": "akı", "renk": "#1a4d8f", "pts": D.seri(faz[j0]["t"][:4 * N + 1], faz[j0]["phi"][:4 * N + 1], 1)},
                      {"ad": "gerilim", "renk": "#94a3b8", "kesik": True, "pts": [[round(t, 2), round(math.sin(D.W * t / 1000 + math.radians(alfa - 120 * j0)), 3)] for t in faz[j0]["t"][:4 * N + 1:2]]}],
          "yatay": [{"y": fs, "etiket": "doyma", "renk": "#dc2626"}, {"y": -fs, "etiket": "doyma", "renk": "#dc2626"}]}
    g3 = {"baslik": "Darbenin sönmesi: tepe değer ve rölenin gördüğü temel bileşen", "x_ad": "Zaman (s)", "y_ad": "Akım (× In)", "ymin": 0,
          "seriler": [{"ad": "tepe (en büyük bacak)", "renk": "#dc2626", "pts": [[round((c_ + 0.5) * 0.02, 3), round(v[0], 3)] for c_, v in enumerate(pr[j0])]},
                      {"ad": "temel bileşen (en büyük faz)", "renk": "#1a4d8f", "pts": [[round((c_ + 0.5) * 0.02, 3), round(v, 3)] for c_, v in enumerate(f1_t)]}],
          "yatay": [{"y": i1s, "etiket": f"I> = {fnum(i1s, 2)} × In", "renk": "#15803d"}], "isaretler": [{"x": t1, "etiket": "tI>"}]}
    grafikler = [g1, g2, g3]
    if semp:
        s = benzet(alfa - 120 * j0, fr * (1 if j0 == 0 else -0.5), fs, x, r, 75, ro, True)
        e1 = [max(abs(v) for v in s["i"][c_ * N:(c_ + 1) * N]) * D.KOK2 for c_ in range(75)]
        e2 = [max(abs(v) for v in s["i2"][c_ * N:(c_ + 1) * N]) * D.KOK2 for c_ in range(75)]
        grafikler.append({"baslik": "Sempatik demeraj: enerjilenen trafo ile yanında çalışan trafonun akım tepeleri", "x_ad": "Zaman (s)", "y_ad": "Akım tepesi (× In)", "ymin": 0,
                          "seriler": [{"ad": "enerjilenen trafo", "renk": "#dc2626", "pts": [[round((c_ + 0.5) * 0.02, 3), round(v, 3)] for c_, v in enumerate(e1)]},
                                      {"ad": "yanında çalışan trafo", "renk": "#1a4d8f", "pts": [[round((c_ + 0.5) * 0.02, 3), round(v, 3)] for c_, v in enumerate(e2)]}]})
        kontroller.append(C("Yanındaki trafoda sempatik demeraj", f"en büyük tepe {fnum(max(e2), 2)} × In ({fnum(e2.index(max(e2)) * 0.02, 2)} s'de)", "bilgi", None,
                            "Enerjilenen trafonun tek yönlü akımı ortak hat direncinde doğru gerilim düşürür; bu, devredeki trafonun akısını ters yöne kaydırır ve onu da doyurur. İki darbe zıt yarı periyotlarda akar, toplam sönme uzar", "hesap"))
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["soguk_yuk", "87t"], "sahne": c.sahne(), "grafikler": grafikler,
        "anlatim": [
            "Sargıya uygulanan gerilim akının değişim hızıdır; akı bu yüzden gerilimin integralidir ve sıçrayamaz. Sürekli çalışmada akı gerilimden 90° geridedir: gerilim sıfırdan geçerken akı tepe değerindedir.",
            f"Kesici, gerilim {fnum(alfa, 0)}°'deyken kapanıyor. Akı sıfırdan (ya da çekirdekte kalan değerden) başlamak zorunda; gerilimin ilk yarı periyodu boyunca tek yönde büyür. Gerilim sıfırında kapanırsa akı anma değerinin iki katına, kalıcı akı da aynı yöndeyse daha da yukarı çıkar.",
            f"Çekirdek anma akısının {fnum(fs, 2)} katında doyar. Akı bunun üstüne çıkınca demir artık akıyı taşıyamaz; sargı hava çekirdekli bir bobin gibi davranır ve akımı yalnız küçük kaçak reaktansı sınırlar: {fnum(tepe, 1)} × In.",
            "Akı her periyodun yalnız bir bölümünde doyma sınırının üstündedir: akım tek yönlü, aralıklı darbeler halinde akar. Bu biçim simetrik değildir; 2. harmonik bakımından zengindir.",
            "Darbe aktıkça sargı ve şebeke direncinde düşen gerilim akının kaymasını azaltır: darbeler periyot periyot küçülür. Küçük trafoda birkaç periyotta, büyük trafoda saniyelerce sürer.",
            "Üç bacak 120° aralıklı gerilim görür: aynı anda üçü birden en kötü durumda olamaz. En az bir bacak doyar; hangi fazda büyük darbe olacağı kapama anına ve kalıcı akıya bağlıdır — her enerjilendirmede farklıdır.",
        ],
        "dersler": [
            "Demeraj arıza değildir ama röleye arıza gibi görünür; onu ayıran dalga biçimidir (2. harmonik), büyüklüğü değil.",
            "En kötü kapama: gerilim sıfırdan geçerken ve kalıcı akı aynı yöndeyken. Aynı trafo bir kapamada 2, ötekinde 10 × In çekebilir.",
            "Rölenin karşılaştırdığı değer darbenin tepesi değil temel bileşenidir: tepe 8 × In iken röle 2–3 × In görür.",
            "Düşük kayıplı çekirdekler anma akısına yakın çalışır: darbe büyür, 2. harmonik oranı düşer. Kilit ayarı eski alışkanlıkla seçilmez.",
            "Yanındaki trafo da etkilenir: sempatik demeraj saniyelerce sürebilir ve çalışan trafonun korumasını açtırabilir.",
        ],
        "tablolar": [{"baslik": "Kapama anı ve kalıcı akıya göre darbe (bu trafo, L1 bacağı)", "cols": ["Kapama açısı", "Kalıcı akı", "Akı tepesi (pu)", "Darbe tepesi (× In)", "2. harmonik"],
                      "rows": [[f"{a_}°", f"%{k_}", fnum(max(abs(v) for v in b["phi"][:N + 1]), 2), fnum(q[0][0], 1), f"%{fnum(q[0][2] * 100, 0)}" if q[0][1] > 0.02 else "—"]
                               for a_, k_ in ((0, 80), (0, 0), (0, -80), (45, 60), (90, 60), (90, 0)) for b in [benzet(a_, k_ / 100, fs, x, r, 2)] for q in [periyotlar(b["i"])]],
                      "not": "90°'de ve kalıcı akı yokken akı doğrudan sürekli rejim değerinde başlar: darbe olmaz. Bu yüzden büyük trafolarda denetimli kapama (gerilim tepesinde) kullanılır."}],
    }
