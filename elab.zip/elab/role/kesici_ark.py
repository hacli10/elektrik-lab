"""Kesici akımı nasıl keser: açma komutundan arkın sönmesine kadar olan zincir, kontak ayrılma anındaki doğru akım bileşeni, akım sıfırında sönme,
toparlanma gerilimi, küçük endüktif akımda akım koparma, kapasitif akımda yeniden tutuşma ve açma bobininin akım izi.

Bağıntılar temel devre bağıntılarıdır: kaynak endüktansı L = U/(√3·ω·Ik); toparlanma geriliminin frekansı f = 1/(2π·√(L·C)); tepe değeri
uc = kpp·kaf·√2·Ur/√3 (ilk açan kutup katsayısı kpp = 1,5, genlik katsayısı kaf = 1,4 → 36 kV'ta 61,7 kV); akım koparmada aşırı gerilim
U = i·√(Lm/C); doğru akım bileşeni %dc = 100·e^(−t/τ). Standart değerler (TS EN 62271-100: τ = 45 ms, kpp, kaf, 36 kV için t3 ≈ 108 µs; açma bobininin
çalışma aralığı anma kumanda geriliminin %70–110'u) asıl metinden teyit edilmedi (dogrulanacak). Bobin akım izi ve ark süreleri öğretim amaçlı,
tipik değerlerledir (tahmini). Kesici arıza koruması için «Kesici arıza (50BF)» sayfasına bakın."""
from __future__ import annotations

import math

from . import dalga as D
from .ortak import A, C, G, K, P3U, S, S3, T, ctl, fnum, num, opt, tek_hat

ID = "kesici_ark"
BASLIK = "Kesici akımı nasıl keser"
IKON = "⚡"
GIRIS = ("Kesici akımı kontakları ayırarak değil, kontaklar arasında yanan arkı akımın sıfır geçişinde söndürerek keser. Bu sayfada açma komutundan arkın sönmesine "
         "kadar geçen süreyi, o anda kontakların karşılaştığı gerilimi ve açma bobininin akımından kesicinin sağlığının nasıl okunduğunu görürsünüz.")
IEC = "TS EN 62271-100 (alternatif akım kesicileri)"
ISLEM = {"kd": "Kısa devre akımını kesme", "ind": "Küçük endüktif akımı kesme (boştaki trafo)", "kap": "Kapasitif akımı kesme (boştaki kablo)"}

KONTROLLER = [
    ctl("islem", "Kesilen akım", "sec", "kd", secenek=opt(*ISLEM.items())),
    ctl("ur", "Kesicinin anma gerilimi", "sec", 36, secenek=opt((7.2, "7,2 kV"), (12, "12 kV"), (17.5, "17,5 kV"), (36, "36 kV"))),
    ctl("ik", "Kısa devre akımı", "sayi", 8, min=1, max=31.5, adim=0.5, birim="kA", goster={"islem": ["kd"]}),
    ctl("xr", "Şebekenin X/R oranı", "sayi", 14, min=2, max=60, adim=1, goster={"islem": ["kd"]}),
    ctl("t_role", "Rölenin açma süresi", "sayi", 30, min=10, max=1000, adim=5, birim="ms", goster={"islem": ["kd"]}),
    ctl("t_ac", "Kesicinin açma süresi (komut → kontak ayrılması)", "sayi", 45, min=15, max=120, adim=1, birim="ms"),
    ctl("faz", "Kontaklar ayrılırken son akım sıfırından geçen süre", "sayi", 4, min=0, max=9.5, adim=0.5, birim="ms", goster={"islem": ["kd"]}),
    ctl("t_min", "En kısa ark süresi", "sayi", 4, min=1, max=12, adim=0.5, birim="ms", yardim="Kontak aralığı yeterince açılmadan ark sönemez: vakumda 3–5 ms, SF6'da 8–10 ms dolayı"),
    ctl("c_nf", "Kaynak tarafının toprağa kapasitesi", "sayi", 200, min=1, max=2000, adim=1, birim="nF", yardim="Yalnız bara: birkaç nF; kablo bağlı şebeke: yüzlerce nF"),
    ctl("i0", "Boştaki trafonun mıknatıslanma akımı", "sayi", 2.0, min=0.2, max=20, adim=0.1, birim="A", goster={"islem": ["ind"]}),
    ctl("ich", "Kesicinin akım koparma düzeyi", "sayi", 4.0, min=0.5, max=15, adim=0.5, birim="A", goster={"islem": ["ind"]}, yardim="Vakum kesicide 3–5 A; ark akım sıfırından önce kopar"),
    ctl("tutus", "Yarım periyot sonra yeniden tutuşma oluyor", "onay", False, goster={"islem": ["kap"]}),
    ctl("u_dc", "Kumanda gerilimi", "sayi", 100, min=50, max=115, adim=1, birim="% Un"),
]


def run(p: dict) -> dict:
    isl = p.get("islem") if p.get("islem") in ISLEM else "kd"
    ur, ik, xr = num(p, "ur", 36), num(p, "ik", 8) * 1000, num(p, "xr", 14)
    t_role, t_ac0, faz, t_min = num(p, "t_role", 30), num(p, "t_ac", 45), num(p, "faz", 4), num(p, "t_min", 4)
    u_dc = num(p, "u_dc", 100) / 100
    calisir = u_dc >= 0.70
    t_ac = t_ac0 * (1 / max(u_dc, 0.5)) ** 1.5                               # düşük kumanda geriliminde bobin yavaş çeker (yaklaşık)
    cap = num(p, "c_nf", 200) * 1e-9
    e_tepe = D.KOK2 * ur / S3                                                # kV — faz geriliminin tepe değeri
    tau = D.tau(xr) * 1000
    t_ayr = t_role + t_ac
    dc = 100 * math.exp(-t_ayr / tau) if isl == "kd" else 0.0
    dc_std = 100 * math.exp(-t_ayr / 45.0)
    kalan = 10 - faz
    t_ark = kalan if kalan >= t_min else kalan + 10
    t_top = t_ayr + t_ark
    L = ur * 1000 / (S3 * D.W * ik) if isl == "kd" else 0.0
    f_trv = 1 / (2 * math.pi * math.sqrt(L * cap)) if isl == "kd" else 0.0
    uc = 1.5 * 1.4 * e_tepe
    t3 = 1e6 / (2 * f_trv) if f_trv else 0.0                                 # µs — tepeye ulaşma (yarım salınım)
    rrrv = uc / t3 if t3 else 0.0
    rrrv_std = 61.7 / 108 if ur == 36 else None
    # akım koparma
    lm = ur * 1000 / (S3 * D.W * max(num(p, "i0", 2.0), 1e-6))
    ich = min(num(p, "ich", 4.0), num(p, "i0", 2.0) * D.KOK2)
    u_ch = ich * math.sqrt(lm / cap) / 1000                                  # kV
    bil = {7.2: 60, 12: 75, 17.5: 95, 36: 170}.get(ur, 170)
    tutus = bool(p.get("tutus"))
    u_kap = 3.0 if tutus else 2.0                                            # pu — kontaklar arası / yeniden tutuşmada hat tarafı

    durum = "acti" if calisir else "gecersiz"
    c = tek_hat(("Kaynak", f"{fnum(ik / 1000, 1)} kA" if isl == "kd" else ""), ({"kd": "Arıza", "ind": "Boştaki trafo", "kap": "Boştaki kablo"}[isl], ""), ("Açma devresi", "bobin çekti" if calisir else "bobin ÇEKMEDİ"),
                durum, 640 if isl == "kd" else None, "sag", gt=False, ileri=False, h=310, kesici_acik=calisir)
    if isl == "kd":
        c.yazi(500, 150, f"Röle {fnum(t_role, 0)} + kesici {fnum(t_ac, 0)} + ark {fnum(t_ark, 1)} ms", "#334155", 12)
        c.yazi(500, 172, f"Toplam kesme süresi {fnum(t_top, 0)} ms", "#1a4d8f", 13, kalin=True)
        c.yazi(500, 194, f"Kontak ayrılırken doğru akım bileşeni %{fnum(dc, 0)}", "#b91c1c" if dc > dc_std + 0.5 else "#334155", 12)
        c.yazi(500, 216, f"Toparlanma gerilimi tepe {fnum(uc, 1)} kV", "#334155", 12)
        c.yazi(500, 236, f"{fnum(f_trv / 1000, 1)} kHz · yükselme {fnum(rrrv, 2)} kV/µs", "#b91c1c" if (rrrv_std and rrrv > rrrv_std) else "#334155", 12)
    elif isl == "ind":
        c.yazi(500, 150, f"Ark {fnum(ich, 1)} A'de, akım sıfırından önce kopuyor", "#334155", 12)
        c.yazi(500, 172, f"Trafonun endüktansındaki enerji kapasiteye boşalır", "#334155", 11.5)
        c.yazi(500, 196, f"Aşırı gerilim ≈ {fnum(u_ch, 0)} kV (tepe)", "#b91c1c" if u_ch > bil else "#1a4d8f", 13, kalin=True)
        c.yazi(500, 218, f"Yalıtım düzeyi (darbe) {bil} kV", "#334155", 12)
    else:
        c.yazi(500, 150, "Akım sıfırında kablo, gerilimin tepe değerinde yüklü kalır", "#334155", 11.5)
        c.yazi(500, 172, "Yarım periyot sonra kontaklar arası gerilim 2 pu", "#1a4d8f", 12.5, kalin=True)
        c.yazi(500, 196, ("Yeniden tutuşma: hat tarafı gerilimi 3 pu'ya savrulur" if tutus else "Kontak aralığı dayanıyor: kesme başarılı"), "#b91c1c" if tutus else "#15803d", 12, kalin=True)
        c.yazi(500, 218, f"= {fnum(u_kap * e_tepe, 0)} kV (tepe)", "#334155", 12)
    c.yazi(500, 262, f"Kumanda gerilimi %{fnum(u_dc * 100, 0)} → açma süresi {fnum(t_ac, 0)} ms" if calisir else f"Kumanda gerilimi %{fnum(u_dc * 100, 0)}: bobin çalışma aralığının altında", "#15803d" if calisir else "#b91c1c", 11.5)

    if isl == "kd":
        ozet = [K("Toplam kesme süresi", f"{fnum(t_top, 0)} ms", "info", f"röle {fnum(t_role, 0)} + açma {fnum(t_ac, 0)} + ark {fnum(t_ark, 1)} ms"),
                K("Ark süresi", f"{fnum(t_ark, 1)} ms", "info", "ilk uygun akım sıfırına kadar" if t_ark == kalan else "ilk sıfır erken geldi: bir sonraki sıfıra kadar"),
                K("Doğru akım bileşeni", f"%{fnum(dc, 0)}", "ok" if dc <= dc_std + 0.5 else "warn", f"kontak ayrılma anında · standart eğri (τ = 45 ms) %{fnum(dc_std, 0)}"),
                K("Toparlanma gerilimi", f"{fnum(uc, 1)} kV", "info", f"tepe · {fnum(f_trv / 1000, 1)} kHz"),
                K("Yükselme hızı", f"{fnum(rrrv, 2)} kV/µs", "ok" if not rrrv_std or rrrv <= rrrv_std else "warn", (f"36 kV için başvuru değeri {fnum(rrrv_std, 2)} kV/µs" if rrrv_std else "başvuru değeri bu gerilim için girilmedi"))]
    elif isl == "ind":
        ozet = [K("Akım koparma düzeyi", f"{fnum(ich, 1)} A", "info", "ark akım sıfırını beklemeden söner"), K("Aşırı gerilim", f"{fnum(u_ch, 0)} kV", "ok" if u_ch <= bil else "bad", f"i·√(Lm/C) · yalıtım düzeyi {bil} kV"),
                K("Trafonun mıknatıslanma endüktansı", f"{fnum(lm, 0)} H", "info", f"boşta akım {fnum(num(p, 'i0', 2), 1)} A"), K("Devredeki kapasite", f"{fnum(num(p, 'c_nf', 200), 0)} nF", "info", "kapasite büyüdükçe aşırı gerilim düşer"),
                K("Açma süresi", f"{fnum(t_ac, 0)} ms", "info", "komuttan kontak ayrılmasına")]
    else:
        ozet = [K("Kontaklar arası gerilim", "2 pu", "info", f"{fnum(2 * e_tepe, 0)} kV — akım sıfırından yarım periyot sonra"), K("Yeniden tutuşma", "VAR" if tutus else "yok", "bad" if tutus else "ok", "kontak aralığı 2 pu'ya dayanmalı"),
                K("Hat tarafı gerilimi", f"{fnum(u_kap, 0)} pu", "bad" if tutus else "ok", f"{fnum(u_kap * e_tepe, 0)} kV (tepe)"), K("Yalıtım düzeyi", f"{bil} kV", "info", "darbe dayanım gerilimi"),
                K("Açma süresi", f"{fnum(t_ac, 0)} ms", "info", "komuttan kontak ayrılmasına")]
    kontroller = [
        C("Açma bobini çalışıyor mu?", f"kumanda gerilimi %{fnum(u_dc * 100, 0)} Un", "%70 … %110 Un (doğru akım açma bobini)", calisir,
          "Açma bobini anma kumanda geriliminin belirli bir aralığında çalışmak zorundadır; akü zayıfsa ya da kablo uzunsa bobin çekmez — " + IEC, "dogrulanacak"),
    ]
    if isl == "kd":
        kontroller += [
            C("Doğru akım bileşeni kesicinin anma değerinin içinde mi?", f"kontak ayrılmasında %{fnum(dc, 0)} (şebeke τ = {fnum(tau, 0)} ms)", f"≤ %{fnum(dc_std, 0)} (standart τ = 45 ms eğrisi)", dc <= dc_std + 0.5,
              "Kesicinin kesme kapasitesi, kontak ayrılma anındaki doğru akım bileşeni yüzdesiyle birlikte tanımlanır; X/R büyük şebekede (jeneratör, trafo yakını) özel değer gerekir — " + IEC, "dogrulanacak"),
            C("Toparlanma geriliminin yükselme hızı", f"{fnum(rrrv, 2)} kV/µs ({fnum(uc, 1)} kV, {fnum(t3, 0)} µs)", (f"≤ {fnum(rrrv_std, 2)} kV/µs (36 kV, kablo şebekesi)" if rrrv_std else "bilgi"), (rrrv <= rrrv_std) if rrrv_std else None,
              "Ark söndüğü an kontak aralığı henüz sıcaktır; gerilim, aralığın dayanımından hızlı yükselirse ark yeniden tutuşur. Kapasite küçüldükçe (kısa bara, reaktör) yükselme hızlanır — " + IEC, "dogrulanacak"),
            C("Ark süresi", f"{fnum(t_ark, 1)} ms", "bilgi", None, "Ark, kontak aralığı yeterince açıldıktan sonraki ilk akım sıfırında söner; kontaklar sıfırdan hemen önce ayrılırsa bir yarım periyot daha yanar", "hesap"),
        ]
    elif isl == "ind":
        kontroller.append(C("Akım koparma aşırı gerilimi yalıtım düzeyinin altında mı?", f"≈ {fnum(u_ch, 0)} kV", f"< {bil} kV", u_ch <= bil,
                            "Bobinde kalan enerji ½·L·i² kapasiteye aktarılır: U = i·√(L/C). Kuru tip trafolarda ve motorlarda parafudr ya da RC söndürücü bu yüzden kullanılır", "hesap"))
    else:
        kontroller.append(C("Kontak aralığı yeniden tutuşmadan dayanıyor mu?", "yeniden tutuşma var" if tutus else "yok", "kapasitif akım kesme sınıfı (yeniden tutuşma olasılığı düşük)", not tutus,
                            "Her yeniden tutuşma hat tarafı gerilimini bir kat daha yükseltir (3 pu, 5 pu …); kablo ve kondansatör fiderlerinde kesicinin kapasitif kesme sınıfı aranır — " + IEC, "dogrulanacak"))
    girdiler = [
        G("Kesicinin açma ve kesme süresi", f"açma {fnum(t_ac0, 0)} ms", "Kesici etiketi ve test raporu (zaman testi)", "Koruma sürelerine eklenir; 50BF ve seçicilik payı bununla hesaplanır", "toplam süre = röle + açma + ark"),
        G("Kısa devre akımı ve X/R", f"{fnum(ik / 1000, 1)} kA · {fnum(xr, 0)}" if isl == "kd" else "—", "Kısa devre hesabı", "Kesme kapasitesi ve doğru akım bileşeni yüzdesi", "bkz. Kısa devre sayfası"),
        G("Kumanda gerilimi ve açma devresi", f"%{fnum(u_dc * 100, 0)} Un", "Akü ve redresör; açma devresinin kablo boyu", "Bobin düşük gerilimde yavaş çeker ya da hiç çekmez", "açma devresi denetimi (74)"),
        G("Kesilen yükün türü", ISLEM[isl], "Tek hat şeması", "Kısa devre, boştaki trafo ve boştaki kablo kesiciyi ayrı biçimlerde zorlar", "kesicinin sınıfı"),
    ]
    adimlar = [
        A("Kontak ayrılma anı", "t = röle süresi + açma süresi", f"{fnum(t_role, 0)} + {fnum(t_ac, 0)} ms", f"{fnum(t_ayr, 0)} ms", "olay sırası", "hesap", ["Kesicinin açma ve kesme süresi"]),
    ]
    if isl == "kd":
        adimlar += [
            A("O andaki doğru akım bileşeni", "%dc = 100·e^(−t/τ) ;  τ = (X/R)/ω", f"100 × e^(−{fnum(t_ayr, 0)}/{fnum(tau, 0)})", f"%{fnum(dc, 0)}", "R–L devresi", "hesap", ["Kısa devre akımı ve X/R"]),
            A("Ark süresi", "ayrılmadan sonraki, en kısa ark süresini aşan ilk akım sıfırı", f"sıfıra {fnum(kalan, 1)} ms; en kısa ark {fnum(t_min, 1)} ms", f"{fnum(t_ark, 1)} ms", "ark akım sıfırında söner", "tahmini"),
            A("Kaynak endüktansı", "L = Ur / (√3·ω·Ik)", f"{fnum(ur, 1)} kV / (1,732 × 314 × {fnum(ik / 1000, 1)} kA)", f"{fnum(L * 1000, 2)} mH", "kısa devre empedansından", "hesap"),
            A("Toparlanma geriliminin frekansı", "f = 1 / (2π·√(L·C))", f"L = {fnum(L * 1000, 2)} mH, C = {fnum(num(p, 'c_nf', 200), 0)} nF", f"{fnum(f_trv / 1000, 1)} kHz", "kaynak endüktansı ile toprak kapasitesinin salınımı", "hesap"),
            A("Toparlanma geriliminin tepesi", "uc = kpp·kaf·√2·Ur/√3", f"1,5 × 1,4 × {fnum(e_tepe, 1)}", f"{fnum(uc, 1)} kV", IEC, "dogrulanacak"),
        ]
    elif isl == "ind":
        adimlar.append(A("Akım koparma aşırı gerilimi", "U = i·√(Lm/C)", f"{fnum(ich, 1)} A × √({fnum(lm, 0)} H / {fnum(num(p, 'c_nf', 200), 0)} nF)", f"{fnum(u_ch, 0)} kV", "enerjinin korunumu: ½·L·i² = ½·C·U²", "hesap"))
    else:
        adimlar.append(A("Kontaklar arası gerilim", "u = Û·(1 − cos ωt)", "akım sıfırından 10 ms sonra", f"2 pu = {fnum(2 * e_tepe, 0)} kV", "kablo tepe gerilimde yüklü kalır, kaynak gerilimi yön değiştirir", "hesap"))
    ayarlar = [
        S("Kesici arıza koruması (50BF) süresi", f"> {fnum(t_ac + t_ark, 0)} ms + kademenin bırakma süresi + pay", "—", "Kesicinin gerçek kesme süresinden kısa olamaz", "bkz. Kesici arıza sayfası — " + P3U + " böl. 5.17"),
        S("Açma devresi denetimi (74)", "etkin", "—", "Bobin devresi kopuksa kesici açamaz; denetim bunu arızadan önce bildirir", P3U + " böl. 6.18"),
    ]
    test = [
        T("Zaman testi", "Açma komutu verilir, üç kutbun kontak ayrılma anları ölçülür", f"Açma süresi ≈ {fnum(t_ac0, 0)} ms; kutuplar arası fark birkaç ms içinde", "etiket değeri ve önceki ölçümlerle karşılaştırılır"),
        T("En düşük kumanda gerilimi", "Kumanda gerilimi %70 Un'a düşürülüp açma denenir", "Kesici açar", IEC),
        T("Bobin akım izi", "Açma sırasında bobin akımı kaydedilir", "İlk tepe, hareket çukuru, plato ve yardımcı kontakla kesilme görülür", "çukurun gecikmesi mekanizma sürtünmesini, platonun düşüklüğü bobin direncini gösterir"),
        T("Kontak direnci", "Kapalı kesiciden doğru akım geçirilir", "Etiket / üretici değerinin içinde", "bkz. Topraklama laboratuvarı › Deneyler"),
    ]
    grafikler = []
    if isl == "kd":
        ts = [j * 0.25 for j in range(int((t_top + 25) / 0.25) + 1)]
        ak = [D.kd_akim(ik / 1000, xr, math.degrees(math.atan(xr)) - 90, t / 1000) if t <= t_top else 0.0 for t in ts]
        grafikler.append({"baslik": "Arıza akımı: komut, kontak ayrılması, ark ve sönme", "x_ad": "Zaman (ms) — arıza t = 0'da", "y_ad": "Akım (kA, anlık)", "zaman": True,
                          "seriler": [{"ad": "akım", "renk": "#dc2626", "pts": D.seri(ts, ak, 1)}],
                          "isaretler": [{"x": t_role, "etiket": "açma komutu"}, {"x": round(t_ayr, 1), "etiket": "kontak ayrıldı"}, {"x": round(t_top, 1), "etiket": "ark söndü"}]})
        tu = [j * t3 / 40 for j in range(0, 161)]
        grafikler.append({"baslik": "Toparlanma gerilimi (ark söndükten sonraki mikrosaniyeler)", "x_ad": "Zaman (µs)", "y_ad": "Kontaklar arası gerilim (kV)", "ymin": 0,
                          "seriler": [{"ad": "toparlanma gerilimi", "renk": "#1a4d8f", "pts": [[round(t, 1), round(uc / 1.4 * (1 - math.exp(-t / (6 * t3)) * math.cos(math.pi * t / t3)) / (1 + math.exp(-1 / 6)) * 1.4, 2)] for t in tu]}]
                          + ([{"ad": "36 kV başvuru zarfı", "renk": "#15803d", "kesik": True, "pts": [[0, 0], [108, 61.7], [round(max(tu), 0), 61.7]]}] if ur == 36 else [])})
    elif isl == "kap":
        ts = [j * 0.25 for j in range(0, 161)]
        grafikler.append({"baslik": "Kapasitif akım kesildikten sonra kontaklar arası gerilim", "x_ad": "Zaman (ms) — akım sıfırından sonra", "y_ad": "Gerilim (pu)", "zaman": True,
                          "seriler": [{"ad": "kontaklar arası", "renk": "#1a4d8f", "pts": [[t, round((1 - math.cos(D.W * t / 1000)) if not (tutus and t >= 10) else abs(2 * math.exp(-(t - 10) / 3) * math.cos(2 * math.pi * 0.9 * (t - 10))), 3)] for t in ts]},
                                      {"ad": "hat (kablo) tarafı", "renk": "#dc2626", "pts": [[t, round(1.0 if not (tutus and t >= 10) else -1 - 2 * math.exp(-(t - 10) / 3) * math.cos(2 * math.pi * 0.9 * (t - 10)), 3)] for t in ts]}]})
    # bobin akım izi (anma akımının katı)
    tb = [j * 0.5 for j in range(0, int(t_ac + 30) * 2)]
    tc_ = 8.0 / max(u_dc, 0.5)
    def bobin(t: float) -> float:                                             # noqa: E306
        if not calisir:
            return u_dc * (1 - math.exp(-t / 8.0))
        t1 = 0.35 * t_ac; t2 = 0.75 * t_ac
        if t < t1:
            return u_dc * (1 - math.exp(-t / tc_))
        ust = u_dc * (1 - math.exp(-t1 / tc_))
        if t < t2:
            return ust - 0.25 * u_dc * math.sin(math.pi * (t - t1) / (t2 - t1))      # çekirdek hareket ederken ters EMK akımı düşürür
        if t < t_ac + 12:
            return ust + (u_dc - ust) * (1 - math.exp(-(t - t2) / 6.0))
        return max(0.0, u_dc * math.exp(-(t - t_ac - 12) / 1.5))                    # yardımcı kontak bobini keser
    grafikler.append({"baslik": "Açma bobininin akım izi", "x_ad": "Zaman (ms) — açma komutundan", "y_ad": "Bobin akımı (anma değerinin katı)", "ymin": 0, "zaman": True,
                      "seriler": [{"ad": "bobin akımı", "renk": "#6d28d9", "pts": [[t, round(bobin(t), 3)] for t in tb]}],
                      "isaretler": ([{"x": round(0.35 * t_ac, 1), "etiket": "çekirdek harekete geçti"}, {"x": round(t_ac, 1), "etiket": "ana kontaklar ayrıldı"}, {"x": round(t_ac + 12, 1), "etiket": "yardımcı kontak kesti"}] if calisir else [])})
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": [], "sahne": c.sahne(), "grafikler": grafikler,
        "anlatim": [
            "Röle açma kontağını kapatır; açma bobininden akım geçer, bobinin çekirdeği mandalı çözer, yay kontakları ayırır. Komuttan kontak ayrılmasına kadar geçen süre kesicinin açma süresidir.",
            "Kontaklar ayrıldığında akım kesilmez: aralıkta ark yanar ve akım arkın içinden akmayı sürdürür. Alternatif akım her yarım periyotta sıfırdan geçer; ark o anda kendiliğinden söner.",
            "Söndükten sonra kontak aralığı bir yarışa girer: aralığın yalıtım dayanımı toparlanır, bir yandan da şebeke gerilimi aralığa geri gelir. Dayanım gerilimden hızlı yükselirse akım kesilmiş olur; değilse ark yeniden tutuşur ve bir yarım periyot daha yanar.",
            "Geri gelen gerilim düz gelmez: kaynak endüktansı ile bara kapasitesi arasında salınır, tepe değeri faz geriliminin iki katına yaklaşır. Kapasite küçükse salınım hızlıdır ve kesici daha çok zorlanır.",
            "Doğru akım bileşeni akım sıfırlarını kaydırır ve arkın enerjisini artırır. Röle ve kesici ne kadar hızlıysa, kontak ayrılırken bileşen o kadar büyüktür: hızlı koruma kesiciyi daha çok zorlar.",
            "Küçük akımlar başka sorun çıkarır. Vakum kesici küçük endüktif akımı sıfırı beklemeden koparır: bobinde kalan enerji aşırı gerilim üretir. Boştaki kablo kesilirken kablo yüklü kalır; yarım periyot sonra kontaklar iki kat gerilimle karşılaşır.",
        ],
        "dersler": [
            "Kesme süresi = röle + açma + ark. Koruma ayarlarındaki «kesici süresi» bu toplamın son iki terimidir.",
            "Kesiciyi zorlayan yalnız akımın büyüklüğü değildir: doğru akım bileşeni, toparlanma geriliminin hızı ve yükün türü de anma değerleridir.",
            "Bobin akım izi kesicinin elektrokardiyogramıdır: mekanizma yavaşladıysa, bobin ısındıysa ya da kumanda gerilimi düştüyse izde görülür.",
            "Akü zayıfsa en iyi röle bile işe yaramaz: açma devresi ve kumanda gerilimi korumanın parçasıdır.",
        ],
        "tablolar": [{"baslik": "Kesiciyi zorlayan üç durum", "cols": ["Durum", "Akım", "Zorlayan", "Sonuç", "Önlem"], "rows": [
            ["Kısa devre", "kA", "büyük akım, doğru akım bileşeni, hızlı yükselen toparlanma gerilimi", "kesememe, kontak aşınması", "yeterli kesme kapasitesi ve doğru akım bileşeni sınıfı"],
            ["Küçük endüktif akım", "birkaç A", "akım sıfırdan önce kopar", "aşırı gerilim (trafo, motor sargısı)", "parafudr, RC söndürücü"],
            ["Kapasitif akım", "onlarca A", "kontaklar arasında 2 pu gerilim", "yeniden tutuşma, gerilim yükselmesi", "kapasitif kesme sınıfı uygun kesici"],
        ]}],
    }
