"""Arıza akımının trafodan geçişi: AG tarafındaki bir arıza OG tarafında hangi fazlarda, ne büyüklükte görünür; sıfır bileşen neden geçmez.

Dayanak: simetrili bileşenler (temel bağıntı). Pozitif bileşen trafodan geçerken bağlantı grubunun saat sayısı kadar, negatif bileşen aynı açı
kadar ters yönde döner; sıfır bileşen yalnız iki tarafta da topraklı yıldız varsa geçer, üçgen sargıda dolaşır. Trafonun sıfır bileşen empedansı
Dyn'de kısa devre empedansına eşit alınmıştır; Yyn'de (üç bacaklı çekirdek, primer yıldız noktası yalıtılmış) mıknatıslanma yolundan kapanan değer
tipiktir (tahmini). 87T sıfır bileşen telafisi: P3T/en M/L007 Çizelge 93."""
from __future__ import annotations

import cmath
import math

from .ortak import A, A120, C, Cizim, G, K, KABUL, P3T, S, S3, T, aci, ariza, ctl, fazor, fnum, num, opt

ID = "trafo_gecis"
BASLIK = "Arıza akımının trafodan geçişi"
IKON = "🔀"
GIRIS = ("AG tarafındaki arıza, OG tarafındaki röleye olduğu gibi yansımaz: bağlantı grubu fazörleri döndürür, üçgen sargı sıfır bileşeni hapseder. "
         "Bu sayfada aynı arızanın iki tarafta nasıl göründüğünü ve OG rölesinin neyi görüp neyi göremediğini izlersiniz.")

# ad: (primer, sekonder, saat sayısı, sıfır bileşenin AG'den görülen yolu, sıfır bileşen OG'ye geçer mi)
GRUP = {
    "Dyn11": ("ucgen", "yildiz", 11, "trafo", False), "Dyn5": ("ucgen", "yildiz", 5, "trafo", False),
    "YNyn0": ("yildiz", "yildiz", 0, "kaynak", True), "Yyn0": ("yildiz", "yildiz", 0, "cekirdek", False),
    "YNd11": ("yildiz", "ucgen", 11, "yok", False), "Dd0": ("ucgen", "ucgen", 0, "yok", False),
}
TIP = {"3f": "Üç fazlı", "2f": "İki fazlı (L2–L3)", "1f": "Faz–toprak (L1)", "2ft": "İki faz–toprak (L2–L3–toprak)"}
Z0_CEKIRDEK = 0.6       # pu — üç bacaklı çekirdekte sıfır bileşen akısı kazan üzerinden kapanır (tipik 0,3 … 1 pu)

KONTROLLER = [
    ctl("grup", "Bağlantı grubu", "sec", "Dyn11", secenek=opt(("Dyn11", "Dyn11 (dağıtım trafosu)"), ("Dyn5", "Dyn5"), ("YNyn0", "YNyn0 (iki yıldız noktası da topraklı)"),
                                                              ("Yyn0", "Yyn0 (primer yıldız noktası yalıtılmış)"), ("YNd11", "YNd11 (arıza üçgen tarafında)"), ("Dd0", "Dd0"))),
    ctl("tip", "AG tarafındaki arıza", "sec", "1f", secenek=opt(*TIP.items())),
    ctl("sn", "Trafo gücü", "sec", 1600, secenek=opt(*[(v, f"{v} kVA") for v in (250, 400, 630, 1000, 1250, 1600, 2000, 2500)])),
    ctl("uk", "Kısa devre gerilimi uk", "sayi", 6.0, min=3, max=12, adim=0.1, birim="%"),
    ctl("u1", "OG gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("u2", "AG gerilimi", "sec", 0.4, secenek=opt((0.4, "0,4 kV"), (0.69, "0,69 kV"))),
    ctl("sk", "OG barasında şebeke kısa devre gücü", "sayi", 250, min=20, max=2500, adim=10, birim="MVA"),
    ctl("ct_p", "OG akım trafosu primeri", "sayi", 50, min=5, max=600, adim=5, birim="A"),
    ctl("s_i", "OG rölesi › I> başlatma", "sayi", 1.2, min=0.2, max=10, adim=0.05, birim="×In"),
    ctl("s_io", "OG rölesi › Io> başlatma", "sayi", 0.10, min=0.01, max=2, adim=0.01, birim="×In"),
]


def hesap(p: dict, tip: str | None = None) -> dict:
    g = p.get("grup") if p.get("grup") in GRUP else "Dyn11"
    tip = tip or (p.get("tip") if p.get("tip") in TIP else "1f")
    pri, sek_, saat, yol, gecer = GRUP[g]
    sn, uk, u1, u2, sk = num(p, "sn", 1600), num(p, "uk", 6) / 100, num(p, "u1", 34.5), num(p, "u2", 0.4), num(p, "sk", 250)
    zs = sn / 1000 / sk                                                  # şebeke empedansı, trafo tabanında (pu)
    z1 = 1j * (zs + uk)
    z0 = {"trafo": 1j * uk, "kaynak": 1j * (zs + uk), "cekirdek": 1j * Z0_CEKIRDEK, "yok": 1e9j}[yol]
    r = ariza(tip, 1.0, z1, z0, 0j, 0j)
    i0, i1, i2 = r["i0"], r["i1"], r["i2"]
    d = cmath.exp(1j * math.radians(30 * saat))                         # AG, OG'den saat×30° geridedir: OG'ye geçerken pozitif bileşen +saat×30° döner (Dyn11: 330° = −30°)
    a = A120
    h1, h2, h0 = i1 * d, i2 / d, (i0 if gecer else 0j)                  # negatif bileşen aynı açı kadar ters yönde döner
    ag = r["I"]
    og = (h0 + h1 + h2, h0 + a * a * h1 + a * h2, h0 + a * h1 + a * a * h2)
    in1, in2 = sn / (S3 * u1), sn / (S3 * u2)
    return {"g": g, "tip": tip, "pri": pri, "sek": sek_, "saat": saat, "yol": yol, "gecer": gecer, "zs": zs, "uk": uk, "ag": ag, "og": og, "in1": in1, "in2": in2,
            "i3": 1 / abs(z1), "ag_toprak": abs(3 * i0), "og_i0": abs(3 * h0), "og_i2": abs(h2), "i1": i1, "i2": i2, "i0": i0}


def run(p: dict) -> dict:
    h = hesap(p)
    g, tip, in1, in2, i3 = h["g"], h["tip"], h["in1"], h["in2"], h["i3"]
    ct, s_i, s_io = num(p, "ct_p", 50), num(p, "s_i", 1.2), num(p, "s_io", 0.1)
    ag_a = [abs(x) * in2 for x in h["ag"]]; og_a = [abs(x) * in1 for x in h["og"]]
    og_max = max(og_a); ag_max = max(ag_a)
    oran = (max(abs(x) for x in h["og"]) / max(abs(x) for x in h["ag"])) if ag_max > 1e-6 else 0.0
    gorur = og_max >= s_i * ct
    toprak_gorur = h["og_i0"] * in1 >= s_io * ct
    ag_toprak = h["ag_toprak"] * in2 > 1.0

    c = Cizim(900, 320)
    ys = (70, 125, 180)
    c.yazi(190, 34, "OG tarafı", "#475569", 11, kalin=True, anchor="middle"); c.yazi(690, 34, "AG tarafı", "#475569", 11, kalin=True, anchor="middle")
    c.daire(418, 125, 46, "cizgi", dolgu="#fff"); c.daire(482, 125, 46, "cizgi", dolgu="#fff")
    c.sarim(418, 125, h["pri"], "#334155", 20); c.sarim(482, 125, h["sek"], "#334155", 20)
    c.yazi(466, 196, g, "#1e293b", 12.5, kalin=True, anchor="end"); c.yazi(466, 212, f"{num(p, 'sn', 1600):g} kVA · uk %{fnum(h['uk'] * 100, 1)}", "#64748b", 10, anchor="end")
    for j, (y, faz) in enumerate(zip(ys, ("L1", "L2", "L3"))):
        a_og, a_ag = og_a[j], ag_a[j]
        c.hat(f"M40,{y} H372", faz, hot=a_og > 0.02 * max(og_max, 1e-9), w=2.6)
        c.hat(f"M528,{y} H800", faz, hot=a_ag > 0.02 * max(ag_max, 1e-9), w=2.6)
        c.yazi(46, y - 8, faz, "#475569", 10)
        c.yazi(200, y - 8, f"{fnum(a_og, 0)} A  ∠{fnum(aci(h['og'][j]), 0)}°" if a_og > 0.5 else "0 A", "#b91c1c" if a_og > 0.5 else "#94a3b8", 11.5, kalin=a_og > 0.5, anchor="middle")
        c.yazi(660, y - 8, f"{fnum(a_ag / 1000, 2)} kA  ∠{fnum(aci(h['ag'][j]), 0)}°" if a_ag > 1 else "0", "#b91c1c" if a_ag > 1 else "#94a3b8", 11.5, kalin=a_ag > 1, anchor="middle")
    c.toroid(110, 125, 8, 72); c.yazi(110, 240, f"AT {ct:g}/…", "#475569", 10, anchor="middle")
    c.kutu(60, 252, 200, 50, "OG rölesi", ("I> başladı" if gorur else "I> başlamadı") + " · " + ("Io> başladı" if toprak_gorur else "Io> başlamadı"), "acti" if gorur else "normal")
    if h["sek"] == "yildiz":
        c.hat("M482,171 V246", "N", hot=ag_toprak, w=2); c.toprak(482, 248, "ariza" if ag_toprak else "toprak"); c.yazi(500, 244, "yıldız noktası", "#64748b", 9.5)
    xf = 770
    if tip == "3f":
        c.hat(f"M{xf},{ys[0]} V{ys[2]}", "ariza", hot=True, w=2.4)
    elif tip == "2f":
        c.hat(f"M{xf},{ys[1]} V{ys[2]}", "ariza", hot=True, w=2.4)
    elif tip == "1f":
        c.hat(f"M{xf},{ys[0]} V246", "ariza", hot=ag_toprak, w=2.4); c.toprak(xf, 248, "ariza")
    else:
        c.hat(f"M{xf},{ys[1]} V246", "ariza", hot=True, w=2.4); c.toprak(xf, 248, "ariza")
    c.simsek(xf - 22, ys[0] - 2 if tip in ("3f", "1f") else ys[1] - 2, 1.1)
    c.yazi(880, 52, TIP[tip] + " arıza", "#b91c1c", 11, kalin=True, anchor="end")
    c.yazi(560, 286, f"AG toprak akımı {fnum(h['ag_toprak'] * in2 / 1000, 2)} kA → OG'de 3·I0 = {fnum(h['og_i0'] * in1, 0)} A", "#15803d" if h["og_i0"] < 1e-6 else "#334155", 11.5, kalin=True)

    renk = ("#8a4b12", "#111827", "#6b7280")
    f_ag = {"baslik": "AG faz akımları (trafo anma akımının katı)", "vektorler": [fazor(f"L{j + 1}", h["ag"][j], renk[j]) for j in range(3)]}
    f_og = {"baslik": "OG faz akımları (trafo anma akımının katı)", "vektorler": [fazor(f"L{j + 1}", h["og"][j], renk[j]) for j in range(3)],
            "not": "Pozitif bileşen bir yöne, negatif bileşen öbür yöne aynı açı kadar döner; sıfır bileşen üçgende kalır."}
    ozet = [
        K("AG arıza akımı", f"{fnum(ag_max / 1000, 2)} kA", "info", f"{TIP[tip].lower()} · üç fazlı değerin %{fnum(max(abs(x) for x in h['ag']) / i3 * 100, 0)}'i" if ag_max > 1 else "akım akmaz: sıfır bileşenin yolu yok"),
        K("OG'de en büyük faz akımı", f"{fnum(og_max, 0)} A", "ok" if gorur else "warn", f"{fnum(og_max / ct, 2)} ×In(AT) · I> {'başlar' if gorur else 'başlamaz'}"),
        K("OG / AG oranı", f"{fnum(oran, 3)}" if ag_max > 1 else "—", "info", "çevirme oranına göre düzeltilmiş; 1,00 = aynen yansıyor"),
        K("OG'de toprak akımı 3·I0", f"{fnum(h['og_i0'] * in1, 0)} A", "info", "sıfır bileşen " + ("OG'ye geçiyor" if h["og_i0"] > 1e-6 else "OG'ye geçmiyor")),
        K("OG'de akım taşıyan faz", f"{sum(1 for x in og_a if og_max > 0.5 and x > 0.02 * og_max)} faz", "info", " · ".join(f"L{j + 1} {fnum(abs(h['og'][j]) / max(max(abs(x) for x in h['og']), 1e-9), 2)}" for j in range(3))),
    ]
    kontroller = [
        C("OG faz aşırı akım rölesi bu AG arızasını görüyor mu?", f"{fnum(og_max, 0)} A = {fnum(og_max / ct, 2)} ×In(AT)", f"I> = {fnum(s_i, 2)} ×In = {fnum(s_i * ct, 0)} A", gorur if ag_max > 1 else None,
          "Röle primer tarafın faz akımlarını ölçer; AG arızası ona bu sayfadaki dağılımla ulaşır", "hesap"),
        C("OG toprak rölesi AG toprak arızasını görür mü?", f"OG'de 3·I0 = {fnum(h['og_i0'] * in1, 0)} A", "üçgen sargı varsa görmez — beklenen budur", None,
          "Sıfır bileşen akımı üçgen sargının içinde dolaşır, hatta çıkmaz. OG toprak rölesinin AG arızasında başlamaması seçiciliği kolaylaştırır", "hesap"),
        C("Sıfır bileşenin AG'den görülen yolu", {"trafo": "üçgen sargı üzerinden: Z0 ≈ uk", "kaynak": "iki yıldız noktası da topraklı: Z0 = şebeke + trafo", "cekirdek": f"yalnız çekirdek / kazan: Z0 ≈ {fnum(Z0_CEKIRDEK, 1)} pu", "yok": "yol yok: toprak arızasında akım akmaz"}[h["yol"]],
          "—", None, "Yyn'de sıfır bileşen empedansı tipik değerdir (üç bacaklı çekirdek); beş bacaklı ya da tek fazlı birimlerde çok daha büyüktür", "tahmini" if h["yol"] == "cekirdek" else "hesap"),
    ]
    girdiler = [
        G("Trafonun bağlantı grubu", g, "Trafo etiketi", "Fazörlerin ne kadar döndüğünü ve sıfır bileşenin geçip geçmediğini belirler", "Dyn11: AG, OG'den 30° ileridedir"),
        G("Trafo gücü ve kısa devre gerilimi", f"{num(p, 'sn', 1600):g} kVA · uk %{fnum(h['uk'] * 100, 1)}", "Trafo etiketi", "AG arıza akımını sınırlayan asıl empedans", f"I3f ≈ In / (uk + şebeke) = {fnum(i3, 1)} × In"),
        G("OG barasındaki şebeke kısa devre gücü", f"{fnum(num(p, 'sk', 250), 0)} MVA", "Dağıtım şirketinin bağlantı görüşü", "Trafo empedansına seri eklenir; küçük trafoda etkisi azdır", f"zs = Sn / Sk″ = {fnum(h['zs'] * 100, 2)} %"),
        G("OG akım trafosu oranı ve röle ayarları", f"{ct:g} A · I> {fnum(s_i, 2)} ×In", "Hücre etiketi; ayar föyü", "AG arızasının OG rölesinde kaç kat göründüğü buna göre okunur", "×In(AT) = primer akım / AT primeri"),
    ]
    adimlar = [
        A("Anma akımları", "In = Sn / (√3·U)", f"{num(p, 'sn', 1600):g} / (1,732 × U)", f"OG {fnum(in1, 1)} A · AG {fnum(in2, 0)} A", "temel bağıntı", "hesap", ["Trafo gücü ve kısa devre gerilimi"]),
        A("AG'de üç fazlı arıza akımı", "I3f = In / (uk + Sn/Sk″)", f"1 / ({fnum(h['uk'], 3)} + {fnum(h['zs'], 4)})", f"{fnum(i3, 1)} × In = {fnum(i3 * in2 / 1000, 1)} kA", "birim değerlerle kısa devre hesabı", "hesap", ["Trafo gücü ve kısa devre gerilimi", "OG barasındaki şebeke kısa devre gücü"]),
        A("AG tarafında bileşenler", "arıza tipine göre I1, I2, I0", TIP[tip], f"I1 {fnum(abs(h['i1']), 2)} · I2 {fnum(abs(h['i2']), 2)} · I0 {fnum(abs(h['i0']), 2)} × In", "bkz. Simetrili bileşenler sayfası", "hesap"),
        A("OG tarafına geçiş", f"I1(OG) = I1 · 1∠{-30 * (12 - h['saat']) if h['saat'] else 0}° ;  I2(OG) = I2 · 1∠{30 * (12 - h['saat']) if h['saat'] else 0}° ;  I0(OG) = " + ("I0" if h["gecer"] else "0"),
          f"saat sayısı {h['saat']}", " · ".join(f"L{j + 1} {fnum(og_a[j], 0)} A" for j in range(3)), "Bağlantı grubu pozitif ve negatif bileşeni ters yönlerde döndürür", "hesap", ["Trafonun bağlantı grubu"]),
        A("OG rölesinin gördüğü", "en büyük faz akımı / AT primeri", f"{fnum(og_max, 0)} / {ct:g}", f"{fnum(og_max / ct, 2)} ×In", "ölçekleme", "hesap", ["OG akım trafosu oranı ve röle ayarları"], "I> (OG)"),
    ]
    ayarlar = [
        S("OG › I> başlatma", f"{fnum(s_i, 2)} ×In", "—", "AG'deki en küçük arıza (genellikle faz–toprak) OG'de 0,58 katı göründüğü için duyarlılık bu arızaya göre denetlenir", "bu sayfadaki hesap", "hesap"),
        S("87T › Bağlantı grubu", g.replace("n", "").replace("N", "") if g.startswith("Dyn") else g, "—", "Diferansiyel röle iki tarafın akımını karşılaştırmadan önce açıyı bu ayara göre düzeltir", P3T + " Çizelge 93"),
        S("87T › Io cmps (OG) · I'o cmps (AG)", "KAPALI · AÇIK" if g.startswith("Dyn") else "—", "AÇIK / KAPALI", "AG tarafının sıfır bileşeni OG'ye geçmediği için AG akımından çıkarılır; yoksa dış toprak arızasında fark akımı oluşur", P3T + " Çizelge 93 (Dyn11)"),
    ]
    test = [
        T("Primer enjeksiyon: AG'de tek faz", "AG L1–N arasına akım (ya da OG'den düşük gerilim uygulayıp AG L1–N kısa devre)", "OG'de iki fazda eşit akım, üçüncüsünde sıfır (Dyn)", KABUL),
        T("Primer enjeksiyon: AG'de iki faz", "AG L2–L3 kısa devre", "OG'de bir fazda tam, öbür ikisinde yarım akım (Dyn)", "oran 1 : 0,5 : 0,5"),
        T("87T kararlılık", "Yük altında fark akımı okunur", "Fark akımı ≈ 0; bağlantı grubu ya da sıfır bileşen telafisi yanlışsa büyük okunur", "bkz. Trafo diferansiyeli sayfası"),
    ]
    rows = []
    for t in TIP:
        hh = hesap(p, t)
        m_ag = [abs(x) / i3 for x in hh["ag"]]; m_og = [abs(x) / i3 for x in hh["og"]]
        rows.append([TIP[t], " : ".join(fnum(v, 2) for v in m_ag), " : ".join(fnum(v, 2) for v in m_og), fnum(hh["og_i0"] / i3, 2), fnum(max(m_og), 2)])
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["87t"], "sahne": c.sahne(fazorler=[f_ag, f_og]),
        "anlatim": [
            f"AG tarafında {TIP[tip].lower()} arıza var. AG fazlarındaki akım: " + " · ".join(f"L{j + 1} {fnum(ag_a[j] / 1000, 2)} kA" for j in range(3)) + ".",
            "Arıza akımı bileşenlerine ayrılır. Pozitif ve negatif bileşen trafodan geçer ama bağlantı grubu yüzünden zıt yönlerde döner; bu yüzden OG'deki faz akımlarının dağılımı AG'dekine benzemez.",
            "Dyn trafoda AG faz–toprak arızası OG'de iki fazda akım olarak görünür; üçüncü faz boştur. Büyüklüğü, çevirme oranına bölünmüş AG akımının 1/√3'üdür (0,58).",
            "AG iki fazlı arızası OG'de üç faza yayılır: birinde üç fazlı arıza kadar, öbür ikisinde yarısı kadar akım. İki fazlı arıza OG'de «üç fazlıymış gibi» okunabilir.",
            "Sıfır bileşen akımı üçgen sargının içinde dolaşır ve OG hattına çıkmaz. OG toprak rölesi AG'deki toprak arızasını görmez; onu OG faz rölesi iki fazlı arıza gibi görür.",
            "Trafonun iki sargısı da üçgense ya da arıza üçgen tarafındaysa, toprak arızasında akacak yol yoktur: akım yerine gerilim kayar.",
        ],
        "dersler": [
            "Dyn trafoda AG faz–toprak arızası OG rölesine 0,58 katı ulaşır: OG rölesinin duyarlılığı bu arızaya göre denetlenir.",
            "AG iki fazlı arızası OG'de bir fazda tam, iki fazda yarım akımdır: arıza kaydındaki faz dağılımından arızanın tipi okunabilir.",
            "Üçgen sargı sıfır bileşen için duvardır: toprak koruması her gerilim düzeyinde ayrı kurulur ve birbirini beklemez.",
            "Diferansiyel rölede bağlantı grubu ve sıfır bileşen telafisi yanlış girilirse, sağlam trafo dış arızada açar.",
        ],
        "tablolar": [{"baslik": f"{g}: AG'deki dört arıza tipi OG'de nasıl görünür (üç fazlı arıza akımının katı)", "cols": ["AG arızası", "AG: L1 : L2 : L3", "OG: L1 : L2 : L3", "OG 3·I0", "OG'de en büyük faz"], "rows": rows,
                      "not": "OG değerleri çevirme oranına göre düzeltilmiştir: 1,00, AG'deki üç fazlı arızanın OG'de göründüğü akımdır."}],
    }
