"""Evirici kaynaklı arıza akımı: güneş santrali eviricisi arızayı senkron jeneratör gibi beslemez; akımı sınırlıdır, dengelidir ve çabuk oturur.

Dayanak: Elektrik Şebeke Yönetmeliği Ek-18, E.18.2 (kapsam: iletime bağlı rüzgâr ve güneş, dağıtıma OG'den bağlı lisanslı güneş santralleri; gerilim
düşümünde Şekil E.18.1'in 1 ve 2 numaralı bölgelerinde bağlı kalma; ±%10'dan büyük gerilim dalgalanmasında nominal akımın %100'üne varan reaktif akım
desteği, 60 ms içinde %10 hata payıyla, 1,5 s boyunca; arıza sonrası aktif gücün saniyede en az %20 / %5 artırılması). Lisanssız tesislerde gerilim
korumaları: LÜY Uygulama Tebliği Ek-2 Tablo-2. Gerilime bağlı aşırı akım: P3U/en M/J006 böl. 5.24. Eviricinin akım sınırı (1,1–1,2 × In) ve senkron
makinenin reaktans / zaman sabiti değerleri tipiktir (tahmini); Şekil E.18.1'in sayısal sınırları metinden okunamadığı için kullanılmadı."""
from __future__ import annotations

import math

from .ortak import A, A120, C, G, K, LUY, P3U, S, S3, T, ctl, fa, fazor, fnum, num, opt, tek_hat

ID = "evirici"
BASLIK = "Evirici kaynaklı arıza akımı"
IKON = "☀"
GIRIS = ("Senkron jeneratör kısa devreyi anma akımının birkaç katıyla besler; evirici ise akımını yarı iletkenlerini korumak için anma akımının hemen üstünde "
         "sınırlar ve üç fazda dengeli tutar. Akıma bakan korumalar bu yüzden evirici katkısını göremeyebilir. Kaynağı ve arızayı seçin; iki kaynağın "
         "farkını ve korumaların ne gördüğünü izleyin.")
SEBEKE = "Elektrik Şebeke Yön. Ek-18 (E.18.2)"
KAYNAK = {"evirici": "Evirici (güneş santrali)", "senkron": "Senkron jeneratör (biyogaz, kojenerasyon)"}

KONTROLLER = [
    ctl("kaynak", "Santralin kaynağı", "sec", "evirici", secenek=opt(*KAYNAK.items())),
    ctl("sn", "Santralin gücü", "sayi", 1000, min=100, max=20000, adim=50, birim="kVA"),
    ctl("un", "Bağlantı gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("tip", "Şebekedeki arıza", "sec", "3f", secenek=opt(("3f", "Üç fazlı"), ("2f", "İki fazlı (L2–L3)"))),
    ctl("u", "Bağlantı noktasında kalan gerilim", "sayi", 20, min=0, max=95, adim=1, birim="%Un", yardim="Arıza ne kadar yakınsa gerilim o kadar çöker"),
    ctl("t_ar", "Arızanın süresi", "sayi", 0.5, min=0.05, max=3.0, adim=0.05, birim="s"),
    ctl("k", "Evirici akım sınırı", "sayi", 1.1, min=1.0, max=1.5, adim=0.01, birim="×In", goster={"kaynak": ["evirici"]}, yardim="Evirici veri sayfasındaki en büyük çıkış akımı"),
    ctl("xd2", "Jeneratör x″d", "sayi", 0.18, min=0.08, max=0.35, adim=0.01, birim="pu", goster={"kaynak": ["senkron"]}),
    ctl("xd1", "Jeneratör x′d", "sayi", 0.30, min=0.15, max=0.6, adim=0.01, birim="pu", goster={"kaynak": ["senkron"]}),
    ctl("xd", "Jeneratör xd", "sayi", 2.0, min=0.8, max=3.0, adim=0.05, birim="pu", goster={"kaynak": ["senkron"]}),
    ctl("uk", "Yükseltici trafo uk", "sayi", 6.0, min=4, max=10, adim=0.1, birim="%"),
    ctl("i_r", "Röle › I> başlatma", "sayi", 1.2, min=0.3, max=5, adim=0.05, birim="×In(santral)", yardim="Yönlü / yönsüz aşırı akım: çoğu kez 1,2 × ihracat akımı"),
    ctl("t_r", "Röle › I> süresi", "sayi", 0.30, min=0.05, max=2, adim=0.05, birim="s"),
    ctl("kapsam", "Tesisin kapsamı", "sec", "luy", secenek=opt(("luy", "Lisanssız (LÜY Tebliği gerilim korumaları)"), ("ek18", "Lisanslı OG güneş santrali (Şebeke Yön. Ek-18)"))),
]
T2D, T1D = 0.03, 0.8            # s — alt geçici ve geçici zaman sabitleri (tipik)


def akim(p: dict, t: float, kaynak: str | None = None) -> float:
    """Santralin arızaya katkısı (×In, etkin değer) — arıza t = 0'da başlar."""
    kaynak = kaynak or (p.get("kaynak") if p.get("kaynak") in KAYNAK else "evirici")
    u = num(p, "u", 20) / 100
    if kaynak == "evirici":
        k = num(p, "k", 1.1)
        return k + (0.6 * math.exp(-t / 0.004) if t >= 0 else 0.0)                 # ilk milisaniyelerde denetim yetişene kadar kısa bir tepe (tahmini)
    xt = num(p, "uk", 6) / 100
    i2, i1, ik = ((1.1 - u) / (num(p, key, d) + xt) for key, d in (("xd2", 0.18), ("xd1", 0.30), ("xd", 2.0)))
    return (i2 - i1) * math.exp(-t / T2D) + (i1 - ik) * math.exp(-t / T1D) + ik


def reaktif(p: dict, t: float) -> float:
    """Eviricinin reaktif akımı (×In): 60 ms içinde hedefe (gerekirse %100) ulaşır."""
    u = num(p, "u", 20) / 100
    hedef = min(1.0, num(p, "k", 1.1)) if u < 0.9 else 0.0
    return hedef * (1 - math.exp(-t / 0.02)) if t >= 0 else 0.0


def run(p: dict) -> dict:
    kay = p.get("kaynak") if p.get("kaynak") in KAYNAK else "evirici"
    ev = kay == "evirici"
    sn, un, u, t_ar = num(p, "sn", 1000), num(p, "un", 34.5), num(p, "u", 20) / 100, num(p, "t_ar", 0.5)
    i_r, t_r, k = num(p, "i_r", 1.2), num(p, "t_r", 0.3), num(p, "k", 1.1)
    iki = p.get("tip") == "2f"
    i_n = sn / (S3 * un)
    ts = [j * 0.005 for j in range(int(t_ar / 0.005) + 1)]
    i_t = [akim(p, t) for t in ts]
    # I> kademesi: akım eşiğin üstünde t_r süre kesintisiz kalırsa açar
    ust = [t for t, v in zip(ts, i_t) if v >= i_r]
    kalma = 0.0
    for t, v in zip(ts, i_t):
        if v >= i_r:
            kalma = t
        else:
            break
    basladi = bool(ust) and i_t[0] >= i_r
    acti = basladi and kalma >= t_r and (ev is False or k >= i_r)
    if ev:
        basladi = k >= i_r; acti = basladi and t_ar >= t_r
    # gerilim korumaları (LÜY Tebliği Ek-2 Tablo-2): %50–88 → 2,0 s ; < %50 → 0,2 s (kesici süresi dahil)
    t27 = 0.2 if u < 0.5 else 2.0 if u < 0.88 else math.inf
    ayrilir27 = t_ar >= t27
    luy = p.get("kapsam") != "ek18"
    i2 = (0.0 if ev else i_t[0] * 0.5) if iki else 0.0                      # iki fazlı arıza: senkron makinede I2 ≈ I1 (akımın yarısı kadar bileşenler); evirici dengeli akım basar
    iq = reaktif(p, 0.06) if ev else 0.0
    ilk = k if ev else i_t[0]                                              # eviricide ilk milisaniyelerdeki tepe ölçüye girmez

    c = tek_hat(("Santral", f"{fnum(sn, 0)} kVA · {'evirici' if ev else 'senkron'}"), ("Şebeke", f"arıza · U = %{fnum(u * 100, 0)}"), ("Santral çıkış rölesi", "I> " + ("AÇTI" if acti else "başladı" if basladi else "başlamadı")),
                "acti" if acti else "normal", 620, "sag", ileri=True, h=310, kesici_acik=acti)
    c.yazi(500, 178, f"Katkı: ilk anda {fnum(ilk, 2)} → {fnum(t_ar, 2)} s sonunda {fnum(i_t[-1], 2)} ×In", "#b91c1c", 12, kalin=True)
    c.yazi(500, 198, f"I> = {fnum(i_r, 2)} ×In ({fa(i_r * i_n)}) · " + ("eşiğin üstünde kalıyor" if acti else "eşiğe ulaşmıyor" if not basladi else "süre dolmadan eşiğin altına iniyor"), "#15803d" if acti else "#b45309", 11.5)
    c.yazi(500, 218, ("Negatif bileşen: " + ("yok — evirici üç fazda dengeli akım basar" if ev else f"{fnum(i2, 2)} ×In")) if iki else ("Reaktif akım 60 ms'de " + f"{fnum(iq, 2)} ×In" if ev else "Akım alt geçici → geçici → sürekli değerlere söner"), "#334155", 11.5)
    c.yazi(500, 246, f"Gerilim koruması (U<): %{fnum(u * 100, 0)} Un → " + (f"{fnum(t27, 1)} s'de ayırır" if t27 < math.inf else "çalışmaz (gerilim %88'in üstünde)"), "#1a4d8f", 12, kalin=True)
    c.yazi(500, 266, ("Lisanssız tesis: ada kalmamak için ayrılması istenir" if luy else "Ek-18: Şekil E.18.1'in 1–2. bölgesinde bağlı kalmalıdır"), "#475569", 11)

    ozet = [
        K("Santralin arıza katkısı", f"{fnum(ilk, 2)} ×In", "info", f"{fa(ilk * i_n)} · {fnum(t_ar, 2)} s sonunda {fnum(i_t[-1], 2)} ×In"),
        K("Aşırı akım kademesi (I>)", "AÇAR" if acti else "başlar, açmaz" if basladi else "görmez", "ok" if acti else "warn", f"eşik {fnum(i_r, 2)} ×In · süre {fnum(t_r, 2)} s"),
        K("Negatif bileşen", f"{fnum(i2, 2)} ×In" if iki else "—", "info", ("evirici dengeli akım basar: 46 ve negatif bileşenli yön elemanı çalışmaz" if ev else "senkron makine dengesiz arızayı dengesiz besler") if iki else "üç fazlı arızada yok"),
        K("Gerilim koruması (27)", f"{fnum(t27, 1)} s" if t27 < math.inf else "çalışmaz", "ok" if ayrilir27 or t27 == math.inf else "info", f"kalan gerilim %{fnum(u * 100, 0)} Un" + (" · arıza süresi içinde ayırır" if ayrilir27 else "")),
        K("Reaktif akım desteği", f"{fnum(iq, 2)} ×In" if ev else "—", "info", "60 ms içinde, 1,5 s boyunca (Ek-18)" if ev else "uyarma düzeni belirler"),
    ]
    kontroller = [
        C("Aşırı akım kademesi santralin katkısını görüyor mu?", f"katkı {fnum(ilk, 2)} → {fnum(i_t[-1], 2)} ×In; eşik {fnum(i_r, 2)} ×In, {fnum(t_r, 2)} s", "evirici akımı sınırlıdır: çoğu kez görmez", None if ev else acti,
          "Evirici, anahtarlama elemanlarını korumak için akımını anma değerinin hemen üstünde sınırlar; senkron makinenin akımı reaktanslarıyla belirlenir ve söner", "tahmini" if ev else "hesap"),
        C("Arızayı gerilimden yakalayan bir koruma var mı?", f"U = %{fnum(u * 100, 0)} Un → U< kademesi " + (f"{fnum(t27, 1)} s" if t27 < math.inf else "çalışmaz"), "U < %88 → 2,0 s ; U < %50 → 0,2 s", (t27 < math.inf) if u < 0.88 else None,
          "Süreler kesicinin açma süresini içerir — " + LUY, "resmi"),
        C("Reaktif akım desteği", f"{fnum(iq, 2)} ×In (60 ms'de)" if ev else "evirici değil", "gerekirse nominal akımın %100'üne kadar; 60 ms içinde, %10 hata payıyla; 1,5 s sürdürülür", None,
          "Gerilim dalgalanması ±%10'dan büyükse her evirici geçici rejim anma değerlerini aşmadan en büyük reaktif akım desteğini sağlar — " + SEBEKE, "resmi"),
        C("Arıza süresince bağlı kalma", "lisanssız: ayrılır" if luy else "lisanslı OG güneş santrali: bağlı kalır", "Şekil E.18.1'in 1 ve 2 numaralı bölgeleri", None,
          "Gerilim bu bölgelerde kaldığı sürece üretim tesisi şebekeye bağlı kalmalıdır; arıza temizlenince aktif güç saniyede en az %20 (1. bölge) ya da %5 (2. bölge) artırılır — " + SEBEKE + ". Şeklin sayısal sınırları burada kullanılmadı", "resmi"),
    ]
    girdiler = [
        G("Kaynağın türü ve gücü", f"{KAYNAK[kay]} · {fnum(sn, 0)} kVA", "Tek hat şeması; evirici ya da jeneratör etiketi", "Arıza katkısının büyüklüğünü ve zamanla değişimini belirler", "evirici: k × In; senkron: (c·U − Ukalan) / (x + xt)"),
        G("Eviricinin en büyük çıkış akımı", f"{fnum(k, 2)} ×In" if ev else "—", "Evirici veri sayfası («max. output current», «short-circuit current»)", "Akıma dayalı korumanın görüp göremeyeceği bu sayıya bağlıdır", "I> ile karşılaştırılır"),
        G("Jeneratörün x″d, x′d, xd değerleri", f"{fnum(num(p, 'xd2', 0.18), 2)} / {fnum(num(p, 'xd1', 0.3), 2)} / {fnum(num(p, 'xd', 2), 2)} pu" if not ev else "—", "Jeneratör veri sayfası", "Arıza akımının ilk değeri ve ne hızla söndüğü", "I″ → I′ → Ik"),
        G("Tesisin bağlı olduğu mevzuat kapsamı", "LÜY (lisanssız)" if luy else "Şebeke Yön. Ek-18 (lisanslı)", "Bağlantı anlaşması; çağrı mektubu", "Lisanssız tesiste ada kalmamak, lisanslı tesiste arıza boyunca bağlı kalmak esastır: gerilim korumasının süresi buna göre değişir", "U< ve U<< süreleri"),
    ]
    adimlar = [
        A("Santralin anma akımı", "In = Sn / (√3·Un)", f"{fnum(sn, 0)} / (1,732 × {fnum(un, 1)})", fa(i_n), "temel bağıntı", "hesap", ["Kaynağın türü ve gücü"]),
        A("Arıza katkısı", "evirici: k·In" if ev else "senkron: I″ = (1,1 − U) / (x″d + xt)", f"{fnum(k, 2)} × {fnum(i_n, 1)}" if ev else f"(1,1 − {fnum(u, 2)}) / ({fnum(num(p, 'xd2', 0.18), 2)} + {fnum(num(p, 'uk', 6) / 100, 2)})",
          f"{fnum(i_t[0] if not ev else k, 2)} ×In = {fa((i_t[0] if not ev else k) * i_n)}", "evirici akım sınırı (veri sayfası)" if ev else "TS EN 60909-0 yaklaşımı", "tahmini" if ev else "dogrulanacak", ["Eviricinin en büyük çıkış akımı" if ev else "Jeneratörün x″d, x′d, xd değerleri"]),
        A("Röle eşiğiyle karşılaştırma", "katkı ≥ I> ve bu süre ≥ tI>", f"{fnum(ilk, 2)} → {fnum(i_t[-1], 2)} ×In ile {fnum(i_r, 2)} ×In, {fnum(t_r, 2)} s", "açar" if acti else "açmaz", "sabit zamanlı kademenin çalışma koşulu", "hesap", [], "I>"),
        A("Gerilim kademesinin süresi", "U < %50 → 0,2 s ; %50 ≤ U < %88 → 2,0 s", f"U = %{fnum(u * 100, 0)}", f"{fnum(t27, 1)} s" if t27 < math.inf else "çalışmaz", LUY, "resmi", ["Tesisin bağlı olduğu mevzuat kapsamı"], "U< / U<<"),
    ]
    ayarlar = [
        S("I> (aşırı akım / yönlü aşırı akım)", f"{fnum(i_r, 2)} ×In(santral)", "—", "Evirici tesisinde arıza katkısı bu eşiğin altında kalabilir; koruma yalnız buna bırakılmaz", "bu sayfadaki hesap", "hesap"),
        S("U< · U<< (27)", "%88 → 2,0 s · %50 → 0,2 s (kesici süresi dahil)", "—", "Evirici katkısı küçük olsa da gerilim çöker: arızayı gerilim kademesi yakalar", LUY),
        S("IV> (51V, gerilime bağlı aşırı akım)", "gerilim düştükçe başlatma eşiği iner", "—", "Arıza akımı yük akımına yakın kaynaklarda (evirici, küçük jeneratör) eşik gerilimle birlikte düşürülür", P3U + " böl. 5.24"),
    ]
    test = [
        T("Evirici katkısı", f"Röleye {fnum(k, 2)} ×In(santral) dengeli akım", "I> başlamaz" if k < i_r else "I> başlar", "eşik " + fnum(i_r, 2) + " ×In"),
        T("Gerilim kademesi", "Üç faz gerilimi %45 Un'a düşür", "U<< 0,2 s − kesici süresinde açar", LUY),
        T("Gerilime bağlı aşırı akım", "Gerilim %30 Un iken akımı artır", "Başlatma, anma gerilimindeki eşiğin altında bir değerde", "bkz. Gerilime bağlı aşırı akım sayfası"),
    ]
    adim = max(1, len(ts) // 120)
    g1 = {"baslik": "Santralin arızaya katkısı: evirici ve senkron jeneratör", "x_ad": "Zaman (s) — arıza t = 0'da", "y_ad": "Akım (×In, etkin)", "ymin": 0,
          "seriler": [{"ad": "evirici", "renk": "#b45309", "pts": [[round(t, 3), round(akim(p, t, "evirici"), 3)] for t in ts[::adim]], "kesik": not ev},
                      {"ad": "senkron jeneratör", "renk": "#1a4d8f", "pts": [[round(t, 3), round(akim(p, t, "senkron"), 3)] for t in ts[::adim]], "kesik": ev}],
          "yatay": [{"y": i_r, "etiket": f"I> = {fnum(i_r, 2)} ×In", "renk": "#dc2626"}], "isaretler": [{"x": t_r, "etiket": "I> süresi"}] if t_r <= t_ar else []}
    tq = [j * 0.005 for j in range(-8, 61)]
    g2 = {"baslik": "Eviricinin akımı: gerilim çökünce aktif akım yerini reaktif akıma bırakır", "x_ad": "Zaman (s)", "y_ad": "Akım (×In)", "ymin": 0,
          "seriler": [{"ad": "reaktif akım", "renk": "#1a4d8f", "pts": [[t, round(reaktif(p, t), 3)] for t in tq]},
                      {"ad": "aktif akım", "renk": "#15803d", "pts": [[t, round(math.sqrt(max(k * k - reaktif(p, t) ** 2, 0)) if t >= 0 else 1.0, 3)] for t in tq]}],
          "isaretler": [{"x": 0.06, "etiket": "60 ms"}]}
    a = A120
    fazorler = []
    if iki:
        v = (1 + 0j, a * a * (0.5 + u / 2) + 0j, a * (0.5 + u / 2) + 0j)
        ie = (k * complex(0, -1), k * a * a * complex(0, -1), k * a * complex(0, -1))
        isk = (0j, akim(p, 0, "senkron") * 0.866 * (a * a - a) / abs(a * a - a), -akim(p, 0, "senkron") * 0.866 * (a * a - a) / abs(a * a - a))
        renk = ("#8a4b12", "#111827", "#6b7280")
        fazorler = [{"baslik": "Evirici: iki fazlı arızada akımlar (×In)", "vektorler": [fazor(f"L{j + 1}", ie[j], renk[j]) for j in range(3)], "not": "Üç faz eşit ve 120° aralıklı: negatif bileşen yok."},
                    {"baslik": "Senkron jeneratör: iki fazlı arızada akımlar (×In)", "vektorler": [fazor(f"L{j + 1}", isk[j], renk[j]) for j in range(3)], "not": "Yalnız arızalı iki fazda, zıt yönlü: pozitif ve negatif bileşen eşit."}]
        _ = v
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["27_dusuk", "67_yonlu"], "sahne": c.sahne(fazorler=fazorler), "grafikler": [g1, g2] if ev else [g1],
        "anlatim": [
            "Senkron jeneratör bir gerilim kaynağıdır: kısa devrede akımını yalnız kendi reaktansı sınırlar. İlk anda anma akımının 4–6 katını verir; uyarma zayıfladıkça akım birkaç saniyede anma akımının altına söner.",
            f"Evirici bir akım kaynağıdır: çıkış akımını ölçer ve yarı iletkenlerinin dayanabileceği değerde ({fnum(k, 2)} ×In) tutar. Kısa devrede de bundan fazlasını vermez; sönme yoktur, arıza sürdükçe aynı akımı basar.",
            "Gerilim çökünce evirici aktif akımı kısar, reaktif akım basar: şebeke gerilimini desteklemek için. Yönetmelik bu desteğin 60 ms içinde devreye girmesini ve 1,5 s sürmesini ister.",
            "Evirici üç fazda dengeli akım üretir. İki fazlı bir arızada bile akımında negatif bileşen yoktur: negatif bileşene bakan korumalar ve yön elemanları santral tarafından beslenen arızayı tanıyamaz.",
            f"Aşırı akım eşiği ihracat akımının üstüne ({fnum(i_r, 2)} ×In) ayarlandığında evirici katkısı ({fnum(k, 2)} ×In) eşiğe ulaşmaz. Arızayı şebeke tarafının akımı ve santral tarafında gerilim korumaları yakalar.",
            "Lisanssız tesiste amaç ada kalmamaktır: gerilim düşünce ayrılır. Lisanslı OG güneş santralinde amaç şebekeyi ayakta tutmaktır: gerilim çukurunda bağlı kalır ve reaktif akım basar. Aynı evirici iki ayrı kurala göre ayarlanır.",
        ],
        "dersler": [
            "Güneş santralinin kısa devre katkısı anma akımının 1,1–1,2 katıdır; kısa devre hesabında ve röle ayarında jeneratör gibi alınmaz.",
            "Akıma dayalı koruma evirici katkısını görmeyebilir: gerilim kademeleri ve gerilime bağlı aşırı akım bu boşluğu kapatır.",
            "Evirici akımında negatif bileşen yoktur; dengesiz arızanın izi gerilimde aranır (V2, V0).",
            "Bağlı kalma (Ek-18) ile ayrılma (LÜY) karşıt isteklerdir; tesisin hangi kapsamda olduğu ayarlardan önce belirlenir.",
        ],
        "tablolar": [{"baslik": "İki kaynağın arıza davranışı", "cols": ["", "Evirici", "Senkron jeneratör"], "rows": [
            ["İlk arıza akımı", f"{fnum(k, 2)} ×In (birkaç ms daha yüksek)", f"{fnum(akim(p, 0, 'senkron'), 2)} ×In"],
            ["0,5 s sonra", f"{fnum(k, 2)} ×In", f"{fnum(akim(p, 0.5, 'senkron'), 2)} ×In"],
            ["Sürekli", f"{fnum(k, 2)} ×In (denetim sürdürür)", f"{fnum(akim(p, 10, 'senkron'), 2)} ×In (uyarma zorlaması yoksa)"],
            ["Dengesiz arızada negatif bileşen", "yok (dengeli akım)", "var (I2 ≈ I1)"],
            ["Akımı belirleyen", "denetim yazılımı ve akım sınırı", "makinenin reaktansları ve uyarması"],
            ["Arızayı yakalayan koruma", "gerilim (27, 59N), gerilime bağlı aşırı akım", "aşırı akım, yönlü aşırı akım"],
        ], "not": "Evirici akım sınırı ve jeneratör verileri tipiktir; gerçek değerler veri sayfasından alınır."}],
    }
