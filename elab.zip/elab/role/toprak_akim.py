"""Toprak aşırı akım koruması (ANSI 50N/51N) — Easergy P3 «Io>», «Io>>» kademeleri.

Dayanak: P3U/en M/J006 böl. 5.21 (yönsüz toprak koruması küçük empedanslı şebekede ana, yüksek empedanslı / kompanze / yalıtılmış şebekede yedek
korumadır; giriş: ölçülen Io ya da hesaplanan IoHes = IL1 + IL2 + IL3 — katı ve küçük empedanslı şebeke için), Çizelge 68–70 (aralıklar, doğruluk);
URRA mühendislik esasları (30 A / 0,3 s; faz toplamında ≥ %10 In; kapasitif akım denetimi)."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, P3U, S, S3, T, URRA, Cizim, ctl, fa, fnum, kademe_test, num, opt

ID = "toprak_akim"
BASLIK = "Toprak aşırı akım (50N/51N)"
IKON = "🌍"
GIRIS = ("Yönsüz toprak kademesi yalnız artık akımın büyüklüğüne bakar. Ayarı üç şey sıkıştırır: aşağıdan fiderin kendi kapasitif akımı ve akım trafosu "
         "hatası, yukarıdan görmek istediğiniz en dirençli arıza. Aradaki pencere dar ise yönlü kademe (67N) gerekir.")

KONTROLLER = [
    ctl("un_kv", "Şebeke gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("ir_a", "Nötr direncinin akım sınırı", "sayi", 1000, min=20, max=2000, adim=10, birim="A", yardim="Besleyen trafo merkezinden; ör. 20 Ω → 1000 A"),
    ctl("ic_bu", "Bu fiderin kapasitif akımı (3·Ic0)", "sayi", 6, min=0.1, max=100, adim=0.1, birim="A", yardim="Kablo boyu × birim kapasitif akım"),
    ctl("giris", "Röle › Io girişi", "sec", "io1", secenek=opt(("io1", "Io1 — toroid (ölçülen)"), ("hes", "IoHes — faz akımlarının toplamı"))),
    ctl("io_p", "Toroidin primeri", "sayi", 50, min=1, max=1000, adim=1, birim="A", goster={"giris": ["io1"]}),
    ctl("ct_p", "Faz akım trafosu primeri", "sayi", 150, min=5, max=3000, adim=5, birim="A", goster={"giris": ["hes"]}),
    ctl("i_yuk", "Fiderin yük akımı", "sayi", 60, min=0, max=2000, adim=1, birim="A", goster={"giris": ["hes"]}),
    ctl("ref_i", "Üst röle › Io> (primer)", "sayi", 60, min=5, max=1000, adim=1, birim="A"),
    ctl("ref_t", "Üst röle › tIo>", "sayi", 0.60, min=0.1, max=5, adim=0.05, birim="s"),
    ctl("dt", "Seçicilik payı Δt", "sayi", 0.30, min=0.1, max=0.5, adim=0.05, birim="s"),
    ctl("io1", "Röle › Io> başlatma", "sayi", 0.60, min=0.005, max=8, adim=0.005, birim="pu"),
    ctl("t1", "Röle › tIo>", "sayi", 0.30, min=0.04, max=10, adim=0.01, birim="s"),
    ctl("io2", "Röle › Io>> başlatma", "sayi", 6.0, min=0.01, max=20, adim=0.01, birim="pu"),
    ctl("t2", "Röle › tIo>>", "sayi", 0.10, min=0.04, max=10, adim=0.01, birim="s"),
    ctl("yer", "Benzetim: arıza yeri", "sec", "bu", secenek=opt(("bu", "Bu fiderde"), ("diger", "Başka fiderde (bu fider sağlam)"))),
    ctl("rf", "Benzetim: arıza direnci", "sayi", 0, min=0, max=5000, adim=10, birim="Ω"),
]


def run(p: dict) -> dict:
    e = num(p, "un_kv", 34.5) * 1000 / S3
    ir, ic = num(p, "ir_a", 1000), num(p, "ic_bu", 6)
    hes = p.get("giris") == "hes"
    taban = num(p, "ct_p", 150) if hes else num(p, "io_p", 50)
    e1, e2 = num(p, "io1", 0.6) * taban, num(p, "io2", 6.0) * taban
    t1, t2 = num(p, "t1", 0.3), num(p, "t2", 0.1)
    rn = e / ir
    akim = lambda rf: e / (rn + rf)                                   # noqa: E731  — dirençli şebekede arıza akımı (kapasitif pay ihmal)
    rf = num(p, "rf", 0); bu = p.get("yer") != "diger"
    v0 = rn / (rn + rf)
    i_olc = akim(rf) if bu else ic * v0
    t_ac = t2 if i_olc >= e2 else t1 if i_olc >= e1 else math.inf
    acar = t_ac < math.inf
    rf_max = max(0.0, e / e1 - rn)
    sahte = 0.03 * num(p, "i_yuk", 60) if hes else 0.0                # faz toplamında AT oran farkından doğan sahte artık akım (yaklaşık %3 yük)
    alt = max(1.5 * ic, 0.1 * taban if hes else 0.0)
    ref_i, ref_t, dt = num(p, "ref_i", 60), num(p, "ref_t", 0.6), num(p, "dt", 0.3)
    o_e1 = min(max(alt, 30.0), ref_i)

    c = Cizim(900, 300)
    c.kutu(20, 46, 120, 50, "Besleyen trafo", f"nötr {fnum(ir, 0)} A")
    c.hat("M80,96 V120", "cizgi"); c.direnc(80, 120, "", hot=True, h=26); c.hat("M80,146 V160", "cizgi"); c.toprak(80, 160)
    c.hat("M140,71 H200", "L1", w=3); c.hat("M200,36 V240", "cizgi", w=5)
    c.hat("M200,76 H830", "L1", hot=bu, w=3); c.yazi(836, 80, "bu fider", "#334155", 10.5, kalin=True)
    c.hat("M200,206 H830", "L1", hot=not bu, w=3); c.yazi(836, 210, "diğer", "#334155", 10.5)
    c.toroid(280, 76, 7, 17); c.yazi(280, 52, "toroid" if not hes else "faz AT toplamı", "#475569", 10, anchor="middle")
    c.hat("M280,94 V124", "cizgi", kesik=True, w=1.4)
    c.kutu(215, 124, 190, 52, "50N/51N  Io>", ("AÇAR — " + fnum(t_ac, 2) + " s") if acar else "başlamadı", ("acti" if bu else "gecersiz") if acar else ("normal" if not bu or rf > rf_max else "gecersiz"))
    c.kap(720, 76, 124, ad=f"Ic {fnum(ic, 1)} A"); c.toprak(720, 124)
    yf = 76 if bu else 206
    c.simsek(554, yf - 8, 1.1); c.hat(f"M560,{yf} V{yf + 38}", "ariza", hot=True); c.toprak(560, yf + 40, "ariza"); c.yazi(572, yf + 30, f"Rf = {fnum(rf, 0)} Ω", "#b91c1c", 10.5)
    c.yazi(425, 140, f"Io = {fa(i_olc)} = {fnum(i_olc / taban, 3)} pu (taban {taban:g} A)", "#b91c1c", 11.5, kalin=True)
    c.yazi(425, 158, f"Io> {fa(e1, 0)} · Io>> {fa(e2, 0)}" + ("" if bu else " — sağlam fiderde görülen: kendi kapasitif akımı"), "#334155", 11)

    ozet = [
        K("Röle kararı", ("AÇAR " + fnum(t_ac, 2) + " s") if acar else "AÇMAZ", "ok" if acar == bu else "bad", "arıza " + ("bu fiderde" if bu else "başka fiderde") + (" — doğru" if acar == bu else " — YANLIŞ")),
        K("Ölçülen artık akım", fa(i_olc), "info", f"{fnum(i_olc / taban, 3)} pu"),
        K("Görülen en büyük arıza direnci", f"{fnum(rf_max, 0)} Ω", "info", f"Io> = {fa(e1, 0)} ile"),
        K("Ayar penceresi", f"{fa(alt, 0)} … {fa(ref_i, 0)}", "ok" if alt <= e1 <= ref_i else "bad", "alt: kapasitif akım / AT hatası · üst: üst röle"),
        K("Katı arızada akım", fa(akim(0), 0), "info", f"{fnum(akim(0) / e1, 0)} × Io>"),
    ]
    kontroller = [
        C("Sağlam fiderde açmıyor mu? (başka fiderdeki arıza)", f"kendi kapasitif akımı {fa(ic)}; Io> = {fa(e1, 0)}", "Io> ≥ 1,5 × Ic", e1 >= 1.5 * ic,
          "Yönsüz kademe yönü bilmez: fiderin kapasitif akımı eşiği aşarsa başka fiderdeki arızada açar. Sağlanmıyorsa 67N kullanılır — " + URRA, "ikincil"),
        C("Faz toplamıyla ölçümde eşik AT hatasının üstünde mi?", f"Io> = %{fnum(e1 / taban * 100, 0)} In(AT); yükte sahte artık akım ≈ {fa(sahte)}" if hes else "toroid kullanılıyor", "≥ %10 In(AT)", (e1 >= 0.1 * taban) if hes else None,
          "IoHes katı ve küçük empedanslı şebeke içindir — " + P3U + " böl. 5.21; %10: " + URRA, "ikincil"),
        C("Katı arızada yeterince büyük mü?", f"{fa(akim(0), 0)} / {fa(e1, 0)} = {fnum(akim(0) / e1, 1)}", "≥ 2", akim(0) >= 2 * e1, "Duyarlılık payı saha pratiği", "ikincil"),
        C("Üst röleyle seçicilik", f"Io> {fa(e1, 0)} · {fnum(t1, 2)} s; üst {fa(ref_i, 0)} · {fnum(ref_t, 2)} s", "eşik ≤ üst; süre ≤ üst − Δt", e1 <= ref_i + 1e-9 and t1 <= ref_t - dt + 1e-9,
          "Radyal şebekede toprak arıza akımı her yerde nötr direnciyle sınırlıdır: derecelendirme zamanla yapılır — " + URRA, "ikincil"),
        C("Ayar aralığı", f"{fnum(num(p, 'io1', 0.6), 3)} pu", "Io>: 0,005 … 8,00 pu (ölçülen girişte)", 0.005 <= num(p, "io1", 0.6) <= 8.0, P3U + " Çizelge 68", "resmi"),
    ]
    girdiler = [
        G("Nötr direncinin akım sınırı", fa(ir, 0), "Dağıtım şirketi; besleyen trafo merkezinin nötr direnci etiketi", "Toprak arıza akımının üst sınırı; arıza direnciyle birlikte küçülür", "I = E / (Rn + Rf)"),
        G("Bu fiderin kapasitif akımı", fa(ic), "Kablo tipi ve uzunluğu", "Başka fiderdeki arızada bu rölenin göreceği akım", "Io> ≥ 1,5 × Ic"),
        G("Toprak akımının nasıl ölçüldüğü", "toroid " + f"{num(p, 'io_p', 50):g}/1 A" if not hes else f"üç faz AT'nin toplamı ({taban:g} A)", "Hücre; röle bağlantı şeması", "Toroid küçük akımları doğru ölçer; faz toplamında AT'lerin oran farkı sahte artık akım üretir", "Ayarın «pu» tabanı"),
        G("Üst rölenin toprak ayarı", f"{fa(ref_i, 0)} / {fnum(ref_t, 2)} s", "Dağıtım şirketi", "Zaman merdiveni: bizim röle ondan önce açmalı", "t ≤ t(üst) − Δt"),
        G("Görülmesi istenen arıza direnci", f"{fnum(rf_max, 0)} Ω (bu ayarla)", "Dağıtım şirketi uygulaması", "Eşik küçüldükçe daha dirençli arızalar görülür; ama alt sınıra yaklaşılır", "Rf max = E / Io> − Rn"),
    ]
    adimlar = [
        A("Nötr direnci", "Rn = E / I nötr", f"{fnum(e, 0)} V / {fnum(ir, 0)} A", f"{fnum(rn, 1)} Ω", "E = Un/√3", "resmi", ["Nötr direncinin akım sınırı"]),
        A("Alt sınır", "Io> ≥ 1,5 × Ic" + ("; ≥ %10 In(AT)" if hes else ""), f"1,5 × {fnum(ic, 1)}" + (f"; 0,1 × {taban:g}" if hes else ""), fa(alt, 0), URRA, "ikincil", ["Bu fiderin kapasitif akımı", "Toprak akımının nasıl ölçüldüğü"]),
        A("Io> başlatma", "alt sınır ≤ Io> ≤ üst rölenin eşiği", f"{fnum(alt, 0)} A … {fnum(ref_i, 0)} A; uygulama değeri 30 A", f"{fa(o_e1, 0)} = {fnum(o_e1 / taban, 3)} pu", URRA + " (30 A / 0,3 s)", "ikincil", ["Üst rölenin toprak ayarı"], "Io> Başlatma"),
        A("Görülen en büyük arıza direnci", "Rf max = E / Io> − Rn", f"{fnum(e, 0)} / {fnum(e1, 0)} − {fnum(rn, 1)}", f"{fnum(rf_max, 0)} Ω", "I = E / (Rn + Rf)", "resmi", ["Görülmesi istenen arıza direnci"]),
        A("Süre", "t = t(üst) − Δt", f"{fnum(ref_t, 2)} − {fnum(dt, 2)}", f"{fnum(max(0.04, ref_t - dt), 2)} s", URRA, "ikincil", ["Üst rölenin toprak ayarı"], "Io> Çalışma süresi"),
    ]
    ayarlar = [
        S("Io girişi", "Io1" if not hes else "IoHes", "Io1 / Io2 / IoHes", "Toroid varsa ölçülen giriş", P3U + " böl. 5.21"),
        S("Io> › Başlatma", f"{fnum(o_e1 / taban, 3)} pu (şu an {fnum(num(p, 'io1', 0.6), 3)})", "0,005 … 8,00 pu; ekrandaki örnek 0,050 pu", f"= {fa(o_e1, 0)} primer", P3U + " Çizelge 68"),
        S("Io> › Gecikme / Çalışma süresi", f"SZ · {fnum(t1, 2)} s", "0,04 … 300 s; ekrandaki örnek 1,00 s", "Üst rölenin süresinden Δt kısa", P3U + " Çizelge 68"),
        S("Io> › Kesinti süresi", "0,00 s", "0 … 300 s", "Aralıklı arızada sayacın sıfırlanmasını geciktirir (ağaç dalı, yalıtım atlaması)", P3U + " böl. 5.21"),
        S("Io>> › Başlatma · süre", f"{fnum(num(p, 'io2', 6.0), 2)} pu · {fnum(t2, 2)} s", "0,01 … 8,00 pu; ekrandaki örnek 0,10 pu / 1,00 s", "Büyük akımlı (katı) arızada hızlı açma", P3U + " Çizelge 69"),
        S("Io>> › Arızalı faz tesp.", "Açık", "Açık / Kapalı", "Açma anındaki faz akımlarını arıza öncesiyle karşılaştırıp arızalı fazı (L1-N, L2-N …) olay kaydına yazar; radyal şebeke içindir", P3U + " böl. 5.21.1"),
        S("Io>> › Ağ tipi · Şebeke topraklaması", "Rez", "Rez / Kap", "Rez: doğrudan, empedans ve rezonans topraklı şebeke; Kap: yalnız yalıtılmış şebeke. Korumayı etkilemez, yalnız arızalı faz tespitini", P3U + " böl. 5.21.1"),
    ]
    test = kademe_test("Io>", o_e1 / taban, "pu (≈ A sekonder, 1 A girişte)", t1, tol="±%2 ya da anma değerinin ±%0,3'ü", tol_t="±%1 ya da ±25 ms", oran=0.95, n=3) + [
        T("Io>> — başlatma ve süre", f"{fnum(num(p, 'io2', 6.0), 2)} pu'ya basamak", f"Açma {fnum(t2, 2)} s", "±%1 ya da ±25 ms"),
        T("Bu sayfadaki arıza", f"{fnum(i_olc / taban, 3)} pu", ("AÇAR " + fnum(t_ac, 2) + " s") if acar else "AÇMAZ", "şu anki ayarlarla"),
    ]
    rs = [0, 5, 10, 20, 50, 100, 200, 300, 500, 700, 1000, 1500, 2000, 3000, 5000]
    g = {"baslik": "Arıza direncine göre toprak arıza akımı ve eşikler", "x_ad": "Arıza direnci (Ω)", "y_ad": "Artık akım (A)", "logy": True,
         "seriler": [{"ad": "arızalı fiderin akımı", "renk": "#dc2626", "pts": [[r, akim(r)] for r in rs]}, {"ad": "sağlam fiderin akımı (kapasitif)", "renk": "#64748b", "kesik": True, "pts": [[r, max(ic * rn / (rn + r), 0.01)] for r in rs]}],
         "yatay": [{"y": e1, "etiket": f"Io> {fa(e1, 0)}", "renk": "#1a4d8f"}, {"y": e2, "etiket": f"Io>> {fa(e2, 0)}", "renk": "#7c3aed"}], "isaretler": [{"x": rf_max, "etiket": f"sınır {fnum(rf_max, 0)} Ω"}] if 0 < rf_max < 5000 else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["50n-51n"],
        "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            f"Dirençle topraklı şebekede toprak arıza akımını nötr direnci sınırlar: katı arızada {fa(akim(0), 0)}. Arıza yerinde direnç varsa akım düşer: I = E / (Rn + Rf).",
            "Eşik ne kadar küçükse o kadar dirençli arıza görülür. Ama iki alt sınır vardır.",
            f"Birincisi fiderin kendi kapasitif akımıdır ({fa(ic)}): başka bir fiderde arıza olduğunda bu akım rölemizden geçer. Yönsüz kademe yönü bilmediği için eşik bunun 1,5 katının üstünde olmalıdır.",
            "İkincisi ölçme hatasıdır: toprak akımı üç faz akım trafosunun toplamından hesaplanıyorsa, trafoların oran farkı yük altında sahte artık akım üretir. Toroidde bu sorun yoktur.",
            "Radyal şebekede toprak arıza akımı her noktada hemen hemen aynıdır; rölelerin sırasını akım değil zaman belirler: en uçtaki en hızlı.",
        ],
        "dersler": [
            "Io ayarı «pu»dur; tabanı toprak akımı girişinin primeridir. 50 A'lik toroidde 0,60 pu = 30 A.",
            "Kablo uzadıkça kapasitif akım büyür; yönsüz kademenin alt sınırı yükselir. Pencere kapanınca 67N'ye geçilir.",
            "Toroidin içinden kablo ekranının topraklama iletkeni geri geçirilmemişse ölçülen akım yanlıştır (bkz. topraklama laboratuvarı › toroid).",
            "Faz toplamıyla (IoHes) duyarlı toprak koruması yapılmaz.",
        ],
        "tablolar": [{"baslik": "Arıza direncine göre", "cols": ["Rf", "Arıza akımı", "Vo", "Io> başlar mı", "Io>> başlar mı"], "rows": [
            [f"{r} Ω", fa(akim(r), 0), f"%{fnum(rn / (rn + r) * 100, 1)}", "evet" if akim(r) >= e1 else "hayır", "evet" if akim(r) >= e2 else "hayır"] for r in (0, 20, 100, 300, 600, 1000, 2000)]}],
    }
