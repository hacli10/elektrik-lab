"""Akım trafosu mıknatıslanma (V–I) testi: eğri nasıl çıkar, diz noktası nasıl bulunur, kusurlar eğride nasıl görünür ve eğriden koruma için ne okunur.

Diz noktası tanımı (TS EN 61869-2, PX sınıfı): uygulanan gerilim %10 artırıldığında mıknatıslanma akımının %50 arttığı nokta — asıl metinden teyit
edilmedi (dogrulanacak). Koruma için gereken diz gerilimi: P3U/en M/J006 böl. 5.1.1 Çizelge 41 (PX sınıfı: Vk/(Rct + Rw) > 30 × Ins) ve böl. 5.1.4
Denklem 5 (doyma akımı Isat = Vk/(Rct + Rw) × Inp/Ins). Primer enjeksiyonla oran ve polarite: Elektrik Tesisleri Kabul Yön. m.28-D-6c.
Eğri modeli öğretim amaçlıdır: diz altında V ∝ I^0,9, diz üstünde V ∝ I^0,06; kusurların eğriye etkisi nitelikseldir (tahmini)."""
from __future__ import annotations

import math

from .ortak import A, C, Cizim, G, K, KABUL, P3U, S, T, ctl, fnum, num, opt

ID = "at_vi"
BASLIK = "AT mıknatıslanma (V–I) testi"
IKON = "📉"
GIRIS = ("Akım trafosunun sekonderinden gerilim uygulayıp çektiği akımı ölçmek, çekirdeğin sağlığını ve korumaya yetip yetmediğini gösterir. Bu sayfada eğrinin nasıl "
         "çıktığını, diz noktasının nasıl bulunduğunu ve sarımlar arası kısa devre, kalıcı mıknatıslık ya da yanlış çekirdek gibi kusurların eğriyi nasıl "
         "değiştirdiğini görürsünüz.")
KUSUR = {"yok": "Sağlam", "sarim": "Sarımlar arası kısa devre", "kalici": "Kalıcı mıknatıslık (mıknatıslığı giderilmemiş)", "olcme": "Yanlış çekirdek: ölçme çekirdeği (FS5)", "acik": "Primer devresi kapalı kalmış (kısa devre / topraklı)"}

KONTROLLER = [
    ctl("kusur", "Akım trafosunun durumu", "sec", "yok", secenek=opt(*KUSUR.items())),
    ctl("ct_p", "Primer anma akımı", "sayi", 200, min=5, max=4000, adim=5, birim="A"),
    ctl("ins", "Sekonder anma akımı", "sec", 5, secenek=opt((1, "1 A"), (5, "5 A"))),
    ctl("vk", "Etiketteki / fabrika raporundaki diz gerilimi", "sayi", 150, min=10, max=2000, adim=5, birim="V"),
    ctl("ie", "Diz noktasında mıknatıslanma akımı", "sayi", 100, min=5, max=1000, adim=5, birim="mA"),
    ctl("rct", "Sekonder sargı direnci Rct", "sayi", 0.3, min=0.05, max=15, adim=0.05, birim="Ω"),
    ctl("rw", "Kablo + röle direnci Rw", "sayi", 0.45, min=0.01, max=10, adim=0.01, birim="Ω"),
    ctl("ik", "Tesisteki en büyük arıza akımı", "sayi", 4000, min=100, max=40000, adim=100, birim="A"),
    ctl("i_ayar", "Röle › I>> ayarı (primer)", "sayi", 2000, min=50, max=30000, adim=50, birim="A"),
]


def egri(v: float, vk: float, ie_k: float, kusur: str) -> float:
    """Uygulanan gerilimde (V) çekilen mıknatıslanma akımı (A)."""
    if kusur == "olcme":
        vk = vk * 0.18                                   # ölçme çekirdeği erken doyar (küçük kesit)
    if kusur == "kalici":
        vk_e = vk
        i = ie_k * (v / vk_e) ** (1 / 0.9) if v <= vk_e else ie_k * (v / vk_e) ** (1 / 0.06)
        return i * (1.6 if v < 0.6 * vk else 1.0)       # düşük gerilimlerde eğri sağa kayık; gerilim yükselince toparlanır
    if kusur == "acik":
        return max(v / 0.4, 1e-6)                        # primer kapalıysa sekonderden bakınca kısa devre görünür: doğrusal, çok büyük akım
    i = ie_k * (v / vk) ** (1 / 0.9) if v <= vk else ie_k * (v / vk) ** (1 / 0.06)
    if kusur == "sarim":
        i += v / (vk / (ie_k * 12))                      # kısa devre sarımlar gerilimle orantılı ek akım çeker
    return i


def diz(vk: float, ie_k: float, kusur: str) -> tuple[float, float]:
    """Ölçülen eğriden diz noktası: gerilim %10 artınca akımın %50 arttığı ilk nokta (V, A)."""
    v = 0.02 * vk
    while v < 3 * vk:
        if egri(1.1 * v, vk, ie_k, kusur) >= 1.5 * egri(v, vk, ie_k, kusur):
            return v, egri(v, vk, ie_k, kusur)
        v *= 1.01
    return float("nan"), float("nan")


def run(p: dict) -> dict:
    kusur = p.get("kusur") if p.get("kusur") in KUSUR else "yok"
    vk, ie_k = num(p, "vk", 150), num(p, "ie", 100) / 1000
    ins, ct_p, rct, rw = num(p, "ins", 5), num(p, "ct_p", 200), num(p, "rct", 0.3), num(p, "rw", 0.45)
    ik, i_ayar = num(p, "ik", 4000), num(p, "i_ayar", 2000)
    vd, idz = diz(vk, ie_k, kusur)
    bulundu = not math.isnan(vd)
    vd_ = vd if bulundu else 0.0
    sapma = (vd_ - vk) / vk * 100 if bulundu else -100.0
    isat = vd_ / (rct + rw) * ct_p / ins if bulundu else 0.0
    px_ok = bulundu and vd_ / (rct + rw) > 30 * ins
    isat_ok = isat > 1.5 * i_ayar
    saglam = bulundu and abs(sapma) <= 10 and kusur in ("yok",)

    c = Cizim(900, 300)
    c.kutu(30, 60, 150, 56, "Ayarlı gerilim kaynağı", "0 … 2 × Vk")
    c.hat("M180,74 H300", "L1", hot=True, w=2.2); c.hat("M180,102 H300", "N", hot=True, w=2.2)
    c.cihaz(210, 20, f"{fnum(idz * 1000 if bulundu else 0, 0)} mA", "A (seri)", True, 96); c.cihaz(210, 128, f"{fnum(vd_, 0)} V", "V (paralel)", True, 96)
    c.yazi(330, 62, "S1", "#475569", 10); c.yazi(330, 116, "S2", "#475569", 10)
    c.bobin(300, 74, 4, False, "cizgi"); c.dikdortgen(332, 62, 20, 54, "cizgi", "#e2e8f0"); c.yazi(342, 142, "çekirdek", "#64748b", 9.5, anchor="middle")
    c.hat("M372,50 V128", "L1", w=4, kesik=kusur != "acik"); c.yazi(392, 46, "P1", "#475569", 10); c.yazi(392, 136, "P2", "#475569", 10)
    c.yazi(372, 164, "primer açık" if kusur != "acik" else "primer KAPALI (hata)", "#15803d" if kusur != "acik" else "#b91c1c", 10.5, kalin=True, anchor="middle")
    x0 = 470
    c.yazi(x0, 44, KUSUR[kusur], "#1e293b", 13, kalin=True)
    c.yazi(x0, 72, (f"Ölçülen diz noktası {fnum(vd_, 0)} V · {fnum(idz * 1000, 0)} mA" if bulundu else "Diz noktası bulunamadı: eğri doğrusal"), "#1a4d8f" if bulundu else "#b91c1c", 12.5, kalin=True)
    c.yazi(x0, 94, f"Rapor değeri {fnum(vk, 0)} V → sapma %{fnum(sapma, 0)}" if bulundu else "Primer devresi açılıp test yinelenir", "#15803d" if abs(sapma) <= 10 else "#b91c1c", 12)
    c.yazi(x0, 124, f"Doyma akımı (bu yükle) {fnum(isat, 0)} A primer = {fnum(isat / ct_p, 1)} ×In", "#334155", 11.5)
    c.yazi(x0, 144, f"Vk/(Rct + Rw) = {fnum(vd_ / (rct + rw), 0)} A ; koşul > {fnum(30 * ins, 0)} A", "#15803d" if px_ok else "#b91c1c", 11.5)
    c.yazi(x0, 174, {"yok": "Eğri rapordakiyle örtüşüyor.", "sarim": "Her gerilimde fazladan akım: diz yuvarlak ve aşağıda.", "kalici": "Düşük gerilimlerde eğri kayık; yüksek gerilimde toparlanır.",
                     "olcme": "Diz çok erken: bu çekirdek ölçme çekirdeği.", "acik": "Akım gerilimle doğrusal ve çok büyük: çekirdek mıknatıslanmıyor."}[kusur], "#475569", 11.5)
    c.yazi(x0, 204, "Test sonunda gerilim yavaşça sıfıra indirilir (mıknatıslık giderme).", "#64748b", 11)
    c.yazi(x0, 222, "1 A sekonderli trafoda diz gerilimi yüksektir: uçlarda kilovoltlar olabilir.", "#b45309", 11)

    ozet = [
        K("Ölçülen diz gerilimi", f"{fnum(vd_, 0)} V" if bulundu else "yok", "ok" if saglam else "bad", f"rapor {fnum(vk, 0)} V · sapma %{fnum(sapma, 0)}" if bulundu else "eğri doğrusal"),
        K("Dizdeki mıknatıslanma akımı", f"{fnum(idz * 1000, 0)} mA" if bulundu else "—", "info", f"rapor {fnum(ie_k * 1000, 0)} mA"),
        K("Doyma akımı", f"{fnum(isat / ct_p, 1)} ×In", "ok" if isat_ok else "bad", f"{fnum(isat, 0)} A primer · ayarın {fnum(isat / max(i_ayar, 1e-9), 1)} katı"),
        K("PX koşulu", "sağlanıyor" if px_ok else "sağlanmıyor", "ok" if px_ok else "bad", f"Vk/(Rct + Rw) = {fnum(vd_ / (rct + rw), 0)} A > {fnum(30 * ins, 0)} A"),
        K("Değerlendirme", "sağlam" if saglam else "kusurlu / uygunsuz", "ok" if saglam else "bad", KUSUR[kusur]),
    ]
    kontroller = [
        C("Eğri fabrika raporuyla örtüşüyor mu?", (f"diz {fnum(vd_, 0)} V; rapor {fnum(vk, 0)} V (%{fnum(sapma, 0)})" if bulundu else "diz noktası yok"), "sapma ±%10 içinde; eğrinin biçimi aynı", saglam,
          "Karşılaştırma aynı trafonun önceki ya da fabrika eğrisiyle ve öbür fazlardaki eş trafolarla yapılır; kabul sınırı uygulamaya göre değişir", "ikincil"),
        C("Diz gerilimi korumaya yetiyor mu?", f"Vk/(Rct + Rw) = {fnum(vd_ / (rct + rw), 0)} A", f"> 30 × Ins = {fnum(30 * ins, 0)} A", px_ok,
          "Ayarlar bilinmiyorsa PX sınıfı için Vk/(Rct + Rw) > 30 × Ins — " + P3U + " Çizelge 41", "resmi"),
        C("Doyma akımı ani kademe için yeterli mi?", f"Isat = Vk/(Rct + Rw) × Inp/Ins = {fnum(isat, 0)} A", f"> 1,5 × I>> = {fnum(1.5 * i_ayar, 0)} A", isat_ok,
          P3U + " Denklem 5 ve Çizelge 40", "resmi"),
        C("En büyük arıza akımında doyuyor mu?", f"arıza {fnum(ik, 0)} A; doyma {fnum(isat, 0)} A", "bilgi (simetrik akım için)", None,
          "Doğru akım bileşeniyle geçici doyma bu değerin çok altında başlar — bkz. Akım trafosu doyması sayfası", "hesap"),
    ]
    girdiler = [
        G("Fabrika test raporu / önceki eğri", f"Vk {fnum(vk, 0)} V · Ie {fnum(ie_k * 1000, 0)} mA", "Akım trafosu test sertifikası; önceki bakım kayıtları", "Tek başına bir eğri az şey söyler: karşılaştırılacak bir başvuru gerekir", "sapma yüzdesi"),
        G("Sekonder sargı direnci ve bağlı yük", f"Rct {fnum(rct, 2)} Ω · Rw {fnum(rw, 2)} Ω", "Sargı direnci ölçümü; kablo ve röle", "Diz geriliminin ne kadar akıma karşılık geldiğini belirler", "Isat = Vk/(Rct + Rw) × Inp/Ins"),
        G("Hangi çekirdeğin hangi uçlara çıktığı", "1S1–1S2 ölçme, 2S1–2S2 koruma gibi", "Etiket; bağlantı şeması", "Ölçme çekirdeği koruma devresine bağlanırsa arızada hemen doyar", "eğriden anlaşılır"),
        G("Güvenlik koşulları", "primer açık ve topraksız; öbür sekonderler kısa devre değil", "Çalışma izni; test yöntemi", "Primer kapalıysa çekirdek mıknatıslanmaz; test geriliminde uçlar tehlikelidir", "testten önce denetim"),
    ]
    adimlar = [
        A("Eğrinin çıkarılması", "sekonderden gerilim adım adım artırılır; her adımda akım okunur", "primer açık", "V–I noktaları (log–log)", "mıknatıslanma deneyi", "hesap", ["Güvenlik koşulları"]),
        A("Diz noktası", "V %10 artınca I %50 artan nokta", "ölçülen eğriden", f"{fnum(vd_, 0)} V, {fnum(idz * 1000, 0)} mA" if bulundu else "bulunamadı", "TS EN 61869-2 (PX sınıfı tanımı)", "dogrulanacak"),
        A("Başvuruyla karşılaştırma", "(ölçülen − rapor) / rapor", f"({fnum(vd_, 0)} − {fnum(vk, 0)}) / {fnum(vk, 0)}", f"%{fnum(sapma, 0)}", "bakım uygulaması", "ikincil", ["Fabrika test raporu / önceki eğri"]),
        A("Doyma akımı", "Isat = Vk / (Rct + Rw) × Inp / Ins", f"{fnum(vd_, 0)} / ({fnum(rct, 2)} + {fnum(rw, 2)}) × {fnum(ct_p, 0)}/{ins:g}", f"{fnum(isat, 0)} A", P3U + " Denklem 5", "resmi", ["Sekonder sargı direnci ve bağlı yük"], "I>> koşulu"),
    ]
    ayarlar = [
        S("Akım trafosu koşulu (ayarlar bilinmiyorsa)", f"Vk > 30 × Ins × (Rct + Rw) = {fnum(30 * ins * (rct + rw), 0)} V", "1 A: Vk > 30·(Rct + Rw) ; 5 A: Vk > 150·(Rct + Rw)", "PX sınıfı için en küçük diz gerilimi", P3U + " Çizelge 41"),
        S("I>> ayarı ile ilişki", f"Isat {fnum(isat, 0)} A > 1,5 × {fnum(i_ayar, 0)} A", "—", "Sabit zamanlı kademe için doyma koşulu", P3U + " Çizelge 40"),
    ]
    test = [
        T("Mıknatıslanma eğrisi", f"S1–S2'ye 0 → {fnum(1.2 * vk, 0)} V, 10–15 adımda", f"Diz {fnum(vk, 0)} V dolayında; adım başına akım raporla örtüşür", "primer açık; sonunda gerilim yavaşça sıfıra"),
        T("Sargı direnci", "Doğru akımla S1–S2 direnci", f"≈ {fnum(rct, 2)} Ω (sıcaklığa göre düzeltilir)", "ölçümden sonra mıknatıslık giderilir"),
        T("Oran ve polarite", "Primerden akım geçirilir (primer enjeksiyon)", "Sekonder akım oranla uyumlu; P1→P2 akımında S1'den çıkış", KABUL),
        T("Sekonder devre yükü", "Röle uçlarından akım basılıp gerilim ölçülür", f"≈ {fnum(rw, 2)} Ω", "hesaplanan Rw ile karşılaştır"),
    ]
    vs = [vk * 0.03 * (1.18 ** j) for j in range(0, 27)]
    g = {"baslik": "Mıknatıslanma eğrisi (log–log)", "x_ad": "Mıknatıslanma akımı (mA)", "y_ad": "Uygulanan gerilim (V)", "logx": True, "logy": True,
         "seriler": [{"ad": "rapordaki (sağlam) eğri", "renk": "#94a3b8", "kesik": True, "pts": [[round(egri(v, vk, ie_k, "yok") * 1000, 3), round(v, 2)] for v in vs]},
                     {"ad": "ölçülen", "renk": "#dc2626", "nokta": True, "r": 3.2, "pts": [[round(egri(v, vk, ie_k, kusur) * 1000, 3), round(v, 2)] for v in vs if egri(v, vk, ie_k, kusur) * 1000 < 1e6]}],
         "yatay": [{"y": vd_, "etiket": f"ölçülen diz {fnum(vd_, 0)} V", "renk": "#1a4d8f"}] if bulundu else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": [], "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Akım trafosu ters yönden de bir trafodur: sekonderine gerilim uygulanırsa çekirdek mıknatıslanır ve küçük bir akım çeker. Primer açıkken bu akım yalnız çekirdeği mıknatıslamaya gider.",
            "Gerilim artırıldıkça akım önce gerilimle orantılı artar: çekirdek doğrusal bölgededir. Bir noktadan sonra küçük bir gerilim artışı büyük akım ister: çekirdek doymaya başlamıştır. Bu dönüm noktası diz noktasıdır.",
            "Diz gerilimi, akım trafosunun arıza anında üretebileceği en büyük gerilimdir. Bunu sekonder devrenin direncine bölerseniz, trafonun doğru aktarabildiği en büyük akımı bulursunuz.",
            "Sarımlar arası kısa devre, çekirdeğin üzerinde kısa devre edilmiş bir sargı demektir: her gerilimde fazladan akım çeker, eğri sağa kayar ve diz yuvarlaklaşır.",
            "Çekirdekte kalıcı mıknatıslık varsa eğrinin alt bölümü kayıktır; gerilim dizin üstüne çıkarılıp yavaşça indirildiğinde düzelir. Test bu yüzden hep yavaş indirmeyle bitirilir.",
            "Ölçme çekirdeği bilerek küçük yapılır: arızada doyup ölçü aletlerini korusun diye. Koruma devresine yanlışlıkla bağlanırsa röle arıza akımını göremez; eğride diz noktası beklenenin beşte biri gibi çıkar.",
        ],
        "dersler": [
            "V–I eğrisi tek başına değil, rapordaki eğriyle ve öbür fazlardaki eş trafolarla karşılaştırılarak okunur.",
            "Diz gerilimi ÷ sekonder devre direnci = trafonun doğru aktarabildiği akım. Etiketteki sınıf bunun kısaltmasıdır.",
            "Test sırasında primer açık olmalı; kapalıysa eğri dümdüz çıkar ve trafo «bozuk» sanılır.",
            "Doğru akımla yapılan her ölçümden sonra mıknatıslık giderilir; yoksa trafo ilk arızada erken doyar.",
        ],
        "tablolar": [{"baslik": "Kusurlar eğride nasıl görünür", "cols": ["Durum", "Eğrinin biçimi", "Diz gerilimi", "Ne yapılır"], "rows": [
            ["Sağlam", "rapordakiyle örtüşür", "aynı", "kayda geçirilir"],
            ["Sarımlar arası kısa devre", "her gerilimde fazla akım, yuvarlak diz", "düşük", "trafo değiştirilir"],
            ["Kalıcı mıknatıslık", "alt bölüm kayık", "aynı", "mıknatıslık giderilip yinelenir"],
            ["Ölçme çekirdeği", "çok erken doyma", "çok düşük", "bağlantı düzeltilir (koruma çekirdeği)"],
            ["Primer kapalı", "doğrusal, çok büyük akım", "yok", "primer açılıp yinelenir"],
        ]}],
    }
