"""Kısa devre: OG barasından AG hat sonuna dört noktada, dört arıza tipinde akımın büyüklüğü, tepe değeri ve dalga biçimi.

Yöntem: eşdeğer gerilim kaynağı (TS EN 60909-0): Ik″ = c·Un / (√3·|Z1|); tepe akım ip = κ·√2·Ik″, κ = 1,02 + 0,98·e^(−3R/X); iki fazlı = (√3/2)·Ik″;
faz–toprak = √3·c·Un / |2·Z1 + Z0|. Gerilim katsayısı c: OG'de en büyük 1,10 / en küçük 1,00; AG'de 1,10 / 0,95. Motor katkısı: kilitli rotor akımı
5 × anma akımı, κ = 1,3 (AG motor grupları). Standardın madde ve çizelgeleri asıl metinden teyit edilmedi (dogrulanacak). Hat ve kablo birim değerleri
tipik katalog değerleridir; sıfır bileşen empedansları (Z0 ≈ 3·Z1 hat, X0 ≈ 3·X1 AG kablosu) kabuldür (tahmini). Trafo düzeltme katsayısı KT uygulanmadı.
Akım trafosu doyma koşulu: P3U/en M/J006 Çizelge 40."""
from __future__ import annotations

import math

from . import dalga as D
from .ortak import A, C, Cizim, G, K, P3U, S, S3, T, URRA, ariza, ctl, fnum, num, opt

ID = "kisa_devre"
BASLIK = "Kısa devre (OG ve AG)"
IKON = "💥"
GIRIS = ("Aynı tesiste kısa devre akımı her noktada başka bir şeydir: OG barasında birkaç kiloamper ve uzun süren doğru akım bileşeni, trafonun AG çıkışında "
         "onlarca kiloamper, uzun bir AG kablosunun sonunda birkaç yüz amper. Arıza yerini ve tipini seçin; akımın büyüklüğünü, tepe değerini, dalga biçimini "
         "ve donanımın buna dayanıp dayanmadığını görün.")

IEC = "TS EN 60909-0 (kısa devre akımlarının hesabı)"
YER = {"og_bara": "OG barası", "og_son": "OG hattının sonu (trafo primeri)", "ag_bara": "AG ana barası (trafo çıkışı)", "ag_son": "AG hattının sonu"}
TIP = {"3f": "Üç fazlı", "2f": "İki fazlı", "1f": "Faz–toprak", "2ft": "İki faz–toprak"}
# OG hat türü: ad, r (Ω/km, işletme sıcaklığında), x (Ω/km)
HAT = {"k95": ("XLPE kablo 3×(1×95) mm² Cu", 0.247, 0.130), "k240": ("XLPE kablo 3×(1×240) mm² Cu", 0.098, 0.110), "h477": ("Havai hat 477 MCM", 0.120, 0.350), "h30": ("Havai hat 3/0 AWG", 0.340, 0.380)}
RHO20 = 1 / 54.0        # Ω·mm²/m — bakır, 20 °C
X_AG = 0.08e-3          # Ω/m — AG kablosunun reaktansı (tipik)
ICM_N = [(6, 1.5), (10, 1.7), (20, 2.0), (50, 2.1), (1e9, 2.2)]          # Icu (kA) üst sınırı → kapama kapasitesi katsayısı n (TS EN 60947-2)

KONTROLLER = [
    ctl("yer", "Arıza yeri", "sec", "ag_bara", secenek=opt(*YER.items())),
    ctl("tip", "Arıza tipi", "sec", "3f", secenek=opt(*TIP.items())),
    ctl("un", "OG gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("sk", "OG barasında şebeke kısa devre gücü Sk″", "sayi", 350, min=20, max=2500, adim=10, birim="MVA", yardim="Dağıtım şirketinin bağlantı görüşünde yazılıdır"),
    ctl("xr", "Şebekenin X/R oranı", "sayi", 10, min=1, max=40, adim=0.5),
    ctl("rn", "OG yıldız noktası direnci", "sayi", 20, min=0, max=200, adim=1, birim="Ω", yardim="0: doğrudan topraklı. 34,5 kV'ta 20 Ω ≈ 1.000 A, 60 Ω ≈ 330 A"),
    ctl("hat", "OG hattı", "sec", "k95", secenek=opt(*[(k, v[0]) for k, v in HAT.items()])),
    ctl("l_km", "OG hattının uzunluğu", "sayi", 2.0, min=0, max=40, adim=0.1, birim="km"),
    ctl("sn", "Trafo gücü", "sec", 1600, secenek=opt(*[(v, f"{v} kVA") for v in (250, 400, 630, 1000, 1250, 1600, 2000, 2500)])),
    ctl("uk", "Trafo kısa devre gerilimi uk", "sayi", 6.0, min=3, max=10, adim=0.1, birim="%"),
    ctl("kesit", "AG hattının kesiti (bakır)", "sec", 95, secenek=opt(*[(v, f"{v} mm²") for v in (16, 25, 35, 50, 70, 95, 120, 150, 185, 240)])),
    ctl("l_m", "AG hattının uzunluğu", "sayi", 60, min=1, max=400, adim=1, birim="m"),
    ctl("motor", "AG barasındaki motorların toplam gücü", "sayi", 200, min=0, max=1500, adim=10, birim="kW"),
    ctl("alfa", "Arıza anında gerilimin açısı", "sayi", 0, min=0, max=180, adim=5, birim="°"),
    ctl("ik_og", "OG hücresinin kısa süreli dayanım akımı", "sec", 16, secenek=opt((12.5, "12,5 kA"), (16, "16 kA"), (20, "20 kA"), (25, "25 kA"))),
    ctl("icu", "AG ana şalterinin kesme kapasitesi Icu", "sec", 50, secenek=opt(*[(v, f"{v} kA") for v in (25, 36, 50, 65, 85, 100)])),
    ctl("in_cb", "AG hat şalterinin anma akımı", "sayi", 160, min=16, max=1600, adim=1, birim="A"),
    ctl("im", "AG hat şalterinin ani (manyetik) ayarı", "sayi", 10, min=3, max=15, adim=0.5, birim="×In"),
]


def empedans(p: dict, yer: str, sicak: bool = False) -> dict:
    """Arıza yerine kadar pozitif ve sıfır bileşen empedansı (Ω, arıza yerinin gerilim düzeyinde) ve o düzeyin anma gerilimi (kV).
    sicak: en küçük kısa devre için AG kablosu kısa devre sonu sıcaklığında (PVC 160 °C: × 1,56)."""
    un, sk, xr, rn = num(p, "un", 34.5), num(p, "sk", 350), num(p, "xr", 10), num(p, "rn", 20)
    zq = 1.1 * un * un / sk                                              # şebeke: ZQ = c·Un²/Sk″
    xq = zq / math.sqrt(1 + 1 / (xr * xr)); zs = complex(xq / xr, xq)
    _, r, x = HAT.get(p.get("hat"), HAT["k95"])
    zl = complex(r, x) * num(p, "l_km", 2)
    if yer in ("og_bara", "og_son"):
        z1 = zs + (zl if yer == "og_son" else 0j)
        z0 = zs + 3 * rn + (3 * zl if yer == "og_son" else 0j)
        return {"u": un, "z1": z1, "z0": z0, "og": True}
    sn, uk = num(p, "sn", 1600), num(p, "uk", 6) / 100
    u2 = 0.4
    zt_m = uk * u2 * u2 / (sn / 1000); rt = 0.01 * u2 * u2 / (sn / 1000)        # trafo: ukr ≈ %1 (yük kaybından; tipik)
    zt = complex(rt, math.sqrt(max(zt_m * zt_m - rt * rt, 0)))
    z1 = (zs + zl) * (u2 / un) ** 2 + zt
    z0 = zt                                                               # Dyn: sıfır bileşen üçgende kapanır; şebeke tarafı görülmez
    if yer == "ag_son":
        kat = 1.56 if sicak else 1.0
        rk = RHO20 / num(p, "kesit", 95) * num(p, "l_m", 60) * kat; xk = X_AG * num(p, "l_m", 60)
        z1 += complex(rk, xk)
        z0 += complex(rk + 3 * rk, 3 * xk)                                # dönüş koruma iletkeninden (faz kesitinde): R0 = RL + 3·RPE
    return {"u": u2, "z1": z1, "z0": z0, "og": False}


def akimlar(p: dict, yer: str, kucuk: bool = False) -> dict:
    """Dört arıza tipinin başlangıç simetrik kısa devre akımı (A), X/R, κ, tepe akım, motor katkısı."""
    e = empedans(p, yer, sicak=kucuk)
    c = (1.0 if e["og"] else 0.95) if kucuk else 1.1
    E = c * e["u"] * 1000 / S3
    out = {}
    for t, kod in (("3f", "3f"), ("2f", "2f"), ("1f", "1f"), ("2ft", "2ft")):
        r = ariza(kod, E, e["z1"], e["z0"], 0j, 0j)
        out[t] = max(abs(x) for x in r["I"]); out[t + "_toprak"] = abs(3 * r["i0"])
    xr = e["z1"].imag / max(e["z1"].real, 1e-12)
    kap = D.kappa(xr)
    im = 0.0
    if yer == "ag_bara" and not kucuk:
        im = 5 * num(p, "motor", 200) * 1000 / (S3 * 400 * 0.8)             # ΣIrM = P / (√3·U·η·cosφ), η·cosφ ≈ 0,8; kilitli rotor akımı 5 × IrM
    out.update(xr=xr, kappa=kap, ip=kap * D.KOK2 * out["3f"] + 1.3 * D.KOK2 * im, motor=im, c=c, e=e, tau=D.tau(xr))
    return out


def run(p: dict) -> dict:
    yer = p.get("yer") if p.get("yer") in YER else "ag_bara"
    tip = p.get("tip") if p.get("tip") in TIP else "3f"
    a = akimlar(p, yer); og = a["e"]["og"]
    ik = a[tip] + (a["motor"] if tip == "3f" else 0.0)
    ik3 = a["3f"] + a["motor"]
    son_k = akimlar(p, "ag_son", kucuk=True)
    ik_min = son_k["1f"]
    in_cb, im = num(p, "in_cb", 160), num(p, "im", 10)
    ik_og, icu = num(p, "ik_og", 16), num(p, "icu", 50)
    n_icm = next(n for lim, n in ICM_N if icu <= lim)
    tumu = {y: akimlar(p, y) for y in YER}

    # --- şema ---
    c = Cizim(900, 310)
    y = 96
    xs = {"og_bara": 190, "og_son": 372, "ag_bara": 560, "ag_son": 800}
    c.kutu(20, y - 27, 120, 54, "Şebeke", f"Sk″ {fnum(num(p, 'sk', 350), 0)} MVA")
    for x1, x2 in ((140, 190), (190, 400), (480, 560), (560, 800)):
        sicak = x1 < xs[yer]
        c.hat(f"M{x1},{y} H{min(x2, xs[yer]) if sicak else x2}", "L1", hot=sicak, w=3)
        if sicak and x2 > xs[yer]:
            c.hat(f"M{xs[yer]},{y} H{x2}", "L1", w=3)
    c.hat(f"M190,{y - 40} V{y + 40}", "cizgi", w=5); c.yazi(190, y - 48, f"OG bara {fnum(num(p, 'un', 34.5), 1)} kV", "#475569", 10, anchor="middle")
    c.yazi(285, y - 10, f"{fnum(num(p, 'l_km', 2), 1)} km", "#64748b", 10, anchor="middle"); c.yazi(285, y + 18, HAT.get(p.get("hat"), HAT["k95"])[0].split(" 3×")[0].split(" 477")[0], "#64748b", 9.5, anchor="middle")
    c.daire(425, y, 26, "cizgi", dolgu="#fff"); c.daire(457, y, 26, "cizgi", dolgu="#fff"); c.sarim(425, y, "ucgen", "#334155", 11); c.sarim(457, y, "yildiz", "#334155", 11)
    c.yazi(441, y + 46, f"{num(p, 'sn', 1600):g} kVA · %{fnum(num(p, 'uk', 6), 1)} · Dyn11", "#475569", 10, anchor="middle")
    c.hat(f"M560,{y - 40} V{y + 40}", "cizgi", w=5); c.yazi(560, y - 48, "AG bara 0,4 kV", "#475569", 10, anchor="middle")
    c.yazi(680, y - 10, f"{fnum(num(p, 'l_m', 60), 0)} m · {num(p, 'kesit', 95):g} mm²", "#64748b", 10, anchor="middle")
    c.kutu(820, y - 22, 66, 44, "Yük", "")
    if num(p, "motor", 200) > 0:
        c.hat(f"M590,{y} V{y + 62}", "L1", hot=yer == "ag_bara", w=2, hot_renk="uyari"); c.daire(590, y + 78, 15, "cizgi", dolgu="#fff"); c.yazi(590, y + 82, "M", "#334155", 11, kalin=True, anchor="middle")
        c.yazi(612, y + 82, f"{fnum(num(p, 'motor', 200), 0)} kW" + (f" → {fnum(a['motor'] / 1000, 1)} kA katkı" if yer == "ag_bara" else ""), "#b45309" if yer == "ag_bara" else "#64748b", 10)
    xf = xs[yer]
    c.simsek(xf - 8, y - 10, 1.2); c.hat(f"M{xf},{y} V{y + 50}", "ariza", hot=True, w=2); c.toprak(xf, y + 52, "ariza")
    for yy, x in xs.items():
        t = tumu[yy]
        c.yazi(x, 216, f"{fnum((t['3f'] + t['motor']) / 1000, 1)} kA", "#b91c1c" if yy == yer else "#64748b", 12 if yy == yer else 10.5, kalin=yy == yer, anchor="middle")
        c.yazi(x, 232, f"X/R {fnum(t['xr'], 1)}", "#b91c1c" if yy == yer else "#94a3b8", 10, anchor="middle")
    c.yazi(20, 216, "Üç fazlı Ik″:", "#475569", 10.5); c.yazi(20, 232, "ve X/R", "#94a3b8", 10)
    c.yazi(20, 268, f"{YER[yer]} — {TIP[tip].lower()}: Ik″ = {fnum(ik / 1000, 2)} kA · tepe ip = {fnum(a['ip'] / 1000, 1)} kA (κ = {fnum(a['kappa'], 2)}) · doğru akım bileşeni τ = {fnum(a['tau'] * 1000, 0)} ms", "#1e293b", 12, kalin=True)
    c.yazi(20, 290, f"AG hat sonunda en küçük faz–toprak akımı {fnum(ik_min, 0)} A — hat şalterinin ani eşiği {fnum(in_cb * im, 0)} A", "#15803d" if ik_min >= in_cb * im else "#b91c1c", 11.5)

    ozet = [
        K("Başlangıç kısa devre akımı Ik″", f"{fnum(ik / 1000, 2)} kA", "info", f"{YER[yer]} · {TIP[tip].lower()}" + (f" · motor katkısı {fnum(a['motor'] / 1000, 1)} kA dahil" if a["motor"] and tip == "3f" else "")),
        K("Tepe akım ip", f"{fnum(a['ip'] / 1000, 1)} kA", "info", f"κ = {fnum(a['kappa'], 2)} · en büyük anlık değer (üç fazlı)"),
        K("X/R ve zaman sabiti", f"{fnum(a['xr'], 1)}", "info", f"doğru akım bileşeni τ = {fnum(a['tau'] * 1000, 0)} ms"),
        K("Toprak akımı", f"{fnum(a[tip + '_toprak'] / (1000 if a[tip + '_toprak'] > 2000 else 1), 2 if a[tip + '_toprak'] > 2000 else 0)} {'kA' if a[tip + '_toprak'] > 2000 else 'A'}", "info",
          "bu arıza tipinde toprak üzerinden dönen akım" if tip in ("1f", "2ft") else "bu arıza tipinde toprak akımı yok"),
        K("AG hat sonu en küçük akım", f"{fnum(ik_min, 0)} A", "ok" if ik_min >= in_cb * im else "bad", f"faz–toprak, sıcak iletken · şalterin ani eşiği {fnum(in_cb * im, 0)} A"),
    ]
    og3, ag3 = tumu["og_bara"], tumu["ag_bara"]
    kontroller = [
        C("OG hücresi kısa devreye dayanıyor mu?", f"OG barasında Ik″ = {fnum(og3['3f'] / 1000, 2)} kA", f"≤ {fnum(ik_og, 1)} kA (etiket: kısa süreli dayanım akımı)", og3["3f"] / 1000 <= ik_og,
          "Hücrenin kısa süreli dayanım akımı (Ik, 1 s) hesaplanan başlangıç kısa devre akımından küçük olamaz — " + IEC + "; TS EN 62271-1", "dogrulanacak"),
        C("OG hücresi tepe akıma dayanıyor mu?", f"ip = {fnum(og3['ip'] / 1000, 1)} kA (κ = {fnum(og3['kappa'], 2)})", f"≤ 2,5 × {fnum(ik_og, 1)} = {fnum(2.5 * ik_og, 1)} kA", og3["ip"] / 1000 <= 2.5 * ik_og,
          "Tepe dayanım akımı 50 Hz'te kısa süreli dayanım akımının 2,5 katıdır — TS EN 62271-1", "dogrulanacak"),
        C("AG ana şalteri kesebiliyor mu?", f"AG barasında Ik″ = {fnum((ag3['3f'] + ag3['motor']) / 1000, 1)} kA", f"Icu ≥ Ik″ → {fnum(icu, 0)} kA", (ag3["3f"] + ag3["motor"]) / 1000 <= icu,
          "Kesme kapasitesi takıldığı yerdeki beklenen kısa devre akımından küçük olamaz — TS EN 60947-2; TS HD 60364-4-43", "dogrulanacak"),
        C("AG ana şalteri arıza üzerine kapatılabilir mi?", f"ip = {fnum(ag3['ip'] / 1000, 1)} kA", f"Icm = {fnum(n_icm, 1)} × Icu = {fnum(n_icm * icu, 0)} kA (tepe)", ag3["ip"] / 1000 <= n_icm * icu,
          "Kapama kapasitesi Icm = n·Icu; n, Icu büyüdükçe 1,5'ten 2,2'ye çıkar — TS EN 60947-2 Çizelge 2", "dogrulanacak"),
        C("AG hat sonundaki en küçük arıza şalteri ani açtırıyor mu?", f"Ik(en küçük, faz–toprak) = {fnum(ik_min, 0)} A", f"≥ ani eşik {fnum(im, 1)} × {fnum(in_cb, 0)} = {fnum(in_cb * im, 0)} A", ik_min >= in_cb * im,
          "En küçük kısa devre akımı (c = 0,95, iletken kısa devre sonu sıcaklığında) koruma düzeninin açma akımından büyük olmalı — " + IEC + "; bkz. Topraklama laboratuvarı › Şebeke tipleri", "dogrulanacak"),
    ]
    e = a["e"]
    girdiler = [
        G("OG barasındaki şebeke kısa devre gücü ve X/R", f"{fnum(num(p, 'sk', 350), 0)} MVA · X/R {fnum(num(p, 'xr', 10), 1)}", "Dağıtım şirketinin bağlantı görüşü; yoksa indirici merkez trafosundan hesap", "Bütün hesabın başlangıcı: kaynak empedansı buradan çıkar", "ZQ = c·Un² / Sk″"),
        G("OG hattının türü ve uzunluğu", f"{HAT.get(p.get('hat'), HAT['k95'])[0]} · {fnum(num(p, 'l_km', 2), 1)} km", "Tek hat şeması; hat projesi", "Hat empedansı arıza akımını düşürür ve X/R oranını değiştirir", "ZL = (r + jx)·ℓ"),
        G("Trafo gücü, uk ve bağlantı grubu", f"{num(p, 'sn', 1600):g} kVA · %{fnum(num(p, 'uk', 6), 1)} · Dyn11", "Trafo etiketi", "AG tarafındaki arıza akımını sınırlayan asıl empedans; üçgen sargı sıfır bileşeni ayırır", "ZT = uk·Un² / Sn"),
        G("AG hattının kesiti ve uzunluğu", f"{num(p, 'kesit', 95):g} mm² · {fnum(num(p, 'l_m', 60), 0)} m", "AG tek hat şeması; kablo listesi", "Hat sonundaki en küçük arıza akımını belirler: koruma bu akımda da açmalı", "RL = ℓ / (54·A), sıcakken × 1,56"),
        G("AG barasındaki motorlar", f"{fnum(num(p, 'motor', 200), 0)} kW", "Yük listesi", "Dönen motorlar ilk periyotlarda arızayı besler: şalterin kapama ve kesme kapasitesine eklenir", "I″kM ≈ 5 × ΣIrM"),
    ]
    adimlar = [
        A("Şebeke empedansı", "ZQ = c·Un² / Sk″", f"1,1 × {fnum(num(p, 'un', 34.5), 1)}² / {fnum(num(p, 'sk', 350), 0)}", f"{fnum(1.1 * num(p, 'un', 34.5) ** 2 / num(p, 'sk', 350), 3)} Ω (OG düzeyinde)", IEC, "dogrulanacak", ["OG barasındaki şebeke kısa devre gücü ve X/R"]),
        A("Arıza yerine kadar toplam empedans", "Z1 = şebeke + hat" + ("" if og else " (AG'ye indirgenmiş) + trafo" + (" + AG hattı" if yer == "ag_son" else "")), "Z = R + jX",
          f"{fnum(e['z1'].real * (1 if og else 1000), 3 if og else 2)} + j{fnum(e['z1'].imag * (1 if og else 1000), 3 if og else 2)} {'Ω' if og else 'mΩ'}", "empedansların toplanması; gerilim düzeyine (U2/U1)² ile indirgeme", "hesap", ["OG hattının türü ve uzunluğu", "Trafo gücü, uk ve bağlantı grubu"]),
        A("Üç fazlı başlangıç kısa devre akımı", "Ik″ = c·Un / (√3·|Z1|)", f"1,1 × {fnum(e['u'] * 1000, 0)} / (1,732 × {fnum(abs(e['z1']) * (1 if og else 1000), 3 if og else 2)}{'' if og else ' mΩ'})", f"{fnum(a['3f'] / 1000, 2)} kA", IEC, "dogrulanacak"),
        A("Tepe akım", "ip = κ·√2·Ik″ ;  κ = 1,02 + 0,98·e^(−3R/X)", f"R/X = {fnum(1 / a['xr'], 3)} → κ = {fnum(a['kappa'], 2)}", f"{fnum(a['ip'] / 1000, 1)} kA", IEC, "dogrulanacak"),
        A("İki fazlı ve faz–toprak", "Ik2″ = (√3/2)·Ik″ ;  Ik1″ = √3·c·Un / |2·Z1 + Z0|", f"Z0 = {fnum(e['z0'].real * (1 if og else 1000), 2)} + j{fnum(e['z0'].imag * (1 if og else 1000), 2)} {'Ω' if og else 'mΩ'}",
          f"iki fazlı {fnum(a['2f'] / 1000, 2)} kA · faz–toprak {fnum(a['1f'] / (1000 if a['1f'] > 2000 else 1), 2 if a['1f'] > 2000 else 0)} {'kA' if a['1f'] > 2000 else 'A'}", IEC + "; sıfır bileşen empedansı kabuldür", "tahmini"),
        A("AG hat sonunda en küçük akım", "Ik1(min) = √3·0,95·Un / |2·Z1 + Z0| , iletken sıcak", f"R × 1,56 (PVC, 160 °C)", f"{fnum(ik_min, 0)} A", IEC, "dogrulanacak", ["AG hattının kesiti ve uzunluğu"], "ani açma eşiği"),
    ]
    ayarlar = [
        S("OG fider › I>> (ani kademe)", "≤ 0,8 × hat sonundaki en küçük iki fazlı arıza akımı; ≥ 1,2–1,3 × AG barasındaki arızanın OG'deki karşılığı", "—", "Ani kademe hat sonundaki arızayı görmeli, trafonun arkasındakini görmemeli", URRA, "ikincil"),
        S("Akım trafosu doyma koşulu", f"Isat > 1,5 × ayar (sabit zamanlı kademe)", "—", "Arıza akımı büyüdükçe akım trafosu doyar; röle akımı eksik ölçer", P3U + " Çizelge 40"),
        S("AG hat şalteri › ani (manyetik) ayar", f"{fnum(im, 1)} ×In = {fnum(in_cb * im, 0)} A", "—", "Hat sonundaki en küçük arıza akımının altında, yol alma akımının üstünde", "bu sayfadaki hesap", "hesap"),
    ]
    test = [
        T("Hızlı sağlama", "AG barası: Ik″ ≈ In(trafo) / uk", f"{fnum(num(p, 'sn', 1600) / (S3 * 0.4), 0)} A / {fnum(num(p, 'uk', 6) / 100, 3)} = {fnum(num(p, 'sn', 1600) / (S3 * 0.4) / (num(p, 'uk', 6) / 100) / 1000, 1)} kA", "şebeke empedansı sayılmazsa üst sınır"),
        T("Çevrim empedansı ölçümü", "AG hat sonunda faz–koruma iletkeni çevrimi", f"Zs ≈ {fnum(230 / max(ik_min, 1e-9) * 1000, 0)} mΩ dolayı (soğuk iletkende daha küçük)", "ölçülen değerden Ik = Uo / Zs"),
        T("Arıza kaydı", "Röle ya da kayıt cihazındaki ilk tepe değer", f"ilk tepe ≈ κ·√2·Ik″; κ = {fnum(a['kappa'], 2)}", "kapama anına bağlı: en kötü durumda bu değer"),
    ]
    N = 64
    ts = [k * 0.02 / N for k in range(5 * N + 1)]
    alfa = num(p, "alfa", 0)
    xs_ = [D.kd_akim(ik, a["xr"], alfa, t) / 1000 for t in ts]
    fi = math.atan(a["xr"])
    dc = [-math.sin(math.radians(alfa) - fi) * D.KOK2 * ik / 1000 * math.exp(-t / max(a["tau"], 1e-6)) for t in ts]
    g1 = {"baslik": f"{YER[yer]}: kısa devre akımının dalga biçimi ({TIP[tip].lower()})", "x_ad": "Zaman (ms)", "y_ad": "Akım (kA, anlık)", "zaman": True,
          "seriler": [{"ad": "kısa devre akımı", "renk": "#dc2626", "pts": D.seri([t * 1000 for t in ts], xs_, 1)}, {"ad": "doğru akım bileşeni", "renk": "#b45309", "kesik": True, "pts": D.seri([t * 1000 for t in ts], dc, 4)}],
          "yatay": [{"y": D.KOK2 * ik / 1000, "etiket": "√2·Ik″ (simetrik tepe)", "renk": "#64748b"}]}
    uzun = [1, 5, 10, 20, 40, 60, 100, 150, 200, 300, 400]
    g2 = {"baslik": "AG hattı boyunca kısa devre akımı (seçili kesit)", "x_ad": "Baradan uzaklık (m)", "y_ad": "Akım (kA)", "logy": True,
          "seriler": [{"ad": "üç fazlı Ik″ (en büyük)", "renk": "#dc2626", "pts": [[m, round(akimlar({**p, "l_m": m}, "ag_son")["3f"] / 1000, 3)] for m in uzun]},
                      {"ad": "faz–toprak (en küçük, sıcak iletken)", "renk": "#1a4d8f", "pts": [[m, round(akimlar({**p, "l_m": m}, "ag_son", kucuk=True)["1f"] / 1000, 3)] for m in uzun]}],
          "yatay": [{"y": in_cb * im / 1000, "etiket": f"şalterin ani eşiği {fnum(in_cb * im, 0)} A", "renk": "#15803d"}], "isaretler": [{"x": num(p, "l_m", 60), "etiket": "hat sonu"}]}
    birim = lambda v: f"{fnum(v / 1000, 2)} kA" if v >= 2000 else f"{fnum(v, 0)} A"      # noqa: E731
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["50-51"], "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Kısa devre akımını, arıza yerine kadar olan empedans belirler: şebeke, hat, trafo, kablo art arda eklenir. Akım, gerilimin bu toplama bölümüdür.",
            f"OG barasında empedans küçük ve hemen hemen saf reaktanstır (X/R = {fnum(tumu['og_bara']['xr'], 0)}): akım {fnum(tumu['og_bara']['3f'] / 1000, 1)} kA, doğru akım bileşeni {fnum(tumu['og_bara']['tau'] * 1000, 0)} ms zaman sabitiyle söner. Tepe akım simetrik tepenin {fnum(tumu['og_bara']['kappa'], 2)} katıdır.",
            f"Trafodan sonra gerilim {fnum(num(p, 'un', 34.5) / 0.4, 0)} kat düşer, akım o kadar büyür; ama trafonun kendi empedansı (uk) onu sınırlar: AG barasında {fnum(tumu['ag_bara']['3f'] / 1000, 1)} kA. Trafo ne kadar büyükse AG arıza akımı o kadar büyüktür.",
            f"AG kablosu dirençtir: hat sonunda akım {fnum(tumu['ag_son']['3f'] / 1000, 1)} kA'e iner, X/R {fnum(tumu['ag_son']['xr'], 1)} olur. Doğru akım bileşeni neredeyse yoktur; tepe akım simetrik tepeye yakındır.",
            "Donanım iki uçtan sınanır. En büyük akım (soğuk iletken, c = 1,10, motor katkısı dahil) kesme ve dayanım kapasitesini belirler; en küçük akım (sıcak iletken, c = 0,95, faz–toprak) korumanın açıp açmayacağını.",
            "Faz–toprak arızasında dönüş yolu belirleyicidir. OG'de yıldız noktası direnci akımı birkaç yüz ampere indirir; AG'de koruma iletkeninin direnci hat direncine eklenir.",
        ],
        "dersler": [
            "AG barasında Ik″ ≈ In / uk: 1.600 kVA, %6 trafoda 38 kA. Şalter kesme kapasitesi trafo gücüyle birlikte büyür.",
            "Tepe akım baraları ve kesicinin kapama kapasitesini, etkin değer kesme kapasitesini ve ısıl dayanımı belirler.",
            "Uzun AG hattının sonunda sorun büyük değil küçük akımdır: şalterin ani eşiğinin altında kalan arıza dakikalarca sürer.",
            "Motorlar arızayı ilk periyotlarda besler: AG barasında birkaç kiloamper ekler, hat sonunda etkisi kalmaz.",
        ],
        "tablolar": [
            {"baslik": f"{YER[yer]}: dört arıza tipi", "cols": ["Arıza tipi", "Akım (en büyük faz)", "Üç fazlıya oranı", "Toprak akımı"],
             "rows": [[TIP[t], birim(a[t] + (a["motor"] if t == "3f" else 0)), f"%{fnum(a[t] / a['3f'] * 100, 0)}", birim(a[t + "_toprak"]) if a[t + "_toprak"] > 0.5 else "—"] for t in TIP],
             "not": "Motor katkısı yalnız üç fazlı arızaya ve AG barasına eklenmiştir."},
            {"baslik": "Dört noktada üç fazlı ve faz–toprak kısa devre", "cols": ["Yer", "Ik″ üç fazlı", "Faz–toprak", "X/R", "κ", "Tepe akım ip", "τ"],
             "rows": [[YER[y_], birim(t["3f"] + t["motor"]), birim(t["1f"]), fnum(t["xr"], 1), fnum(t["kappa"], 2), birim(t["ip"]).replace(" kA", " kA (tepe)"), f"{fnum(t['tau'] * 1000, 0)} ms"] for y_, t in tumu.items()],
             "not": "OG'de faz–toprak akımını yıldız noktası direnci sınırlar. Hat ve kablo değerleri tipiktir; sıfır bileşen empedansları kabuldür."},
        ],
    }
