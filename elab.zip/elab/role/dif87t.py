"""Trafo diferansiyel koruması (ANSI 87T) — PowerLogic / Easergy P3T32 «dI>» ekranındaki alanlarla: ayarların her biri hangi veriden çıkar, testte hangi nokta yakalanır.

Dayanak: P3T32 kılavuzu P3T/en M/L007 böl. 6.30 (fark akımı Id = |IW + I'W|, tutucu akım Ib = (|IW| + |I'W|) / 2 — Denklem 26–27; üçgen tarafta sargı akımı
(IL1 − IL2)/√3 — Denklem 24; sıfır akım kompanzasyonu Çizelge 93; ayarlar Çizelge 95: IStart %5–50 (varsayılan %25), eğim 1 %5–100 (%50), IBIAS2 1,00–3,00 ×In (2,00),
eğim 2 %100–200 (%150); Çizelge 96: tutucu akım 0,5 ×In'e kadar düz, 2. harmonik kilidi %5–30, 5. harmonik kilidi %20–50, çalışma < 60 ms; Çizelge 97: dI>> 5,0–40,0 ×In,
< 40 ms; 2. harmonik fark akımından hesaplanır; dI>> eğim ve harmonik kilidi içermez; AT denetimi dI> içinde), böl. 4 (faz akımlarında 1 pu = trafonun anma akımı).
Sahte fark akımının kaynakları ve dış arıza davranışı için PowerLogic P5 kılavuzu P5/EN M/02-503A. Akım modeli topraklama laboratuvarındaki diferansiyel sayfasıyla
ortaktır (elab/lab/diferansiyel.py)."""
from __future__ import annotations

import math

from ..lab import diferansiyel as L
from .ortak import A, C, EKRAN, G, K, KABUL, P3T, P5, S, S3, T, Cizim, ctl, fa, fnum, num, opt

ID = "dif87t"
BASLIK = "Trafo diferansiyel (87T)"
IKON = "⚖"
GIRIS = ("Diferansiyel röle trafoya giren akımla çıkan akımı karşılaştırır. Ayarların hepsi tek bir sorunun cevabıdır: arıza yokken bile iki taraf "
         "neden tam eşit görünmez? Kademe değiştirici, akım trafosu hatası, boşta akım, demeraj ve doyma — her biri bir ayarı belirler.")

DURUM = {"yuk": "Tam yük (kademe seçilen konumda)", "dis": "Dış arıza — AG barasında üç fazlı kısa devre", "ic": "İç arıza (koruma bölgesinde)", "inrush": "Enerjilendirme (demeraj akımı)", "asiri": "Aşırı uyarma (gerilim yüksek / frekans düşük)"}
GRUP = {"Dyn11": "Dyn11", "Dyn5": "Dyn5", "Dyn1": "Dyn1", "Yyn0": "Yyn0"}
HATA = {"yok": "Hata yok", "p1": "OG akım trafosu ters bağlı", "p2": "AG akım trafosu ters bağlı", "grup": "Rölede bağlantı grubu yanlış girilmiş", "oran": "Rölede trafo / AT verileri girilmemiş (oran eşleme yok)"}
IB1 = 0.5            # eğim 1'in başladığı tutucu akım (×In) — ekran alanı «dI> başlatma (Itut < 0,5 In)»

KONTROLLER = [
    ctl("sn_kva", "Trafo gücü", "sayi", 2000, min=250, max=40000, adim=50, birim="kVA", yardim="Etiketten"),
    ctl("u2_kv", "AG / ikinci taraf gerilimi", "sec", 0.4, secenek=opt((0.4, "0,4 kV"), (6.3, "6,3 kV"), (10.5, "10,5 kV")), yardim="OG tarafı 34,5 kV alınmıştır"),
    ctl("grup", "Bağlantı grubu", "sec", "Dyn11", secenek=opt(*GRUP.items())),
    ctl("uk", "Kısa devre gerilimi uk", "sayi", 6, min=4, max=14, adim=0.5, birim="%"),
    ctl("kademe_ar", "Kademe değiştirici aralığı (±)", "sayi", 5, min=0, max=15, adim=0.5, birim="%", yardim="Etiket: ör. ±2×2,5 % → 5"),
    ctl("ct1", "OG akım trafosu primeri", "sayi", 50, min=5, max=2000, adim=5, birim="A"),
    ctl("ct2", "AG akım trafosu primeri", "sayi", 3000, min=50, max=6000, adim=50, birim="A"),
    ctl("at_hata", "Akım trafosu hatası (her biri, arıza akımında)", "sayi", 5, min=1, max=10, adim=1, birim="%", yardim="5P sınıfı: doğruluk sınır akımında bileşik hata %5"),
    ctl("durum", "Durum", "sec", "yuk", secenek=opt(*DURUM.items())),
    ctl("kademe", "Kademe konumu (anma oranından sapma)", "sayi", 5, min=-15, max=15, adim=0.5, birim="%", goster={"durum": ["yuk", "dis"]}),
    ctl("doyma", "Dış arızada AG akım trafosunun doyması", "sayi", 0, min=0, max=80, adim=5, birim="%", goster={"durum": ["dis"]}),
    ctl("ic_pu", "İç arıza akımı (OG tarafından)", "sayi", 0.4, min=0.05, max=20, adim=0.05, birim="×In", goster={"durum": ["ic"]}),
    ctl("id_min", "Röle › dI> başlatma (Itut < 0,5 In)", "sayi", 20, min=5, max=50, adim=1, birim="%In"),
    ctl("egim1", "Röle › Eğim 1", "sayi", 50, min=5, max=100, adim=5, birim="%"),
    ctl("ib2", "Röle › Eğim 2 başlangıcı için Itut", "sayi", 2.0, min=1.0, max=3.0, adim=0.1, birim="×In"),
    ctl("egim2", "Röle › Eğim 2", "sayi", 150, min=100, max=200, adim=5, birim="%"),
    ctl("h2_blok", "Röle › dI> inrush enable (2. harmonik kilidi)", "onay", True),
    ctl("h2", "Röle › 2. harm. başlatma", "sayi", 15, min=5, max=30, adim=1, birim="%"),
    ctl("h5_blok", "Röle › dI> 5. harm. kilit etkin", "onay", True),
    ctl("h5", "Röle › 5. harm. kilit sınır", "sayi", 35, min=20, max=50, adim=1, birim="%"),
    ctl("id2", "Röle › dI>> başlatma", "sayi", 20, min=5, max=40, adim=0.5, birim="×In"),
    ctl("hata", "Devreye alma hatası", "sec", "yok", secenek=opt(*HATA.items())),
]


def esik(ib: float, p: dict) -> float:
    """P3T32 «dI>» karakteristiği: Itut < 0,5·In'de düz; sonra eğim 1; «Eğim 2 başlangıcı»ndan sonra eğim 2 (×In)."""
    d0, s1, b2, s2 = num(p, "id_min", 20) / 100, num(p, "egim1", 50) / 100, num(p, "ib2", 2.0), num(p, "egim2", 150) / 100
    if ib <= IB1:
        return d0
    if ib <= b2:
        return d0 + s1 * (ib - IB1)
    return d0 + s1 * (b2 - IB1) + s2 * (ib - b2)


def olc(p: dict) -> dict:
    """Rölenin faz başına fark ve tutucu akımı (×In) ile harmonik oranları."""
    dur = p.get("durum") if p.get("durum") in DURUM else "yuk"
    grup = p.get("grup") if p.get("grup") in GRUP else "Dyn11"
    hata = p.get("hata") if p.get("hata") in HATA else "yok"
    q = {"grup": grup, "r_grup": ({"Dyn11": "Dyn1", "Dyn1": "Dyn11", "Dyn5": "Dyn11", "Yyn0": "Dyn11"}[grup] if hata == "grup" else grup),
         "durum": {"yuk": "yuk", "dis": "dis3", "ic": "ic", "inrush": "inrush", "asiri": "yuk"}[dur], "sn_mva": num(p, "sn_kva", 2000) / 1000, "u2_kv": num(p, "u2_kv", 0.4),
         "ct1": num(p, "ct1", 50), "ct2": num(p, "ct2", 3000), "yuk_pct": 100, "uk_pct": num(p, "uk", 6), "kademe": num(p, "kademe", 5) if dur in ("yuk", "dis") else 0,
         "ic_pu": num(p, "ic_pu", 0.4), "doyma": num(p, "doyma", 0), "r_oran": hata != "oran", "p1": hata == "p1", "p2": hata == "p2", "r_i0": True,
         "id_min": 0.2, "egim1": 30, "kirilma": 2.5, "egim2": 70, "h2_blok": False, "id_yuksek": 99}
    r = L.hesap(q)
    idf, ibs, h2 = list(r["id"]), list(r["ib"]), list(r["h2"]); h5 = [0.0, 0.0, 0.0]
    if dur == "asiri":                                       # mıknatıslanma akımı büyür: tek taraftan görünür, 5. harmoniği yüksektir (tipik değerler)
        idf = [d + 0.60 for d in idf]; h5 = [0.45, 0.42, 0.47]
    thr = [esik(b, p) for b in ibs]
    ust = [d > t + 1e-9 for d, t in zip(idf, thr)]
    b2 = bool(p.get("h2_blok")) and any(h >= num(p, "h2", 15) / 100 for h in h2)
    b5 = bool(p.get("h5_blok")) and any(h >= num(p, "h5", 35) / 100 for h in h5)
    yuk = [d > num(p, "id2", 20) for d in idf]
    acar = (any(ust) and not b2 and not b5) or any(yuk)
    return {"dur": dur, "hata": hata, "id": idf, "ib": ibs, "thr": thr, "ust": ust, "h2": h2, "h5": h5, "b2": b2, "b5": b5, "yuk": yuk, "acar": acar, "i1n": r["i1n"], "i2n": r["i2n"], "r": r}


def run(p: dict) -> dict:
    m = olc(p); dur = m["dur"]
    sn = num(p, "sn_kva", 2000); u1 = 34.5; u2 = num(p, "u2_kv", 0.4); ct1, ct2 = num(p, "ct1", 50), num(p, "ct2", 3000)
    i1n, i2n = m["i1n"], m["i2n"]; uk = num(p, "uk", 6) / 100
    kad, ath = num(p, "kademe_ar", 5) / 100, num(p, "at_hata", 5) / 100
    beklenen = dur == "ic"
    k = max(range(3), key=lambda j: m["id"][j] - m["thr"][j])            # en kritik faz
    # ---- önerilen ayarlar ----
    sahte_yuk = kad + 2 * 0.01 + 0.01                                    # tam yükte: kademe + iki AT'nin oran hatası (%1) + boşta akım (%1)
    o_id = min(50, max(20, 5 * math.ceil(2 * sahte_yuk * 100 / 5)))      # 2 kat pay, 5'e yuvarla
    sahte_egim = kad + 2 * ath                                           # geçen akımla orantılı sahte fark: kademe + iki AT'nin bileşik hatası
    o_e1 = min(100, max(30, 5 * math.ceil(1.5 * sahte_egim * 100 / 5)))
    o_id2 = min(40.0, max(10.0, math.ceil(1.2 / uk)))
    ikd = 1 / uk                                                         # dış arızada geçen akım (×In)

    # ---- şema ----
    c = Cizim(900, 300)
    renk = {"p1": "ariza", "p2": "ariza"}
    c.kutu(20, 50, 100, 46, "OG şebeke", "34,5 kV"); c.kutu(780, 50, 100, 46, "AG bara", f"{fnum(u2, 1)} kV")
    c.hat("M120,73 H400", "L1", hot=dur != "asiri" or True, w=3); c.hat("M500,73 H780", "L1", hot=dur in ("yuk", "dis"), w=3)
    c.toroid(220, 73, 7, 17, renk.get(m["hata"] if m["hata"] == "p1" else "", "#1e293b")); c.yazi(220, 46, f"AT {ct1:g}/1" + (" TERS" if m["hata"] == "p1" else ""), "#b91c1c" if m["hata"] == "p1" else "#475569", 10, anchor="middle")
    c.toroid(680, 73, 7, 17, renk.get(m["hata"] if m["hata"] == "p2" else "", "#1e293b")); c.yazi(680, 46, f"AT {ct2:g}/1" + (" TERS" if m["hata"] == "p2" else ""), "#b91c1c" if m["hata"] == "p2" else "#475569", 10, anchor="middle")
    c.daire(430, 73, 30, "cizgi", dolgu="#fff"); c.daire(470, 73, 30, "cizgi", dolgu="none")
    c.sarim(430, 75, "ucgen" if p.get("grup", "Dyn11")[0] == "D" else "yildiz", r=13); c.sarim(470, 76, "yildiz", r=13)
    c.yazi(450, 13, f"{fnum(sn, 0)} kVA · {p.get('grup', 'Dyn11')} · uk %{fnum(uk * 100, 1)}", "#334155", 11, kalin=True, anchor="middle")
    c.dikdortgen(205, 20, 490, 100, "mavi", kesik=True, kw=1.2); c.yazi(210, 134, "koruma bölgesi: iki akım trafosunun arası", "#1d4ed8", 10)
    c.hat("M220,91 V190 H330", "cizgi", kesik=True, w=1.4); c.hat("M680,91 V190 H570", "cizgi", kesik=True, w=1.4)
    c.kutu(330, 162, 240, 62, "87T  dI>", ("AÇTI" if m["acar"] else "açmadı") + (" — 2. harmonik kilidi" if m["b2"] and not m["acar"] else " — 5. harmonik kilidi" if m["b5"] and not m["acar"] else ""),
           "acti" if m["acar"] else ("gecersiz" if m["acar"] != beklenen else "normal"))
    c.yazi(450, 246, f"L{k + 1}: fark Id = {fnum(m['id'][k], 2)} ×In · tutucu Itut = {fnum(m['ib'][k], 2)} ×In · eşik {fnum(m['thr'][k], 2)} ×In", "#b91c1c" if m["ust"][k] else "#334155", 12, kalin=True, anchor="middle")
    c.yazi(450, 266, f"2. harmonik %{fnum(max(m['h2']) * 100, 0)} · 5. harmonik %{fnum(max(m['h5']) * 100, 0)}", "#475569", 11, anchor="middle")
    if dur == "ic":
        c.simsek(444, 96, 1.2); c.yazi(450, 148, "iç arıza", "#b91c1c", 10.5, kalin=True, anchor="middle")
    if dur == "dis":
        c.simsek(734, 62, 1.2); c.hat("M740,73 V118", "ariza", hot=True); c.toprak(740, 120, "ariza"); c.yazi(752, 112, "dış arıza", "#b91c1c", 10.5, kalin=True)
    if dur == "inrush":
        c.yazi(540, 100, "AG açık: akım yalnız OG'den girer", "#b45309", 10.5)

    ozet = [
        K("Röle kararı", "AÇAR" if m["acar"] else "AÇMAZ", "ok" if m["acar"] == beklenen else "bad", ("doğru" if m["acar"] == beklenen else "YANLIŞ") + " — " + ("iç arıza var" if beklenen else "iç arıza yok")),
        K("Fark akımı Id", f"{fnum(m['id'][k], 2)} ×In", "bad" if m["ust"][k] else "ok", f"L{k + 1} · eşik {fnum(m['thr'][k], 2)}"),
        K("Tutucu akım Itut", f"{fnum(m['ib'][k], 2)} ×In", "info", "(|I1| + |I2|) / 2"),
        K("OG anma akımı", fa(i1n), "info", f"{fnum(i1n / ct1, 3)} A sekonder ({ct1:g}/1)"),
        K("AG anma akımı", fa(i2n, 0), "info", f"{fnum(i2n / ct2, 3)} A sekonder ({ct2:g}/1)"),
    ]
    e_yuk = esik(1.0, p); e_dis = esik(ikd, p)
    kontroller = [
        C("Röle bu durumda doğru karar veriyor mu?", ("açar" if m["acar"] else "açmaz"), "yalnız iç arızada açar", m["acar"] == beklenen,
          "Id = |IW + I'W|, Ib = (|IW| + |I'W|) / 2; tutucu akım 0,5 ×In'e kadar düz, sonra iki eğim — " + P3T + " böl. 6.30 Denklem 26–27, Çizelge 96", "resmi"),
        C("dI> yükteki sahte fark akımının üstünde mi?", f"kademe %{fnum(kad * 100, 1)} + AT oran hatası 2 × %1 + boşta akım %1 = %{fnum(sahte_yuk * 100, 1)}; tam yükte eşik %{fnum(e_yuk * 100, 0)}",
          "eşik ≥ 2 × sahte fark", e_yuk >= 2 * sahte_yuk, "Sahte fark akımının kaynakları: " + P5 + " (kademe değiştirici, AT hatası, mıknatıslanma akımı < %1). 2 kat pay öğretim amaçlı", "ikincil"),
        C("Eğimler dış arızadaki sahte fark akımını karşılıyor mu?", f"geçen akım {fnum(ikd, 1)} ×In; sahte fark ≈ (%{fnum(kad * 100, 1)} + 2 × %{fnum(ath * 100, 0)}) × {fnum(ikd, 1)} = {fnum(sahte_egim * ikd, 2)} ×In; eşik {fnum(e_dis, 2)} ×In",
          "eşik ≥ 1,5 × sahte fark", e_dis >= 1.5 * sahte_egim * ikd, "Eğim 1 kademe ve oran hatasını, eğim 2 AT doymasını karşılar — " + P5, "ikincil"),
        C("2. harmonik kilidi demerajı tutuyor mu?", "etkin, %" + fnum(num(p, "h2", 15), 0) if p.get("h2_blok") else "devre dışı", "etkin; ayar %10 … %20", bool(p.get("h2_blok")) and 10 <= num(p, "h2", 15) <= 20,
          "2. harmonik fark akımından hesaplanır (100 × If2 / If1); ayar aralığı %5 … %30 — " + P3T + " böl. 6.30, Çizelge 96. %10–20 önerisi saha pratiği", "ikincil"),
        C("dI>> demeraj tepesinin ve dış arıza akımının üstünde mi?", f"{fnum(num(p, 'id2', 20), 1)} ×In; dış arızada geçen akım 1/uk = {fnum(ikd, 1)} ×In", f"≥ {fnum(o_id2, 0)} ×In", num(p, "id2", 20) >= o_id2 - 1e-9,
          "dI>> eğim ve 2. harmonik kilidi içermez (" + P3T + " böl. 6.30); bu yüzden dış arızadaki en büyük akımın üstüne konur (Siemens 7UT85 hesap örneği: 1/uk'nın üstü)", "ikincil"),
        C("Akım trafolarının polaritesi ve röledeki trafo verileri", HATA[m["hata"]], "yük altında Id ≈ 0", m["hata"] == "yok", KABUL + "; yük altında rölenin ölçtüğü fark akımı okunur", "resmi"),
    ]
    girdiler = [
        G("Trafo gücü ve gerilimleri", f"{fnum(sn, 0)} kVA, {u1:g} / {fnum(u2, 1)} kV", "Trafo etiketi", "İki tarafın anma akımı buradan; röle bütün akımları trafonun anma akımına oranlar («×In» burada trafo anma akımıdır)", "In = S / (√3·U)"),
        G("Bağlantı grubu", p.get("grup", "Dyn11"), "Trafo etiketi", "İki taraf arasında 30°'nin katı kadar faz kayması vardır; röle AG akımlarını döndürerek karşılaştırır", "Yanlış girilirse yükte bile fark akımı okunur"),
        G("Kademe değiştirici aralığı", f"± %{fnum(kad * 100, 1)}", "Trafo etiketi (ör. ±2 × 2,5 %)", "Kademe anma konumundan ayrılınca oran değişir; röle bunu bilmez — sahte fark akımı", "dI> ve eğim 1"),
        G("İki tarafın akım trafosu oranı, sınıfı, polaritesi", f"{ct1:g}/1 ve {ct2:g}/1 A", "Hücre etiketleri; AT deney raporu", "Röle oranı düzeltir; hata ve doyma eğimlerle karşılanır", "Sekonder anma akımları: " + f"{fnum(i1n / ct1, 3)} A ve {fnum(i2n / ct2, 3)} A"),
        G("Kısa devre gerilimi uk", f"%{fnum(uk * 100, 1)}", "Trafo etiketi", "Dış arızada trafodan geçecek en büyük akım", f"1/uk = {fnum(ikd, 1)} ×In → dI>>"),
        G("Demeraj akımı ve 2. harmonik oranı", "8–12 ×In tepe; 2. harmonik %15–60 (tipik)", "Üretici verisi; yoksa tipik değer", "Enerjilendirmede akım yalnız bir taraftan girer: tam bir fark akımıdır", "2. harmonik kilidi; dI>> bu tepenin üstünde"),
        G("Nötr topraklaması (hangi sargı topraklı)", "AG yıldız noktası topraklı", "Tek hat şeması", "Topraklı tarafın dışındaki toprak arızasında sıfır bileşen akımı yalnız o tarafta görünür", "Sıfır bileşen süzgeci"),
    ]
    adimlar = [
        A("Anma akımları", "In = S / (√3 · U)", f"{fnum(sn, 0)} / (1,732 × {u1:g}) ve / (1,732 × {fnum(u2, 1)})", f"{fa(i1n)} ve {fa(i2n, 0)}", "temel bağıntı", "resmi", ["Trafo gücü ve gerilimleri"]),
        A("Sekonder anma akımları (test için)", "In,s = In / AT oranı", f"{fnum(i1n, 1)} / {ct1:g} ve {fnum(i2n, 0)} / {ct2:g}", f"{fnum(i1n / ct1, 3)} A ve {fnum(i2n / ct2, 3)} A", "Röle bu değerleri 1,00 ×In sayar (genlik eşleme) — " + P5 + " «Amplitude matching»", "resmi", ["İki tarafın akım trafosu oranı, sınıfı, polaritesi"]),
        A("Yükteki sahte fark akımı", "kademe + AT oran hatası + boşta akım", f"%{fnum(kad * 100, 1)} + 2 × %1 + %1", f"%{fnum(sahte_yuk * 100, 1)}", P5 + " (mıknatıslanma akımı < %1)", "ikincil", ["Kademe değiştirici aralığı"]),
        A("dI> başlatma", "≥ 2 × yükteki sahte fark", f"2 × %{fnum(sahte_yuk * 100, 1)} → 5'e yuvarla", f"%{o_id:g} In", "pay öğretim amaçlı; üretici varsayılanı %25 (" + P3T + " Çizelge 95)", "ikincil", [], "dI> başlatma (Itut < 0,5 In)"),
        A("Eğim 1", "≥ 1,5 × (kademe + 2 × AT bileşik hatası)", f"1,5 × (%{fnum(kad * 100, 1)} + 2 × %{fnum(ath * 100, 0)})", f"%{o_e1:g}", "kademe ve oran hatası geçen akımla orantılı büyür", "ikincil", ["Kademe değiştirici aralığı", "İki tarafın akım trafosu oranı, sınıfı, polaritesi"], "Eğim 1"),
        A("Eğim 2 başlangıcı", "yük bölgesinin üstü", "en büyük yük ≈ 1,2–1,5 ×In → 2 ×In", "2,0 ×In", "bu noktadan sonra akım ancak arıza akımıdır; AT doyması başlar", "ikincil", [], "Eğim 2 başlangıcı için Itut"),
        A("Eğim 2", "AT doymasına karşı dik eğim", "bir taraf doyarsa fark akımı geçen akımın büyük bölümü olur", "%100–150", "tek taraftan beslemenin eğimi %200'dür: eğim 2 bunun altında kalmalı ki iç arıza açsın", "ikincil", [], "Eğim 2"),
        A("dI>>", "≥ 1,2 / uk ve ≥ demeraj tepesi", f"1,2 / {fnum(uk, 3)}", f"{fnum(o_id2, 0)} ×In", "Siemens 7UT85 hesap örneği (yerel arşiv); " + P5, "ikincil", ["Kısa devre gerilimi uk", "Demeraj akımı ve 2. harmonik oranı"], "dI>> başlatma"),
    ]
    cg = {"Dyn11": ("Dy11", "OFF", "ON"), "Dyn5": ("Dy5", "OFF", "ON"), "Dyn1": ("Dy1", "OFF", "ON"), "Yyn0": ("Yy0", "OFF", "ON")}[p.get("grup") if p.get("grup") in GRUP else "Dyn11"]
    ayarlar = [
        S("dI> — Etkin", "Açık", "—", "Ana diferansiyel kademe (tek ayar grubu)", P3T + " böl. 6.30"),
        S("dI> başlatma (Itut < 0,5 In)", f"%{o_id:g} In (şu an %{fnum(num(p, 'id_min', 20), 0)})", "%5 … %50 In; varsayılan %25", "Tutucu akım 0,5 ×In'in altındayken sabit eşik: yükteki sahte fark akımının 2 katı", P3T + " Çizelge 95–96"),
        S("Eğim 1", f"%{o_e1:g} (şu an %{fnum(num(p, 'egim1', 50), 0)})", "%5 … %100; varsayılan %50", "0,5 ×In'den eğim 2 başlangıcına kadar: kademe + AT hatası", P3T + " Çizelge 95–96"),
        S("Eğim 2 başlangıcı için Itut", f"2,00 ×In (şu an {fnum(num(p, 'ib2', 2.0), 2)})", "1,00 … 3,00 ×In; varsayılan 2,00", "Yük bölgesinin bittiği yer", P3T + " Çizelge 95–96"),
        S("Eğim 2", f"%150 (şu an %{fnum(num(p, 'egim2', 150), 0)})", "%100 … %200; varsayılan %150", "Dış arızada AT doyması", P3T + " Çizelge 95–96"),
        S("dI> inrush enable · 2. harm. başlatma", f"Açık · %{fnum(num(p, 'h2', 15), 0)}", "%5 … %30 ya da kapalı; ekrandaki örnek %10", "Demeraj kilidi; oran fark akımından hesaplanır. Düşük kayıplı yeni trafolarda 2. harmonik %10'a kadar düşebilir", P3T + " Çizelge 96"),
        S("dI> 5. harm. kilit etkin · sınır", f"Açık · %{fnum(num(p, 'h5', 35), 0)}", "%20 … %50 ya da kapalı; ekrandaki örnek %35", "Aşırı uyarmada mıknatıslanma akımı fark akımı gibi görünür; 5. harmonikle tanınır", P3T + " Çizelge 96"),
        S("dI>> başlatma", f"{fnum(o_id2, 0)} ×In (şu an {fnum(num(p, 'id2', 20), 1)})", "5,0 … 40,0 ×In", "Eğimsiz, kilitsiz hızlı kademe (< 40 ms): ağır iç arızada AT doysa bile açar", P3T + " Çizelge 97"),
        S("Ölçekleme › trafo anma gücü ve gerilimleri (Un, U'n), AT oranları", f"{fnum(sn, 0)} kVA · {u1:g}/{fnum(u2, 1)} kV · {ct1:g}/1 · {ct2:g}/1", "—", "Röle iki tarafın anma akımını kendisi hesaplar (In = Sn / √3·Un); 1 pu = trafonun anma akımı. YG tarafı IL uçlarına bağlanır", P3T + " böl. 4 (per unit ölçekleme), böl. 6.30 notu"),
        S("Bağlantı grubu (ConnGrp) · Io cmps · I'o cmps", f"{cg[0]} · {cg[1]} · {cg[2]}", "Çizelge 93'teki bütün gruplar", "Topraklı yıldız tarafta sıfır akım kompanzasyonu açılır (burada AG tarafı: I'o cmps); yoksa dış toprak arızasında fark akımı oluşur", P3T + " böl. 6.30 Çizelge 93"),
        S("AT denetimi modu (dI> içinde)", "gösterge ya da tutma (restrain)", "indication / restrain / block", "Tutma: AT arızasında başlatma değerine 100 puan eklenir. Kilitleme önerilmez: AT arızası sırasındaki gerçek arızada koruma kalmaz", P3T + " böl. 6.30 «Current transformer supervision»"),
    ]
    s1, s2 = i1n / ct1, i2n / ct2
    nokta = []
    for ib in (1.0, num(p, "ib2", 2.0), num(p, "ib2", 2.0) + 1.0):
        idt = esik(ib, p)
        nokta.append(T(f"Eğim noktası — Itut = {fnum(ib, 1)} ×In", f"İki taraftan geçen akım: OG {fnum((ib + idt / 2) * s1, 3)} A, AG {fnum((ib - idt / 2) * s2, 3)} A (AG akımını yavaşça azaltın)", f"Açma Id ≈ {fnum(idt, 2)} ×In'de", "±%3 ya da 0,02 ×In (akım < 200 mA ise)"))
    test = [
        T("Yük altında denetim (enerji verildikten sonra)", "Trafo en az %20–30 yükteyken rölenin ölçüm sayfasını okuyun", "Fark akımı ≈ 0 (birkaç yüzde), tutucu akım ≈ yük akımı; üç fazda da", "Büyük fark akımı: polarite, bağlantı grubu ya da oran hatası"),
        T("dI> — OG tarafından tek taraflı", f"Yalnız OG girişine üç fazlı dengeli akım; {fnum(num(p, 'id_min', 20) / 100 * s1, 3)} A'e doğru yükseltin", f"Başlatma {fnum(num(p, 'id_min', 20) / 100 * s1, 3)} A (= %{fnum(num(p, 'id_min', 20), 0)} × {fnum(s1, 3)} A)", "±%3 ya da 0,02 ×In (akım < 200 mA ise)"),
        T("dI> — AG tarafından tek taraflı", "Yalnız AG girişine üç fazlı dengeli akım", f"Başlatma {fnum(num(p, 'id_min', 20) / 100 * s2, 3)} A", "±%3 ya da 0,02 ×In (akım < 200 mA ise)"),
        T("Kararlılık (geçen akım)", f"OG'ye {fnum(s1, 3)} A, AG'ye {fnum(s2, 3)} A; AG akımını bağlantı grubunun faz kayması kadar döndürüp ters yönde verin", "Fark akımı ≈ 0; açma yok", "—"),
    ] + nokta + [
        T("2. harmonik kilidi", f"OG'den 50 Hz {fnum(2 * num(p, 'id_min', 20) / 100 * s1, 3)} A + 100 Hz bileşen", f"100 Hz oranı %{fnum(num(p, 'h2', 15), 0)}'in üstünde: açmaz; altında: açar (< 60 ms)", "±%2 birim"),
        T("dI>>", f"OG'den {fnum(num(p, 'id2', 20) * s1, 2)} A'e doğru (kısa süreli)", "Açar; 2. harmonik olsa da açar; süre < 40 ms (Id > 3,5 × ayar)", "±%3 ya da anma değerinin ±%0,5'i"),
    ]
    xs = [x * 0.05 for x in range(0, int(max(6.0, ikd * 1.15) / 0.05) + 1)]
    g = {"baslik": "Karakteristik: fark akımı – tutucu akım düzleminde çalışma noktası", "x_ad": "Tutucu akım Itut (×In)", "y_ad": "Fark akımı Id (×In)", "ymin": 0, "ymax": max(3.0, min(max(m["id"]) * 1.25, 14.0)),
         "seriler": [{"ad": "açma eşiği (dI>)", "renk": "#1a4d8f", "pts": [[x, round(esik(x, p), 3)] for x in xs]},
                     {"ad": "tek taraftan besleme (iç arıza)", "renk": "#94a3b8", "kesik": True, "pts": [[x, 2 * x] for x in xs]},
                     {"ad": "sahte fark: kademe + AT hatası", "renk": "#d97706", "kesik": True, "pts": [[x, round(sahte_egim * x, 3)] for x in xs]},
                     {"ad": "ölçülen (L1, L2, L3)", "renk": "#dc2626", "nokta": True, "r": 5, "pts": [[round(b, 3), round(d, 3)] for b, d in zip(m["ib"], m["id"])]}],
         "yatay": [{"y": num(p, "id2", 20), "etiket": "dI>>", "renk": "#7c3aed"}] if num(p, "id2", 20) <= max(3.0, min(max(m["id"]) * 1.25, 14.0)) else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["87t"],
        "sahne": c.sahne(), "grafikler": [g],
        "cubuklar": [{"baslik": "Harmonik oranları ve kilit sınırları", "kategoriler": ["L1", "L2", "L3"], "y_ad": "% (temel bileşene göre)",
                      "seriler": [{"ad": "2. harmonik", "renk": "#1a4d8f", "deger": [round(h * 100, 1) for h in m["h2"]]}, {"ad": "5. harmonik", "renk": "#d97706", "deger": [round(h * 100, 1) for h in m["h5"]]},
                                  {"ad": "2. harm. ayarı", "renk": "#94a3b8", "deger": [num(p, "h2", 15)] * 3}, {"ad": "5. harm. ayarı", "renk": "#cbd5e1", "deger": [num(p, "h5", 35)] * 3}]}] if dur in ("inrush", "asiri") else [],
        "anlatim": [
            f"Röle iki tarafın akımını trafonun anma akımına oranlar: OG'de {fa(i1n)} ({fnum(s1, 3)} A sekonder), AG'de {fa(i2n, 0)} ({fnum(s2, 3)} A sekonder) «1,00 ×In»dir. Bağlantı grubunun faz kaymasını da düzeltir.",
            "Sonra iki büyüklük hesaplar: fark akımı (giren − çıkan) ve tutucu akım (ikisinin ortalaması). Arıza yokken fark sıfıra yakın, tutucu akım yük akımına eşittir.",
            f"Fark hiçbir zaman tam sıfır olmaz. Kademe değiştirici oranı ±%{fnum(kad * 100, 1)} oynatır; akım trafolarının hatası vardır; trafo boşta akım çeker. Bunlar geçen akımla birlikte büyür: eşik de tutucu akımla birlikte yükselmelidir — eğimli karakteristiğin nedeni budur.",
            "Dış arızada geçen akım çok büyüktür; bir akım trafosu doyarsa çıkan akım eksik ölçülür ve büyük bir sahte fark doğar. Bunu dik ikinci eğim karşılar.",
            "Enerjilendirmede akım yalnız bir taraftan girer: röle için bu tam bir iç arızadır. Demeraj akımının dalga biçimi bozuktur; 2. harmonik oranı ayarı aşınca kademe kilitlenir.",
            "Gerilim yükselir ya da frekans düşerse çekirdek doyar, mıknatıslanma akımı büyür (aşırı uyarma). Bu akımın 5. harmoniği yüksektir; 5. harmonik kilidi yanlış açmayı önler.",
            "Çok büyük fark akımında (dI>>) röle hiçbir kilide bakmadan açar: ağır iç arızada akım trafosu doysa da gecikme olmaz.",
        ],
        "dersler": [
            "dI> = yükteki sahte fark akımının üstü. Eğim 1 = kademe + AT hatası. Eğim 2 = AT doyması. dI>> = dış arıza akımının ve demeraj tepesinin üstü.",
            "P3T32'de faz akımlarında 1 pu = trafonun anma akımıdır (AT primeri değil); röle bunu Sn ve Un'den kendisi hesaplar. Test akımı = ayar × trafonun sekonder anma akımı.",
            "Tek taraftan enjeksiyonda fark = akım, tutucu = akımın yarısı: eğimi %200 olan doğru üzerinde yürürsünüz.",
            "Yük altında fark akımı okunuyorsa önce polariteye, sonra bağlantı grubuna, sonra oranlara bakın.",
            "2. harmonik ayarı çok yüksekse demerajda açar; çok düşükse akım trafosu doymuş bir iç arızada gecikir.",
        ],
        "tablolar": [
            {"baslik": "Her durumda röle ne ölçer", "cols": ["Durum", "Id (×In)", "Itut (×In)", "Eşik", "2. harm.", "5. harm.", "Karar"], "rows": [
                (lambda mm, ad: [ad, fnum(max(mm["id"]), 2), fnum(mm["ib"][max(range(3), key=lambda j: mm["id"][j])], 2), fnum(mm["thr"][max(range(3), key=lambda j: mm["id"][j])], 2), f"%{fnum(max(mm['h2']) * 100, 0)}", f"%{fnum(max(mm['h5']) * 100, 0)}", "AÇAR" if mm["acar"] else "açmaz"])(olc({**p, "durum": d, "hata": "yok", **ek}), ad)
                for d, ek, ad in (("yuk", {"kademe": 0}, "Tam yük, kademe ortada"), ("yuk", {"kademe": num(p, "kademe_ar", 5)}, "Tam yük, kademe uçta"), ("dis", {"doyma": 0, "kademe": num(p, "kademe_ar", 5)}, "Dış arıza, AT doymamış"),
                                  ("dis", {"doyma": 40, "kademe": num(p, "kademe_ar", 5)}, "Dış arıza, AG AT'si %40 doymuş"), ("ic", {"ic_pu": 0.4}, "İç arıza 0,4 ×In"), ("ic", {"ic_pu": 12}, "İç arıza 12 ×In"), ("inrush", {}, "Enerjilendirme"), ("asiri", {}, "Aşırı uyarma"))],
             "not": "Demeraj ve aşırı uyarmadaki harmonik oranları tipik değerlerdir (öğretim amaçlı)."},
            {"baslik": "Tek fazlı enjeksiyonda röle içi çarpanlar", "cols": ["Enjeksiyon", "Rölenin hesapladığı akım", "Neden"], "rows": [
                ["Yıldız tarafta tek faz, sıfır bileşen süzgeci açık", "enjekte edilenin 2/3'ü (öbür iki fazda −1/3)", "Sıfır bileşen (akımın 1/3'ü) her fazdan çıkarılır"],
                ["Saat sayısı tek olan grupta (Dyn11 …) AG tarafında tek faz", "enjekte edilenin 1/√3'ü, iki fazda", "Faz düzeltmesi iki fazın farkını √3'e böler"],
                ["Üç fazlı dengeli enjeksiyon", "enjekte edilenin kendisi", "Çarpan yok — eğim testleri üç fazlı yapılır"]],
             "not": "P3T32 üçgen tarafta sargı akımını (IL1 − IL2)/√3 olarak hesaplar ve topraklı yıldız tarafta sıfır akımı düşer (" + P3T + " böl. 6.30 Denklem 24, Çizelge 93). Çarpanların P5'teki karşılığı: " + P5 + " Çizelge 119."},
        ],
    }
