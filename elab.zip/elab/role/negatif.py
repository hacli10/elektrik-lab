"""Negatif bileşen aşırı akım koruması (ANSI 46) — Easergy P3 «I2>» kademesi.

Dayanak: P3U/en M/J006 böl. 5.12 (negatif bileşen rotorda çift frekanslı akım doğurur; etkin değere dayalı aşırı yük koruması bunu göremez; sabit ve
ters zamanlı karakteristik: T = K1 / [(I2/In)² − K2²], en uzun 1000 s), Çizelge 56 (başlatma 2–70 %, sabit zaman 1,0–600 s, K1 1–50 s, başlatma süresi
≈ 300 ms, doğruluk ±1 birim, süre ±5 % ya da ±200 ms), böl. 3.10 (simetrili bileşenler). Makinenin negatif bileşen dayanımı (sürekli I2 ve (I2/In)²·t)
üretici verisidir; tipik değerler IEC 60034-1'e dayanır — «dogrulanacak»."""
from __future__ import annotations

import math

from .ortak import A, A120, C, G, K, P3T, P3U, S, S3, T, ctl, fa, fnum, fz, aci, kutup, num, opt, simetrik, tek_hat

ID = "negatif"
BASLIK = "Negatif bileşen (46)"
IKON = "🔁"
GIRIS = ("Üç fazın akımı eşit değilse içinde ters yönde dönen bir bileşen vardır: negatif bileşen. Jeneratörün ve motorun rotorunu çift frekanslı akımla "
         "ısıtır; faz kopukluğunu, ters faz sırasını ve dengesiz arızayı da ele verir. Röle bu bileşeni hesaplar ve anma akımının yüzdesi olarak izler.")

DURUM = {"dengeli": "Dengeli yük", "dengesiz": "Dengesiz yük (bir faz düşük)", "acik": "Bir faz kopuk", "ikifaz": "İki faz arası arıza", "ters": "Faz sırası ters"}

KONTROLLER = [
    ctl("s_kva", "Korunan makinenin / trafonun gücü", "sayi", 1870, min=100, max=40000, adim=10, birim="kVA"),
    ctl("un_kv", "Gerilim", "sec", 34.5, secenek=opt((0.4, "0,4 kV"), (6.3, "6,3 kV"), (10.5, "10,5 kV"), (34.5, "34,5 kV"))),
    ctl("ct_p", "Akım trafosu primeri", "sayi", 50, min=5, max=6000, adim=5, birim="A"),
    ctl("durum", "Durum", "sec", "acik", secenek=opt(*DURUM.items())),
    ctl("yuk", "Yük akımı", "sayi", 80, min=10, max=150, adim=5, birim="% In"),
    ctl("fark", "Düşük fazın eksiği", "sayi", 20, min=0, max=100, adim=5, birim="%", goster={"durum": ["dengesiz"]}),
    ctl("i_ar", "Arıza akımı", "sayi", 3.0, min=0.5, max=20, adim=0.5, birim="×In", goster={"durum": ["ikifaz"]}),
    ctl("k2", "Röle › Başlatma K2", "sayi", 20, min=2, max=70, adim=1, birim="%"),
    ctl("mod", "Röle › Gecikme", "sec", "sz", secenek=opt(("sz", "SZ — sabit zamanlı"), ("ters", "Ters zamanlı (K1)"))),
    ctl("t", "Röle › Çalışma süresi", "sayi", 10.0, min=1.0, max=600, adim=0.5, birim="s", goster={"mod": ["sz"]}),
    ctl("k1", "Röle › Gecikme çarpanı K1", "sayi", 15, min=1, max=50, adim=1, birim="s", goster={"mod": ["ters"]}),
    ctl("i2s", "Makine › sürekli dayanabildiği I2", "sayi", 8, min=3, max=20, adim=1, birim="% In", yardim="Jeneratör veri föyü"),
    ctl("km", "Makine › (I2/In)²·t dayanımı", "sayi", 20, min=5, max=60, adim=1, birim="s", yardim="Jeneratör veri föyü"),
]


def akimlar(p: dict) -> tuple[complex, complex, complex]:
    """Faz akımları (makinenin anma akımının katı)."""
    d = p.get("durum") if p.get("durum") in DURUM else "acik"
    i = num(p, "yuk", 80) / 100; a = A120; f = kutup(1, -20)
    if d == "dengesiz":
        return i * (1 - num(p, "fark", 20) / 100) * f, i * a * a * f, i * a * f
    if d == "acik":                                           # L1 kopuk: kalan iki faz tek bir çevrim oluşturur
        return 0j, i * S3 / 2 * kutup(1, -90) * f, i * S3 / 2 * kutup(1, 90) * f
    if d == "ikifaz":
        k = num(p, "i_ar", 3.0)
        return 0j, k * kutup(1, -90 - 60), k * kutup(1, 90 - 60)
    if d == "ters":
        return i * f, i * a * f, i * a * a * f
    return i * f, i * a * a * f, i * a * f


def sure(i2: float, p: dict) -> float:
    k2 = num(p, "k2", 20) / 100
    if i2 < k2:
        return math.inf
    if p.get("mod") == "ters":
        return min(1000.0, num(p, "k1", 15) / max(i2 * i2 - k2 * k2, 1e-9))
    return num(p, "t", 10.0)


def run(p: dict) -> dict:
    d = p.get("durum") if p.get("durum") in DURUM else "acik"
    i_n = num(p, "s_kva", 1870) / (S3 * num(p, "un_kv", 34.5)); ct_p = num(p, "ct_p", 50)
    ia, ib, ic = akimlar(p)
    i0, i1, i2 = simetrik(ia, ib, ic)
    m2 = abs(i2); t_role = sure(m2, p); t_mak = num(p, "km", 20) / (m2 * m2) if m2 > num(p, "i2s", 8) / 100 else math.inf
    acar = t_role < math.inf
    c = tek_hat(("Şebeke", ""), ("Jeneratör / motor", f"{fnum(num(p, 's_kva', 1870), 0)} kVA"), ("46  I2>", ("AÇAR " + fnum(t_role, 1) + " s") if acar else "başlamadı"), "acti" if acar else "normal", None, "sol", gt=False, ileri=False, at_ad=f"AT {ct_p:g}/1")
    c.yazi(500, 190, f"I2 = %{fnum(m2 * 100, 0)} In = {fa(m2 * i_n)} · I1 = %{fnum(abs(i1) * 100, 0)} In", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, f"Faz akımları: {fnum(abs(ia) * 100, 0)} / {fnum(abs(ib) * 100, 0)} / {fnum(abs(ic) * 100, 0)} % In", "#334155", 11)
    c.yazi(500, 226, "Makine bu dengesizliğe " + (f"{fnum(t_mak, 0)} s dayanır" if t_mak < math.inf else "sürekli dayanır"), "#334155", 11)
    mx = max(abs(ia), abs(ib), abs(ic), 1e-9)
    fazor = {"baslik": "Faz akımları ve negatif bileşen", "vektorler": [fz("IL1", abs(ia) * 100, aci(ia), abs(ia) / mx, "#8a4b12"), fz("IL2", abs(ib) * 100, aci(ib), abs(ib) / mx, "#111827"), fz("IL3", abs(ic) * 100, aci(ic), abs(ic) / mx, "#6b7280"),
                                                                   fz("I2", m2 * 100, aci(i2), m2 / mx, "#dc2626", kesik=True), fz("I1", abs(i1) * 100, aci(i1), abs(i1) / mx, "#15803d", kesik=True)],
             "not": "Büyüklükler makinenin anma akımının yüzdesi. I2 = (IL1 + a²·IL2 + a·IL3) / 3."}
    ozet = [
        K("Röle kararı", ("AÇAR " + fnum(t_role, 1) + " s") if acar else "AÇMAZ", "ok" if (acar or t_mak == math.inf) and (not acar or t_role <= t_mak) else "bad", "makine dayanımı " + (fnum(t_mak, 0) + " s" if t_mak < math.inf else "sürekli")),
        K("Negatif bileşen I2", f"%{fnum(m2 * 100, 0)} In", "bad" if m2 >= num(p, "k2", 20) / 100 else "ok", fa(m2 * i_n)),
        K("I2 / I1", f"%{fnum(m2 / max(abs(i1), 1e-9) * 100, 0)}" if abs(i1) > 1e-6 else "∞", "info", "dengesizlik oranı"),
        K("Pozitif bileşen I1", f"%{fnum(abs(i1) * 100, 0)} In", "info", "işe yarayan bileşen"),
        K("Makine anma akımı", fa(i_n), "info", f"{fnum(i_n / ct_p, 2)} ×In(AT)"),
    ]
    kontroller = [
        C("Röle makine zarar görmeden açıyor mu?", f"röle {fnum(t_role, 1) + ' s' if acar else 'açmaz'}; makine dayanımı {fnum(t_mak, 0) + ' s' if t_mak < math.inf else 'sürekli'}", "röle süresi ≤ makine dayanımı", (t_role <= t_mak) if t_mak < math.inf else True,
          "Makine dayanımı: (I2/In)²·t = K (üretici verisi; IEC 60034-1 tipik değerleri)", "dogrulanacak"),
        C("Başlatma sürekli dayanımın üstünde, arıza düzeyinin altında mı?", f"K2 = %{fnum(num(p, 'k2', 20), 0)}; sürekli dayanım %{fnum(num(p, 'i2s', 8), 0)}", "sürekli dayanım ≤ K2 ≤ %50 (faz kopukluğunda I2 ≥ %50·yük)", num(p, "i2s", 8) <= num(p, "k2", 20) <= 50,
          "Aralık %2 … %70: " + P3U + " Çizelge 56", "resmi"),
        C("Faz kopukluğu görülüyor mu?", f"bir faz kopukken I2 = %{fnum(num(p, 'yuk', 80) / 2, 0)} In (yük %{fnum(num(p, 'yuk', 80), 0)})", f"≥ K2 = %{fnum(num(p, 'k2', 20), 0)}", num(p, "yuk", 80) / 2 >= num(p, "k2", 20),
          "Yalıtılmış / dirençli şebekede bir faz kopunca kalan iki fazın akımı eşit ve zıttır: I2 = I1 = yük / 2 (hesap)", "resmi"),
        C("Sabit zamanlı kademenin süresi", f"{fnum(num(p, 't', 10.0), 1)} s" if p.get("mod") != "ters" else f"K1 = {fnum(num(p, 'k1', 15), 0)} s", "1,0 … 600 s; şebekedeki dengesiz arızaların temizlenme süresinden uzun", None,
          P3U + " Çizelge 56 (başlatma süresi ≈ 300 ms; süre doğruluğu ±%5 ya da ±200 ms)", "resmi"),
    ]
    girdiler = [
        G("Makinenin anma akımı", fa(i_n), "Etiket (S, U)", "Röle I2'yi bu akımın yüzdesi olarak değerlendirir (motor / jeneratör / trafo modunda)", "I2 (%) = I2 / In"),
        G("Makinenin sürekli negatif bileşen dayanımı", f"%{fnum(num(p, 'i2s', 8), 0)} In", "Jeneratör / motor veri föyü", "Başlatma bunun altına inerse normal şebeke dengesizliğinde açar", "K2 ≥ bu değer"),
        G("Makinenin (I2/In)²·t dayanımı", f"{fnum(num(p, 'km', 20), 0)} s", "Jeneratör / motor veri föyü", "Rölenin süresi her I2 değerinde bunun altında kalmalı", "K1 ≤ K (ters zamanlıda)"),
        G("Şebekenin doğal dengesizliği ve dengesiz arızaların temizlenme süresi", "I2 ≈ %1–5; arıza süresi 0,3–1 s", "Ölçüm; üst koruma ayarları", "Şebekedeki iki fazlı arıza da I2 üretir; 46 ondan önce açmamalı", "t > üst korumaların süresi"),
    ]
    adimlar = [
        A("Negatif bileşen", "I2 = (IL1 + a²·IL2 + a·IL3) / 3", f"{fnum(abs(ia) * 100, 0)}∠{fnum(aci(ia), 0)}°, {fnum(abs(ib) * 100, 0)}∠{fnum(aci(ib), 0)}°, {fnum(abs(ic) * 100, 0)}∠{fnum(aci(ic), 0)}° % In", f"%{fnum(m2 * 100, 0)} In", P3U + " böl. 3.10 (simetrili bileşenler)", "resmi", ["Makinenin anma akımı"]),
        A("Başlatma K2", "sürekli dayanım ≤ K2 ≤ kopuk fazdaki I2", f"%{fnum(num(p, 'i2s', 8), 0)} … %{fnum(num(p, 'yuk', 80) / 2, 0)}", f"%{fnum(max(num(p, 'i2s', 8), min(20, num(p, 'yuk', 80) / 2)), 0)}", "ekrandaki örnek %20", "ikincil", ["Makinenin sürekli negatif bileşen dayanımı"], "Başlatma K2"),
        A("Makinenin dayanma süresi", "t = K / (I2/In)²", f"{fnum(num(p, 'km', 20), 0)} / {fnum(m2, 2)}²", f"{fnum(t_mak, 0)} s" if t_mak < math.inf else "sürekli", "üretici verisi", "dogrulanacak", ["Makinenin (I2/In)²·t dayanımı"]),
        A("Rölenin süresi", "SZ: t;  ters: T = K1 / [(I2/In)² − K2²]", f"I2 = {fnum(m2, 2)}, K2 = {fnum(num(p, 'k2', 20) / 100, 2)}", f"{fnum(t_role, 1)} s" if acar else "başlamaz", P3U + " böl. 5.12 Denklem 19", "resmi", [], "Çalışma süresi / K1"),
    ]
    ayarlar = [
        S("Başlatma K2", f"%{fnum(num(p, 'k2', 20), 0)}", "%2 … %70; ekrandaki örnek %20", "İzin verilen en büyük dengesizlik (I2 / In)", P3U + " Çizelge 56"),
        S("Gecikme eğrisi", "SZ" if p.get("mod") != "ters" else "Ters (Inv)", "SZ / Ters", "Jeneratörde makinenin I2²t eğrisini izlemek için ters zamanlı uygundur", P3U + " böl. 5.12"),
        S("Çalışma süresi", f"{fnum(num(p, 't', 10.0), 1)} s", "1,0 … 600 s; ekrandaki örnek 10,0 s", "Şebekedeki dengesiz arızaların temizlenmesini bekler", P3U + " Çizelge 56"),
        S("Gecikme çarpanı K1", f"{fnum(num(p, 'k1', 15), 0)} s", "1 … 50 s", "Ters zamanlıda; makinenin K değerinin altında", P3U + " Çizelge 56"),
        S("I'2> (AG tarafı kademesi — trafo rölesi)", "ikinci akım girişi (I'L) ile aynı işlev", "%2 … %70; aynı süre aralıkları", "Trafo rölesinde (P3T32) iki tarafın negatif bileşeni ayrı kademelerle izlenir; taban trafonun anma akımıdır (ITN)", P3T + " böl. 6.10 Çizelge 65"),
        S("Ek sabit zamanlı kademe", "programlanabilir kademe (ANSI 99)", "—", "Birden çok sabit zamanlı kademe gerekirse (ör. alarm) programlanabilir kademeler kullanılır", P3U + " böl. 5.12"),
    ]
    sn = i_n / ct_p
    test = [
        T("Başlatma", f"Tek faza akım: tek fazlı akımda I2 = I/3. {fnum(3 * num(p, 'k2', 20) / 100 * sn, 3)} A'e doğru yükseltin", f"Başlatma tek faz {fnum(3 * num(p, 'k2', 20) / 100 * sn, 3)} A'de (I2 = %{fnum(num(p, 'k2', 20), 0)} In)", "±%1 birim"),
        T("Ters faz sırası", f"Üç faza dengeli {fnum(num(p, 'k2', 20) / 100 * sn * 1.2, 3)} A, iki fazın yerini değiştirerek", "I2 = akımın tamamı; başlar", "—"),
        T("Dengeli akımda kararlılık", f"Üç faza dengeli {fnum(sn, 3)} A (doğru sıra)", "I2 ≈ 0; başlamaz", "—"),
        T("Süre", "Başlatmanın 2 katı I2", (f"{fnum(num(p, 't', 10.0), 1)} s" if p.get("mod") != "ters" else f"{fnum(sure(2 * num(p, 'k2', 20) / 100, p), 1)} s"), "±%5 ya da ±200 ms"),
        T("Bu sayfadaki durum", f"I2 = %{fnum(m2 * 100, 0)} In", ("AÇAR " + fnum(t_role, 1) + " s") if acar else "AÇMAZ", DURUM[d]),
    ]
    xs = [x for x in range(2, 101)]
    g = {"baslik": "Rölenin süresi makinenin dayanma süresinin altında kalmalı", "x_ad": "Negatif bileşen I2 (% In)", "y_ad": "Süre (s)", "logy": True, "ymin": 0.1, "ymax": 1000,
         "seriler": [{"ad": "röle", "renk": "#dc2626", "pts": [[x, min(sure(x / 100, p), 1000)] for x in xs if sure(x / 100, p) < math.inf]},
                     {"ad": "makine dayanımı (I2²·t = K)", "renk": "#1a4d8f", "pts": [[x, min(num(p, "km", 20) / (x / 100) ** 2, 1000)] for x in xs if x > num(p, "i2s", 8)]}],
         "isaretler": [{"x": min(m2 * 100, 100), "etiket": "şu an"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["_46_"],
        "sahne": c.sahne(fazor=fazor), "grafikler": [g],
        "anlatim": [
            "Dengesiz üç akım, biri doğru yönde (pozitif), biri ters yönde (negatif) dönen iki dengeli takımın toplamı olarak yazılabilir. Röle faz akımlarından negatif takımın büyüklüğünü hesaplar.",
            "Negatif bileşen makinede rotora göre iki kat hızla döner; rotor yüzeyinde 100 Hz akımlar dolaştırır ve hızla ısıtır. Etkin değere bakan aşırı yük koruması bunu fark etmez.",
            f"Bu durumda I2 = %{fnum(m2 * 100, 0)} In. Bir faz koptuğunda kalan iki fazın akımı eşit ve zıt olur: negatif bileşen pozitife eşittir, yükün yarısı kadardır.",
            "Makinenin dayanımı (I2/In)²·t = K biçimindedir: dengesizlik iki katına çıkarsa dayanma süresi dörtte bire iner. Ters zamanlı karakteristik bu eğriyi izler.",
            "Şebekedeki iki fazlı arızalar da negatif bileşen üretir; süre, o arızaları temizleyen korumalardan uzun seçilir ki 46 gereksiz açmasın.",
        ],
        "dersler": [
            "Tek faza akım verirseniz I2 = I/3'tür: %20'lik başlatmayı tek fazda 0,60 × In ile yakalarsınız.",
            "Faz sırası ters bağlanmışsa bütün akım negatif bileşendir — devreye almada röle hemen başlıyorsa önce sıraya bakın.",
            "K2 makinenin sürekli dayanımının altına inmez; K1 makinenin K değerinin üstüne çıkmaz.",
        ],
        "tablolar": [{"baslik": "Duruma göre bileşenler (yük %" + fnum(num(p, "yuk", 80), 0) + ")", "cols": ["Durum", "I1", "I2", "I2/I1", "Röle"], "rows": [
            (lambda t3, ad: [ad, f"%{fnum(abs(t3[1]) * 100, 0)}", f"%{fnum(abs(t3[2]) * 100, 0)}", (f"%{fnum(abs(t3[2]) / abs(t3[1]) * 100, 0)}" if abs(t3[1]) > 1e-6 else "∞"), (fnum(sure(abs(t3[2]), p), 1) + " s") if sure(abs(t3[2]), p) < math.inf else "açmaz"])(simetrik(*akimlar({**p, "durum": dd})), DURUM[dd])
            for dd in DURUM]}],
    }
