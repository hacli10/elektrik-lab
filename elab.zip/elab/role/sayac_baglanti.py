"""Sayaç ve ölçü devresi bağlantı hataları: ters akım trafosu, yer değiştirmiş uçlar, eksik gerilim — sayacın (ve aynı devreden beslenen güç / yön
korumasının) gördüğü fazörler ve ölçtüğü güç.

Hesap temel bağıntıdır: üç elemanlı (dört telli) ölçmede P = Σ Re(Vk·Ik*); iki elemanlı (Aron, üç telli) ölçmede P = Re(V12·I1*) + Re(V32·I3*).
Hatalar, sayacın uçlarına gelen büyüklüklerin yer ya da yön değiştirmesi olarak uygulanır. Aron bağlantısı yalnız üç telli (toprak akımı olmayan)
sistemde doğrudur. Primer enjeksiyonla oran ve polarite doğrulaması: Elektrik Tesisleri Kabul Yön. m.28-D-6c."""
from __future__ import annotations

import cmath
import math

from .ortak import A, A120, C, Cizim, G, K, KABUL, S, T, aci, ctl, fazor, fnum, kutup, num, opt

ID = "sayac_baglanti"
BASLIK = "Sayaç ve ölçü devresi bağlantı hataları"
IKON = "🧮"
GIRIS = ("Bir akım trafosunun ters bağlanması ya da iki ucun yer değiştirmesi sayaçta arıza göstermez; sayaç çalışır, yalnız yanlış yazar. Aynı hata güç ve yön "
         "korumasını da yanıltır. Bir hata seçin; sayacın gördüğü fazörleri, her elemanın ölçtüğü gücü ve toplam hatayı izleyin.")
HATA = {"yok": "Doğru bağlantı", "at_ters": "L1 akım trafosu ters (S1–S2 yer değişmiş)", "akim_yer": "L1 ve L2 akım uçları yer değişmiş", "ger_sira": "L2 ve L3 gerilim uçları yer değişmiş",
        "ger_yok": "L1 gerilimi yok (sigorta atık / uç gevşek)", "akim_yok": "L1 akımı sayaca gelmiyor (klemens köprüsü kapalı)", "faz_kay": "Akımlar bir faz kaymış (L1 akımı L2 elemanında …)"}
BAG = {"uc": "Üç elemanlı (dört telli: 3 akım + 3 faz gerilimi)", "aron": "İki elemanlı (Aron, üç telli: L1 ve L3 akımı)"}

KONTROLLER = [
    ctl("bag", "Ölçme bağlantısı", "sec", "uc", secenek=opt(*BAG.items())),
    ctl("hata", "Bağlantı hatası", "sec", "yok", secenek=opt(*HATA.items())),
    ctl("i", "Yük akımı", "sayi", 0.8, min=0.05, max=1.2, adim=0.05, birim="×In"),
    ctl("cosfi", "Güç katsayısı", "sayi", 0.90, min=0.2, max=1.0, adim=0.01),
    ctl("tur", "Yükün türü", "sec", "ind", secenek=opt(("ind", "Endüktif (akım geride)"), ("kap", "Kapasitif (akım ileride)"))),
    ctl("yon", "Güç akışı", "sec", "tuk", secenek=opt(("tuk", "Tüketim (şebekeden tesise)"), ("ure", "Üretim (tesisten şebekeye)"))),
]


def olc(p: dict, hata: str | None = None) -> dict:
    hata = hata or (p.get("hata") if p.get("hata") in HATA else "yok")
    aron = p.get("bag") == "aron"
    i, cf = num(p, "i", 0.8), min(max(num(p, "cosfi", 0.9), 0.0), 1.0)
    fi = math.degrees(math.acos(cf)) * (1 if p.get("tur") != "kap" else -1)
    yon = 180 if p.get("yon") == "ure" else 0
    V = [kutup(1, 0), kutup(1, -120), kutup(1, 120)]
    I = [kutup(i, a - fi + yon) for a in (0, -120, 120)]
    gercek = sum((v * x.conjugate()) for v, x in zip(V, I))
    Vb, Ib = list(V), list(I)
    if hata == "at_ters":
        Ib[0] = -Ib[0]
    elif hata == "akim_yer":
        Ib[0], Ib[1] = Ib[1], Ib[0]
    elif hata == "ger_sira":
        Vb[1], Vb[2] = Vb[2], Vb[1]
    elif hata == "ger_yok":
        Vb[0] = 0j
    elif hata == "akim_yok":
        Ib[0] = 0j
    elif hata == "faz_kay":
        Ib = [Ib[2], Ib[0], Ib[1]]
    if aron:
        eleman = [(Vb[0] - Vb[1]) * Ib[0].conjugate(), (Vb[2] - Vb[1]) * Ib[2].conjugate()]
        gor_v = [Vb[0] - Vb[1], Vb[2] - Vb[1]]; gor_i = [Ib[0], Ib[2]]; adlar = ("V12·I1", "V32·I3")
    else:
        eleman = [v * x.conjugate() for v, x in zip(Vb, Ib)]
        gor_v, gor_i, adlar = Vb, Ib, ("L1", "L2", "L3")
    olculen = sum(eleman)
    return {"hata": hata, "aron": aron, "gercek": gercek, "olculen": olculen, "eleman": eleman, "adlar": adlar, "v": gor_v, "i": gor_i, "fi": fi, "oran": (round(olculen.real / gercek.real * 100, 6) + 0.0) if abs(gercek.real) > 1e-9 else 0.0}


def run(p: dict) -> dict:
    o = olc(p)
    P, Q = o["olculen"].real, o["olculen"].imag
    Pg, Qg = o["gercek"].real, o["gercek"].imag
    S_ = abs(o["olculen"])
    cf_o = P / S_ if S_ > 1e-9 else 0.0
    dogru = abs(o["oran"] - 100) < 1.0 and abs(Q - Qg) < 0.01 * max(abs(Qg), 0.05)
    ters_el = [o["adlar"][j] for j, e in enumerate(o["eleman"]) if (e.real < -1e-6) != (Pg < 0)]
    bos_el = [o["adlar"][j] for j, e in enumerate(o["eleman"]) if abs(e) < 1e-6]

    c = Cizim(900, 300)
    c.yazi(30, 36, BAG["aron" if o["aron"] else "uc"].split(" (")[0] + " ölçme", "#1e293b", 12.5, kalin=True)
    for j, (ad, e) in enumerate(zip(o["adlar"], o["eleman"])):
        x = 30 + j * 180
        durum = "gecersiz" if (ad in ters_el or ad in bos_el) else "normal"
        c.kutu(x, 56, 160, 62, f"{ad} elemanı", f"P = {fnum(e.real, 2)} · Q = {fnum(e.imag, 2)}", durum)
        c.yazi(x + 80, 136, "ters" if ad in ters_el else "boş" if ad in bos_el else "olağan", "#b91c1c" if durum == "gecersiz" else "#15803d", 11, kalin=True, anchor="middle")
    x0 = 600
    c.kutu(x0, 56, 270, 62, "Sayacın yazdığı", f"P = {fnum(P, 2)} · Q = {fnum(Q, 2)} (×Un·In)", "normal" if dogru else "gecersiz")
    c.yazi(30, 176, f"Gerçek güç: P = {fnum(Pg, 2)} · Q = {fnum(Qg, 2)} — cos φ = {fnum(num(p, 'cosfi', 0.9), 2)}", "#334155", 12)
    c.yazi(30, 200, f"Sayaç gerçeğin %{fnum(o['oran'], 0)}'ini yazıyor" + (" (yön ters!)" if o["oran"] < 0 else ""), "#15803d" if dogru else "#b91c1c", 14, kalin=True)
    c.yazi(30, 224, f"Sayacın gördüğü güç katsayısı {fnum(abs(cf_o), 2)}" + (" — gerçek değerden farklı" if abs(abs(cf_o) - num(p, "cosfi", 0.9)) > 0.02 else ""), "#334155", 12)
    c.yazi(30, 252, HATA[o["hata"]], "#b91c1c" if o["hata"] != "yok" else "#15803d", 12, kalin=True)
    c.yazi(30, 276, ("Belirti: " + (", ".join(ters_el) + " elemanı ters güç gösteriyor" if ters_el else "") + ("; " if ters_el and bos_el else "") + (", ".join(bos_el) + " elemanı boş" if bos_el else "")) if (ters_el or bos_el) else
           ("Belirti: elemanların gücü olağan görünüyor; hata yalnız fazör diyagramından anlaşılır" if not dogru else "Her eleman aynı yönde ve dengeli güç ölçüyor"), "#475569", 11.5)

    renk = ("#8a4b12", "#111827", "#6b7280")
    fv = [fazor(("V1", "V2", "V3")[j] if not o["aron"] else ("V12", "V32")[j], v, renk[j], kesik=True) for j, v in enumerate(o["v"])]
    fi_ = [fazor(("I1", "I2", "I3")[j] if not o["aron"] else ("I1", "I3")[j], x, ("#dc2626", "#b45309", "#15803d")[j]) for j, x in enumerate(o["i"])]
    f = {"baslik": "Sayacın uçlarında gördüğü fazörler", "vektorler": fv + fi_, "not": "Doğru bağlantıda her akım kendi geriliminden φ kadar geride (endüktif yük) durur ve üçü de aynı düzeni izler."}
    ozet = [
        K("Sayacın yazdığı / gerçek", f"%{fnum(o['oran'], 0)}", "ok" if dogru else "bad", "aktif enerji" + (" — eksik yazıyor" if 0 <= o["oran"] < 99 else " — fazla yazıyor" if o["oran"] > 101 else " — ters yazıyor" if o["oran"] < 0 else "")),
        K("Ölçülen aktif güç", f"{fnum(P, 2)}", "info", f"gerçek {fnum(Pg, 2)} (×Un·In)"),
        K("Ölçülen reaktif güç", f"{fnum(Q, 2)}", "info", f"gerçek {fnum(Qg, 2)}"),
        K("Sayacın gördüğü cos φ", f"{fnum(abs(cf_o), 2)}", "ok" if abs(abs(cf_o) - num(p, "cosfi", 0.9)) <= 0.02 else "warn", f"gerçek {fnum(num(p, 'cosfi', 0.9), 2)}"),
        K("Belirti veren eleman", ", ".join(ters_el + bos_el) or "yok", "ok" if not (ters_el or bos_el) else "warn", "ters ya da boş ölçen eleman"),
    ]
    kontroller = [
        C("Sayaç doğru ölçüyor mu?", f"ölçülen P = {fnum(P, 2)}; gerçek {fnum(Pg, 2)}", "oran %100", dogru, "Güç, her elemanın kendi gerilimi ile kendi akımının çarpımlarının toplamıdır; uçlardan biri yer ya da yön değiştirirse toplam bozulur", "hesap"),
        C("Bütün elemanlar aynı yönde güç ölçüyor mu?", (", ".join(ters_el) + " ters") if ters_el else "hepsi aynı yönde", "dengeli yükte her eleman aynı işaretli güç ölçer", not ters_el if not o["aron"] else None,
          "Üç elemanlı ölçmede tek tek eleman güçleri en kolay tanı aracıdır. Aron bağlantısında bir elemanın gücü, cos φ < 0,5 iken doğru bağlantıda da negatif olur", "hesap"),
        C("Güç ve yön koruması aynı devreden besleniyorsa", "aynı hata röleyi de yanıltır" if not dogru else "etkilenmez", "yük altında yön testi", None,
          "Ters akım trafosu, yönlü aşırı akım ve ters güç rölesinde yönü çevirir; devreye almada yük akımıyla fazör kontrolü yapılır — " + KABUL, "resmi"),
    ]
    girdiler = [
        G("Bağlantı şeması ve klemens planı", BAG["aron" if o["aron"] else "uc"].split(" (")[0], "Ölçü hücresi / pano projesi", "Hangi akımın hangi gerilimle eşleştiği buradan izlenir", "uçtan uca süreklilik"),
        G("Akım ve gerilim trafosu oranları ve polariteleri", "P1/S1 yönü, faz sırası", "Etiketler; primer enjeksiyon kayıtları", "Tek bir ters uç gücün işaretini çevirir", "polarite testi"),
        G("O andaki yükün yönü ve yaklaşık güç katsayısı", f"cos φ {fnum(num(p, 'cosfi', 0.9), 2)} · {'tüketim' if p.get('yon') != 'ure' else 'üretim'}", "İşletme bilgisi; başka bir ölçü aleti", "Fazör diyagramı ancak beklenen açı bilinirse yorumlanır", "akımın gerilime göre beklenen yeri"),
    ]
    adimlar = [
        A("Gerçek güç", "P = 3·U·I·cos φ ;  Q = 3·U·I·sin φ", f"3 × {fnum(num(p, 'i', 0.8), 2)} × {fnum(num(p, 'cosfi', 0.9), 2)}", f"P = {fnum(Pg, 2)} · Q = {fnum(Qg, 2)}", "dengeli üç fazlı güç", "hesap", ["O andaki yükün yönü ve yaklaşık güç katsayısı"]),
        A("Her elemanın ölçtüğü", "Pk = Re(Vk · Ik*)" if not o["aron"] else "P = Re(V12·I1*) + Re(V32·I3*)", "sayacın uçlarına gelen büyüklüklerle", " · ".join(f"{ad}: {fnum(e.real, 2)}" for ad, e in zip(o["adlar"], o["eleman"])), "güç ölçme bağıntısı", "hesap", ["Bağlantı şeması ve klemens planı"]),
        A("Toplam ve hata", "ölçülen / gerçek", f"{fnum(P, 2)} / {fnum(Pg, 2)}", f"%{fnum(o['oran'], 0)}", "oran", "hesap"),
    ]
    ayarlar = [
        S("Sayaç / röle › faz sırası ve güç yönü göstergeleri", "izlenir", "—", "Çoğu elektronik sayaç ve röle ters faz sırasını ve eleman bazında güç yönünü gösterir", "cihazın ölçüm ekranı", "ikincil"),
        S("Röle › ölçüm ekranında fazör görünümü", "devreye almada kaydedilir", "—", "Akımların gerilimlere göre açısı, beklenen yük açısıyla karşılaştırılır", "devreye alma uygulaması", "ikincil"),
    ]
    test = [
        T("Polarite ve oran (primer enjeksiyon)", "Her faz için primerden akım geçirilir", "Sekonderde doğru fazda, doğru yönde ve doğru oranda akım", KABUL),
        T("Yük altında fazör kontrolü", "Tesis yük altındayken akım ve gerilim açıları okunur", f"Her akım kendi geriliminden {fnum(abs(o['fi']), 0)}° {'geride' if o['fi'] >= 0 else 'ileride'}", "üç faz aynı düzende"),
        T("Eleman güçleri", "Sayaç / röle ekranında faz bazında aktif güç", "Üçü de aynı işaretli ve birbirine yakın", "biri ters ya da sıfırsa o fazın devresi incelenir"),
        T("Karşılaştırma", "Kısa süreli enerji, başka bir ölçü noktasıyla karşılaştırılır", "Fark sınıf doğruluğu içinde", "trafo kaybı ve ölçü noktası farkı hesaba katılır"),
    ]
    rows = []
    for h_ in HATA:
        oo = olc(p, h_)
        rows.append([HATA[h_], f"%{fnum(oo['oran'], 0)}", " · ".join(fnum(e.real, 2) for e in oo["eleman"]), "ters yazar" if oo["oran"] < 0 else "doğru" if abs(oo["oran"] - 100) < 1 else "eksik yazar" if oo["oran"] < 100 else "fazla yazar"])
    cosler = [0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 1.0]
    g = {"baslik": "Hatanın büyüklüğü güç katsayısına göre", "x_ad": "Güç katsayısı", "y_ad": "Sayacın yazdığı / gerçek (%)",
         "seriler": [{"ad": HATA[h_].split(" (")[0], "renk": r_, "pts": [[cf, round(max(min(olc({**p, "cosfi": cf}, h_)["oran"], 250), -250), 1)] for cf in cosler]}
                     for h_, r_ in (("at_ters", "#dc2626"), ("akim_yer", "#b45309"), ("faz_kay", "#1a4d8f"), ("ger_yok", "#15803d"))],
         "yatay": [{"y": 100, "etiket": "doğru", "renk": "#64748b"}], "isaretler": [{"x": num(p, "cosfi", 0.9), "etiket": "şu an"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": [], "sahne": c.sahne(fazor=f), "grafikler": [g],
        "cubuklar": [{"baslik": "Elemanların ölçtüğü aktif güç", "kategoriler": list(o["adlar"]) + ["toplam", "gerçek"], "alt": ["eleman"] * len(o["adlar"]) + ["sayaç", "olması gereken"], "y_ad": "×Un·In (mutlak)",
                      "seriler": [{"ad": "aktif güç", "renk": "#1a4d8f", "deger": [round(abs(e.real), 3) for e in o["eleman"]] + [round(abs(P), 3), round(abs(Pg), 3)]}]}],
        "anlatim": [
            "Sayaç her faz için gerilimle akımı çarpar ve toplar. Gücün işareti, akımın gerilime göre açısından gelir: akım gerilimle aynı yöndeyse tüketim, zıt yöndeyse üretim.",
            "Bir akım trafosunun sekonder uçları ters bağlanırsa o fazın akımı 180° döner: o eleman aynı gücü eksi işaretle ölçer. Dengeli yükte toplam, +1 +1 −1 = üçte bir olur; sayaç tüketimin yalnız üçte birini yazar.",
            "İki akım ucu (ya da iki gerilim ucu) yer değiştirirse iki eleman yanlış fazın akımını kendi gerilimiyle çarpar: açılar 120° kayar. Dengeli yükte bu iki elemanın gücü üçüncüyü tam götürür: toplam sıfırdır, sayaç yük varken durur. Akımların üçü birden bir faz kayarsa toplam, güç katsayısına göre küçük, sıfır ya da ters çıkar.",
            "Bir gerilim eksikse o eleman hiçbir şey ölçmez: dengeli yükte sayaç üçte iki yazar. Sayaç çalışmaya devam ettiği için eksiklik fark edilmeyebilir.",
            "İki elemanlı (Aron) bağlantı üç telli sistemde doğru ölçer, ama tanısı zordur: doğru bağlantıda bile iki eleman farklı güç ölçer ve cos φ 0,5'in altındayken biri negatif olur.",
            "Aynı akım ve gerilim devresinden beslenen güç ve yön koruması da aynı fazörleri görür: ters akım trafosu, ters güç rölesini tüketimde açtırır, yönlü aşırı akım rölesini arızada kör eder.",
        ],
        "dersler": [
            "Bağlantı hatalı sayaç durmaz, yanlış yazar: hata fatura ya da mahsuplaşma karşılaştırmasında ortaya çıkar.",
            "Ters bir akım trafosu: sayaç üçte bir yazar. Eksik bir gerilim: üçte iki yazar. İkisi de güç katsayısından bağımsızdır.",
            "İki uç yer değiştirdiyse dengeli yükte sayaç sıfır yazar; üç akım birden kaydıysa hata güç katsayısıyla değişir. İkisi de fazör diyagramıyla bulunur.",
            "Devreye almada yük altında fazör kontrolü hem sayacı hem yön korumasını doğrular.",
        ],
        "tablolar": [{"baslik": "Bu yükte her hatanın sonucu", "cols": ["Hata", "Sayacın yazdığı / gerçek", "Eleman güçleri", "Sonuç"], "rows": rows,
                      "not": "Dengeli yük için. Bir faz kaymış akımlarda oran güç katsayısına göre değişir (grafiğe bakın); dengesiz yükte bütün oranlar değişir."}],
    }
