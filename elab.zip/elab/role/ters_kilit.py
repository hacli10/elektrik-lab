"""Ters kilitleme (kilitlemeli aşırı akım / mantıksal seçicilik, ANSI 68): fider rölesinin başlatma işaretiyle giriş rölesinin hızlı kademesini
kilitleyerek bara arızasını zaman kademelendirmesini beklemeden temizlemek.

Dayanak: GE MiCOM P14D (P14DEd2-TM-EN-11.2) böl. 14 «Blocked Overcurrent Protection» — giriş fiderindeki hızlı eleman, çıkış fiderlerinin başlatma
kontaklarıyla kilitlenir; bara arızasında kilit gelmez ve hızlı eleman açar; başlatma işareti kesici arıza alarmıyla kaldırılabilir (böl. 14.2).
Schneider Sepam series 60 (SEPED310017EN) «Logic discrimination»: mantıksal eşikler kilit işareti gönderir ve kilitle durdurulabilir; zaman esaslı
eşikler kilitlenemez ve yedektir; kilit işareti arıza temizlenene kadar sürer, açma komutundan sonra kesici süresi ve bırakma süresi kadar sonra kesilir;
bozuk kablo ya da donanım durumunda güvenliği yedek eşikler sağlar. Süreler (başlatma 30 ms, işaret iletimi 10 ms, kesici 60 ms) tipiktir (tahmini)."""
from __future__ import annotations

from .ortak import A, C, Cizim, G, K, S, T, URRA, ctl, fnum, num, opt
from .roleler import P14D, SEPAM

ID = "ters_kilit"
BASLIK = "Ters kilitleme (bara koruması)"
IKON = "🔒"
GIRIS = ("Zaman kademelendirmesinde kaynağa en yakın röle en uzun bekler; oysa en büyük arıza akımı oradadır. Ters kilitlemede fider rölesi arızayı görünce giriş "
         "rölesine «bende, bekle» der. İşaret gelmezse arıza baradadır ve giriş rölesi beklemeden açar. Arızanın yerini ve işaret devresinin durumunu "
         "değiştirin; hangi kesicinin ne zaman açtığını izleyin.")
YER = {"fider": "Çıkış fiderinde (1. fider)", "bara": "Barada", "yok": "Arıza yok, yük akıyor"}
HATA = {"yok": "Yok", "kopuk": "Kilit kablosu kopuk (işaret ulaşmıyor)", "yapisik": "Kilit girişi sürekli etkin (kablo kısa devre / kontak yapışık)", "esik": "Fider rölesinin başlatması arıza akımının üstünde", "kesici": "Fider kesicisi açmıyor (kesici arızası)"}
T_BASLA, T_ILET, T_CB = 0.03, 0.01, 0.06

KONTROLLER = [
    ctl("yer", "Arızanın yeri", "sec", "bara", secenek=opt(*YER.items())),
    ctl("hata", "İşaret devresinde / donanımda hata", "sec", "yok", secenek=opt(*HATA.items())),
    ctl("ik", "Arıza akımı", "sayi", 6000, min=500, max=25000, adim=100, birim="A"),
    ctl("i_g", "Giriş rölesi › I>> (hızlı, kilitlenebilir)", "sayi", 1200, min=200, max=10000, adim=50, birim="A"),
    ctl("t_h", "Giriş rölesi › tI>> (hızlı kademe)", "sayi", 0.10, min=0.03, max=0.5, adim=0.01, birim="s", yardim="Kilit işaretinin gelmesine yetecek kadar: başlatma + iletim süresinden uzun"),
    ctl("t_y", "Giriş rölesi › tI> (yedek, zaman kademeli)", "sayi", 0.70, min=0.2, max=2.0, adim=0.05, birim="s"),
    ctl("i_f", "Fider rölesi › I> başlatma", "sayi", 600, min=100, max=8000, adim=50, birim="A"),
    ctl("t_f", "Fider rölesi › tI>", "sayi", 0.30, min=0.05, max=1.5, adim=0.05, birim="s"),
    ctl("bf", "Kesici arızasında kilit kaldırılıyor (50BF)", "onay", True),
    ctl("t_bf", "50BF süresi", "sayi", 0.20, min=0.1, max=0.6, adim=0.01, birim="s", goster={"bf": [True]}),
]


def benzet(p: dict) -> dict:
    """Olay sırası (s): kim başladı, kilit geldi mi, hangi kesici ne zaman açtı."""
    yer = p.get("yer") if p.get("yer") in YER else "bara"
    hata = p.get("hata") if p.get("hata") in HATA else "yok"
    ik, i_g, i_f = num(p, "ik", 6000), num(p, "i_g", 1200), num(p, "i_f", 600)
    t_h, t_y, t_f, t_bf = num(p, "t_h", 0.1), num(p, "t_y", 0.7), num(p, "t_f", 0.3), num(p, "t_bf", 0.2)
    bf = bool(p.get("bf", True))
    olay = []
    ariza = yer != "yok"
    fider_gorur = yer == "fider" and ik >= i_f and hata != "esik"
    giris_gorur = ariza and ik >= i_g
    kilit_basla = None
    if hata == "yapisik":
        kilit_basla = -1.0
    elif fider_gorur and hata != "kopuk":
        kilit_basla = T_BASLA + T_ILET
    fider_acma = t_f + T_BASLA if fider_gorur else None                     # açma komutu
    fider_temiz = (fider_acma + T_CB) if (fider_acma is not None and hata != "kesici") else None
    kilit_bitis = None
    if kilit_basla is not None and hata != "yapisik":
        if hata == "kesici":
            kilit_bitis = (fider_acma + t_bf) if bf else None               # 50BF çalışınca başlatma işareti kaldırılır
        else:
            kilit_bitis = fider_temiz + 0.04                                  # arıza temizlenince başlatma bırakır (bırakma süresi)
    # giriş rölesi hızlı kademe: başlatmadan t_h sonra, o anda kilit yoksa açar; kilit kalkarsa süre yeniden sayılır
    giris_hizli = None
    if giris_gorur:
        t0 = T_BASLA
        if kilit_basla is None or kilit_basla > t0 + t_h:
            giris_hizli = t0 + t_h
        elif kilit_bitis is not None and (fider_temiz is None or kilit_bitis < fider_temiz):
            giris_hizli = kilit_bitis + t_h                                   # arıza sürüyor, kilit kalktı
    giris_yedek = (T_BASLA + t_y) if giris_gorur and (fider_temiz is None or fider_temiz > T_BASLA + t_y) else None
    adaylar = [t for t in (giris_hizli, giris_yedek) if t is not None and (fider_temiz is None or t < fider_temiz)]
    giris_acma = min(adaylar) if adaylar else None
    giris_temiz = giris_acma + T_CB if giris_acma is not None else None
    if giris_temiz is not None and fider_acma is not None and giris_temiz <= fider_acma:
        fider_acma = fider_temiz = None                                    # giriş kesicisi arızayı önce temizledi: fider rölesi süresini dolduramaz
    temiz = min([t for t in (fider_temiz, giris_temiz) if t is not None], default=None)
    return {"yer": yer, "hata": hata, "fider_gorur": fider_gorur, "giris_gorur": giris_gorur, "kilit": (kilit_basla, kilit_bitis), "fider_acma": fider_acma, "fider_temiz": fider_temiz,
            "giris_hizli": giris_hizli, "giris_yedek": giris_yedek, "giris_acma": giris_acma, "giris_temiz": giris_temiz, "temiz": temiz, "hizli_mi": giris_acma is not None and giris_acma == giris_hizli, "olay": olay}


def run(p: dict) -> dict:
    b = benzet(p); yer, hata = b["yer"], b["hata"]
    t_h, t_y, t_f = num(p, "t_h", 0.1), num(p, "t_y", 0.7), num(p, "t_f", 0.3)
    giris_acti = b["giris_temiz"] is not None; fider_acti = b["fider_temiz"] is not None
    # doğru davranış: fider arızası → yalnız fider kesicisi; bara arızası → giriş kesicisi, hızlı kademeyle; arıza yok → hiçbiri
    if yer == "fider":
        dogru = fider_acti and not giris_acti if hata != "kesici" else giris_acti
    elif yer == "bara":
        dogru = giris_acti and b["hizli_mi"]
    else:
        dogru = not giris_acti and not fider_acti
    klasik = (0.03 + t_y + T_CB) if yer == "bara" else None
    ms = lambda t: f"{fnum(t * 1000, 0)} ms" if t is not None else "—"        # noqa: E731

    c = Cizim(900, 320)
    c.kutu(360, 16, 180, 40, "Kaynak (trafo)", "")
    c.hat("M450,56 V84", "L1", hot=yer != "yok" or True, w=3)
    c.dikdortgen(440, 84, 20, 20, "ariza" if giris_acti else "cizgi", dolgu="#fee2e2" if giris_acti else "#fff"); c.yazi(430, 98, "giriş kesicisi" + (" (açtı)" if giris_acti else ""), "#b91c1c" if giris_acti else "#475569", 10, anchor="end")
    c.hat("M450,104 V140", "L1", hot=True, w=3)
    c.hat("M150,140 H750", "cizgi", w=6); c.yazi(760, 144, "bara", "#475569", 10.5)
    c.kutu(520, 70, 200, 44, "Giriş rölesi", ("hızlı kademe AÇTI" if b["hizli_mi"] else "yedek kademe AÇTI") if giris_acti else ("kilitli — bekliyor" if b["kilit"][0] is not None and b["giris_gorur"] else "başlamadı" if not b["giris_gorur"] else "bekliyor"),
           ("acti" if dogru else "gecersiz") if giris_acti else "normal")
    xs = (230, 450, 670)
    for j, x in enumerate(xs):
        sicak = (j == 0 and yer == "fider") or yer == "yok"
        acti = j == 0 and fider_acti
        c.hat(f"M{x},140 V176", "L1", hot=sicak, w=2.6)
        c.dikdortgen(x - 10, 176, 20, 20, "ariza" if acti else "cizgi", dolgu="#fee2e2" if acti else "#fff")
        c.hat(f"M{x},196 V268", "L1", hot=sicak, w=2.6)
        c.kutu(x - 100, 206, 84, 40, f"{j + 1}. fider", ("AÇTI" if acti else "başladı" if (j == 0 and b["fider_gorur"]) else "—"), "acti" if acti else "vurgu" if (j == 0 and b["fider_gorur"]) else "normal")
    if yer == "fider":
        c.simsek(xs[0] - 8, 262, 1.2); c.toprak(xs[0], 282, "ariza"); c.yazi(xs[0] + 14, 284, "arıza", "#b91c1c", 11, kalin=True)
    elif yer == "bara":
        c.simsek(300, 124, 1.3); c.yazi(322, 128, "bara arızası", "#b91c1c", 11, kalin=True)
    kilit_var = b["kilit"][0] is not None
    c.hat(f"M{xs[0] - 100},226 H104 V92 H520", "mor" if kilit_var else "soluk", hot=kilit_var, kesik=True, w=1.6, hot_renk="mor")
    c.yazi(112, 86, "kilit işareti" + (" (kopuk)" if hata == "kopuk" else " (sürekli etkin)" if hata == "yapisik" else ""), "#6d28d9" if kilit_var else "#94a3b8", 10)
    c.yazi(20, 308, ("Arıza " + ms(b["temiz"]) + "'de temizlendi" if b["temiz"] is not None else "Açma yok") + (f" — zaman kademelendirmesiyle {ms(klasik)} sürerdi" if klasik and giris_acti and b["hizli_mi"] else ""),
           "#15803d" if dogru else "#b91c1c", 12.5, kalin=True)

    ozet = [
        K("Sonuç", "doğru" if dogru else "YANLIŞ", "ok" if dogru else "bad", {"fider": "fider arızasında yalnız fider kesicisi açmalı", "bara": "bara arızasında giriş kesicisi hızlı açmalı", "yok": "arıza yokken kimse açmamalı"}[yer]),
        K("Arızanın temizlenme süresi", ms(b["temiz"]), "ok" if (b["temiz"] or 9) <= 0.2 or yer != "bara" else "warn", f"zaman kademelendirmesiyle {ms(klasik)}" if klasik else "—"),
        K("Giriş kesicisi", ("açtı — " + ("hızlı kademe" if b["hizli_mi"] else "yedek kademe")) if giris_acti else "açmadı", "info", ms(b["giris_temiz"])),
        K("1. fider kesicisi", "açtı" if fider_acti else "açmadı", "info", ms(b["fider_temiz"])),
        K("Kilit işareti", "geldi" if kilit_var else "gelmedi", "info", (f"{ms(b['kilit'][0])} → {ms(b['kilit'][1])}" if kilit_var and hata != "yapisik" else "sürekli" if hata == "yapisik" else "fider rölesi başlamadı")),
    ]
    kontroller = [
        C("Seçicilik ve hız sağlanıyor mu?", (f"giriş {ms(b['giris_temiz'])}" if giris_acti else "giriş açmadı") + " · " + (f"fider {ms(b['fider_temiz'])}" if fider_acti else "fider açmadı"),
          {"fider": "yalnız fider kesicisi", "bara": "giriş kesicisi, hızlı kademeyle", "yok": "açma yok"}[yer], dogru,
          "Çıkış fiderlerinin başlatma işaretleri giriş rölesinin hızlı elemanını kilitler; bara arızasında kilit gelmez ve hızlı eleman açar — " + P14D + " böl. 14", "resmi"),
        C("Hızlı kademenin süresi kilide yetiyor mu?", f"tI>> = {fnum(t_h * 1000, 0)} ms; kilit {fnum((T_BASLA + T_ILET) * 1000, 0)} ms'de ulaşır", "tI>> > fider başlatma + iletim süresi (pay ile ≥ 50–100 ms)", t_h >= T_BASLA + T_ILET + 0.02,
          "Hızlı kademe, fider rölesinin başlatıp kilit işaretini iletmesine yetecek kadar geciktirilir; yoksa fider arızasında giriş de açar. Süreler tipik", "tahmini"),
        C("Yedek kademe fider korumasını bekliyor mu?", f"giriş tI> = {fnum(t_y, 2)} s; fider {fnum(t_f, 2)} s + kesici {fnum(T_CB * 1000, 0)} ms", "tI>(giriş) ≥ tI>(fider) + 0,3 s", t_y >= t_f + 0.3,
          "Kilitlenemeyen zaman esaslı eşikler mantıksal eşiklerin yedeğidir; kablo ya da donanım bozulduğunda güvenliği bunlar sağlar — " + SEPAM + " «Logic discrimination»", "resmi"),
        C("Kesici arızasında kilit kalkıyor mu?", "50BF başlatma işaretini kaldırıyor" if p.get("bf", True) else "kaldırmıyor: giriş yedek kademeyi bekler", "kilit, kesici arızası alarmıyla kaldırılmalı", bool(p.get("bf", True)),
          "Başlatma işareti kesici arıza alarmıyla kapatılabilir («Remove I> Start» ayarı): fider kesicisi açamazsa giriş rölesinin hızlı kademesi serbest kalır — " + P14D + " böl. 14.2", "resmi"),
    ]
    girdiler = [
        G("Baradaki ve fider sonundaki arıza akımları", f"{fnum(num(p, 'ik', 6000), 0)} A", "Kısa devre hesabı", "Giriş rölesinin hızlı kademesi bara arızasını, fider rölelerinin başlatması fider sonundaki en küçük arızayı görmeli", "I>> (giriş) ve I> (fider) eşikleri"),
        G("Fider rölelerinin başlatma süresi ve çıkış kontağı", "tipik 20–40 ms", "Röle kılavuzu («start time»); çıkış rölesinin tipi", "Kilit işaretinin ne kadar sürede ulaştığını belirler", "tI>> (giriş) bu süreden uzun olmalı"),
        G("Kilit devresinin şeması", "bütün fider rölelerinin başlatma kontakları → giriş rölesinin kilit girişi", "Sekonder proje (kablolu) ya da haberleşme mantığı", "Bir fiderin kontağı eksikse o fiderdeki arızada giriş de açar", "devreye almada her fider ayrı denenir"),
        G("Kesici süreleri ve 50BF ayarı", f"kesici {fnum(T_CB * 1000, 0)} ms · 50BF {fnum(num(p, 't_bf', 0.2) * 1000, 0)} ms", "Kesici test raporu; ayar föyü", "Kilit süresiz kalırsa kesici arızasında bara korumasız kalır", "kilidin kaldırılma koşulu"),
    ]
    adimlar = [
        A("Kilit işaretinin ulaşma süresi", "t = fider başlatma + iletim", f"{fnum(T_BASLA * 1000, 0)} + {fnum(T_ILET * 1000, 0)} ms", ms(T_BASLA + T_ILET), "röle başlatma süresi ve çıkış kontağı (tipik)", "tahmini", ["Fider rölelerinin başlatma süresi ve çıkış kontağı"]),
        A("Giriş rölesinin hızlı kademesi", "tI>> ≥ kilit süresi + pay", f"{ms(T_BASLA + T_ILET)} + pay", f"{fnum(t_h * 1000, 0)} ms", P14D + " böl. 14", "resmi", [], "tI>> (giriş)"),
        A("Bara arızasının temizlenmesi", "başlatma + tI>> + kesici", f"{fnum(T_BASLA * 1000, 0)} + {fnum(t_h * 1000, 0)} + {fnum(T_CB * 1000, 0)} ms", ms(T_BASLA + t_h + T_CB), "olay sırası", "hesap", ["Kesici süreleri ve 50BF ayarı"]),
        A("Aynı arıza zaman kademelendirmesiyle", "başlatma + tI> + kesici", f"{fnum(T_BASLA * 1000, 0)} + {fnum(t_y * 1000, 0)} + {fnum(T_CB * 1000, 0)} ms", ms(T_BASLA + t_y + T_CB), "olay sırası", "hesap"),
    ]
    ayarlar = [
        S("Giriş › I>> (kilitlenebilir hızlı kademe)", f"{fnum(num(p, 'i_g', 1200), 0)} A · {fnum(t_h * 1000, 0)} ms", "—", "Bara arızasını görür; fider rölelerinin başlatma işaretiyle kilitlenir", P14D + " böl. 14.1"),
        S("Giriş › I> (yedek, kilitlenemez)", f"{fnum(t_y, 2)} s", "—", "Kilit devresi bozulduğunda ve kesici arızasında son güvence", SEPAM + " «Logic discrimination»"),
        S("Fider › başlatma çıkışı → kilit girişi", "I> başlatma (bütün kademeler)", "—", "Açma değil başlatma işareti gönderilir: gecikmesiz olmalı", P14D + " böl. 14.1"),
        S("Fider › başlatmayı kesici arızasında kaldır", "etkin" if p.get("bf", True) else "kapalı", "—", "Fider kesicisi açamazsa giriş rölesinin kilidi çözülür", P14D + " böl. 14.2"),
        S("Seçicilik payı", "0,3 s (zaman esaslı kademeler arası)", "—", "Kesici süresi + rölenin taşma süresi + hata payı", URRA, "ikincil"),
    ]
    test = [
        T("Bara arızası", "Yalnız giriş rölesine arıza akımı; fider röleleri akımsız", f"Giriş {fnum(t_h * 1000, 0)} ms'de açar", "hızlı kademe"),
        T("Fider arızası", "Giriş ve bir fider rölesine aynı anda arıza akımı", f"Fider {fnum(t_f, 2)} s'de açar; giriş açmaz", "her fider için ayrı ayrı yinelenir"),
        T("Kilit kablosu", "Kilit kablosu sökülüp fider arızası yinelenir", "Giriş hızlı kademeyle açar (beklenen kusur davranışı): kablonun işlevi böyle doğrulanır", "sonra kablo geri takılır"),
        T("Kesici arızası", "Fider açma devresi kesilip fider arızası yinelenir", f"50BF süresi sonunda kilit kalkar, giriş açar", "kilit kaldırma mantığı"),
    ]
    son = max(1.0, (b["temiz"] or 0) + 0.15)
    ts = [j * 0.005 for j in range(int(son / 0.005) + 1)]
    def iz(basla, bitis, taban):                                               # noqa: E306
        return [[round(t, 3), taban + (0.8 if (basla is not None and t >= basla and (bitis is None or t < bitis)) else 0.0)] for t in ts]
    g = {"baslik": "Olay sırası", "x_ad": "Zaman (s) — arıza t = 0'da", "y_ad": "işaretler (her satır bir işaret)", "ymin": 0, "ymax": 5.2,
         "seriler": [{"ad": "fider başlatma", "renk": "#1a4d8f", "pts": iz(T_BASLA if b["fider_gorur"] else None, b["fider_temiz"] + 0.04 if b["fider_temiz"] else None, 4)},
                     {"ad": "kilit girişi", "renk": "#6d28d9", "pts": iz(None if b["kilit"][0] is None else max(b["kilit"][0], 0), b["kilit"][1], 3)},
                     {"ad": "giriş başlatma", "renk": "#b45309", "pts": iz(T_BASLA if b["giris_gorur"] else None, b["temiz"] + 0.04 if b["temiz"] else None, 2)},
                     {"ad": "fider açma", "renk": "#15803d", "pts": iz(b["fider_acma"], None, 1)},
                     {"ad": "giriş açma", "renk": "#dc2626", "pts": iz(b["giris_acma"], None, 0)}],
         "isaretler": [{"x": round(b["temiz"], 3), "etiket": "arıza temizlendi"}] if b["temiz"] is not None else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["50-51"], "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Işınsal şebekede seçicilik süreyle sağlanır: fider rölesi 0,3 s'de, giriş rölesi 0,6–0,7 s'de açar. Bara arızasını yalnız giriş rölesi görür ve en uzun süreyi bekler — arıza akımının en büyük olduğu yerde.",
            "Ters kilitleme bu beklemeyi kaldırır. Giriş rölesine ikinci, hızlı bir kademe eklenir. Bu kademe arızayı görür görmez saymaya başlar, ama fider rölelerinden biri «arızayı ben de görüyorum» derse durur.",
            "Fider arızasında fider rölesi de başlar ve kilit işaretini gönderir: giriş rölesinin hızlı kademesi kilitlenir, fider kendi süresinde açar. Giriş rölesinin yedek kademesi her ihtimale karşı saymayı sürdürür.",
            f"Bara arızasında hiçbir fider rölesi akım görmez; kilit gelmez. Hızlı kademe {fnum(t_h * 1000, 0)} ms sonra açar: arıza {ms(T_BASLA + t_h + T_CB)}'de temizlenir, zaman kademelendirmesindeki {ms(T_BASLA + t_y + T_CB)} yerine.",
            "Düzenin zayıf noktası işaret devresidir. Kablo koparsa fider arızasında giriş de açar (seçicilik kaybolur ama arıza temizlenir). Kilit girişi sürekli etkin kalırsa hızlı kademe hiç açamaz; bara arızası yedek kademeye kalır.",
            "Fider kesicisi açamazsa fider rölesi başlatmayı sürdürür ve kilit kalkmaz. Bunun için kesici arızası alarmı başlatma işaretini keser: giriş rölesi serbest kalır ve barayı boşaltır.",
        ],
        "dersler": [
            "Ters kilitleme ayrı bir bara koruması değildir; var olan rölelerin başlatma işaretleriyle kurulur.",
            "Kilitleyen işaret açma değil başlatmadır: gecikmesiz gelmeli ve arıza sürdükçe kalmalıdır.",
            "Hızlı kademe sıfıra ayarlanmaz: kilidin ulaşması için 50–100 ms bırakılır.",
            "Yedek zaman kademeleri kaldırılmaz: işaret devresi bozulduğunda geriye kalan tek koruma onlardır.",
        ],
        "tablolar": [{"baslik": "Her durumda ne olur (bu ayarlarla)", "cols": ["Arıza yeri", "Hata", "Giriş kesicisi", "Fider kesicisi", "Temizleme"],
                      "rows": [[YER[y_].split(" (")[0], HATA[h_].split(" (")[0], (("hızlı " if bb["hizli_mi"] else "yedek ") + ms(bb["giris_temiz"])) if bb["giris_temiz"] is not None else "açmaz", ms(bb["fider_temiz"]) if bb["fider_temiz"] is not None else "açmaz", ms(bb["temiz"])]
                               for y_, h_ in (("bara", "yok"), ("fider", "yok"), ("fider", "kopuk"), ("bara", "yapisik"), ("fider", "esik"), ("fider", "kesici")) for bb in [benzet({**p, "yer": y_, "hata": h_})]]}],
    }
