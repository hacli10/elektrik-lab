"""Gerilime bağlı aşırı akım koruması (ANSI 51V) — Easergy P3 «IV>» kademesi.

Dayanak: P3U/en M/J006 böl. 5.24 (uyartımı yalnız kendi uçlarından beslenen jeneratörlerin kısa devre koruması; yakın kısa devrede arıza akımı hızla düşer ve yüksek ayarlı
aşırı akım kademesinin çalışmasını tehlikeye atar; kademe sabit zamanlıdır; gerilim tutuculu: başlatma akımı, denetim gerilimi — pozitif bileşen gerilimi V1 — ayarlı
düzeyin altına indikçe doğrusal olarak düşer; gerilim denetimli: VX1 = VX2 seçilirse basamaklı; IY1 = IY2 = %100 ise olağan aşırı akım kademesi gibi çalışır),
Çizelge 73 (IV> 0,50–4,00 ×IGN; VX1, VX2 %0–150; IY1, IY2 %0–200 IV>; süre 0,08–300 s; başlatma süresi ≈ 60 ms; bırakma oranı 0,97; doğruluk ±%3).
Jeneratörün sürekli kısa devre akımı üretici verisidir; buradaki değerler tipiktir — «tahmini»."""
from __future__ import annotations

from .ortak import A, C, G, K, P3U, S, T, ctl, fnum, num, opt, tek_hat

ID = "gerilim51v"
BASLIK = "Gerilime bağlı aşırı akım (51V)"
IKON = "📉"
GIRIS = ("Jeneratörün yakınındaki kısa devrede akım ilk anda büyüktür, sonra hızla düşer; uyartım kendi uçlarından besleniyorsa anma akımının altına bile inebilir. "
         "Olağan aşırı akım rölesi bu akımı yük sanır. Ama arızada gerilim çökmüştür: 51V eşiği gerilime bağlar — gerilim düştükçe eşik de düşer.")

DURUM = {"yuk": "Tam yük (gerilim normal)", "asiri": "Aşırı yük (gerilim biraz düşük)", "ilk": "Yakın kısa devre — ilk an", "surekli": "Yakın kısa devre — sürekli durum (akım düşmüş)", "uzak": "Uzak kısa devre"}
NOKTA = {"yuk": (100, 1.0), "asiri": (93, 1.3), "ilk": (15, 4.5), "surekli": (12, 0.8), "uzak": (70, 1.6)}        # (U1 %, I ×In) — tipik

KONTROLLER = [
    ctl("durum", "Durum", "sec", "surekli", secenek=opt(*DURUM.items())),
    ctl("i_sur", "Sürekli kısa devre akımı", "sayi", 0.8, min=0.2, max=4.0, adim=0.05, birim="×In", goster={"durum": ["surekli"]}, yardim="Jeneratör veri föyü: uyartım desteği yoksa anma akımının altına inebilir"),
    ctl("iv", "Röle › IV> başlatma", "sayi", 1.50, min=0.50, max=4.00, adim=0.01, birim="×In"),
    ctl("vx1", "Röle › VX1", "sayi", 20, min=0, max=150, adim=1, birim="%Un"),
    ctl("vx2", "Röle › VX2", "sayi", 80, min=0, max=150, adim=1, birim="%Un"),
    ctl("iy1", "Röle › IY1", "sayi", 20, min=0, max=200, adim=1, birim="% IV>"),
    ctl("iy2", "Röle › IY2", "sayi", 100, min=0, max=200, adim=1, birim="% IV>"),
    ctl("t", "Röle › Çalışma süresi", "sayi", 1.0, min=0.08, max=300, adim=0.02, birim="s"),
    ctl("i51", "Karşılaştırma: olağan aşırı akım kademesi I>", "sayi", 1.50, min=0.5, max=5.0, adim=0.05, birim="×In"),
]


def esik(u: float, p: dict) -> float:
    """Gerilime göre başlatma akımı (×In): VX1'in altında IY1, VX2'nin üstünde IY2, arası doğrusal."""
    iv = num(p, "iv", 1.5); x1, x2 = sorted((num(p, "vx1", 20), num(p, "vx2", 80))); y1, y2 = num(p, "iy1", 20) / 100, num(p, "iy2", 100) / 100
    if u <= x1:
        return iv * y1
    if u >= x2 or x2 - x1 < 1e-9:
        return iv * y2
    return iv * (y1 + (y2 - y1) * (u - x1) / (x2 - x1))


def run(p: dict) -> dict:
    d = p.get("durum") if p.get("durum") in DURUM else "surekli"
    u, i = NOKTA[d]
    if d == "surekli":
        i = num(p, "i_sur", 0.8)
    e = esik(u, p); basla = i >= e; t = num(p, "t", 1.0)
    i51 = num(p, "i51", 1.5); basla51 = i >= i51
    beklenen = d in ("ilk", "surekli", "uzak")
    c = tek_hat(("Jeneratör", "uyartım uçlardan"), ("Şebeke / yük", DURUM[d].split(" (")[0].split(" —")[0]), ("51V  IV>", ("AÇAR " + fnum(t, 2) + " s") if basla else "başlamadı"), "acti" if basla else ("gecersiz" if beklenen else "normal"),
                620 if d in ("ilk", "surekli", "uzak") else None, "sag", ileri=False)
    c.yazi(500, 190, f"U1 = %{fnum(u, 0)} · I = {fnum(i, 2)} ×In · bu gerilimdeki eşik {fnum(e, 2)} ×In", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, "51V: " + ("başlar" if basla else "başlamaz") + " · olağan I> (" + fnum(i51, 2) + " ×In): " + ("başlar" if basla51 else "BAŞLAMAZ"), "#334155", 11)
    c.yazi(500, 226, "Gerilim düştükçe eşik düşer: küçük arıza akımı yakalanır", "#334155", 11)
    ozet = [
        K("51V", ("AÇAR " + fnum(t, 2) + " s") if basla else "başlamadı", "ok" if basla == beklenen else "bad", ("doğru" if basla == beklenen else "YANLIŞ") + " — " + ("arıza var" if beklenen else "arıza yok")),
        K("Bu gerilimdeki eşik", f"{fnum(e, 2)} ×In", "info", f"U1 = %{fnum(u, 0)}"),
        K("Akım", f"{fnum(i, 2)} ×In", "info", f"eşiğin {fnum(i / max(e, 1e-9), 2)} katı"),
        K("Olağan aşırı akım (I>)", "başlar" if basla51 else "başlamaz", "ok" if basla51 == beklenen else "bad", "gerilime bakmaz"),
        K("Anma geriliminde eşik", f"{fnum(esik(100, p), 2)} ×In", "ok" if esik(100, p) >= 1.15 else "bad", "tam yükte açmamalı"),
    ]
    kontroller = [
        C("Bu durumda davranış doğru mu?", ("başladı" if basla else "başlamadı") + f" (I = {fnum(i, 2)}, eşik {fnum(e, 2)} ×In)", "arızada başlar; yükte ve aşırı yükte başlamaz", basla == beklenen, P3U + " böl. 5.24", "resmi"),
        C("Anma geriliminde eşik yükün üstünde mi?", f"{fnum(esik(100, p), 2)} ×In", "≥ 1,15 × anma akımı", esik(100, p) >= 1.15, "IY2 = %100 iken eşik IV>'dir — " + P3U + " böl. 5.24; pay öğretim amaçlı", "ikincil"),
        C("Sürekli kısa devre akımı çökmüş gerilimde eşiği aşıyor mu?", f"I sürekli = {fnum(num(p, 'i_sur', 0.8), 2)} ×In; %12 gerilimde eşik {fnum(esik(12, p), 2)} ×In", "akım ≥ 1,5 × eşik", num(p, "i_sur", 0.8) >= 1.5 * esik(12, p),
          "Uyartımı uçlardan beslenen jeneratörde sürekli kısa devre akımı anma akımının altına inebilir (üretici verisi)", "tahmini"),
        C("Süre üst korumalarla uyumlu mu?", f"{fnum(t, 2)} s", "şebeke tarafındaki korumalardan uzun; jeneratörün kısa devre dayanımından kısa", None, "Kademe sabit zamanlıdır (0,08–300 s) — " + P3U + " Çizelge 73", "resmi"),
        C("Gerilim trafosu arızasında yanlış açma", "GT sigortası atarsa U1 düşer: eşik düşer", "60FL işaretiyle kilit matrisinden kilitlenmeli", None, P3U + " böl. 6.8 (GT denetimi); eşiğin gerilime bağlılığı: böl. 5.24", "resmi"),
    ]
    girdiler = [
        G("Jeneratörün uyartım biçimi", "statik uyartım, uçlardan besleme (destek yok)", "Jeneratör veri föyü", "Uçlardan beslenen uyartımda yakın arızada gerilim çöker, uyartım düşer, akım söner", "51V'nin gerekçesi"),
        G("Sürekli kısa devre akımı", f"{fnum(num(p, 'i_sur', 0.8), 2)} ×In", "Jeneratör veri föyü (sürekli üç fazlı kısa devre akımı)", "Düşük gerilimdeki eşik bunun altında olmalı", "IV> × IY1 ≤ I sürekli / 1,5"),
        G("En büyük yük akımı ve o andaki gerilim", "1,0–1,3 ×In; %93–100 Un", "İşletme kayıtları", "Anma gerilimindeki eşik bunun üstünde olmalı", "IV> × IY2"),
        G("Şebeke arızalarında jeneratör uçlarındaki gerilim", "uzak arızada %60–80; yakın arızada %10–20", "Kısa devre hesabı", "VX1 ve VX2 bu iki bölgeyi ayırır", "VX1, VX2"),
    ]
    adimlar = [
        A("Anma gerilimindeki eşik", "IV> × IY2", f"{fnum(num(p, 'iv', 1.5), 2)} × %{fnum(num(p, 'iy2', 100), 0)}", f"{fnum(esik(100, p), 2)} ×In", P3U + " böl. 5.24", "resmi", ["En büyük yük akımı ve o andaki gerilim"], "IV>, IY2"),
        A("Çökmüş gerilimdeki eşik", "IV> × IY1 (U ≤ VX1)", f"{fnum(num(p, 'iv', 1.5), 2)} × %{fnum(num(p, 'iy1', 20), 0)}", f"{fnum(esik(0, p), 2)} ×In", P3U + " böl. 5.24", "resmi", ["Sürekli kısa devre akımı"], "IY1, VX1"),
        A("Arada (VX1 < U < VX2)", "doğrusal: IV> × [IY1 + (IY2 − IY1) · (U − VX1) / (VX2 − VX1)]", f"U = %{fnum(u, 0)}", f"{fnum(e, 2)} ×In", P3U + " böl. 5.24 Şekil 101", "resmi", ["Şebeke arızalarında jeneratör uçlarındaki gerilim"], "VX2"),
    ]
    ayarlar = [
        S("IV> › Başlatma", f"{fnum(num(p, 'iv', 1.5), 2)} ×In", "0,50 … 4,00 ×IGN", "Anma gerilimindeki eşik (IY2 = %100 ise)", P3U + " Çizelge 73"),
        S("VX1 · VX2", f"%{fnum(num(p, 'vx1', 20), 0)} · %{fnum(num(p, 'vx2', 80), 0)}", "%0 … %150", "Eşiğin değişmeye başladığı ve bittiği gerilimler. Eşit seçilirse gerilim denetimli (basamaklı) olur", P3U + " Çizelge 73"),
        S("IY1 · IY2", f"%{fnum(num(p, 'iy1', 20), 0)} · %{fnum(num(p, 'iy2', 100), 0)}", "%0 … %200 IV>", "VX1'in altındaki ve VX2'nin üstündeki eşik çarpanları. İkisi de %100 ise olağan aşırı akım kademesi", P3U + " Çizelge 73"),
        S("Çalışma süresi", f"{fnum(t, 2)} s", "0,08 … 300 s", "Sabit zamanlı", P3U + " Çizelge 73"),
        S("Kilit matrisi › GT denetimi (60FL) → IV>", "bağlı", "—", "GT sigortası atınca eşik düşer; kilit yanlış açmayı önler", P3U + " böl. 6.8"),
    ]
    test = [
        T("Anma geriliminde başlatma", "Üç faza anma gerilimi; akımı yükseltin", f"Başlatma {fnum(esik(100, p), 2)} ×In", "±%3"),
        T("Çökmüş gerilimde başlatma", f"Gerilimi %{fnum(max(num(p, 'vx1', 20) - 5, 0), 0)}'e indirin; akımı yükseltin", f"Başlatma {fnum(esik(0, p), 2)} ×In", "±%3"),
        T("Ara nokta", f"Gerilim %{fnum((num(p, 'vx1', 20) + num(p, 'vx2', 80)) / 2, 0)}", f"Başlatma {fnum(esik((num(p, 'vx1', 20) + num(p, 'vx2', 80)) / 2, p), 2)} ×In", "±%3"),
        T("Süre", "Eşiğin 2 katı akım", f"{fnum(t, 2)} s", "±%1 ya da ±30 ms"),
    ]
    us = list(range(0, 121, 2))
    g = {"baslik": "Karakteristik: gerilim düştükçe başlatma akımı düşer", "x_ad": "Pozitif bileşen gerilimi U1 (% Un)", "y_ad": "Akım (×In)", "ymin": 0,
         "seriler": [{"ad": "51V eşiği", "renk": "#dc2626", "pts": [[x, round(esik(x, p), 3)] for x in us]}, {"ad": "olağan I> eşiği", "renk": "#94a3b8", "kesik": True, "pts": [[x, i51] for x in us]},
                     {"ad": "durumlar (yük · aşırı yük · ilk an · sürekli · uzak)", "renk": "#1a4d8f", "nokta": True, "r": 5, "pts": [[NOKTA[k][0], num(p, "i_sur", 0.8) if k == "surekli" else NOKTA[k][1]] for k in NOKTA]}],
         "isaretler": [{"x": u, "etiket": "şu an"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["51v"],
        "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Jeneratörün yakınında kısa devre olduğunda akım ilk anda anma akımının birkaç katıdır; birkaç periyot içinde geçici, sonra sürekli değerine düşer.",
            "Uyartım gücünü jeneratörün kendi uçlarından alıyorsa arızada o da çöker ve sürekli kısa devre akımı anma akımının altına inebilir. Yüksek ayarlı aşırı akım kademesi bu akımı göremez; düşük ayarlısı ise yükte açar.",
            "Arızayı yükten ayıran gerilimdir: yükte gerilim normaldir, yakın arızada çökmüştür. 51V başlatma akımını gerilime bağlar.",
            f"VX2'nin üstünde eşik IV> × IY2'dir (anma geriliminde {fnum(esik(100, p), 2)} ×In); VX1'in altında IV> × IY1'e iner ({fnum(esik(0, p), 2)} ×In); arada doğrusal değişir.",
            "VX1 ile VX2 eşit seçilirse eşik basamak biçiminde değişir (gerilim denetimli). Ayrı seçilirse yumuşak geçiş olur (gerilim tutuculu).",
            "Gerilim trafosu sigortası atarsa röle gerilimi düşük sanar ve eşiği indirir: yükte açma olur. Bu yüzden 51V, GT denetimi işaretiyle kilitlenir.",
        ],
        "dersler": [
            "51V, akımı sönen kaynaklar (uçlardan uyartımlı jeneratör, evirici) için aşırı akımın duyarlı biçimidir.",
            "Anma geriliminde eşik yükün üstünde, çökmüş gerilimde sürekli kısa devre akımının altında olmalı.",
            "Denetim gerilimi pozitif bileşendir; GT arızasına karşı 60FL kilidi şarttır.",
            "IY1 = IY2 = %100 girilirse kademe olağan bir aşırı akım kademesi olur.",
        ],
        "tablolar": [{"baslik": "Beş durumda iki korumanın davranışı", "cols": ["Durum", "U1", "Akım", "51V eşiği", "51V", "Olağan I>"], "rows": [
            [DURUM[k], f"%{NOKTA[k][0]}", f"{fnum(num(p, 'i_sur', 0.8) if k == 'surekli' else NOKTA[k][1], 2)} ×In", f"{fnum(esik(NOKTA[k][0], p), 2)} ×In",
             "başlar" if (num(p, "i_sur", 0.8) if k == "surekli" else NOKTA[k][1]) >= esik(NOKTA[k][0], p) else "—", "başlar" if (num(p, "i_sur", 0.8) if k == "surekli" else NOKTA[k][1]) >= i51 else "—"] for k in NOKTA],
            "not": "Durumlardaki gerilim ve akım değerleri tipiktir (öğretim amaçlı)."}],
    }
