"""Çok fiderli şebekede toprak arızası: yıldız noktası yalıtılmış, söndürme bobinli (Petersen) ya da dirençli şebekede her fiderin toroidinden
geçen artık akım, yönü ve hangi rölenin açtığı; aralıklı (kendi kendine sönen) arıza.

Model: −V0 referans alınır. Sağlam fiderin artık akımı kendi kapasitif akımıdır (−V0'dan 90° geride); arızalı fiderinki öbür fiderlerin kapasitif
akımlarının toplamı (90° ileride) artı yıldız noktası elemanının akımıdır (bobin: 90° geride + küçük bir aktif bileşen; direnç: −V0 ile aynı fazda).
Arıza direnci nötr kaymasını küçültür: V0/E = 1 / (1 + Rf·Y), Y şebekenin toprağa toplam admitansı. Kapasitif akım birim değeri (A/km) tipiktir (tahmini).
Röle kipleri (kapasitif / rezistif) ve işaret kuralı: P3U/en M/J006 böl. 5.31; aralıklı arıza: böl. 5.32 (arıza süresi tipik 0,1–1 ms; temel bileşenle
çalışan yönlü eleman doğru tanıyamaz; 67NI anlık örneklerle çalışır). Ayrıntılı kademe ayarı için «Yönlü toprak (67N)» sayfasına bakın."""
from __future__ import annotations

import cmath
import math

from .ortak import A, C, Cizim, G, K, KANIT, P3U, S, S3, T, aci, ctl, fa, fazor, fnum, num, opt

ID = "toprak_fider"
BASLIK = "Çok fiderli şebekede toprak arızası"
IKON = "🕸"
GIRIS = ("Yıldız noktası yalıtılmış ya da bobinli şebekede toprak arızası akımı küçüktür ve bütün fiderlerden geçer: her fider kendi kablo kapasitesi kadar akım taşır. "
         "Arızalı fideri ötekilerden ayıran akımın büyüklüğü değil yönüdür. Fider sayısını, boylarını ve yıldız noktasının biçimini değiştirin; her toroidin "
         "gördüğünü ve hangi rölenin açtığını izleyin.")
NOTR = {"yalitilmis": "Yalıtılmış", "bobin": "Söndürme bobini (Petersen)", "direnc": "Direnç üzerinden"}
KIP = {"sin": "Kapasitif (Io·sin φ) — yalıtılmış şebeke", "cos": "Rezistif (Io·cos φ) — bobinli / dirençli şebeke"}

KONTROLLER = [
    ctl("notr", "Yıldız noktası", "sec", "yalitilmis", secenek=opt(*NOTR.items())),
    ctl("un", "Şebeke gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("n", "Fider sayısı", "sec", 3, secenek=opt((2, "2"), (3, "3"), (4, "4"))),
    ctl("l1", "1. fider (kablo)", "sayi", 4, min=0.1, max=30, adim=0.1, birim="km"),
    ctl("l2", "2. fider (kablo)", "sayi", 6, min=0.1, max=30, adim=0.1, birim="km"),
    ctl("l3", "3. fider (kablo)", "sayi", 2, min=0.1, max=30, adim=0.1, birim="km", goster={"n": [3, 4]}),
    ctl("l4", "4. fider (kablo)", "sayi", 8, min=0.1, max=30, adim=0.1, birim="km", goster={"n": [4]}),
    ctl("ic_km", "Kablonun kapasitif toprak akımı", "sayi", 3.0, min=0.05, max=6, adim=0.05, birim="A/km", yardim="34,5 kV XLPE kabloda 2–4 A/km; havai hatta 0,1 A/km dolayı"),
    ctl("ariza", "Arızalı fider", "sec", 1, secenek=opt((1, "1. fider"), (2, "2. fider"), (3, "3. fider"), (4, "4. fider"))),
    ctl("rf", "Arıza direnci", "sayi", 0, min=0, max=5000, adim=10, birim="Ω"),
    ctl("komp", "Bobin ayarı", "sayi", 95, min=70, max=130, adim=1, birim="%", goster={"notr": ["bobin"]}, yardim="%100: bobin akımı toplam kapasitif akıma eşit (tam ayar); altı eksik, üstü fazla kompanzasyon"),
    ctl("iw", "Bobinin aktif akımı / paralel direnç", "sayi", 10, min=0, max=100, adim=1, birim="A", goster={"notr": ["bobin"]}),
    ctl("ir", "Yıldız noktası direncinin akımı", "sayi", 300, min=5, max=1500, adim=5, birim="A", goster={"notr": ["direnc"]}),
    ctl("kip", "Röle › yön kipi", "sec", "sin", secenek=opt(*KIP.items())),
    ctl("esik", "Röle › Io başlatma (primer)", "sayi", 2.0, min=0.2, max=100, adim=0.1, birim="A"),
    ctl("vo", "Röle › Vo başlatma", "sayi", 10, min=1, max=50, adim=1, birim="%"),
    ctl("aralikli", "Arıza aralıklı (kendi kendine sönüp yeniden tutuşuyor)", "onay", False),
]


def hesap(p: dict) -> dict:
    n = int(num(p, "n", 3)); notr = p.get("notr") if p.get("notr") in NOTR else "yalitilmis"
    ic = [num(p, f"l{j + 1}", (4, 6, 2, 8)[j]) * num(p, "ic_km", 3.0) for j in range(n)]
    k = min(max(int(num(p, "ariza", 1)), 1), n) - 1
    top = sum(ic)
    i_n = {"yalitilmis": 0j, "bobin": complex(num(p, "iw", 10), -num(p, "komp", 95) / 100 * top), "direnc": complex(num(p, "ir", 300), 0)}[notr]
    e = num(p, "un", 34.5) * 1000 / S3
    y = (i_n + 1j * top) / e                                               # tam kaymada şebekenin toprağa akıttığı akım / faz gerilimi
    v0 = abs(1 / (1 + num(p, "rf", 0) * y))
    io = [(1j * (top - ic[j]) + i_n) * v0 if j == k else -1j * ic[j] * v0 for j in range(n)]
    i_ariza = abs(i_n + 1j * top) * v0                                      # arıza yerinden toprağa akan akım
    return {"n": n, "notr": notr, "ic": ic, "k": k, "top": top, "i_n": i_n, "v0": v0, "io": io, "i_ariza": i_ariza, "e": e}


def karar(p: dict, h: dict) -> list:
    """Her fider rölesi için (çalışma büyüklüğü A, ileri mi, açar mı)."""
    kip = p.get("kip") if p.get("kip") in KIP else "sin"
    esik, vo = num(p, "esik", 2.0), num(p, "vo", 10) / 100
    out = []
    for z in h["io"]:
        b = z.imag if kip == "sin" else z.real                             # −V0'a göre dik (kapasitif) ya da aynı fazdaki (rezistif) bileşen
        out.append((b, b > 0, b >= esik and h["v0"] >= vo))
    return out


def run(p: dict) -> dict:
    h = hesap(p); kr = karar(p, h)
    n, k, notr = h["n"], h["k"], h["notr"]
    kip = p.get("kip") if p.get("kip") in KIP else "sin"
    esik, vo = num(p, "esik", 2.0), num(p, "vo", 10) / 100
    aralikli = bool(p.get("aralikli"))
    ariza_acar = kr[k][2] and not aralikli
    saglam_acan = [j + 1 for j in range(n) if j != k and kr[j][2]]
    uygun_kip = (kip == "sin") == (notr == "yalitilmis")

    c = Cizim(900, 96 + n * 56)
    c.kutu(20, 40, 96, 54, "Trafo", {"yalitilmis": "nötr yalıtılmış", "bobin": f"bobin %{fnum(num(p, 'komp', 95), 0)}", "direnc": "nötr direnci"}[notr])
    c.hat(f"M116,67 H160", "L1", w=3); c.hat(f"M160,40 V{74 + n * 56}", "cizgi", w=5); c.yazi(160, 30, "OG bara", "#475569", 10, anchor="middle")
    if notr != "yalitilmis":
        c.hat("M68,94 V112", "cizgi", w=1.6); (c.bobin(68, 112, 3, False, "cizgi") if notr == "bobin" else c.direnc(68, 112, "", False, False, 22)); c.toprak(68, 142, "toprak")
    for j in range(n):
        y = 70 + j * 56
        ar = j == k
        c.hat(f"M160,{y} H{560 if ar else 600}", "L1", hot=True, w=2.6, hot_renk="ariza" if ar else "uyari")
        c.toroid(230, y, 6, 15)
        c.yazi(300, y - 9, f"{j + 1}. fider · {fnum(num(p, f'l{j + 1}', 1), 1)} km · kendi kapasitif akımı {fnum(h['ic'][j], 1)} A", "#475569", 10)
        if ar:
            c.simsek(552, y - 9, 1.0); c.hat(f"M560,{y} V{y + 22}", "ariza", hot=True, w=2); c.toprak(560, y + 24, "ariza")
        b, ileri, acar = kr[j]
        c.kutu(640, y - 19, 246, 38, f"{fnum(abs(h['io'][j]), 1)} A ∠{fnum(aci(h['io'][j]), 0)}° → {'ileri' if ileri else 'geri'}", ("AÇAR" if acar else "açmaz") + f" · {'kapasitif' if kip == 'sin' else 'rezistif'} bileşen {fnum(b, 1)} A",
               ("acti" if ar else "gecersiz") if acar else "normal")
    c.yazi(300, 86 + n * 56, f"Nötr kayması V0 = %{fnum(h['v0'] * 100, 0)} · arıza yerindeki akım {fa(h['i_ariza'])}", "#1e293b", 12, kalin=True)

    renk = ("#dc2626", "#1a4d8f", "#15803d", "#b45309")
    olc = max(max(abs(z) for z in h["io"]), 1e-9)
    f = {"baslik": "Fiderlerin artık akımları (−V0'a göre)", "vektorler": [fazor("−V0", complex(olc, 0), "#94a3b8", kesik=True)] + [fazor(f"F{j + 1}", h["io"][j], renk[j]) for j in range(n)],
         "not": "Sağlam fiderlerin akımı aşağıya (90° geride), arızalı fiderinki öbürlerinin toplamı kadar yukarıya bakar; bobin bunu aşağı çeker, direnç sağa yatırır."}
    ozet = [
        K("Arızalı fiderin rölesi", "AÇAR" if ariza_acar else "açmaz", "ok" if ariza_acar else "bad", f"{k + 1}. fider · {fnum(abs(h['io'][k]), 1)} A ∠{fnum(aci(h['io'][k]), 0)}°" + (" · aralıklı arızada süreyi dolduramaz" if aralikli else "")),
        K("Sağlam fiderler", "açmıyor" if not saglam_acan else f"{', '.join(str(x) for x in saglam_acan)}. fider AÇAR", "ok" if not saglam_acan else "bad", "her biri kendi kapasitif akımını geri yönde görür"),
        K("Nötr kayması V0", f"%{fnum(h['v0'] * 100, 0)}", "ok" if h["v0"] >= vo else "warn", f"faz geriliminin oranı · arıza direnci {fnum(num(p, 'rf', 0), 0)} Ω"),
        K("Arıza yerindeki akım", fa(h["i_ariza"]), "info", {"yalitilmis": "toplam kapasitif akım", "bobin": "bobin kapasitif akımı söndürür: artık akım", "direnc": "direnç akımı + kapasitif akım"}[notr]),
        K("Toplam kapasitif akım", fa(h["top"]), "info", f"{n} fider · {fnum(sum(num(p, f'l{j + 1}', 1) for j in range(n)), 1)} km kablo"),
    ]
    kontroller = [
        C("Arızalı fiderin rölesi açıyor mu?", f"{'kapasitif' if kip == 'sin' else 'rezistif'} bileşen {fnum(kr[k][0], 1)} A; V0 %{fnum(h['v0'] * 100, 0)}", f"≥ {fnum(esik, 1)} A (ileri) ve V0 ≥ %{fnum(vo * 100, 0)}", ariza_acar,
          "Arızalı fiderin toroidinden öbür fiderlerin kapasitif akımları ile yıldız noktası akımı geçer; yön −V0'a göre belirlenir — " + P3U + " böl. 5.31" + ("; aralıklı arıza için böl. 5.32" if aralikli else ""), "resmi"),
        C("Sağlam fiderlerin röleleri açmıyor mu?", "; ".join(f"F{j + 1}: {fnum(kr[j][0], 1)} A" for j in range(n) if j != k), "geri yönde görmeli (negatif bileşen)", not saglam_acan,
          "Sağlam fider yalnız kendi kapasitif akımını taşır; yönü arızalı fiderinkinin tersidir. Yönsüz bir toprak rölesi uzun kablolu sağlam fiderde de açar", "hesap"),
        C("Yön kipi şebekenin yıldız noktasına uygun mu?", KIP[kip].split(" — ")[0] + " kip, " + NOTR[notr].lower() + " şebeke", "yalıtılmış → kapasitif; bobinli / dirençli → rezistif", uygun_kip,
          "Bobinli şebekede kapasitif bileşen bobin akımıyla söndürülür ve fazla kompanzasyonda işaret değiştirir: arızalı fider yalnız aktif (rezistif) bileşenden tanınır — " + KANIT, "resmi"),
        C("En kısa fiderde arıza olsa röle görebilir mi?", f"en uzun fider {fnum(max(h['ic']), 1)} A taşır; geriye kalan en az {fnum(h['top'] - max(h['ic']), 1)} A", f"≥ Io ayarı {fnum(esik, 1)} A" if kip == "sin" else "rezistif kipte aktif akıma bakılır", (h["top"] - max(h["ic"])) * h["v0"] >= esik if kip == "sin" else None,
          "Yalıtılmış şebekede arızalı fiderin gördüğü akım, kendisi dışındaki fiderlerin kapasitif akımıdır: tek fider kaldığında röle hiçbir şey görmez", "hesap"),
    ]
    girdiler = [
        G("Yıldız noktasının biçimi", NOTR[notr], "Tek hat şeması; indirici merkez", "Arıza akımının büyüklüğünü ve hangi bileşenden tanınacağını belirler", "yön kipi seçimi"),
        G("Her fiderin kablo boyu ve kapasitif akımı", " · ".join(f"F{j + 1} {fnum(h['ic'][j], 1)} A" for j in range(n)), "Kablo listesi; üretici verisi (µF/km) ya da ölçü", "Sağlam fiderin gördüğü akım kendi kapasitif akımıdır: ayar bunun üstünde olamazsa yön şarttır", "Ic = 3·ω·C0·U/√3"),
        G("Bobinin ayarı ve aktif akımı", f"%{fnum(num(p, 'komp', 95), 0)} · {fnum(num(p, 'iw', 10), 0)} A" if notr == "bobin" else "—", "Bobin etiketi ve ayar göstergesi; paralel direnç", "Rezistif kipte röle yalnız bu aktif akımı görür", "Io·cos φ"),
        G("Toroidlerin yönü ve Vo ölçüsü", "P1 baraya; açık üçgen ya da hesaplanan Vo", "Devreye alma kayıtları", "Yön −V0'a göre belirlenir; toroid ters takılıysa sağlam fider ileri, arızalı fider geri görünür", "polarite testi"),
    ]
    adimlar = [
        A("Fiderlerin kapasitif akımı", "Ic = (A/km) × boy", " · ".join(f"{fnum(num(p, f'l{j + 1}', 1), 1)} km" for j in range(n)), " · ".join(f"{fnum(v, 1)} A" for v in h["ic"]) + f" (toplam {fnum(h['top'], 1)} A)", "kablo verisi (tipik)", "tahmini", ["Her fiderin kablo boyu ve kapasitif akımı"]),
        A("Nötr kayması", "V0 / E = 1 / |1 + Rf·Y|", f"Rf = {fnum(num(p, 'rf', 0), 0)} Ω", f"%{fnum(h['v0'] * 100, 0)}", "gerilim bölücü: arıza direnci ile şebekenin toprağa admitansı", "hesap"),
        A("Sağlam fiderin artık akımı", "Io = −j·Ic(kendi) · V0", "—", " · ".join(f"F{j + 1} {fnum(abs(h['io'][j]), 1)} A" for j in range(n) if j != k), "sağlam fider yalnız kendi kapasitesini besler", "hesap"),
        A("Arızalı fiderin artık akımı", "Io = [ j·ΣIc(öbür fiderler) + I(yıldız noktası) ] · V0", f"j·{fnum(h['top'] - h['ic'][k], 1)} + ({fnum(h['i_n'].real, 1)} − j{fnum(-h['i_n'].imag, 1)})", f"{fnum(abs(h['io'][k]), 1)} A ∠{fnum(aci(h['io'][k]), 0)}°", "bütün dönüş akımları arızalı fiderin toroidinden geçer", "hesap", ["Yıldız noktasının biçimi"]),
        A("Rölenin baktığı bileşen", "kapasitif: Io·sin φ ;  rezistif: Io·cos φ", KIP[kip].split(" — ")[0], f"arızalı fider {fnum(kr[k][0], 1)} A", P3U + " böl. 5.31", "resmi", [], "Io yön kipi"),
    ]
    ayarlar = [
        S("Ioφ> › Kip", "Kapasitif (yalıtılmış) / Rezistif (bobinli, dirençli)", "—", "Şebekenin yıldız noktasına göre seçilir; yanlış kipte arızalı fider tanınmaz", P3U + " böl. 5.31"),
        S("Ioφ> › Başlatma", f"{fnum(esik, 1)} A primer", "—", "Arızalı fiderin gördüğü en küçük bileşenin altında", "bu sayfadaki hesap", "hesap"),
        S("Vo> başlatma", f"%{fnum(vo * 100, 0)}", "—", "Dengesizlikten oluşan sürekli nötr kaymasının üstünde; yüksek dirençli arızada V0 küçülür", "bu sayfadaki hesap", "hesap"),
        S("Ioint> (67NI, aralıklı toprak arızası)", "bobinli kablo şebekesinde", "—", "Kendi kendine sönen arızalar 0,1–1 ms sürer; temel bileşenle çalışan kademe bunları doğru tanıyamaz", P3U + " böl. 5.32"),
    ]
    test = [
        T("Yön", "Vo = %30, Io = 2 × ayar; açıyı çevir", "Kapasitif kipte +90° dolayında, rezistif kipte 0° dolayında başlar", "bkz. Yönlü toprak (67N) sayfası"),
        T("Sağlam fider", "Io'yu −90°'de (geri) uygula", "Başlamaz", "akım ne kadar büyük olursa olsun"),
        T("Primer deneme", "Bir fiderin sonunda toprak arızası yapılır (işletmecinin izniyle)", "Yalnız o fiderin rölesi açar; ötekiler geri yön gösterir", "toroid yönlerinin kesin doğrulaması"),
    ]
    grafikler = []
    if aralikli:
        ts = [j * 0.5 for j in range(0, 401)]                                # ms
        vuruslar = (10, 45, 95, 140, 170)
        tau = 60.0 if notr == "bobin" else 8.0                               # nötr geriliminin sönme zaman sabiti (ms): bobinli şebekede yavaş
        v, i = [], []
        for t in ts:
            son = max((x for x in vuruslar if x <= t), default=None)
            v.append(0.0 if son is None else math.exp(-(t - son) / tau) * math.cos(2 * math.pi * 0.05 * (t - son) * (0.92 if notr == "bobin" else 1)))
            i.append(sum(8.0 * math.exp(-(t - x) / 0.6) for x in vuruslar if 0 <= t - x < 5))
        grafikler.append({"baslik": "Aralıklı toprak arızası: her tutuşmada kısa bir akım darbesi; nötr gerilimi arada söner", "x_ad": "Zaman (ms)", "y_ad": "pu (öğretim amaçlı)", "zaman": True,
                          "seriler": [{"ad": "nötr gerilimi V0", "renk": "#1a4d8f", "pts": [[t, round(x, 3)] for t, x in zip(ts, v)]}, {"ad": "arızalı fiderin artık akımı", "renk": "#dc2626", "pts": [[t, round(x, 3)] for t, x in zip(ts, i)]}]})
    grafikler.append({"baslik": "Arıza direnci büyüdükçe nötr kayması ve arızalı fiderin akımı küçülür", "x_ad": "Arıza direnci (Ω)", "y_ad": "% · A", "logx": True, "ymin": 0,
                      "seriler": [{"ad": "V0 (%)", "renk": "#1a4d8f", "pts": [[r, round(hesap({**p, "rf": r})["v0"] * 100, 2)] for r in (1, 10, 30, 100, 300, 1000, 3000, 5000)]},
                                  {"ad": "arızalı fiderin Io (A)", "renk": "#dc2626", "pts": [[r, round(abs(hh["io"][hh["k"]]), 2)] for r in (1, 10, 30, 100, 300, 1000, 3000, 5000) for hh in [hesap({**p, "rf": r})]]}],
                      "yatay": [{"y": vo * 100, "etiket": f"Vo ayarı %{fnum(vo * 100, 0)}", "renk": "#64748b"}]})
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["67n"], "sahne": c.sahne(fazor=f), "grafikler": grafikler,
        "anlatim": [
            "Bir faz toprağa değdiğinde o fazın gerilimi sıfıra iner, öbür iki fazın toprağa göre gerilimi faz arası gerilime yükselir. Yıldız noktası toprağa göre faz gerilimi kadar kayar (V0).",
            "Sağlam iki fazın kablo kapasiteleri artık daha yüksek gerilim altındadır: bütün fiderlerden toprağa kapasitif akım akar ve arıza yerinden geri döner. Her fider kendi boyu kadar akım üretir.",
            f"Sağlam fiderin toroidi yalnız kendi kapasitif akımını görür. Arızalı fiderin toroidinden ise öbür bütün fiderlerin akımı geri gelir: {fnum(h['top'] - h['ic'][k], 1)} A, ters yönde. Arızayı belirleyen bu yön farkıdır.",
            "Söndürme bobini yıldız noktasına bağlı bir endüktanstır: arıza yerinde kapasitif akımın tersi yönde akım akıtır ve onu söndürür. Arıza akımı birkaç ampere iner, ark kendi kendine söner; ama arızalı fiderin kapasitif bileşeni de kaybolur ya da işaret değiştirir.",
            "Bu yüzden bobinli şebekede röle kapasitif bileşene değil, bobinin kayıplarından ve paralel dirençten gelen küçük aktif bileşene bakar: bu bileşen yalnız arızalı fiderde vardır.",
            "Kablo şebekesinde arıza çoğu kez aralıklıdır: yalıtım delinir, ark bir milisaniyeden kısa sürede söner, gerilim toparlanınca yeniden tutuşur. Temel bileşenle çalışan kademe başlar ve bırakır; süresini dolduramaz. Bunun için anlık örneklerle çalışan ayrı bir kademe (67NI) vardır.",
        ],
        "dersler": [
            "Yalıtılmış şebekede toprak arıza akımı şebekenin toplam kablo boyuyla orantılıdır; arızalı fider kendi akımını değil ötekilerinkini görür.",
            "Uzun kablolu sağlam fider, kısa fiderdeki arızada ayarın üstünde akım taşıyabilir: yönsüz toprak rölesi seçici olamaz.",
            "Bobinli şebekede kip rezistif olmalı; kapasitif kipte fazla kompanzasyon arızalı fideri «geri» gösterir.",
            "Toroidin yönü ve Vo'nun polaritesi yanlışsa her şey tersine döner: sağlam fiderler açar, arızalı fider bekler.",
        ],
        "tablolar": [{"baslik": "Her fiderin rölesi ne görüyor", "cols": ["Fider", "Kendi kapasitif akımı", "Toroidden geçen Io", "−V0'a göre açı", "Yön", "Sonuç"],
                      "rows": [[f"{j + 1}. fider" + (" (arızalı)" if j == k else ""), fa(h["ic"][j]), fa(abs(h["io"][j])), f"{fnum(aci(h['io'][j]), 0)}°", "ileri" if kr[j][1] else "geri", "AÇAR" if kr[j][2] else "açmaz"] for j in range(n)],
                      "not": "Açı işareti Easergy P3 kuralıyladır: pozitif, −V0'dan ileride. ABB 615'te işaret terstir (bkz. Yönlü toprak sayfası)."}],
    }
