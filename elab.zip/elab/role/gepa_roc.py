"""GEPA ROC-121 / ROC-131 ayar hesaplayıcı (saha aracı): ön paneldeki DIP anahtarlarının konumundan ayarları okur ya da istenen ayar için DIP konumlarını bulur;
arıza akımında açma süresini ve sekonder enjeksiyon sınama değerlerini verir.

Dayanak (metinden ve şekillerden okundu): GEPA «ROC Serisi Aşırı Akım Röleleri» kullanma kılavuzu (gepaelk.com; belgeler/kaynaklar):
- gecikmeli açma akım ayarı: faz 1–16,75 A (0,25 A adım), toprak 0,2–3,35 A (0,05 A adım); çubuk, değerin yazılı olduğu yöne itilince değer toplama eklenir; örnek Is = 1 + (0,25 + 1 + 4) = 6,25 A;
- ani açma: 2–17 × Is; örnek I>> = [2 + (1 + 4)] × Is = 7 Is; MODE bloğunun birinci anahtarı ∞ konumunda ani açma iptal; ani açma zamanı 40 ms (ayarın 1,2 katında);
- zaman çarpanı xt: 0,05–1,0 (0,1 adım); örnek xt = 0,1 + 0,3 + 0,4 = 0,8 — TABAN EKLENMEZ; bütün anahtarlar kapalıyken xt = 0,05;
- MODE A-B-C: 000 Normal Inverse · 001 Very Inverse · 010 Extremely Inverse · 011 Long Time · 100…111 Time Lag 1…4 (15 / 10 / 5 / 2,5 s); MODE bloğunda sol yan «∞ / 1», sağ yan «ON / 0»;
- sabit zamanlı kipte gecikme 0,75–15 · 0,5–10 · 0,25–5 · 0,125–2,5 s (= Time Lag × xt); ayar hatası ±%5; geriye dönüş oranı %95;
- akım devresi In = 5 A (faz), 1 A (toprak); sürekli 2 In, 1 s 100 In; TEST ve RESET düğmeleri.
Kılavuz ROC-131'i (3 faz + toprak; Mod, I>> ve xt fazlar ve toprak için ortak) anlatır ve tiplerin birbirine çok benzediğini yazar. ROC-121'de faz ve toprak için ayrı Mod / I>> / xt
blokları bulunduğu, kullanıcının cihazdan hazırladığı hesaplayıcıdan alınmıştır; kılavuzda ROC-121 panel resmi yoktur (dogrulanacak).
Ters zamanlı eğrilerin sabitleri kılavuzun bu baskısında yoktur (Tablo 1 ve Grafik 1 eksik): kılavuz eğrilerin IEC-255 ve BS-142'ye göre olduğunu yazar; standart IEC sabitleri
kullanıldı. Long Time için kılavuz «Very Inverse'e çok benzer, zamanlar 10 kat daha uzun» der; standart değer 120 / (M − 1) alındı (dogrulanacak: sekonder enjeksiyonla denetlenir)."""
from __future__ import annotations

import math

from ..lab.cizim import Cizim
from ..lab.core import C, K, ctl, fnum, fsure, num, opt
from .ortak import A, G, P3U, S, T

ID = "gepa_roc"
BASLIK = "GEPA ROC-121 ayar hesaplayıcı"
IKON = "🎛️"
GIRIS = ("GEPA ROC serisi rölelerde ayar, ön paneldeki kırmızı DIP anahtarlarıyla yapılır. Rölede gördüğünüz konumları buraya işleyin: sekonder ve primer ayarlar, eğri, açma süresi ve "
         "sınama değerleri çıkar. Tersini yapmak için — istediğiniz akım ve süreden DIP konumlarını bulmak için — «Ne yapılacak» ayarını değiştirin. "
         "Anahtar, değerin yazılı olduğu yana (sola) itilince o değer eklenir.")

GEPA = "GEPA ROC serisi aşırı akım röleleri kullanma kılavuzu"
EGRI = [("Normal Inverse", 0.14, 0.02), ("Very Inverse", 13.5, 1.0), ("Extremely Inverse", 80.0, 2.0), ("Long Time", 120.0, 1.0)]
SABIT = [15.0, 10.0, 5.0, 2.5]
MOD_AD = [e[0] for e in EGRI] + [f"Time Lag {k + 1} ({fnum(v, 1) if v != int(v) else int(v)} s)" for k, v in enumerate(SABIT)]
IS_FAZ = (1.0, (0.25, 0.5, 1.0, 2.0, 4.0, 8.0))
IS_TOPRAK = (0.2, (0.05, 0.1, 0.2, 0.4, 0.8, 1.6))
ANI = (2.0, (1.0, 2.0, 4.0, 8.0))
XT = (0.1, 0.2, 0.3, 0.4)
XT_MIN = 0.05
ANI_SURE = 0.04              # s — ayar değerinin 1,2 katında
HATA = 0.05                  # ayar hatası ±%5
IN_FAZ, IN_TOPRAK = 5.0, 1.0


def yaz(v: float, n: int = 2) -> str:
    """Gereksiz sıfırları atılmış sayı: 2 · 0,25 · 16,75."""
    s = f"{v:.{n}f}".rstrip("0").rstrip(".")
    return (s or "0").replace(".", ",")


def bitler(v, n: int) -> list:
    s = "".join(ch for ch in str(v if v is not None else "") if ch in "01")
    return [int(ch) for ch in s.ljust(n, "0")[:n]]


def toplam(bits: list, taban: float, adimlar: tuple) -> float:
    return round(taban + sum(a for b, a in zip(bits, adimlar) if b), 4)


def xt_deger(bits: list) -> float:
    """Zaman çarpanı: açık anahtarların toplamı; hepsi kapalıysa 0,05 (kılavuz: xt = 0,1 + 0,3 + 0,4 = 0,8)."""
    s = round(sum(a for b, a in zip(bits, XT) if b), 4)
    return s if s > 0 else XT_MIN


def mod_coz(bits: list) -> tuple:
    """(ani açma iptal mi, eğri no 0…7). Birinci anahtar ∞; A-B-C üç bitlik kod (A en büyük basamak)."""
    return bool(bits[0]), bits[1] * 4 + bits[2] * 2 + bits[3]


def sure(m: float, egri: int, xt: float):
    """Gecikmeli açma süresi (s); m = I / Is. m ≤ 1 ise None."""
    if m <= 1.0:
        return None
    if egri >= 4:
        return SABIT[egri - 4] * xt
    _, k, a = EGRI[egri]
    return xt * k / (m ** a - 1)


def acma(i: float, is_p: float, egri: int, xt: float, ani_kat) -> dict:
    """Primer akımda rölenin davranışı. tur: yok | alt | ani | zaman."""
    if not i > 0:
        return {"t": None, "tur": "yok", "m": 0.0, "neden": "Akım girilmedi."}
    m = i / is_p
    if ani_kat and i >= ani_kat * is_p:
        return {"t": ANI_SURE, "tur": "ani", "m": m, "neden": f"I>> ani kademesi: {yaz(ani_kat)} × Is = {fnum(ani_kat * is_p, 1)} A primer; ≈ 40 ms"}
    if m <= 1.0:
        return {"t": None, "tur": "alt", "m": m, "neden": f"Akım ayarın altında (Is = {fnum(is_p, 1)} A primer): röle açmaz."}
    t = sure(m, egri, xt)
    return {"t": t, "tur": "zaman", "m": m, "neden": f"{MOD_AD[egri]} · I / Is = {yaz(m)} · xt = {yaz(xt)}"}


def en_yakin(adimlar: tuple, hedef: float) -> tuple:
    """Toplamı hedefe en yakın anahtar birleşimi: (bitler, toplam). Eşitlikte daha az anahtar."""
    en = None
    for mask in range(1 << len(adimlar)):
        bits = [(mask >> k) & 1 for k in range(len(adimlar))]
        s = sum(a for b, a in zip(bits, adimlar) if b)
        key = (round(abs(s - hedef), 6), sum(bits), mask)
        if en is None or key < en[0]:
            en = (key, bits, round(s, 4))
    return en[1], en[2]


def xt_bul(hedef: float) -> tuple:
    """İstenen zaman çarpanına en yakın ayar: (bitler, xt). 0,05 yalnız bütün anahtarlar kapalıyken elde edilir."""
    bits, s = en_yakin(XT, hedef)
    if s <= 0 or abs(XT_MIN - hedef) < abs(s - hedef):
        return [0, 0, 0, 0], XT_MIN
    return bits, s


def bit_yaz(bits: list) -> str:
    return "".join(str(b) for b in bits)


def acik_yaz(bits: list, etiket: list) -> str:
    a = [e for b, e in zip(bits, etiket) if b]
    return ("sola itili: " + ", ".join(a)) if a else "hepsi sağda (kapalı)"


E_IS = ["+" + yaz(v) for v in IS_TOPRAK[1]]
F_IS = ["+" + yaz(v) for v in IS_FAZ[1]]
E_ANI = ["+" + yaz(v) for v in ANI[1]]
E_XT = ["+" + yaz(v) for v in XT]
E_MOD = ["∞", "A", "B", "C"]
SAG_MOD = ["ON", "0", "0", "0"]
OKU, BUL = {"yon": ["oku"]}, {"yon": ["bul"]}
OKU121, BUL121 = {"yon": ["oku"], "model": ["121"]}, {"yon": ["bul"], "model": ["121"]}
EGRI_SEC = opt(*[(k, a) for k, a in enumerate(MOD_AD)])

KONTROLLER = [
    ctl("yon", "Ne yapılacak", "sec", "oku", secenek=opt(("oku", "Röledeki DIP konumlarından ayarı oku"), ("bul", "İstediğim ayar için DIP konumlarını bul"))),
    ctl("model", "Röle", "sec", "121", secenek=opt(("121", "ROC-121 — 2 faz + toprak (faz ve toprak için ayrı Mod / I>> / xt)"), ("131", "ROC-131 — 3 faz + toprak (Mod / I>> / xt ortak)"))),
    ctl("ct_ph", "Faz AT primeri ( … / 5 A)", "sayi", 100, min=5, max=4000, adim=5, birim="A"),
    ctl("ct_e", "Toprak AT primeri", "sayi", 100, min=5, max=4000, adim=5, birim="A", yardim="Fazların artık akım bağlantısında faz AT oranı; toroidde toroidin oranı"),
    ctl("ct_es", "Toprak AT sekonderi", "sec", 5, secenek=opt((5, "5 A (faz AT'lerinin artık akım bağlantısı)"), (1, "1 A (toroid / ayrı AT)"))),
    ctl("e_is", "TOPRAK  Is⏚>  (taban 0,2 A)", "dip", "000100", anahtar=E_IS, goster=OKU),
    ctl("a_is", "A FAZI  Is A>  (taban 1 A)", "dip", "001000", anahtar=F_IS, goster=OKU),
    ctl("b_is", "B FAZI  Is B>  (taban 1 A)", "dip", "001000", anahtar=F_IS, goster={"yon": ["oku"], "model": ["131"]}),
    ctl("c_is", "C FAZI  Is C>  (taban 1 A)", "dip", "001000", anahtar=F_IS, goster=OKU),
    ctl("f_mode", "FAZ  Mode  (ROC-131'de ortak)", "dip", "0000", anahtar=E_MOD, sag=SAG_MOD, goster=OKU, yardim="Sol: ∞ (ani açma iptal) ve 1 · sağ: ON (ani açma devrede) ve 0"),
    ctl("f_inst", "FAZ  I>> × Is  (taban 2; ROC-131'de ortak)", "dip", "0010", anahtar=E_ANI, goster=OKU),
    ctl("f_xt", "FAZ  xt  (hepsi kapalı: 0,05; ROC-131'de ortak)", "dip", "1000", anahtar=E_XT, goster=OKU),
    ctl("t_mode", "TOPRAK  Mode", "dip", "0000", anahtar=E_MOD, sag=SAG_MOD, goster=OKU121),
    ctl("t_inst", "TOPRAK  I>> × Is  (taban 2)", "dip", "0010", anahtar=E_ANI, goster=OKU121),
    ctl("t_xt", "TOPRAK  xt  (hepsi kapalı: 0,05)", "dip", "1000", anahtar=E_XT, goster=OKU121),
    ctl("rf_is", "Faz: çalışma akımı Is (primer)", "sayi", 40, min=1, max=10000, adim=1, birim="A", goster=BUL),
    ctl("rf_egri", "Faz: eğri", "sec", 0, secenek=EGRI_SEC, goster=BUL),
    ctl("rf_t", "Faz: aşağıdaki arıza akımında istenen açma süresi", "sayi", 0.45, min=0.05, max=60, adim=0.05, birim="s", goster=BUL),
    ctl("rf_ani", "Faz: ani açma I>> (primer; 0 = kullanılmasın)", "sayi", 400, min=0, max=40000, adim=10, birim="A", goster=BUL),
    ctl("rt_is", "Toprak: çalışma akımı Is (primer)", "sayi", 10, min=1, max=5000, adim=1, birim="A", goster=BUL),
    ctl("rt_egri", "Toprak: eğri", "sec", 0, secenek=EGRI_SEC, goster=BUL121),
    ctl("rt_t", "Toprak: aşağıdaki arıza akımında istenen açma süresi", "sayi", 0.5, min=0.05, max=60, adim=0.05, birim="s", goster=BUL121),
    ctl("rt_ani", "Toprak: ani açma I>> (primer; 0 = kullanılmasın)", "sayi", 100, min=0, max=20000, adim=5, birim="A", goster=BUL121),
    ctl("i_f", "Faz arıza akımı (primer)", "sayi", 200, min=1, max=40000, adim=5, birim="A"),
    ctl("i_e", "Toprak arıza akımı (primer)", "sayi", 40, min=1, max=20000, adim=1, birim="A"),
]


def _ters(is_p: float, oran: float, taban_adim: tuple, egri: int, i_ar: float, t_ist: float, ani_p: float, notlar: list, ad: str) -> dict:
    """İstenen primer değerlerden DIP konumları."""
    taban, adimlar = taban_adim
    ust = taban + sum(adimlar)
    hedef = is_p / oran
    if hedef < taban - 1e-9:
        notlar.append(f"{ad}: istenen Is rölenin en düşük ayarının altında ({fnum(taban * oran, 1)} A primer); en düşük ayar seçildi.")
    if hedef > ust + 1e-9:
        notlar.append(f"{ad}: istenen Is en yüksek ayarın üstünde ({fnum(ust * oran, 1)} A primer); AT oranı büyütülmeli.")
    b_is, s = en_yakin(adimlar, min(max(hedef, taban), ust) - taban)
    is_sek = round(taban + s, 4)
    is_prim = is_sek * oran
    if ani_p > 0:
        kat = ani_p / is_prim
        if kat < 2 - 1e-9:
            notlar.append(f"{ad}: I>> en az 2 × Is olabilir ({fnum(2 * is_prim, 1)} A primer).")
        if kat > 17 + 1e-9:
            notlar.append(f"{ad}: I>> en çok 17 × Is olabilir ({fnum(17 * is_prim, 1)} A primer).")
        b_ani, sa = en_yakin(ANI[1], min(max(kat, 2.0), 17.0) - 2.0)
        ani_iptal = 0
    else:
        b_ani, ani_iptal = [0, 0, 0, 0], 1
    b_mod = [ani_iptal, (egri >> 2) & 1, (egri >> 1) & 1, egri & 1]
    m = i_ar / is_prim
    xt_ist = None
    b_xt = [1, 0, 0, 0]
    if m > 1.0 and t_ist > 0:
        xt_ist = t_ist / SABIT[egri - 4] if egri >= 4 else t_ist * (m ** EGRI[egri][2] - 1) / EGRI[egri][1]
        if xt_ist < XT_MIN - 1e-9:
            notlar.append(f"{ad}: bu süre için gereken xt ({yaz(xt_ist, 3)}) en küçük değerin (0,05) altında; daha uzun süre ya da daha dik bir eğri seçin.")
        if xt_ist > 1.0 + 1e-9:
            notlar.append(f"{ad}: bu süre için gereken xt ({yaz(xt_ist, 3)}) en büyük değerin (1,0) üstünde; daha yavaş bir eğri ya da daha küçük Is seçin.")
        b_xt, _ = xt_bul(xt_ist)
    elif m <= 1.0:
        notlar.append(f"{ad}: arıza akımı Is'in altında; röle bu akımda açmaz.")
    return {"is": b_is, "mod": b_mod, "ani": b_ani, "xt": b_xt, "xt_ist": xt_ist}


def _blok(cz: Cizim, x: float, y: float, w: float, baslik: str, etiket: list, bits: list, alt: str, sag: list | None = None) -> None:
    """Ön paneldeki bir DIP bloğu: sol yanda değerler; çubuk sola (değere doğru) itiliyse değer eklenir."""
    cz.yazi(x + w / 2, y, baslik, "#e8ecef", 11, kalin=True, anchor="middle")
    n = len(bits); xs = x + 52; tw = w - 52 - (26 if sag else 6)
    cz.dikdortgen(xs - 4, y + 8, tw + 8, n * 15 + 6, "#7e211c", "#a8322b", kw=1.2, r=3)
    for k in range(n):
        yy = y + 12 + k * 15
        cz.yazi(xs - 8, yy + 9, etiket[k], "#f7e9e7" if bits[k] else "#9aa4ad", 10, kalin=bool(bits[k]), anchor="end")
        cz.dikdortgen(xs, yy, tw, 11, "#5c1814", "#7e211c", kw=0.6, r=2)
        cz.dikdortgen(xs + (1 if bits[k] else tw / 2), yy + 1, tw / 2 - 1, 9, "#d6d0c2", "#f4f1ea", kw=0.5, r=1.5)
        if sag:
            cz.yazi(xs + tw + 8, yy + 9, sag[k], "#9aa4ad" if bits[k] else "#f7e9e7", 9.5)
    cz.yazi(x + w / 2, y + n * 15 + 28, alt, "#ffd27a", 11, kalin=True, anchor="middle")


def run(p: dict) -> dict:
    yon, model = str(p.get("yon", "oku")), str(p.get("model", "121"))
    ortak = model == "131"
    ct_ph, ct_e, ct_es = max(num(p, "ct_ph", 100), 1.0), max(num(p, "ct_e", 100), 1.0), num(p, "ct_es", 5) or 5
    o_f, o_e = ct_ph / 5.0, ct_e / ct_es
    i_f, i_e = num(p, "i_f", 200), num(p, "i_e", 40)
    notlar: list = []
    if yon == "bul":
        rf = _ters(num(p, "rf_is", 40), o_f, IS_FAZ, int(num(p, "rf_egri", 0)), i_f, num(p, "rf_t", 0.45), num(p, "rf_ani", 400), notlar, "Faz")
        b = {"a_is": rf["is"], "b_is": rf["is"], "c_is": rf["is"], "f_mode": rf["mod"], "f_inst": rf["ani"], "f_xt": rf["xt"]}
        if ortak:
            rt = _ters(num(p, "rt_is", 10), o_e, IS_TOPRAK, int(num(p, "rf_egri", 0)), i_e, 0.0, 0.0, [], "Toprak")
            b.update({"e_is": rt["is"], "t_mode": rf["mod"], "t_inst": rf["ani"], "t_xt": rf["xt"]})
            rt["xt_ist"] = None
        else:
            rt = _ters(num(p, "rt_is", 10), o_e, IS_TOPRAK, int(num(p, "rt_egri", 0)), i_e, num(p, "rt_t", 0.5), num(p, "rt_ani", 100), notlar, "Toprak")
            b.update({"e_is": rt["is"], "t_mode": rt["mod"], "t_inst": rt["ani"], "t_xt": rt["xt"]})
    else:
        rf = rt = None
        b = {k: bitler(p.get(k), n) for k, n in (("e_is", 6), ("a_is", 6), ("b_is", 6), ("c_is", 6), ("f_mode", 4), ("f_inst", 4), ("f_xt", 4), ("t_mode", 4), ("t_inst", 4), ("t_xt", 4))}
        if ortak:
            b.update({"t_mode": b["f_mode"], "t_inst": b["f_inst"], "t_xt": b["f_xt"]})
    if not ortak:
        b["b_is"] = b["a_is"]
    # ---- ayarlar ----
    is_a, is_b, is_c, is_e = toplam(b["a_is"], *IS_FAZ), toplam(b["b_is"], *IS_FAZ), toplam(b["c_is"], *IS_FAZ), toplam(b["e_is"], *IS_TOPRAK)
    fazlar = [("A", is_a), ("C", is_c)] if not ortak else [("A", is_a), ("B", is_b), ("C", is_c)]
    is_f = min(v for _, v in fazlar)                                       # en duyarlı faz elemanı
    f_iptal, f_egri = mod_coz(b["f_mode"]); t_iptal, t_egri = mod_coz(b["t_mode"])
    f_kat = None if f_iptal else toplam(b["f_inst"], *ANI); t_kat = None if t_iptal else toplam(b["t_inst"], *ANI)
    f_xt, t_xt = xt_deger(b["f_xt"]), xt_deger(b["t_xt"])
    isf_p, ise_p = is_f * o_f, is_e * o_e
    af, ae = acma(i_f, isf_p, f_egri, f_xt, f_kat), acma(i_e, ise_p, t_egri, t_xt, t_kat)
    esit = max(v for _, v in fazlar) - is_f < 1e-9
    if_sek, ie_sek = i_f / o_f, i_e / o_e

    def sonuc(a: dict) -> str:
        return "açmaz" if a["t"] is None else "ani (≈ 40 ms)" if a["tur"] == "ani" else fsure(a["t"])

    def belirsiz(i: float, is_p: float, kat) -> bool:
        return bool(kat) and (1 - HATA) * kat * is_p <= i < (1 + HATA) * kat * is_p

    def ani_yaz(kat, is_sek: float, oran: float) -> str:
        return "devre dışı (∞)" if kat is None else f"{yaz(kat)} × Is = {yaz(kat * is_sek)} A sek → {fnum(kat * is_sek * oran, 1)} A primer"

    # ---- ön panel ----
    cz = Cizim(900, 372)
    cz.dikdortgen(8, 6, 884, 360, "#c9c3b2", "#2a2f35", kw=3, r=10)
    cz.yazi(26, 28, ("ROC-131 · 3 Faz 1 Toprak" if ortak else "ROC-121 · 2 Faz 1 Toprak") + " Aşırı Akım Rölesi", "#e8ecef", 13, kalin=True)
    cz.yazi(872, 28, "sola itili çubuk = değer eklenir", "#9aa4ad", 10.5, anchor="end")
    ust = [("TOPRAK  Is⏚> (A)", E_IS, b["e_is"], f"= {yaz(is_e)} A")] + [(f"{f} FAZI  Is {f}> (A)", F_IS, b[f.lower() + "_is"], f"= {yaz(v)} A") for f, v in fazlar]
    wu = 860.0 / len(ust)
    for k, (bs, et, bt, alt) in enumerate(ust):
        _blok(cz, 20 + k * wu + (wu - 170) / 2, 52, 170, bs, et, bt, alt)
    y2 = 208
    mod_alt = lambda eg, ip: MOD_AD[eg] + (" · ani iptal" if ip else "")          # noqa: E731
    if ortak:
        alt_b = [("Mode (ortak)", E_MOD, b["f_mode"], mod_alt(f_egri, f_iptal), SAG_MOD), ("I>> × Is (ortak)", E_ANI, b["f_inst"], "= " + yaz(toplam(b["f_inst"], *ANI)) + " × Is", None),
                 ("xt (ortak)", E_XT, b["f_xt"], "= " + yaz(f_xt), None)]
    else:
        alt_b = [("FAZ  Mode", E_MOD, b["f_mode"], mod_alt(f_egri, f_iptal), SAG_MOD), ("FAZ  I>> × Is", E_ANI, b["f_inst"], "= " + yaz(toplam(b["f_inst"], *ANI)) + " × Is", None),
                 ("FAZ  xt", E_XT, b["f_xt"], "= " + yaz(f_xt), None),
                 ("TOPRAK  Mode", E_MOD, b["t_mode"], mod_alt(t_egri, t_iptal), SAG_MOD), ("TOPRAK  I>> × Is", E_ANI, b["t_inst"], "= " + yaz(toplam(b["t_inst"], *ANI)) + " × Is", None),
                 ("TOPRAK  xt", E_XT, b["t_xt"], "= " + yaz(t_xt), None)]
    wa = 860.0 / len(alt_b)
    for k, (bs, et, bt, alt, sg) in enumerate(alt_b):
        _blok(cz, 20 + k * wa + (wa - 132) / 2, y2, 132, bs, et, bt, alt, sg)
    cz.yazi(26, 352, f"Faz arızası {fnum(i_f, 0)} A: {sonuc(af)}  ·  Toprak arızası {fnum(i_e, 0)} A: {sonuc(ae)}", "#ffd27a", 12.5, kalin=True)
    # ---- özet ----
    ozet = [
        K("Faz Is>", f"{yaz(is_f)} A sek → {fnum(isf_p, 1)} A", "warn" if not esit else "info", f"{MOD_AD[f_egri]} · xt {yaz(f_xt)}" + ("" if esit else " · fazlar farklı ayarlı")),
        K("Faz I>> (ani)", "devre dışı" if f_kat is None else f"{yaz(f_kat)} × Is → {fnum(f_kat * isf_p, 1)} A", "info", "∞ konumunda iptal" if f_kat is None else f"{yaz(f_kat * is_f)} A sek · ≈ 40 ms"),
        K("Toprak Is⏚>", f"{yaz(is_e)} A sek → {fnum(ise_p, 1)} A", "info", f"{MOD_AD[t_egri]} · xt {yaz(t_xt)}"),
        K("Toprak I>> (ani)", "devre dışı" if t_kat is None else f"{yaz(t_kat)} × Is → {fnum(t_kat * ise_p, 1)} A", "info", "∞ konumunda iptal" if t_kat is None else f"{yaz(t_kat * is_e)} A sek · ≈ 40 ms"),
        K(f"Faz arızası {fnum(i_f, 0)} A", sonuc(af), "bad" if af["t"] is None else "ok", af["neden"]),
        K(f"Toprak arızası {fnum(i_e, 0)} A", sonuc(ae), "bad" if ae["t"] is None else "ok", ae["neden"]),
    ]
    kontroller = [
        C("Faz elemanları aynı ayarlanmış mı?", " · ".join(f"{f}: {yaz(v)} A" for f, v in fazlar), "aynı değer", esit,
          "Fazların çalışma akımı olağan olarak aynı ayarlanır; farklıysa hesap en düşük ayarlı (en duyarlı) faza göre yapılır. Rölede yeniden bakın", "ikincil"),
        C("Faz arıza akımında röle açıyor mu?", f"{fnum(i_f, 0)} A = {yaz(af['m'])} × Is → {sonuc(af)}", "I > Is; ters zamanlı eğride güvenli bölge ≥ 1,1 × Is", af["t"] is not None and (af["tur"] == "ani" or f_egri >= 4 or af["m"] >= 1.1),
          f"{GEPA}: akım Is> ayarının üstüne çıkınca PICK-UP LED'i yanar, gecikme sonunda açma yapılır; ayar hatası ±%5. 1,1 × Is'in altında süre çok uzar ve belirsizdir", "resmi"),
        C("Toprak arıza akımında röle açıyor mu?", f"{fnum(i_e, 0)} A = {yaz(ae['m'])} × Is → {sonuc(ae)}", "I > Is; ters zamanlı eğride güvenli bölge ≥ 1,1 × Is", ae["t"] is not None and (ae["tur"] == "ani" or t_egri >= 4 or ae["m"] >= 1.1),
          f"{GEPA}: toprak elemanı da aynı biçimde çalışır; toprak arızasında hem «Faz açma» hem «Toprak açma» rölesi enerjilenir", "resmi"),
        C("Arıza akımları ani açma eşiğinin belirsiz bölgesinin dışında mı?", f"faz I>> {fnum(f_kat * isf_p, 0) if f_kat else '—'} A · toprak I>> {fnum(t_kat * ise_p, 0) if t_kat else '—'} A",
          "arıza akımı eşiğin ±%5'i içinde olmamalı", not (belirsiz(i_f, isf_p, f_kat) or belirsiz(i_e, ise_p, t_kat)),
          f"{GEPA}: ani açma ayar hatası ±%5; 40 ms'lik süre ayarın 1,2 katında geçerlidir. Eşiğe çok yakın akımda rölenin ani mi gecikmeli mi açacağı belli olmaz", "resmi"),
        C("Röle girişleri arıza akımına dayanır mı?", f"faz girişi {fnum(if_sek, 1)} A · toprak girişi {fnum(ie_sek, 1)} A (sekonder)", f"1 s için ≤ 100 × In: faz {fnum(100 * IN_FAZ, 0)} A · toprak {fnum(100 * IN_TOPRAK, 0)} A",
          if_sek <= 100 * IN_FAZ and ie_sek <= 100 * IN_TOPRAK, f"{GEPA} (teknik özellikler): In = 5 A (faz), 1 A (toprak); aşırı yük akımı sürekli 2 In, 1 s 100 In. Toprak girişi 1 A anma akımlıdır: sürekli en çok 2 A", "resmi"),
        C("Toprak ayarı fazların dengesizlik akımının üstünde mi?", f"Is⏚ = {fnum(ise_p, 1)} A primer", f"faz AT primerinin ≳ %10'u ({fnum(0.1 * ct_ph, 0)} A) — artık akım bağlantısında", (ise_p >= 0.1 * ct_ph) if ct_es == 5 else None,
          "Artık akım (Holmgreen) bağlantısında AT hataları ve yük dengesizliği toprak girişinden akım geçirir; çok düşük ayar yanlış açtırır. Toroidde bu sınır aranmaz", "ikincil"),
    ]
    if yon == "bul":
        kontroller.insert(0, C("İstenen değerler rölenin ayar aralığında mı?", "uygun" if not notlar else f"{len(notlar)} uyarı: " + " ".join(notlar), "Is faz 1–16,75 A · toprak 0,2–3,35 A · I>> 2–17 × Is · xt 0,05–1,0",
                               not notlar, f"{GEPA} (teknik özellikler): ayar aralıkları ve adımları", "resmi"))
    if yon == "bul":
        def tutma(ad: str, sn: dict, t_ist: float, ac: dict, is_p: float, egri: int, xt: float, i: float) -> None:
            if sn.get("xt_ist") is None or ac["m"] <= 1.0:
                return
            komsu = " · ".join(f"xt {yaz(q)}: {fsure(sure(ac['m'], egri, q))}" for q in (round(xt - 0.1, 2) if xt > 0.11 else XT_MIN, round(xt + 0.1, 2) if xt >= 0.1 else 0.1) if XT_MIN <= q <= 1.0 and abs(q - xt) > 1e-9)
            t = sure(ac["m"], egri, xt)
            kontroller.insert(1, C(f"{ad}: bulunan ayar istenen süreyi veriyor mu?", f"istenen {fsure(t_ist)} → {sonuc(ac)} (xt {yaz(xt)}; gereken {yaz(sn['xt_ist'], 3)})", "±%20 içinde — xt 0,1'lik adımlarla ayarlanır",
                                   ac["tur"] == "zaman" and abs(t - t_ist) <= 0.2 * t_ist, f"{GEPA} (teknik özellikler): zaman çarpanı 0,05–1,0, 0,1'lik adımlarla. Komşu kademeler: {komsu or '—'}"
                                   + (" Bu akım I>> eşiğinin üstünde: röle ani açar, istenen süre devreye girmez." if ac["tur"] == "ani" else ""), "resmi"))
        if not ortak:
            tutma("Toprak", rt, num(p, "rt_t", 0.5), ae, ise_p, t_egri, t_xt, i_e)
        tutma("Faz", rf, num(p, "rf_t", 0.45), af, isf_p, f_egri, f_xt, i_f)
    girdiler = [
        G("Akım trafosu oranları", f"faz {fnum(ct_ph, 0)}/5 A · toprak {fnum(ct_e, 0)}/{fnum(ct_es, 0)} A", "AT etiketi; tek hat şeması", "Röle sekonder amperle ayarlanır; primer değer AT oranıyla bulunur",
          f"oran: faz {yaz(o_f)} · toprak {yaz(o_e)}"),
        G("DIP konumları (1 = sola itili)", f"Is⏚ {bit_yaz(b['e_is'])} · " + " · ".join(f"Is {f} {bit_yaz(b[f.lower() + '_is'])}" for f, _ in fazlar), "Röle ön paneli (fotoğraf: tam karşıdan, flaşsız)",
          "Her çubuk, değerin yazılı olduğu yöne itiliyse o değer toplama eklenir", f"Mod {bit_yaz(b['f_mode'])} · I>> {bit_yaz(b['f_inst'])} · xt {bit_yaz(b['f_xt'])}"
          + ("" if ortak else f" | toprak: Mod {bit_yaz(b['t_mode'])} · I>> {bit_yaz(b['t_inst'])} · xt {bit_yaz(b['t_xt'])}")),
        G("Arıza akımları", f"faz {fnum(i_f, 0)} A · toprak {fnum(i_e, 0)} A (primer)", "Kısa devre hesabı; koordinasyon çalışması", "Açma süresi akımın Is'e oranına bağlıdır", f"sekonder: {fnum(if_sek, 2)} A · {fnum(ie_sek, 2)} A"),
    ]
    k_f = EGRI[f_egri] if f_egri < 4 else None; k_t = EGRI[t_egri] if t_egri < 4 else None
    egri_k = lambda eg: (P3U + " (IEC eğri sabitleri çizelgesi); " + GEPA + ": eğriler IEC-255 ve BS-142'ye göre", "resmi") if eg < 3 else (          # noqa: E731
        GEPA + ": «Long Time, Very Inverse'e çok benzer; zamanlar 10 kat daha uzun» — standart IEC değeri 120 alındı, sınamayla doğrulanacak", "dogrulanacak") if eg == 3 else (
        GEPA + " (teknik özellikler): sabit zamanlı kipte gecikme = Time Lag × xt (0,125–2,5 · 0,25–5 · 0,5–10 · 0,75–15 s)", "resmi")
    adimlar = [
        A("Faz çalışma akımı", "Is = 1 + Σ(sola itili anahtarlar)", f"1 + ({' + '.join(yaz(a) for bt, a in zip(b['a_is'], IS_FAZ[1]) if bt) or '0'})", f"{yaz(is_a)} A sek → {fnum(is_a * o_f, 1)} A primer",
          f"{GEPA}: örnek Is = 1 + (0,25 + 1 + 4) = 6,25 A; aralık 1–16,75 A", "resmi", ["DIP konumları (1 = sola itili)", "Akım trafosu oranları"]),
        A("Toprak çalışma akımı", "Is⏚ = 0,2 + Σ(sola itili anahtarlar)", f"0,2 + ({' + '.join(yaz(a) for bt, a in zip(b['e_is'], IS_TOPRAK[1]) if bt) or '0'})", f"{yaz(is_e)} A sek → {fnum(ise_p, 1)} A primer",
          f"{GEPA} (teknik özellikler): toprak 0,2–3,35 A, 0,05 A adım", "resmi"),
        A("Ani açma", "I>> = [2 + Σ] × Is", f"faz: [2 + ({' + '.join(yaz(a) for bt, a in zip(b['f_inst'], ANI[1]) if bt) or '0'})] × {yaz(is_f)}",
          f"faz {ani_yaz(f_kat, is_f, o_f)} · toprak {ani_yaz(t_kat, is_e, o_e)}", f"{GEPA}: örnek I>> = [2 + (1 + 4)] × Is = 7 Is; MODE'un birinci anahtarı ∞ konumunda ani açma iptal", "resmi"),
        A("Zaman çarpanı", "xt = Σ(sola itili anahtarlar); hepsi kapalıysa 0,05", f"faz: {' + '.join(yaz(a) for bt, a in zip(b['f_xt'], XT) if bt) or 'hepsi kapalı'}", f"faz {yaz(f_xt)} · toprak {yaz(t_xt)}",
          f"{GEPA}: örnek xt = 0,1 + 0,3 + 0,4 = 0,8 (taban eklenmez); aralık 0,05–1,0", "resmi"),
        A("Eğri", "MODE A-B-C kodu", f"faz {''.join(str(x) for x in b['f_mode'][1:])} · toprak {''.join(str(x) for x in b['t_mode'][1:])}", f"faz {MOD_AD[f_egri]} · toprak {MOD_AD[t_egri]}",
          f"{GEPA}: MODE çizelgesi (000 Normal Inverse … 111 Time Lag 4)", "resmi"),
        A("Faz arızasında süre", ("t = xt · " + yaz(k_f[1]) + " / (M^" + yaz(k_f[2]) + " − 1)") if k_f else "t = Time Lag × xt", f"M = {fnum(i_f, 0)} / {fnum(isf_p, 1)} = {yaz(af['m'])} · xt = {yaz(f_xt)}",
          sonuc(af), *egri_k(f_egri)),
        A("Toprak arızasında süre", ("t = xt · " + yaz(k_t[1]) + " / (M^" + yaz(k_t[2]) + " − 1)") if k_t else "t = Time Lag × xt", f"M = {fnum(i_e, 0)} / {fnum(ise_p, 1)} = {yaz(ae['m'])} · xt = {yaz(t_xt)}",
          sonuc(ae), *egri_k(t_egri)),
    ]
    ayarlar = [S(f"Is {f}> (faz {f})", f"{yaz(v)} A", acik_yaz(b[f.lower() + "_is"], F_IS), "Gecikmeli açma (51) çalışma akımı", GEPA, "resmi") for f, v in fazlar] + [
        S("Is⏚> (toprak)", f"{yaz(is_e)} A", acik_yaz(b["e_is"], E_IS), "Toprak arızası (51N) çalışma akımı", GEPA, "resmi"),
        S("Mode" + (" (ortak)" if ortak else " — faz"), MOD_AD[f_egri] + (" · ani iptal" if f_iptal else " · ani devrede"), "∞ " + ("solda (∞)" if f_iptal else "sağda (ON)") + " · A B C = " + " ".join(str(x) for x in b["f_mode"][1:]),
          "Eğri ve ani açmanın devrede olup olmadığı", GEPA, "resmi"),
        S("I>> × Is" + (" (ortak)" if ortak else " — faz"), yaz(toplam(b["f_inst"], *ANI)) + " × Is" + (" (iptal)" if f_iptal else ""), acik_yaz(b["f_inst"], E_ANI), "Ani açma (50) eşiği", GEPA, "resmi"),
        S("xt" + (" (ortak)" if ortak else " — faz"), yaz(f_xt), acik_yaz(b["f_xt"], E_XT), "Zaman çarpanı", GEPA, "resmi"),
    ]
    if not ortak:
        ayarlar += [
            S("Mode — toprak", MOD_AD[t_egri] + (" · ani iptal" if t_iptal else " · ani devrede"), "∞ " + ("solda (∞)" if t_iptal else "sağda (ON)") + " · A B C = " + " ".join(str(x) for x in b["t_mode"][1:]),
              "Toprak eğrisi ve ani açma", GEPA + " — ROC-121'de ayrı toprak bloğu kılavuzda gösterilmez", "dogrulanacak"),
            S("I>> × Is — toprak", yaz(toplam(b["t_inst"], *ANI)) + " × Is" + (" (iptal)" if t_iptal else ""), acik_yaz(b["t_inst"], E_ANI), "Toprak ani açma (50N) eşiği", GEPA + " — ROC-121'de ayrı toprak bloğu kılavuzda gösterilmez", "dogrulanacak"),
            S("xt — toprak", yaz(t_xt), acik_yaz(b["t_xt"], E_XT), "Toprak zaman çarpanı", GEPA + " — ROC-121'de ayrı toprak bloğu kılavuzda gösterilmez", "dogrulanacak"),
        ]

    def sinama(ad: str, is_sek: float, egri: int, xt: float, kat) -> list:
        out = [T(f"{ad}: başlatma", f"Akımı yavaşça artırın: {yaz(is_sek * 0.9, 3)} A → {yaz(is_sek * 1.1, 3)} A (sekonder)", f"PICK-UP LED'i {yaz(is_sek * (1 - HATA), 3)} – {yaz(is_sek * (1 + HATA), 3)} A arasında yanar",
                 "ayar hatası ±%5; bırakma ≈ %95")]
        for m in (2.0, 5.0):
            if kat and m >= kat * (1 - HATA):
                continue
            t = sure(m, egri, xt)
            out.append(T(f"{ad}: süre ({yaz(m)} × Is)", f"{yaz(m * is_sek, 3)} A sekonder, ani uygulayın", f"{fsure(t)} ({fsure(t * (1 - HATA))} – {fsure(t * (1 + HATA))})", "süreye kesici açma süresi dahil değildir"))
        if kat:
            out.append(T(f"{ad}: ani açma", f"{yaz(1.2 * kat * is_sek, 2)} A sekonder (1,2 × I>>)", "≤ 40 ms; ANİ LED'i yanar", f"{yaz(0.9 * kat * is_sek, 2)} A'de gecikmeli açmalı"))
        return out

    test = sinama("Faz", is_f, f_egri, f_xt, f_kat) + sinama("Toprak", is_e, t_egri, t_xt, t_kat) + [
        T("TEST düğmesi", "Röle enerjiliyken basın (kesici açar!)", "ani devredeyse ani açma + ANİ LED'i; ∞ konumundaysa gecikmeli açma", "RESET ihbar LED'lerini siler")]
    # ---- eğri ----
    def egri_pts(is_p: float, egri: int, xt: float, kat) -> list:
        pts, ust = [], (kat * 1.8 if kat else 30.0)
        for k in range(81):
            m = 1.03 * (ust / 1.03) ** (k / 80)
            a = acma(m * is_p, is_p, egri, xt, kat)
            if a["t"] is not None:
                pts.append([round(m * is_p, 2), round(min(max(a["t"], 0.01), 1000.0), 4)])
        return pts

    g1 = {"baslik": "Akım – zaman eğrisi (primer)", "x_ad": "Primer akım (A)", "y_ad": "Süre (s)", "logx": True, "logy": True,
          "seriler": [{"ad": f"faz · {MOD_AD[f_egri]} · xt {yaz(f_xt)}", "renk": "#c2410c", "pts": egri_pts(isf_p, f_egri, f_xt, f_kat)},
                      {"ad": f"toprak · {MOD_AD[t_egri]} · xt {yaz(t_xt)}", "renk": "#0f766e", "pts": egri_pts(ise_p, t_egri, t_xt, t_kat)}],
          "isaretler": [{"x": i_f, "etiket": "faz arızası"}, {"x": i_e, "etiket": "toprak arızası"}]}
    katlar = (1.5, 2.0, 3.0, 5.0, 10.0, 15.0, 20.0)
    satir = lambda m, is_sek, oran, egri, xt, kat: ("ani" if kat and m >= kat else fsure(sure(m, egri, xt)))          # noqa: E731
    rows = [[yaz(m) + " × Is", f"{yaz(m * is_f, 2)} A / {fnum(m * isf_p, 0)} A", satir(m, is_f, o_f, f_egri, f_xt, f_kat), f"{yaz(m * is_e, 2)} A / {fnum(m * ise_p, 0)} A", satir(m, is_e, o_e, t_egri, t_xt, t_kat)] for m in katlar]
    mod_rows = [[ad + (" ◀ faz" if k == f_egri else "") + (" ◀ toprak" if k == t_egri else ""), f"{(k >> 2) & 1} {(k >> 1) & 1} {k & 1}",
                 (f"t = xt · {yaz(EGRI[k][1])} / (M^{yaz(EGRI[k][2])} − 1)" if k < 4 else f"t = {yaz(SABIT[k - 4])} s × xt"),
                 (fsure(EGRI[k][1] / (2 ** EGRI[k][2] - 1)) + " · " + fsure(EGRI[k][1] / (10 ** EGRI[k][2] - 1))) if k < 4 else fsure(SABIT[k - 4])] for k, ad in enumerate(MOD_AD)]
    kopya = "\n".join([
        "GEPA " + ("ROC-131" if ortak else "ROC-121") + " ayarı",
        f"Faz AT {fnum(ct_ph, 0)}/5 A · Toprak AT {fnum(ct_e, 0)}/{fnum(ct_es, 0)} A",
        *[f"Is {f}>: {yaz(v)} A sek ({fnum(v * o_f, 1)} A primer)" for f, v in fazlar],
        f"Faz eğri: {MOD_AD[f_egri]}, xt = {yaz(f_xt)}", "Faz I>>: " + ani_yaz(f_kat, is_f, o_f),
        f"Is toprak>: {yaz(is_e)} A sek ({fnum(ise_p, 1)} A primer)", f"Toprak eğri: {MOD_AD[t_egri]}, xt = {yaz(t_xt)}", "Toprak I>>: " + ani_yaz(t_kat, is_e, o_e),
        f"Faz arızası {fnum(i_f, 0)} A: {sonuc(af)} · Toprak arızası {fnum(i_e, 0)} A: {sonuc(ae)}",
        "DIP (1 = sola itili, yukarıdan aşağı): Is toprak " + bit_yaz(b["e_is"]) + " | " + " | ".join(f"Is {f} {bit_yaz(b[f.lower() + '_is'])}" for f, _ in fazlar)
        + f" | Mod {bit_yaz(b['f_mode'])} | I>> {bit_yaz(b['f_inst'])} | xt {bit_yaz(b['f_xt'])}"
        + ("" if ortak else f" | Toprak mod {bit_yaz(b['t_mode'])} | Toprak I>> {bit_yaz(b['t_inst'])} | Toprak xt {bit_yaz(b['t_xt'])}"),
    ])
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1], "kopya": kopya,
        "anlatim": [
            "ROC serisi rölelerde her ayar bloğu bir taban değer ve yanında değerleri yazılı anahtarlardan oluşur. Çubuk, değerin yazılı olduğu yöne (sola) itildiğinde o değer toplama eklenir; öbür yönde eklenmez. Bütün çubuklar kapalıyken ayar taban değerdedir: faz 1 A, toprak 0,2 A, ani açma 2 × Is.",
            f"Akım ayarları AT sekonderindeki amperdir. Burada faz {yaz(is_f)} A sekonder, {fnum(ct_ph, 0)}/5 oranıyla {fnum(isf_p, 1)} A primer eder; toprak {yaz(is_e)} A sekonder, {fnum(ise_p, 1)} A primer.",
            f"Zaman çarpanı öbür bloklardan farklı çalışır: taban değer eklenmez. xt, açık anahtarların toplamıdır; yalnız hepsi kapalıyken 0,05 olur. Kılavuzdaki örnek: 0,1 + 0,3 + 0,4 = 0,8. Şimdiki ayar: faz {yaz(f_xt)}, toprak {yaz(t_xt)}.",
            "MODE bloğunun birinci anahtarı ani açmayı yönetir: sol yanında ∞, sağ yanında ON yazar. Çubuk ∞ yanındaysa ani açma iptaldir; ON yanındaysa devrededir. Öbür üç anahtar (A, B, C) eğriyi seçer: sol yan 1, sağ yan 0'dır. Panelde bloğun sağında yazan «ON 0 0 0» bir ayar değil, sağ konumların anlamıdır.",
            (f"Faz arızasında {fnum(i_f, 0)} A, ayarın {yaz(af['m'])} katıdır: {sonuc(af)}. " if af["t"] is not None else f"Faz arıza akımı {fnum(i_f, 0)} A ayarın altında kalıyor: röle açmaz. ")
            + (f"Toprak arızasında {fnum(i_e, 0)} A, ayarın {yaz(ae['m'])} katıdır: {sonuc(ae)}." if ae["t"] is not None else f"Toprak arıza akımı {fnum(i_e, 0)} A ayarın altında kalıyor: röle açmaz."),
            ("ROC-121 iki faz elemanlıdır (A ve C). B fazı – toprak arızasını yalnız toprak elemanı görür; B fazını içeren iki fazlı arızayı A ya da C elemanı görür. Bu yüzden toprak ayarının doğru ve duyarlı olması bu rölede ayrıca önemlidir."
             if not ortak else "ROC-131'de Mod, I>> ve xt blokları üç faz ve toprak için ortaktır: toprak elemanı aynı eğriyi ve aynı zaman çarpanını kullanır; ani açma eşiği her elemanın kendi Is değerinin aynı katıdır."),
            "Toprak girişinin anma akımı 1 A'dir (sürekli en çok 2 A). Faz akım trafolarının artık akım bağlantısında yük dengesizliği ve AT hataları bu girişten akım geçirir; polarite hatası varsa tesis yüklendiğinde röle sürekli açtırır (kılavuzdaki uyarı).",
            "Enerjili hücrede DIP anahtarlarına dokunmayın: bir çubuğun kayması ayarı değiştirir ve açmaya yol açabilir. Önce paneli tam karşıdan fotoğraflayın; ayarı buradan okuyun. Kesin davranış sekonder enjeksiyonla görülür: «Test planı» kartındaki akım ve süreleri kullanın.",
        ],
        "dersler": [
            "Çubuk, değerin yazılı olduğu yana itiliyse değer eklenir: Is = taban + toplam.",
            "xt'de taban yoktur: xt = açık anahtarların toplamı; hepsi kapalıysa 0,05 (aralık 0,05–1,0).",
            "MODE: birinci anahtar ∞ (ani iptal) / ON (ani devrede); A-B-C eğriyi seçer, sol yan 1, sağ yan 0.",
            "Ani açma 2–17 × Is; süre ≈ 40 ms (ayarın 1,2 katında); ayar hatası ±%5.",
            "Akım ayarları sekonder amperdir; toprak girişi 1 A anma akımlıdır.",
        ],
        "tablolar": [
            {"baslik": "Bu ayarla akıma göre açma süresi", "cols": ["Akım", "Faz: sekonder / primer", "Faz süre", "Toprak: sekonder / primer", "Toprak süre"], "rows": rows,
             "not": "Süreler rölenin kendi süresidir; kesicinin açma süresi eklenir. Ayar hatası ±%5."},
            {"baslik": "MODE kodları ve eğriler", "cols": ["Eğri", "A B C", "Bağıntı (M = I / Is)", "xt = 1 iken: 2 × Is · 10 × Is"], "rows": mod_rows,
             "not": "A, B, C: sol yan 1, sağ yan 0. Ters zamanlı eğrilerin sabitleri standart IEC değerleridir; kılavuzun bu baskısında eğri çizelgesi yoktur. Long Time için 120 alındı (kılavuz: Very Inverse'in yaklaşık 10 katı): sınamayla doğrulayın."},
        ],
    }
