"""Röleye giderken elinizde olması gerekenler: hangi veri nereden alınır, hangi korumada kullanılır; birim dönüşümleri (×In, pu, %Un, sekonder).

Dayanak: röle kılavuzlarındaki ölçekleme tanımları (P3U/en M/J006 böl. 9.7, 5.1), Elektrik Tesisleri Kabul Yön. m.28-D, Lisanssız Üretim Tebliği m.17."""
from __future__ import annotations

from .ortak import A, C, G, K, KABUL, LUY, P3T, P3U, S, S3, T, at_ctl, ctl, fa, fnum, num, opt, sek, tek_hat

ID = "hazirlik"
BASLIK = "Röleye giderken"
IKON = "🧳"
GIRIS = ("Röle ayarı masada başlar. Sahaya çıkmadan önce elinizde olması gereken veriler, her birinin nereden alınacağı, hangi korumada ne işe yaradığı "
         "ve röledeki birimlere (×In, pu, %Un) nasıl çevrileceği burada. Diğer sayfaların hepsi bu verileri kullanır.")

KONTROLLER = at_ctl() + [
    ctl("taban", "Rölede faz akımının «×In» tabanı", "sec", "at", secenek=opt(("at", "AT primeri — fider rölesi (P3U, fider modu)"), ("nesne", "Korunan nesnenin anma akımı — trafo rölesi (P3T32), motor modu")),
        yardim="Trafo rölesinde 1 pu = trafonun anma akımıdır; röle bunu Sn ve Un'den hesaplar"),
    ctl("io_p", "Toprak akımı girişi (toroid ya da nötr AT) primeri", "sayi", 50, min=1, max=1000, adim=1, birim="A", yardim="Röledeki «Io1» girişinin anma değeri; Io ayarları «pu» bu değere göredir"),
    ctl("s_kva", "Korunan trafonun / santralin gücü", "sayi", 1870, min=50, max=40000, adim=10, birim="kVA", yardim="Etiketten"),
    ctl("ik_ka", "Baradaki üç fazlı kısa devre akımı", "sayi", 8.0, min=0.5, max=31.5, adim=0.1, birim="kA", yardim="Dağıtım şirketinin bağlantı görüşü ya da kısa devre hesabı"),
    ctl("i_prim", "Çevirmek istediğiniz primer akım", "sayi", 37.6, min=0.5, max=20000, adim=0.1, birim="A", yardim="Hesapla bulduğunuz ayar değeri (ör. 1,2 × azami yük)"),
    ctl("u_pct", "Çevirmek istediğiniz gerilim", "sayi", 88, min=1, max=150, adim=1, birim="%Un"),
]

KULLANIM = [          # (veri, nereden alınır, kullanan korumalar, ne işe yarar)
    ("Tek hat şeması (onaylı proje)", "Onaylı proje; dağıtım şirketinin bağlantı görüşü eki", "bütün fonksiyonlar", "Hangi hücrede hangi röle, AT ve GT'nin yeri, kesicinin neyi açtığı"),
    ("AT oranı, sınıfı, gücü (ör. 50/1 A, 5P20, 15 VA)", "Hücre etiketi; AT deney raporu", "50/51, 67, 87T, 46, 49, ark", "×In ayarları ve doyma denetimi"),
    ("Toprak akımı girişi (toroid oranı ya da faz toplamı)", "Toroid etiketi; röle bağlantı şeması", "50N/51N, 67N, 64REF", "Io ayarının «pu» karşılığı"),
    ("GT oranı ve sargı düzeni (3 faz–toprak, açık üçgen)", "GT etiketi; tek hat şeması", "67, 67N, 27, 59, 59N, 47, 24, 81", "%Un ayarları, yön kararının kutuplama gerilimi"),
    ("Trafo etiketi (S, U1/U2, uk, bağlantı grubu, kademe aralığı)", "Trafo etiketi; fabrika deney raporu", "87T, 64REF, 49T, 50/51, 24", "Anma akımları, faz kayması, demeraj ve kısa devre akımı"),
    ("Jeneratör etiketi (S, x″d, izin verilen I2)", "Jeneratör veri föyü (üretici)", "67, 46, 81, 81R", "Santralin arızaya katkısı; negatif bileşen dayanımı; atalet"),
    ("Azami yük / ihracat akımı", "Bağlantı anlaşmasındaki güç; yük hesabı; sayaç kayıtları", "50/51, 67, 49T, ark", "Başlatma eşiğinin alt sınırı (yükte açmasın)"),
    ("Kısa devre akımları (en büyük, en küçük; faz ve toprak)", "Dağıtım şirketinin bağlantı görüşü; kısa devre hesabı", "50/51, 50N/51N, 67, 87T, ark", "Eşiğin üst sınırı (arızada kesin açsın), AT doyması"),
    ("Nötr topraklama biçimi (direnç, bobin, yalıtılmış) ve akım sınırı", "Dağıtım şirketi (besleyen trafo merkezi)", "50N/51N, 67N, 59N, 64REF", "Toprak arıza akımının büyüklüğü ve açısı"),
    ("Hat / kablo verisi (tip, uzunluk, R ve X)", "Dağıtım şirketi; iletken ve kablo kataloğu", "67, 67N", "Arıza açısı φ = atan(X/R); kapasitif akım"),
    ("Üst merkezdeki referans rölenin ayarları", "Dağıtım şirketi; üst merkezdeki röleden okunur", "50/51, 50N/51N", "Seçicilik: bizim röle ondan önce açmalı"),
    ("Dağıtım şirketinin bağlantı görüşü ve koruma tutanağı", "Dağıtım şirketi", "27, 59, 81, 81R, 67, 59N", "Tebliğ sınır değerleri içindeki seçilmiş ayarlar"),
    ("Röle sipariş kodu ve yazılım sürümü", "Röle etiketi; röle bilgi ekranı", "bütün fonksiyonlar", "Hangi fonksiyonun, hangi girişin var olduğu; ayar aralıkları"),
    ("Kesici açma süresi ve açma bobini gerilimi", "Kesici etiketi; deney raporu", "bütün fonksiyonlar", "Toplam temizleme süresi (Tebliğ süreleri kesici dâhildir)"),
]


def run(p: dict) -> dict:
    un = num(p, "un_kv", 34.5); ct_p, ct_s = num(p, "ct_p", 50), num(p, "ct_s", 1); vt_s = num(p, "vt_s", 100)
    io_p = num(p, "io_p", 50); s = num(p, "s_kva", 1870); ik = num(p, "ik_ka", 8.0) * 1000
    i_prim = num(p, "i_prim", 37.6); u_pct = num(p, "u_pct", 88)
    i_n = s / (S3 * un)
    nesne = p.get("taban") == "nesne"
    i_taban = i_n if nesne else ct_p                              # faz akımında 1 ×In'in primer karşılığı
    x_in = i_prim / i_taban; i_sek = sek(i_prim, ct_p, ct_s)
    u_sek = u_pct / 100 * vt_s
    oran = i_n / ct_p
    ik_kat = ik / ct_p

    c = tek_hat(("Santral / trafo", f"{fnum(s, 0)} kVA"), ("Şebeke", f"Ik = {fnum(ik / 1000, 1)} kA"), ("Koruma rölesi", f"1 ×In = {fnum(i_taban, 1)} A"), "normal", None, "sag",
                at_ad=f"AT {ct_p:g}/{ct_s:g}", gt_ad=f"GT {fnum(un, 1)}/{vt_s / 1000:g} kV")
    for i, (x, y, t) in enumerate([(85, 30, "etiket: S, U, uk, x″d"), (340, 30, "oran · sınıf · polarite"), (232, 158, "oran · sargı düzeni"),
                                   (765, 30, "Ik: en büyük / en küçük"), (560, 112, "hat: R, X, uzunluk"), (375, 252, "sipariş kodu · sürüm")], 1):
        c.daire(x - 12 if i != 3 else x - 10, y - 4, 8, "mavi", dolgu="#dbeafe", w=1.2); c.yazi(x - 12 if i != 3 else x - 10, y - 0.5, str(i), "#1d4ed8", 9.5, kalin=True, anchor="middle")
        c.yazi(x + 1, y, t, "#1d4ed8", 9.5)
    c.yazi(500, 196, f"Primer {fa(i_prim)}  →  {fnum(x_in, 2)} ×In  →  sekonder {fnum(i_sek, 3)} A", "#b91c1c", 12, kalin=True)
    c.yazi(500, 216, f"Gerilim %{fnum(u_pct, 0)} Un  →  sekonder {fnum(u_sek, 1)} V (faz arası)", "#1d4ed8", 12, kalin=True)

    ozet = [K("Tesisin anma akımı", fa(i_n), "info", f"S / (√3·U) = {fnum(s, 0)} / (1,732 × {fnum(un, 1)})"),
            K("Röledeki karşılığı", "1,00 ×In" if nesne else f"{fnum(oran, 2)} ×In", "ok" if nesne else ("warn" if oran > 1.2 or oran < 0.2 else "ok"), ("röle için «In» trafonun anma akımıdır" if nesne else f"AT primeri {ct_p:g} A — röle için «In» budur")),
            K("Çevrilen akım", f"{fnum(x_in, 2)} ×In", "info", f"sekonder {fnum(i_sek, 3)} A"),
            K("Çevrilen gerilim", f"{fnum(u_sek, 1)} V", "info", f"%{fnum(u_pct, 0)} Un · faz–nötr {fnum(u_sek / S3, 1)} V"),
            K("Bara kısa devresi", f"{fnum(ik_kat, 0)} ×In", "bad" if ik_kat > 20 * 1.0 * 5 else "info", "AT doyma denetiminin girdisi")]
    kontroller = [
        C("AT primeri tesisin anma akımına uygun mu?", f"In(tesis) / In(AT) = {fnum(i_n, 1)} / {ct_p:g} = {fnum(oran, 2)}", "0,2 … 1,2 arası uygun",
          0.2 <= oran <= 1.2, "Ayar aralıkları ×In cinsindendir (ör. 67 başlatma 0,10–4,00 ×In): " + P3U + " Çizelge 82", "resmi"),
        C("Ayar röle aralığında mı?", f"{fnum(x_in, 2)} ×In", "50/51-1: 0,05 … 5,00 ×In", 0.05 <= x_in <= 5.0, P3U + " Çizelge 65", "resmi"),
        C("Koruma sargısı kısa devrede doymadan ölçer mi? (5P20 için kaba denetim)", f"Ik / In(AT) = {fnum(ik_kat, 0)}", "≤ 20 × (anma yükü / gerçek yük) — gerçek yük küçükse sınır büyür",
          None, "Doyma akımı koşulu: sabit zamanlıda Isat > 1,5 × ayar; ters zamanlıda Isat > 1,5 × min(Ik, 20 × ayar) — " + P3U + " böl. 5.1 Çizelge 40", "resmi"),
        C("Sekonder devre deneyden önce doğrulandı mı?", "oran, polarite, sekonder bağlantı", "primer enjeksiyonla", None, KABUL, "resmi"),
        C("Üretim tesisi ayarları tutanakla teslim edilecek", "gerilim, frekans, ROCOF ayarları", "dağıtım şirketinin gözetiminde", None, LUY, "resmi"),
    ]
    girdiler = [G(ad, "—", nereden, ne, f"Kullanan korumalar: {kim}") for ad, nereden, kim, ne in KULLANIM]
    adimlar = [
        A("Tesisin anma akımı", "In = S / (√3 · U)", f"{fnum(s, 0)} kVA / (1,732 × {fnum(un, 1)} kV)", fa(i_n), "temel bağıntı", "resmi", ["Trafo / jeneratör etiketi"]),
        A("Primer amperi röle birimine çevir", "ayar (×In) = I primer / In;  In: " + ("trafonun anma akımı" if nesne else "AT primeri"), f"{fnum(i_prim, 1)} / {fnum(i_taban, 1)}", f"{fnum(x_in, 2)} ×In",
          (P3T + " böl. 4 (faz akımlarında 1 pu = trafonun anma akımı; ark ve toprak kademelerinde AT primeri)") if nesne else (P3U + " (ayar aralıkları ×In; fider modunda In, AT primeridir)"), "resmi", ["Akım trafosu oranı"], "Başlatma [×In]"),
        A("Test cihazına verilecek sekonder akım", "I sekonder = I primer × In,s / In,p", f"{fnum(i_prim, 1)} × {ct_s:g} / {ct_p:g}", f"{fnum(i_sek, 3)} A", "AT oranı", "resmi", ["Akım trafosu oranı"]),
        A("Toprak akımı ayarı", "Io (pu) = Io primer / Io girişinin primeri", f"30 A / {io_p:g} A", f"{fnum(30 / io_p, 2)} pu", P3U + " böl. 5.31 (başlatma «×I0N»)", "resmi", ["Toprak akımı girişi"], "Io başlatma [pu]"),
        A("Gerilim ayarı", "U sekonder = %Un × Un,s", f"%{fnum(u_pct, 0)} × {vt_s:g} V", f"{fnum(u_sek, 1)} V faz arası", P3U + " böl. 5.8 / 5.25 (faz arası gerilim)", "resmi", ["Gerilim trafosu oranı"], "Başlatma [%Un]"),
    ]
    ayarlar = [
        S("Ölçekleme › AT primer / sekonder", f"{ct_p:g} / {ct_s:g} A", "—", "Yanlış girilirse bütün akım ayarları aynı oranda kayar; ekrandaki primer akım yanlış okunur", P3U + " böl. 9 (ölçekleme)"),
        S("Ölçekleme › Io1 girişi primer / sekonder", f"{io_p:g} / 1 A", "—", "Toprak ayarlarının «pu» tabanı; toroid oranı faz AT'sinden farklı olabilir", P3U + " böl. 5.21"),
        S("Ölçekleme › GT primer / sekonder", f"{fnum(un * 1000, 0)} / {vt_s:g} V", "—", "%Un ayarlarının tabanı", P3U + " böl. 9.7"),
        S("Gerilim ölçme modu", "3LN (üç faz–toprak) ya da 2LL+Vo", "3LN, 3LN+Vo, 2LL+Vo …", "3LN'de Vo hesaplanır (taban GT/√3); «+Vo» modlarında açık üçgenden ölçülür (taban GT0 sekonderi)", P3U + " böl. 5.27, 9.7"),
        S("Ayar grubu", "1 (etkin grup)", "1 … 4", "Dört ayar grubu vardır; dijital girişle ya da soğuk yük işaretiyle değiştirilebilir. Test ettiğiniz grup etkin grup olmalı", P3U + " böl. 5 (ayar grupları)"),
    ]
    test = [
        T("Hazırlık", "Test bloğundan akım devresini kısa devre edip röleyi ayırın; gerilim devresini açın. Açma çıkışını kesiciden ayırın ya da kesiciyi deney konumuna alın", "Akım trafosu sekonderi hiçbir an açık kalmaz", KABUL),
        T("Ölçme doğruluğu", f"Üç faza {fnum(ct_s, 0)} A, {fnum(vt_s / S3, 1)} V (faz–nötr), 0° verin", f"Rölede {ct_p:g} A ve {fnum(un, 1)} kV okunur; faz sırası L1-L2-L3", "±%1 dolayı"),
        T("Polarite", "Akımı gerilimle aynı fazda verin (omik, ileri)", "Rölede güç pozitif, cosφ ≈ +1; ters okunuyorsa AT ya da GT bağlantısı ters", P3U + " böl. 3.9"),
        T("Kayıt", "Her kademe için: başlatma, bırakma, açma süresi", "Değerler ayar föyüyle birlikte tutanağa yazılır", LUY),
    ]
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["olcekleme", "scaling"],
        "sahne": c.sahne(),
        "anlatim": [
            "Röle akımı amper olarak değil, akım trafosunun anma akımının katı olarak görür: «1,20 ×In» demek, AT primeri 50 A ise 60 A demektir. Aynı ayar 200/1'lik bir hücrede 240 A eder.",
            f"Bu yüzden ilk iş tesisin anma akımını ({fa(i_n)}) AT primerine ({ct_p:g} A) bölmektir: {fnum(oran, 2)}. Hesapladığınız her primer akım bu yolla ×In'e çevrilir.",
            "Toprak akımı ayrı bir girişten ölçülür (toroid ya da nötr AT); onun birimi «pu»dur ve tabanı o girişin primeridir — faz AT'sinin değil.",
            "Gerilim ayarları anma geriliminin yüzdesidir; röle faz arası gerilimi esas alır. Test cihazına sekonder volt verirsiniz.",
            "Açı gerektiren korumalarda (67, 67N) bunlara iki şey eklenir: akımın ve gerilimin röleye hangi yönle girdiği (polarite) ve arıza yolunun R/X oranı.",
        ],
        "dersler": [
            "Fider rölesinde ×In'in «In»i AT primeridir. Trafo rölesinde (P3T32) faz akımı kademelerinde trafonun anma akımıdır; ark ve toprak kademelerinde yine AT anma akımı.",
            "Io ayarının tabanı toprak akımı girişinin primeridir; faz AT'siyle karıştırılırsa ayar 5–10 kat kayar.",
            "Tebliğdeki temizleme süreleri kesici açma süresini içerir: röle süresi = sınır − kesici süresi.",
            "Ayarı hesaplamak için gereken verinin yarısı etikette, yarısı dağıtım şirketinin bağlantı görüşündedir; ikisini de masada toplayın.",
        ],
        "tablolar": [
            {"baslik": "Hangi veri hangi korumada kullanılır", "cols": ["Veri", "Nereden alınır", "Kullanan korumalar", "Ne işe yarar"], "rows": [list(r) for r in KULLANIM]},
            {"baslik": "Röledeki birimler", "cols": ["Birim", "Tabanı", "Örnek", "Dönüşüm"], "rows": [
                ["×In — fider rölesi (P3U)", "Faz AT primeri", f"1,20 ×In = {fa(1.2 * ct_p)}", "primer A / AT primeri"],
                ["×In — trafo rölesi (P3T32), faz akımı kademeleri", "Trafonun anma akımı (röle Sn ve Un'den hesaplar)", f"1,20 ×In = {fa(1.2 * i_n)}", "sekonder A = pu × In(trafo) × AT sekonderi / AT primeri"],
                ["×In — ark kademesi (I>iç) ve 64REF", "Akım trafosunun anma akımı (trafo rölesinde bile)", f"1,20 pu = {fa(1.2 * ct_p)}", "sekonder A = pu × AT sekonderi"],
                ["pu (Io)", "Toprak akımı girişinin primeri", f"0,20 pu = {fa(0.2 * io_p)}", "primer A / Io girişi primeri"],
                ["%Un", "GT primeri (faz arası)", f"%80 = {fnum(0.8 * un, 1)} kV = {fnum(0.8 * vt_s, 0)} V sekonder", "sekonder V = % × GT sekonderi"],
                ["%Vo (Uo)", "3LN modunda GT/√3; «+Vo» modunda açık üçgen sargısının sekonderi", "%10", "katı toprak arızasında %100"],
                ["%In (I2, dI)", "Korunan nesnenin anma akımı (trafo/motor modu)", "dI> %20", "trafo anma akımının yüzdesi"],
                ["Açı kayması (°)", "Kutuplama gerilimi 0° alınır", "−60° (akım 60° geride)", "bkz. Yönlü faz sayfası"]],
             "not": "Tabanlar: " + P3U + " böl. 5.20–5.31, 9.7; " + P3T + " böl. 4 «Per unit scaling» (örnek: AT 750/5, In = 525 A, 7 A sekonder = 2,00 ×In; ark kademesinde aynı 7 A = 1,4 pu)."},
            {"baslik": "Sıra: masada — sahada — test sonrası", "cols": ["Aşama", "Yapılacak"], "rows": [
                ["Masada", "Verileri topla; ayarları hesapla; ayar föyünü (alan adı = röle ekranındaki ad) hazırla; test planını çıkar"],
                ["Sahada, enerjisiz", "AT/GT oranı ve polaritesini etiketten ve sekonder devreden doğrula; röle ölçekleme ayarlarını föyle karşılaştır"],
                ["Sekonder enjeksiyon", "Her kademe: başlatma, bırakma, süre; yönlü korumada sınır açıları; diferansiyelde eğim noktaları"],
                ["Enerji altında", "Yük akımıyla yön ve diferansiyel akım denetimi (yük altında diferansiyel akım ≈ 0, güç yönü beklenen işarette)"],
                ["Test sonrası", "Ayar dosyasını röleden geri oku ve sakla; tutanağı imzalat; test bloğu ve açma devresini eski haline getir"]]},
        ],
    }

