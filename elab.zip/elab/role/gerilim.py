"""Gerilim korumaları: aşırı gerilim (ANSI 59), düşük gerilim (ANSI 27), pozitif bileşen düşük gerilim (ANSI 27P) — Easergy P3 «V>», «V<», «U1<».

Dayanak: Lisanssız Elektrik Üretimi Yön. Uygulama Tebliği m.17, Ek-2 Tablo-2 (YG'den bağlanan üretim tesisi: V ≥ %120 → 0,2 s; %110 < V < %120 → 1,0 s;
%50 ≤ V < %88 → 2,0 s; V < %50 → 0,2 s; süreler arızayı tespit ve kesici açma süresi dâhil temizleme süresidir); P3U/en M/J006 böl. 5.25 (59: üç faz arası
gerilimden herhangi biri; bırakma gecikmesi; histerezis varsayılan %3), Çizelge 74; böl. 5.8 (27: en küçük faz arası gerilim; düşük gerilim kendini kilitleme:
en büyük faz arası gerilim kilit sınırının altındaysa kademe kilitlenir; süre 0,08 s'den kısaysa sınır ≥ %15), Çizelge 50; P5/EN M/02-503A (27P: pozitif bileşen U1)."""
from __future__ import annotations

import math

from .ortak import A, A120, C, G, K, LUY, P3U, P5, S, S3, T, ctl, fnum, kademe_test, num, opt, simetrik, sz_kademe, tek_hat

ID = "gerilim"
BASLIK = "Gerilim (59 · 27 · 27P)"
IKON = "🔺"
GIRIS = ("Üretim tesisinin şebekeye bağlı kalıp kalmayacağına gerilim ve frekans korumaları karar verir. Sınırları mevzuat koyar: gerilim şu aralıkta "
         "şu kadar süre kalırsa tesis ayrılır. Röleye girilecek süre ise bundan kesici süresi düşülerek bulunur.")

OLAY = {"cukur3": "Gerilim çukuru — üç fazda", "cukur2": "Gerilim çukuru — iki fazda (dengesiz)", "yuksel": "Gerilim yükselmesi", "kesinti": "Şebeke kesintisi (gerilim sıfıra iner)"}
# Tebliğ Ek-2 Tablo-2: (alt, üst, temizleme süresi s)
SINIR = [(120.0, 999.0, 0.2, "V ≥ %120"), (110.0, 120.0, 1.0, "%110 < V < %120"), (50.0, 88.0, 2.0, "%50 ≤ V < %88"), (0.0, 50.0, 0.2, "V < %50")]

KONTROLLER = [
    ctl("vt_s", "Gerilim trafosu sekonderi (faz arası)", "sec", 100, secenek=opt((100, "100 V"), (110, "110 V"))),
    ctl("olay", "Olay", "sec", "cukur3", secenek=opt(*OLAY.items())),
    ctl("v", "Olay sırasındaki gerilim", "sayi", 70, min=0, max=150, adim=1, birim="%Un", goster={"olay": ["cukur3", "cukur2", "yuksel"]}),
    ctl("sure", "Olayın süresi", "sayi", 3.0, min=0.05, max=5.0, adim=0.05, birim="s"),
    ctl("t_kesici", "Kesicinin açma süresi", "sayi", 60, min=20, max=120, adim=5, birim="ms"),
    ctl("v59_1", "Röle › V> (kademe 1)", "sayi", 120, min=50, max=150, adim=1, birim="%Un"),
    ctl("t59_1", "Röle › tV>", "sayi", 0.10, min=0.08, max=5, adim=0.02, birim="s"),
    ctl("v59_2", "Röle › V>> (kademe 2)", "sayi", 110, min=50, max=150, adim=1, birim="%Un"),
    ctl("t59_2", "Röle › tV>>", "sayi", 0.90, min=0.06, max=5, adim=0.02, birim="s"),
    ctl("v27_1", "Röle › V< (kademe 1)", "sayi", 88, min=20, max=120, adim=1, birim="%Un"),
    ctl("t27_1", "Röle › tV<", "sayi", 1.90, min=0.08, max=20, adim=0.02, birim="s"),
    ctl("v27_2", "Röle › V<< (kademe 2)", "sayi", 50, min=20, max=120, adim=1, birim="%Un"),
    ctl("t27_2", "Röle › tV<<", "sayi", 0.10, min=0.06, max=5, adim=0.02, birim="s"),
    ctl("blok", "Röle › Düşük gerilim kilitleme", "sayi", 0, min=0, max=80, adim=1, birim="%Un", yardim="0: kilit yok. Üretim tesisinde şebeke kesintisinde de ayrılmak gerekir"),
    ctl("hist", "Röle › Histerezis", "sayi", 3.0, min=0.1, max=20, adim=0.1, birim="%"),
    ctl("p27", "Röle › 27P (U1<) kademesi kullanılıyor", "onay", False),
    ctl("v27p", "Röle › U1<", "sayi", 80, min=20, max=120, adim=1, birim="%Un", goster={"p27": [True]}),
    ctl("t27p", "Röle › tU1<", "sayi", 1.0, min=0.08, max=20, adim=0.02, birim="s", goster={"p27": [True]}),
]


def gerilimler(olay: str, v: float) -> tuple[float, float, float]:
    """Olay sırasında (en küçük faz arası, en büyük faz arası, pozitif bileşen) — % Un."""
    a = A120; k = v / 100
    if olay == "kesinti":
        return 0.0, 0.0, 0.0
    ua, ub, uc = (1 + 0j, k * a * a, k * a) if olay == "cukur2" else (k + 0j, k * a * a, k * a)
    ll = [abs(ua - ub) / S3 * 100, abs(ub - uc) / S3 * 100, abs(uc - ua) / S3 * 100]
    return min(ll), max(ll), abs(simetrik(ua, ub, uc)[1]) * 100


def run(p: dict) -> dict:
    olay = p.get("olay") if p.get("olay") in OLAY else "cukur3"
    v = num(p, "v", 70); sure = num(p, "sure", 3.0); tk = num(p, "t_kesici", 60) / 1000; vt_s = num(p, "vt_s", 100)
    vmin, vmax, u1 = gerilimler(olay, v)
    T0, dt = 0.3, 0.01
    ts = [j * dt for j in range(int((T0 + sure + 1.2) / dt) + 1)]
    ic = [T0 <= t < T0 + sure for t in ts]
    smin = [vmin if x else 100.0 for x in ic]; smax = [vmax if x else 100.0 for x in ic]; s1 = [u1 if x else 100.0 for x in ic]
    h = num(p, "hist", 3.0) / 100; blok = num(p, "blok", 0)
    kilit = [m < blok for m in smax] if blok > 0 else None
    kademeler = [("V>", sz_kademe(ts, smax, num(p, "v59_1", 120), num(p, "t59_1", 0.1), True, h), "#dc2626"),
                 ("V>>", sz_kademe(ts, smax, num(p, "v59_2", 110), num(p, "t59_2", 0.9), True, h), "#f97316"),
                 ("V<", sz_kademe(ts, smin, num(p, "v27_1", 88), num(p, "t27_1", 1.9), False, h, kilit=kilit), "#1d4ed8"),
                 ("V<<", sz_kademe(ts, smin, num(p, "v27_2", 50), num(p, "t27_2", 0.1), False, h, kilit=kilit), "#7c3aed")]
    if p.get("p27"):
        kademeler.append(("U1<", sz_kademe(ts, s1, num(p, "v27p", 80), num(p, "t27p", 1.0), False, h, kilit=kilit), "#0f766e"))
    acan = min(((r["acma"], ad) for ad, r, _ in kademeler if r["acma"] is not None), default=(None, ""))
    t_tem = None if acan[0] is None else acan[0] - T0 + tk                      # temizleme süresi (olay başından kesicinin açmasına)
    # Tebliğ'e göre gereken
    olc = vmax if olay == "yuksel" else vmin
    gerek = next(((lim, ad) for lo, hi, lim, ad in SINIR if (lo <= olc < hi) or (lo == 120 and olc >= 120)), None)
    if 88 <= olc <= 110:
        gerek = None
    uygun = (t_tem is None) if gerek is None else ((t_tem is not None and t_tem <= gerek[0] + 1e-9) or (sure < gerek[0] - tk and t_tem is None))
    c = tek_hat(("Santral", ""), ("Dağıtım şebekesi", OLAY[olay].split(" —")[0]), ("59 · 27 · 27P", (f"{acan[1]} AÇTI — {fnum(t_tem, 2)} s") if acan[0] is not None else "açmadı"),
                "acti" if acan[0] is not None else "normal", None, "sag", ileri=False, kesici_acik=acan[0] is not None, gt_ad=f"GT …/{vt_s:g} V")
    c.yazi(500, 190, f"En küçük faz arası %{fnum(vmin, 0)} · en büyük %{fnum(vmax, 0)} · pozitif bileşen U1 %{fnum(u1, 0)}", "#1d4ed8", 11.5, kalin=True)
    c.yazi(500, 208, "Tebliğ: " + (f"{gerek[1]} → en geç {fnum(gerek[0], 1)} s'de ayrılmalı" if gerek else "bu gerilimde bağlı kalmalı"), "#334155", 11)
    c.yazi(500, 226, f"Temizleme = röle süresi + kesici ({fnum(tk * 1000, 0)} ms)", "#334155", 11)
    ozet = [
        K("Sonuç", (f"{acan[1]} açtı") if acan[0] is not None else "bağlı kaldı", "ok" if uygun else "bad", "Tebliğ'e " + ("uygun" if uygun else "AYKIRI")),
        K("Temizleme süresi", f"{fnum(t_tem, 2)} s" if t_tem is not None else "—", "info" if t_tem is None else ("ok" if gerek and t_tem <= gerek[0] + 1e-9 else "warn"), f"sınır {fnum(gerek[0], 1)} s" if gerek else "ayrılma gerekmiyor"),
        K("En küçük faz arası gerilim", f"%{fnum(vmin, 0)}", "info", f"{fnum(vmin / 100 * vt_s, 1)} V sekonder — 27 buna bakar"),
        K("En büyük faz arası gerilim", f"%{fnum(vmax, 0)}", "info", f"{fnum(vmax / 100 * vt_s, 1)} V sekonder — 59 buna bakar"),
        K("Pozitif bileşen U1", f"%{fnum(u1, 0)}", "info", "27P buna bakar"),
    ]
    def sinir_ok(v_ayar, t_ayar, lo, hi, lim):
        return lo <= v_ayar <= hi and t_ayar + tk <= lim + 1e-9
    kontroller = [
        C("Bu olayda davranış Tebliğ'e uygun mu?", (f"{acan[1]} açtı, temizleme {fnum(t_tem, 2)} s" if t_tem is not None else "bağlı kaldı"), (f"{gerek[1]}: ≤ {fnum(gerek[0], 1)} s" if gerek else "bağlı kalmalı"), uygun, LUY, "resmi"),
        C("V> (aşırı gerilim, kademe 1)", f"%{fnum(num(p, 'v59_1', 120), 0)} · röle {fnum(num(p, 't59_1', 0.1), 2)} s + kesici = {fnum(num(p, 't59_1', 0.1) + tk, 2)} s", "V ≥ %120 → temizleme ≤ 0,2 s", sinir_ok(num(p, "v59_1", 120), num(p, "t59_1", 0.1), 110.01, 120, 0.2), LUY, "resmi"),
        C("V>> (aşırı gerilim, kademe 2)", f"%{fnum(num(p, 'v59_2', 110), 0)} · {fnum(num(p, 't59_2', 0.9) + tk, 2)} s", "%110 < V < %120 → temizleme ≤ 1,0 s", sinir_ok(num(p, "v59_2", 110), num(p, "t59_2", 0.9), 110, 119.99, 1.0), LUY, "resmi"),
        C("V< (düşük gerilim, kademe 1)", f"%{fnum(num(p, 'v27_1', 88), 0)} · {fnum(num(p, 't27_1', 1.9) + tk, 2)} s", "%50 ≤ V < %88 → temizleme ≤ 2,0 s", sinir_ok(num(p, "v27_1", 88), num(p, "t27_1", 1.9), 50.01, 88, 2.0), LUY, "resmi"),
        C("V<< (düşük gerilim, kademe 2)", f"%{fnum(num(p, 'v27_2', 50), 0)} · {fnum(num(p, 't27_2', 0.1) + tk, 2)} s", "V < %50 → temizleme ≤ 0,2 s", sinir_ok(num(p, "v27_2", 50), num(p, "t27_2", 0.1), 20, 50, 0.2), LUY, "resmi"),
        C("Düşük gerilim kilitleme şebeke kesintisinde ayrılmayı engelliyor mu?", f"kilit sınırı %{fnum(blok, 0)}", "üretim tesisinde 0 (kilit yok) ya da en küçük artık gerilimin altı", blok == 0,
          "Kilit, gerilim tümden kesilince gereksiz açmayı önlemek içindir (motor fideri). Kendini kilitleme 0 ile devre dışı kalır — " + P3U + " böl. 5.8. Üretim tesisinde kesintide de ayrılmak gerekir (Tebliğ: V < %50 → 0,2 s)", "resmi"),
        C("Histerezis", f"%{fnum(h * 100, 1)}", "varsayılan %3; eşik normal gerilime %2'den yakınsa küçültülür", None, P3U + " böl. 5.25 (59: %97'nin altına inene kadar arıza sayılır)", "resmi"),
    ]
    girdiler = [
        G("Dağıtım şirketinin gerilim koruma ayarları", "Tebliğ Ek-2 Tablo-2 sınırları içinde", "Bağlantı görüşü; koruma ayar tutanağı", "Sınır değerler mevzuattadır; tesise özel değeri dağıtım şirketi belirler ve tutanakla teslim alır", "V>, V>>, V<, V<< ve süreleri"),
        G("Kesicinin açma süresi", f"{fnum(tk * 1000, 0)} ms", "Kesici etiketi; deney raporu", "Tebliğ süreleri kesici dâhil temizleme süresidir", "röle süresi = sınır − kesici süresi"),
        G("Gerilim trafosu oranı ve bağlantısı", f"…/{vt_s:g} V", "GT etiketi; röle gerilim ölçme modu", "Röle faz arası gerilimi esas alır; %Un tabanı GT primeridir", "sekonder V = % × GT sekonderi"),
        G("Rölenin en kısa çalışma süresi", "27 ve 59 için 0,08 s", "Röle kılavuzu", "0,2 s'lik temizleme süresine sığmak için röle süresi + kesici ≤ 0,2 s olmalı", "0,08 + kesici ≤ 0,2 s"),
        G("27P gerekli mi (motor yükü)", "isteğe bağlı", "Tesisin yük yapısı", "Dengesiz çukurda en küçük faz arası gerilim ile pozitif bileşen farklıdır; motoru asıl ilgilendiren pozitif bileşendir", "U1< ayarı"),
    ]
    adimlar = [
        A("Röle süresi", "t röle = Tebliğ temizleme süresi − kesici süresi", f"0,2 − {fnum(tk, 2)}; 1,0 − {fnum(tk, 2)}; 2,0 − {fnum(tk, 2)}", f"≤ {fnum(0.2 - tk, 2)} s · ≤ {fnum(1.0 - tk, 2)} s · ≤ {fnum(2.0 - tk, 2)} s", LUY + " (dipnot a: tespit ve kesici açma süresi dâhildir)", "resmi", ["Kesicinin açma süresi"], "Çalışma süreleri"),
        A("Sekonder gerilim (test için)", "U sekonder = % × GT sekonderi", f"%120 · %110 · %88 · %50 × {vt_s:g} V", f"{fnum(1.2 * vt_s, 0)} · {fnum(1.1 * vt_s, 0)} · {fnum(0.88 * vt_s, 0)} · {fnum(0.5 * vt_s, 0)} V (faz arası)", P3U + " böl. 5.25 (faz arası gerilim)", "resmi", ["Gerilim trafosu oranı ve bağlantısı"]),
        A("Olaydaki en küçük faz arası gerilim", "üç fazlı çukurda = çukur derinliği; iki fazlı çukurda fazörlerden", f"{OLAY[olay]}, %{fnum(v, 0)}", f"%{fnum(vmin, 0)} (U1 = %{fnum(u1, 0)})", "fazör hesabı", "resmi"),
        A("Tebliğ'in bu gerilim için istediği", "Ek-2 Tablo-2", gerek[1] if gerek else "%88 … %110 arası", (f"≤ {fnum(gerek[0], 1)} s") if gerek else "ayrılma yok", LUY, "resmi", ["Dağıtım şirketinin gerilim koruma ayarları"]),
    ]
    ayarlar = [
        S("V> › Başlatma · Çalışma süresi", f"%{fnum(num(p, 'v59_1', 120), 0)} Un · {fnum(num(p, 't59_1', 0.1), 2)} s", "%50 … %150 · 0,08 … 300 s; ekrandaki örnek %120 / 0,20 s", "Tebliğ: V ≥ %120 → 0,2 s (kesici dâhil): röle süresi kesici süresi kadar kısaltılır", P3U + " Çizelge 74; " + LUY),
        S("V> › Reset gecikmesi", "0,06 s", "0,06 … 300 s", "Aralıklı olayda sayacın sıfırlanmasını geciktirir (yalnız 1. kademe)", P3U + " böl. 5.25"),
        S("V> › Histerezis", f"%{fnum(h * 100, 1)}", "%0,1 … %20", "Bırakma = eşik × (1 − histerezis)", P3U + " Çizelge 74"),
        S("V>> › Başlatma · süre", f"%{fnum(num(p, 'v59_2', 110), 0)} · {fnum(num(p, 't59_2', 0.9), 2)} s", "—", "Tebliğ: %110 < V < %120 → 1,0 s", LUY),
        S("V< › Başlatma · süre", f"%{fnum(num(p, 'v27_1', 88), 0)} · {fnum(num(p, 't27_1', 1.9), 2)} s", "%20 … %120 · 0,08 … 300 s; ekrandaki örnek %80 / 20,00 s", "Tebliğ: %50 ≤ V < %88 → 2,0 s", P3U + " Çizelge 50; " + LUY),
        S("V< › Düşük gerilim kilitleme", f"%{fnum(blok, 0)} Un", "%0 … %80; ekrandaki örnek %10", "Üretim tesisinde 0: şebeke kesintisinde de açsın", P3U + " böl. 5.8"),
        S("V<< › Başlatma · süre", f"%{fnum(num(p, 'v27_2', 50), 0)} · {fnum(num(p, 't27_2', 0.1), 2)} s", "—", "Tebliğ: V < %50 → 0,2 s", LUY),
        S("U1< (27P) › Başlatma · süre", f"%{fnum(num(p, 'v27p', 80), 0)} · {fnum(num(p, 't27p', 1.0), 2)} s" if p.get("p27") else "kullanılmıyor", "—", "Pozitif bileşene bakar; motor yükü için. Tebliğ'de ayrı bir sınırı yoktur", P5 + " «Positive sequence undervoltage (ANSI 27P)»"),
    ]
    test = (kademe_test("V>", num(p, "v59_1", 120) / 100 * vt_s, "V", num(p, "t59_1", 0.1), True, "±%3", "±%1 ya da ±30 ms", 1 - h, 1)
            + kademe_test("V<", num(p, "v27_1", 88) / 100 * vt_s, "V", num(p, "t27_1", 1.9), False, "±%3", "±%1 ya da ±30 ms", 1 + h, 1)
            + [T("V<< — süre", f"Üç fazı {fnum(0.4 * vt_s, 0)} V'a basamakla indirin", f"Açma {fnum(num(p, 't27_2', 0.1), 2)} s; kesiciyle {fnum(num(p, 't27_2', 0.1) + tk, 2)} s", "±%1 ya da ±30 ms"),
               T("Düşük gerilim kilitleme", "Üç fazı birden sıfıra indirin", "Kilit 0 ise V< ve V<< açar; kilit > 0 ise açmaz", "—"),
               T("Tek faz arası gerilim", "Yalnız bir faz arası gerilimi eşiğin altına indirin", "V< başlar (en küçüğe bakar); U1< başlamayabilir", "—")])
    g = {"baslik": "Gerilim ve kademelerin başlaması", "x_ad": "Zaman (s)", "y_ad": "Gerilim (% Un)", "zaman": True, "ymin": 0, "ymax": max(140, vmax + 10),
         "seriler": [{"ad": "en küçük faz arası", "renk": "#1d4ed8", "pts": [[round(t, 2), x] for t, x in zip(ts, smin)]}, {"ad": "en büyük faz arası", "renk": "#dc2626", "kesik": True, "pts": [[round(t, 2), x] for t, x in zip(ts, smax)]},
                     {"ad": "pozitif bileşen U1", "renk": "#0f766e", "kesik": True, "pts": [[round(t, 2), x] for t, x in zip(ts, s1)]}],
         "yatay": [{"y": num(p, "v59_1", 120), "etiket": "V>", "renk": "#dc2626"}, {"y": num(p, "v59_2", 110), "etiket": "V>>", "renk": "#f97316"}, {"y": num(p, "v27_1", 88), "etiket": "V<", "renk": "#1d4ed8"}, {"y": num(p, "v27_2", 50), "etiket": "V<<", "renk": "#7c3aed"}],
         "isaretler": ([{"x": acan[0], "etiket": f"{acan[1]} açma"}, {"x": acan[0] + tk, "etiket": "kesici açtı"}] if acan[0] is not None else [])}
    vs = list(range(0, 151, 2))
    def t_role(x):
        if x >= num(p, "v59_1", 120):
            return num(p, "t59_1", 0.1) + tk
        if x > num(p, "v59_2", 110):
            return num(p, "t59_2", 0.9) + tk
        if x < num(p, "v27_2", 50):
            return num(p, "t27_2", 0.1) + tk
        if x < num(p, "v27_1", 88):
            return num(p, "t27_1", 1.9) + tk
        return None
    def t_teb(x):
        return 0.2 if x >= 120 else 1.0 if x > 110 else 0.2 if x < 50 else 2.0 if x < 88 else None
    g2 = {"baslik": "Gerilime göre ayrılma süresi: röle ayarı Tebliğ sınırının altında kalmalı", "x_ad": "Gerilim (% Un)", "y_ad": "Temizleme süresi (s)", "ymin": 0, "ymax": 2.4,
          "seriler": [{"ad": "Tebliğ sınırı", "renk": "#1a4d8f", "nokta": True, "r": 3, "pts": [[x, t_teb(x)] for x in vs if t_teb(x) is not None]},
                      {"ad": "röle + kesici", "renk": "#dc2626", "nokta": True, "r": 2, "pts": [[x, t_role(x)] for x in vs if t_role(x) is not None]}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["_59_", "_27_"],
        "sahne": c.sahne(), "grafikler": [g, g2],
        "anlatim": [
            "Röle üç faz arası gerilimi ölçer. Aşırı gerilim kademesi en büyüğüne, düşük gerilim kademesi en küçüğüne bakar; biri eşiği geçince kademe başlar, süre dolunca açar.",
            "Üretim tesisinde eşikleri ve süreleri Tebliğ'in Ek-2 Tablo-2'si sınırlar: gerilim ne kadar bozuksa tesis o kadar çabuk ayrılır.",
            f"Tablodaki süre temizleme süresidir: rölenin algılaması + kesicinin açması. Kesici {fnum(tk * 1000, 0)} ms sürüyorsa röleye 0,2 s değil en çok {fnum(0.2 - tk, 2)} s girilir.",
            "Kısa süren çukurlarda tesis bağlı kalır: süre dolmadan gerilim düzelirse kademe bırakır. Bırakma eşiği histerezis kadar ötededir.",
            "Dengesiz çukurda üç gerilim farklıdır. 27 en kötü faz arasına bakar; 27P ise pozitif bileşene — üç fazın «işe yarayan» ortak bölümüne.",
            "Düşük gerilim kilitleme, gerilim tümden gidince kademeyi susturur. Motor fiderinde yararlıdır; üretim tesisinde ise şebeke kesintisinde ayrılmayı engeller.",
        ],
        "dersler": [
            "Tebliğ süresi = röle süresi + kesici süresi. Röleye sınırın kendisini girerseniz tesis geç ayrılır.",
            "59 en büyük, 27 en küçük faz arası gerilime bakar; ikisi de faz–nötr değil faz arasıdır.",
            "Üretim tesisinde düşük gerilim kilidi 0 olmalı; yoksa kesintide V<< çalışmaz.",
            "Ayarlar dağıtım şirketinin gözetiminde yapılır ve tutanakla teslim edilir (Tebliğ Ek-2 notu).",
        ],
        "tablolar": [{"baslik": "Tebliğ Ek-2 Tablo-2 ve röleye girilecek değerler", "cols": ["Parametre", "Açma ayarı", "Temizleme süresi", "Röle süresi (kesici " + fnum(tk * 1000, 0) + " ms)", "P3 kademesi"], "rows": [
            ["Aşırı gerilim — kademe 1", "V ≥ %120", "0,2 s", f"≤ {fnum(0.2 - tk, 2)} s", "V>"], ["Aşırı gerilim — kademe 2", "%110 < V < %120", "1,0 s", f"≤ {fnum(1.0 - tk, 2)} s", "V>>"],
            ["Düşük gerilim — kademe 1", "%50 ≤ V < %88", "2,0 s", f"≤ {fnum(2.0 - tk, 2)} s", "V<"], ["Düşük gerilim — kademe 2", "V < %50", "0,2 s", f"≤ {fnum(0.2 - tk, 2)} s", "V<<"]],
            "not": LUY + ". Gerilim ayarları anma geriliminin yüzdesidir (dipnot a). AG'den bağlanan tesisler için Tablo-1 geçerlidir (230 V + %15 → 0,2 s; −%15…%20 → 1,5 s; −%50…%75 → 0,2 s)."}],
    }
