"""Motor yol alma akımı: kapama anındaki asimetrik tepe, hızlanma boyunca akım ve moment, gerilim çukuru, yol verme yöntemleri, motor korumaları.

İki ayrı olay vardır: (1) elektriksel geçici olay — duran motor şebekeye endüktif bir yük gibi bağlanır; kısa devredeki gibi doğru akım bileşeni oluşur ve
ilk tepe, kilitli rotor akımının tepe değerinin κ katına çıkar (κ = 1,02 + 0,98·e^(−3R/X)); (2) mekanik yol alma — akım, motor hızlanana kadar kilitli
rotor değerine yakın kalır. Hız denklemi: TA·dn/dt = M(motor)·u² − M(yük). Akım–hız ve moment–hız eğrilerinin biçimi katalog uç değerlerinden
(Ia/In, Ma/Mn, Mk/Mn) geçirilen yaklaşık eğrilerdir (tahmini). Koruma: P3U/en M/J006 böl. 5.15 (48: IST>, IMOTST, TSTART; T = (ISTART/IMEAS)²·TSTART;
motor durumları; yumuşak yol vericide yol alma işareti oluşmaz), Çizelge 59; böl. 5.23 ve Çizelge 72 (51LR); böl. 5.29 ve Çizelge 81 (66)."""
from __future__ import annotations

import math

from . import dalga as D
from .ortak import A, C, G, K, P3U, S, S3, T, URRA, ctl, fa, fnum, num, opt, tek_hat

ID = "yolalma_motor"
BASLIK = "Motor yol alma akımı"
IKON = "🌀"
GIRIS = ("Motor şebekeye bağlandığı anda iki şey olur: ilk periyotta doğru akım bileşeniyle büyüyen bir tepe, ardından motor hızlanana kadar süren kilitli rotor "
         "akımı. Birincisi ani açtırıcıları, ikincisi ısıl korumayı ve gerilimi zorlar. Motoru, yükü ve yol verme yöntemini seçin; akımı, hızı, gerilim çukurunu "
         "ve korumaların davranışını izleyin.")
YONTEM = {"dol": "Doğrudan yol verme", "yd": "Yıldız–üçgen", "soft": "Yumuşak yol verici", "vfd": "Frekans konvertörü"}

KONTROLLER = [
    ctl("seviye", "Motor gerilimi", "sec", "ag", secenek=opt(("ag", "AG — 400 V"), ("og", "OG — 6,3 kV"))),
    ctl("pn", "Motor gücü", "sec", 110, secenek=opt(*[(v, f"{v:g} kW") for v in (7.5, 15, 22, 37, 55, 75, 110, 160, 250, 400, 630, 1000)])),
    ctl("ia", "Kilitli rotor (kalkış) akımı Ia/In", "sayi", 6.5, min=4, max=9, adim=0.1, yardim="Katalog; verimli (IE3–IE4) motorlarda 7–8'e çıkar"),
    ctl("cosk", "Kalkıştaki güç katsayısı", "sayi", 0.25, min=0.10, max=0.50, adim=0.01, yardim="Duran motor hemen hemen saf endüktanstır; küçük değer → uzun süren doğru akım bileşeni"),
    ctl("ma", "Kalkış momenti Ma/Mn", "sayi", 2.0, min=0.8, max=3.5, adim=0.1),
    ctl("mk", "Devrilme momenti Mk/Mn", "sayi", 2.5, min=1.6, max=4.0, adim=0.1),
    ctl("yuk", "Yük türü", "sec", "fan", secenek=opt(("fan", "Fan / santrifüj pompa (moment hızın karesiyle artar)"), ("sabit", "Sabit moment (konveyör, pistonlu kompresör)"))),
    ctl("m_yuk", "Yükün anma hızdaki momenti / Mn", "sayi", 0.8, min=0.1, max=1.2, adim=0.05),
    ctl("ta", "Yol alma zaman sabiti (motor + yük ataleti)", "sayi", 1.5, min=0.1, max=15, adim=0.1, birim="s", yardim="TA = J·ω / Mn: anma momentiyle boşta hızlanma süresi. Fan ve değirmende büyük, pompada küçük"),
    ctl("yontem", "Yol verme yöntemi", "sec", "dol", secenek=opt(*YONTEM.items())),
    ctl("i_lim", "Yumuşak yol verici akım sınırı", "sayi", 3.5, min=1.5, max=5, adim=0.1, birim="×In", goster={"yontem": ["soft"]}),
    ctl("gecis", "Üçgene geçiş hızı", "sayi", 85, min=40, max=98, adim=1, birim="%", goster={"yontem": ["yd"]}),
    ctl("sk", "Motor barasındaki kısa devre gücü", "sayi", 25, min=2, max=500, adim=1, birim="MVA", yardim="1.600 kVA, %6 trafonun AG barasında ≈ 26 MVA"),
    ctl("alfa", "Kapama anında gerilimin açısı", "sayi", 0, min=0, max=180, adim=5, birim="°", goster={"yontem": ["dol"]}),
    ctl("i_st", "Röle › 48 yol alma algılama akımı IST>", "sayi", 1.5, min=1.3, max=10, adim=0.05, birim="×IMOT"),
    ctl("t_st", "Röle › 48 izin verilen yol alma süresi TSTART", "sayi", 10, min=1, max=300, adim=0.5, birim="s"),
    ctl("tip48", "Röle › 48 gecikme tipi", "sec", "inv", secenek=opt(("dt", "Sabit zamanlı (DT)"), ("inv", "Akıma bağlı (INV)"))),
    ctl("t_e", "Motorun kilitli rotorda dayanma süresi (sıcak)", "sayi", 12, min=3, max=60, adim=1, birim="s", yardim="Motor veri sayfası"),
    ctl("i_ani", "Ani açtırıcı ayarı (manyetik / I>>)", "sayi", 13, min=6, max=20, adim=0.5, birim="×In"),
]


def i_dol(n: float, ia: float) -> float:
    """Anma geriliminde doğrudan yol vermede akım (×In), hıza göre: hızın büyük bölümünde kilitli rotor değerine yakın kalır."""
    n = min(max(n, 0.0), 1.0)
    if n <= 0.985:                                                          # anma hızında (kayma %1,5) anma akımı
        return 1.0 + (ia - 1.0) * (1.0 - (n / 0.985) ** 5)
    return 1.0 - 0.65 * (n - 0.985) / 0.015                                 # senkron hıza doğru boşta akıma (≈ 0,35 × In) iner


def m_motor(n: float, ma: float, mk: float) -> float:
    """Anma geriliminde motor momenti (×Mn), hıza göre: kalkış → hafif çukur → devrilme → anma hızında Mn → senkron hızda sıfır."""
    n = min(max(n, 0.0), 1.0)
    tab = ((0.0, ma), (0.25, 0.92 * ma), (0.6, 0.5 * (ma + mk)), (0.85, mk), (0.94, 0.72 * mk), (0.985, 1.0), (1.0, 0.0))
    for (x0, y0), (x1, y1) in zip(tab, tab[1:]):
        if n <= x1:
            return y0 + (y1 - y0) * (n - x0) / (x1 - x0)
    return 0.0


def m_yuk(n: float, tur: str, m: float) -> float:
    return m * (0.1 + 0.9 * n * n) if tur == "fan" else m


def benzet(p: dict) -> dict:
    """Mekanik yol alma: t (s), hız (pu), hat akımı (×In), bara gerilimi (pu), motor ve yük momenti."""
    ia, ma, mk = num(p, "ia", 6.5), num(p, "ma", 2.0), num(p, "mk", 2.5)
    tur, my, ta = p.get("yuk") or "fan", num(p, "m_yuk", 0.8), num(p, "ta", 1.5)
    yon = p.get("yontem") if p.get("yontem") in YONTEM else "dol"
    sm = num(p, "pn", 110) / 0.8 / 1000                                   # motorun görünür gücü (MVA): Pn / (η·cos φ), η·cos φ ≈ 0,8
    zs = sm / num(p, "sk", 25)                                             # şebeke empedansı, motor tabanında (pu)
    ilim, gecis = num(p, "i_lim", 3.5), num(p, "gecis", 85) / 100
    dt, n, t = 0.01, 0.0, 0.0
    ts, ns, is_, us, mm, ml = [], [], [], [], [], []
    ucgen = False; t_gecis = None
    for _ in range(6001):
        id_ = i_dol(n, ia)
        if yon == "vfd":                                                    # konvertör: akım anma değeri dolayında, hız rampayla (10 s)
            i, u, m = min(1.1, 0.3 + 0.8 * my), 1.0, m_yuk(n, tur, my) + 0.3
        else:
            kat = 1.0
            if yon == "yd" and not ucgen:
                kat = 1 / 3
            u = 1.0 / (1.0 + id_ * kat * zs)                                # bara gerilimi: şebeke empedansında düşen gerilim çıkarılır
            um = u                                                          # motor sargısının gördüğü gerilim (hat akımıyla doğrusal)
            if yon == "soft":
                um = min(u, ilim / id_)                                     # akım sınırı: gerilim kısılır
                u = 1.0 / (1.0 + id_ * (um / u if u else 0) * zs) if u else 0
            i = id_ * kat * um if yon != "soft" else id_ * um
            m = m_motor(n, ma, mk) * kat * um * um
        y = m_yuk(n, tur, my)
        ts.append(t); ns.append(n); is_.append(i); us.append(u); mm.append(m); ml.append(y)
        n_once = n
        if yon == "vfd":
            n = min(0.985, n + dt / 10.0)
        else:
            n = min(1.0, max(0.0, n + dt * (m - y) / ta))
            if yon == "yd" and not ucgen and n >= gecis:
                ucgen = True; t_gecis = t
        t += dt
        if t > 1.5 and yon != "vfd" and abs(n - n_once) < 2e-6 and (ucgen or yon != "yd" or n < gecis - 0.01):
            break                                                           # hız oturdu (ya da motor yol alamıyor)
        if yon == "vfd" and n >= 0.985 and t > 10.5:
            break
    return {"t": ts, "n": ns, "i": is_, "u": us, "mm": mm, "ml": ml, "t_gecis": t_gecis, "zs": zs, "yon": yon}


def run(p: dict) -> dict:
    og = p.get("seviye") == "og"
    un = 6300.0 if og else 400.0
    pn, ia, cosk = num(p, "pn", 110), num(p, "ia", 6.5), num(p, "cosk", 0.25)
    i_n = pn * 1000 / (S3 * un * 0.8)
    b = benzet(p); yon = b["yon"]
    i_st, t_st, t_e, i_ani = num(p, "i_st", 1.5), num(p, "t_st", 10), num(p, "t_e", 12), num(p, "i_ani", 13)
    xr = math.tan(math.acos(cosk)); kap = D.kappa(xr)
    i_ilk = b["i"][0]                                                       # ilk andaki etkin akım (×In)
    tepe = kap * D.KOK2 * i_ilk if yon in ("dol", "yd") else D.KOK2 * i_ilk  # asimetrik ilk tepe (anlık, ×In)
    n_son = b["n"][-1]
    aldi = n_son >= 0.9
    # yol alma süresi: akım 1,2 × IMOT'un altına inince (röle «yol alıyor» durumundan çıkar)
    t_yol = next((t for t, i, n in zip(b["t"], b["i"], b["n"]) if i <= 1.2 and n > 0.5), None) if aldi else None
    u_min = min(b["u"])
    # 48: sabit zamanlı → süre TSTART'ı aşarsa; akıma bağlı → ∫ dt / T(I) ≥ 1 ,  T = (ISTART/I)²·TSTART
    algiladi = max(b["i"][:21]) >= i_st                                     # 200 ms içinde IST> aşılmalı
    say, t48 = 0.0, None
    for t, i in zip(b["t"], b["i"]):
        if not algiladi or i < 1.2:
            if t > 0.3 and i < 1.2:
                break
            continue
        say += 0.01 / (t_st if p.get("tip48") == "dt" else (ia / max(i, 1e-6)) ** 2 * t_st)
        if say >= 1.0:
            t48 = t; break
    isil = sum((i * i) * 0.01 for i in b["i"] if i > 1.2) / (ia * ia * t_e) * 100          # yol almanın kullandığı kilitli rotor ısıl payı (%)
    ani_acar = tepe / D.KOK2 >= i_ani
    mm0 = b["mm"][0]

    c = tek_hat(("Şebeke", f"{fnum(num(p, 'sk', 25), 0)} MVA"), ("Motor", f"{pn:g} kW · {fa(i_n)}"), ("Motor koruma rölesi", "48: " + ("AÇTI" if t48 is not None else "yol alıyor" if algiladi else "yol alma algılanmadı")),
                "gecersiz" if (t48 is not None or ani_acar) else "normal", None, "sag", gt=False, ileri=False, h=310, kesici_acik=t48 is not None or ani_acar)
    c.yazi(500, 150, f"İlk tepe {fnum(tepe, 1)} × In = {fa(tepe * i_n)}" + (f"  (κ = {fnum(kap, 2)})" if yon in ("dol", "yd") else ""), "#b91c1c", 12.5, kalin=True)
    c.yazi(500, 172, f"Yol alma akımı {fnum(i_ilk, 2)} × In = {fa(i_ilk * i_n)}", "#334155", 12, kalin=True)
    c.yazi(500, 192, f"Bara gerilimi en düşük %{fnum(u_min * 100, 0)} · kalkış momenti {fnum(mm0, 2)} × Mn", "#334155", 11.5)
    c.yazi(500, 212, (f"Yol alma süresi {fnum(t_yol, 1)} s · son hız %{fnum(n_son * 100, 0)}" if t_yol is not None else f"Motor yol alamıyor: hız %{fnum(n_son * 100, 0)}'de kalıyor"), "#15803d" if aldi else "#b91c1c", 12, kalin=True)
    c.yazi(500, 232, f"Isıl pay: kilitli rotor dayanımının %{fnum(isil, 0)}'i", "#334155", 11.5)
    c.yazi(500, 258, ("Ani açtırıcı ilk tepede AÇAR" if ani_acar else f"48 kademesi {fnum(t48, 1)} s'de AÇAR" if t48 is not None else "Korumalar yol almaya izin veriyor"), "#b91c1c" if (ani_acar or t48 is not None) else "#15803d", 12, kalin=True)

    ozet = [
        K("İlk tepe (anlık)", f"{fnum(tepe, 1)} × In", "bad" if ani_acar else "info", f"{fa(tepe * i_n)} · simetrik tepenin {fnum(tepe / (D.KOK2 * i_ilk), 2)} katı"),
        K("Yol alma akımı", f"{fnum(i_ilk, 2)} × In", "info", f"{fa(i_ilk * i_n)} · {YONTEM[yon].lower()}"),
        K("Yol alma süresi", f"{fnum(t_yol, 1)} s" if t_yol is not None else "yol alamıyor", "ok" if (aldi and t48 is None) else "bad", f"son hız %{fnum(n_son * 100, 0)}" + (f" · 48 izni {fnum(t_st, 0)} s" if aldi else "")),
        K("Bara gerilimi (en düşük)", f"%{fnum(u_min * 100, 0)}", "ok" if u_min >= 0.85 else "warn", "aynı baradaki tüketicilerin gördüğü çukur"),
        K("Isıl pay", f"%{fnum(isil, 0)}", "ok" if isil <= 100 else "bad", f"∫I²dt / (Ia²·tE) · peş peşe ≈ {max(int(100 / max(isil, 1)), 0)} yol alma"),
    ]
    kontroller = [
        C("Motor yükü kaldırıp hızlanıyor mu?", f"kalkışta motor {fnum(mm0, 2)} × Mn, yük {fnum(b['ml'][0], 2)} × Mn; son hız %{fnum(n_son * 100, 0)}", "motor momenti her hızda yük momentinden büyük olmalı", aldi,
          "TA·dn/dt = M(motor)·u² − M(yük): gerilim düşünce moment karesiyle azalır; yıldızda ve yumuşak yol vericide bu yüzden ağır yük kalkmaz", "hesap"),
        C("Ani açtırıcı ilk tepede açmıyor mu?", f"ilk tepe {fnum(tepe, 1)} × In (anlık) = {fnum(tepe / D.KOK2, 1)} × In (etkin karşılığı)", f"< {fnum(i_ani, 1)} × In", not ani_acar,
          "Manyetik açtırıcı anlık değere tepki verir; ayarı simetrik akımın etkin değeri olarak verildiğinden tepe √2'ye bölünerek karşılaştırılır. Doğru akım bileşeni ilk tepeyi κ kat büyütür", "hesap"),
        C("Yol alma denetimi (48) yol almaya izin veriyor mu?", (f"yol alma {fnum(t_yol, 1)} s" if t_yol is not None else "yol alma bitmiyor") + f"; izin {fnum(t_st, 1)} s ({'sabit' if p.get('tip48') == 'dt' else 'akıma bağlı'})", "yol alma, izin verilen süreden kısa olmalı", t48 is None,
          "IST> kademesi uzayan doğrudan yol almaya karşı korur; akıma bağlı gecikme T = (ISTART / IMEAS)² · TSTART — " + P3U + " böl. 5.15, Çizelge 59", "resmi"),
        C("Röle yol almayı algılıyor mu?", f"ilk 200 ms'de akım {fnum(max(b['i'][:21]), 2)} × IMOT", f"≥ IST> = {fnum(i_st, 2)} × IMOT", algiladi if yon in ("dol", "yd") else None,
          "Akım %10 IMOT'un altından 200 ms içinde IST> üstüne çıkarsa «yol alıyor» sayılır; yumuşak yol verici ve frekans konvertöründe akım düşük kaldığından işaret oluşmaz, motor doğrudan «çalışıyor» durumuna geçer — " + P3U + " böl. 5.15", "resmi"),
        C("Yol alma ısıl dayanımın içinde mi?", f"∫I²dt = kilitli rotor dayanımının %{fnum(isil, 0)}'i", "≤ %100 (Ia² · tE)", isil <= 100,
          "Yol almada ısınma akımın karesiyle ve süreyle orantılıdır; dayanma süresi motor veri sayfasından alınır", "hesap"),
        C("Gerilim çukuru kabul edilebilir mi?", f"en düşük bara gerilimi %{fnum(u_min * 100, 0)}", "≥ %85 (kontaktör ve öbür tüketiciler için)", u_min >= 0.85,
          "Sınır uygulamaya göre değişir; kontaktör bobinleri genellikle %85 Un'un altında bırakabilir", "ikincil"),
    ]
    girdiler = [
        G("Motor etiketi: güç, gerilim, anma akımı", f"{pn:g} kW · {fnum(un, 0)} V · {fa(i_n)}", "Motor etiketi", "Röledeki bütün motor ayarları IMOT'un (motor anma akımı) katıdır", "IMOT ölçekleme sayfasına girilir"),
        G("Kalkış akımı ve kalkış güç katsayısı", f"Ia/In = {fnum(ia, 1)} · cos φ = {fnum(cosk, 2)}", "Motor veri sayfası / katalog", "Yol alma akımının büyüklüğü ve ilk tepedeki doğru akım bileşeni", f"IMOTST = {fnum(ia, 1)} × IMOT ; κ = {fnum(kap, 2)}"),
        G("Yol alma süresi ve kilitli rotor dayanma süresi", f"tE = {fnum(t_e, 0)} s", "Motor veri sayfası (sıcak / soğuk); yük makinesinin ataleti", "48'in süresi ikisinin arasında seçilir: yol almadan uzun, dayanma süresinden kısa", "TSTART"),
        G("Saatte izin verilen yol alma sayısı", "ör. soğuk 3, sıcak 2", "Motor üreticisi", "Her yol alma motoru ısıtır; peş peşe yol almalar sargıyı ve rotor kafesini zorlar", "66: N>"),
        G("Motor barasındaki kısa devre gücü", f"{fnum(num(p, 'sk', 25), 0)} MVA", "Kısa devre hesabı (bkz. Kısa devre sayfası)", "Yol alma akımının bara gerilimini ne kadar düşürdüğünü belirler", f"Δu ≈ Ia · Sm / Sk″"),
    ]
    adimlar = [
        A("Motor anma akımı", "In = Pn / (√3·U·η·cos φ)", f"{pn:g} kW / (1,732 × {fnum(un, 0)} V × 0,8)", fa(i_n), "η·cos φ ≈ 0,8 alındı; gerçek değer etikettedir", "tahmini", ["Motor etiketi: güç, gerilim, anma akımı"], "IMOT"),
        A("Kalkıştaki X/R ve tepe katsayısı", "X/R = tan(acos(cos φk)) ;  κ = 1,02 + 0,98·e^(−3R/X)", f"cos φk = {fnum(cosk, 2)} → X/R = {fnum(xr, 1)}", f"κ = {fnum(kap, 2)}", "doğru akım bileşeni kısa devredeki gibi oluşur (TS EN 60909-0 bağıntısı)", "dogrulanacak", ["Kalkış akımı ve kalkış güç katsayısı"]),
        A("İlk tepe", "î = κ · √2 · I(yol alma)", f"{fnum(kap, 2)} × 1,414 × {fnum(i_ilk, 2)}", f"{fnum(tepe, 1)} × In (anlık)", "bu sayfadaki hesap", "hesap", [], "ani açtırıcı"),
        A("Bara gerilimi", "u = 1 / (1 + I(pu) · Sm/Sk″)", f"1 / (1 + {fnum(i_ilk, 2)} × {fnum(b['zs'], 3)})", f"%{fnum(b['u'][0] * 100, 0)}", "gerilim bölücü (büyüklükçe yaklaşık)", "hesap", ["Motor barasındaki kısa devre gücü"]),
        A("Yol alma süresi", "TA · dn/dt = M(motor)·u² − M(yük)", f"TA = {fnum(num(p, 'ta', 1.5), 1)} s", f"{fnum(t_yol, 1)} s" if t_yol is not None else "yol alamıyor", "hareket denklemi; eğri biçimleri yaklaşık", "tahmini", ["Yol alma süresi ve kilitli rotor dayanma süresi"], "TSTART"),
        A("48'in akıma bağlı süresi", "T = (ISTART / IMEAS)² · TSTART", f"({fnum(ia, 1)} / {fnum(i_ilk, 2)})² × {fnum(t_st, 1)}", f"{fnum((ia / max(i_ilk, 1e-6)) ** 2 * t_st, 1)} s", P3U + " böl. 5.15 Denklem 20", "resmi", [], "IST>"),
    ]
    ayarlar = [
        S("48 › Motor yol alma algılama akımı IST>", f"{fnum(i_st, 2)} × IMOT", "1,30 … 10,00 × IMOT", "Yük akımının üstünde, yol alma akımının altında: yol almanın başladığını buradan anlar", P3U + " Çizelge 59"),
        S("48 › Anma yol alma akımı IMOTST", f"{fnum(ia, 2)} × IMOT", "1,50 … 10,00 × IMOT (varsayılan 6,00)", "Motorun katalogdaki Ia/In değeri; akıma bağlı gecikmenin referansı", P3U + " Çizelge 59"),
        S("48 › Çalışma süresi / gecikme katsayısı", f"{fnum(t_st, 1)} s ({'DT' if p.get('tip48') == 'dt' else 'INV'})", "1,0 … 300,0 s", "Ölçülen yol alma süresinin üstünde, motorun dayanma süresinin altında", P3U + " Çizelge 59"),
        S("51LR › Başlatma (kilitli rotor)", "motorun kilitli rotor verisine göre", "%10 … %100 IMOTST; 1,0 … 300,0 s", "Motor çalışırken sıkışırsa açar; yol alma sırasında kendiliğinden kilitlidir", P3U + " böl. 5.23, Çizelge 72"),
        S("66 › En çok yol alma sayısı · yol almalar arası en kısa süre", "üretici verisine göre", "1 … 20 ; 0,0 … 100 dk", "Sık yol vermeyi engeller; sondan bir önceki yol almada uyarı verir", P3U + " böl. 5.29, Çizelge 81"),
    ]
    test = [
        T("Yol almanın algılanması", f"Akım 0 → {fnum(max(i_st * 1.2, 2), 1)} × IMOT (basamak)", "Motor durumu «yol alıyor»; 48 saymaya başlar", "akım önce en az 500 ms %10 IMOT'un altında olmalı"),
        T("48 süresi", f"{fnum(ia, 1)} × IMOT uygula", f"Açma {fnum(t_st, 1)} s sonra", "±%5 ya da en az ±30 ms (akıma bağlı)"),
        T("Akıma bağlı gecikme", f"{fnum(ia * 0.7, 1)} × IMOT uygula", f"Açma {fnum(t_st / 0.49, 1)} s sonra (INV)", "T = (ISTART/IMEAS)² · TSTART"),
        T("Yol alma kaydı", "Motor gerçek yükle yol verilir, arıza kaydı alınır", f"İlk tepe ≈ {fnum(tepe, 0)} × In'e kadar; akım {fnum(t_yol or 0, 1)} s dolayında anma değerine iner", "TSTART bu kayda göre doğrulanır"),
    ]
    N = 64
    tw = [k * 0.02 / N for k in range(6 * N + 1)]
    iw = [(D.kd_akim(i_ilk, xr, num(p, "alfa", 0), t) if yon in ("dol", "yd") else D.KOK2 * i_ilk * math.sin(D.W * t) * min(1.0, t / 0.04)) for t in tw]
    g1 = {"baslik": "Kapama anı: ilk altı periyot", "x_ad": "Zaman (ms)", "y_ad": "Akım (× In, anlık)", "zaman": True,
          "seriler": [{"ad": "motor akımı", "renk": "#dc2626", "pts": D.seri([t * 1000 for t in tw], iw, 1)}],
          "yatay": [{"y": D.KOK2 * i_ani, "etiket": f"ani açtırıcı {fnum(i_ani, 1)} × In (tepe karşılığı)", "renk": "#15803d"}, {"y": D.KOK2 * i_ilk, "etiket": "simetrik tepe", "renk": "#64748b"}]}
    ad = max(1, len(b["t"]) // 150)
    g2 = {"baslik": "Yol alma boyunca akım ve bara gerilimi", "x_ad": "Zaman (s)", "y_ad": "Akım (× In, etkin) · gerilim (× 10 pu)", "ymin": 0,
          "seriler": [{"ad": "hat akımı", "renk": "#dc2626", "pts": [[round(t, 2), round(v, 3)] for t, v in list(zip(b["t"], b["i"]))[::ad]]},
                      {"ad": "bara gerilimi × 10", "renk": "#1a4d8f", "kesik": True, "pts": [[round(t, 2), round(v * 10, 3)] for t, v in list(zip(b["t"], b["u"]))[::ad]]}],
          "yatay": [{"y": i_st, "etiket": f"IST> {fnum(i_st, 2)}", "renk": "#15803d"}], "isaretler": ([{"x": t_yol, "etiket": "yol alma bitti"}] if t_yol is not None else []) + ([{"x": t48, "etiket": "48 açtı"}] if t48 is not None else [])}
    g3 = {"baslik": "Hız ve momentler", "x_ad": "Zaman (s)", "y_ad": "Hız (pu) · moment (× Mn)", "ymin": 0,
          "seriler": [{"ad": "hız", "renk": "#15803d", "pts": [[round(t, 2), round(v, 3)] for t, v in list(zip(b["t"], b["n"]))[::ad]]},
                      {"ad": "motor momenti", "renk": "#dc2626", "pts": [[round(t, 2), round(v, 3)] for t, v in list(zip(b["t"], b["mm"]))[::ad]]},
                      {"ad": "yük momenti", "renk": "#64748b", "kesik": True, "pts": [[round(t, 2), round(v, 3)] for t, v in list(zip(b["t"], b["ml"]))[::ad]]}]}
    hizlar = [j / 50 for j in range(51)]
    ma_, mk_ = num(p, "ma", 2.0), num(p, "mk", 2.5)
    g4 = {"baslik": "Moment–hız ve akım–hız eğrileri (anma geriliminde doğrudan yol verme)", "x_ad": "Hız (pu)", "y_ad": "Moment (× Mn) · akım (× In)", "ymin": 0,
          "seriler": [{"ad": "motor momenti", "renk": "#dc2626", "pts": [[n, round(m_motor(n, ma_, mk_), 3)] for n in hizlar]},
                      {"ad": "yük momenti", "renk": "#64748b", "kesik": True, "pts": [[n, round(m_yuk(n, p.get("yuk") or "fan", num(p, "m_yuk", 0.8)), 3)] for n in hizlar]},
                      {"ad": "akım", "renk": "#1a4d8f", "pts": [[n, round(i_dol(n, ia), 3)] for n in hizlar]}]}

    def satir(y_: str) -> list:
        bb = benzet({**p, "yontem": y_})
        ok_ = bb["n"][-1] >= 0.9
        ty = next((t for t, i, n in zip(bb["t"], bb["i"], bb["n"]) if i <= 1.2 and n > 0.5), None) if ok_ else None
        return [YONTEM[y_], f"{fnum(bb['i'][0], 2)} × In", f"{fnum(bb['mm'][0], 2)} × Mn", f"%{fnum(min(bb['u']) * 100, 0)}", ("rampa süresi (10 s)" if y_ == "vfd" else f"{fnum(ty, 1)} s" if ty is not None else "yol alamaz")]
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["49t", "soguk_yuk"], "sahne": c.sahne(), "grafikler": [g1, g2, g3, g4],
        "anlatim": [
            "Duran motor şebekeye bağlandığında rotor dönmediği için motor, sekonderi kısa devre edilmiş bir trafo gibidir: anma akımının 5–8 katını çeker. Bu akım hemen hemen saf endüktiftir.",
            f"Endüktif devrede akım sıçrayamaz. Kapama anına göre akıma bir doğru akım bileşeni eklenir; ilk tepe simetrik tepenin {fnum(kap, 2)} katına çıkar ve birkaç periyotta söner. Motor koruma şalterinin ani açtırıcısını zorlayan bu ilk tepedir.",
            "Motor hızlandıkça rotor frekansı düşer ama akım, hızın %80'ine kadar kilitli rotor değerine yakın kalır; ancak son bölümde hızla düşer. Yol alma süresini motor momenti ile yük momenti arasındaki fark ve atalet belirler.",
            f"Yol alma akımı şebeke empedansında gerilim düşürür: bara gerilimi %{fnum(u_min * 100, 0)}'e iniyor. Moment gerilimin karesiyle azaldığından zayıf şebekede yol alma uzar; gerilim çok düşerse motor yükü kaldıramaz.",
            "Yıldız–üçgende akım ve moment üçte bire iner; yumuşak yol verici gerilimi kısarak akımı sınırlar ama momenti karesiyle düşürür. Frekans konvertöründe yol alma akımı yoktur: motor baştan itibaren anma kaymasında çalışır.",
            "Röle yol almayı akımın %10'un altından 200 ms içinde eşiğin üstüne çıkmasından tanır. Yol alma süresince kilitli rotor kademesi kilitlidir; yol alma izin verilen süreden uzun sürerse 48 açar. Her yol alma ısıl payın bir bölümünü kullanır: 66 peş peşe yol vermeyi sınırlar.",
        ],
        "dersler": [
            "Yol almada iki ayrı akım vardır: ilk periyottaki tepe (ani açtırıcı için) ve saniyelerce süren yol alma akımı (ısıl koruma ve gerilim için).",
            "Verimli motorlarda Ia/In büyür, kalkış güç katsayısı düşer: ilk tepe 13–15 × In'e çıkabilir; eski ayarla ani açtırıcı yol vermede atar.",
            "Gerilim %10 düşerse moment %19 düşer. Yol alamayan motor kilitli rotor akımını çekmeye devam eder: 48 bunun içindir.",
            "Yumuşak yol verici ve konvertörde röle «yol alıyor» işareti üretmez; 48 ve 66 bu uygulamalarda aynı biçimde çalışmaz.",
        ],
        "tablolar": [{"baslik": "Aynı motor ve yükte yol verme yöntemleri", "cols": ["Yöntem", "İlk akım", "Kalkış momenti", "En düşük bara gerilimi", "Yol alma süresi"], "rows": [satir(y_) for y_ in YONTEM],
                      "not": "Yıldız–üçgende geçiş anındaki darbe ayrıca incelenir (Topraklama laboratuvarı › Makine ve kumanda › Motor)."}],
    }
