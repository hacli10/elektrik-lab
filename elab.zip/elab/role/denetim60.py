"""Ölçü devresi denetimi: akım trafosu denetimi (ANSI 60, CTS) ve gerilim trafosu denetimi (ANSI 60FL, VTS) — Easergy P3.

Dayanak: P3U/en M/J006 böl. 6.7 (AT denetimi: üç faz akımından biri Imin<'in altına düşerken bir başkası Imax>'ı aşıyorsa gecikme sonunda alarm; açık AT
sekonderi tehlikeli gerilim doğurur), Çizelge 108 (Imax> 0–10 ×In, varsayılan 2,0; Imin< varsayılan 0,2; t 0,02–600 s, varsayılan 0,10);
böl. 6.8 (GT denetimi: V2, V2> ayarını aşarken I2, I2< ayarının altındaysa alarm; gerilime bağlı korumalar kilitlenebilir), Çizelge 111 (V2> varsayılan
%34,6 Un; I2< varsayılan %100 In; t 0,10 s). V2 yüzdesinin tabanı (faz–nötr mü faz arası mı) kılavuzda açık değildir — eşik karşılaştırması «dogrulanacak»."""
from __future__ import annotations

from .ortak import A, A120, C, G, K, KABUL, P3U, S, T, ctl, fnum, num, opt, simetrik, tek_hat

ID = "denetim60"
BASLIK = "AT / GT denetimi (60 · 60FL)"
IKON = "🔍"
GIRIS = ("Koruma, ölçtüğü akım ve gerilim doğruysa doğru çalışır. Bir gerilim trafosu sigortası atarsa röle gerilimi düşmüş sanır; bir akım trafosu "
         "sekonderi açılırsa akımı dengesiz sanır. Denetim fonksiyonları bu durumu gerçek arızadan ayırır ve yanlış açacak korumaları kilitler.")

OLAY = {"normal": "Normal işletme", "gt1": "Bir GT sigortası attı", "gt3": "GT sekonder otomatı açtı (üç faz birden)", "at1": "Bir fazın AT sekonderi açık devre", "ariza": "Şebekede iki fazlı kısa devre (gerçek arıza)"}

KONTROLLER = [
    ctl("olay", "Durum", "sec", "gt1", secenek=opt(*OLAY.items())),
    ctl("yuk", "Yük akımı", "sayi", 60, min=5, max=150, adim=5, birim="% In"),
    ctl("v2", "Röle › GT denetimi V2>", "sayi", 20.0, min=0, max=200, adim=0.1, birim="% Un"),
    ctl("i2", "Röle › GT denetimi I2<", "sayi", 100, min=0, max=200, adim=1, birim="% In"),
    ctl("imax", "Röle › AT denetimi Imax>", "sayi", 0.3, min=0, max=10, adim=0.05, birim="×In"),
    ctl("imin", "Röle › AT denetimi Imin<", "sayi", 0.05, min=0, max=10, adim=0.05, birim="×In"),
    ctl("t", "Röle › Gecikme t>", "sayi", 0.10, min=0.02, max=600, adim=0.02, birim="s"),
    ctl("di", "GT otomatının yardımcı kontağı röleye bağlı", "onay", True),
    ctl("kilit", "Kilit matrisi: GT denetimi → 27, 27P, 47, 67 (yön)", "onay", True),
]


def olc(p: dict) -> dict:
    o = p.get("olay") if p.get("olay") in OLAY else "gt1"; a = A120; y = num(p, "yuk", 60) / 100
    U = [1 + 0j, a * a, a]; I = [y + 0j, y * a * a, y * a]
    if o == "gt1":
        U[0] = 0j
    elif o == "gt3":
        U = [0j, 0j, 0j]
    elif o == "at1":
        I[0] = 0j
    elif o == "ariza":                                           # L2–L3 kısa devresi: iki fazın gerilimi birbirine yaklaşır, akım büyür ve zıt yönlüdür
        U = [1 + 0j, complex(-0.5, -0.25), complex(-0.5, 0.25)]; I = [y + 0j, complex(0, -4.0), complex(0, 4.0)]
    return {"o": o, "U": U, "I": I, "v2": abs(simetrik(*U)[2]) * 100, "v1": abs(simetrik(*U)[1]) * 100, "i2": abs(simetrik(*I)[2]) * 100, "imax": max(abs(x) for x in I), "imin": min(abs(x) for x in I)}


def run(p: dict) -> dict:
    m = olc(p); o = m["o"]
    vts = m["v2"] > num(p, "v2", 20.0) and m["i2"] < num(p, "i2", 100)
    vts_di = o == "gt3" and bool(p.get("di"))
    cts = m["imin"] < num(p, "imin", 0.05) and m["imax"] > num(p, "imax", 0.3)
    gt_olay, at_olay = o in ("gt1", "gt3"), o == "at1"
    gt_ok = (vts or vts_di) == gt_olay; at_ok = cts == at_olay
    kilitli = (vts or vts_di) and bool(p.get("kilit"))
    yanlis27 = gt_olay and not kilitli                             # gerilim «düşük» görünür: 27 yanlış açar
    c = tek_hat(("Santral", ""), ("Dağıtım şebekesi", OLAY[o]), ("60 · 60FL", ("GT ALARMI" if (vts or vts_di) else "") + (" " if (vts or vts_di) and cts else "") + ("AT ALARMI" if cts else "") or "alarm yok"),
                "acti" if (vts or vts_di or cts) else ("gecersiz" if (gt_olay or at_olay) else "normal"), 620 if o == "ariza" else None, "sag" if o != "gt3" else "sag", ileri=False,
                at_ad="AT" + (" — sekonder AÇIK" if o == "at1" else ""), gt_ad="GT" + (" — sigorta atık" if o == "gt1" else " — otomat açık" if o == "gt3" else ""))
    c.yazi(500, 190, f"V2 = %{fnum(m['v2'], 1)} · I2 = %{fnum(m['i2'], 0)} · faz akımları {fnum(m['imin'], 2)} … {fnum(m['imax'], 2)} ×In", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, "Gerilime bağlı korumalar: " + ("KİLİTLİ" if kilitli else ("kilitsiz — 27 / 67 yanlış çalışabilir" if gt_olay else "serbest")), "#b91c1c" if yanlis27 else "#334155", 11)
    c.yazi(500, 228, "GT alarmı: V2 > V2>  VE  I2 < I2<", "#475569", 10.5)
    c.yazi(500, 244, "AT alarmı: bir faz < Imin<  VE  bir faz > Imax>", "#475569", 10.5)
    ozet = [
        K("GT denetimi (60FL)", "ALARM" if (vts or vts_di) else "alarm yok", "ok" if gt_ok else "bad", ("doğru" if gt_ok else "YANLIŞ") + " — " + ("GT devresi arızalı" if gt_olay else "GT devresi sağlam")),
        K("AT denetimi (60)", "ALARM" if cts else "alarm yok", "ok" if at_ok else "bad", ("doğru" if at_ok else "YANLIŞ") + " — " + ("AT devresi arızalı" if at_olay else "AT devresi sağlam")),
        K("Negatif bileşen gerilim V2", f"%{fnum(m['v2'], 1)}", "info", f"ayar %{fnum(num(p, 'v2', 20.0), 1)}"),
        K("Negatif bileşen akım I2", f"%{fnum(m['i2'], 0)}", "info", f"ayar %{fnum(num(p, 'i2', 100), 0)}"),
        K("Gerilime bağlı korumalar", "kilitli" if kilitli else "serbest", "bad" if yanlis27 else "ok", "27 yanlış açar" if yanlis27 else ""),
    ]
    kontroller = [
        C("GT devresi arızası doğru tanınıyor mu?", ("alarm" if (vts or vts_di) else "alarm yok") + f" (V2 = %{fnum(m['v2'], 1)}, I2 = %{fnum(m['i2'], 0)})", "sigorta atınca alarm; gerçek arızada alarm yok", gt_ok,
          "V2 ayarı aşar ve aynı anda I2 ayarın altındaysa alarm — " + P3U + " böl. 6.8. V2 yüzdesinin tabanı kılavuzla doğrulanacak", "dogrulanacak"),
        C("Tek sigorta atması görülüyor mu?", f"tek faz kaybında V2 = %33,3; ayar %{fnum(num(p, 'v2', 20.0), 1)}", "V2> < %33", num(p, "v2", 20.0) < 33.3,
          "Bir faz gerilimi sıfırken V2 = 1/3 (hesap, faz–nötr tabanında). Varsayılan %34,6 ile karşılaştırma rölenin kullandığı tabana bağlıdır — devreye almada bir sigortayı çıkarıp deneyin", "dogrulanacak"),
        C("Üç faz birden kaybolursa?", "V2 = 0: bu yöntem görmez" + (" — otomat kontağı bağlı" if p.get("di") else ""), "GT otomatının yardımcı kontağı dijital girişe bağlanıp kilit matrisinde kullanılmalı", bool(p.get("di")),
          "Yöntem negatif bileşene dayanır; dengeli kayıpta negatif bileşen yoktur (hesap). Kilit matrisine dış işaret bağlanabilir — " + P3U + " böl. 5.8", "resmi"),
        C("Gerilime bağlı korumalar kilitleniyor mu?", "kilit matrisi bağlı" if p.get("kilit") else "bağlı değil", "27, 27P, 47 kilitlenir; 67 için «Yön + Artçı» ya da kilit", bool(p.get("kilit")),
          "GT denetimi işareti kilit matrisinde gerilim kademelerini kilitlemek için kullanılır — " + P3U + " böl. 5.8, 5.14, 6.8", "resmi"),
        C("AT denetimi bu yük düzeyinde çalışabilir mi?", f"yük {fnum(num(p, 'yuk', 60) / 100, 2)} ×In; Imax> = {fnum(num(p, 'imax', 0.3), 2)} ×In", "Imax> < en küçük işletme akımı; Imin< bunun belirgin altında", num(p, "imax", 0.3) < num(p, "yuk", 60) / 100,
          "Koşul: bir faz Imin<'in altında VE bir başka faz Imax>'ın üstünde — " + P3U + " böl. 6.7. Varsayılan Imax> = 2,0 ×In ile yük akımında alarm oluşmaz", "resmi"),
        C("Açık AT sekonderi tehlikesi", "açık" if at_olay else "kapalı", "AT sekonderi hiçbir an açık kalmamalı", not at_olay, "Açık devre sekonder tehlikeli gerilim doğurur — " + P3U + " böl. 6.7; " + KABUL, "resmi"),
    ]
    girdiler = [
        G("GT sekonder koruması (sigorta mı, otomat mı; yardımcı kontak var mı)", "üç ayrı sigorta / üç kutuplu otomat", "Hücre sekonder şeması", "Tek faz kaybı V2 ile görülür; üç fazın birden kaybı ancak yardımcı kontakla", "Dijital giriş → kilit matrisi"),
        G("En küçük işletme akımı", f"%{fnum(num(p, 'yuk', 60), 0)} In", "Yük kayıtları", "AT denetimi yük akımıyla çalışır: Imax> yükün altında olmalı", "Imax>, Imin<"),
        G("Şebekenin doğal gerilim ve akım dengesizliği", "V2 ≈ %1–2; I2 birkaç yüzde", "Röle ölçüm sayfası", "Eşikler bunların üstünde olmalı", "V2>, I2<"),
        G("Hangi korumalar gerilime bağlı", "27, 27P, 47, 59N (hesaplanan), 67, 67N, 81 (düşük gerilim kilidi)", "Ayar föyü", "GT arızasında bunlar yanlış açar ya da susar", "Kilit matrisi"),
    ]
    adimlar = [
        A("Tek faz gerilim kaybında V2", "V2 = (0 + a²·U + a·U) / 3", "bir faz 0, öbürleri tam", "%33,3", "simetrili bileşenler", "resmi"),
        A("GT denetimi V2>", "doğal dengesizlik < V2> < %33", "ör. %10–30", f"%{fnum(num(p, 'v2', 20.0), 1)} (şu an)", "varsayılan %34,6: " + P3U + " Çizelge 111", "dogrulanacak", ["Şebekenin doğal gerilim ve akım dengesizliği"], "V2>"),
        A("GT denetimi I2<", "gerçek dengesiz arızadaki I2'nin altı, yükteki I2'nin üstü", "sigorta atınca akım değişmez: I2 küçük kalır", f"%{fnum(num(p, 'i2', 100), 0)} (şu an)", "varsayılan %100: " + P3U + " Çizelge 111", "resmi", [], "I2<"),
        A("AT denetimi Imax> ve Imin<", "Imin< < Imax> < en küçük yük", f"yük {fnum(num(p, 'yuk', 60) / 100, 2)} ×In", f"Imax> ≈ {fnum(0.5 * num(p, 'yuk', 60) / 100, 2)}, Imin< ≈ {fnum(0.1 * num(p, 'yuk', 60) / 100, 2)} ×In", "öneri (öğretim amaçlı)", "ikincil", ["En küçük işletme akımı"], "Imax>, Imin<"),
    ]
    ayarlar = [
        S("GT denetimi › V2>", f"%{fnum(num(p, 'v2', 20.0), 1)} Un", "%0 … %200; varsayılan %34,6", "Negatif bileşen gerilim eşiği", P3U + " Çizelge 111"),
        S("GT denetimi › I2<", f"%{fnum(num(p, 'i2', 100), 0)} In", "%0 … %200; varsayılan %100", "Negatif bileşen akım bunun altındaysa olay arıza değil sigorta atmasıdır", P3U + " Çizelge 111"),
        S("GT denetimi › t>", f"{fnum(num(p, 't', 0.1), 2)} s", "0,02 … 600 s; varsayılan 0,10", "Alarm gecikmesi; kilitlenecek kademenin süresinden kısa olmalı", P3U + " Çizelge 111"),
        S("AT denetimi › Imax>", f"{fnum(num(p, 'imax', 0.3), 2)} ×In", "0 … 10 ×In; varsayılan 2,0", "En az bir fazda bu akımın üstü görülmeli", P3U + " Çizelge 108"),
        S("AT denetimi › Imin<", f"{fnum(num(p, 'imin', 0.05), 2)} ×In", "0 … 10 ×In; varsayılan 0,2", "Bir fazın akımı bunun altına düşmüş olmalı", P3U + " Çizelge 108"),
        S("Kilit matrisi › GT denetimi → gerilim kademeleri", "bağlı" if p.get("kilit") else "bağlı değil", "—", "Bağlanmazsa alarm verir ama yanlış açmayı önlemez", P3U + " böl. 6.8"),
    ]
    test = [
        T("GT denetimi", "Üç faza anma gerilimi ve yük akımı verin; bir fazın gerilimini kesin", f"{fnum(num(p, 't', 0.1), 2)} s sonra GT alarmı; 27 kilitlenir", "V2 eşiği ±%3 dolayı"),
        T("Gerçek arıza ayrımı", "Aynı gerilim kaybıyla birlikte akımı da dengesiz yapın (I2 > I2<)", "GT alarmı gelmez; korumalar serbest", "—"),
        T("Üç faz kaybı", "Üç fazın gerilimini birden kesin", "V2 yöntemi alarm vermez; otomat kontağı bağlıysa dijital giriş kilitler", "—"),
        T("AT denetimi", f"Üç faza Imax>'ın üstünde akım; bir fazı kesin (test cihazından — gerçek AT sekonderini açmayın)", f"{fnum(num(p, 't', 0.1), 2)} s sonra AT alarmı", "—"),
    ]
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["_60_", "60fl"],
        "sahne": c.sahne(),
        "cubuklar": [{"baslik": "Negatif bileşenler ve eşikler", "kategoriler": ["V2 (% Un)", "I2 (% In)"], "y_ad": "%",
                      "seriler": [{"ad": "ölçülen", "renk": "#dc2626", "deger": [round(m["v2"], 1), round(min(m["i2"], 250), 1)]}, {"ad": "ayar", "renk": "#1a4d8f", "deger": [num(p, "v2", 20.0), num(p, "i2", 100)]}]}],
        "anlatim": [
            "Gerilim trafosunun bir sigortası attığında röle o fazın gerilimini sıfır görür. Düşük gerilim rölesi bunu gerilim çukuru sanar; yönlü röle yönü yanlış çözer.",
            "Gerçek bir arızayla farkı akımdadır: sigorta atınca şebekede hiçbir şey değişmemiştir, akımlar dengelidir. Röle gerilimde negatif bileşen görüp akımda görmüyorsa sorun ölçü devresindedir.",
            "Bu yöntem üç fazın birden kaybını göremez: dengeli kayıpta negatif bileşen yoktur. Bunun için GT otomatının yardımcı kontağı röleye bağlanır.",
            "Akım trafosu tarafında benzer mantık: bir fazın akımı kaybolmuş ama öbür fazlar yük taşıyorsa o fazın sekonder devresi açılmıştır. Bu aynı zamanda tehlikedir: açık AT sekonderinde yüksek gerilim oluşur.",
            "Denetim işaretleri yalnız alarm verir. Yanlış açmayı önlemek için kilit matrisinde gerilime bağlı kademelere bağlanmaları gerekir.",
        ],
        "dersler": [
            "V2 var + I2 yok → GT sigortası. V2 var + I2 var → gerçek arıza.",
            "Üç faz otomat açması V2 ile görülmez: yardımcı kontağı bağlayın.",
            "AT denetiminin varsayılanı (Imax> 2 ×In) yük akımında çalışmaz; yükünüze göre ayarlayın.",
            "Kilit matrisine bağlanmayan denetim, yanlış açmayı önlemez.",
        ],
        "tablolar": [{"baslik": "Duruma göre ölçülenler ve denetim (bu ayarlarla)", "cols": ["Durum", "V2", "I2", "GT alarmı", "AT alarmı"], "rows": [
            (lambda mm, ad: [ad, f"%{fnum(mm['v2'], 1)}", f"%{fnum(mm['i2'], 0)}", "ALARM" if (mm["v2"] > num(p, "v2", 20.0) and mm["i2"] < num(p, "i2", 100)) or (mm["o"] == "gt3" and p.get("di")) else "—",
                             "ALARM" if mm["imin"] < num(p, "imin", 0.05) and mm["imax"] > num(p, "imax", 0.3) else "—"])(olc({**p, "olay": oo}), OLAY[oo]) for oo in OLAY]}],
    }
