"""Sınırlandırılmış toprak arıza koruması (ANSI 64REF) — küçük empedanslı, tutuculu «dIo>» kademesi.

Dayanak: P3T32 kılavuzu P3T/en M/L007 böl. 6.22 (fark akımı ID = |I0Meas + I0Calc| — Denklem 21; koruma bölgesine giren akım artı; I0Meas ve I0Calc'in anma akımı akım
trafosu anma akımıdır; tutucu akım IB = (|IL1| + |IL2| + |IL3|) / 3 — Denklem 22; dIo>> kademesi tutucu akıma bakmaz; yönlü engelleme: açma yalnız ölçülen nötr akımı ile
hesaplanan artık akım arasındaki açı ±88°'den küçükse; «Io3 girişini kullanın» notu), Çizelge 83 (başlatma %5–50 In, tutucu akım 0,5 ×In'e kadar düz, eğim 1 %5–100,
eğim 2 başlangıcı 1–3 ×In, eğim 2 %100–200, çalışma < 60 ms, doğruluk ±%3 ya da 0,02 ×In). Sargı kapsama bağıntısı klasik koruma kitaplarındaki bağıntıdır."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, KABUL, P3T, S, S3, T, Cizim, ctl, fa, fnum, num, opt

ID = "ref64"
BASLIK = "Sınırlı toprak (64REF)"
IKON = "🎯"
GIRIS = ("Trafo sargısının nötre yakın bölümündeki toprak arızasında akım küçüktür; faz diferansiyeli bunu göremez. 64REF yalnız sargının toprak "
         "akımlarını karşılaştırır: nötrden giren akım, faz iletkenlerinden çıkan artık akıma eşit değilse arıza sargının içindedir.")

KONTROLLER = [
    ctl("sn_kva", "Trafo gücü", "sayi", 2000, min=250, max=40000, adim=50, birim="kVA"),
    ctl("un_kv", "Korunan (topraklı) sargının gerilimi", "sec", 34.5, secenek=opt((0.4, "0,4 kV"), (6.3, "6,3 kV"), (10.5, "10,5 kV"), (34.5, "34,5 kV"))),
    ctl("i_max", "Sargı ucundaki toprak arızasında nötr akımı", "sayi", 300, min=20, max=40000, adim=10, birim="A", yardim="Nötr direncinin akım sınırı; doğrudan topraklıda Ik1"),
    ctl("ct_p", "Faz akım trafosu primeri", "sayi", 50, min=5, max=6000, adim=5, birim="A"),
    ctl("ctn_p", "Nötr akım trafosu primeri", "sayi", 50, min=5, max=6000, adim=5, birim="A", yardim="Röledeki «Ölçülen Io girişi»nin (ör. Io3) oranı"),
    ctl("yer", "Arıza yeri", "sec", "ic", secenek=opt(("ic", "Sargının içinde"), ("dis", "Dışarıda — faz akım trafolarının ötesinde"))),
    ctl("x", "İç arızanın sargıdaki yeri (nötrden itibaren)", "sayi", 20, min=1, max=100, adim=1, birim="%", goster={"yer": ["ic"]}),
    ctl("doyma", "Dış arızada bir faz akım trafosunun doyması", "sayi", 0, min=0, max=80, adim=5, birim="%", goster={"yer": ["dis"]}),
    ctl("dio", "Röle › dIo> başlatma", "sayi", 10, min=5, max=50, adim=1, birim="%In"),
    ctl("e1", "Röle › Eğim 1", "sayi", 50, min=5, max=100, adim=5, birim="%"),
    ctl("ib2", "Röle › Eğim 2 başlangıcı için Itut", "sayi", 2.0, min=1.0, max=3.0, adim=0.1, birim="pu"),
    ctl("e2", "Röle › Eğim 2", "sayi", 100, min=100, max=200, adim=5, birim="%"),
    ctl("yonlu", "Röle › Yönlü engelleme etkin", "onay", True),
    ctl("ters", "Nötr akım trafosu ters bağlı", "onay", False),
]


def esik(ib: float, p: dict) -> float:
    d0, s1, b2, s2 = num(p, "dio", 10) / 100, num(p, "e1", 50) / 100, num(p, "ib2", 2.0), num(p, "e2", 100) / 100
    if ib <= 0.5:
        return d0
    return d0 + s1 * (ib - 0.5) if ib <= b2 else d0 + s1 * (b2 - 0.5) + s2 * (ib - b2)


def olc(p: dict, yer: str | None = None, x: float | None = None) -> dict:
    """Akımlar faz akım trafosunun anma akımının katı (kılavuz: I0Meas ve I0Calc'in anma akımı AT anma akımıdır); koruma bölgesine giren akım artı."""
    i_n = num(p, "sn_kva", 2000) / (S3 * num(p, "un_kv", 34.5))            # korunan sargının anma akımı (yalnız bilgi ve 87T karşılaştırması için)
    yer = yer or (p.get("yer") if p.get("yer") in ("ic", "dis") else "ic")
    xx = (num(p, "x", 20) if x is None else x) / 100
    imax = num(p, "i_max", 300) / num(p, "ct_p", 50)
    if yer == "ic":
        i_notr, i_faz = xx * imax, 0.0                       # nötrden girer; faz tarafında kaynak yoksa artık akım yok
    else:
        i_notr, i_faz = imax, -imax * (1 - num(p, "doyma", 0) / 100)     # nötrden girer, arızalı fazın iletkeninden çıkar (doyma: eksik ölçülür)
    if p.get("ters"):
        i_notr = -i_notr
    idf = abs(i_notr + i_faz)                                # Denklem 21
    ib = abs(i_faz) / 3                                      # Denklem 22: (|IL1| + |IL2| + |IL3|) / 3 — yük akımı ihmal, yalnız arızalı fazın akımı
    zit = abs(i_notr) > 0.02 and abs(i_faz) > 0.02 and i_notr * i_faz < 0              # iki akım arasındaki açı > 88°: içinden geçen arıza
    blok = bool(p.get("yonlu")) and zit
    thr = esik(ib, p)
    return {"in": i_n, "i_notr": i_notr, "i_faz": i_faz, "id": idf, "ib": ib, "thr": thr, "blok": blok, "acar": idf > thr and not blok, "yer": yer, "imax": imax}


def run(p: dict) -> dict:
    m = olc(p); i_n = m["in"]; imax = m["imax"]; imax_tr = num(p, "i_max", 300) / i_n
    beklenen = m["yer"] == "ic"
    dio = num(p, "dio", 10) / 100; ct_p, ctn_p = num(p, "ct_p", 50), num(p, "ctn_p", 50)
    x_ref = min(100.0, dio / imax * 100)                                  # 64REF'in göremediği sargı bölümü (%)
    x_87 = min(100.0, math.sqrt(0.20 * S3 / imax_tr) * 100)                  # 87T (dI> %20) için: öbür sargıdaki akım ≈ x²·Imax/√3
    c = Cizim(900, 300)
    c.kutu(20, 40, 110, 46, "Besleme", "öbür sargı")
    c.hat("M130,63 H250", "L1", w=3); c.daire(280, 63, 30, "cizgi", dolgu="#fff"); c.daire(322, 63, 30, "cizgi"); c.sarim(280, 65, "ucgen", r=13); c.sarim(322, 66, "yildiz", r=13)
    c.hat("M352,63 H800", "L1", hot=m["yer"] == "dis", w=3); c.kutu(800, 40, 80, 46, "Yük / hat", "")
    c.toroid(470, 63, 7, 17); c.yazi(470, 36, f"faz AT {ct_p:g}/1 (IoHes = IL1+IL2+IL3)", "#475569", 10, anchor="middle")
    c.hat("M322,93 V150", "cizgi", hot=True, w=2.4); c.toroid(322, 130, 12, 6, "ariza" if p.get("ters") else "#1e293b")
    c.yazi(340, 134, f"nötr AT {ctn_p:g}/1" + (" — TERS" if p.get("ters") else ""), "#b91c1c" if p.get("ters") else "#475569", 10)
    c.direnc(322, 150, f"{fnum(num(p, 'i_max', 300), 0)} A", hot=True, h=26); c.hat("M322,176 V190", "cizgi"); c.toprak(322, 190)
    c.dikdortgen(240, 20, 250, 128, "mavi", kesik=True, kw=1.2); c.yazi(244, 14, "koruma bölgesi: nötr AT ile faz AT'leri arası", "#1d4ed8", 10)
    c.kutu(520, 150, 230, 60, "64REF  dIo>", ("AÇTI" if m["acar"] else "açmadı" + (" — yönlü engelleme" if m["blok"] else "")), "acti" if m["acar"] else ("gecersiz" if m["acar"] != beklenen else "normal"))
    c.hat("M470,81 V180 H520", "cizgi", kesik=True, w=1.4); c.hat("M334,130 H420 V196 H520", "cizgi", kesik=True, w=1.4)
    if m["yer"] == "ic":
        c.simsek(300, 84, 1.0); c.yazi(232, 118, f"arıza: sargının %{fnum(num(p, 'x', 20), 0)}'inde", "#b91c1c", 10.5, kalin=True, anchor="end")
    else:
        c.simsek(674, 52, 1.1); c.hat("M680,63 V104", "ariza", hot=True); c.toprak(680, 106, "ariza"); c.yazi(692, 100, "dış arıza", "#b91c1c", 10.5, kalin=True)
    c.yazi(520, 232, f"Io (nötr) = {fnum(abs(m['i_notr']), 2)} ×In · IoHes (faz) = {fnum(abs(m['i_faz']), 2)} ×In  (In: AT anma akımı)", "#334155", 11)
    c.yazi(520, 250, f"fark dIo = {fnum(m['id'], 2)} ×In · tutucu {fnum(m['ib'], 2)} ×In · eşik {fnum(m['thr'], 2)} ×In", "#b91c1c" if m["id"] > m["thr"] else "#334155", 11.5, kalin=True)
    ozet = [
        K("Röle kararı", "AÇAR" if m["acar"] else "AÇMAZ", "ok" if m["acar"] == beklenen else "bad", ("doğru" if m["acar"] == beklenen else "YANLIŞ") + " — arıza " + ("sargının içinde" if beklenen else "dışarıda")),
        K("Fark akımı dIo", f"{fnum(m['id'], 2)} ×In", "bad" if m["id"] > m["thr"] else "ok", f"= {fa(m['id'] * ct_p)} · eşik {fnum(m['thr'], 2)} (In = AT {ct_p:g} A)"),
        K("64REF'in göremediği sargı", f"%{fnum(x_ref, 0)}", "ok" if x_ref <= 20 else "warn", "nötre en yakın bölüm"),
        K("87T'nin göremediği sargı", f"%{fnum(x_87, 0)}", "warn" if x_87 > x_ref else "info", "aynı sargıda, dI> = %20 ile"),
        K("Sargının anma akımı", fa(i_n), "info", f"AT {ct_p:g} A'in {fnum(i_n / ct_p, 2)} katı"),
    ]
    kontroller = [
        C("Röle bu durumda doğru karar veriyor mu?", "açar" if m["acar"] else "açmaz", "yalnız sargı içindeki arızada açar", m["acar"] == beklenen,
          "ID = |I0Meas + I0Calc|; IB = (|IL1| + |IL2| + |IL3|) / 3 — " + P3T + " böl. 6.22 Denklem 21–22", "resmi"),
        C("Sargının en az %80'i korunuyor mu?", f"görülmeyen bölüm = dIo> · In(AT) / I nötr = {fnum(dio, 2)} × {ct_p:g} / {fnum(num(p, 'i_max', 300), 0)} = %{fnum(x_ref, 1)}", "≤ %20", x_ref <= 20,
          "Dirençle topraklı yıldız sargıda arıza akımı arıza yerinin nötre uzaklığıyla orantılıdır (klasik bağıntı); %80 hedefi saha pratiği", "ikincil"),
        C("Dış arızada kararlı mı (bir faz AT'si doysa da)?", f"dış arıza, doyma %{fnum(num(p, 'doyma', 0), 0)} → " + ("açar" if olc(p, 'dis')["acar"] else "açmaz"), "açmaz", not olc({**p, "ters": False}, "dis")["acar"],
          "Yönlü engelleme açıkken açma yalnız ölçülen nötr akımı ile hesaplanan artık akım arasındaki açı ±88°'den küçükse verilir — " + P3T + " böl. 6.22", "resmi"),
        C("Nötr ve faz akım trafolarının oranı aynı mı?", f"nötr {ctn_p:g}/1, faz {ct_p:g}/1", "aynı oran; farklıysa geçen akımda fark akımı oluşmadığı kararlılık testiyle doğrulanır", (ctn_p == ct_p) or None,
          "I0Meas ve I0Calc'in anma akımı kendi akım trafolarının anma akımıdır — " + P3T + " böl. 6.22 notu. Oranlar farklıyken rölenin eşlemesi kılavuzda anlatılmıyor", "dogrulanacak"),
        C("Nötr akım trafosunun polaritesi", "ters" if p.get("ters") else "doğru", "primer enjeksiyon ya da dış arıza benzetimiyle doğrulanır", not p.get("ters"), KABUL, "resmi"),
    ]
    girdiler = [
        G("Hangi sargı topraklı ve nasıl", f"{fnum(num(p, 'un_kv', 34.5), 1)} kV yıldız, nötr akımı {fnum(num(p, 'i_max', 300), 0)} A ile sınırlı", "Tek hat şeması; nötr direnci etiketi", "64REF yalnız topraklı sargıyı korur; arıza akımının üst sınırını nötr empedansı belirler", "Kapsama = dIo> · In / I nötr"),
        G("Faz akım trafosunun anma akımı", f"{ct_p:g} A", "Hücre etiketi", "64REF'te «%In»in In'i akım trafosunun anma akımıdır (faz diferansiyelindeki gibi trafonun anma akımı değil)", "dIo> (A) = % × AT primeri"),
        G("Nötr akım trafosu (oran, polarite, hangi girişe bağlı)", f"{ctn_p:g}/1 A → Io3 girişi", "Tek hat şeması; röle bağlantı şeması", "Rölede «Ölçülen Io girişi» olarak seçilir; polaritesi yanlışsa dış arızada açar", "Ölçülen Io"),
        G("Faz akım trafoları (oran)", f"{ct_p:g}/1 A", "Hücre etiketi", "Röle üç faz akımının toplamını (IoHes) kendisi hesaplar", "Hesaplanan Io"),
        G("Dış arızadaki en büyük akım ve faz AT sınıfı", "5P20 dolayı", "Kısa devre hesabı; AT etiketi", "Doyan faz AT'si sahte artık akım üretir; eğimler ve yönlü engelleme bunu karşılar", "Eğim 1, eğim 2, yönlü engelleme"),
    ]
    adimlar = [
        A("Röle birimi", "In = faz akım trafosunun anma akımı", f"AT {ct_p:g}/1 A", f"1 ×In = {ct_p:g} A", P3T + " böl. 6.22 notu; böl. 4 (toprak akımlarında 1 pu = AT primeri)", "resmi", ["Faz akım trafosunun anma akımı"]),
        A("Sargı içi arızada akım", "I = x · I nötr (x: arıza yerinin nötre uzaklığı)", f"%{fnum(num(p, 'x', 20), 0)} × {fnum(num(p, 'i_max', 300), 0)} A", f"{fa(num(p, 'x', 20) / 100 * num(p, 'i_max', 300))} = {fnum(num(p, 'x', 20) / 100 * imax, 2)} ×In", "gerilim arıza yerine kadar olan sarım sayısıyla orantılı; direnç sabit", "ikincil", ["Hangi sargı topraklı ve nasıl"]),
        A("dIo> başlatma", "dIo> ≤ hedef kapsama × I nötr / In(AT)", f"%20 × {fnum(imax, 2)} ×In", f"≤ %{fnum(min(50, 0.2 * imax * 100), 0)} In → %10 dolayı", "duyarlılık ile AT hatasından doğan sahte artık akım arasında denge", "ikincil", ["Hangi sargı topraklı ve nasıl", "Faz akım trafosunun anma akımı"], "dIo> başlatma"),
        A("Görülmeyen sargı bölümü", "x min = dIo> · In(AT) / I nötr", f"{fnum(dio, 2)} × {ct_p:g} / {fnum(num(p, 'i_max', 300), 0)}", f"%{fnum(x_ref, 1)}", "64REF için", "ikincil"),
        A("Aynı sargıda 87T'nin kapsaması", "x min = √(dI> · √3 · In(trafo) / I nötr)", f"√(0,20 × 1,732 × {fnum(i_n, 1)} / {fnum(num(p, 'i_max', 300), 0)})", f"%{fnum(x_87, 0)}", "öbür sargıdan görülen akım x²·I nötr/√3 ile orantılıdır: nötre yakın arızada faz diferansiyeli kördür", "ikincil"),
    ]
    ayarlar = [
        S("Ölçülen Io giriş", "Io3 (nötr akım trafosunun bağlı olduğu giriş)", "Io3", "Yıldız noktası iletkenindeki akım; küçük empedanslı REF için Io3 girişi kullanılır", P3T + " böl. 6.22 notu, Çizelge 83"),
        S("IoHes giriş", "IL (korunan sargı tarafının faz akımları)", "IoHes / I'oHes", "Röle üç faz akımını toplayarak artık akımı hesaplar; hangi tarafın akımları olduğu seçilir", P3T + " Çizelge 83"),
        S("Yönlü engelleme etkin", "Açık", "Açık / Kapalı", "Açma yalnız iki akım arasındaki açı ±88°'den küçükse verilir: dış arızada faz AT'si doysa da açmaz", P3T + " böl. 6.22"),
        S("dIo> başlatma", f"%{fnum(num(p, 'dio', 10), 0)} In = {fa(dio * ct_p)}", "%5 … %50 In; ekrandaki örnek %10", f"Sargının %{fnum(100 - x_ref, 0)}'ini korur (In: AT anma akımı)", P3T + " Çizelge 83"),
        S("Eğim 1", f"%{fnum(num(p, 'e1', 50), 0)}", "%5 … %100; ekrandaki örnek %50", "Tutucu akım 0,5 ×In'i geçince: geçen akımla büyüyen AT hatası", P3T + " Çizelge 83"),
        S("Eğim 2 başlangıcı için Itut", f"{fnum(num(p, 'ib2', 2.0), 2)} ×In", "1 … 3 ×In; ekrandaki örnek 2,00", "Bu akımın üstünde faz AT'si doyabilir", P3T + " Çizelge 83"),
        S("Eğim 2", f"%{fnum(num(p, 'e2', 100), 0)}", "%100 … %200; ekrandaki örnek %100", "AT doymasına karşı", P3T + " Çizelge 83"),
        S("dIo>> kademesi", "isteğe bağlı", "%5 … %50 In", "Tutucu akıma bakmaz (eğimsiz); çalışma < 50 ms", P3T + " böl. 6.22, Çizelge 83"),
        S("Kilit matrisi › 2. harmonik / soğuk yük → dIo>", "isteğe bağlı", "—", "Enerjilendirmede kademeyi kilitlemek için olağan 2. harmonik ve soğuk yük kilidi kullanılabilir", P3T + " böl. 6.22"),
    ]
    test = [
        T("Nötr girişinden tek başına", f"Io3 girişine akım; {fnum(dio, 3)} A'e doğru yükseltin (1 A anma girişte)", f"Başlatma {fnum(dio, 3)} A sekonder (= %{fnum(dio * 100, 0)} × AT anma akımı); çalışma < 60 ms", "±%3 ya da 0,02 ×In (akım < 200 mA ise)"),
        T("Faz girişinden tek faz", "Bir faz girişine akım (IoHes = o akım; tutucu = akımın üçte biri)", f"Başlatma {fnum(dio, 3)} A sekonder", "±%3 ya da 0,02 ×In"),
        T("Kararlılık — dış arıza benzetimi", "Aynı akımı bir faz girişinden ve nötr girişinden seri, zıt yönde geçirin (1 A dolayı)", "Fark ≈ 0; açma yok", "—"),
        T("Polarite sağlaması", "Kararlılık testinde nötr girişinin uçlarını değiştirin", "Fark = 2 × akım: açar. Normal bağlantıda açmıyorsa polarite doğrudur", "—"),
        T("Yönlü engelleme", "Kararlılık düzeninde faz akımını %40 azaltın (doyma benzetimi)", "Engelleme açıkken açmaz (açı 180°); kapalıyken fark eşiği aşar ve açar", "sınır açı ±88°"),
    ]
    xs = list(range(1, 101))
    g = {"baslik": "Sargının ne kadarı korunuyor: arıza yeri nötre yaklaştıkça akım küçülür", "x_ad": "Arıza yeri (sargının yüzdesi, nötrden itibaren)", "y_ad": "ölçülen fark akımı / eşik", "logy": True,
         "seriler": [{"ad": "64REF (dIo>)", "renk": "#15803d", "pts": [[x, max(x / 100 * imax / dio, 1e-3)] for x in xs]},
                     {"ad": "87T (dI> = %20)", "renk": "#1a4d8f", "pts": [[x, max((x / 100) ** 2 * imax_tr / S3 / 0.20, 1e-3)] for x in xs]}],
         "yatay": [{"y": 1.0, "etiket": "eşik"}], "isaretler": [{"x": x_ref, "etiket": f"64REF %{fnum(x_ref, 0)}"}, {"x": x_87, "etiket": f"87T %{fnum(x_87, 0)}"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["64ref"],
        "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Yıldız sargının bir noktası toprağa değdiğinde arızayı süren gerilim, nötr ile arıza yeri arasındaki sarımların gerilimidir. Arıza nötre ne kadar yakınsa gerilim ve akım o kadar küçüktür.",
            "Faz diferansiyeli (87T) bu akımı öbür sargıdan, dönüştürme oranıyla daha da küçülmüş görür: nötre yakın bölümde kördür.",
            "64REF yalnız toprak akımına bakar: nötr iletkenindeki akımı (ölçülen Io) ve üç faz akımının toplamını (hesaplanan IoHes) karşılaştırır.",
            "Arıza dışarıdaysa akım nötrden girer, faz iletkeninden çıkar: ikisi eşit ve zıt yönlüdür, fark sıfırdır. Arıza içerideyse nötrden giren akım faz tarafından çıkmaz: fark akımın kendisidir.",
            "Dış arızada bir faz akım trafosu doyarsa toplam eksik çıkar ve sahte fark oluşur. Tutucu akım üç faz akımının ortalamasıdır; tek fazlı arızada küçük kalır. Asıl güvence yönlü engellemedir: iki akım arasındaki açı ±88°'den büyükse açma verilmez.",
            "Seçici olduğu için gecikmesiz çalışır; koordinasyon süresi gerekmez.",
        ],
        "dersler": [
            "64REF, 87T'nin göremediği nötre yakın sargı bölümünü korur; ikisi birbirinin yerine geçmez.",
            "Kapsama = 1 − dIo> · In(AT) / I nötr. Burada In akım trafosunun anma akımıdır; nötr direnci akımı küçükse aynı ayar daha az sargı korur.",
            "Nötr akım trafosunun polaritesi yanlışsa röle iç arızada da açar, dış arızada da — hata ancak kararlılık testinde görülür.",
            "Nötr AT ile faz AT'lerinin oranı farklı olabilir; röle eşler. Oranları ölçekleme sayfasında doğru girin.",
        ],
        "tablolar": [{"baslik": "Arıza yerine göre iki korumanın gördüğü", "cols": ["Arıza yeri", "Arıza akımı", "64REF: fark / eşik", "87T: fark / eşik"], "rows": [
            [f"sargının %{x}'i", fa(x / 100 * num(p, "i_max", 300), 0), fnum(x / 100 * imax / dio, 1) + (" — görür" if x / 100 * imax >= dio else " — görmez"), fnum((x / 100) ** 2 * imax_tr / S3 / 0.2, 1) + (" — görür" if (x / 100) ** 2 * imax_tr / S3 >= 0.2 else " — görmez")]
            for x in (5, 10, 20, 30, 50, 80, 100)], "not": "87T sütunu dI> = %20 ve dirençle topraklı yıldız sargı kabulüyledir (klasik bağıntı; öğretim amaçlı)."}],
    }
