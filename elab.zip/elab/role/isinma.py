"""Isınma ve soğuma zaman ekseninde: yük çevrimi boyunca ısıl modelin durumu, sıcak ve soğuk açma eğrileri, yeniden yol verme ve negatif
bileşenin ısıl etkisi (49 · 46 · 66).

Dayanak: P3U/en M/J006 böl. 5.16 (ısıl model: açma süresi t = τ·ln[(I² − Ip²)/(I² − a²)], a = k·In; soğuma akım 0,3·In'in altındayken Cτ katsayısıyla
uzatılmış zaman sabitiyle; alarm düzeyi). Negatif bileşenin ısıl modele katılması: Schneider Sepam series 60 (SEPED310017EN) ısıl aşırı yük —
eşdeğer akım Ieq² = Iph² + K·Ii², K ∈ {0 · 2,25 · 4,5 · 9}; asenkron motor için K'nin kalkış momenti, kalkış akımı ve kaymadan hesaplandığı
denklem kılavuzda vardır ama metin çıkarımında okunamadı (dogrulanacak). Benzetim birinci dereceden ısıl modeldir: dθ/dt = (Ieq²/(k·In)² · 100 − θ)/τ."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, P3U, S, T, ctl, fnum, num, opt, tek_hat
from .roleler import SEPAM

ID = "isinma"
BASLIK = "Isınma ve soğuma (49 · 46)"
IKON = "♨"
GIRIS = ("Termik koruma akımın o anki değerine değil, geçmişine bakar: akımın karesinden bir «ısıl düzey» hesaplar. Bu sayfada bir yük çevrimini — çalışma, aşırı yük, "
         "durma, yeniden yol verme — zaman ekseninde izlersiniz: düzey nasıl yükselir, durunca neden yavaş iner, sıcak makine neden çabuk açar ve dengesiz akım "
         "motoru neden fazladan ısıtır.")

KONTROLLER = [
    ctl("tau", "Isınma zaman sabiti τ", "sayi", 20, min=2, max=180, adim=1, birim="dk", yardim="Motor 10–40 dk, kuru trafo 30–60 dk, yağlı trafo 2–3 saat"),
    ctl("ctau", "Dururken soğuma zaman sabiti", "sayi", 3.0, min=1, max=10, adim=0.5, birim="× τ", yardim="Duran motorun fanı dönmez: soğuma ısınmadan birkaç kat yavaştır"),
    ctl("k", "En büyük sürekli akım k", "sayi", 1.06, min=1.0, max=1.3, adim=0.01, birim="×In"),
    ctl("i0", "Olağan yük", "sayi", 0.85, min=0, max=1.0, adim=0.05, birim="×In"),
    ctl("i1", "Aşırı yük", "sayi", 1.30, min=1.0, max=3.0, adim=0.05, birim="×In"),
    ctl("t1", "Aşırı yükün süresi", "sayi", 8, min=1, max=120, adim=1, birim="dk"),
    ctl("dur", "Sonra durma süresi", "sayi", 30, min=0, max=120, adim=1, birim="dk"),
    ctl("yol", "Durduktan sonra yeniden yol veriliyor", "onay", True),
    ctl("ia", "Yol alma akımı", "sayi", 6.0, min=3, max=9, adim=0.1, birim="×In", goster={"yol": [True]}),
    ctl("ts", "Yol alma süresi", "sayi", 8, min=1, max=60, adim=1, birim="s", goster={"yol": [True]}),
    ctl("i2", "Negatif bileşen akımı", "sayi", 0, min=0, max=50, adim=1, birim="%In", yardim="Gerilim dengesizliği %2 ise motorda %10–15 negatif bileşen akımı akar"),
    ctl("kn", "Negatif bileşen katsayısı K", "sec", 4.5, secenek=opt((0, "0 (sayılmaz)"), (2.25, "2,25"), (4.5, "4,5"), (9, "9"))),
    ctl("alarm", "Alarm düzeyi", "sayi", 90, min=60, max=99, adim=1, birim="%"),
]


def ieq(i: float, i2: float, kn: float) -> float:
    return math.sqrt(i * i + kn * i2 * i2)


def benzet(p: dict) -> dict:
    tau, ctau, k = num(p, "tau", 20) * 60, num(p, "ctau", 3.0), num(p, "k", 1.06)
    i0, i1, t1, dur = num(p, "i0", 0.85), num(p, "i1", 1.3), num(p, "t1", 8) * 60, num(p, "dur", 30) * 60
    i2, kn = num(p, "i2", 0) / 100, num(p, "kn", 4.5)
    yol, ia, ts_ = bool(p.get("yol", True)), num(p, "ia", 6.0), num(p, "ts", 8)
    th = (ieq(i0, i2 * (1 if i0 > 0 else 0), kn) / k) ** 2 * 100            # olağan yükte sürekli rejim düzeyi
    th0 = th
    dt = 1.0
    t = -5 * 60.0
    ts, ths, is_ = [], [], []
    acma = None; alarm_t = None; th_yol = None; yol_basla = None
    son = t1 + dur + (ts_ + 10 * 60 if yol else 5 * 60)
    while t <= son:
        if t < 0:
            i = i0
        elif t < t1 and acma is None:
            i = i1
        elif t < (acma if acma is not None else t1) + dur:                  # durma, açma olduysa açma anından başlar
            i = 0.0
        elif yol and (yol_basla is None or t < yol_basla + ts_):
            if yol_basla is None:
                yol_basla = t; th_yol = th
            i = ia
        else:
            i = i0 if yol else 0.0
        ie = ieq(i, i2 if i > 0.3 else 0.0, kn)
        hedef = (ie / k) ** 2 * 100
        tc = tau * ctau if i < 0.3 else tau
        th += (hedef - th) * (1 - math.exp(-dt / tc))
        if th >= num(p, "alarm", 90) and alarm_t is None and t >= 0:
            alarm_t = t
        if th >= 100 and acma is None and t >= 0:
            acma = t
        if int(t) % 15 == 0:
            ts.append(t / 60); ths.append(th); is_.append(i)
        t += dt
    return {"t": ts, "th": ths, "i": is_, "th0": th0, "acma": acma, "alarm": alarm_t, "th_yol": th_yol, "yol_basla": yol_basla, "th_max": max(ths)}


def t_acma(i: float, ip: float, k: float, tau_dk: float) -> float | None:
    """Açma süresi (dk): t = τ·ln[(I² − Ip²)/(I² − k²)]; I ≤ k ise açmaz."""
    if i <= k:
        return None
    return tau_dk * math.log((i * i - ip * ip) / (i * i - k * k))


def run(p: dict) -> dict:
    b = benzet(p)
    tau, k, i0, i1 = num(p, "tau", 20), num(p, "k", 1.06), num(p, "i0", 0.85), num(p, "i1", 1.3)
    i2, kn = num(p, "i2", 0) / 100, num(p, "kn", 4.5)
    ia, ts_ = num(p, "ia", 6.0), num(p, "ts", 8)
    acti = b["acma"] is not None
    t_sicak, t_soguk = t_acma(ieq(i1, i2, kn), ieq(i0, i2, kn), k, tau), t_acma(ieq(i1, i2, kn), 0.0, k, tau)
    yol_artis = (ia / k) ** 2 * 100 * (1 - math.exp(-ts_ / (tau * 60)))      # bir yol almanın ısıl düzeye kattığı pay (%)
    yol_ok = (b["th_yol"] is None) or (b["th_yol"] + yol_artis < 100)
    fazla = (ieq(1.0, i2, kn) ** 2 - 1) * 100                                # negatif bileşenin anma yükünde ısınmaya katkısı (%)

    c = tek_hat(("Besleme", ""), ("Motor / trafo", f"yük {fnum(i0, 2)} → {fnum(i1, 2)} ×In"), ("Termik koruma (49)", ("AÇTI" if acti else "alarm" if b["alarm"] is not None else "izliyor")),
                "acti" if acti else "normal", None, "sag", gt=False, ileri=False, h=310, kesici_acik=acti)
    c.yazi(500, 150, f"Olağan yükte ısıl düzey %{fnum(b['th0'], 0)}", "#334155", 12)
    c.yazi(500, 172, f"Aşırı yükte en yüksek düzey %{fnum(min(b['th_max'], 999), 0)}", "#b91c1c" if b["th_max"] >= 100 else "#1a4d8f", 12.5, kalin=True)
    c.yazi(500, 192, (f"Açma {fnum(b['acma'] / 60, 1)} dk sonra" if acti else f"Açma yok (sıcaktan {fnum(t_sicak, 1) + ' dk' if t_sicak else 'açmaz'})"), "#b91c1c" if acti else "#15803d", 12, kalin=True)
    c.yazi(500, 212, f"Aynı aşırı yük soğuk makinede: " + (f"{fnum(t_soguk, 1)} dk" if t_soguk else "açmaz"), "#334155", 11.5)
    c.yazi(500, 232, f"Bir yol alma düzeye %{fnum(yol_artis, 0)} ekler", "#334155", 11.5)
    c.yazi(500, 258, ("Yeniden yol verme: " + ("ısıl pay yeterli" if yol_ok else "ısıl pay yetmiyor — yol almada açar")) if p.get("yol", True) else "Yeniden yol verilmiyor", "#15803d" if yol_ok else "#b91c1c", 12, kalin=True)

    ozet = [
        K("Termik koruma", "AÇTI" if acti else "açmadı", "warn" if acti else "ok", (f"{fnum(b['acma'] / 60, 1)} dk sonra" if acti else "aşırı yük süresi yetmedi")),
        K("En yüksek ısıl düzey", f"%{fnum(min(b['th_max'], 999), 0)}", "bad" if b["th_max"] >= 100 else "warn" if b["th_max"] >= num(p, "alarm", 90) else "ok", f"olağan yükte %{fnum(b['th0'], 0)}"),
        K("Sıcak / soğuk açma süresi", f"{fnum(t_sicak, 1) if t_sicak else '∞'} / {fnum(t_soguk, 1) if t_soguk else '∞'} dk", "info", f"{fnum(i1, 2)} ×In aşırı yükte"),
        K("Yeniden yol verme", "olur" if yol_ok else "açar", "ok" if yol_ok else "bad", f"yol alma düzeye %{fnum(yol_artis, 0)} ekler" + (f"; o anda %{fnum(b['th_yol'], 0)}" if b["th_yol"] is not None else "")),
        K("Negatif bileşenin katkısı", f"+%{fnum(fazla, 0)}", "ok" if fazla < 5 else "warn", f"I2 = %{fnum(i2 * 100, 0)} In, K = {fnum(kn, 2)} → eşdeğer akım {fnum(ieq(1.0, i2, kn), 3)} ×In"),
    ]
    kontroller = [
        C("Alarm açmadan önce geliyor mu?", (f"alarm {fnum(b['alarm'] / 60, 1)} dk" if b["alarm"] is not None else "alarm yok") + (f"; açma {fnum(b['acma'] / 60, 1)} dk" if acti else "; açma yok"), "alarm < açma: işletmeciye yükü azaltacak süre kalmalı",
          (b["alarm"] is not None and b["alarm"] < b["acma"]) if acti else None, "Alarm düzeyi açma düzeyinin yüzdesidir — " + P3U + " böl. 5.16", "resmi"),
        C("Sıcak makine daha çabuk açıyor mu?", f"sıcak {fnum(t_sicak, 1) if t_sicak else '∞'} dk · soğuk {fnum(t_soguk, 1) if t_soguk else '∞'} dk", "t = τ·ln[(I² − Ip²)/(I² − a²)] — önceki yük Ip süreyi kısaltır", None,
          "Açma süresi önceki yük akımına bağlıdır: a = k·In, Ip arıza öncesi akım — " + P3U + " böl. 5.16", "resmi"),
        C("Durduktan sonra yeniden yol verilebilir mi?", (f"yol almadan önce %{fnum(b['th_yol'], 0)} + yol alma %{fnum(yol_artis, 0)}" if b["th_yol"] is not None else "yeniden yol verilmiyor"), "toplam < %100", yol_ok if b["th_yol"] is not None else None,
          "Akım 0,3·In'in altındayken model, Cτ katsayısıyla uzatılmış zaman sabitiyle soğur: duran motor yavaş soğur — " + P3U + " böl. 5.16", "resmi"),
        C("Negatif bileşen ısıl modele katılıyor mu?", f"Ieq² = I² + K·I2² → anma yükünde ısınma +%{fnum(fazla, 0)}", "K = 0 · 2,25 · 4,5 · 9", None,
          "Negatif bileşen rotorda iki kat frekanslı akım dolaştırır; ısıl modele K katsayısıyla eklenir — " + SEPAM + " (ısıl aşırı yük)", "resmi"),
    ]
    girdiler = [
        G("Isınma zaman sabiti", f"{fnum(tau, 0)} dk", "Motor / trafo veri sayfası; yoksa ısınma deneyi", "Düzeyin ne hızla yükseldiğini belirler: yanlışsa koruma ya erken açar ya geç", "τ"),
        G("Sürekli dayanılan en büyük akım", f"{fnum(k, 2)} ×In", "Veri sayfası (servis katsayısı); ortam sıcaklığı", "Bu akımın üstünde düzey sonunda %100'e ulaşır", "k"),
        G("Dururken soğuma zaman sabiti", f"{fnum(num(p, 'ctau', 3), 1)} × τ", "Motor veri sayfası", "Kendinden fanlı motor dururken çok yavaş soğur: peş peşe yol vermede belirleyici", "Cτ"),
        G("Sıcak ve soğuk dayanma eğrileri", "kilitli rotor süresi (sıcak / soğuk)", "Motor üreticisi", "Röle eğrisi bu eğrilerin altında kalmalı", "τ ve k bunlara göre doğrulanır"),
    ]
    adimlar = [
        A("Olağan yükte ısıl düzey", "θ = (I / (k·In))² · 100", f"({fnum(i0, 2)} / {fnum(k, 2)})²", f"%{fnum(b['th0'], 0)}", P3U + " böl. 5.16", "resmi", ["Sürekli dayanılan en büyük akım"]),
        A("Sıcak makinede açma süresi", "t = τ·ln[(I² − Ip²)/(I² − k²)]", f"{fnum(tau, 0)} × ln[({fnum(i1, 2)}² − {fnum(i0, 2)}²)/({fnum(i1, 2)}² − {fnum(k, 2)}²)]", f"{fnum(t_sicak, 1)} dk" if t_sicak else "açmaz", P3U + " böl. 5.16", "resmi", ["Isınma zaman sabiti"], "tau"),
        A("Soğuk makinede açma süresi", "aynı bağıntı, Ip = 0", "—", f"{fnum(t_soguk, 1)} dk" if t_soguk else "açmaz", P3U + " böl. 5.16", "resmi"),
        A("Bir yol almanın payı", "Δθ = (Ia/k)² · 100 · (1 − e^(−ts/τ))", f"({fnum(ia, 1)}/{fnum(k, 2)})² × (1 − e^(−{fnum(ts_, 0)}/{fnum(tau * 60, 0)}))", f"%{fnum(yol_artis, 0)}", "birinci dereceden ısıl model", "hesap"),
        A("Eşdeğer akım (negatif bileşenle)", "Ieq = √(I² + K·I2²)", f"√(1 + {fnum(kn, 2)} × {fnum(i2, 2)}²)", f"{fnum(ieq(1.0, i2, kn), 3)} ×In", SEPAM + " (ısıl aşırı yük)", "resmi", [], "K"),
    ]
    ayarlar = [
        S("T> › En büyük sürekli akım", f"{fnum(k, 2)} ×In", "0,10 … 2,40 ×In", "Makinenin sürekli dayandığı akım", P3U + " Çizelge 60"),
        S("T> › Zaman sabiti tau", f"{fnum(tau, 0)} dk", "2 … 180 dk", "Makinenin ısınma zaman sabiti", P3U + " Çizelge 60"),
        S("T> › Soğuma zaman sabiti katsayısı", f"{fnum(num(p, 'ctau', 3), 1)} × tau", "1,0 … 10,0", "Dururken soğumanın yavaşlığı", P3U + " Çizelge 60"),
        S("T> › Alarm", f"%{fnum(num(p, 'alarm', 90), 0)}", "%60 … %99", "Açmadan önce uyarı", P3U + " Çizelge 60"),
        S("Sepam › negatif bileşen katsayısı K", fnum(kn, 2), "0 · 2,25 · 4,5 · 9", "Dengesiz beslemede rotorun fazladan ısınması", SEPAM + " (ısıl aşırı yük)"),
    ]
    test = [
        T("Soğuk açma süresi", f"Isıl düzey sıfırlandıktan sonra {fnum(i1, 2)} ×In uygula", f"Açma {fnum(t_soguk, 1) if t_soguk else '—'} dk sonra", "±%5 ya da 1 s"),
        T("Sıcak açma süresi", f"Önce {fnum(i0, 2)} ×In ile düzey oturana kadar bekle, sonra {fnum(i1, 2)} ×In", f"Açma {fnum(t_sicak, 1) if t_sicak else '—'} dk sonra", "önceki yük süreyi kısaltır"),
        T("Soğuma", "Açmadan sonra akımı kes, düzeyi izle", f"Düzey {fnum(tau * num(p, 'ctau', 3), 0)} dk zaman sabitiyle iner", "Cτ × τ"),
    ]
    g1 = {"baslik": "Yük çevrimi boyunca ısıl düzey", "x_ad": "Zaman (dk) — aşırı yük t = 0'da başlar", "y_ad": "Isıl düzey (%) · akım (× 20 %)", "ymin": 0,
          "seriler": [{"ad": "ısıl düzey", "renk": "#dc2626", "pts": [[round(t, 2), round(min(v, 160), 2)] for t, v in zip(b["t"], b["th"])]},
                      {"ad": "akım × 20", "renk": "#94a3b8", "kesik": True, "pts": [[round(t, 2), round(min(v * 20, 160), 2)] for t, v in zip(b["t"], b["i"])]}],
          "yatay": [{"y": 100, "etiket": "açma %100", "renk": "#b91c1c"}, {"y": num(p, "alarm", 90), "etiket": "alarm", "renk": "#b45309"}],
          "isaretler": ([{"x": round(b["acma"] / 60, 2), "etiket": "açma"}] if acti else []) + ([{"x": round(b["yol_basla"] / 60, 2), "etiket": "yol verme"}] if b["yol_basla"] is not None else [])}
    akimlar = [1.1, 1.15, 1.2, 1.3, 1.5, 1.75, 2, 2.5, 3, 4, 5, 6, 8]
    g2 = {"baslik": "Açma eğrileri: soğuk ve sıcak başlangıç", "x_ad": "Akım (×In)", "y_ad": "Açma süresi (dk)", "logx": True, "logy": True,
          "seriler": [{"ad": "soğuk", "renk": "#1a4d8f", "pts": [[i, round(t_acma(i, 0.0, k, tau), 4)] for i in akimlar if t_acma(i, 0.0, k, tau)]},
                      {"ad": f"sıcak (önceki yük {fnum(i0, 2)} ×In)", "renk": "#dc2626", "pts": [[i, round(t_acma(i, i0, k, tau), 4)] for i in akimlar if t_acma(i, i0, k, tau)]}],
          "isaretler": [{"x": i1, "etiket": "aşırı yük"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["49t", "46_negatif"], "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Bir sargının ısınması akımın karesiyle orantılıdır ama anında olmaz: bakırın ve demirin ısı sığası vardır. Sıcaklık, akım değiştiğinde yeni değerine üstel bir eğriyle, makinenin zaman sabitiyle yaklaşır.",
            f"Röle sıcaklığı ölçmez, hesaplar. Akımın karesinden bir «ısıl düzey» türetir: en büyük sürekli akımda ({fnum(k, 2)} ×In) düzey %100'e oturur. Olağan yükte düzey %{fnum(b['th0'], 0)}'tir — makine zaten ılıktır.",
            f"Aşırı yük başlayınca düzey yükselmeye başlar. Açmaya kalan süre, başlangıç düzeyine bağlıdır: soğuk makine {fnum(t_soguk, 1) if t_soguk else '∞'} dk, ılık makine {fnum(t_sicak, 1) if t_sicak else '∞'} dk dayanır.",
            "Makine durunca akım sıfıra iner, düzey inmeye başlar; ama kendinden fanlı motor dönmediği için soğuması yavaştır. Röle bunu daha uzun bir soğuma zaman sabitiyle modeller.",
            f"Yol alma akımı kısa sürer ama büyüktür: her yol alma düzeye %{fnum(yol_artis, 0)} ekler. Makine henüz soğumadan yeniden yol verilirse düzey yol alma sırasında %100'ü geçer. Saat başına yol alma sayısının sınırlanmasının nedeni budur.",
            "Dengesiz gerilimde motor negatif bileşen akımı çeker. Bu bileşenin döner alanı rotora göre iki kat frekansla döner; rotor çubuklarında akım yüzeye sıkışır ve direnç birkaç katına çıkar. Küçük bir negatif bileşen bile rotoru belirgin ısıtır: ısıl modele bir katsayıyla eklenir.",
        ],
        "dersler": [
            "Termik korumanın belleği vardır: aynı aşırı yükte ılık makine soğuk makineden çok daha çabuk açar.",
            "Zaman sabiti yanlış girilirse koruma ya gereksiz açar ya makineyi yakar; değer veri sayfasından alınır.",
            "Duran motor yavaş soğur. Açmadan hemen sonra yeniden yol vermek, ısıl payı olmayan makineyi zorlamaktır.",
            "Gerilim dengesizliği motor için gizli aşırı yüktür: faz akımları olağan görünürken rotor ısınır.",
        ],
        "tablolar": [{"baslik": "Negatif bileşenin ısınmaya katkısı (anma yükünde)", "cols": ["Negatif bileşen akımı", "K = 2,25", "K = 4,5", "K = 9"],
                      "rows": [[f"%{v}", *[f"+%{fnum((ieq(1.0, v / 100, kk) ** 2 - 1) * 100, 0)}" for kk in (2.25, 4.5, 9)]] for v in (5, 10, 15, 20, 30)],
                      "not": "Ieq² = I² + K·I2². Katsayı makinenin yapısına bağlıdır; üretici vermediyse kılavuzdaki bağıntıyla hesaplanır."}],
    }
