"""Soğuk yük alma ve kapama darbesi (demeraj) tespiti — Easergy P3 «Soğuk yük alma» ekranı.

Dayanak: P3U/en M/J006 böl. 6.3 (soğuk yük: üç faz akımı da boşta eşiğinin altındayken en az biri 80 ms içinde başlatma eşiğini aşarsa işaret,
«en uzun süre» boyunca ya da akım başlatmanın altına inene kadar etkin; kapama darbesi: aynı koşul + 2. harmonik oranı; işaret ayar grubu
değiştirmek ya da kademe kilitlemek için kullanılır; 2. harmonik ayarı 0 ise soğuk yük gibi davranır), Çizelge 100 (aralıklar)."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, P3U, S, T, at_ctl, ctl, fa, fnum, num, opt, tek_hat

ID = "soguk_yuk"
BASLIK = "Soğuk yük · kapama darbesi"
IKON = "❄"
GIRIS = ("Uzun bir kesintiden sonra fider enerjilenince yük normalden büyük akım çeker (soğuk yük); trafolar demeraj akımı çeker. İkisi de arıza değildir "
         "ama aşırı akım kademesini başlatabilir. Röle bu olayı «akım yoktu, birden geldi» diye tanır ve geçici olarak daha kaba bir ayara geçer.")

OLAY = {"soguk": "Soğuk yük (termostatlı yüklerin hepsi birden devrede)", "demeraj": "Trafo enerjilendirme (kapama darbesi)", "ariza": "Arızalı hatta kapama", "artis": "Yük artışı (fider zaten enerjiliydi)"}
EYLEM = {"grup": "2. ayar grubuna geç (I> iki katına çıkar)", "kilit": "I> kademesini kilitle", "yok": "Hiçbir şey yapma"}

KONTROLLER = at_ctl(ct_p=150, gt=False)[1:] + [
    ctl("olay", "Olay", "sec", "soguk", secenek=opt(*OLAY.items())),
    ctl("tepe", "Olayın ilk akımı", "sayi", 2.5, min=0.5, max=12, adim=0.1, birim="×In"),
    ctl("tau", "Akımın sönme zaman sabiti", "sayi", 3.0, min=0.05, max=30, adim=0.05, birim="s", yardim="Demerajda 0,1–0,5 s; soğuk yükte saniyeler – dakikalar"),
    ctl("bos", "Röle › Boşta akım", "sayi", 0.05, min=0.01, max=0.50, adim=0.01, birim="×In"),
    ctl("bas", "Röle › Başlatma akımı", "sayi", 1.10, min=0.30, max=10.0, adim=0.05, birim="×In"),
    ctl("tmax", "Röle › Max zaman", "sayi", 5.0, min=0.01, max=300, adim=0.05, birim="s"),
    ctl("h2", "Röle › Kapama darbesi 2. harm. başlatma", "sayi", 10, min=0, max=99, adim=1, birim="%"),
    ctl("eylem", "İşaretin kullanımı", "sec", "grup", secenek=opt(*EYLEM.items())),
    ctl("i1", "Aşırı akım › I> (1. grup)", "sayi", 1.20, min=0.2, max=5, adim=0.05, birim="×In"),
    ctl("t1", "Aşırı akım › tI> (sabit zamanlı)", "sayi", 0.50, min=0.05, max=5, adim=0.05, birim="s"),
    ctl("i2", "Aşırı akım › I>> (kilitsiz ani kademe)", "sayi", 8.0, min=1, max=40, adim=0.5, birim="×In"),
]


def benzet(p: dict) -> dict:
    olay = p.get("olay") if p.get("olay") in OLAY else "soguk"
    tepe, tau = num(p, "tepe", 2.5), num(p, "tau", 3.0)
    bos, bas, tmax, h2a = num(p, "bos", 0.05), num(p, "bas", 1.1), num(p, "tmax", 5.0), num(p, "h2", 10) / 100
    once = 0.6 if olay == "artis" else 0.0
    son = {"soguk": 0.8, "demeraj": 0.05, "ariza": tepe, "artis": tepe}[olay]
    h2_olay = 0.45 if olay == "demeraj" else 0.02
    T0, dt, N = 0.2, 0.01, 620
    akim = lambda t: once if t < T0 else son + (tepe - son) * math.exp(-(t - T0) / tau)       # noqa: E731
    t_s = [n * dt for n in range(N)]; i_s = [akim(t) for t in t_s]
    # soğuk yük / kapama darbesi işareti
    kosul = once < bos and tepe >= bas                              # boştaydı ve 80 ms içinde eşiği aştı (basamak)
    darbe = kosul and (h2a == 0 or h2_olay >= h2a)
    t_bit = T0
    if kosul:
        for t, i in zip(t_s, i_s):
            if t >= T0 and (i < bas or t - T0 >= tmax):
                break
            t_bit = t
    eylem = p.get("eylem") if p.get("eylem") in EYLEM else "grup"
    i1, t1, i2 = num(p, "i1", 1.2), num(p, "t1", 0.5), num(p, "i2", 8.0)
    sayac, t_acma, esik = 0.0, None, []
    for t, i in zip(t_s, i_s):
        etkin = kosul and T0 <= t <= t_bit
        e = (2 * i1 if eylem == "grup" else math.inf if eylem == "kilit" else i1) if etkin else i1
        esik.append(e if e < math.inf else None)
        if i >= i2 and t >= T0 and t_acma is None:
            t_acma = t + 0.03
        sayac = sayac + dt if i >= e else 0.0
        if sayac >= t1 and t_acma is None:
            t_acma = t
    return {"olay": olay, "t": t_s, "i": i_s, "esik": esik, "kosul": kosul, "darbe": darbe, "t_bit": t_bit, "T0": T0, "t_acma": t_acma, "h2_olay": h2_olay, "once": once, "eylem": eylem}


def run(p: dict) -> dict:
    m = benzet(p); ct_p = num(p, "ct_p", 150)
    beklenen = m["olay"] == "ariza" or (m["olay"] == "artis" and num(p, "tepe", 2.5) >= num(p, "i1", 1.2))      # kalıcı aşırı akım: açması doğrudur
    acti = m["t_acma"] is not None
    sure = m["t_bit"] - m["T0"]
    c = tek_hat(("Besleme", "fider enerjileniyor"), ("Fider", OLAY[m["olay"]].split(" (")[0]), ("Soğuk yük + 50/51", ("AÇTI " + fnum(m["t_acma"] - m["T0"], 2) + " s") if acti else "açmadı"),
                "acti" if acti else "normal", 620 if m["olay"] == "ariza" else None, "sag", gt=False, ileri=False, at_ad=f"AT {ct_p:g}/1", kesici_acik=acti)
    c.yazi(500, 190, "Soğuk yük işareti: " + (f"ETKİN, {fnum(sure, 2)} s" if m["kosul"] else "yok (tanıma koşulu oluşmadı)"), "#15803d" if m["kosul"] else "#64748b", 11.5, kalin=True)
    c.yazi(500, 208, "Kapama darbesi işareti: " + ("ETKİN" if m["darbe"] else "yok") + f" (2. harmonik %{fnum(m['h2_olay'] * 100, 0)}, ayar %{fnum(num(p, 'h2', 10), 0)})", "#334155", 11)
    c.yazi(500, 226, "İşaretin etkisi: " + EYLEM[m["eylem"]], "#334155", 11)
    ozet = [
        K("Aşırı akım kademesi", "AÇTI" if acti else "AÇMADI", "ok" if acti == beklenen else "bad", ("doğru" if acti == beklenen else "YANLIŞ") + " — " + ("arıza ya da kalıcı aşırı akım var" if beklenen else "arıza yok")),
        K("Soğuk yük işareti", "etkin" if m["kosul"] else "yok", "ok" if m["kosul"] else "info", f"{fnum(sure, 2)} s sürdü" if m["kosul"] else "koşul oluşmadı"),
        K("Kapama darbesi işareti", "etkin" if m["darbe"] else "yok", "ok" if m["darbe"] else "info", f"2. harmonik %{fnum(m['h2_olay'] * 100, 0)}"),
        K("İlk akım", f"{fnum(num(p, 'tepe', 2.5), 1)} ×In", "info", fa(num(p, "tepe", 2.5) * ct_p, 0)),
        K("Akımın eşiğin altına inmesi", f"{fnum(num(p, 'tau', 3.0) * math.log(max((num(p, 'tepe', 2.5) - 0.8) / max(num(p, 'i1', 1.2) - 0.8, 1e-6), 1.0)), 1)} s" if m["olay"] == "soguk" else "—", "info", "I> (1. grup) altına"),
    ]
    kontroller = [
        C("Aşırı akım kademesi doğru davranıyor mu?", "açtı" if acti else "açmadı", "arızada ve kalıcı aşırı akımda açar; soğuk yükte ve demerajda açmaz", acti == beklenen, "Soğuk yük işareti ayar grubunu değiştirir ya da kademeyi kilitler — " + P3U + " böl. 6.3", "resmi"),
        C("Olay tanındı mı?", "evet" if m["kosul"] else "hayır", "önceki akım < boşta akım VE akım 80 ms içinde başlatmayı aşar", m["kosul"] or m["olay"] == "artis",
          P3U + " böl. 6.3 (Şekil 136: akım boşta eşiğinin altına inmemişse etkinleşmez)", "resmi"),
        C("«Max zaman» olayın süresini kapsıyor mu?", f"Max zaman {fnum(num(p, 'tmax', 5.0), 2)} s; işaret {fnum(sure, 2)} s sürdü", "akım I>'nin altına inene kadar etkin kalmalı", (not m["kosul"]) or acti == beklenen,
          "İşaret, «Max zaman» dolana ya da akım «Başlatma akımı»nın altına inene kadar etkindir — " + P3U + " böl. 6.3", "resmi"),
        C("Başlatma akımı I>'nin altında mı?", f"{fnum(num(p, 'bas', 1.1), 2)} ×In; I> = {fnum(num(p, 'i1', 1.2), 2)} ×In", "başlatma ≤ I>", num(p, "bas", 1.1) <= num(p, "i1", 1.2), "İşaret, korunacak kademe başlamadan önce etkin olmalı (öğretim amaçlı öneri)", "ikincil"),
        C("Ani kademe kilitsiz ve demerajın üstünde mi?", f"I>> = {fnum(num(p, 'i2', 8.0), 1)} ×In; ilk akım {fnum(num(p, 'tepe', 2.5), 1)} ×In", "I>> ≥ 1,2 × beklenen demeraj", num(p, "i2", 8.0) >= 1.2 * num(p, "tepe", 2.5) or m["olay"] == "ariza",
          "Kilitsiz ani kademe beklenen demeraj akımının %20 üstüne ayarlanır; böylece enerjilendirmedeki kısa devrede hızlı açma korunur — " + P3U + " böl. 6.3", "resmi"),
    ]
    girdiler = [
        G("Fiderin yük türü ve kesinti sonrası davranışı", "ilk akım " + fnum(num(p, "tepe", 2.5), 1) + " ×In, " + fnum(num(p, "tau", 3.0), 1) + " s'de söner", "İşletme kayıtları (önceki enerjilendirmelerin kayıtları)", "«Max zaman» ve 2. grubun eşiği bundan çıkar", "Max zaman ≥ akımın I> altına inme süresi"),
        G("Fiderdeki trafoların toplam gücü", "demeraj 8–12 × ΣIn, 0,1–0,5 s", "Tek hat şeması", "Kapama darbesinin büyüklüğü; 2. harmonik oranı", "I>> ≥ 1,2 × demeraj; 2. harmonik ayarı"),
        G("Normal işletmede en küçük akım", "boşta akım eşiğinin üstünde kalmalı", "Sayaç / röle kayıtları", "Fider enerjiliyken akım «boşta» eşiğinin altına düşerse her yük artışı soğuk yük sanılır", "Boşta akım < en küçük işletme akımı"),
        G("Korunan aşırı akım kademesinin ayarı", f"I> {fnum(num(p, 'i1', 1.2), 2)} ×In / {fnum(num(p, 't1', 0.5), 2)} s", "Ayar föyü", "İşaret bu kademeyi kabalaştırır ya da kilitler", "2. ayar grubu / kilit matrisi"),
    ]
    adimlar = [
        A("Boşta akım", "en küçük işletme akımının altı", "fider enerjisizken akım sıfırdır; ölçme gürültüsünün üstü", f"{fnum(num(p, 'bos', 0.05), 2)} ×In", P3U + " Çizelge 100 (0,01 … 0,50 ×In)", "resmi", ["Normal işletmede en küçük akım"], "Boşta akım"),
        A("Başlatma akımı", "≤ korunan kademenin eşiği", f"I> = {fnum(num(p, 'i1', 1.2), 2)} ×In", f"{fnum(min(num(p, 'i1', 1.2), 1.1), 2)} ×In", "işaret kademe başlamadan etkin olmalı", "ikincil", ["Korunan aşırı akım kademesinin ayarı"], "Başlatma akımı"),
        A("Max zaman", "≥ akımın I> altına inme süresi", f"τ · ln[(I ilk − I son) / (I> − I son)] = {fnum(num(p, 'tau', 3.0), 1)} × ln[({fnum(num(p, 'tepe', 2.5), 1)} − 0,8) / ({fnum(num(p, 'i1', 1.2), 2)} − 0,8)]",
          f"{fnum(num(p, 'tau', 3.0) * math.log(max((num(p, 'tepe', 2.5) - 0.8) / max(num(p, 'i1', 1.2) - 0.8, 1e-6), 1.0)), 1)} s", "üstel sönme kabulü", "ikincil", ["Fiderin yük türü ve kesinti sonrası davranışı"], "Max zaman"),
        A("2. harmonik başlatma", "demerajın 2. harmonik oranının altı", "tipik demeraj %15–60", "%10–20", P3U + " Çizelge 100 (0 … %99; 0 ise soğuk yük gibi davranır)", "ikincil", ["Fiderdeki trafoların toplam gücü"], "Kapama darbesi 2. harm. başlatma"),
    ]
    ayarlar = [
        S("Soğuk yük alma — Etkin", "Açık", "—", "İşaret çıkış ve kilit matrisinde kullanılabilir olur"),
        S("Akım giriş", "IL", "IL / I'L", "Hangi akım girişinin izleneceği", P3U + " Çizelge 100"),
        S("Boşta akım", f"{fnum(num(p, 'bos', 0.05), 2)} ×In", "0,01 … 0,50 ×In; ekrandaki örnek 0,01", "Bunun altı «fider enerjisiz» sayılır", P3U + " Çizelge 100"),
        S("Başlatma akımı", f"{fnum(num(p, 'bas', 1.1), 2)} ×In", "0,30 … 10,00 ×In; ekrandaki örnek 1,10", "Akım bunu 80 ms içinde aşarsa olay tanınır; altına inince işaret düşer", P3U + " Çizelge 100"),
        S("Max zaman", f"{fnum(num(p, 'tmax', 5.0), 2)} s", "0,01 … 300 s; ekrandaki örnek 0,20 s", "İşaretin en uzun süresi. 0,20 s demeraja yeter, soğuk yüke yetmez", P3U + " Çizelge 100"),
        S("Kapama darbesi › 2. harm. başlatma", f"%{fnum(num(p, 'h2', 10), 0)}", "0 … %99; ekrandaki örnek %10", "Demeraj işareti için ek koşul", P3U + " Çizelge 100"),
        S("Çıkış matrisi › Soğuk yük olayı → sanal çıkış → ayar grubu 2", EYLEM[m["eylem"]], "—", "İşaret tek başına bir şey yapmaz; matriste bir eyleme bağlanmalıdır", P3U + " böl. 6.3"),
    ]
    test = [
        T("Tanıma", f"Akım 0 iken {fnum(1.2 * num(p, 'bas', 1.1), 2)} ×In basamak", "«Soğuk yük olayı» işareti gelir; «Max zaman» sonunda düşer", "süre ±%1 ya da ±30 ms dolayı"),
        T("Boşta koşulu", f"Önce {fnum(2 * num(p, 'bos', 0.05), 2)} ×In (boşta eşiğinin üstü), sonra aynı basamak", "İşaret gelmez", "—"),
        T("Yavaş artış", "Akımı sıfırdan başlatma eşiğine 80 ms'den uzun sürede çıkarın", "İşaret gelmez", P3U + " Şekil 136"),
        T("Kapama darbesi", f"Aynı basamak + 100 Hz bileşen %{fnum(num(p, 'h2', 10) + 5, 0)}", "«Kapama darbe akımı» işareti gelir; 100 Hz bileşen ayarın altındaysa bir periyot sonra düşer", "—"),
        T("Eylem", "Soğuk yük işareti etkinken I> (1. grup) üstünde, 2. grup altında akım", "Açma yok; işaret düşünce 1. grup geri gelir ve süre sonunda açar", "—"),
    ]
    g = {"baslik": "Enerjilendirmeden sonra akım ve aşırı akım eşiği", "x_ad": "Zaman (s)", "y_ad": "Akım (×In)", "zaman": True, "ymin": 0,
         "seriler": [{"ad": "akım", "renk": "#dc2626", "pts": [[round(t, 2), round(i, 3)] for t, i in zip(m["t"], m["i"])]},
                     {"ad": "etkin I> eşiği", "renk": "#1a4d8f", "pts": [[round(t, 2), e if e is not None else num(p, "tepe", 2.5) * 1.3] for t, e in zip(m["t"], m["esik"])]}],
         "yatay": [{"y": num(p, "bas", 1.1), "etiket": "soğuk yük başlatma", "renk": "#15803d"}, {"y": num(p, "bos", 0.05), "etiket": "boşta", "renk": "#94a3b8"}],
         "isaretler": ([{"x": m["t_bit"], "etiket": "işaret düştü"}] if m["kosul"] else []) + ([{"x": m["t_acma"], "etiket": "AÇMA"}] if acti else [])}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["soguk_yuk"],
        "sahne": c.sahne(), "grafikler": [g],
        "anlatim": [
            "Röle üç faz akımını izler. Üçü de «boşta akım»ın altındaysa fider enerjisizdir.",
            "Akım bu durumdan 80 ms içinde «başlatma akımı»nın üstüne çıkarsa röle bunu enerjilendirme olarak tanır ve «soğuk yük» işaretini verir.",
            "İşaret, akım başlatmanın altına inene kadar ya da «Max zaman» dolana kadar etkin kalır. Bu sürede aşırı akım kademesi daha kaba bir ayar grubuna geçirilir ya da kilitlenir.",
            "Akımda yeterli 2. harmonik varsa bu bir trafo demerajıdır: «kapama darbesi» işareti de gelir. Demeraj kısa sürer (onda birkaç saniye), soğuk yük uzun (saniyeler, dakikalar).",
            "Arızalı hatta kapamada da akım sıfırdan fırlar ve işaret gelir. Bu yüzden kilitsiz bir ani kademe (I>>) bırakılır: arıza akımı onu aşar ve hemen açar.",
            "Fider zaten enerjiliyken gelen yük artışı soğuk yük değildir: akım boşta eşiğinin altına inmediği için işaret gelmez ve kademe normal ayarıyla çalışır.",
        ],
        "dersler": [
            "İşaret kendi başına korumayı değiştirmez; çıkış / kilit matrisinde bir eyleme (ayar grubu, kilit) bağlanmalıdır.",
            "«Max zaman» olayın süresinden kısaysa işaret erken düşer ve kademe soğuk yükte açar. Ekrandaki 0,20 s demeraj içindir.",
            "2. harmonik ayarını 0 yaparsanız kapama darbesi işareti soğuk yük işaretiyle aynı davranır.",
            "Her zaman kilitsiz bir ani kademe bırakın: enerjilendirmedeki gerçek kısa devre gecikmesin.",
        ],
        "tablolar": [{"baslik": "Dört olayda ne olur (bu ayarlarla)", "cols": ["Olay", "Soğuk yük işareti", "Kapama darbesi", "Aşırı akım", "Doğru mu"], "rows": [
            (lambda mm, o: [OLAY[o].split(" (")[0], f"{fnum(mm['t_bit'] - mm['T0'], 2)} s" if mm["kosul"] else "yok", "var" if mm["darbe"] else "yok", "AÇTI" if mm["t_acma"] is not None else "açmadı", "✓" if (mm["t_acma"] is not None) == (o == "ariza" or (o == "artis" and ek["tepe"] >= num(p, "i1", 1.2))) else "✗"])(benzet({**p, "olay": o, **ek}), o)
            for o, ek in (("soguk", {}), ("demeraj", {"tepe": 6.0, "tau": 0.15}), ("ariza", {"tepe": 10.0}), ("artis", {"tepe": 1.5}))],
            "not": "Demeraj satırı 6 ×In / 0,15 s, arıza satırı 10 ×In, yük artışı 1,5 ×In ile hesaplanmıştır."}],
    }
