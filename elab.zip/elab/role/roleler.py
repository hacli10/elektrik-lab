"""Röle marka / modeline göre yönlü koruma tanımları: aynı fiziksel açma bölgesi her rölede başka bir sayıyla girilir.

Fizik değişmez: arızada akım gerilimden arıza yolunun empedans açısı φ kadar geri kalır; açma bölgesinin merkezi θc = −φ (akımın faz gerilimine göre açısı).
Değişen üç şeydir: (1) rölenin kutuplama (referans) gerilimi — pozitif bileşen U1, arızalı fazın kendi gerilimi ya da ona dik sağlam faz arası gerilim;
(2) işaret kuralı — geride kalan akım artı mı eksi mi; (3) açma bölgesinin genişliği ve gerilim hafızası. Buradaki her satır ilgili kılavuzdan okunmuştur;
kılavuzu yerel arşivde olmayan röleler «ikincil» ya da «dogrulanacak» işaretlidir ve bölge genişliği için varsayım yapıldığı belirtilir.

Okunan kılavuzlar: Schneider Easergy P3U (P3U/en M/J006 böl. 5.30–5.31), ABB 615 serisi teknik kılavuzu (1MRS756887 Q böl. 4.1.2, Çizelge 234, 238–240, 245–246),
Schneider PowerLogic P5 (P5/EN M/02-503A, ANSI 67), GE F60 (1601-0093-AK1, böl. 5 «Phase directional overcurrent»), GE MiCOM P14D (P14DEd2-TM-EN-11.2 böl. 6),
Schneider Easergy Sepam series 60 (SEPED310017EN, ANSI 67). Siemens 7SR11/12 ve Thytronic NVA100X için kaynak URRA profil notlarıdır."""
from __future__ import annotations

from .ortak import P3U, P5

ABB = "ABB 615 serisi teknik kılavuzu (1MRS756887 Q)"
F60 = "GE F60 kılavuzu (1601-0093-AK1, sürüm 8.1x)"
P14D = "GE MiCOM P14D teknik kılavuzu (P14DEd2-TM-EN-11.2)"
SEPAM = "Schneider Easergy Sepam series 60 kılavuzu (SEPED310017EN)"
URRA_P = "URRA röle profili notu (kılavuz yerel arşivde yok)"

# tur: "u1" (referans faz / pozitif bileşen gerilimi; geride = eksi) · "lag" (referans faz gerilimi; geride = artı) · "dik" (referans dik bağlantı gerilimi; ayar = 90° − φ)
ROLE67 = {
    "p3": dict(ad="Schneider Easergy P3U / P3x3x", param="Açı kayması (Angle offset)", tur="u1", formul="−φ", aralik=(-180, 179), yari=88.0,
               kutup="Faz arası ve üç fazlı arızada pozitif bileşen gerilimi U1; faz–nötr arızada sağlam faz arası gerilim (çapraz)",
               bolge="açı kayması ± 88° (sabit)", hafiza="0,2 … 3,2 s (ayarlanır)", hafiza_s=None, min_u="2 V sekonder",
               sonra="«Yön»: kilitli · «Yön + Artçı»: yönsüz çalışır", kaynak=P3U + " böl. 5.30, Çizelge 82", durum="resmi"),
    "abb615": dict(ad="ABB REF615 / REF620 / REG615 (DPHxPDOC)", param="Characteristic angle", tur="lag", formul="+φ", aralik=(-179, 180), yari=80.0,
                   kutup="Seçilir (Pol quantity): Cross pol (varsayılan), Self pol, Pos. seq. volt, Neg. seq. volt — dördünde de açı tanımı aynıdır",
                   bolge="Min / Max forward angle 0 … 90° (varsayılan 80° / 80°)", hafiza="Voltage Mem time 0 … 3000 ms (varsayılan 40 ms)", hafiza_s=None, min_u="Min operate voltage (varsayılan 0,01 ×Un)",
                   sonra="Allow Non Dir = True ise yönsüz çalışır; değilse yön «bilinmiyor»", kaynak=ABB + " böl. 4.1.2, Çizelge 234, 238–240, 245–246 (REF620: aynı işlev bloğu; 620 kılavuzu okunmadı)", durum="resmi"),
    "p5": dict(ad="Schneider PowerLogic P5", param="Characteristic angle (RCA)", tur="dik", formul="90° − φ", aralik=(-95, 95), yari=90.0,
               kutup="Dik bağlantı: IA ↔ VBC, IB ↔ VCA, IC ↔ VAB", bolge="RCA ± 90° (sabit)", hafiza="5 s (sabit)", hafiza_s=5.0, min_u="0,015 pu",
               sonra="5 s sonra kilitli; GT arızasında «VTS blocking»: Non-directional / Blocked", kaynak=P5 + " «Directional phase overcurrent (ANSI 67)»", durum="resmi"),
    "f60": dict(ad="GE Multilin F60 (UR)", param="PHASE DIR 1 ECA", tur="dik", formul="90° − φ", aralik=(0, 359), yari=90.0,
                kutup="Dik bağlantı: IA ↔ VBC; kutuplama gerilimi ECA kadar ileri döndürülür", bolge="kutuplama gerilimi ± 90° (sabit)", hafiza="1 s (sabit)", hafiza_s=1.0, min_u="Voltage cut-off level; akım ≥ %5 In",
                sonra="BLOCK WHEN V MEM EXP: Yes → kilitli, No → açmaya izin verilir", kaynak=F60 + " böl. 5, s.5-264 – 5-265", durum="resmi"),
    "p14d": dict(ad="GE MiCOM P14D (P40 Agile)", param="I>n Char Angle (RCA)", tur="dik", formul="90° − φ", aralik=(-180, 180), yari=90.0,
                 kutup="Dik bağlantı: IA ↔ VBC, IB ↔ VCA, IC ↔ VAB", bolge="I>n Trip Angle ile ayarlanır (en çok 180° = RCA ± 90°)", hafiza="3,2 s (sabit; eşzamanlı kutuplama)", hafiza_s=3.2, min_u="—",
                 sonra="GT denetimi yönlü kademeyi kilitler ya da yönsüze çevirir", kaynak=P14D + " böl. 6 (öneri: düz fider +30°, trafo fideri +45°)", durum="resmi"),
    "sepam": dict(ad="Schneider Easergy Sepam series 60", param="Characteristic angle θ", tur="dik", formul="90° − φ (yalnız 30°, 45°, 60°)", aralik=(30, 60), yari=90.0, secenek=(30, 45, 60),
                  kutup="Dik bağlantı: akıma dik faz arası gerilim (90° bağlantı)", bolge="yarım düzlem (θ ± 90°)", hafiza="gerilim < %1,5 Unp iken yön saklanır (akım eşiğin üstünde kaldıkça)", hafiza_s=float("inf"), min_u="%1,5 Unp",
                  sonra="—", kaynak=SEPAM + " «ANSI 67 — Directional phase overcurrent»", durum="resmi"),
    "7sr": dict(ad="Siemens Reyrolle 7SR11 / 7SR12", param="67 Char Angle", tur="dik", formul="90° − φ", aralik=(-95, 95), yari=90.0,
                kutup="Dik bağlantı (profil notu)", bolge="kılavuzla doğrulanacak (burada ± 90° alındı)", hafiza="kılavuzla doğrulanacak", hafiza_s=None, min_u="—",
                sonra="kılavuzla doğrulanacak", kaynak=URRA_P + ": 7SR11 & 7SR12 Argus Technical Manual (2017/02) — «Char Angle −95° … +95°; dik bağlantı»", durum="ikincil"),
    "nva": dict(ad="Thytronic Pro_N NVA100X", param="Karakteristik açısı", tur="u1", formul="−φ (doğrulanmadı)", aralik=(-180, 180), yari=90.0,
                kutup="kılavuzla doğrulanacak", bolge="kılavuzla doğrulanacak (burada ± 90° alındı)", hafiza="kılavuzla doğrulanacak", hafiza_s=None, min_u="—",
                sonra="kılavuzla doğrulanacak", kaynak=URRA_P + ": ThySetter ekran görüntüleri — «arıza akımının gerilime göre gecikme açısı; kabloda −45°, havai hatta −60 … −70°»", durum="dogrulanacak"),
}
YONSUZ = "Siemens 7SR10, Schneider PowerLogic P1F ve Thytronic NA11'de yönlü faz kademesi yoktur (URRA profillerinde 67 işlevi bulunmuyor)."


def aci67(rol: str, merkez: float) -> dict:
    """Açma bölgesinin merkezi `merkez` (akımın faz gerilimine göre açısı, °; geride ise eksi) için rölede girilecek açı.
    Dönen: {deger, metin, not} — aralık dışı ya da yalnız belirli değerleri kabul eden rölede en yakın geçerli değer ve uyarı."""
    r = ROLE67.get(rol) or ROLE67["p3"]
    phi = -merkez                                             # arıza açısı (geride kalma, artı)
    v = {"u1": merkez, "lag": phi, "dik": 90.0 - phi}[r["tur"]]
    lo, hi = r["aralik"]
    if rol == "f60":
        v = v % 360
    else:
        while v > 180:
            v -= 360
        while v < -180:
            v += 360
    uyari = ""
    if r.get("secenek"):
        yakin = min(r["secenek"], key=lambda s: abs(s - v))
        if abs(yakin - v) > 0.5:
            uyari = f"röle yalnız {', '.join(str(s) + '°' for s in r['secenek'])} kabul eder; en yakını {yakin}° (merkez {yakin - 90:g}° olur)"
        v = float(yakin)
    elif not (lo <= v <= hi):
        uyari = f"ayar aralığı {lo}° … {hi}° dışında"
        v = max(lo, min(hi, v))
    return {"deger": v, "metin": f"{r['param']} = {v:+g}°".replace("+0°", "0°"), "not": uyari, "merkez": {"u1": v, "lag": -v, "dik": v - 90.0}[r["tur"]]}


# ---------------- 67N: artık akımın −Vo'ya göre açısı ----------------
# isaret: +1 → artı açı = akım −Vo'dan İLERİDE (kapasitif) · −1 → artı açı = akım −Vo'dan GERİDE (endüktif)
ROLE67N = {
    "p3": dict(ad="Schneider Easergy P3U / P3x3x", param="Açı kayması", isaret=+1, mod="RezKap (Rez / Kap) · Sektör · Yönsüz", bolge="± 88°",
               oneri="dirençli: Sektör 0° (ya da biraz eksi) · yalıtılmış: Kap · bobinli: Rez", kaynak=P3U + " böl. 5.31, Çizelge 84", durum="resmi"),
    "abb615": dict(ad="ABB REF615 / REF620 (DEFxPDEF)", param="Characteristic angle", isaret=-1, mod="Operation mode: Phase angle · IoSin · IoCos · Phase angle 80 · Phase angle 88", bolge="Min / Max forward angle (ya da sabit 80° / 88°)",
                   oneri="yalıtılmış: IoSin, −90° · bobinli: IoCos, 0° · katı topraklı: Phase angle, +60°", kaynak=ABB + " böl. 4.2 (s.328–332, Çizelge 337)", durum="resmi"),
    "p14d": dict(ad="GE MiCOM P14D", param="IN> / ISEF> Char Angle", isaret=+1, mod="kutuplama −Vres (sıfır bileşen) ya da negatif bileşen", bolge="RCA ± 90°",
                 oneri="dirençli: 0° · katı topraklı dağıtım: −45° · iletim: −60° · yalıtılmış (SEF): +90°", kaynak=P14D + " böl. 6 (toprak yönlü; yalıtılmış ve bobinli şebeke uygulaması)", durum="resmi"),
    "7sr": dict(ad="Siemens Reyrolle 7SR11 / 7SR12", param="67N Char Angle", isaret=-1, mod="—", bolge="kılavuzla doğrulanacak",
                oneri="arıza akımının gerilimden geri kalma açısı doğrudan girilir (faz elemanındaki 90° − φ burada yok)", kaynak=URRA_P + ": 7SR11 & 7SR12 Argus Technical Manual — «67N Char Angle −95° … +95°»", durum="ikincil"),
}
DIGER67N = "GE F60 (NEUTRAL DIR OC1 FWD ECA −90 … 90°, limit açısı 40 … 90°), Schneider P5 ve Sepam için toprak yönlü elemanın işaret kuralı burada doğrulanmadı; röle kılavuzundan bakılmalıdır."


def aci67n(rol: str, aci_p3: float) -> dict:
    """P3 kuralıyla (artı = −Vo'dan ileride) verilen merkez açının seçilen röledeki karşılığı."""
    r = ROLE67N.get(rol) or ROLE67N["p3"]
    v = aci_p3 * r["isaret"]
    return {"deger": v, "metin": f"{r['param']} = {v:+g}°".replace("+0°", "0°").replace("-0°", "0°")}


# ---------------- 50/51 ve 67'nin temel alanları: röle marka / modeline göre adlar ----------------
URRA_PR = "URRA röle profili (kılavuz sayfa atıflı)"
ALAN = {
    "p3": dict(ad="Schneider Easergy P3", basla="Başlatma [×In]", egri="Gecikme eğrisi ailesi · Gecikme tipi", carpan="k", sure="Çalışma süresi", yon="Yön modu (Yön / Yön + Artçı / Yönsüz)",
               kaynak=P3U + " Çizelge 65–67, 82", durum="resmi"),
    "abb615": dict(ad="ABB REF615 / REF620", basla="Start value (0,05 … 5,0 ×In) · Start value Mult", egri="Operating curve type", carpan="Time multiplier (0,05 … 15)", sure="Operate delay time (40 … 200000 ms)",
                   yon="Directional mode (Non-directional / Forward / Reverse) · Allow Non Dir", kaynak=ABB + " PHLPTOC ve DPHLPDOC ayar çizelgeleri (Çizelge 245–246)", durum="resmi"),
    "p5": dict(ad="Schneider PowerLogic P5", basla="Pick-up value (0,05 … 40 pu)", egri="Operating curve", carpan="TMS", sure="Operate delay (0 … 600 s)", yon="Direction mode (Forward / Reverse) · VTS blocking",
               kaynak=P5 + " «Phase overcurrent», «Directional phase overcurrent (ANSI 67)»", durum="resmi"),
    "f60": dict(ad="GE Multilin F60", basla="PHASE TOC1 PICKUP (0,020 … 30,000 pu) · PHASE IOC1 PICKUP", egri="PHASE TOC1 CURVE", carpan="PHASE TOC1 TD MULTIPLIER (0 … 600)", sure="PHASE IOC1 PICKUP DELAY (0 … 600 s)",
                yon="PHASE DIR 1 çıkışı aşırı akım elemanının BLOCK girişine bağlanır · BLOCK WHEN V MEM EXP", kaynak=F60 + " böl. 5; alan adları ve aralıklar: " + URRA_PR, durum="ikincil"),
    "p14d": dict(ad="GE MiCOM P14D", basla="I>1 Current Set", egri="I>1 Function", carpan="I>1 TMS", sure="I>1 Time Delay", yon="I>1 Direction (Non-Directional / Directional Fwd / Directional Rev) · I>1 Char Angle · I>1 Trip Angle",
                 kaynak=P14D + " böl. 6", durum="resmi"),
    "sepam": dict(ad="Schneider Sepam series 60", basla="Is set point (0,1 … 24 In)", egri="Tripping curve", carpan="Time delay T (ters zamanlıda 10·Is'teki süre)", sure="Time delay T", yon="Tripping direction (line / busbar) · Characteristic angle θ",
                  kaynak=SEPAM + " «ANSI 50/51», «ANSI 67»", durum="resmi"),
    "7sr": dict(ad="Siemens Reyrolle 7SR11 / 7SR12", basla="51-n Setting · 50-n Setting", egri="51-n Char", carpan="51-n Time Mult", sure="51-n Delay (DTL) · 50-n Delay", yon="51-n Dir. Control (Non-Dir / Forward / Reverse) · 67 Char Angle",
                kaynak=URRA_PR + ": 7SR11 & 7SR12 Argus Technical Manual (2017/02)", durum="ikincil"),
    "nva": dict(ad="Thytronic Pro_N NVA100X", basla="I> Sabit Zaman / Ters Zaman ayarı", egri="I> Akım Zaman Eğrisi", carpan="(ters zaman ayarı içinde)", sure="I> Sabit-Zaman Açma Gecikmesi", yon="Iy> kademeleri: Karakteristik Açısı",
                kaynak=URRA_PR + ": ThySetter ekran görüntüleri", durum="ikincil"),
}


def alan_cizelgesi() -> dict:
    """Aşırı akım ve yönlü sayfalarında gösterilen «alan adları» çizelgesi."""
    return {"baslik": "Röle marka ve modeline göre alan adları (faz aşırı akım ve yön)", "cols": ["Röle", "Başlatma", "Eğri", "Zaman çarpanı", "Sabit süre", "Yön", "Durum"],
            "rows": [[v["ad"], v["basla"], v["egri"], v["carpan"], v["sure"], v["yon"], v["durum"]] for v in ALAN.values()],
            "not": "Değerler her rölede aynıdır (primer amper, saniye); değişen alanın adı ve birimidir (×In, pu). Kaynaklar: " + "; ".join(sorted({v["kaynak"].split(" «")[0].split(" böl.")[0].split(" Çizelge")[0].split(" PHLPTOC")[0] for v in ALAN.values()})) + "."}
