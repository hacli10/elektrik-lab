"""Nötr gerilim kayması / artık aşırı gerilim koruması (ANSI 59N) — Easergy P3 «Vo>» kademesi.

Dayanak: P3U/en M/J006 böl. 5.27 (toprak arızalarına karşı seçici olmayan yedek koruma; temel frekans bileşeni, 3. harmonik 60 dB'den fazla bastırılır;
ölçme: 3LN modunda faz–toprak gerilimlerinden hesap — ayar tabanı GT gerilimi/√3; «+Vo» modlarında açık üçgenden ölçme — taban GT0 sekonderi),
Çizelge 78–80 (başlatma %1 … %60, süre 0,3 … 300 s, başlatma süresi ≈ 200 ms, bırakma oranı 0,97); Lisanssız Üretim Tebliği Ek-2 Tablo-2 dipnot d
(59N: topraklama sistemine bağlı olarak gerektiğinde dağıtım şirketi ister; süre ve ayarı dağıtım şirketi belirler; statik jeneratörlere uygulanmaz)."""
from __future__ import annotations

import math

from .ortak import A, A120, C, G, K, LUY, P3U, S, S3, T, aci, ctl, fnum, fz, kademe_test, num, opt, tek_hat

ID = "vo_59n"
BASLIK = "Nötr gerilim kayması (59N)"
IKON = "📐"
GIRIS = ("Bir faz toprağa değdiğinde yıldız noktası toprağa göre kayar: üç faz–toprak geriliminin toplamı artık sıfır değildir. Bu artık gerilim "
         "şebekenin her yerinde görülür; akım gerektirmez. Santral toprak arızasına akım vermese bile arızayı bu gerilimden anlar.")

NOTR = {"direnc": "Şebekeye bağlı — nötr direnç üzerinden topraklı", "ada": "Ada (şebeke kesicisi açık) — nötr yalıtılmış"}
MODLAR = {"hesap": "3LN — faz–toprak gerilimlerinden hesap", "olcum": "Açık üçgen sargıdan ölçüm (…+Vo)"}

KONTROLLER = [
    ctl("un_kv", "Şebeke gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("notr", "Şebeke durumu", "sec", "direnc", secenek=opt(*NOTR.items())),
    ctl("ir_a", "Nötr direncinin akım sınırı", "sayi", 1000, min=20, max=2000, adim=10, birim="A", goster={"notr": ["direnc"]}),
    ctl("ic_a", "Adada kalan şebekenin kapasitif akımı", "sayi", 5, min=0.2, max=100, adim=0.1, birim="A", goster={"notr": ["ada"]}),
    ctl("rf", "Arıza direnci", "sayi", 0, min=0, max=20000, adim=10, birim="Ω"),
    ctl("mod", "Röle › Gerilim ölçme modu", "sec", "hesap", secenek=opt(*MODLAR.items())),
    ctl("vt_s", "GT sekonderi (faz arası)", "sec", 100, secenek=opt((100, "100 V"), (110, "110 V"))),
    ctl("vo", "Röle › Vo> başlatma", "sayi", 10, min=1, max=60, adim=1, birim="%"),
    ctl("t", "Röle › Çalışma süresi", "sayi", 2.0, min=0.3, max=300, adim=0.1, birim="s"),
    ctl("t_seb", "Şebekedeki toprak korumalarının en uzun süresi", "sayi", 1.0, min=0.1, max=5, adim=0.1, birim="s", yardim="Fiderlerin 51N / 67N süreleri; dağıtım şirketinden"),
]


def v0(p: dict, rf: float) -> float:
    """Artık gerilim (faz–toprak geriliminin yüzdesi)."""
    e = num(p, "un_kv", 34.5) * 1000 / S3
    z = complex(e / num(p, "ir_a", 1000), 0) if p.get("notr") != "ada" else complex(0, -e / num(p, "ic_a", 5))
    return abs(z / (z + rf)) * 100


def run(p: dict) -> dict:
    ada = p.get("notr") == "ada"; rf = num(p, "rf", 0); vt_s = num(p, "vt_s", 100)
    v = v0(p, rf); esik, t = num(p, "vo", 10), num(p, "t", 2.0)
    basla = v >= esik
    e = num(p, "un_kv", 34.5) * 1000 / S3
    z = (e / num(p, "ir_a", 1000)) if not ada else (e / num(p, "ic_a", 5))
    rf_max = (z * math.sqrt((100 / esik) ** 2 - 1)) if ada else z * (100 / esik - 1)
    # faz–toprak gerilimleri: L1 arızalı; nötr −k·E kadar kayar
    k = v / 100; a = A120
    ua, ub, uc = (1 - k) + 0j, a * a - k, a - k
    taban = vt_s / S3 if p.get("mod") != "olcum" else vt_s                  # açık üçgen: sargılar vt_s/3; katı arızada üçünün toplamı vt_s
    c = tek_hat(("Santral", "OG sargısı üçgen"), ("Dağıtım şebekesi", "ada — nötr yalıtılmış" if ada else f"nötr {fnum(num(p, 'ir_a', 1000), 0)} A"), ("59N  Vo>", ("AÇAR " + fnum(t, 1) + " s") if basla else "başlamadı"),
                "acti" if basla else "normal", 620, "", ileri=False, gt_ad="GT (3 faz–toprak)" if p.get("mod") != "olcum" else "GT (açık üçgen)")
    c.yazi(500, 190, f"Vo = %{fnum(v, 1)} · sağlam fazların toprağa göre gerilimi %{fnum(abs(ub) * 100, 0)}", "#b91c1c", 11.5, kalin=True)
    c.yazi(500, 208, f"Röle girişinde: {fnum(v / 100 * taban, 1)} V (taban {fnum(taban, 1)} V = %100)", "#334155", 11)
    c.yazi(500, 226, f"Bu ayarla görülen en büyük arıza direnci: {fnum(rf_max, 0)} Ω", "#334155", 11)
    fazor = {"baslik": "Faz–toprak gerilimleri (L1 toprak arızası)", "vektorler": [fz("UL1", abs(ua) * 100, aci(ua), abs(ua) / 1.75, "#8a4b12"), fz("UL2", abs(ub) * 100, aci(ub), abs(ub) / 1.75, "#111827"), fz("UL3", abs(uc) * 100, aci(uc), abs(uc) / 1.75, "#6b7280"),
                                                                             fz("Vo", v, 180, k / 1.75, "#dc2626", kesik=True)], "not": "Büyüklükler faz–nötr geriliminin yüzdesi. Katı arızada sağlam fazlar faz arası gerilime (%173) çıkar."}
    ozet = [
        K("Kademe", ("AÇAR " + fnum(t, 1) + " s") if basla else "başlamadı", "ok" if basla else "warn", f"eşik %{fnum(esik, 0)}"),
        K("Artık gerilim Vo", f"%{fnum(v, 1)}", "info", f"{fnum(v / 100 * taban, 1)} V röle girişinde"),
        K("Sağlam fazların gerilimi", f"%{fnum(abs(ub) * 100, 0)}", "bad" if abs(ub) > 1.5 else "warn" if abs(ub) > 1.1 else "ok", "toprağa göre (faz–nötr yüzdesi)"),
        K("Görülen en büyük arıza direnci", f"{fnum(rf_max, 0)} Ω", "info", "bu Vo> ayarıyla"),
        K("Şebeke korumalarıyla sıra", f"{fnum(t, 1)} s", "ok" if t > num(p, "t_seb", 1.0) else "bad", f"şebeke toprak korumaları ≤ {fnum(num(p, 't_seb', 1.0), 1)} s"),
    ]
    kontroller = [
        C("Bu arıza görülüyor mu?", f"Vo = %{fnum(v, 1)}", f"≥ Vo> = %{fnum(esik, 0)}", basla, P3U + " böl. 5.27", "resmi"),
        C("Başlatma doğal dengesizliğin üstünde mi?", f"%{fnum(esik, 0)}", "≥ %5 (işletmede ölçülen artık gerilimin rahatça üstü)", esik >= 5, "Aralık %1 … %60: " + P3U + " Çizelge 78. Alt sınır önerisi saha pratiği (kapasite dengesizliği, GT hataları)", "ikincil"),
        C("Süre şebekedeki seçici toprak korumalarından uzun mu?", f"{fnum(t, 1)} s; şebeke ≤ {fnum(num(p, 't_seb', 1.0), 1)} s", "t(59N) > şebeke toprak korumalarının süresi", t > num(p, "t_seb", 1.0),
          "59N seçici değildir: artık gerilim her yerde aynıdır. Önce arızalı fiderin koruması açmalı — " + P3U + " böl. 5.27 (seçici olmayan yedek)", "resmi"),
        C("Ayar ve süreyi kim belirler?", "dağıtım şirketi", "Tebliğ Ek-2 Tablo-2 dipnot d", None, LUY + " (59N: topraklama sistemine bağlı olarak gerektiğinde dağıtım şirketi ister; süre ve ayarı o belirler)", "resmi"),
        C("Gerilim ölçme modu ile ayar tabanı uyumlu mu?", MODLAR[p.get("mod") if p.get("mod") in MODLAR else "hesap"], "3LN: taban GT/√3; açık üçgen: taban GT0 sekonderi", None, P3U + " böl. 5.27", "resmi"),
    ]
    girdiler = [
        G("Şebekenin nötr topraklaması", NOTR["ada" if ada else "direnc"], "Dağıtım şirketi", "Arıza direncine karşı Vo'nun ne kadar düşeceğini belirler: dirençli şebekede Vo çabuk düşer, yalıtılmış şebekede yüksek kalır", "Vo = E · Z / (Z + Rf)"),
        G("Gerilim trafosunun sargı düzeni", "üç faz–toprak GT; varsa açık üçgen sargı", "GT etiketi; tek hat şeması", "Artık gerilim ancak faz–toprak bağlı GT'lerle elde edilir (iki GT'li V bağlantıda yoktur)", "Gerilim ölçme modu"),
        G("Yükseltici trafonun OG sargı bağlantısı", "üçgen / yıldız noktası yalıtılmış", "Trafo etiketi", "Santral toprak arızasına sıfır bileşen akımı vermez: şebeke tarafındaki arızayı akımdan göremez", "59N'nin gerekçesi"),
        G("Şebekedeki toprak korumalarının süreleri", f"≤ {fnum(num(p, 't_seb', 1.0), 1)} s", "Dağıtım şirketi", "59N onlardan sonra açmalı", "t(59N) > t(şebeke)"),
        G("Dağıtım şirketinin 59N isteği", "ayar ve süre", "Bağlantı görüşü", "Tebliğ bu korumanın değerini dağıtım şirketine bırakır", "Vo>, süre"),
    ]
    adimlar = [
        A("Nötr / şebeke empedansı", "Z = E / I (nötr direnci ya da kapasitif akım)", f"{fnum(e, 0)} V / {fnum(num(p, 'ic_a', 5) if ada else num(p, 'ir_a', 1000), 0)} A", f"{fnum(z, 0)} Ω" + (" (kapasitif)" if ada else ""), "E = Un/√3", "resmi", ["Şebekenin nötr topraklaması"]),
        A("Artık gerilim", "Vo = E · |Z / (Z + Rf)|", f"Rf = {fnum(rf, 0)} Ω", f"%{fnum(v, 1)}", "gerilim bölücü", "resmi"),
        A("Görülen en büyük arıza direnci", "Vo = Vo> eşitliğinden", f"Vo> = %{fnum(esik, 0)}", f"{fnum(rf_max, 0)} Ω", "aynı bağıntı", "resmi", [], "Vo> Başlatma"),
        A("Röle girişindeki gerilim", "%Vo × taban", f"%{fnum(esik, 0)} × {fnum(taban, 1)} V", f"{fnum(esik / 100 * taban, 1)} V", P3U + " böl. 5.27 (taban: 3LN'de GT/√3; açık üçgende GT0 sekonderi)", "resmi", ["Gerilim trafosunun sargı düzeni"]),
        A("Süre", "t > şebeke toprak korumalarının süresi", f"> {fnum(num(p, 't_seb', 1.0), 1)} s", f"{fnum(t, 1)} s", "seçici olmayan yedek koruma", "resmi", ["Şebekedeki toprak korumalarının süreleri"], "Çalışma süresi"),
    ]
    ayarlar = [
        S("Vo> › Başlatma", f"%{fnum(esik, 0)}", "%1 … %60; ekrandaki örnek %10", "Doğal dengesizliğin üstü; istenen arıza direnci duyarlılığı", P3U + " Çizelge 78"),
        S("Vo> › Çalışma süresi", f"{fnum(t, 1)} s", "0,3 … 300 s; ekrandaki örnek 2,0 s", "Şebekenin seçici toprak korumalarından uzun", P3U + " Çizelge 78"),
        S("Vo>> kademesi", "yüksek eşik, kısa süre (ada tespiti için)", "—", "Şebeke kesicisi açtıktan sonra katı arızada Vo = %100: hızlı ayrılma", P3U + " Çizelge 79"),
        S("Gerilim ölçme modu", MODLAR[p.get("mod") if p.get("mod") in MODLAR else "hesap"], "3LN, 3LN+Vo, 2LL+Vo …", "Vo'nun hesaplanacağını mı ölçüleceğini mi ve ayarın tabanını belirler", P3U + " böl. 5.27, 9.7"),
    ]
    dusus = min(3 * esik, 100)
    test = kademe_test("Vo>", esik / 100 * taban, "V (Vo girişinde ya da hesaplanan)", t, True, "±%2 ya da anma değerinin ±%0,3'ü (hesaplanan Vo'da ±1 V)", "±%1 ya da ±150 ms", 0.97, 1) + [
        T("3LN modunda tek fazı düşürerek", f"Üç faza {fnum(vt_s / S3, 1)} V; bir fazı %{fnum(dusus, 0)} düşürün ({fnum(vt_s / S3 * (1 - dusus / 100), 1)} V)", f"Vo = düşüşün 1/3'ü = %{fnum(dusus / 3, 1)}: başlatma", "±1 V"),
        T("Açık üçgen girişinden", f"Vo girişine {fnum(esik / 100 * vt_s, 1)} V", "Başlatma", "±%2"),
        T("3. harmonik", "Vo girişine yalnız 150 Hz gerilim", "Başlamaz (3. harmonik bastırılır)", P3U + " böl. 5.27"),
    ]
    rs = [0, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000]
    g = {"baslik": "Arıza direncine göre artık gerilim: şebekeye bağlıyken ve adada", "x_ad": "Arıza direnci (Ω)", "y_ad": "Vo (%)", "logy": True, "ymin": 0.1, "ymax": 100,
         "seriler": [{"ad": "şebekeye bağlı (nötr dirençli)", "renk": "#1a4d8f", "pts": [[r, max(v0({**p, "notr": "direnc"}, r), 0.1)] for r in rs]},
                     {"ad": "ada (nötr yalıtılmış)", "renk": "#dc2626", "pts": [[r, max(v0({**p, "notr": "ada"}, r), 0.1)] for r in rs]}],
         "yatay": [{"y": esik, "etiket": f"Vo> %{fnum(esik, 0)}"}], "isaretler": [{"x": rf, "etiket": "şu an"}] if rf > 0 else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "gorsel": ["59n"],
        "sahne": c.sahne(fazor=fazor), "grafikler": [g],
        "anlatim": [
            "Sağlam şebekede üç faz–toprak gerilimi eşit ve 120° aralıklıdır; toplamları sıfırdır. Bir faz toprağa değince o fazın gerilimi düşer, yıldız noktası toprağa göre kayar: toplam artık sıfır değildir.",
            f"Katı arızada kayma faz–nötr geriliminin tamamıdır (Vo = %100) ve sağlam iki faz toprağa göre faz arası gerilime çıkar. Şu an Vo = %{fnum(v, 1)}.",
            "Arıza yerinde direnç varsa gerilim, arıza direnci ile şebekenin toprağa göre empedansı arasında bölünür. Nötrü dirençle topraklı şebekede bu empedans küçüktür: Vo çabuk düşer. Yalıtılmış (ada) şebekede büyüktür: Vo yüksek kalır.",
            "Santralin yükseltici trafosunun OG sargısı üçgense santral toprak arızasına akım vermez; 51N ve 67N şebeke tarafındaki arızayı göremez. Artık gerilim ise santral barasında da ölçülür.",
            "Şebeke kesicisi açıp santral adada kalırsa nötr yalıtılmış olur: arıza akımı neredeyse sıfırdır ama Vo tamdır. Arızayı beslememek için santrali 59N ayırır.",
            "Artık gerilim her yerde aynı olduğundan 59N arızanın yerini bilemez; süresi seçici korumalardan uzun tutulur.",
        ],
        "dersler": [
            "59N akım gerektirmez; santralin toprak arızasına katkısı olmasa da çalışır.",
            "Ayarın tabanına dikkat: 3LN'de %100 = GT/√3 (57,7 V); açık üçgende %100 = sargının sekonderi.",
            "Tek fazın gerilimini %30 düşürürseniz Vo %10 olur (üçte biri).",
            "Ayar ve süre dağıtım şirketinindir (Tebliğ Ek-2 Tablo-2 dipnot d).",
        ],
        "tablolar": [{"baslik": "Arıza direncine göre Vo", "cols": ["Rf", "Şebekeye bağlı", "Ada", "Vo> ile"], "rows": [
            [f"{r} Ω", f"%{fnum(v0({**p, 'notr': 'direnc'}, r), 1)}", f"%{fnum(v0({**p, 'notr': 'ada'}, r), 1)}", ("bağlıyken görür" if v0({**p, "notr": "direnc"}, r) >= esik else "bağlıyken görmez") + " · " + ("adada görür" if v0({**p, "notr": "ada"}, r) >= esik else "adada görmez")] for r in (0, 50, 200, 1000, 5000)]}],
    }
