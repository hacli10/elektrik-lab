"""Elektrik Lab — Topraklama laboratuvarı ve Röle laboratuvarı.

agcalc v0.19'un «Öğren» bölümünden ayrılmış bağımsız uygulamadır: proje verisi okumaz, yazmaz. Hesap çekirdeği (elab/lab, elab/role) yalnız
Python standart kitaplığını kullanır; bu sayede aynı kod hem bilgisayardaki sunucuda (elab/api.py) hem de tarayıcının içinde (Pyodide,
ui/public/motor-worker.js) çalışır. İkisi de çekirdeğe tek kapıdan girer: elab/kopru.py."""
__version__ = "1.3.0"
UYGULAMA = "elab"
AD = "Elektrik Lab"
