"""Köprü: arayüzün hesap çekirdeğine girdiği tek kapı.

İki çalışma biçimi vardır ve ikisi de buradaki işlevleri çağırır; böylece sonuç her iki biçimde de aynıdır:
  • sunucu   — elab/api.py (FastAPI), bilgisayarda çalışır;
  • tarayıcı — ui/public/motor-worker.js, Python'u tarayıcının içinde (Pyodide) çalıştırır; `cagir()` JSON metni alır, JSON metni verir.

Bu dosya yalnız standart kitaplığı kullanır (tarayıcıda da yüklenir); FastAPI ya da dosya sistemi gerektiren hiçbir şey buraya konmaz."""
from __future__ import annotations

import json
import math

from . import AD, UYGULAMA, __version__, guc, lab, role
from .lab.dersnotu import ders_notu_html

BOLUMLER = {
    "lab": {"ad": "Topraklama laboratuvarı", "kisa": "Topraklama", "ikon": "⏚", "modul": lab,
            "tanim": "Öğretici simülasyonlar: ayarları değiştirin, sonucu canlı görün. Modeller öğretim amaçlı sadeleştirilmiştir; her sınır değerinin dayanağı yanında yazılıdır."},
    "role": {"ad": "Röle laboratuvarı", "kisa": "Röle", "ikon": "🛡", "modul": role,
             "tanim": "Her koruma fonksiyonu için: röleye giderken elinizde olması gerekenler, hangi verinin hangi hesapla hangi ayara dönüştüğü, röle ekranındaki alanlar, "
                      "canlı benzetim ve test planı. Her değerin dayanağı ve durumu yanında yazılıdır."},
    "guc": {"ad": "Güç sistemi laboratuvarı", "kisa": "Güç", "ikon": "⚡", "modul": guc,
            "tanim": "Dağıtım trafosu, motorlar, arıza fiziği, kablo boyu, AG tesisat, OG şebeke ve GES: bir olay nasıl oluşur, hangi büyüklük ne olur, ne kadar sürer. "
                     "Ayarı değiştirin, sonucu canlı görün. Her değerin dayanağı ve durumu yanında yazılıdır."},
}


def duz(o):
    """JSON'a çevrilebilir yalın veri: sonsuz ve tanımsız sayılar null olur (JSON bunları taşıyamaz)."""
    if isinstance(o, float) and (math.isinf(o) or math.isnan(o)):
        return None
    if isinstance(o, dict):
        return {k: duz(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [duz(v) for v in o]
    return o


def _bolum(bolum: str):
    try:
        return BOLUMLER[bolum]["modul"]
    except KeyError:
        raise KeyError(f"Bilinmeyen bölüm: {bolum}")


def surum() -> dict:
    return {"uygulama": UYGULAMA, "ad": AD, "surum": __version__}


def spec() -> dict:
    """Arayüzün açılışta istediği her şey: bölümler, konular, ayar tanımları, röle ekran görüntülerinin dizini."""
    return {**surum(),
            "bolumler": [{"id": b, "ad": v["ad"], "kisa": v["kisa"], "ikon": v["ikon"], "tanim": v["tanim"], "konular": v["modul"].spec()} for b, v in BOLUMLER.items()],
            "gorseller": role.gorseller()}


def run(bolum: str, konu: str, params: dict | None = None) -> dict:
    return duz(_bolum(bolum).run(str(konu or ""), params or {}))


def ders_notu(bolum: str, konu: str, params: dict | None = None, cizimler: list | None = None) -> str:
    """Seçili konu ve ayarların ders notu (yazdırılabilir HTML). Çizimler arayüzden gelir (SVG metni ya da <img>)."""
    return ders_notu_html(_bolum(bolum).run(str(konu or ""), params or {}), cizimler or [])


def cagir(islem: str, govde: str = "{}") -> str:
    """Tarayıcı motorunun çağırdığı tek işlev: JSON metni alır, JSON metni döndürür. Hata da JSON olarak döner (istisna dışarı sızmaz)."""
    try:
        g = json.loads(govde or "{}")
        if islem == "spec":
            veri = spec()
        elif islem == "run":
            veri = run(g.get("bolum", ""), g.get("konu", ""), g.get("params"))
        elif islem == "dersnotu":
            veri = {"html": ders_notu(g.get("bolum", ""), g.get("konu", ""), g.get("params"), g.get("cizimler"))}
        elif islem == "surum":
            veri = surum()
        else:
            raise KeyError(f"Bilinmeyen işlem: {islem}")
        return json.dumps({"ok": True, "veri": veri}, ensure_ascii=False, allow_nan=False)
    except Exception as e:  # noqa: BLE001 — arayüze okunur bir ileti dönmeli
        return json.dumps({"ok": False, "hata": f"{type(e).__name__}: {e}" if not isinstance(e, KeyError) else str(e.args[0] if e.args else e)}, ensure_ascii=False)
