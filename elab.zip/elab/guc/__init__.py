"""Güç sistemi laboratuvarı: dağıtım trafosu, motorlar, arıza fiziği, kablo boyu, AG tesisat, OG şebeke ve GES konularının öğretim benzetimleri.

Proje verisi okumaz, yazmaz. Sayfa kalıbı röle laboratuvarıyla aynıdır (ID, BASLIK, IKON, GIRIS, KONTROLLER, run(params)); sonuçtaki
girdiler / adimlar / ayarlar / test bölümleri burada «gereken veriler / hesap adımları / koruma ve izleme / sahada nasıl görülür» adıyla gösterilir.
Başka bölümde yazılmış bir sayfa buraya «bolum:modul» biçiminde alınabilir (ör. «role:demeraj_trafo»): dosya yerinde durur, konu bu bölümün menüsünde görünür."""
from __future__ import annotations

import importlib

from .. import role as _role

GRUPLAR = [
    ("Dağıtım trafosu", ["trafo_tip", "trafo_yuk", "trafo_isil", "trafo_yag", "trafo_faz", "trafo_dengesiz", "trafo_kademe", "role:demeraj_trafo", "trafo_kd", "role:trafo_gecis",
                         "trafo_paralel", "trafo_ses", "lab:trafo_test"]),
    ("Motorlar", ["doner_alan", "asenkron", "tek_faz_motor", "motor_faz", "steinmetz", "motor_dengesiz", "motor_ariza", "motor_kablo"]),
    ("Arıza fiziği", ["atlama", "delinme", "yuzey", "kd_isi", "kd_kuvvet", "ark_enerji", "ic_ark", "ark_parlama", "malzeme", "ariza_ms"]),
    ("Kablo boyu", ["boy_ag", "boy_og", "boy_ucgen", "boy_ges"]),
    ("AG tesisat", ["secicilik", "sinirlama", "kablo_isi", "cokme", "kompanzasyon", "notr_kopma", "paralel_kablo", "pano_isi"]),
    ("OG şebeke", ["enh", "yuruyen", "og_sigorta", "ring"]),
    ("GES", ["pv_egri", "golge", "dizi", "uretim", "adalanma", "ges_reaktif"]),
]
ADLAR = [k for _, ks in GRUPLAR for k in ks]
# kartların başlıkları: bu bölümde röle ayarı değil, olayın kendisi anlatılır
ETIKET = {
    "girdiler": ["Bu olayı çözmek için gereken veriler", "veri · nereden alınır · neden gerekir · nasıl kullanılır"],
    "adimlar": ["Hesap adımları", "soldaki veri → bağıntı → sağdaki sonuç"],
    "ayarlar": ["Koruma ve izleme: hangi cihaz neyi görür", "cihaz / alan · değer · aralık · dayanak"],
    "ayar_cols": ["Cihaz / alan", "Değer", "Aralık", "Neden", "Dayanak", "Durum"],
    "test": ["Sahada nasıl görülür, nasıl ölçülür", "ölçüm ya da gözlem · nasıl yapılır · beklenen"],
    "test_cols": ["Ölçüm / gözlem", "Nasıl", "Beklenen", "Not"],
    "adim_cip": "sonuç",
}


def _mods() -> list:
    """(modül, kaynak bölüm) çiftleri; henüz yazılmamış sayfalar atlanır."""
    out = []
    for ad in ADLAR:
        kaynak, _, name = ad.rpartition(":")
        yol = f"{__name__.rsplit('.', 1)[0]}.{kaynak}.{name}" if kaynak else f"{__name__}.{name}"
        try:
            out.append((importlib.import_module(yol), kaynak or "guc"))
        except ModuleNotFoundError as e:
            if e.name != yol:
                raise
    return out


def _grup_of() -> dict:
    return {ad.rpartition(":")[2]: g for g, ks in GRUPLAR for ad in ks}


def spec() -> list[dict]:
    go = _grup_of()
    return [{"id": m.ID, "baslik": m.BASLIK, "ikon": m.IKON, "giris": m.GIRIS, "kontroller": m.KONTROLLER, "grup": go.get(m.ID, "")} for m, _ in _mods()]


def _find(topic: str):
    for m, kaynak in _mods():
        if m.ID == topic:
            return m, kaynak
    raise KeyError(f"Bilinmeyen güç sistemi laboratuvarı konusu: {topic}")


def defaults(topic: str) -> dict:
    return {c["key"]: c["vars"] for c in _find(topic)[0].KONTROLLER}


def run(topic: str, params: dict | None = None) -> dict:
    m, kaynak = _find(topic)
    p = defaults(topic)
    p.update({k: v for k, v in (params or {}).items() if v is not None})
    out = m.run(p)
    for k in ("ozet", "kontroller", "anlatim", "dersler", "grafikler", "tablolar", "girdiler", "adimlar", "ayarlar", "test", "gorsel"):
        out.setdefault(k, [])
    out.setdefault("sahne", {})
    for satir in out["adimlar"] + out["kontroller"] + out["ayarlar"]:
        if satir.get("durum") == "resmi" and not any(iz in satir.get("kaynak", "") for iz in _role.RESMI_IZ):
            satir["durum"] = "hesap"
    out["gorsel"] = _role.gorsel_bul(out["gorsel"])
    out["konu"] = topic
    out["params"] = p
    out["bolum"] = "guc"
    if kaynak == "guc":
        out["etiketler"] = ETIKET
    return out
