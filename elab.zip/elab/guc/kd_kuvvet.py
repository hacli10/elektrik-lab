"""Kısa devrede kuvvet: paralel iletkenler birbirini akımların çarpımıyla orantılı bir kuvvetle iter ya da çeker. Baralarda mesnet izolatörüne binen yük,
baranın eğilmesi; tek damarlı kablolarda savrulma ve kelepçe aralığı; kuvvetin zamanla değişimi (100 Hz).

Kuvvet: F′ = μ0·i1·i2 / (2π·a) (temel bağıntı). Üç fazlı kısa devrede orta iletkene etkiyen en büyük kuvvet F′ = (√3/2)·μ0·ip² / (2π·a) (IEC 60865 — bellekten, dogrulanacak).
Tepe akım ip = κ·√2·Ik″. Hücrelerin anma tepe dayanım akımı 40 kA (TEDAŞ-MLZ/95-007.E), mesnet izolatörlerinin eğilmede kırılma yükleri 2000 … 16000 N (TEDAŞ-MLZ/96-020) —
resmi. Baranın akma sınırı ve dinamik katsayı tipiktir (tahmini)."""
from __future__ import annotations

import math

from . import fizik as F
from .ortak import A, C, G, K, RENK3, S, T, Cizim, ctl, fnum, num, opt, pts

ID = "kd_kuvvet"
BASLIK = "Kısa devrede kuvvet"
IKON = "💪"
GIRIS = ("Akım taşıyan iki iletken birbirine kuvvet uygular. Olağan akımda fark edilmez; kısa devrede akım yüz kat, kuvvet on bin kat büyür: baralar mesnetlerinden kopar, "
         "kablolar kamçı gibi savrulur. Akımı, faz aralığını ve mesnet açıklığını değiştirin; kuvvetin nereye çıktığını ve mesnedin dayanıp dayanmadığını izleyin.")
MESNET = (2000, 4000, 6000, 8000, 10000, 12500, 16000)

KONTROLLER = [
    ctl("duzen", "Düzen", "sec", "bara", secenek=opt(("bara", "Üç fazlı düz baralar (hücre, pano)"), ("kablo", "Tek damarlı kablolar yan yana"))),
    ctl("ik", "Kısa devre akımı Ik″ (etkin)", "sayi", 16.0, min=1, max=80, adim=0.5, birim="kA"),
    ctl("kappa", "Tepe katsayısı κ", "sayi", 1.76, min=1.02, max=2.0, adim=0.02, yardim="X/R büyükse (trafoya yakın) 1,8'e yaklaşır; uzun kablonun sonunda 1,1–1,3"),
    ctl("tip", "Arıza tipi", "sec", "3f", secenek=opt(("3f", "Üç faz"), ("2f", "İki faz"))),
    ctl("a", "Faz iletkenlerinin eksen aralığı", "sayi", 300, min=30, max=600, adim=10, birim="mm", yardim="36 kV hücrede ≈ 300–370 mm; AG panoda 60–100 mm"),
    ctl("l", "Mesnet / kelepçe açıklığı", "sayi", 1000, min=200, max=2500, adim=50, birim="mm"),
    ctl("mesnet", "Mesnet izolatörünün eğilmede kırılma yükü", "sec", 4000, secenek=opt(*[(m, f"{m} N") for m in MESNET]), goster={"duzen": ["bara"]}),
    ctl("b", "Bara: kalınlık (kuvvet yönündeki boyut)", "sayi", 10, min=3, max=20, adim=1, birim="mm", goster={"duzen": ["bara"]}),
    ctl("h", "Bara: yükseklik", "sayi", 60, min=20, max=160, adim=10, birim="mm", goster={"duzen": ["bara"]}),
]


def run(p: dict) -> dict:
    bara = p.get("duzen", "bara") == "bara"
    ik, kappa, tip = num(p, "ik", 16.0), num(p, "kappa", 1.76), str(p.get("tip", "3f"))
    a, l = num(p, "a", 300) / 1000, num(p, "l", 1000) / 1000
    ip = kappa * math.sqrt(2) * ik * (1.0 if tip == "3f" else math.sqrt(3) / 2)
    fm = F.kuvvet_3f(ip, a) if tip == "3f" else F.kuvvet(ip, ip, a)                 # N/m
    f_mesnet = fm * l * 1.1                                                          # sürekli kirişte orta mesnet payı ≈ 1,1
    in_ = 1.0                                                                        # kA: anma akımı mertebesi (karşılaştırma)
    f_anma = F.kuvvet(math.sqrt(2) * in_, math.sqrt(2) * in_, a)
    kir = num(p, "mesnet", 4000)
    b, h = num(p, "b", 10), num(p, "h", 60)
    w = h * b * b / 6                                                                # mm³ — kuvvet kalınlık yönünde (baralar yan yana, dar yüzleri karşılıklı değil)
    sigma = fm * l * l / 12 * 1000 / w                                               # N/mm² (sürekli kiriş: M = F′·l²/12)
    akma = 250.0
    c = Cizim(900, 300)
    xs = (170, 170 + min(max(a * 300, 60), 150), 170 + 2 * min(max(a * 300, 60), 150))
    yon = (-1, 0, 1) if tip == "3f" else (0, -1, 1)
    for j, x in enumerate(xs):
        aktif = not (tip == "2f" and j == 0)
        if bara:
            c.dikdortgen(x - 6, 80, 12, 70, "ariza" if aktif else "cizgi", "#fbbf24" if aktif else "#e2e8f0", kw=2, r=2)
            c.dikdortgen(x - 9, 150, 18, 46, "cizgi", "#fde68a", kw=1.2, r=3); c.hat(f"M{x - 16},196 h32", "cizgi", w=3)
        else:
            c.daire(x, 130, 22, "cizgi", "#e2e8f0", w=1.4); c.daire(x, 130, 11, "ariza" if aktif else "cizgi", "#fbbf24" if aktif else "#fff")
        c.yazi(x, 68, f"L{j + 1}", RENK3[j], 12, kalin=True, anchor="middle")
        if aktif and yon[j]:
            c.ok(x, 115 if bara else 130, x + yon[j] * 46, 115 if bara else 130, "ariza", 3)
        elif aktif:
            c.ok(x - 4, 105, x - 40, 105, "uyari", 2); c.ok(x + 4, 125, x + 40, 125, "uyari", 2)
    c.hat(f"M{xs[0]},230 H{xs[1]}", "mavi", w=1.4); c.yazi((xs[0] + xs[1]) / 2, 248, f"{fnum(a * 1000, 0)} mm", "#1d4ed8", 11.5, kalin=True, anchor="middle")
    c.yazi((xs[0] + xs[2]) / 2, 274, "kesit görünüşü: oklar tepe anındaki kuvvet yönleri", "#64748b", 10.5, anchor="middle")
    c.yazi(520, 56, f"Tepe akım ip = {fnum(ip, 1)} kA", "#b91c1c", 14, kalin=True)
    c.yazi(520, 82, f"Kuvvet {fnum(fm, 0)} N/m ≈ metrede {fnum(fm / 9.81, 0)} kg", "#b91c1c", 13.5, kalin=True)
    c.yazi(520, 106, f"1 kA anma akımındaki kuvvetin {fnum(fm / f_anma, 0)} katı", "#334155", 12)
    if bara:
        c.yazi(520, 136, f"Mesnede binen yük {fnum(f_mesnet, 0)} N — kırılma yükü {fnum(kir, 0)} N", "#b91c1c" if f_mesnet > kir else "#15803d", 12.5, kalin=True)
        c.yazi(520, 160, f"Baranın eğilme gerilmesi {fnum(sigma, 0)} N/mm² (akma ≈ {fnum(akma, 0)})", "#b91c1c" if sigma > akma else "#334155", 12.5)
    else:
        c.yazi(520, 136, f"Kelepçeye binen yük {fnum(fm * l, 0)} N ({fnum(l * 1000, 0)} mm aralıkta)", "#b91c1c" if fm * l > 5000 else "#334155", 12.5, kalin=True)
        c.yazi(520, 160, "Kelepçesiz kablo iter, savrulur; ek ve başlıklar çekilir.", "#334155", 12)
    c.yazi(520, 192, "Kuvvet akımın karesiyle büyür, aralıkla ters orantılıdır:", "#64748b", 11); c.yazi(520, 208, "AG panoda (dar aralık) kuvvet OG hücresindekinden büyüktür.", "#64748b", 11)
    c.yazi(520, 232, "Aynı yönlü akımlar birbirini çeker, zıt yönlüler iter.", "#64748b", 11)
    ozet = [
        K("Tepe akım", f"{fnum(ip, 1)} kA", "warn", f"κ = {fnum(kappa, 2)} · Ik″ = {fnum(ik, 1)} kA"),
        K("Kuvvet", f"{fnum(fm, 0)} N/m", "bad" if fm > 3000 else "warn", f"≈ {fnum(fm / 9.81, 0)} kg/m"),
        (K("Mesnet yükü", f"{fnum(f_mesnet, 0)} N", "bad" if f_mesnet > kir else "warn" if f_mesnet > 0.5 * kir else "ok", f"kırılma yükü {fnum(kir, 0)} N · pay × {fnum(kir / f_mesnet, 1)}") if bara else
         K("Kelepçe yükü", f"{fnum(fm * l, 0)} N", "warn" if fm * l > 5000 else "ok", f"{fnum(l * 1000, 0)} mm aralık")),
        (K("Bara eğilme gerilmesi", f"{fnum(sigma, 0)} N/mm²", "bad" if sigma > akma else "ok", f"{fnum(b, 0)} × {fnum(h, 0)} mm · akma ≈ {fnum(akma, 0)}") if bara else K("Savrulma", "kelepçe gerekir" if fm > 500 else "sınırlı", "warn" if fm > 500 else "ok", "tek damarlı kablo")),
        K("Anma akımına göre", f"× {fnum(fm / f_anma, 0)}", "info", "1 kA anma akımındaki kuvvete göre"),
    ]
    kontroller = [
        C("Tepe akım donanımın tepe dayanım akımının altında mı?", f"{fnum(ip, 1)} kA", "≤ 40 kA (OG hücresi, 16 kA sınıfı)", ip <= 40.0 + 1e-9, "Anma kısa süreli dayanım akımı 16 kA (1 s), anma tepe dayanım akımı 40 kA — TEDAŞ-MLZ/95-007.E (hava yalıtımlı metal mahfazalı hücreler şartnamesi)", "resmi"),
    ] + ([
        C("Mesnet izolatörü dayanıyor mu?", f"{fnum(f_mesnet, 0)} N", f"≤ {fnum(kir, 0)} N (eğilmede kırılma yükü)", f_mesnet <= kir, "Mesnet izolatörlerinin eğilmede kırılma yükü sınıfları 2000 – 4000 – 6000 – 8000 – 10000 – 12500 – 16000 N — TEDAŞ-MLZ/96-020 böl. 2.2", "resmi"),
        C("Bara kalıcı eğilmeden dayanıyor mu?", f"{fnum(sigma, 0)} N/mm²", f"≤ {fnum(akma, 0)} N/mm² (sert bakır, akma)", sigma <= akma, "σ = M / W, M = F′·l²/12 (sürekli kiriş); kuvvet baranın kalınlığı yönünde — akma sınırı tipik", "tahmini"),
    ] if bara else [
        C("Kelepçe aralığı yeterli mi?", f"kelepçe başına {fnum(fm * l, 0)} N", "kelepçenin dayanım sınıfına göre (ör. 5 kN)", fm * l <= 5000, "Tek damarlı kabloların kısa devre kelepçeleri tepe akıma göre seçilir; sınıf değeri üretici kataloğundandır — tipik", "tahmini"),
    ]) + [
        C("Kuvvet bağıntısı", f"F′ = {fnum(fm, 0)} N/m", "bilgi", None, "F′ = (√3/2)·μ0·ip²/(2π·a) (üç faz, orta iletken) — IEC 60865'teki bağıntı; asıl metinle doğrulanacak", "dogrulanacak"),
    ]
    girdiler = [
        G("Kısa devre akımı ve tepe katsayısı", f"Ik″ = {fnum(ik, 1)} kA · κ = {fnum(kappa, 2)}", "Kısa devre hesabı (X/R oranından κ)", "Kuvveti etkin değer değil ilk tepenin karesi belirler", "ip = κ·√2·Ik″"),
        G("Faz aralığı", f"{fnum(a * 1000, 0)} mm", "Hücre / pano çizimi; kablo döşeme düzeni", "Kuvvet aralıkla ters orantılıdır", "F′ ∝ 1/a"),
        G("Mesnet / kelepçe açıklığı", f"{fnum(l * 1000, 0)} mm", "Montaj çizimi", "Her mesnede iki yanındaki yarım açıklıkların kuvveti biner; eğilme momenti açıklığın karesiyle artar", "F = F′·l · M = F′·l²/12"),
    ]
    adimlar = [
        A("Tepe akım", "ip = κ · √2 · Ik″" + (" · (√3/2)" if tip == "2f" else ""), f"{fnum(kappa, 2)} × 1,414 × {fnum(ik, 1)}", f"{fnum(ip, 1)} kA", "ilk yarım periyodun tepesi: doğru bileşen eklenir", "hesap", ["Kısa devre akımı ve tepe katsayısı"]),
        A("Birim uzunluktaki kuvvet", "F′ = (√3/2)·μ0·ip² / (2π·a)" if tip == "3f" else "F′ = μ0·ip² / (2π·a)", f"0,2 × {'0,866 × ' if tip == '3f' else ''}{fnum(ip, 1)}² / {fnum(a, 3)}", f"{fnum(fm, 0)} N/m", "Ampère kuvvet yasası", "hesap", ["Faz aralığı"]),
        A("Mesnede binen yük" if bara else "Kelepçeye binen yük", "F = 1,1 · F′ · l" if bara else "F = F′ · l", f"{fnum(fm, 0)} × {fnum(l, 2)}", f"{fnum(f_mesnet if bara else fm * l, 0)} N", "sürekli kirişte orta mesnet", "hesap", ["Mesnet / kelepçe açıklığı"]),
    ] + ([A("Baranın eğilme gerilmesi", "σ = F′·l² / (12·W) · W = h·b²/6", f"W = {fnum(w, 0)} mm³", f"{fnum(sigma, 0)} N/mm²", "kiriş kuramı", "hesap")] if bara else [])
    ayarlar = [
        S("Akım sınırlayan sigorta / kesici", "tepe akımı keser", "—", "Kuvvet ilk yarım periyotta oluşur: yalnız akım sınırlayan cihaz onu azaltabilir; röle süresi kuvveti değiştirmez", "«Akım sınırlama» sayfası", "ikincil"),
        S("Mesnet sınıfı ve açıklığı", f"≥ {next((m for m in MESNET if m >= f_mesnet), 16000)} N ya da daha sık mesnet" if bara else "kısa devre kelepçesi", "2000 … 16000 N", "Kuvveti taşımanın iki yolu", "TEDAŞ-MLZ/96-020 böl. 2.2"),
        S("Pano / hücre tepe dayanım akımı", "Ipk ≥ ip", "—", "Tip deneyiyle doğrulanmış düzen değiştirilmez: bara aralığı ve mesnet sayısı deneydeki gibi kalır", "TEDAŞ-MLZ/95-007.E"),
    ]
    test = [
        T("Arızadan sonra", "Baralarda eğilme, mesnetlerde çatlak, cıvatalarda gevşeme; kablolarda yer değiştirme, başlıklarda çekilme", "yok", "çatlamış epoksi mesnet bir sonraki arızada kırılır"),
        T("Cıvata torku", "Tork anahtarı ile bara ekleri ve mesnet bağlantıları", "üretici değeri", "gevşek ek hem ısınır hem kuvvet altında açılır"),
    ]
    ts = [k * 0.5 for k in range(0, 161)]
    tau = 0.045
    def i_an(t_ms: float, faz: float) -> float:
        t = t_ms / 1000
        return math.sqrt(2) * ik * (math.sin(100 * math.pi * t + faz - math.pi / 2) + math.exp(-t / tau) * math.cos(faz) * (kappa - 1.02) / 0.78)
    kuv = [F.kuvvet(i_an(t, 0), i_an(t, 0), a) if tip == "2f" else abs(F.kuvvet(i_an(t, 0), i_an(t, -2.094), a) - F.kuvvet(i_an(t, 0), i_an(t, 2.094), a)) for t in ts]
    g1 = {"baslik": "Kuvvetin zamanla değişimi (ilk 80 ms)", "x_ad": "Zaman (ms)", "y_ad": "Kuvvet (N/m)", "zaman": True, "ymin": 0,
          "seriler": [{"ad": "orta iletkene etkiyen kuvvet" if tip == "3f" else "iki iletken arasındaki kuvvet", "renk": "#dc2626", "pts": pts(ts, kuv, 0)}],
          "yatay": [{"y": fm, "etiket": "hesap tepesi", "renk": "#7c3aed"}]}
    iks = [1 + k for k in range(0, 60)]
    g2 = {"baslik": "Kısa devre akımına göre kuvvet", "x_ad": "Ik″ (kA)", "y_ad": "Kuvvet (N/m)", "logy": True,
          "seriler": [{"ad": f"a = {x} mm", "renk": rk, "pts": pts(iks, [F.kuvvet_3f(kappa * math.sqrt(2) * q, x / 1000) for q in iks], 0)} for x, rk in ((80, "#dc2626"), (150, "#b45309"), (300, "#1a4d8f"), (500, "#15803d"))],
          "isaretler": [{"x": ik, "etiket": "Ik″"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "ses": [{"ad": "Kısa devre darbesi", "not": "baraların ve mahfazanın 100 Hz'lik kuvvetle sarsılması", "sure": 0.8, "zarf": "sonen", "tau": 0.1, "taban": 0.0, "siddet": 1.0,
                 "parcalar": [{"f": 100, "a": 1.0}, {"f": 50, "a": 0.8}, {"f": 200, "a": 0.4}], "gurultu": 0.6, "gurultu_f": 800}],
        "anlatim": [
            "Akım taşıyan her iletkenin çevresinde manyetik alan vardır; yanındaki iletken bu alanın içindedir ve akımıyla orantılı bir kuvvet görür. Aynı yönlü akımlar birbirini çeker, zıt yönlüler iter.",
            f"Kuvvet iki akımın çarpımıyla orantılıdır. Olağan çalışmada (1 kA) metrede {fnum(f_anma, 1)} N: fark edilmez. Kısa devrede tepe akım {fnum(ip, 1)} kA: kuvvet {fnum(fm / f_anma, 0)} katına, metrede {fnum(fm, 0)} N'a çıkar.",
            "Belirleyici olan akımın etkin değeri değil ilk tepesidir. Arızanın başında akımda bir doğru bileşen bulunur; ilk tepe simetrik tepenin κ katıdır. Kuvvet bu tepenin karesiyle oluşur ve yaklaşık 10 ms sonra en büyük değerindedir: hiçbir röle bu kadar hızlı değildir.",
            ("Üç fazlı düzende en çok zorlanan orta baradır: iki yanındaki akımlar onu sırayla iter ve çeker. Kuvvet 100 Hz'te titreşir; mesnet izolatörü bu yükü eğilmeyle taşır. " + (f"Burada mesnede {fnum(f_mesnet, 0)} N biniyor; kırılma yükü {fnum(kir, 0)} N." if bara else "")
             if tip == "3f" else "İki faz arızasında akımlar zıt yönlüdür: iki iletken birbirini iter. Üçüncü iletken akım taşımaz."),
            ("Bara aralığı daraldıkça kuvvet büyür: AG panolarında aralık 60–100 mm'dir ve kuvvet, aynı akımda OG hücresindekinin 3–5 katıdır. Panonun tepe dayanım akımı bu yüzden tip deneyiyle doğrulanır."
             if bara else "Tek damarlı kablolar bağlanmazsa birbirini iter: kablo tavadan fırlar, başlığından çekilir. Kısa devre kelepçeleri ve yeterince sık bağlama bu yüzden gereklidir; üçlü (yonca) demette kuvvetler birbirini büyük ölçüde götürür."),
        ],
        "dersler": [
            "Kuvvet ∝ ip² / a: akım iki katına çıkarsa kuvvet dört katına, aralık yarıya inerse iki katına çıkar.",
            "Kuvveti ilk tepe belirler (≈ 10 ms): röle süresi kuvveti değiştirmez, yalnız akım sınırlayan cihaz değiştirir.",
            "36 kV hücrede tepe dayanım akımı 40 kA; mesnet izolatörleri 2000–16000 N sınıflarındadır.",
            "Tip deneyli pano ve hücrede bara aralığı ve mesnet sayısı değiştirilmez: dayanım o düzen için geçerlidir.",
            "Tek damarlı kablolar kısa devre kelepçesiyle ya da yonca demetle bağlanır.",
        ],
        "tablolar": [{"baslik": "Akıma ve aralığa göre kuvvet (N/m, üç faz, κ = " + fnum(kappa, 2) + ")", "cols": ["Ik″", "ip", "a = 80 mm", "a = 150 mm", "a = 300 mm", "a = 500 mm"],
                      "rows": [[f"{str(q).replace('.', ',')} kA", f"{fnum(kappa * math.sqrt(2) * q, 1)} kA"] + [fnum(F.kuvvet_3f(kappa * math.sqrt(2) * q, x / 1000), 0) for x in (80, 150, 300, 500)] for q in (10, 16, 25, 31.5, 50)],
                      "not": "100 N ≈ 10 kg. 50 kA'lık bir AG panosunda (80 mm aralık) metrede 3,5 tonluk bir kuvvet 100 Hz'te titreşir."}],
    }
