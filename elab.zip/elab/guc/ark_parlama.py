"""Ark parlaması: açık bir panonun ya da hücrenin önünde duran kişiye ulaşan ısı (olay enerjisi, cal/cm²); akımın, mesafenin ve en çok da temizleme süresinin etkisi;
ikinci derece yanık sınırı, koruyucu giysi düzeyi, ark parlama sınırı.

Hesap: IEEE 1584-2002 deneysel bağıntıları (0,208–15 kV); 34,5 kV'ta aynı bağıntı uzatılarak kullanılır (standardın 15 kV üstü için önerdiği Lee bağıntısı
E = 2,142·10⁶·U·Ibf·t / D² kapalı hücrede çok büyük sonuç verir; karşılaştırma için ayrıca yazılır) — bağıntılar bellekten yazılmıştır (dogrulanacak).
İkinci derece yanık eşiği 1,2 cal/cm² ve giysi düzeyleri (4 – 8 – 25 – 40 cal/cm²) NFPA 70E'den bellekle (dogrulanacak). Bu sayfa bir ark parlama etüdü değildir:
büyüklüklerin birbirine nasıl bağlı olduğunu gösterir."""
from __future__ import annotations

import math

from . import fizik as F
from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, logsp, num, opt, pts

ID = "ark_parlama"
BASLIK = "Ark parlaması"
IKON = "🦺"
GIRIS = ("Açık bir panoda ark yanarsa karşısındaki kişiye ulaşan şey akım değil ısıdır: santimetre kareye düşen kalori. 1,2 cal/cm² çıplak deride ikinci derece yanık yapar. "
         "Bu enerji akımla ve en çok da arkın süresiyle büyür, mesafeyle hızla azalır. Korumanın süresini ve çalışma mesafesini değiştirip izleyin.")
YER = {"pano": ("AG dağıtım panosu / MCC", True, 1.641, 25, 455), "sg": ("AG ana pano (şalt)", True, 1.473, 32, 610), "acik": ("Açık havada (kablo başlığı, bara)", False, 2.0, 32, 455), "og": ("OG hücresi", True, 0.973, 150, 910)}
KORUMA = {"sinir": ("Akım sınırlayan sigorta", 0.01), "ark": ("Ark rölesi + kesici", 0.07), "ani": ("Ani kademe + kesici", 0.10), "kisa": ("Kısa gecikmeli kademe (S)", 0.30), "gec": ("Gecikmeli aşırı akım", 0.60), "yedek": ("Yedek koruma", 1.5)}
KKD = [(1.2, "0", "günlük iş giysisi (pamuklu)"), (4.0, "1", "ark dayanımlı gömlek–pantolon, yüz siperi"), (8.0, "2", "ark dayanımlı giysi, başlık / siper"), (25.0, "3", "ark tulumu + başlık"), (40.0, "4", "ağır ark tulumu + başlık")]

KONTROLLER = [
    ctl("u", "Sistem gerilimi", "sec", 0.4, secenek=opt((0.4, "0,4 kV"), (0.69, "0,69 kV"), (6.3, "6,3 kV"), (10.5, "10,5 kV"), (34.5, "34,5 kV"))),
    ctl("yer", "Donanım", "sec", "pano", secenek=opt(*[(k, v[0]) for k, v in YER.items()])),
    ctl("ibf", "Kısa devre akımı (ark yokken)", "sayi", 25.0, min=1, max=65, adim=0.5, birim="kA"),
    ctl("koruma", "Arkı temizleyen koruma", "sec", "kisa", secenek=opt(*[(k, f"{v[0]} (≈ {fnum(v[1] * 1000, 0)} ms)") for k, v in KORUMA.items()])),
    ctl("d", "Çalışma mesafesi (ark – gövde)", "sayi", 455, min=200, max=3000, adim=5, birim="mm", yardim="AG panoda ≈ 455 mm (kol boyu), şalt panosunda ≈ 610 mm, OG hücresinde ≈ 910 mm"),
    ctl("toprakli", "Şebeke doğrudan topraklı", "onay", True),
]


def enerji(u: float, yer: str, ibf: float, t: float, d: float, toprakli: bool) -> dict:
    ad, kutu, x, g, _ = YER[yer]
    return F.ieee1584(u, ibf, t, d, g, kutu, toprakli, x)


def sinir_mesafe(u: float, yer: str, ibf: float, t: float, toprakli: bool, esik: float = 1.2) -> float:
    lo, hi = 50.0, 60000.0
    for _ in range(50):
        mid = math.sqrt(lo * hi)
        lo, hi = (mid, hi) if enerji(u, yer, ibf, t, mid, toprakli)["e"] > esik else (lo, mid)
    return hi


def run(p: dict) -> dict:
    u, yer, ibf, d, toprakli = num(p, "u", 0.4), str(p.get("yer", "pano")), num(p, "ibf", 25.0), num(p, "d", 455), bool(p.get("toprakli", True))
    kor = str(p.get("koruma", "kisa")); kad, t = KORUMA[kor]
    r = enerji(u, yer, ibf, t, d, toprakli)
    e = r["e"]
    kat = next((k for k in KKD if e <= k[0]), None)
    afb = sinir_mesafe(u, yer, ibf, t, toprakli)
    c = Cizim(900, 300)
    c.dikdortgen(60, 60, 110, 200, "cizgi", "#e2e8f0", kw=2.4); c.yazi(115, 50, YER[yer][0].split(" (")[0], "#475569", 10.5, anchor="middle")
    c.simsek(150, 140, 1.8)
    xk = 170 + min(max(d * 0.25, 60), 300)
    for j, (rr, col) in enumerate(((60, "ariza"), (110, "uyari"), (170, "mavi"))):
        c.daire(170, 160, rr, col, w=1.4, kesik=True)
    c.kisi(xk, 262, xk - 14, 190, "bad" if e > 1.2 else "ok")
    c.hat(f"M170,280 H{xk}", "mavi", w=1.4); c.yazi((170 + xk) / 2, 296, f"{fnum(d, 0)} mm", "#1d4ed8", 11.5, kalin=True, anchor="middle")
    c.yazi(540, 56, f"Olay enerjisi {fnum(e, 1)} cal/cm²", "#b91c1c" if e > 8 else "#b45309" if e > 1.2 else "#15803d", 15, kalin=True)
    c.yazi(540, 82, ("Çıplak deride ikinci derece yanık sınırının altında" if e <= 1.2 else f"Giysi düzeyi {kat[1]}: {kat[2]}" if kat else "40 cal/cm²'nin üstünde: enerji altında çalışılmaz"), "#b91c1c" if not kat else "#334155", 12.5, kalin=True)
    c.yazi(540, 108, f"Ark akımı {fnum(r['ia'], 1)} kA (kısa devre akımının %{fnum(r['ia'] / ibf * 100, 0)}'i)", "#334155", 12.5)
    c.yazi(540, 132, f"{kad}: {fnum(t * 1000, 0)} ms", "#334155", 12.5)
    c.yazi(540, 156, f"Ark parlama sınırı (1,2 cal/cm²): {fnum(afb / 1000, 2)} m", "#1a4d8f", 12.5, kalin=True)
    c.yazi(540, 186, "Enerji süreyle doğru orantılıdır: süre yarıya inerse", "#64748b", 11); c.yazi(540, 202, "enerji yarıya iner. Mesafeyle hızla azalır.", "#64748b", 11)
    c.yazi(540, 228, f"Yöntem: {r['yontem']}", "#64748b", 10.5)
    ozet = [
        K("Olay enerjisi", f"{fnum(e, 1)} cal/cm²", "bad" if e > 8 else "warn" if e > 1.2 else "ok", f"{fnum(d, 0)} mm'de · {fnum(e * 4.184, 1)} J/cm²"),
        K("Giysi düzeyi", "gerekmez" if e <= 1.2 else kat[1] if kat else "çalışılmaz", "bad" if not kat else "warn" if e > 1.2 else "ok", (kat[2] if kat else "> 40 cal/cm²")),
        K("Ark akımı", f"{fnum(r['ia'], 1)} kA", "info", f"kısa devre {fnum(ibf, 1)} kA"),
        K("Ark parlama sınırı", f"{fnum(afb / 1000, 2)} m", "warn" if afb > 1000 else "ok", "1,2 cal/cm²'nin düştüğü mesafe"),
        K("Temizleme süresi", f"{fnum(t * 1000, 0)} ms", "bad" if t > 0.3 else "ok", kad),
    ]
    e_ark = enerji(u, yer, ibf, KORUMA["ark"][1], d, toprakli)["e"]
    kontroller = [
        C("Olay enerjisi ikinci derece yanık eşiğinin altında mı?", f"{fnum(e, 1)} cal/cm²", "≤ 1,2 cal/cm² (çıplak deri)", e <= 1.2, "1,2 cal/cm² (5 J/cm²) ikinci derece yanığın başlangıcı kabul edilir — NFPA 70E / IEEE 1584 (asıl metinle doğrulanacak)", "dogrulanacak"),
        C("Uygun koruyucu giysi var mı?", f"{fnum(e, 1)} cal/cm²", "≤ 40 cal/cm² (en ağır giysi düzeyi)", e <= 40.0, "Giysi düzeyleri 4 – 8 – 25 – 40 cal/cm²; üstünde enerji altında çalışılmaz — NFPA 70E (asıl metinle doğrulanacak)", "dogrulanacak"),
        C("Kişi ark parlama sınırının dışında mı?", f"{fnum(d, 0)} mm", f"sınır {fnum(afb, 0)} mm", d >= afb, "Sınırın içinde çalışan herkes ark dayanımlı giysi giyer; yakından geçen de etkilenir", "dogrulanacak"),
        C("Süre kısaltılırsa?", f"şimdi {fnum(e, 1)} cal/cm²", f"ark rölesiyle {fnum(e_ark, 1)} cal/cm²", None, "Olay enerjisi süreyle doğru orantılıdır: giysiyi kalınlaştırmak yerine süreyi kısaltmak asıl önlemdir", "hesap"),
        C("Lee bağıntısıyla (kuramsal üst sınır)", f"{fnum(r['lee'], 1)} cal/cm²", "bilgi", None, "E = 2,142·10⁶·U·Ibf·t / D²: arkın bütün gücünün ışınıma dönüştüğünü varsayar; 15 kV'un üstünde standardın önerdiği yöntemdir ve çok temkinlidir — doğrulanacak", "dogrulanacak"),
        C("AG'de ark akımı", f"{fnum(r['ia'], 1)} kA", "korumanın ani eşiğinin üstünde olmalı", None, "AG'de ark akımı kısa devre akımının %40–60'ıdır: süre, kısa devre akımına göre değil ark akımına göre koruma eğrisinden okunur", "dogrulanacak"),
    ]
    girdiler = [
        G("Kısa devre akımı", f"{fnum(ibf, 1)} kA", "Kısa devre hesabı: çalışılacak panonun barasında", "Ark akımını ve gücünü belirler", "Ia = f(Ibf, U, aralık)"),
        G("Koruma süresi (ark akımında)", f"{fnum(t * 1000, 0)} ms — {kad}", "Koruma eğrisi: ark akımına karşılık gelen açma süresi + kesici süresi", "Enerjiyi doğrudan çarpar; değiştirilebilen tek büyüklük", "E ∝ t"),
        G("Çalışma mesafesi ve donanım", f"{fnum(d, 0)} mm · {YER[yer][0]}", "İşin niteliği: ölçü, şalter sürme, sigorta değiştirme", "Kapalı kutu enerjiyi çalışana doğru odaklar", "E ∝ 1 / D^x"),
    ]
    adimlar = [
        A("Ark akımı", "lg Ia = K + 0,662·lg Ibf + 0,0966·U + 0,000526·G + 0,5588·U·lg Ibf − 0,00304·G·lg Ibf (U < 1 kV)" if u < 1 else "lg Ia = 0,00402 + 0,983·lg Ibf",
          f"Ibf = {fnum(ibf, 1)} kA · U = {str(u).replace('.', ',')} kV · G = {YER[yer][3]} mm", f"{fnum(r['ia'], 1)} kA", r["yontem"] + " — doğrulanacak", "dogrulanacak", ["Kısa devre akımı"]),
        A("Normalize enerji", "lg En = K1 + K2 + 1,081·lg Ia + 0,0011·G", "0,2 s ve 610 mm için", "deneysel katsayılarla", r["yontem"] + " — doğrulanacak", "dogrulanacak"),
        A("Süre ve mesafe düzeltmesi", "E = 4,184 · Cf · En · (t / 0,2) · (610 / D)^x", f"t = {fnum(t, 2)} s · D = {fnum(d, 0)} mm · x = {fnum(YER[yer][2], 3)}", f"{fnum(e * 4.184, 1)} J/cm² = {fnum(e, 1)} cal/cm²", "kapalı kutuda mesafe üssü 2'den küçüktür: enerji odaklanır", "dogrulanacak", ["Koruma süresi (ark akımında)", "Çalışma mesafesi ve donanım"]),
        A("Ark parlama sınırı", "E(D) = 1,2 cal/cm² olan D", "aynı bağıntının mesafe için çözümü", f"{fnum(afb / 1000, 2)} m", "ikiye bölme ile", "hesap"),
    ]
    ayarlar = [
        S("Ani kademe (I / Ii)", f"ark akımının altında: < {fnum(r['ia'] * 0.85, 1)} kA", "—", "Ark akımı ani kademeyi geçmezse süre kısa gecikmeden gecikmeliye, enerji 5–10 katına çıkar", "saha pratiği", "ikincil"),
        S("Bakım kipi / ark azaltma ayarı", "çalışma sırasında ani kademe düşürülür, gecikmeler sıfırlanır", "—", "Seçicilik geçici olarak feda edilir, enerji düşer", "kesici üreticisi kılavuzu", "ikincil"),
        S("Ark rölesi", "ışık + akım, ≈ 70 ms toplam", "—", "Seçicilikten bağımsız en kısa süre", "Röle laboratuvarı › Ark koruması", "ikincil"),
        S("Uzaktan sürme / kapalı kapı manevrası", "mesafe artar", "—", "Mesafe iki katına çıkınca enerji 2–4 kat düşer", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Etiket", "Panonun üstünde: olay enerjisi, çalışma mesafesi, ark parlama sınırı, giysi düzeyi", f"{fnum(e, 1)} cal/cm² @ {fnum(d, 0)} mm · sınır {fnum(afb / 1000, 2)} m", "ayar ya da şebeke değişince yeniden hesaplanır"),
        T("Koruma süresinin doğrulanması", "Primer / sekonder enjeksiyonla ark akımı düzeyinde açma süresi", f"≈ {fnum(t * 1000, 0)} ms", "hesaptaki süre tutmuyorsa etiket geçersizdir"),
    ]
    ts = logsp(0.01, 2.0, 40)
    g1 = {"baslik": "Temizleme süresine göre olay enerjisi", "x_ad": "Süre (s)", "y_ad": "cal/cm²", "logx": True, "logy": True,
          "seriler": [{"ad": f"{fnum(d, 0)} mm", "renk": "#dc2626", "pts": pts(ts, [enerji(u, yer, ibf, x, d, toprakli)["e"] for x in ts], 3)},
                      {"ad": f"{fnum(d * 2, 0)} mm", "renk": "#1a4d8f", "kesik": True, "pts": pts(ts, [enerji(u, yer, ibf, x, d * 2, toprakli)["e"] for x in ts], 3)}],
          "yatay": [{"y": 1.2, "etiket": "yanık eşiği", "renk": "#15803d"}, {"y": 8, "etiket": "düzey 2", "renk": "#d97706"}, {"y": 40, "etiket": "düzey 4", "renk": "#dc2626"}], "isaretler": [{"x": t, "etiket": "koruma"}]}
    dd = logsp(200, 5000, 35)
    g2 = {"baslik": "Mesafeye göre olay enerjisi", "x_ad": "Mesafe (mm)", "y_ad": "cal/cm²", "logx": True, "logy": True,
          "seriler": [{"ad": v[0], "renk": rk, "kesik": k != kor, "pts": pts(dd, [enerji(u, yer, ibf, v[1], x, toprakli)["e"] for x in dd], 3)} for (k, v), rk in zip(list(KORUMA.items())[1:5], ("#15803d", "#1a4d8f", "#b45309", "#dc2626"))],
          "yatay": [{"y": 1.2, "etiket": "yanık eşiği", "renk": "#15803d"}], "isaretler": [{"x": d, "etiket": "çalışan"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Arkın saldığı enerjinin büyük bölümü ışınımdır: görünür ışık, morötesi ve kızılötesi. Karşısındaki yüzeye ulaşan miktar «olay enerjisi» olarak ölçülür: santimetre kareye kaç kalori düştüğü.",
            "1,2 cal/cm², bir çakmak alevinin parmağa bir saniye tutulması kadardır: çıplak deride ikinci derece yanığın başladığı yer. Olağan iş giysisi bundan fazlasında tutuşur ve yanığı büyütür.",
            f"Bu panoda ark akımı {fnum(r['ia'], 1)} kA. Koruma {fnum(t * 1000, 0)} ms'de temizliyor: {fnum(d, 0)} mm'deki kişiye {fnum(e, 1)} cal/cm² ulaşıyor.",
            "Enerji üç şeye bağlıdır. Akım: şebekeye aittir. Mesafe: işin niteliğine bağlıdır, uzaktan sürmeyle artırılabilir. Süre: korumanın ayarıdır ve enerjiyi doğrudan çarpar. Süreyi kısaltmak, giysiyi kalınlaştırmaktan her zaman daha etkilidir.",
            ("AG'de tuzak şudur: ark akımı kısa devre akımının yarısı kadardır. Koruma eğrisinde bu akım ani kademenin altına düşerse açma süresi 50 ms'den 300–600 ms'ye sıçrar; enerji on kat artar. En tehlikeli pano, kısa devre akımı en büyük olan değil, koruması en yavaş olandır."
             if u < 1 else "OG'de ark akımı kısa devre akımına yakındır; mesafe daha büyük, ama gecikmeler de (seçicilik için) daha uzundur."),
            "Ark dayanımlı giysi yaralanmayı sınırlar, olayı önlemez; basınç dalgasına ve erimiş metale karşı korumaz. Asıl önlem enerjisiz çalışmaktır; mümkün değilse süreyi kısaltmak ve mesafeyi artırmaktır.",
        ],
        "dersler": [
            "Olay enerjisi ∝ süre: 600 ms'lik gecikme, 60 ms'lik açmanın on katı yanık demektir.",
            "1,2 cal/cm² ikinci derece yanık eşiğidir; ark parlama sınırı bu enerjinin düştüğü mesafedir.",
            "AG'de süre ark akımına göre okunur, kısa devre akımına göre değil.",
            "En tehlikeli pano, koruması en yavaş olandır: çoğu zaman trafonun AG çıkışındaki ana pano.",
            "Önlem sırası: enerjiyi kes → süreyi kısalt → mesafeyi artır → koruyucu giysi.",
        ],
        "tablolar": [{"baslik": f"Korumaya göre olay enerjisi ({fnum(d, 0)} mm)", "cols": ["Koruma", "Süre", "Olay enerjisi", "Giysi düzeyi", "Ark parlama sınırı"],
                      "rows": [[v[0] + (" ◀" if k == kor else ""), f"{fnum(v[1] * 1000, 0)} ms", f"{fnum(q, 1)} cal/cm²", ("gerekmez" if q <= 1.2 else next((x[1] for x in KKD if q <= x[0]), "çalışılmaz")), f"{fnum(sinir_mesafe(u, yer, ibf, v[1], toprakli) / 1000, 2)} m"]
                               for k, v in KORUMA.items() for q in [enerji(u, yer, ibf, v[1], d, toprakli)["e"]]],
                      "not": "Akım sınırlayan sigortada akım da küçülür; gerçek enerji buradakinden düşüktür."},
                     {"baslik": "Koruyucu giysi düzeyleri", "cols": ["Olay enerjisi (en çok)", "Düzey", "Giysi"], "rows": [[f"{fnum(k[0], 1)} cal/cm²", k[1], k[2]] for k in KKD], "not": "NFPA 70E'deki düzeyler — asıl metinle doğrulanacak."}],
    }
