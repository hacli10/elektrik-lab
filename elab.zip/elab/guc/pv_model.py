"""PV modül modeli (GES sayfalarının ortak hesabı).

I–V eğrisi, veri sayfasındaki dört noktadan (Voc, Isc, Vmp, Imp) kurulan açık bağıntıyla çizilir:
    I = Isc · [1 − C1 · (exp(V / (C2·Voc)) − 1)],  C2 = (Vmp/Voc − 1) / ln(1 − Imp/Isc),  C1 = (1 − Imp/Isc) · exp(−Vmp / (C2·Voc))
Eğri (0, Isc), (Vmp, Imp) ve (Voc, 0) noktalarından geçer. Işınım ve sıcaklık düzeltmesi: akımlar ışınımla doğru orantılı ve α ile; gerilimler β (Voc) ve γ − α (Vmp)
sıcaklık katsayılarıyla ve ışınımın logaritmasıyla (n·Ns·kT/q · ln G) değişir. Hücre sıcaklığı: Tc = Ta + (NOCT − 20) · G / 800.

Modül değerleri piyasadaki tipik veri sayfalarının mertebesindedir (tahmini): belirli bir üreticinin ürünü değildir."""
from __future__ import annotations

import math

MODUL = {
    "m550": {"ad": "550 Wp · tek kristal PERC · 144 yarım hücre", "pmax": 550, "voc": 49.90, "isc": 13.98, "vmp": 41.96, "imp": 13.11, "a": 0.048, "b": -0.27, "g": -0.35,
             "noct": 45, "ns": 72, "alan": 2.58, "sigorta": 25, "vsis": 1500},
    "m450": {"ad": "450 Wp · tek kristal PERC · 144 yarım hücre", "pmax": 450, "voc": 49.30, "isc": 11.60, "vmp": 41.50, "imp": 10.85, "a": 0.048, "b": -0.27, "g": -0.35,
             "noct": 45, "ns": 72, "alan": 2.17, "sigorta": 20, "vsis": 1500},
    "m410": {"ad": "410 Wp · 108 yarım hücre (çatı tipi)", "pmax": 410, "voc": 37.30, "isc": 13.95, "vmp": 31.25, "imp": 13.12, "a": 0.048, "b": -0.27, "g": -0.35,
             "noct": 45, "ns": 54, "alan": 1.95, "sigorta": 25, "vsis": 1500},
    "n580": {"ad": "580 Wp · n-tipi TOPCon · 144 yarım hücre", "pmax": 580, "voc": 51.90, "isc": 14.25, "vmp": 43.30, "imp": 13.40, "a": 0.045, "b": -0.25, "g": -0.29,
             "noct": 43, "ns": 72, "alan": 2.58, "sigorta": 30, "vsis": 1500},
}
V_DIYOT = 0.5            # köprüleme (bypass) diyodunun iletim gerilimi (V)
N_ALT = 3                # modüldeki alt dizi (köprüleme diyodu) sayısı
R_TERS = 50.0            # Ω — diyotsuz, tamamı gölgeli bir alt dizinin ters yöndeki eşdeğer direnci (mertebe)


def secenek() -> list:
    return [{"id": k, "ad": v["ad"]} for k, v in MODUL.items()]


def hucre_sicakligi(ta: float, g: float, noct: float, ek: float = 0.0) -> float:
    """ek: montajdan gelen ek ısınma (çatıya yapışık montajda ≈ +10 K)."""
    return ta + (noct - 20.0) * g / 800.0 + ek * g / 1000.0


def nokta(m: dict, g: float, tc: float, bol: int = 1) -> dict:
    """Verilen ışınım (W/m²) ve hücre sıcaklığında (°C) eğrinin değerleri. bol: gerilimi bölen sayı (alt dizi için 3)."""
    gg = max(g, 1.0) / 1000.0
    dt = tc - 25.0
    isc = m["isc"] * gg * (1 + m["a"] / 100 * dt)
    imp = m["imp"] * gg * (1 + m["a"] / 100 * dt)
    vt = 0.0257 * 1.1 * m["ns"] * (tc + 273.0) / 298.0
    voc = m["voc"] * (1 + m["b"] / 100 * dt) + vt * math.log(gg)
    vmp = m["vmp"] * (1 + (m["g"] - m["a"]) / 100 * dt) + vt * math.log(gg)
    voc = max(voc, 0.2 * m["voc"])
    vmp = min(max(vmp, 0.1 * m["voc"]), 0.97 * voc)
    voc /= bol; vmp /= bol
    c2 = (vmp / voc - 1) / math.log(1 - imp / isc)
    c1 = (1 - imp / isc) * math.exp(-vmp / (c2 * voc))
    return {"isc": isc, "imp": imp, "voc": voc, "vmp": vmp, "pmp": vmp * imp, "c1": c1, "c2": c2}


def akim(v: float, n: dict) -> float:
    if v <= 0:
        return n["isc"]
    if v >= n["voc"]:
        return 0.0
    return max(n["isc"] * (1 - n["c1"] * (math.exp(v / (n["c2"] * n["voc"])) - 1)), 0.0)


def gerilim(i: float, n: dict):
    """Akıma karşılık gerilim; akım kısa devre akımını aşıyorsa None (hücre ters kutuplanır)."""
    if i >= n["isc"]:
        return None
    if i <= 0:
        return n["voc"]
    return n["c2"] * n["voc"] * math.log((1 - i / n["isc"]) / n["c1"] + 1)


def dizi_egri(gruplar: list, adim: int = 240, bypass: str = "saglam") -> dict:
    """Seri bağlı alt dizilerin ortak eğrisi. gruplar: [(alt dizi sayısı, nokta sözlüğü), …]. bypass: saglam | acik (diyot yok / açık devre arızalı).
    Dönen: {"v": […], "i": […], "p": […]} — akım 0'dan en büyük kısa devre akımına taranır."""
    imax = max(n["isc"] for _, n in gruplar)
    vs, is_, ps = [], [], []
    for k in range(adim + 1):
        i = imax * (1 - (1 - k / adim) ** 2) * 0.9995          # küçük akımlarda seyrek, dirsekte sık
        v = 0.0
        for adet, n in gruplar:
            g = gerilim(i, n)
            if g is None:
                g = -V_DIYOT if bypass == "saglam" else -min((i - n["isc"]) * R_TERS, 25.0 * n["voc"])
            v += adet * g
        if v < 0:
            break
        vs.append(v); is_.append(i); ps.append(v * i)
    return {"v": vs, "i": is_, "p": ps}


def tepeler(e: dict) -> list:
    """Güç eğrisindeki yerel tepeler: [(V, I, P), …] — gerilime göre azalan sırada (eğri akıma göre tarandığı için)."""
    p = e["p"]; out = []
    for k in range(1, len(p) - 1):
        if p[k] >= p[k - 1] and p[k] > p[k + 1] and p[k] > 0.02 * max(p):
            out.append((e["v"][k], e["i"][k], p[k]))
    if len(p) >= 2 and p[-1] > p[-2] and p[-1] > 0.02 * max(p):
        out.append((e["v"][-1], e["i"][-1], p[-1]))
    return out
