"""Trafonun sesi: çekirdeğin 100 Hz uğultusu nereden gelir; gerilim, yük, harmonikler, demeraj, gevşek parça ve faz kopması sesi nasıl değiştirir;
belli bir uzaklıkta kaç dB duyulur. Hesaplanan tayf tarayıcıda sese çevrilir (dinlenebilir).

Ses gücü düzeyleri (LwA) TEDAŞ şartnamelerinin toleranssız en yüksek değerleridir (99-032.E böl. 2.2.12, 99-031.B böl. 2.2.11). Olağan dışı sesin nedenleri
Siemens GEAFOL işletme kılavuzunun arıza çizelgesindendir. Sayısal düzeltmeler tipiktir (tahmini): aşırı uyarmada çekirdek sesi ≈ 130·log10(B/Bn) dB artar (%10 fazla akı ≈ +5 dB);
yük sesi ≈ 39 + 18·log10(Sn / 1 MVA) + 40·log10(I/In) dB(A) (TS EN 60076-10'daki kestirim bağıntısı — doğrulanacak); uzaklıkla azalma yansıtıcı zemin üzerinde
serbest alan Lp = Lw − 10·log10(2π·r²); kapalı odada yankı alanı Lp = Lw + 10·log10(2/(4π·r²) + 4/R)."""
from __future__ import annotations

import math

from .ortak import A, C, G, IEC10, K, S, SIEMENS_K, T, Cizim, ctl, db_topla, fnum, num, opt, pts, tr_al, tr_ctl

ID = "trafo_ses"
BASLIK = "Trafonun sesi"
IKON = "🔊"
GIRIS = ("Sağlıklı bir trafo düzgün, alçak bir uğultu çıkarır: şebeke frekansının iki katı, 100 Hz. Bu ses çekirdek sacının her yarım periyotta bir uzayıp kısalmasından gelir. "
         "Ses değiştiyse trafoda ya da şebekede bir şey değişmiştir. Durumu seçin, sesi dinleyin ve tayfına bakın.")
DURUM = {"normal": "Olağan çalışma", "asiri": "Aşırı uyarma (gerilim yüksek / kademe düşük)", "yuk": "Ağır yük", "harmonik": "Harmonikli yük (sürücü, doğrultucu)", "dc": "Enerjilendirme anı (demeraj)",
         "gevsek": "Gevşek parça (bara, mahfaza, sıkıştırma)", "faz": "OG'de bir faz kopuk"}
FREK = (100, 200, 300, 400, 500, 600)
TAYF = {"normal": (0, -7, -13, -18, -23, -27), "asiri": (0, -3, -6, -9, -12, -15), "yuk": (0, -6, -12, -17, -22, -26), "harmonik": (0, -4, -3, -8, -6, -10),
        "dc": (0, -2, -4, -6, -9, -12), "gevsek": (0, -6, -11, -14, -16, -18), "faz": (0, -9, -15, -20, -25, -29)}

KONTROLLER = tr_ctl() + [
    ctl("durum", "Durum", "sec", "normal", secenek=opt(*DURUM.items())),
    ctl("u", "Gerilim (kademe geriliminin yüzdesi)", "sayi", 100, min=90, max=112, adim=0.5, birim="%", goster={"durum": ["normal", "asiri", "yuk", "harmonik", "gevsek"]}),
    ctl("yuk", "Yük", "sayi", 60, min=0, max=150, adim=5, birim="%"),
    ctl("thd", "Yük akımının harmonik bozulması (THDi)", "sayi", 30, min=0, max=80, adim=5, birim="%", goster={"durum": ["harmonik"]}),
    ctl("r", "Dinleme uzaklığı", "sayi", 3, min=0.5, max=50, adim=0.5, birim="m"),
    ctl("oda", "Yer", "sec", "acik", secenek=opt(("acik", "Açık alan (direk tipi, köşk dışı)"), ("oda", "Kapalı trafo odası (yankılı)"))),
]


def duzey(tr: dict, durum: str, u: float, k: float, thd: float) -> dict:
    cekirdek = tr["lwa"] + 130 * math.log10(max(u, 0.5))
    yuk = 39 + 18 * math.log10(tr["sn"] / 1000) + 40 * math.log10(max(k, 0.05))
    ek = 0.0
    if durum == "harmonik":
        yuk += 20 * math.log10(1 + 3 * thd); cekirdek += 20 * math.log10(1 + thd)      # harmonik akılar çekirdeği de titretir
    elif durum == "dc":
        cekirdek += 15
    elif durum == "gevsek":
        ek = cekirdek + 3                                   # titreyen parça çekirdek kadar ses verir
    elif durum == "faz":
        cekirdek -= 3
    top = db_topla(cekirdek, yuk, ek) if ek else db_topla(cekirdek, yuk)
    return {"cekirdek": cekirdek, "yuk": yuk, "ek": ek, "top": top}


def basinc(lw: float, r: float, oda: bool) -> float:
    if oda:
        rs = 0.1 * 103 / 0.9                                # oda sabiti: 4×5×3,5 m, ortalama yutma 0,1
        return lw + 10 * math.log10(2 / (4 * math.pi * r * r) + 4 / rs)
    return lw - 10 * math.log10(2 * math.pi * r * r)


def ses(ad: str, aciklama: str, durum: str, siddet: float) -> dict:
    par = [{"f": f, "a": round(10 ** (d / 20), 4)} for f, d in zip(FREK, TAYF[durum])]
    x = {"ad": ad, "not": aciklama, "sure": 3.0, "zarf": "surekli", "siddet": round(min(max(siddet, 0.15), 1.0), 3), "parcalar": par}
    if durum == "dc":
        x.update(zarf="sonen", tau=0.7, taban=0.25, sure=3.5, parcalar=par + [{"f": 50, "a": 0.9}, {"f": 150, "a": 0.6}, {"f": 250, "a": 0.35}])
    elif durum == "gevsek":
        x.update(vuru=7, gurultu=0.35, gurultu_f=1800, citirti=0.02)
    elif durum == "harmonik":
        x["parcalar"] = par + [{"f": 700, "a": 0.25}, {"f": 1100, "a": 0.18}, {"f": 1300, "a": 0.14}]
    elif durum == "faz":
        x.update(vuru=1.5)
    return x


def run(p: dict) -> dict:
    tr = tr_al(p); kuru = tr["tip"] == "kuru"
    durum = str(p.get("durum", "normal"))
    u, k, thd, r, oda = num(p, "u", 100) / 100, num(p, "yuk", 60) / 100, num(p, "thd", 30) / 100, num(p, "r", 3), p.get("oda") == "oda"
    if durum == "asiri" and u < 1.05:
        u = 1.08
    if durum == "yuk" and k < 1.0:
        k = 1.2
    if durum in ("dc", "faz"):
        u = 1.0
    d = duzey(tr, durum, u, k, thd); d0 = duzey(tr, "normal", 1.0, max(k if durum != "yuk" else 0.6, 0.05), 0)
    lp, lp0 = basinc(d["top"], r, oda), basinc(d0["top"], r, oda)
    fark = d["top"] - d0["top"]
    c = Cizim(900, 300)
    c.dikdortgen(40, 90, 150, 150, "cizgi", "#fde68a" if kuru else "#fef9c3", kw=2.4); c.yazi(115, 170, f"{fnum(tr['sn'], 0)} kVA", "#475569", 12, kalin=True, anchor="middle")
    c.yazi(115, 80, f"LwA {fnum(d['top'], 0)} dB(A)", "#b91c1c" if fark > 3 else "#334155", 12.5, kalin=True, anchor="middle")
    for j in range(1, 5):
        c.daire(190, 165, 30 + j * 34, "mavi", w=1.2, kesik=True)
    xk = 190 + min(40 + r * 16, 330)
    c.kisi(xk, 262, xk - 12, 224, "ok")
    c.yazi(190 + min(40 + r * 16, 330), 96, f"{fnum(r, 1)} m: {fnum(lp, 0)} dB(A)", "#1d4ed8", 13, kalin=True, anchor="middle")
    c.yazi(560, 60, DURUM[durum], "#b91c1c" if durum != "normal" else "#15803d", 13, kalin=True)
    c.yazi(560, 84, f"Çekirdek sesi {fnum(d['cekirdek'], 0)} dB · yük (sargı) sesi {fnum(d['yuk'], 0)} dB", "#334155", 11.5)
    c.yazi(560, 106, f"Olağan duruma göre {'+' if fark >= 0 else '−'}{fnum(abs(fark), 1)} dB" + (" — iki kat gürültülü duyulur" if fark >= 9 else " — belirgin fark" if fark >= 3 else ""), "#b91c1c" if fark >= 3 else "#334155", 12, kalin=fark >= 3)
    c.yazi(560, 136, "Uzaklık iki katına çıkınca düzey " + ("yankılı odada çok az düşer." if oda else "6 dB düşer."), "#64748b", 11)
    c.yazi(560, 156, "10 dB artış, kulağa yaklaşık iki kat ses demektir.", "#64748b", 11)
    c.yazi(560, 190, "Sesi oluşturan: sacın boyunun akıyla değişmesi", "#334155", 11.5); c.yazi(560, 208, "(manyetostriksiyon). Akı periyotta iki kez tepe yapar:", "#334155", 11.5)
    c.yazi(560, 226, "temel ses 100 Hz, üstünde 200, 300, 400 Hz…", "#334155", 11.5)
    ozet = [
        K("Ses gücü düzeyi", f"{fnum(d['top'], 0)} dB(A)", "bad" if fark > 6 else "warn" if fark > 3 else "ok", f"şartname sınırı {fnum(tr['lwa'], 0)} dB(A) (anma geriliminde, boşta)"),
        K(f"{fnum(r, 1)} m'de ses basıncı", f"{fnum(lp, 0)} dB(A)", "info", "kapalı oda (yankılı)" if oda else "açık alan"),
        K("Olağan duruma göre", f"{'+' if fark >= 0 else '−'}{fnum(abs(fark), 1)} dB", "bad" if fark > 6 else "warn" if fark > 3 else "ok", f"olağan: {fnum(lp0, 0)} dB(A)"),
        K("Çekirdek sesi", f"{fnum(d['cekirdek'], 0)} dB", "info", f"akı %{fnum(u * 100, 1)}"),
        K("Yük sesi", f"{fnum(d['yuk'], 0)} dB", "info", f"yük %{fnum(k * 100, 0)}" + (f" · THDi %{fnum(thd * 100, 0)}" if durum == "harmonik" else "")),
    ]
    kontroller = [
        C("Ses gücü şartname sınırının içinde mi?", f"{fnum(d['top'], 0)} dB(A)", f"≤ {fnum(tr['lwa'], 0)} dB(A) (+3 dB'ye kadar işletme payı)", d["top"] <= tr["lwa"] + 3,
          "Çizelgedeki değerler en yüksek değerlerdir, tolerans uygulanmaz; anma geriliminde ve boşta ölçülür — " + tr["kaynak"] + (" böl. 2.2.11" if kuru else " böl. 2.2.12"), "resmi" if tr["kapsam"] else "tahmini"),
        C("Ses olağan mı?", DURUM[durum], "düzgün, sabit 100 Hz uğultu", durum == "normal", "Olağan dışı sesin nedenleri: gerilim kademe geriliminin üstünde · bara, mahfaza, zemin bağlantısı gevşek · çekirdekte serbest uç · duvar yansıması · yükte harmonik · aşırı yük — " + SIEMENS_K + " arıza çizelgesi", "resmi"),
        C("Aşırı uyarma", f"gerilim kademe geriliminin %{fnum(u * 100, 1)}'i", "≤ %105", u <= 1.05 + 1e-9, "Gerilim kademe geriliminin üstündeyse kademe yükseltilir — «Kademe değiştirme» sayfası", "ikincil"),
        C("Yük sesi çekirdek sesini geçiyor mu?", f"yük {fnum(d['yuk'], 0)} dB · çekirdek {fnum(d['cekirdek'], 0)} dB", "dağıtım trafosunda çekirdek sesi baskındır", d["yuk"] <= d["cekirdek"], IEC10 + " — yük sesi kestirim bağıntısı; doğrulanacak", "dogrulanacak"),
    ]
    girdiler = [
        G("Trafonun ses gücü düzeyi", f"{fnum(tr['lwa'], 0)} dB(A)", "Etiket / deney raporu; şartname çizelgesi", "Ses gücü kaynağın büyüklüğüdür; uzaklıktan bağımsızdır", "Lp = Lw − 10·log10(2π·r²)"),
        G("Gerilim ve kademe", f"%{fnum(u * 100, 1)}", "OG gerilim ölçüsü, kademe göstergesi", "Çekirdek sesi akıyla hızla artar", "≈ 130·log10(B/Bn) dB"),
        G("Yük ve harmonikler", f"%{fnum(k * 100, 0)}" + (f" · THDi %{fnum(thd * 100, 0)}" if durum == "harmonik" else ""), "AG analizörü", "Sargı sesi akımın karesiyle artar; harmonikler tayfı yukarı taşır", "40·log10(I/In) dB"),
        G("Yer ve uzaklık", f"{fnum(r, 1)} m · {'kapalı oda' if oda else 'açık alan'}", "Yerleşim planı", "Yankılı odada ses uzaklıkla azalmaz; duvar ve köşeler yükseltir", "oda sabiti R = α·S / (1 − α)"),
    ]
    adimlar = [
        A("Çekirdek sesi", "Lc = LwA + 130·log10(B / Bn)", f"{fnum(tr['lwa'], 0)} + 130·log10({fnum(u, 3)})" + (" + 15 (demeraj)" if durum == "dc" else ""), f"{fnum(d['cekirdek'], 1)} dB", "manyetostriksiyon akıyla hızla büyür — katsayı tipik", "tahmini", ["Trafonun ses gücü düzeyi", "Gerilim ve kademe"]),
        A("Yük (sargı) sesi", "Ly = 39 + 18·log10(Sn / 1 MVA) + 40·log10(I / In)", f"39 + 18·log10({fnum(tr['sn'] / 1000, 2)}) + 40·log10({fnum(k, 2)})", f"{fnum(d['yuk'], 1)} dB", IEC10 + " — doğrulanacak", "dogrulanacak", ["Yük ve harmonikler"]),
        A("Toplam", "L = 10·log10(Σ 10^(Li/10))", f"{fnum(d['cekirdek'], 1)} ⊕ {fnum(d['yuk'], 1)}" + (f" ⊕ {fnum(d['ek'], 1)}" if d["ek"] else ""), f"{fnum(d['top'], 1)} dB(A)", "bağımsız kaynakların enerjileri toplanır", "hesap"),
        A("Uzaklıkta ses basıncı", "Lp = Lw + 10·log10(2/(4π·r²) + 4/R)" if oda else "Lp = Lw − 10·log10(2π·r²)", f"r = {fnum(r, 1)} m" + (" · R ≈ 11 m²" if oda else ""), f"{fnum(lp, 1)} dB(A)", "yansıtıcı zemin üzerinde nokta kaynak" + (" + yankı alanı" if oda else ""), "hesap", ["Yer ve uzaklık"]),
    ]
    ayarlar = [
        S("Kademe", "şebeke gerilimine uygun kademe", "—", "Aşırı uyarma sesin ve boşta kaybın başlıca nedenidir", SIEMENS_K + " arıza çizelgesi"),
        S("Titreşim takozları / esnek AG bağlantısı", "trafo ayaklarında ve bara bağlantısında", "—", "Titreşimin zemine ve baraya geçmesini keser", SIEMENS_K + " böl. 6"),
        S("Harmonik süzgeci", "AG tarafında", "—", "Sürücü ve doğrultucu yüklerinde çekirdeğin dengesiz uyarılmasını azaltır", SIEMENS_K + " arıza çizelgesi"),
        S("Yerleşim", "köşeden ve duvardan uzak", "—", "Birbirine yakın cihazlar ve duvar yansımaları sesi üst üste bindirir", SIEMENS_K + " arıza çizelgesi"),
    ]
    test = [
        T("Dinleme", "1–3 m'den, yük ve gerilim not edilerek", "sabit, düzgün uğultu", "dalgalanma, tıkırtı, cızırtı olağan değildir"),
        T("Ses ölçümü", "Ses ölçer, A ağırlıklı; trafonun çevresinde birkaç noktada", f"{fnum(r, 1)} m'de ≈ {fnum(lp0, 0)} dB(A) (olağan)", "arka plan gürültüsü 10 dB daha düşük olmalı"),
        T("Cızırtı / çıtırtı", "Karanlıkta gözle, ultrasonik dinleyiciyle", "yok", "buşing ve kablo başlığında yüzeysel boşalma belirtisi: Topraklama laboratuvarı › Kısmi boşalma"),
        T("Tıkırtı", "Bara cıvataları, mahfaza sacları, tekerlek kilitleri", "hepsi sıkı", "gevşek sac 100 Hz'de titrer"),
    ]
    rs = [0.5 * 1.25 ** j for j in range(0, 22)]
    g1 = {"baslik": "Uzaklığa göre ses basıncı düzeyi", "x_ad": "Uzaklık (m)", "y_ad": "dB(A)", "logx": True,
          "seriler": [{"ad": "açık alan", "renk": "#1a4d8f", "kesik": oda, "pts": pts(rs, [basinc(d["top"], x, False) for x in rs], 1)},
                      {"ad": "kapalı oda", "renk": "#dc2626", "kesik": not oda, "pts": pts(rs, [basinc(d["top"], x, True) for x in rs], 1)}], "isaretler": [{"x": r, "etiket": "dinleyici"}]}
    us = [0.9 + j * 0.01 for j in range(0, 23)]
    g2 = {"baslik": "Gerilime ve yüke göre ses gücü", "x_ad": "Gerilim (% kademe gerilimi)", "y_ad": "LwA (dB)",
          "seriler": [{"ad": "boşta", "renk": "#1a4d8f", "pts": pts([x * 100 for x in us], [duzey(tr, "normal", x, 0.05, 0)["top"] for x in us], 1)},
                      {"ad": "anma yükünde", "renk": "#b45309", "pts": pts([x * 100 for x in us], [duzey(tr, "normal", x, 1.0, 0)["top"] for x in us], 1)},
                      {"ad": "%150 yükte", "renk": "#dc2626", "pts": pts([x * 100 for x in us], [duzey(tr, "normal", x, 1.5, 0)["top"] for x in us], 1)}],
          "isaretler": [{"x": u * 100, "etiket": "şimdi"}, {"x": 105, "etiket": "%105"}]}
    cub = {"baslik": "Sesin tayfı (bağıl düzey; 40 = en güçlü bileşen)", "kategoriler": [f"{f} Hz" for f in FREK], "y_ad": "bağıl dB",
           "seriler": [{"ad": "olağan", "renk": "#94a3b8", "deger": [40 + x for x in TAYF["normal"]]}, {"ad": DURUM[durum][:22], "renk": "#dc2626", "deger": [40 + x for x in TAYF[durum]]}]}
    sesler = [ses("Olağan uğultu", "100 Hz ve katları; sabit ve düzgün", "normal", 0.35)]
    if durum != "normal":
        ack = {"asiri": "aynı uğultu daha sert: üst harmonikler güçlenir", "yuk": "uğultu kalınlaşır ve yükselir", "harmonik": "uğultunun üstüne vızıltı biner", "dc": "ilk anda sert bir homurtu, saniyeler içinde olağana iner",
               "gevsek": "uğultunun üstünde titreyen, tıkırdayan bir ses", "faz": "uğultu alçalır ve dalgalanır"}[durum]
        sesler.append(ses(DURUM[durum], ack, durum, 0.35 * 10 ** (fark / 20)))
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2], "cubuklar": [cub], "ses": sesler,
        "anlatim": [
            "Çekirdek sacı mıknatıslandığında boyu milyonda birkaç oranında değişir (manyetostriksiyon). Akı bir periyotta iki kez tepe yaptığı için sac saniyede 100 kez uzayıp kısalır: trafonun temel sesi 100 Hz'dir.",
            "Uzama akıyla doğru orantılı değildir; bu yüzden 100 Hz'in yanında 200, 300, 400 Hz bileşenleri de vardır. Kulak bunlara 100 Hz'ten daha duyarlıdır: sesin «rengini» üst bileşenler belirler.",
            {"normal": "Olağan çalışmada ses sabittir ve yükle çok az değişir: dağıtım trafosunda çekirdek sesi sargı sesinden onlarca dB güçlüdür.",
             "asiri": f"Gerilim kademe geriliminin %{fnum(u * 100, 1)}'i: çekirdek doymaya yaklaşır, uzama hızla büyür. Ses hem yükselir hem sertleşir; çare kademeyi yükseltmektir.",
             "yuk": "Ağır yükte sargılar arasındaki kuvvet (akımın karesiyle) artar ve sargı sesi çekirdek sesine yaklaşır: uğultu kalınlaşır. Yük sesi yine 100 Hz'dir.",
             "harmonik": "Sürücü ve doğrultucu akımları 250, 350, 550 Hz… bileşenler taşır. Sargı kuvvetleri ve çekirdek akısı bu frekanslarda da titrer: uğultunun üstüne vızıltı biner, trafo ek kayıpla ısınır.",
             "dc": "Enerjilendirme anında akı tek yöne kayar ve çekirdek her periyodun bir yarısında doyar. Ses bir an için çok yükselir, tayfa 50 Hz ve tek katları girer; darbe söndükçe ses olağana döner.",
             "gevsek": "Gevşek bir bara, mahfaza sacı ya da sıkıştırma parçası 100 Hz'lik titreşimle tıkırdar. Ses trafonun elektriksel durumundan bağımsızdır; yükle ve sıcaklıkla gelip gidebilir.",
             "faz": "Bir faz kopunca bacakların akıları eşit olmaz: iki bacak az, biri tam uyarılır. Uğultu alçalır, tınısı değişir; motorlu yükte akım dalgalandıkça ses de dalgalanır."}[durum],
            f"Ses gücü kaynağa aittir; duyulan ses uzaklığa ve ortama bağlıdır. {'Kapalı odada duvarlardan yansıyan ses baskındır: uzaklaşmak düzeyi pek düşürmez.' if oda else 'Açık alanda uzaklık iki katına çıkınca düzey 6 dB düşer.'} {fnum(r, 1)} m'de {fnum(lp, 0)} dB(A).",
            "Kuru tip trafo aynı güçte yağlı trafodan 8–12 dB daha gürültülüdür: yağ ve tank sesi söndürür, dökme reçineli sargı ve açık çekirdek söndürmez.",
        ],
        "dersler": [
            "Trafonun sesi 100 Hz'dir, 50 Hz değil: sac her yarım periyotta bir uzar.",
            "Ses aniden ya da zamanla değiştiyse nedeni aranır: gerilim (kademe), yük, harmonik, gevşek parça.",
            "Aşırı uyarma hem sesi hem boşta kaybı artırır; ikisi birlikte artıyorsa kademe yanlıştır.",
            "Cızırtı ve çıtırtı uğultudan farklıdır: yüzeysel boşalma ya da ark belirtisidir ve bekletilmez.",
            "Kapalı odada sesi azaltmanın yolu yutucu yüzey ve titreşim yalıtımıdır; trafoyu uzaklaştırmak işe yaramaz.",
        ],
        "tablolar": [{"baslik": "Ses olağan dışıysa", "cols": ["Belirti", "Olası neden", "Yapılacak"],
                      "rows": [["Uğultu yüksek ve sert", "Primer gerilim kademe geriliminin üstünde", "Trafo enerjisizken kademe yükseltilir"], ["Tıkırtı, titreşim", "Bara iyi sabitlenmemiş; trafo zemine, mahfaza sacları gövdeye iyi bağlanmamış (rezonans)", "Bara, mahfaza ve taban bağlantıları sıkılır"],
                               ["Yüksek frekanslı titreme", "Çekirdekte ya da sıkıştırma parçalarında sıkılmamış serbest uç", "Sıkıştırma denetlenir, serbest uç yalıtkan malzemeyle bastırılır"],
                               ["Odada uğultu birikiyor", "Cihazlar birbirine yakın; duvar yansımaları üst üste biniyor", "Yerleşim düzenlenir"], ["Vızıltı", "Yükte frekans çevirici gibi harmonik üreten cihazlar", "AG tarafına süzgeç"],
                               ["Uğultu kalın ve yüksek", "Trafo aşırı yüklü", "Yük dengelenir, dağıtılır"]],
                      "not": "Nedenler ve çareler Siemens GEAFOL işletme kılavuzunun arıza çizelgesindendir; yağlı trafolar için de geçerlidir."}],
    }
