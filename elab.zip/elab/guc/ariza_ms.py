"""Bir arızanın milisaniyeleri: delinmeden arkın sönmesine kadar olan sıra — ilk tepe ve kuvvet, basınç tepesi, yanık eşiği, kablonun, bakırın ve çeliğin tutuşması,
rölenin algılaması, kesicinin açması. Aynı arıza farklı korumalarla ne kadar farklı biter.

Büyüklükler öbür arıza fiziği sayfalarındaki modellerden gelir (kuvvet, basınç, ark enerjisi, olay enerjisi). «≈ 100 ms'de kablo, 150 ms'de bakır, 200 ms'de çelik yanmaya başlar»
eşikleri ark koruması yayınlarında anılan saha kuralıdır (ikincil). Koruma süreleri tipiktir (tahmini): ark rölesi 7 ms, ani kademe 40 ms, kesici 60 ms, akım sınırlayan
sigorta ilk yarım periyotta."""
from __future__ import annotations

import math

from . import fizik as F
from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, num, opt, pts

ID = "ariza_ms"
BASLIK = "Bir arızanın milisaniyeleri"
IKON = "⏱"
GIRIS = ("Bir ark arızası göz açıp kapayıncaya kadar (≈ 150 ms) başlar, tepe yapar ve çoğu hasarı verir. O süre içinde sırayla neler olur ve koruma bu sıranın neresinde devreye girer? "
         "Olayı ve korumayı seçin; zaman çizgisinde hangi eşiklerin aşıldığına bakın.")
OLAY = {"og": ("OG hücresinde iç ark", 34.5, 30, True, 910, "og"), "ag": ("AG ana panoda ark", 0.4, 3, True, 610, "sg"), "acik": ("Açık havada izolatör atlaması", 34.5, 35, False, 2000, "acik")}
KORUMA = {"sinir": ("Akım sınırlayan sigorta", 2, 3), "ark": ("Ark rölesi + kesici", 7, 60), "ani": ("Ani aşırı akım + kesici", 40, 60), "gec": ("Gecikmeli aşırı akım (0,4 s) + kesici", 440, 60), "yedek": ("Yedek koruma (1 s) + kesici", 1040, 60)}

KONTROLLER = [
    ctl("olay", "Olay", "sec", "og", secenek=opt(*[(k, v[0]) for k, v in OLAY.items()])),
    ctl("ik", "Kısa devre akımı", "sayi", 16.0, min=2, max=50, adim=0.5, birim="kA"),
    ctl("koruma", "Koruma", "sec", "gec", secenek=opt(*[(k, v[0]) for k, v in KORUMA.items()])),
    ctl("kappa", "Tepe katsayısı κ", "sayi", 1.7, min=1.02, max=2.0, adim=0.02),
]


def run(p: dict) -> dict:
    olay, ik, kor, kappa = str(p.get("olay", "og")), num(p, "ik", 16.0), str(p.get("koruma", "gec")), num(p, "kappa", 1.7)
    oad, u, l, kapali, d, yer = OLAY[olay]
    kad, t_role, t_cb = KORUMA[kor]
    t_c = t_role + t_cb                                               # ms: arkın sönmesi
    if u < 1:
        ia = F.ieee1584(u, ik, 0.2, d, l * 10, True, True, 1.473)["ia"]; ua = min(F.ark_gerilimi(l), 0.75 * u * 1000 / math.sqrt(3))
    else:
        ia = ik * 0.98; ua = F.ark_gerilimi(l)
    p_ark = 3 * ua * ia * 1000 / 1e6
    sinirli = kor == "sinir"
    ip = kappa * math.sqrt(2) * ik * (0.35 if sinirli else 1.0)       # akım sınırlayan sigorta tepeyi keser
    b = F.basinc(p_ark, 0.6 if olay == "og" else 0.4, 120, 0.2, 0.10, dt_ms=0.25) if kapali else None
    x_ = {"og": 0.973, "sg": 1.473, "acik": 2.0}[yer]
    e_hiz = F.ieee1584(u, ik, 1.0, d, l * 10, kapali, True, x_)["e"]   # cal/cm² / s
    t_yanik = 1.2 / e_hiz * 1000 if e_hiz > 0 else 1e9
    e_top = p_ark * t_c / 1000 * (0.25 if sinirli else 1.0)
    olaylar = [
        (0.0, "Delinme / atlama", "yalıtkan iletkene dönüşür; ark kurulur"),
        (5.0, "Akımın ilk tepesi", f"{fnum(ip, 0)} kA: baralar ve mesnetler en büyük kuvveti görür"),
    ]
    if b:
        olaylar.append((b["t_kapak"] or 3.0, "Tahliye kapağı açılır", "bölme basıncı açma değerine vardı"))
        olaylar.append((b["t_tepe"], "Basınç tepesi", f"{fnum(b['tepe'], 2)} bar: kapılar ve mahfaza en büyük yükü görür"))
    olaylar += [
        (t_yanik, "Yanık eşiği aşılır", f"{fnum(d, 0)} mm'deki kişide 1,2 cal/cm²: ikinci derece yanık başlar"),
        (100.0, "Kablo yalıtkanı tutuşur", "PVC ve XLPE yanmaya başlar"),
        (150.0, "Bakır yanar", "bara ve kontaklar erir, damlar"),
        (200.0, "Çelik yanar", "mahfaza sacı delinir; ark dışarı çıkar"),
        (float(t_role), "Koruma algılar ve açma verir", kad),
        (float(t_c), "Kesici açar: ark söner", f"toplam {fnum(e_top, 2)} MJ açığa çıktı"),
    ]
    olaylar.sort(key=lambda x: x[0])
    gecti = [o for o in olaylar if o[0] <= t_c + 1e-9]
    asilan = [o[1] for o in gecti if o[1] in ("Yanık eşiği aşılır", "Kablo yalıtkanı tutuşur", "Bakır yanar", "Çelik yanar")]
    hasar = ("Donanım yeniden kullanılabilir: yüzey temizliği ve denetim" if t_c < 100 else "Kablo ve yalıtkan parçalar değişir; bara onarılır" if t_c < 150 else
             "Bara ve kontaklar değişir; bölme yenilenir" if t_c < 200 else "Hücre / pano yenilenir; ark bölmenin dışına çıkmıştır")
    c = Cizim(900, 330)
    tmax = max(t_c * 1.15, 260.0)
    x0, x1, yz = 50, 860, 170
    X = lambda t: x0 + (x1 - x0) * min(t, tmax) / tmax                # noqa: E731
    c.hat(f"M{x0},{yz} H{x1}", "cizgi", w=3)
    c.alan(f"M{x0},{yz - 8} H{X(t_c):.0f} V{yz + 8} H{x0} Z", "ariza", 0.35)
    for k in range(0, int(tmax) + 1, 50 if tmax < 700 else 200):
        c.hat(f"M{X(k):.0f},{yz - 5} v10", "cizgi", w=1.2); c.yazi(X(k), yz + 26, f"{k}", "#64748b", 10, anchor="middle")
    c.yazi(x1, yz + 44, "ms", "#64748b", 10, anchor="end")
    gosterilen = [o for o in olaylar if o[0] <= tmax]
    for j, (t, ad, _) in enumerate(gosterilen):
        ust = j % 2 == 0
        seviye = (j // 2) % 3
        y = yz - 34 - seviye * 30 if ust else yz + 62 + seviye * 30
        once = t <= t_c + 1e-9
        c.hat(f"M{X(t):.0f},{yz} V{y + (6 if ust else -12)}", "ariza" if once else "soluk", w=1.4, kesik=not once)
        c.daire(X(t), yz, 4, "ariza" if once else "soluk", "#dc2626" if once else "#fff", w=1.4)
        c.yazi(min(max(X(t), 90), 800), y, f"{fnum(t, 0)} ms — {ad}", "#b91c1c" if once else "#94a3b8", 10.5, kalin=ad.startswith("Kesici"), anchor="middle")
    c.yazi(50, 26, f"{oad} · {fnum(ik, 1)} kA · {kad}", "#334155", 13, kalin=True)
    c.yazi(50, 46, f"Ark {fnum(t_c, 0)} ms yandı: {fnum(e_top, 2)} MJ. {hasar}.", "#b91c1c" if t_c >= 100 else "#15803d", 12, kalin=True)
    ozet = [
        K("Arkın süresi", f"{fnum(t_c, 0)} ms", "ok" if t_c < 100 else "bad", f"algılama {t_role} ms + açma {t_cb} ms"),
        K("Açığa çıkan enerji", f"{fnum(e_top, 2)} MJ", "ok" if e_top < 0.25 else "warn" if e_top < 2 else "bad", f"ark gücü {fnum(p_ark, 1)} MW"),
        K("Aşılan eşikler", str(len(asilan)), "ok" if not asilan else "bad", ", ".join(x.split(" ")[0].lower() for x in asilan) or "hiçbiri"),
        K("İlk tepe", f"{fnum(ip, 0)} kA", "warn", "5 ms'de: korumadan bağımsız" + (" (sigorta kesti)" if sinirli else "")),
        K("Basınç tepesi", f"{fnum(b['tepe'], 2)} bar" if b else "—", "warn" if b else "info", f"{fnum(b['t_tepe'], 0)} ms'de" if b else "açık hava"),
    ]
    kontroller = [
        C("Ark, kablo tutuşmadan söndü mü?", f"{fnum(t_c, 0)} ms", "< 100 ms", t_c < 100, "Ark koruması yayınlarındaki saha kuralı: ≈ 100 ms'de kablo, 150 ms'de bakır, 200 ms'de çelik yanmaya başlar", "ikincil"),
        C("Ark, mahfaza delinmeden söndü mü?", f"{fnum(t_c, 0)} ms", "< 200 ms", t_c < 200, "Çelik sac delindiğinde sıcak gaz ve erimiş metal bölmenin dışına çıkar", "ikincil"),
        C("Yanık eşiği aşılmadan söndü mü?", f"eşik {fnum(t_yanik, 0)} ms'de", f"ark {fnum(t_c, 0)} ms", t_c < t_yanik, f"{fnum(d, 0)} mm'deki kişi için olay enerjisi 1,2 cal/cm² — «Ark parlaması» sayfasındaki bağıntı (doğrulanacak)", "dogrulanacak"),
        C("İlk tepe ve basınç", f"{fnum(ip, 0)} kA · " + (f"{fnum(b['tepe'], 2)} bar" if b else "açık hava"), "korumadan bağımsız", None, "İlk 5–30 ms'de olan olayları yalnız akım sınırlayan cihaz ve donanımın yapısı (tepe dayanım akımı, tahliye) karşılar", "hesap"),
    ]
    girdiler = [
        G("Kısa devre akımı", f"{fnum(ik, 1)} kA", "Kısa devre hesabı", "Olayın ölçeğini belirler", "ark gücü, kuvvet, basınç"),
        G("Koruma zinciri", f"{kad}: {t_role} + {t_cb} ms", "Röle ayarı, kesici kataloğu", "Arkın ne kadar yanacağını belirler", "t = algılama + açma"),
    ]
    adimlar = [
        A("Ark gücü", "P = 3 · U(ark) · I", f"3 × {fnum(ua, 0)} V × {fnum(ia, 1)} kA", f"{fnum(p_ark, 1)} MW", "«Ark enerjisi» sayfası", "tahmini", ["Kısa devre akımı"]),
        A("Arkın süresi", "t = algılama + kesici", f"{t_role} + {t_cb}", f"{fnum(t_c, 0)} ms", "koruma zinciri", "tahmini", ["Koruma zinciri"]),
        A("Enerji", "E = P · t", f"{fnum(p_ark, 1)} MW × {fnum(t_c / 1000, 3)} s" + (" × 0,25 (akım sınırlama)" if sinirli else ""), f"{fnum(e_top, 2)} MJ", "güç sabit alınır", "hesap"),
        A("Yanık eşiğine varış", "t = 1,2 cal/cm² / (enerji hızı)", f"{fnum(e_hiz, 1)} cal/cm² / s", f"{fnum(t_yanik, 0)} ms", "«Ark parlaması» sayfası", "dogrulanacak"),
    ]
    ayarlar = [
        S("Ark rölesi", "ışık + akım: 7 ms", "—", "Toplam süreyi kesici süresine indirir (≈ 70 ms): bütün yanma eşiklerinin altında", "Röle laboratuvarı › Ark koruması", "ikincil"),
        S("Ani kademe / ters kilitleme", "40–100 ms", "—", "Seçicilik gecikmesini bara arızasında kaldırır", "Röle laboratuvarı › Ters kilitleme", "ikincil"),
        S("Akım sınırlayan sigorta", "< 10 ms, tepeyi de keser", "—", "Kuvvet ve basıncı da azaltabilen tek koruma", "«Akım sınırlama» sayfası", "ikincil"),
    ]
    ts = [k * 5.0 for k in range(0, int(tmax / 5) + 1)]
    g1 = {"baslik": "Açığa çıkan enerji ve korumaların temizleme anları", "x_ad": "Zaman (ms)", "y_ad": "Enerji (MJ)", "zaman": True, "ymin": 0,
          "seriler": [{"ad": "ark enerjisi (koruma açmasaydı)", "renk": "#94a3b8", "kesik": True, "pts": pts(ts, [p_ark * t / 1000 for t in ts], 3)},
                      {"ad": "bu korumayla", "renk": "#dc2626", "pts": pts(ts, [p_ark * min(t, t_c) / 1000 * (0.25 if sinirli else 1.0) for t in ts], 3)}],
          "isaretler": [{"x": v[1] + v[2], "etiket": v[0].split(" ")[0]} for v in KORUMA.values() if v[1] + v[2] <= tmax]}
    grafikler = [g1]
    if b:
        grafikler.append({"baslik": "Bölme basıncı (ilk 120 ms)", "x_ad": "Zaman (ms)", "y_ad": "Basınç (bar)", "zaman": True, "ymin": 0,
                          "seriler": [{"ad": "basınç", "renk": "#7c3aed", "pts": pts(b["t"], [max(x, 0) for x in b["p"]], 3, adim=4)}]})
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "sahne": c.sahne(), "grafikler": grafikler,
        "test": [T("Olay kaydı", "Rölenin arıza kaydı: başlangıç, açma komutu, akımın sıfırlanması", f"toplam ≈ {fnum(t_c, 0)} ms", "ölçülen süre ayarlanandan uzunsa kesici ya da yardımcı röle yavaştır"),
                 T("Kesici açma süresi", "Kesici analizörü", f"≈ {t_cb} ms", "bakımsız kesicide süre uzar: ark koruması bile işe yaramaz")],
        "anlatim": [
            "Sıfırıncı milisaniye: yalıtım bir noktada pes eder. Bir kıvılcım, akımı taşıyan bir arka dönüşür; ark, şebekenin verebildiği bütün akımı çeker.",
            f"Beşinci milisaniye: akım ilk tepesindedir ({fnum(ip, 0)} kA). Baralar arasındaki kuvvet bu anda en büyüktür. Hiçbir röle henüz karar vermemiştir; bu yükü donanımın kendisi taşır.",
            (f"On ile otuz milisaniye arası: kapalı bölmede basınç tepe yapar ({fnum(b['tepe'], 2)} bar, {fnum(b['t_tepe'], 0)} ms). Tahliye kapağı açılır, gaz dışarı atılır. Bu da korumadan önce olup biter." if b else
             "Açık havada basınç birikmez: ses ve ışık vardır, ama gaz serbestçe genleşir. Ark manyetik kuvvetle uzar ve yukarı kaçar."),
            f"Sonrası bir yarıştır. Ark her milisaniyede {fnum(p_ark, 0)} kJ ısı salar. Yaklaşık 100 ms'de kablo yalıtkanı tutuşur, 150 ms'de bakır erir ve yanar, 200 ms'de çelik sac delinir. {fnum(d, 0)} mm'deki bir kişi için yanık eşiği {fnum(t_yanik, 0)} ms'de aşılır.",
            f"Seçili koruma arkı {fnum(t_c, 0)} ms'de söndürüyor: {('eşiklerin hiçbiri aşılmadan.' if not asilan else 'bu arada şunlar oldu: ' + ', '.join(x.lower() for x in asilan) + '.')} {hasar}.",
            "Gecikmeli aşırı akım koruması seçicilik için bekler; ark beklemez. Ark rölesi, ters kilitleme ve akım sınırlayan sigorta bu yüzden vardır: aynı arıza 70 ms'de bir temizlik işi, 500 ms'de bir yenileme işidir.",
        ],
        "dersler": [
            "İlk 30 ms (kuvvet ve basınç) donanımın yapısına, sonrası (yanma) korumanın hızına aittir.",
            "Saha kuralı: 100 ms kablo, 150 ms bakır, 200 ms çelik.",
            "Kesicinin kendisi 50–60 ms alır: ark rölesi bile bunun altına inemez. Daha hızlısı akım sınırlayan sigortadır.",
            "Seçicilik gecikmesi normal arızada erdemdir, ark arızasında kusur: ikisi ayrı korumalarla çözülür.",
        ],
        "tablolar": [{"baslik": "Zaman çizelgesi", "cols": ["Zaman", "Olay", "Açıklama", "Durum"],
                      "rows": [[f"{fnum(t, 0)} ms", ad, ack, "oldu" if t <= t_c + 1e-9 else "ark söndüğü için olmadı"] for t, ad, ack in olaylar]},
                     {"baslik": "Aynı arıza, farklı koruma", "cols": ["Koruma", "Arkın süresi", "Enerji", "Sonuç"],
                      "rows": [[v[0] + (" ◀" if k == kor else ""), f"{v[1] + v[2]} ms", f"{fnum(p_ark * (v[1] + v[2]) / 1000 * (0.25 if k == 'sinir' else 1.0), 2)} MJ",
                                ("temizlik ve denetim" if v[1] + v[2] < 100 else "kablo ve yalıtkanlar değişir" if v[1] + v[2] < 150 else "bara ve kontaklar değişir" if v[1] + v[2] < 200 else "hücre / pano yenilenir")] for k, v in KORUMA.items()]}],
    }
