"""GES üretimi: güneşin gün içindeki yolu, eğim ve yön, sıcaklık kaybı, eviricinin kırpması (DC/AC oranı) ve yıllık enerji.

Model: açık gökyüzü ışınımı (hava kütlesine bağlı doğrudan ışınım, %10 yayılı ışınım), eğik düzleme geliş açısı, bulutluluk için aylık ortalama çarpanlar, hücre sıcaklığı
(NOCT), güç sıcaklık katsayısı, sabit kirlenme ve DC kayıpları (%5), evirici verimi %98, AC gücünde kırpma ve AC kayıpları (%1,5). Yıllık hesapta her ay, açık ve kapalı günlerin karışımı sayılır. Bulutluluk çarpanları ve aylık sıcaklıklar İç Anadolu için kaba
ortalamalardır (tahmini): sonuçlar öğretim içindir, fizibilite için ölçülmüş ışınım verisi (PVGIS, Meteonorm, saha ölçümü) kullanılır.
Dayanak (metinden): TEDAŞ LÜY 50 kWe GES Tip Şartnamesi böl. 2.3.4.1 (evirici / üreteç güç oranı genellikle %80–%120; farklı yön ve eğimdeki diziler ayrı MPPT girişlerine)."""
from __future__ import annotations

import math

from . import pv_model as PV
from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, num, opt, pts

ID = "uretim"
BASLIK = "GES üretimi ve evirici kırpması"
IKON = "📈"
GIRIS = ("Bir santralin ürettiği enerji etiket gücüyle değil, güneşin o gün izlediği yolla, modülün baktığı yönle, sıcaklıkla ve eviricinin gücüyle belirlenir. "
         "Ayı, eğimi, yönü ve DC/AC oranını değiştirin; günlük eğrinin biçimini, öğle saatlerinde eviricinin kırptığı bölümü ve yıllık enerjiyi izleyin.")

GES = "TEDAŞ LÜY 50 kWe GES Tip Şartnamesi"
AYLAR = ("Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık")
GUN_NO = (17, 47, 75, 105, 135, 162, 198, 228, 258, 288, 318, 344)
GUN_SAY = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
BULUT = (0.40, 0.45, 0.52, 0.58, 0.66, 0.78, 0.86, 0.85, 0.78, 0.62, 0.48, 0.38)          # doğrudan ışınımın aylık ortalama payı
T_AY = (0.5, 2.0, 6.5, 11.5, 16.0, 20.0, 23.5, 23.5, 19.0, 13.0, 6.5, 2.5)                # 39° enlem, °C
ETA_EV, K_DC, K_AC = 0.98, 0.95, 0.985          # evirici verimi · DC tarafı (yansıma, uyumsuzluk, kablo) · AC tarafı (kablo, trafo)

KONTROLLER = [
    ctl("modul", "Modül", "sec", "m550", secenek=PV.secenek()),
    ctl("pdc", "Kurulu DC gücü", "sayi", 125, min=5, max=2000, adim=5, birim="kWp"),
    ctl("pac", "Evirici AC gücü", "sayi", 100, min=5, max=2000, adim=5, birim="kW"),
    ctl("enlem", "Enlem", "sayi", 39, min=36, max=42, adim=0.5, birim="°K"),
    ctl("egim", "Modül eğimi", "sayi", 25, min=0, max=60, adim=1, birim="°"),
    ctl("yon", "Yön (0: güney · −90: doğu · +90: batı)", "sayi", 0, min=-90, max=90, adim=5, birim="°"),
    ctl("ay", "Ay", "sec", 6, secenek=opt(*[(k + 1, a) for k, a in enumerate(AYLAR)])),
    ctl("hava", "Hava", "sec", "acik", secenek=opt(("acik", "Açık gün"), ("ort", "Ayın ortalama günü"), ("kapali", "Kapalı gün"))),
    ctl("kir", "Kirlenme kaybı", "sayi", 3, min=0, max=15, adim=1, birim="%"),
]


def gun(ay: int, lat: float, tilt: float, az: float, f: float, m: dict, pdc: float, pac: float, kir: float, adim: float = 0.25) -> dict:
    """Bir günün eğrisi. Dönen: saatler, ışınım (W/m²), DC gücü (kW, kırpılmamış), AC gücü (kW) ve günlük toplamlar (kWh)."""
    d = math.radians(23.45 * math.sin(2 * math.pi * (284 + GUN_NO[ay - 1]) / 365))
    fi, b, g = math.radians(lat), math.radians(tilt), math.radians(az)
    ta_ort = T_AY[ay - 1] + (39 - lat) * 1.5
    ts, gs, pds, pas, tcs = [], [], [], [], []
    e_isin = e_stc = e_dc = e_ac = 0.0
    t = 4.0
    while t <= 20.0001:
        w = math.radians(15 * (t - 12))
        sa = math.sin(fi) * math.sin(d) + math.cos(fi) * math.cos(d) * math.cos(w)
        gt = 0.0
        if sa > 0.01:
            alt = math.degrees(math.asin(sa))
            am = 1 / (sa + 0.50572 * (alt + 6.07995) ** -1.6364)
            dni = 1353 * 0.7 ** (am ** 0.678)
            dhi0 = 0.1 * dni
            ghi0 = dni * sa + dhi0
            dhi = dhi0 + (1 - f) * 0.30 * ghi0
            ghi = f * dni * sa + dhi
            ct = (math.sin(d) * math.sin(fi) * math.cos(b) - math.sin(d) * math.cos(fi) * math.sin(b) * math.cos(g) + math.cos(d) * math.cos(fi) * math.cos(b) * math.cos(w)
                  + math.cos(d) * math.sin(fi) * math.sin(b) * math.cos(g) * math.cos(w) + math.cos(d) * math.sin(b) * math.sin(g) * math.sin(w))
            gt = f * dni * max(ct, 0.0) + dhi * (1 + math.cos(b)) / 2 + 0.2 * ghi * (1 - math.cos(b)) / 2
        ta = ta_ort + 5 * math.cos(2 * math.pi * (t - 15) / 24)
        tc = PV.hucre_sicakligi(ta, gt, m["noct"])
        p_stc = pdc * gt / 1000
        p_dc = p_stc * (1 + m["g"] / 100 * (tc - 25)) * (1 - kir / 100) * K_DC
        p_ac = min(p_dc * ETA_EV, pac) * K_AC
        ts.append(t); gs.append(gt); pds.append(p_dc); pas.append(p_ac); tcs.append(tc)
        e_isin += gt * adim / 1000; e_stc += p_stc * adim; e_dc += p_dc * adim; e_ac += p_ac * adim
        t += adim
    return {"t": ts, "g": gs, "pdc": pds, "pac": pas, "tc": tcs, "h": e_isin, "e_stc": e_stc, "e_dc": e_dc, "e_ac": e_ac}


def yil(lat, tilt, az, m, pdc, pac, kir) -> dict:
    ay_e, e_stc, e_dc, e_ac, h = [], 0.0, 0.0, 0.0, 0.0
    for a in range(1, 13):
        c = max((BULUT[a - 1] - 0.15) / 0.85, 0.0)                 # ayın açık günlerinin payı; kalanı kapalı gün (kırpma açık günlerde olur)
        e_a = 0.0
        for f, pay in ((1.0, c), (0.15, 1 - c)):
            r = gun(a, lat, tilt, az, f, m, pdc, pac, kir, 0.5)
            gs = GUN_SAY[a - 1] * pay
            e_a += r["e_ac"] * gs
            e_stc += r["e_stc"] * gs; e_dc += r["e_dc"] * gs; e_ac += r["e_ac"] * gs; h += r["h"] * gs
        ay_e.append(e_a)
    return {"ay": ay_e, "e_stc": e_stc, "e_dc": e_dc, "e_ac": e_ac, "h": h}


def run(p: dict) -> dict:
    mk = str(p.get("modul", "m550")); m = PV.MODUL.get(mk, PV.MODUL["m550"])
    pdc, pac, lat, tilt, az = num(p, "pdc", 125), num(p, "pac", 100), num(p, "enlem", 39), num(p, "egim", 25), num(p, "yon", 0)
    ay, hava, kir = int(min(max(num(p, "ay", 6), 1), 12)), str(p.get("hava", "acik")), num(p, "kir", 3)
    f = {"acik": 1.0, "ort": BULUT[ay - 1], "kapali": 0.08}.get(hava, 1.0)
    r = gun(ay, lat, tilt, az, f, m, pdc, pac, kir)
    y = yil(lat, tilt, az, m, pdc, pac, kir)
    oran = pdc / pac
    ev_oran = pac / pdc * 100
    p_tepe, pdc_tepe = max(r["pac"]), max(r["pdc"])
    pac_net = pac * K_AC
    kirp_gun = (1 - r["e_ac"] / (r["e_dc"] * ETA_EV * K_AC)) * 100 if r["e_dc"] > 0 else 0.0
    kirp_yil = (1 - y["e_ac"] / (y["e_dc"] * ETA_EV * K_AC)) * 100
    sic_gun = (1 - r["e_dc"] / (r["e_stc"] * (1 - kir / 100) * K_DC)) * 100 if r["e_stc"] > 0 else 0.0
    verim_y = y["e_ac"] / pdc                                    # kWh/kWp·yıl
    pr = y["e_ac"] / y["e_stc"]
    t_kirp = sum(0.25 for q in r["pdc"] if q * ETA_EV > pac * 1.0001)
    tc_max = max(r["tc"])
    k_tepe = r["pac"].index(p_tepe)
    cz = Cizim(900, 320)
    cz.hat("M40,200 H430", "toprak", w=2)
    # güneşin yolu (şematik yay) ve modül
    cz.hat("M60,200 Q235,-30 410,200", "uyari", w=1.5, kesik=True)
    gy = max(r["g"]); xg = 60 + 350 * (r["t"][r["g"].index(gy)] - 4) / 16
    cz.daire(xg, 200 - 190 * 4 * ((xg - 60) / 350) * (1 - (xg - 60) / 350) * 0.6, 14, "uyari", "#fde68a")
    bx, by = 235, 200
    ex, ey = bx + 70 * math.cos(math.radians(tilt)), by - 70 * math.sin(math.radians(tilt))
    cz.hat(f"M{bx - 35 * math.cos(math.radians(tilt)):.0f},{by - 6 + 35 * math.sin(math.radians(tilt)) - 0:.0f} L{ex - 35 * math.cos(math.radians(tilt)):.0f},{ey - 6 + 35 * math.sin(math.radians(tilt)):.0f}", "#1e3a8a", w=7)
    cz.yazi(235, 222, f"eğim {fnum(tilt, 0)}° · yön {fnum(az, 0)}°", "#334155", 11, anchor="middle")
    cz.yazi(60, 222, "doğu", "#94a3b8", 10); cz.yazi(410, 222, "batı", "#94a3b8", 10, anchor="end")
    cz.yazi(40, 40, f"{AYLAR[ay - 1]} · {fnum(lat, 1)}° K · " + {"acik": "açık gün", "ort": "ortalama gün", "kapali": "kapalı gün"}.get(hava, ""), "#334155", 12, kalin=True)
    cz.kutu(470, 40, 130, 54, "PV dizileri", f"{fnum(pdc, 0)} kWp")
    cz.hat("M600,67 H650", "L1", hot=p_tepe > 0, w=3)
    cz.kutu(650, 40, 130, 54, "Evirici", f"{fnum(pac, 0)} kW", "vurgu" if t_kirp > 0 else "normal")
    cz.hat("M780,67 H860", "L1", hot=p_tepe > 0, w=3)
    cz.yazi(625, 118, f"DC/AC = {fnum(oran, 2)}", "#b45309" if oran > 1.25 or oran < 0.83 else "#334155", 12, kalin=True, anchor="middle")
    cz.yazi(470, 150, f"Günlük enerji {fnum(r['e_ac'], 0)} kWh ({fnum(r['e_ac'] / pdc, 2)} kWh/kWp)", "#15803d", 13, kalin=True)
    cz.yazi(470, 174, f"En yüksek AC gücü {fnum(p_tepe, 0)} kW (saat {fnum(r['t'][k_tepe], 1)}) · DC {fnum(pdc_tepe, 0)} kW", "#334155", 12)
    cz.yazi(470, 198, (f"Evirici {fnum(t_kirp, 1)} saat kırpıyor: günün %{fnum(kirp_gun, 1)} kadarı" if t_kirp > 0 else "Evirici bu gün kırpmıyor"), "#b45309" if t_kirp > 0 else "#64748b", 12, kalin=t_kirp > 0)
    cz.yazi(470, 222, f"Sıcaklık kaybı %{fnum(sic_gun, 1)} (hücre en çok {fnum(tc_max, 0)} °C)", "#64748b", 12)
    cz.yazi(40, 262, f"Yıllık: {fnum(y['e_ac'] / 1000, 1)} MWh · {fnum(verim_y, 0)} kWh/kWp · başarım oranı {fnum(pr, 2)}", "#1d4ed8", 13, kalin=True)
    cz.yazi(40, 288, f"Yıllık kırpma kaybı %{fnum(kirp_yil, 1)} · düzleme düşen ışınım {fnum(y['h'], 0)} kWh/m²·yıl", "#64748b", 12)
    ozet = [
        K("Günlük enerji", f"{fnum(r['e_ac'], 0)} kWh", "info", f"{fnum(r['e_ac'] / pdc, 2)} kWh/kWp · ışınım {fnum(r['h'], 1)} kWh/m²"),
        K("En yüksek AC gücü", f"{fnum(p_tepe, 0)} kW", "warn" if t_kirp > 0 else "info", f"DC {fnum(pdc_tepe, 0)} kW · evirici {fnum(pac, 0)} kW"),
        K("Kırpma kaybı", f"%{fnum(kirp_gun, 1)} (gün)", "warn" if kirp_yil > 3 else "info", f"yıllık %{fnum(kirp_yil, 1)}"),
        K("Yıllık enerji", f"{fnum(y['e_ac'] / 1000, 1)} MWh", "info", f"{fnum(verim_y, 0)} kWh/kWp"),
        K("Başarım oranı (PR)", fnum(pr, 2), "ok" if pr >= 0.75 else "warn", "AC enerji / (ışınım × etiket gücü)"),
    ]
    kontroller = [
        C("Evirici / üreteç güç oranı olağan aralıkta mı?", f"%{fnum(ev_oran, 0)} (DC/AC = {fnum(oran, 2)})", "%80 – %120", 80 <= ev_oran <= 120,
          f"{GES} böl. 2.3.4.1: evirici anma gücünün PV üreteç gücünden küçük olması genel uygulamadır; Türkiye'de evirici/üreteç güç oranı genellikle %80–%120 aralığında seçilir", "resmi"),
        C("Yıllık kırpma kaybı kabul edilebilir mi?", f"%{fnum(kirp_yil, 1)}", "≲ %3", kirp_yil <= 3.0,
          "Modül yılın çoğunda etiket gücüne ulaşmaz; evirici küçük seçilince yalnız en parlak saatler kırpılır. %3'ün üstü, eviricinin fazla küçük olduğunu gösterir (uygulama ölçütü)", "ikincil"),
        C("Başarım oranı", fnum(pr, 2), "≥ 0,75", pr >= 0.75, "İyi tasarlanmış santralde 0,78–0,85. Düşükse: sıcaklık, kirlenme, kırpma, gölge ya da arıza", "ikincil"),
        C("Hücre sıcaklığı", f"en çok {fnum(tc_max, 0)} °C", "≤ 85 °C", tc_max <= 85, "Modül veri sayfalarındaki çalışma sıcaklığı üst sınırı", "ikincil"),
        C("Eğim yıllık üretim için uygun mu?", f"{fnum(tilt, 0)}°", f"enlemin ≈ 10° altı ({fnum(lat - 10, 0)}°) dolayında en yüksek", abs(tilt - (lat - 10)) <= 15,
          "Yaz ışınımı baskın olduğu için yıllık en iyi eğim enlemden küçüktür; kış üretimi isteniyorsa eğim artırılır. Aşağıdaki çizelge bu enlem için hesaplanmıştır", "hesap"),
    ]
    girdiler = [
        G("Yer ve zaman", f"{fnum(lat, 1)}° K · {AYLAR[ay - 1]}", "Saha koordinatı", "Güneşin yüksekliğini ve gün uzunluğunu belirler", f"öğle güneş yüksekliği ≈ {fnum(90 - lat + 23.45 * math.sin(2 * math.pi * (284 + GUN_NO[ay - 1]) / 365), 0)}°"),
        G("Eğim ve yön", f"{fnum(tilt, 0)}° · {fnum(az, 0)}°", "Konstrüksiyon projesi; çatıda çatının kendisi", "Işının modüle geliş açısını belirler", "ışınım geliş açısının kosinüsüyle orantılıdır"),
        G("DC ve AC güç", f"{fnum(pdc, 0)} kWp · {fnum(pac, 0)} kW", "Modül sayısı × etiket gücü; evirici etiketi", "Kırpmanın başladığı güç", f"DC/AC = {fnum(oran, 2)}"),
        G("Işınım verisi", "açık gökyüzü modeli × bulutluluk çarpanı", "Gerçek tasarımda: PVGIS, Meteonorm, saha ölçümü", "Yıllık enerjinin en belirsiz girdisidir", f"bu modelde {fnum(y['h'], 0)} kWh/m²·yıl"),
    ]
    adimlar = [
        A("Güneşin yüksekliği", "sin h = sinφ·sinδ + cosφ·cosδ·cosω", f"φ = {fnum(lat, 1)}° · δ = {fnum(23.45 * math.sin(2 * math.pi * (284 + GUN_NO[ay - 1]) / 365), 1)}°", "saat saat", "δ: güneşin o günkü eğikliği · ω: saat açısı", "hesap", ["Yer ve zaman"]),
        A("Modül düzlemindeki ışınım", "G = DNI·cosθ + yayılı + yansıyan", f"en yüksek {fnum(max(r['g']), 0)} W/m²", f"günlük {fnum(r['h'], 2)} kWh/m²", "θ: ışının modül yüzeyine dik doğrultuyla açısı", "hesap", ["Eğim ve yön"]),
        A("Hücre sıcaklığı ve güç", "P = Pdc · G/1000 · (1 + γ·(Tc − 25))", f"γ = %{fnum(m['g'], 2)}/°C · hücre en çok {fnum(tc_max, 0)} °C", f"sıcaklık kaybı %{fnum(sic_gun, 1)}", "sıcak ve parlak saatlerde en büyük", "hesap"),
        A("Kirlenme ve DC kayıpları", "P · (1 − kir) · 0,95", f"kirlenme %{fnum(kir, 0)} · yansıma, uyumsuzluk ve DC kablo %5", f"DC tepe {fnum(pdc_tepe, 0)} kW", "varsayım", "tahmini"),
        A("Evirici ve kırpma", "P(AC) = min(P(DC) · η, P(evirici))", f"η = %98 · sınır {fnum(pac, 0)} kW · AC kablo ve trafo %1,5", f"tepe {fnum(p_tepe, 0)} kW · {fnum(t_kirp, 1)} saat kırpma", "evirici çalışma noktasını kaydırarak gücü sınırlar", "hesap", ["DC ve AC güç"]),
        A("Yıllık enerji", "E = Σ aylar (açık günler + kapalı günler)", "aylık bulutluluk çarpanlarıyla açık gün payı", f"{fnum(y['e_ac'] / 1000, 1)} MWh · {fnum(verim_y, 0)} kWh/kWp", "bulutluluk çarpanları kaba ortalamadır", "tahmini", ["Işınım verisi"]),
        A("Başarım oranı", "PR = E(AC) / (H · Pdc)", f"{fnum(y['e_ac'], 0)} / ({fnum(y['h'], 0)} × {fnum(pdc, 0)})", fnum(pr, 2), "ışınımdan bağımsız kalite ölçüsü", "hesap"),
    ]
    ayarlar = [
        S("Evirici › aktif güç sınırı", f"{fnum(pac, 0)} kW (anma) ya da bağlantı anlaşmasındaki güç", "—", "Şebekeye verilen güç anlaşma gücünü aşamaz", "bağlantı anlaşması", "ikincil"),
        S("İzleme sistemi › başarım oranı", "günlük PR; referans hücre ile", f"beklenen ≈ {fnum(pr, 2)}", "Arızayı ve kirlenmeyi enerji kaybı büyümeden gösterir", "saha pratiği", "ikincil"),
        S("Dizilerin MPPT'lere dağıtımı", "farklı yön / eğim ayrı MPPT girişine", "—", "Aynı MPPT'de farklı yönler birbirini aşağı çeker", f"{GES} böl. 2.3.4.1", "resmi"),
        S("Temizlik", f"kirlenme %{fnum(kir, 0)}: " + ("temizlik gerekir" if kir >= 5 else "olağan"), "—", "Yağışsız yaz aylarında kirlenme birikir", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Günlük üretim eğrisi", "Evirici / izleme yazılımı", "açık günde düzgün çan; kırpmada tepesi düz", "çentik: gölge · dişli eğri: parçalı bulut"),
        T("Başarım oranı", "Sayaç enerjisi / (ışınımölçer × etiket gücü)", f"≈ {fnum(pr, 2)}", "kabulde ve yıllık bakımda"),
        T("Diziler arası karşılaştırma", "Aynı yönde, aynı sayıda modüllü dizilerin akımları", "birbirine ±%5 içinde", "düşük kalan dizi: gölge, kir, arıza"),
    ]
    g1 = {"baslik": f"Günlük eğri — {AYLAR[ay - 1]}", "x_ad": "Saat (güneş saati)", "y_ad": "Güç (kW)", "ymin": 0,
          "seriler": [{"ad": "DC gücü (kırpılmamış)", "renk": "#94a3b8", "pts": pts(r["t"], r["pdc"], 1)}, {"ad": "AC gücü", "renk": "#dc2626", "pts": pts(r["t"], r["pac"], 1)},
                      {"ad": "ışınım × Pdc (sıcaklık ve kayıp yok)", "renk": "#f59e0b", "pts": pts(r["t"], [q * pdc / 1000 for q in r["g"]], 1)}],
          "yatay": [{"y": pac, "etiket": f"evirici {fnum(pac, 0)} kW", "renk": "#7c3aed"}]}
    g2 = {"baslik": "Aylara göre enerji (ortalama hava)", "x_ad": "Ay", "y_ad": "Enerji (MWh)", "ymin": 0, "seriler": [{"ad": "aylık AC enerji", "renk": "#1a4d8f", "pts": pts(list(range(1, 13)), [q / 1000 for q in y["ay"]], 2)}],
          "isaretler": [{"x": ay, "etiket": AYLAR[ay - 1]}]}
    rows = []
    for tl in (0, 10, 20, 30, 40, 50):
        yy = yil(lat, tl, az, m, pdc, pac, kir)
        rows.append([f"{tl}°" + (" ◀" if abs(tl - tilt) < 5 else ""), fnum(yy["h"], 0), fnum(yy["e_ac"] / pdc, 0), fnum(yy["ay"][11] / pdc, 0), fnum(yy["ay"][5] / pdc, 0), fnum(yy["e_ac"] / yy["e_stc"], 2)])
    rows2 = []
    for q in (1.0, 1.1, 1.2, 1.3, 1.5):
        yy = yil(lat, tilt, az, m, pdc, pdc / q, kir)
        rows2.append([fnum(q, 2) + (" ◀" if abs(q - oran) < 0.05 else ""), fnum(pdc / q, 0), fnum(yy["e_ac"] / 1000, 1), f"%{fnum((1 - yy['e_ac'] / (yy['e_dc'] * ETA_EV * K_AC)) * 100, 1)}", fnum(yy["e_ac"] / (pdc / q), 0)])
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"Modülün etiketindeki güç 1000 W/m² ışınım ve 25 °C hücre sıcaklığı içindir: laboratuvar koşulu. Sahada ışınım güneşin yüksekliğine ve modülün ona hangi açıyla baktığına bağlıdır. {AYLAR[ay - 1]} ayında bu enlemde modül düzlemine en çok {fnum(max(r['g']), 0)} W/m² düşüyor.",
            f"Günlük eğri bir çandır: sabah ve akşam güneş alçaktır, ışın hem atmosferde uzun yol alır hem modüle yatık gelir. Eğrinin altındaki alan enerjidir: bugün {fnum(r['e_ac'], 0)} kWh, kurulu her kWp için {fnum(r['e_ac'] / pdc, 2)} kWh.",
            f"Sıcaklık üretimi iki yönden etkiler. Parlak saatlerde hücre {fnum(tc_max, 0)} °C'a çıkar ve güç düşer: bugünkü kayıp %{fnum(sic_gun, 1)}. Bu yüzden en yüksek anlık güç çoğu zaman haziranda değil, serin ve açık bir bahar gününde görülür.",
            (f"DC gücü ({fnum(pdc, 0)} kWp) eviricinin AC gücünden ({fnum(pac, 0)} kW) büyük seçilmiş: DC/AC = {fnum(oran, 2)}. Modül yılın çoğunda etiket gücüne ulaşmadığı için evirici sabah ve akşam daha dolu çalışır; karşılığında en parlak saatlerde gücü sınırlar. "
             + (f"Bugün {fnum(t_kirp, 1)} saat boyunca eğrinin tepesi düz: kırpılan enerji günün %{fnum(kirp_gun, 1)} kadarı, yılın %{fnum(kirp_yil, 1)} kadarı." if t_kirp > 0 else f"Bugün kırpma yok; yıl boyunca kayıp %{fnum(kirp_yil, 1)}.")
             if oran > 1.02 else f"DC gücü eviricinin gücünü aşmıyor (DC/AC = {fnum(oran, 2)}): kırpma olmaz, ama evirici yılın büyük bölümünde düşük yükte çalışır ve bağlantı gücü tam kullanılmaz."),
            f"Eğim ve yön eğrinin biçimini değiştirir. Güneye bakan dizi öğlen tepe yapar; doğu–batı dizilimi tepeyi basar, eğriyi sabaha ve akşama yayar. Yıllık enerji için en iyi eğim bu enlemde {fnum(lat - 10, 0)}° dolayındadır; kış üretimi isteniyorsa daha dik seçilir.",
            f"Yıl boyunca bu santral ≈ {fnum(y['e_ac'] / 1000, 1)} MWh üretir: kWp başına {fnum(verim_y, 0)} kWh. Düzleme düşen ışınımın etiket gücüyle çarpımına oranı — başarım oranı — {fnum(pr, 2)}. Bu sayı ışınımdan bağımsızdır: santralin ne kadar iyi kurulduğunu ve işletildiğini gösterir.",
            "Buradaki ışınım basit bir açık gökyüzü modeli ve kaba bulutluluk ortalamalarıdır. Gerçek fizibilitede sahanın uzun yıllar ışınım verisi kullanılır; yıldan yıla ±%5 oynama olağandır.",
        ],
        "dersler": [
            "Etiket gücü laboratuvar koşuludur: sahada güç, ışınımın geliş açısına ve hücre sıcaklığına bağlıdır.",
            "DC gücünü eviriciden büyük seçmek (DC/AC ≈ 1,1–1,3) yılın çoğunda kazandırır; bedeli en parlak saatlerdeki kırpmadır.",
            "Yıllık en iyi eğim enlemin yaklaşık 10° altıdır; yön güneyden saptıkça tepe kayar ve basılır.",
            "Başarım oranı (PR) santralin kalite ölçüsüdür: iyi santralde 0,78–0,85.",
            "TEDAŞ tip şartnamesi evirici/üreteç güç oranı için %80–%120 aralığını verir.",
        ],
        "tablolar": [
            {"baslik": f"Eğime göre yıllık üretim ({fnum(lat, 1)}° K, yön {fnum(az, 0)}°)", "cols": ["Eğim", "Işınım (kWh/m²·yıl)", "Yıllık (kWh/kWp)", "Aralık (kWh/kWp)", "Haziran (kWh/kWp)", "PR"], "rows": rows},
            {"baslik": "DC/AC oranına göre (DC gücü sabit)", "cols": ["DC/AC", "Evirici (kW)", "Yıllık enerji (MWh)", "Kırpma kaybı", "Evirici kW'ı başına (kWh)"], "rows": rows2,
             "not": "Işınım modeli ve bulutluluk çarpanları öğretim içindir; değerler sahaya göre ±%10–15 değişir."},
        ],
    }
