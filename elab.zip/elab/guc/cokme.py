"""Motor kalkışında gerilim çökmesi: kalkış akımı trafo ve kablo empedansında gerilim düşürür; bara gerilimi ve motor uç gerilimi ne kadar çöker, öbür yükler ve
motorun kendisi bundan nasıl etkilenir; yol verme yönteminin etkisi.

Model: seri empedanslar (şebeke + trafo + kablo) ve kalkıştaki motor empedansı (sabit empedans, cosφ ≈ 0,35); öbür yükler sabit empedans. Sınır: kendi trafosu olan tüketicide,
bütün yükler devredeyken en büyük motorun yol almasında gerilim düşümü ≤ %15 — Elektrik İç Tesisleri Yön. (yol vericiler bendi), laboratuvarın kural verisinden (resmi).
Kontaktörün tutma gerilimi (≈ %70–85 Un) ve yol verme yöntemlerinin akım oranları tipiktir (tahmini)."""
from __future__ import annotations

import cmath
import math

from ..lab.core import ruleset
from . import kablo as KB
from .asenkron import GUCLER, anma_akim
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, guc_sec, num, opt, pts, trafo

ID = "cokme"
BASLIK = "Kalkışta gerilim çökmesi"
IKON = "📉"
GIRIS = ("Büyük bir motor yol alırken anma akımının altı katını çeker ve bu akım trafonun ve kablonun empedansında gerilim düşürür: lambalar kırpışır, kontaktörler bırakır, "
         "motorun kendi momenti de düşer. Trafo gücünü, kablo boyunu ve yol verme yöntemini değiştirin; çökmenin nereye vardığını izleyin.")
YOL = {"dol": ("Doğrudan", 1.0, 1.0), "yd": ("Yıldız–üçgen", 1 / 3, 1 / 3), "soft": ("Yumuşak yol verici (akım sınırı 3 × In)", 0.5, 0.25), "vfd": ("Frekans çevirici", 0.2, 1.0)}

KONTROLLER = [
    ctl("sn", "Trafo gücü", "sec", 630, secenek=guc_sec()),
    ctl("pn", "Motor gücü", "sec", 75, secenek=opt(*[(g, f"{str(g).replace('.', ',')} kW") for g in GUCLER])),
    ctl("kalk", "Kalkış akımı (doğrudan)", "sayi", 6.5, min=4, max=9, adim=0.5, birim="× In"),
    ctl("yol", "Yol verme", "sec", "dol", secenek=opt(*[(k, v[0]) for k, v in YOL.items()])),
    ctl("l", "Motor kablosu boyu", "sayi", 80, min=1, max=500, adim=5, birim="m"),
    ctl("s", "Motor kablosu kesiti", "sec", 70, secenek=opt(*[(k, f"{str(k).replace('.', ',')} mm²") for k in KB.KESIT if k >= 2.5])),
    ctl("yuk", "Trafonun öbür yükleri", "sayi", 50, min=0, max=100, adim=5, birim="%", yardim="Motor kalkarken devrede olan öbür yüklerin trafo gücüne oranı"),
    ctl("sk", "OG şebekesinin kısa devre gücü", "sayi", 250, min=20, max=1000, adim=10, birim="MVA"),
]


def run(p: dict) -> dict:
    sn, pn, kalk, yol = num(p, "sn", 630), num(p, "pn", 75), num(p, "kalk", 6.5), str(p.get("yol", "dol"))
    l, s, yuk, sk = num(p, "l", 80), num(p, "s", 70), num(p, "yuk", 50) / 100, num(p, "sk", 250)
    tr = trafo("hermetik", sn, 33.0)
    yad, k_i, k_m = YOL[yol]
    an = anma_akim(pn)
    i_k = an["i"] * kalk * k_i                                           # hattan çekilen kalkış akımı (anma geriliminde)
    u = 400.0 / math.sqrt(3)
    z_tr = complex(tr["ur"], tr["ux"]) / 100 * 400 ** 2 / (sn * 1000)
    z_s = 400 ** 2 / (sk * 1e6) * complex(0.1, 0.995)
    z_k = complex(KB.r_km(s, "cu", 70.0), KB.X_AG) * l / 1000
    z_m = (u / i_k) * cmath.rect(1, math.acos(0.35)) if i_k > 0 else complex(1e9)
    z_y = (u / (yuk * tr["i2"])) * cmath.rect(1, math.acos(0.9)) if yuk > 0 else complex(1e9)
    # kalkıştan önce bara gerilimi
    z_once = z_y
    v_once = u * abs(z_once / (z_s + z_tr + z_once))
    z_par = 1 / (1 / z_y + 1 / (z_k + z_m))
    v_bara = u * abs(z_par / (z_s + z_tr + z_par))
    v_motor = v_bara * abs(z_m / (z_k + z_m))
    cok_bara = (1 - v_bara / u) * 100; cok_motor = (1 - v_motor / u) * 100; degisim = (v_once - v_bara) / u * 100
    i_ger = v_motor / abs(z_m)
    m_kalk = k_m * (v_motor / u) ** 2 * 100                              # anma gerilimindeki doğrudan kalkış momentinin yüzdesi
    sinir = ruleset().ictesisler["motor_yol_verme"]["kendi_trafosu_max_du_pct"]
    oran = pn / (an["eta"] * an["cos"]) / sn * 100
    c = Cizim(900, 290)
    c.kutu(20, 60, 110, 54, "OG şebeke", f"{fnum(sk, 0)} MVA")
    c.daire(180, 87, 20, "cizgi"); c.daire(206, 87, 20, "cizgi"); c.yazi(193, 52, f"{fnum(sn, 0)} kVA · uk %{fnum(tr['uk'], 1)}", "#475569", 10.5, anchor="middle")
    c.hat("M130,87 H160", "L1", hot=True, w=3); c.hat("M226,87 H300", "L1", hot=True, w=3)
    c.hat("M300,50 V200", "cizgi", w=5); c.yazi(300, 40, "AG bara", "#475569", 10.5, anchor="middle")
    c.cihaz(250, 205, f"{fnum(v_bara * math.sqrt(3), 0)} V", "bara gerilimi", ok=cok_bara <= sinir)
    c.hat("M300,87 H470", "L1", hot=True, w=3); c.yazi(385, 76, f"{fnum(l, 0)} m · {str(s).replace('.', ',')} mm²", "#334155", 10.5, anchor="middle")
    c.daire(510, 87, 36, "cizgi", w=3); c.yazi(510, 95, "M", "#334155", 20, kalin=True, anchor="middle"); c.yazi(510, 140, f"{str(pn).replace('.', ',')} kW · {yad.split(' (')[0]}", "#475569", 10.5, anchor="middle")
    c.hat("M300,160 H400", "cizgi", w=2); c.kutu(400, 142, 110, 36, "Öbür yükler", f"%{fnum(yuk * 100, 0)}")
    c.yazi(580, 56, f"Kalkış akımı {fa(i_ger, 0)} ({fnum(i_ger / an['i'], 1)} × In)", "#b91c1c", 13, kalin=True)
    c.yazi(580, 82, f"Bara gerilimi −%{fnum(cok_bara, 1)} (kalkışla −%{fnum(degisim, 1)})", "#b91c1c" if cok_bara > sinir else "#334155", 13, kalin=True)
    c.yazi(580, 106, f"Motor uçlarında −%{fnum(cok_motor, 1)} → {fnum(v_motor * math.sqrt(3), 0)} V", "#b91c1c" if cok_motor > sinir else "#334155", 12.5)
    c.yazi(580, 130, f"Kalkış momenti: %{fnum(m_kalk, 0)} (doğrudan, tam gerilime göre)", "#b91c1c" if m_kalk < 40 else "#334155", 12.5)
    c.yazi(580, 158, "Kontaktörler %85'in altında bırakabilir;", "#64748b", 11); c.yazi(580, 174, "aydınlatmada %3'lük değişim gözle görülür.", "#64748b", 11)
    c.yazi(580, 200, f"Motorun görünen gücü trafo gücünün %{fnum(oran, 0)}'i", "#64748b", 11)
    ozet = [
        K("Bara geriliminde çökme", f"−%{fnum(cok_bara, 1)}", "bad" if cok_bara > sinir else "warn" if degisim > 3 else "ok", f"{fnum(v_bara * math.sqrt(3), 0)} V · kalkışın payı −%{fnum(degisim, 1)}"),
        K("Motor uçlarında çökme", f"−%{fnum(cok_motor, 1)}", "bad" if cok_motor > sinir else "ok", f"{fnum(v_motor * math.sqrt(3), 0)} V"),
        K("Kalkış akımı", fa(i_ger, 0), "info", f"{fnum(i_ger / an['i'], 1)} × In (In = {fa(an['i'], 0)})"),
        K("Kalkış momenti", f"%{fnum(m_kalk, 0)}", "bad" if m_kalk < 40 else "ok", "doğrudan kalkıştaki tam gerilim momentine göre"),
        K("Motor / trafo", f"%{fnum(oran, 0)}", "warn" if oran > 30 else "ok", "görünen güç oranı"),
    ]
    kontroller = [
        C("Kalkışta gerilim düşümü sınırın içinde mi?", f"motor uçlarında −%{fnum(cok_motor, 1)}", f"≤ %{fnum(sinir, 0)}", cok_motor <= sinir,
          "Kendi trafosu olan tüketicide, bütün yükler devredeyken en büyük motorun yol almasında, trafo empedansı dâhil bağıl gerilim düşümü ≤ %15 — Elektrik İç Tesisleri Yön. (yol vericiler ve ayar aygıtları bendi)", "resmi"),
        C("Öbür yükler etkilenmiyor mu?", f"bara −%{fnum(cok_bara, 1)} · ani değişim −%{fnum(degisim, 1)}", "bara ≥ %85 Un; değişim ≤ %3–5 (aydınlatma)", cok_bara <= 15 and degisim <= 5, "Kontaktör bobinleri ≈ %85 Un'in altında tutmayabilir; aydınlatmada %3'ü aşan ani değişim kırpışma olarak görülür — tipik", "tahmini"),
        C("Motor yükü kaldırabiliyor mu?", f"kalkış momenti %{fnum(m_kalk, 0)}", "≥ yükün kalkış momenti (pompa, fan ≈ %20–40; konveyör, kırıcı ≈ %100+)", m_kalk >= 40, "Moment gerilimin karesiyle düşer: yıldız–üçgende üçte bire, %85 gerilimde %72'ye iner", "hesap"),
    ]
    girdiler = [
        G("Trafo", f"{fnum(sn, 0)} kVA · uk %{fnum(tr['uk'], 1)}", "Etiket", "Çökmenin büyük bölümü trafonun reaktansında olur", f"Z = uk · U²/Sn = {fnum(abs(z_tr) * 1000, 1)} mΩ"),
        G("Motor", f"{str(pn).replace('.', ',')} kW · In {fa(an['i'], 0)} · kalkış {fnum(kalk, 1)} × In, cosφ ≈ 0,35", "Etiket ve katalog", "Kalkış akımı neredeyse tümüyle reaktiftir: reaktansta en çok gerilim düşürür", f"I(kalkış) = {fa(an['i'] * kalk, 0)}"),
        G("Motor kablosu", f"{fnum(l, 0)} m · {str(s).replace('.', ',')} mm²", "Proje", "Motor uçlarındaki ek çökmeyi belirler", f"Z = {fnum(abs(z_k) * 1000, 1)} mΩ"),
    ]
    adimlar = [
        A("Kalkış empedansı", "Zm = U / I(kalkış) ∠ arccos 0,35", f"230 V / {fnum(i_k, 0)} A", f"{fnum(abs(z_m) * 1000, 0)} mΩ", "kalkışta motor küçük bir endüktif empedanstır", "hesap", ["Motor"]),
        A("Bara gerilimi", "U(bara) = U · Zp / (Zs + Ztr + Zp)", f"Zp = (motor + kablo) ∥ öbür yükler = {fnum(abs(z_par) * 1000, 0)} mΩ", f"{fnum(v_bara * math.sqrt(3), 0)} V (−%{fnum(cok_bara, 1)})", "gerilim bölücü", "hesap", ["Trafo"]),
        A("Motor uç gerilimi", "U(motor) = U(bara) · Zm / (Zk + Zm)", f"Zk = {fnum(abs(z_k) * 1000, 1)} mΩ", f"{fnum(v_motor * math.sqrt(3), 0)} V (−%{fnum(cok_motor, 1)})", "kablodaki ek düşüm", "hesap", ["Motor kablosu"]),
        A("Kalkış momenti", "M ∝ U² · (yöntem katsayısı)", f"({fnum(v_motor / u, 2)})² × {fnum(k_m, 2)}", f"%{fnum(m_kalk, 0)}", "moment gerilimin karesiyle orantılıdır", "hesap"),
    ]
    ayarlar = [
        S("Yol verme yöntemi", yad, "doğrudan · Y–Δ · yumuşak · sürücü", "Hattan çekilen akımı ve momenti birlikte düşürür", "saha pratiği", "ikincil"),
        S("Kontaktör / kumanda gerilimi", "kumanda devresi ayrı ve kararlı kaynaktan", "—", "Çökme sırasında kontaktörlerin bırakmaması için", "saha pratiği", "ikincil"),
        S("Düşük gerilim rölesi (27)", "gecikmeli (0,5–2 s)", "—", "Kalkış çökmesinde açmamalı", "saha pratiği", "ikincil"),
        S("Aşırı akım › ani kademe", f"> {fa(i_ger * 1.3, 0)}", "—", "Kalkış akımında açmamalı", "Röle laboratuvarı › Motor yol alma", "ikincil"),
    ]
    test = [T("Kalkış kaydı", "Analizörle bara ve motor gerilimi, akım; yarım periyotluk kayıt", f"en düşük gerilim ≈ {fnum(v_motor * math.sqrt(3), 0)} V, akım ≈ {fa(i_ger, 0)}", "multimetre bu kadar kısa çökmeyi göstermez")]
    ls = [5 * 1.25 ** k for k in range(0, 22) if 5 * 1.25 ** k <= 500]
    def cok(sn_, yol_, l_):
        t_ = trafo("hermetik", sn_, 33.0); zt = complex(t_["ur"], t_["ux"]) / 100 * 400 ** 2 / (sn_ * 1000)
        ik_ = an["i"] * kalk * YOL[yol_][1]; zm = (u / ik_) * cmath.rect(1, math.acos(0.35)); zk = complex(KB.r_km(s, "cu", 70.0), KB.X_AG) * l_ / 1000
        zy = (u / (yuk * t_["i2"])) * cmath.rect(1, math.acos(0.9)) if yuk > 0 else complex(1e9)
        zp = 1 / (1 / zy + 1 / (zk + zm)); vb = u * abs(zp / (z_s + zt + zp))
        return (1 - vb * abs(zm / (zk + zm)) / u) * 100
    g1 = {"baslik": "Kablo boyuna göre motor uçlarındaki çökme", "x_ad": "Motor kablosu boyu (m)", "y_ad": "Çökme (%)", "ymin": 0,
          "seriler": [{"ad": v[0].split(" (")[0], "renk": rk, "kesik": k != yol, "pts": pts(ls, [cok(sn, k, x) for x in ls], 2)} for (k, v), rk in zip(YOL.items(), ("#dc2626", "#b45309", "#1a4d8f", "#15803d"))],
          "yatay": [{"y": sinir, "etiket": f"sınır %{fnum(sinir, 0)}", "renk": "#dc2626"}], "isaretler": [{"x": l, "etiket": "boy"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1],
        "anlatim": [
            f"Duran motor şebekeye küçük bir empedans gibi görünür: doğrudan yol vermede anma akımının {fnum(kalk, 1)} katını çeker ve bu akımın büyük bölümü reaktiftir (cosφ ≈ 0,35).",
            f"Bu akım trafonun kısa devre empedansından geçer. Trafonun empedansı da ağırlıkla reaktiftir: reaktif akım, reaktansta en büyük gerilim düşümünü yapar. Bara gerilimi %{fnum(cok_bara, 1)} çöküyor.",
            f"Kablo ikinci bir bölücüdür: {fnum(l, 0)} m sonunda motor uçlarında çökme %{fnum(cok_motor, 1)}. Motor ne kadar uzaksa kendi kalkış akımından o kadar çok etkilenir.",
            f"Çökmenin iki sonucu vardır. Barayı paylaşan yükler onu görür: lamba kırpışır, kontaktör bırakabilir, sürücü hata verir. Motorun kendisi de görür: moment gerilimin karesiyle düşer, burada %{fnum(m_kalk, 0)}'e. Yük ağırsa motor hızlanamaz, kalkış uzar, çökme sürer.",
            ("Yıldız–üçgen hem akımı hem momenti üçte bire indirir: çökme küçülür ama ağır yük kalkmaz. Yumuşak yol verici akımı sınırlar; moment akımın karesiyle düşer. Sürücü, anma akımı dolayında tam moment verebilen tek yöntemdir."
             if yol != "dol" else "Çare ya kaynağı güçlendirmektir (büyük trafo, kalın ve kısa kablo) ya da kalkış akımını azaltmaktır (yıldız–üçgen, yumuşak yol verici, sürücü)."),
        ],
        "dersler": [
            "Kalkış akımı reaktiftir; çökmeyi trafonun ve hattın reaktansı belirler.",
            "Yönetmelik sınırı: kendi trafosu olan tesiste kalkışta ≤ %15.",
            "Moment ∝ U²: %15 çökme, %28 moment kaybıdır.",
            "Yıldız–üçgen akımı da momenti de üçte bire indirir; sürücü akımı düşürür, momenti korur.",
            "Motor gücü trafo gücünün üçte birini geçiyorsa doğrudan yol verme sorgulanır.",
        ],
        "tablolar": [{"baslik": "Yol verme yöntemine göre", "cols": ["Yöntem", "Hattan çekilen akım", "Motor uçlarında çökme", "Kalkış momenti"],
                      "rows": [[v[0] + (" ◀" if k == yol else ""), f"{fnum(kalk * v[1], 1)} × In", f"−%{fnum(cok(sn, k, l), 1)}", f"%{fnum(v[2] * (1 - cok(sn, k, l) / 100) ** 2 * 100, 0)}"] for k, v in YOL.items()],
                      "not": "Akım ve moment oranları tipiktir; yumuşak yol vericide akım sınırı ayarlanabilir."}],
    }
