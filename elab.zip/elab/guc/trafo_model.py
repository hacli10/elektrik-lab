"""Dağıtım trafosu — ortak modeller.

1) Üç fazlı devre modeli (faz koordinatlarında, birim değerlerle): şebeke (Thevenin) — YG hat kesintileri — sargılar (bağlantı grubuna göre) — AG yükü ve arızası.
   Her bacak ideal bir manyetik bağdır: bacağın sargı gerilimleri V = n·e + z·i (e: bacağın sarım başına gerilimi, n: sarım oranı, z: kaçak empedans),
   bacağın amper-sarım dengesi Σ n·i = Σ Ym·e (mıknatıslanma; üç bacaklı çekirdekte sıfır bileşen akısı demirden dönemez, bu yüzden sıfır bileşen
   mıknatıslanma empedansı küçüktür). Düğüm denklemleriyle birlikte tek bir doğrusal takım çözülür (ortak.coz).
   Birimler: gerilim tabanı her iki tarafta faz–nötr anma gerilimi, akım tabanı anma hat akımı. Yıldız sargı n = 1, üçgen sargı n = √3, zikzak yarım sargı n = 1/√3.
   Doğrusal modeldir: çekirdek doyması, ferrorezonans ve ark yoktur.

2) Isıl model: yağlı trafoda üst yağ ve sıcak nokta (IEC 60076-7 fark denklemleri), kuru tipte sargı sıcak noktası (tek zaman sabiti); ömür tüketimi."""
from __future__ import annotations

import cmath
import math

from .ortak import A120, S3, coz

GRUPLAR = ("Dyn11", "Dyn5", "Yzn11", "Yzn5", "Yyn0")
GMIN = 1e-9


class Devre:
    """Düğüm + bacak + sargı bilinmeyenli doğrusal takım. Düğüm 0 toprak (referans)."""

    def __init__(self):
        self.ad = ["toprak"]
        self.y: dict = {}          # (i, j) -> admitans (düğüm matrisi)
        self.j: dict = {}          # düğüm -> enjekte akım
        self.sargi: list = []      # (bacak, a, b, n, z)

    def dugum(self, ad: str) -> int:
        if ad not in self.ad:
            self.ad.append(ad)
        return self.ad.index(ad)

    def _ekle(self, i: int, j: int, v: complex) -> None:
        if i and j:
            self.y[(i, j)] = self.y.get((i, j), 0j) + v

    def dal(self, a: int, b: int, y: complex) -> None:
        """a–b arasında admitans."""
        self._ekle(a, a, y); self._ekle(b, b, y); self._ekle(a, b, -y); self._ekle(b, a, -y)

    def kaynak(self, a: int, e: complex, z: complex) -> None:
        """Toprağa göre e gerilimli, z iç empedanslı kaynak (Norton eşdeğeri)."""
        self.dal(a, 0, 1 / z); self.j[a] = self.j.get(a, 0j) + e / z

    def blok(self, dugumler: list, ym: list) -> None:
        """Toprağa göre 3×3 admitans bloğu (yük)."""
        for r, i in enumerate(dugumler):
            for c, j in enumerate(dugumler):
                self._ekle(i, j, ym[r][c])

    def sar(self, bacak: int, a: int, b: int, n: float, z: complex = 0j) -> int:
        self.sargi.append((bacak, a, b, n, z))
        return len(self.sargi) - 1

    def coz(self, ym: list) -> dict:
        """ym: 3×3 mıknatıslanma admitans matrisi. Dönen: v[düğüm adı], e[3], i[sargı]."""
        nd = len(self.ad) - 1; ns = len(self.sargi); n = nd + 3 + ns
        a = [[0j] * n for _ in range(n)]; b = [0j] * n
        for (i, j), v in self.y.items():
            a[i - 1][j - 1] += v
        for i in range(nd):
            a[i][i] += GMIN
        for i, v in self.j.items():
            b[i - 1] += v
        for w, (k, p, q, tur, z) in enumerate(self.sargi):
            col = nd + 3 + w
            if p:
                a[p - 1][col] += 1          # sargı akımı p düğümünden çıkar
            if q:
                a[q - 1][col] -= 1
            row = nd + 3 + w                 # V_p − V_q − n·e_k − z·i = 0
            if p:
                a[row][p - 1] += 1
            if q:
                a[row][q - 1] -= 1
            a[row][nd + k] -= tur
            a[row][col] -= z
            a[nd + k][col] += tur            # bacak: Σ n·i − Σ Ym·e = 0
        for k in range(3):
            for m in range(3):
                a[nd + k][nd + m] -= ym[k][m]
        x = coz(a, b)
        return {"v": {ad: x[i] for i, ad in enumerate(self.ad[1:])} | {"toprak": 0j}, "e": x[nd:nd + 3], "i": x[nd + 3:]}


def dizi_blok(y0: complex, y1: complex, y2: complex) -> list:
    """Sıfır/pozitif/negatif bileşen admitanslarından faz admitans matrisi (dönen makine ya da dengeli yük)."""
    a = A120
    t = [[1, 1, 1], [1, a * a, a], [1, a, a * a]]
    ys = (y0, y1, y2)
    return [[sum(ys[s] * t[i][s] * t[j][s].conjugate() for s in range(3)) / 3 for j in range(3)] for i in range(3)]


def miknatis(i0: float, cekirdek: str = "3") -> list:
    """Mıknatıslanma admitans matrisi. i0: boşta akım (pu). cekirdek: «3» üç bacaklı (sıfır bileşen akısı havadan döner: Z0m ≈ 0,6 pu, tipik) | «5» beş bacaklı / kabuk tipi."""
    y1 = i0 * cmath.rect(1, math.radians(-80))
    y0 = 1 / complex(0.06, 0.6) if cekirdek == "3" else y1
    return [[(y0 + 2 * y1) / 3 if i == j else (y0 - y1) / 3 for j in range(3)] for i in range(3)]


def kur(grup: str, zk: complex, zs: complex, acik: tuple = (False, False, False), yg_notr_toprakli: bool = False, e_kaynak: float = 1.0) -> tuple:
    """Şebeke + trafo. Dönen: (devre, düğümler). acik: YG L1, L2, L3 iletkeninin açık olup olmadığı."""
    d = Devre()
    yg = [d.dugum(x) for x in ("A", "B", "C")]
    ag = [d.dugum(x) for x in ("a", "b", "c")]
    for k in range(3):
        if not acik[k]:
            d.kaynak(yg[k], e_kaynak * A120 ** (-k) if k else complex(e_kaynak), zs if abs(zs) > 1e-9 else complex(1e-6))
    ters = grup.endswith("5")
    if grup[0] == "D":
        saat1 = grup.endswith("1") and not grup.endswith("11")
        for k in range(3):
            p, q = (yg[k], yg[(k + 2) % 3]) if saat1 else (yg[k], yg[(k + 1) % 3])
            d.sar(k, p, q, S3, 3 * zk)
    else:
        n1 = 0 if yg_notr_toprakli else d.dugum("N1")
        for k in range(3):
            d.sar(k, yg[k], n1, 1.0, zk)
    if "z" in grup:                              # zikzak: faz a = bacak a yarımı − bacak b yarımı
        for k in range(3):
            m = d.dugum("m" + "abc"[k])
            p, q = (ag[k], m) if not ters else (m, ag[k])
            d.sar(k, p, q, 1 / S3)
            p, q = (0, m) if not ters else (m, 0)
            d.sar((k + 1) % 3, p, q, 1 / S3)
    else:
        for k in range(3):
            d.sar(k, *((ag[k], 0) if not ters else (0, ag[k])), 1.0)
    return d, {"yg": yg, "ag": ag}


def hesapla(grup: str, zk: complex, zs: complex, acik: tuple, yuk: dict, i0: float = 0.01, cekirdek: str = "3", ariza: dict | None = None, e_kaynak: float = 1.0) -> dict:
    """Motor yükü sabit güçlüdür: pozitif bileşen gerilimi düşünce motor aynı momenti vermek için daha çok akım çeker (y1 ∝ 1/V1²). Gerilim çok düşerse
    motor devrilir ve kilitli rotor empedansına iner. Bu yüzden çözüm birkaç kez yinelenir."""
    carp, r = 1.0, None
    for _ in range(8):
        r = _coz1(grup, zk, zs, acik, yuk, i0, cekirdek, ariza, e_kaynak, carp)
        if not (yuk.get("s", 0) * yuk.get("motor", 0) > 0) or ariza:
            break
        v1 = abs(dizi(r["ua"])[1])
        yeni = min(1.0 / max(v1 * v1, 1e-6), 6.0 / 0.85)            # üst sınır: kilitli rotor (devrilme)
        if abs(yeni - carp) < 1e-3:
            break
        carp = 0.5 * (carp + yeni)
    r["motor_carp"] = carp
    r["devrildi"] = carp >= 6.0 / 0.85 - 0.05
    return r


def _coz1(grup: str, zk: complex, zs: complex, acik: tuple, yuk: dict, i0: float, cekirdek: str, ariza: dict | None, e_kaynak: float, carp: float) -> dict:
    """Trafonun bir işletme durumunu çözer.
    yuk: {"s": toplam yük (pu), "cos": güç katsayısı, "motor": motor payı (0…1), "tek": [L1, L2, L3 çarpanları] (tek fazlı yüklerin faz dağılımı)}
    ariza: AG uçlarında {"tip": 3f | 2f | 1f | 2ft, "rf": pu}"""
    d, n = kur(grup, zk, zs, acik, e_kaynak=e_kaynak)
    ag = n["ag"]
    s = max(yuk.get("s", 0.0), 0.0); cosf = min(max(yuk.get("cos", 0.9), 0.05), 1.0); mot = min(max(yuk.get("motor", 0.0), 0.0), 1.0)
    tek = yuk.get("tek", [1.0, 1.0, 1.0])
    y_sabit = s * (1 - mot) * complex(cosf, -math.sqrt(1 - cosf * cosf))          # sabit empedanslı yük (pu admitans, anma geriliminde)
    for k in range(3):
        if abs(y_sabit) * tek[k] > 0:
            d.dal(ag[k], 0, y_sabit * tek[k])
    y1m = y2m = 0j
    if s * mot > 0:                              # motor yükü: pozitif bileşende çalışma empedansı, negatif bileşende kilitli rotor empedansı (≈ 1/6 pu, cosφ ≈ 0,3)
        y1m = s * mot * carp * complex(0.85, -math.sqrt(1 - 0.85 ** 2))
        y2m = s * mot * 6.0 * complex(0.3, -math.sqrt(1 - 0.09))
        d.blok(ag, dizi_blok(0j, y1m, y2m))
    if ariza:
        yf = 1 / max(ariza.get("rf", 0.0), 1e-6)
        tip = ariza["tip"]
        if tip == "3f":
            for k in range(3):
                d.dal(ag[k], 0, yf)
        elif tip == "1f":
            d.dal(ag[0], 0, yf)
        elif tip == "2f":
            d.dal(ag[1], ag[2], yf)
        elif tip == "2ft":
            d.dal(ag[1], 0, yf); d.dal(ag[2], 0, yf)
    c = d.coz(miknatis(i0, cekirdek))
    v = c["v"]
    ua = [v[x] for x in "abc"]; uy = [v[x] for x in "ABC"]
    # hat akımları: YG'de kaynaktan trafoya, AG'de trafodan yüke (sargı akımlarından)
    iy = [0j, 0j, 0j]; ia = [0j, 0j, 0j]
    k_sargi = [0.0, 0.0, 0.0]; kay = [0.0, 0.0, 0.0]
    for w, (k, p, q, tur, z) in enumerate(d.sargi):
        iw = c["i"][w]
        for t, dug in enumerate(n["yg"]):
            if p == dug:
                iy[t] += iw
            if q == dug:
                iy[t] -= iw
        for t, dug in enumerate(ag):
            if p == dug:
                ia[t] -= iw
            if q == dug:
                ia[t] += iw
        anma = 1 / S3 if tur > 1.5 else 1.0        # sargının anma akımı (pu): üçgen sargıda hat akımının 1/√3'ü, yıldız ve zikzak yarım sargıda hat akımı
        yuklenme = abs(iw) / anma
        k_sargi[k] = max(k_sargi[k], yuklenme)
        kay[k] += yuklenme ** 2
    nsb = sum(1 for wdg in d.sargi if wdg[0] == 0)      # bacak başına sargı sayısı
    inotr = sum(ia)
    return {"ua": ua, "uy": uy, "iy": iy, "ia": ia, "e": c["e"], "k_sargi": k_sargi, "kayip": sum(kay) / (3 * nsb), "inotr": inotr, "sargi": [(w[0], w[3], c["i"][i]) for i, w in enumerate(d.sargi)],
            "y1m": y1m, "y2m": y2m}


def dizi(v: list) -> tuple:
    """(sıfır, pozitif, negatif) bileşen."""
    a = A120
    return (v[0] + v[1] + v[2]) / 3, (v[0] + a * v[1] + a * a * v[2]) / 3, (v[0] + a * a * v[1] + a * v[2]) / 3


# ---------------- ısıl model ----------------
YAG = {"x": 0.8, "y": 1.6, "k11": 1.0, "k21": 1.0, "k22": 2.0, "tau_o": 180.0, "tau_w": 4.0, "d_or": 60.0, "d_hr": 18.0}
KURU = {"q": 1.6, "tau": 45.0, "d_hr": 115.0, "d_pt": 90.0}      # sıcak nokta artışı 115 K (40 °C ortamda 155 °C); PT100 ölçüm noktası daha soğuktur (≈ 90 K, tipik)
SINIR_YAG = {"olagan": (1.5, 120.0, 105.0, "olağan çevrimsel yükleme"), "uzun": (1.8, 140.0, 115.0, "uzun süreli acil yükleme"), "kisa": (2.0, 160.0, 115.0, "kısa süreli acil yükleme")}
KURU_IHBAR, KURU_ACMA, KURU_FAN_AC, KURU_FAN_KAPA = 130.0, 150.0, 100.0, 80.0
YAG_IHBAR, YAG_ACMA = 90.0, 100.0          # üst yağ termometresi: ihbar / açma (tipik ayarlar)


def yaslanma(tip: str, th: float) -> float:
    """Bağıl yaşlanma hızı (1 = anma sıcak nokta sıcaklığında)."""
    if tip == "kuru":
        return 2 ** ((th - 145.0) / 10.0)
    return 2 ** ((th - 98.0) / 6.0)


def surekli(tip: str, k: float, ta: float, r: float, k_sn: float | None = None, fan: bool = False) -> dict:
    """Sürekli rejim sıcaklıkları. k: toplam kaybı belirleyen yük katsayısı (kayıp ∝ k²); k_sn: en sıcak sargının yük katsayısı (verilmezse k)."""
    ks = k if k_sn is None else k_sn
    if tip == "kuru":
        carp = 0.6 if fan else 1.0               # zorlamalı havada sıcaklık artışı azalır (tipik: aynı sıcaklıkta ≈ %40 fazla güç ↔ artış × ≈ 0,6)
        return {"yag": None, "sn": ta + KURU["d_hr"] * carp * ks ** KURU["q"], "pt": ta + KURU["d_pt"] * carp * ks ** KURU["q"]}
    yag = ta + YAG["d_or"] * ((1 + r * k * k) / (1 + r)) ** YAG["x"]
    return {"yag": yag, "sn": yag + YAG["d_hr"] * ks ** YAG["y"], "pt": yag}


def benzet(tip: str, profil, ta: float, r: float, sure_dk: float, dt: float = 1.0, bas: dict | None = None, k_sn_oran: float = 1.0, fan_oto: bool = True) -> dict:
    """Zaman benzetimi. profil(t_dk) → yük katsayısı K. bas: başlangıç {yag, d1, d2} (verilmezse profil(0) yükünde sürekli rejim).
    k_sn_oran: en sıcak sargının yük katsayısı / K (dengesiz çalışmada > 1). Dönen: t (dk), k, yag, sn, omur (tüketilen ömür, saat), fan."""
    n = int(round(sure_dk / dt))
    k0 = profil(0.0)
    ts, ks, yag_, sn_, om_, fan_, pt_ = [], [], [], [], [], [], []
    omur = 0.0
    if tip == "kuru":
        fan = False
        d = (bas or {}).get("d", KURU["d_hr"] * (k0 * k_sn_oran) ** KURU["q"])
        for i in range(n + 1):
            t = i * dt; k = profil(t)
            th = ta + d
            olc = ta + d * KURU["d_pt"] / KURU["d_hr"]                     # PT100'ün gösterdiği
            if fan_oto:
                fan = True if olc >= KURU_FAN_AC else False if olc <= KURU_FAN_KAPA else fan
            ts.append(t); ks.append(k); yag_.append(None); sn_.append(th); fan_.append(fan); pt_.append(olc)
            omur += yaslanma(tip, th) * dt / 60; om_.append(omur)
            hedef = KURU["d_hr"] * (0.6 if fan else 1.0) * (k * k_sn_oran) ** KURU["q"]
            d += dt / KURU["tau"] * (hedef - d)
        return {"t": ts, "k": ks, "yag": yag_, "sn": sn_, "omur": om_, "fan": fan_, "pt": pt_}
    c = YAG
    if bas:
        yag, d1, d2 = bas["yag"], bas["d1"], bas["d2"]
    else:
        yag = ta + c["d_or"] * ((1 + r * k0 * k0) / (1 + r)) ** c["x"]
        d1 = c["k21"] * c["d_hr"] * (k0 * k_sn_oran) ** c["y"]; d2 = (c["k21"] - 1) * c["d_hr"] * (k0 * k_sn_oran) ** c["y"]
    for i in range(n + 1):
        t = i * dt; k = profil(t)
        th = yag + d1 - d2
        ts.append(t); ks.append(k); yag_.append(yag); sn_.append(th); fan_.append(False)
        omur += yaslanma(tip, th) * dt / 60; om_.append(omur)
        ky = (k * k_sn_oran) ** c["y"]
        yag += dt / (c["k11"] * c["tau_o"]) * (c["d_or"] * ((1 + r * k * k) / (1 + r)) ** c["x"] - (yag - ta))
        adim = min(dt, 1.0); m = max(1, int(round(dt / adim)))            # sargı zaman sabiti küçüktür: iç adım
        for _ in range(m):
            d1 += adim / (c["k22"] * c["tau_w"]) * (c["k21"] * c["d_hr"] * ky - d1)
            d2 += adim / (c["tau_o"] / c["k22"]) * ((c["k21"] - 1) * c["d_hr"] * ky - d2)
    return {"t": ts, "k": ks, "yag": yag_, "sn": sn_, "omur": om_, "fan": fan_, "pt": yag_}


def ilk_gecis(ts: list, vs: list, esik: float):
    """Değerin eşiği ilk aştığı an (dk) ya da None."""
    for t, v in zip(ts, vs):
        if v is not None and v >= esik:
            return t
    return None


def izinli_k(tip: str, ta: float, r: float, sn_sinir: float, yag_sinir: float | None = None, k_sn_oran: float = 1.0) -> float:
    """Sürekli çalışmada sınırları aşmayan en büyük yük katsayısı (ikiye bölme)."""
    lo, hi = 0.0, 3.0
    for _ in range(40):
        mid = (lo + hi) / 2
        s = surekli(tip, mid, ta, r, mid * k_sn_oran)
        asti = s["sn"] > sn_sinir or (yag_sinir is not None and s["yag"] is not None and s["yag"] > yag_sinir)
        lo, hi = (lo, mid) if asti else (mid, hi)
    return lo
