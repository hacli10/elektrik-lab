"""Motor arızaları ve belirtileri: sarımlar arası kısa devre, kırık rotor çubuğu, hava aralığı kaçıklığı / rulman, yalıtımın ısıl yaşlanması.
Her arızanın akımda, titreşimde ve seste bıraktığı iz; hangi ölçü ve hangi korumanın gördüğü.

Sayısal ilişkiler tanı pratiğindeki kurallardır (ikincil / tahmini): kırık çubukta akım tayfında (1 ± 2s)·f yan bantları, düzeyi ≈ 20·log10(kırık / toplam çubuk) − 6 dB
ve değerlendirme eşikleri (−54 dB sağlam, −48 dB izlenir, −42 dB kırık); sarımlar arası kısa devrede negatif bileşen akımı ≈ kısa devre oranı × kalkış akımı oranı / 3;
yalıtım ömrü sınıf sıcaklığının üstünde her 10 K'de yarıya iner (Montsinger kuralı)."""
from __future__ import annotations

import math

from . import motor_model as M
from .asenkron import GUCLER, anma_akim
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, num, opt, pts

ID = "motor_ariza"
BASLIK = "Motor arızaları ve belirtileri"
IKON = "🩺"
GIRIS = ("Motor arızalanmadan önce haber verir: akımın tayfında, titreşiminde ve sesinde. Sarımlar arası kısa devre akımları dengesizleştirir, kırık rotor çubuğu akımı ve sesi "
         "kayma frekansında dalgalandırır, sıcaklık yalıtımın ömrünü yer. Arızayı ve şiddetini seçin; ölçü aletinin ne göstereceğine bakın.")
ARIZA = {"saglam": "Sağlam motor", "sarim": "Sarımlar arası kısa devre (stator)", "cubuk": "Kırık rotor çubuğu", "eksen": "Hava aralığı kaçıklığı / rulman aşınması", "isi": "Aşırı sıcaklık (yalıtımın yaşlanması)"}
SINIF = {"B": 130, "F": 155, "H": 180}

KONTROLLER = [
    ctl("pn", "Motor gücü", "sec", 30, secenek=opt(*[(g, f"{str(g).replace('.', ',')} kW") for g in GUCLER])),
    ctl("ariza", "Arıza", "sec", "cubuk", secenek=opt(*ARIZA.items())),
    ctl("yuk", "Yük", "sayi", 80, min=10, max=110, adim=5, birim="%"),
    ctl("f_sarim", "Kısa devre olan sarım oranı (bir fazda)", "sayi", 3, min=0.5, max=20, adim=0.5, birim="%", goster={"ariza": ["sarim"]}),
    ctl("n_cubuk", "Kırık çubuk sayısı", "sayi", 2, min=1, max=8, adim=1, goster={"ariza": ["cubuk"]}),
    ctl("n_top", "Rotordaki toplam çubuk sayısı", "sayi", 40, min=20, max=80, adim=2, goster={"ariza": ["cubuk"]}),
    ctl("kac", "Hava aralığı kaçıklığı", "sayi", 30, min=5, max=80, adim=5, birim="%", goster={"ariza": ["eksen"]}),
    ctl("sinif", "Yalıtım sınıfı", "sec", "F", secenek=opt(("B", "B (130 °C)"), ("F", "F (155 °C)"), ("H", "H (180 °C)")), goster={"ariza": ["isi"]}),
    ctl("t_sargi", "Sargı sıcaklığı (en sıcak nokta)", "sayi", 165, min=80, max=220, adim=5, birim="°C", goster={"ariza": ["isi"]}),
]


def run(p: dict) -> dict:
    pn, ar, yuk = num(p, "pn", 30), str(p.get("ariza", "cubuk")), num(p, "yuk", 80) / 100
    par = M.UC; a0 = M.anma(par); an = anma_akim(pn); amper = an["i"] / a0["i"]
    r = M.calisma(par, yuk)
    s = r["s"]; i_pu = abs(r["i1"]) / a0["i"]
    f1 = 50.0
    tayf = [(f1, 0.0, "temel")]                                   # (frekans, dB, ad)
    kpi_ad, kpi_deger, kpi_durum, kpi_alt = "Belirti", "yok", "ok", "akım tayfı temiz"
    i2 = 0.0; vuru = 0.0; omur = 1.0; hukum = "Motor sağlam: akım tayfında yalnız 50 Hz, üç faz akımı eşit, ses düzgün."
    kontroller = []
    ses = [{"ad": "Sağlam motor", "not": "düzgün uğultu ve hava sesi", "sure": 3.0, "zarf": "surekli", "siddet": 0.3, "parcalar": [{"f": 100, "a": 0.5}, {"f": 24.3, "a": 0.0}, {"f": 300, "a": 0.15}], "gurultu": 0.35, "gurultu_f": 1200}]
    if ar == "sarim":
        f = num(p, "f_sarim", 3) / 100
        i2 = f * 6.0 / 3                                          # negatif bileşen akımı (× In)
        tayf += [(150.0, 20 * math.log10(max(f * 2, 1e-4)), "3. harmonik")]
        ic = min(1 / (0.06 + f), 15.0)                            # kısa devre halkasındaki akım (× In) — kaba
        kpi_ad, kpi_deger, kpi_durum, kpi_alt = "Negatif bileşen akımı", f"%{fnum(i2 * 100, 0)} In", "bad" if i2 > 0.05 else "warn", f"kısa devre halkasında ≈ {fnum(ic, 0)} × In dolaşır"
        hukum = f"Bir fazın sarımlarının %{fnum(f * 100, 1)}'i kısa devre: faz akımları eşit değil, kısa devre halkası yerel olarak aşırı ısınıyor. Arıza saatler–günler içinde faz–toprak ya da fazlar arası arızaya büyür."
        kontroller = [
            C("Akım dengesizliği", f"I2 ≈ %{fnum(i2 * 100, 0)} In", "≤ %3–5 (gerilimler dengeliyken)", i2 <= 0.05, "Gerilimler dengeli olduğu halde akımlar dengesizse kaynak motordur. Fazlar kaydırıldığında yüksek akım motorun aynı ucunda kalır", "ikincil"),
            C("Aşırı akım / termik röle görür mü?", f"faz akımı ≈ {fnum(i_pu + i2, 2)} × In", "> 1,15 × In", (i_pu + i2) > 1.15, "Küçük bir sarım grubunun kısa devresi hat akımını çok az artırır; arıza büyüyene kadar aşırı akım korumasına görünmez", "tahmini"),
            C("Kısa devre halkasındaki akım", f"≈ {fnum(ic, 0)} × In", "sarım yalıtımı dayanmaz", False, "Kısa devre olan sarımlar çekirdeğin akısını keser: üzerlerinde endüklenen gerilim neredeyse sıfır dirençli halkada büyük akım dolaştırır — kaba kestirim", "tahmini"),
        ]
        ses.append({"ad": "Sarımlar arası kısa devre", "not": "uğultu sertleşir, 100 Hz belirginleşir", "sure": 3.0, "zarf": "surekli", "siddet": 0.5, "parcalar": [{"f": 100, "a": 1.0}, {"f": 200, "a": 0.4}, {"f": 300, "a": 0.25}], "gurultu": 0.3, "gurultu_f": 1200})
    elif ar == "cubuk":
        nb, nt = num(p, "n_cubuk", 2), num(p, "n_top", 40)
        db = 20 * math.log10(nb / nt) - 6
        fl, fu = f1 * (1 - 2 * s), f1 * (1 + 2 * s)
        tayf += [(fl, db, "alt yan bant (1−2s)f"), (fu, db - 3, "üst yan bant (1+2s)f")]
        vuru = 2 * s * f1
        kpi_ad, kpi_deger, kpi_durum, kpi_alt = "Yan bant düzeyi", f"{fnum(db, 0)} dB", "bad" if db > -42 else "warn" if db > -54 else "ok", f"{fnum(fl, 1)} ve {fnum(fu, 1)} Hz'te"
        hukum = f"{fnum(nb, 0)} çubuk kırık: rotorun bir bölgesi akım taşımıyor. Akım ve moment, kayma frekansının iki katında ({fnum(vuru, 1)} Hz) dalgalanıyor; ampermetre ibresi ve motorun sesi bu hızda salınır."
        kontroller = [
            C("Yan bant düzeyi", f"{fnum(db, 0)} dB (temel bileşene göre)", "< −54 dB sağlam · −54…−48 izlenir · > −42 dB kırık çubuk", db <= -48, "Akım imza analizinde kullanılan değerlendirme eşikleri; yük %50'nin üstündeyken ölçülür", "ikincil"),
            C("Yan bantlar temel bileşenden ayrılabiliyor mu?", f"aralık {fnum(2 * s * f1, 2)} Hz (kayma %{fnum(s * 100, 1)})", "≥ 0,5 Hz: yük yeterli", 2 * s * f1 >= 0.5, "Boşta kayma çok küçüktür: yan bantlar 50 Hz'in dibine yapışır ve görülemez. Ölçü yük altında yapılır", "hesap"),
            C("Koruma röleleri görür mü?", "akımın etkin değeri neredeyse değişmez", "görmez", None, "Kırık çubuk bir koruma arızası değil bir durum izleme bulgusudur: akım imza analizi ya da titreşim ölçüsüyle yakalanır", "ikincil"),
        ]
        ses.append({"ad": "Kırık rotor çubuğu", "not": f"uğultu saniyede {fnum(vuru, 1)} kez dalgalanır", "sure": 4.0, "zarf": "surekli", "siddet": 0.5, "vuru": max(vuru, 0.6), "parcalar": [{"f": 100, "a": 1.0}, {"f": 200, "a": 0.3}, {"f": 300, "a": 0.15}], "gurultu": 0.3, "gurultu_f": 1200})
    elif ar == "eksen":
        e = num(p, "kac", 30) / 100
        fr = f1 * (1 - s) / 2                                     # 4 kutup: dönme frekansı
        db = 20 * math.log10(max(e * 0.02, 1e-5))
        tayf += [(f1 - fr, db, "f − fr"), (f1 + fr, db, "f + fr")]
        vuru = fr
        kpi_ad, kpi_deger, kpi_durum, kpi_alt = "Kaçıklık", f"%{fnum(e * 100, 0)}", "bad" if e > 0.4 else "warn" if e > 0.1 else "ok", f"yan bantlar {fnum(f1 - fr, 1)} ve {fnum(f1 + fr, 1)} Hz'te"
        hukum = f"Rotor hava aralığının ortasında değil (%{fnum(e * 100, 0)} kaçık): dar taraftaki çekim kuvveti büyür, rotor o yöne çekilir, rulman yükü ve titreşim artar. İlerlerse rotor statora sürter."
        kontroller = [
            C("Kaçıklık", f"%{fnum(e * 100, 0)}", "≤ %10 (hava aralığının yüzdesi)", e <= 0.10, "Üretim ve montaj toleransı; rulman aşındıkça artar", "ikincil"),
            C("Sürtme riski", f"dar taraf hava aralığının %{fnum((1 - e) * 100, 0)}'i", "kaçıklık < %40", e < 0.4, "Tek yanlı manyetik çekim kaçıklıkla birlikte büyür ve mili daha da eğer: süreç kendini besler", "tahmini"),
        ]
        ses.append({"ad": "Kaçıklık / rulman", "not": "uğultunun üstünde dönme hızında vuran, hırıltılı ses", "sure": 3.5, "zarf": "surekli", "siddet": 0.5, "vuru": fr, "parcalar": [{"f": 100, "a": 0.8}, {"f": fr, "a": 0.5}, {"f": 2 * fr, "a": 0.3}], "gurultu": 0.6, "gurultu_f": 3000, "citirti": 0.01})
    elif ar == "isi":
        sinif, t = str(p.get("sinif", "F")), num(p, "t_sargi", 165)
        omur = 2 ** (-(t - SINIF[sinif]) / 10)
        kpi_ad, kpi_deger, kpi_durum, kpi_alt = "Yalıtım ömrü", f"× {fnum(omur, 2)}", "bad" if omur < 0.6 else "warn" if omur < 1 else "ok", f"sınıf {sinif}: {SINIF[sinif]} °C · sargı {fnum(t, 0)} °C"
        hukum = f"Sargı {fnum(t, 0)} °C: {sinif} sınıfı sınırının {fnum(t - SINIF[sinif], 0)} K " + ("üstünde. Yalıtım ömrü anma ömrünün " if t > SINIF[sinif] else "altında. Yalıtım ömrü anma ömrünün ") + f"{fnum(omur, 2)} katı."
        kontroller = [
            C("Sargı sıcaklığı sınıf sınırının altında mı?", f"{fnum(t, 0)} °C", f"≤ {SINIF[sinif]} °C (sınıf {sinif})", t <= SINIF[sinif], "Yalıtım sınıfı, yalıtımın 20 000 saat dayanması beklenen sıcaklıktır; anma yükünde sargı genellikle bir alt sınıfın sıcaklığında çalıştırılır", "ikincil"),
            C("Ömür", f"anma ömrünün {fnum(omur, 2)} katı", "≥ 1", omur >= 1.0, "Her 10 K fazlalık ömrü yarıya indirir (Montsinger kuralı)", "ikincil"),
        ]
    tayf_cub = {"baslik": "Akım tayfı (temel bileşene göre; 0 dB = 50 Hz)", "kategoriler": [f"{fnum(x[0], 1)} Hz" for x in tayf], "alt": [x[2] for x in tayf], "y_ad": "dB + 80",
                "seriler": [{"ad": "düzey + 80 dB", "renk": "#1a4d8f", "deger": [round(max(x[1] + 80, 0), 1) for x in tayf]}]}
    faz = [i_pu + i2, i_pu - i2 / 2, i_pu - i2 / 2]
    c = Cizim(900, 290)
    c.daire(150, 140, 96, "cizgi", w=8); c.daire(150, 140, 60 if ar != "eksen" else 60, "cizgi", "#e2e8f0", w=2)
    if ar == "eksen":
        c.daire(150 + 20 * num(p, "kac", 30) / 100, 140, 60, "ariza", "#fee2e2", w=2.4); c.yazi(150, 256, "rotor bir yana kaymış", "#b91c1c", 10.5, anchor="middle")
    if ar == "cubuk":
        for k in range(int(num(p, "n_cubuk", 2))):
            ang = math.radians(20 + k * 14)
            c.daire(150 + 52 * math.cos(ang), 140 - 52 * math.sin(ang), 5, "ariza", "#dc2626")
        c.yazi(150, 256, "kırık çubuklar akım taşımıyor", "#b91c1c", 10.5, anchor="middle")
    if ar == "sarim":
        c.simsek(222, 86, 1.2); c.yazi(150, 256, "bir fazda sarımlar arası kısa devre", "#b91c1c", 10.5, anchor="middle")
    if ar == "isi":
        c.daire(150, 140, 78, "ariza", w=14, kesik=True); c.yazi(150, 256, "sargı sınıf sıcaklığının üstünde", "#b91c1c", 10.5, anchor="middle")
    c.yazi(150, 146, "rotor", "#475569", 11, anchor="middle"); c.yazi(150, 36, "stator", "#475569", 11, anchor="middle")
    c.yazi(300, 50, ARIZA[ar], "#15803d" if ar == "saglam" else "#b91c1c", 14, kalin=True)
    c.yazi(300, 78, f"Yük %{fnum(yuk * 100, 0)} · kayma %{fnum(s * 100, 2)} · akım {fa(i_pu * amper, 1)}", "#334155", 12)
    c.yazi(300, 102, "Faz akımları: " + " / ".join(fa(x * amper, 1) for x in faz), "#b91c1c" if i2 > 0.05 else "#334155", 12.5, kalin=i2 > 0.05)
    c.yazi(300, 126, f"{kpi_ad}: {kpi_deger} — {kpi_alt}", "#b91c1c" if kpi_durum == "bad" else "#334155", 12.5, kalin=True)
    satirlar, sat = [], ""
    for kelime in hukum.split(" "):
        if len(sat) + len(kelime) > 88:
            satirlar.append(sat.strip()); sat = ""
        sat += kelime + " "
    satirlar.append(sat.strip())
    for j, st in enumerate(satirlar[:5]):
        c.yazi(300, 160 + j * 19, st, "#334155", 11.5)
    ozet = [
        K("Durum", ARIZA[ar].split(" (")[0], "ok" if ar == "saglam" else "bad", f"yük %{fnum(yuk * 100, 0)}"),
        K(kpi_ad, kpi_deger, kpi_durum, kpi_alt),
        K("Faz akımları", " / ".join(fnum(x * amper, 1) for x in faz) + " A", "bad" if i2 > 0.05 else "ok", "eşit değil" if i2 > 0.01 else "eşit"),
        K("Dalgalanma", f"{fnum(vuru, 1)} Hz" if vuru else "yok", "warn" if vuru else "ok", "akımda, momentte ve seste" if vuru else "akım sabit"),
        K("Kayma", f"%{fnum(s * 100, 2)}", "info", f"hız {fnum(1500 * (1 - s), 0)} d/dk (4 kutup)"),
    ]
    girdiler = [
        G("Motor etiketi", f"{str(pn).replace('.', ',')} kW · ≈ {fa(an['i'], 1)} · yalıtım sınıfı", "Etiket", "Anma akımı, anma hızı (kayma) ve yalıtım sınıfı değerlendirmenin tabanıdır", "s = (ns − n) / ns"),
        G("Yük ve kayma", f"%{fnum(yuk * 100, 0)} · kayma %{fnum(s * 100, 2)}", "Akım ve hız ölçüsü", "Rotor arızalarının izi kayma frekansına bağlıdır: yük yoksa görünmez", "yan bant = (1 ± 2s)·f"),
        G("Akım kaydı", "bir fazın akımı, en az 10 s, yüksek çözünürlükte", "Akım pensi + kayıt cihazı / analizör", "Yan bantlar temel bileşenden 40–60 dB küçüktür; tayfta aranır", "FFT, çözünürlük ≤ 0,1 Hz"),
    ]
    adimlar = [
        A("Kayma", "M(motor, s) = M(yük)", f"yük %{fnum(yuk * 100, 0)}", f"%{fnum(s * 100, 2)}", "«Asenkron motor» sayfasındaki model", "hesap", ["Yük ve kayma"]),
    ] + ([A("Yan bant frekansları", "f(1 ± 2s)", f"50 × (1 ± 2 × {fnum(s, 4)})", f"{fnum(f1 * (1 - 2 * s), 2)} Hz ve {fnum(f1 * (1 + 2 * s), 2)} Hz", "kırık çubuk rotor alanında geri dönen bir bileşen oluşturur; stator akımında bu frekanslarda görünür", "hesap"),
          A("Yan bant düzeyi", "L ≈ 20·log10(Nk / N) − 6 dB", f"20·log10({fnum(num(p, 'n_cubuk', 2), 0)} / {fnum(num(p, 'n_top', 40), 0)}) − 6", kpi_deger, "tanı pratiğindeki kestirim", "ikincil"),
          A("Dalgalanma frekansı", "2·s·f", f"2 × {fnum(s, 4)} × 50", f"{fnum(vuru, 2)} Hz", "akım ve moment bu frekansta salınır", "hesap")] if ar == "cubuk" else
         [A("Negatif bileşen akımı", "I2 ≈ f × (Ik/In) / 3", f"{fnum(num(p, 'f_sarim', 3), 1)} % × 6 / 3", f"%{fnum(i2 * 100, 1)} In", "kısa devre bir fazın amper-sarımını eksiltir — kaba kestirim", "tahmini")] if ar == "sarim" else
         [A("Yan bant frekansları", "f ± fr · fr = f·(1 − s) / (kutup çifti)", f"fr = {fnum(f1 * (1 - s) / 2, 2)} Hz", f"{fnum(f1 - f1 * (1 - s) / 2, 1)} Hz ve {fnum(f1 + f1 * (1 - s) / 2, 1)} Hz", "hava aralığı dönme hızında değişir", "hesap")] if ar == "eksen" else
         [A("Ömür katsayısı", "L / Ln = 2^(−(θ − θsınıf) / 10)", f"2^(−({fnum(num(p, 't_sargi', 165), 0)} − {SINIF[str(p.get('sinif', 'F'))]}) / 10)", f"× {fnum(omur, 2)}", "Montsinger kuralı", "ikincil")] if ar == "isi" else [])
    ayarlar = [
        S("Akım imza analizi", "yılda bir ya da şüphede", "yük ≥ %50", "Kırık çubuk ve kaçıklığı motor çalışırken, pano içinden bulur", "durum izleme pratiği", "ikincil"),
        S("Akım dengesizliği koruması (46)", "I2 > %10–15 In", "—", "Sarımlar arası kısa devre büyüdüğünde yakalar", "Röle laboratuvarı › Negatif bileşen", "ikincil"),
        S("Sargı sıcaklığı (PTC / PT100)", "sınıf sınırının 10–20 K altında açma", "—", "Aşırı yük, tıkalı soğutma ve sık yol vermeyi doğrudan sargıdan ölçer", "saha pratiği", "ikincil"),
        S("Titreşim izleme", "rulman frekansları, 1× ve 2× dönme, 100 Hz", "—", "Rulman ve kaçıklık arızalarını akımdan önce gösterir", "durum izleme pratiği", "ikincil"),
    ]
    test = [
        T("Sargı direnci", "Enerjisizken üç faz arası, mikroohmmetre", "üç değer %1–2 içinde eşit", "kısa devre olan fazın direnci düşüktür"),
        T("Darbe (surge) karşılaştırma testi", "İki faza aynı darbe; dalga biçimleri üst üste", "çakışır", "sarımlar arası kısa devrede salınım frekansı kayar: megerin göremediği arızayı gösterir"),
        T("Yalıtım direnci ve polarizasyon indeksi", "Meger 500–1000 V DC, 1 dk ve 10 dk", "PI ≥ 2", "Topraklama laboratuvarı › Yalıtım direnci"),
        T("Akım tayfı", "Yük altında bir fazın akımı", f"yan bantlar: {', '.join(f'{fnum(x[0], 1)} Hz' for x in tayf[1:]) or 'yok'}", "kırık çubukta ampermetre ibresi de yavaşça salınır"),
    ]
    ts = [k * 0.02 for k in range(0, 151)]
    der = 10 ** (tayf[1][1] / 20) * 2 if ar == "cubuk" else 0.0
    g1 = {"baslik": "Akımın etkin değerinin zamanla değişimi", "x_ad": "Zaman (s)", "y_ad": "Akım (A)", "zaman": True,
          "seriler": [{"ad": "arızalı", "renk": "#dc2626", "pts": pts(ts, [i_pu * amper * (1 + der * math.cos(2 * math.pi * vuru * t)) if ar == "cubuk" else (i_pu + i2) * amper for t in ts], 2)},
                      {"ad": "sağlam", "renk": "#94a3b8", "kesik": True, "pts": [[0, round(i_pu * amper, 2)], [3, round(i_pu * amper, 2)]]}]}
    tt = list(range(100, 221, 5))
    g2 = {"baslik": "Sargı sıcaklığına göre yalıtım ömrü (anma ömrünün katı)", "x_ad": "Sargı sıcaklığı (°C)", "y_ad": "Ömür katsayısı", "logy": True,
          "seriler": [{"ad": f"sınıf {k}", "renk": rk, "pts": pts(tt, [2 ** (-(x - v) / 10) for x in tt], 4)} for (k, v), rk in zip(SINIF.items(), ("#1a4d8f", "#dc2626", "#15803d"))],
          "yatay": [{"y": 1.0, "etiket": "anma ömrü", "renk": "#94a3b8"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2], "cubuklar": [tayf_cub], "ses": ses,
        "anlatim": [
            "Sağlam motorda üç faz akımı eşittir, tayfında yalnız şebeke frekansı vardır ve ses sabit bir uğultudur. Her arıza bu simetriyi kendine özgü bir biçimde bozar.",
            hukum,
            "Stator arızaları (sarımlar arası kısa devre) akımların eşitliğini bozar ve negatif bileşen üretir. Rotor arızaları (kırık çubuk, kaçıklık) akımın büyüklüğünü değiştirmez; ona kaymaya ya da dönme hızına bağlı yan bantlar ekler.",
            "Yan bantlar temel bileşenin binde biri mertebesindedir: ampermetre göstermez, koruma rölesi görmez. Tayf analizi gösterir; şiddetlendiğinde ibre ve ses yavaşça dalgalanmaya başlar.",
            "Isıl yaşlanma en sessiz arızadır: belirtisi yoktur. Yalıtım her 10 K fazlalıkta iki kat hızlı yaşlanır; sık yol verme, tıkalı fan kapağı, düşük ya da dengesiz gerilim ve aşırı yük aynı sonuca götürür.",
        ],
        "dersler": [
            "Akımlar dengesiz ama gerilimler dengeliyse arıza motordadır.",
            "Ampermetre ibresi yavaşça salınıyorsa ve ses dalgalanıyorsa rotor çubuklarından şüphelenilir.",
            "Meger sarımlar arası kısa devreyi göstermez; sargı direnci karşılaştırması ve darbe testi gösterir.",
            "Rotor arızalarının izi yük altında görünür: boşta ölçü yanıltır.",
            "Yalıtımın ömrünü sıcaklık belirler: 10 K fazlası ömrün yarısıdır.",
        ],
        "tablolar": [{"baslik": "Arıza — iz — ölçü", "cols": ["Arıza", "Akımda", "Seste / titreşimde", "En iyi gösteren ölçü"],
                      "rows": [["Sarımlar arası kısa devre", "faz akımları eşit değil, negatif bileşen", "100 Hz uğultu sertleşir", "sargı direnci, darbe testi"], ["Kırık rotor çubuğu", "(1 ± 2s)·f yan bantları; ibre salınır", "uğultu 2·s·f hızında dalgalanır", "akım tayfı (yük altında)"],
                               ["Hava aralığı kaçıklığı", "f ± fr yan bantları", "dönme hızında titreşim, 100 Hz artar", "titreşim ölçüsü, akım tayfı"], ["Rulman", "geç ve zayıf", "yüksek frekanslı hışırtı, tıkırtı; ısınma", "titreşim (zarf analizi), sıcaklık"],
                               ["Isıl yaşlanma", "yok", "yok", "sargı sıcaklığı kaydı, yalıtım direnci ve PI eğilimi"], ["Faz kaybı", "bir fazda 0 A, ikisinde ≈ √3 kat", "güçlü uğultu, titreme", "üç faz akımı"]],
                      "not": "Eşikler ve kestirim bağıntıları tanı pratiğinden alınmıştır; kesin değerlendirme motorun önceki ölçüleriyle (eğilim) yapılır."}],
    }
