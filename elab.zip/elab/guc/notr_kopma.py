"""Nötr kopması: üç fazlı, nötrlü bir beslemede nötr iletkeni koparsa tek fazlı yüklerin ortak noktası serbest kalır ve yüklerin büyüklüğüne göre kayar. Az yüklü fazın
gerilimi faz arası gerilime kadar yükselir, çok yüklü fazınki çöker. TN-C sistemde (PEN) aynı kopma gövdeleri de gerilim altında bırakır.

Hesap: yıldız noktası kayması (Millman): U(N′) = Σ(Ek·Yk) / ΣYk; faz yükleri sabit empedans (temel devre bağıntısı — hesap). Cihazların dayanabildiği gerilim (≈ 253 V sürekli,
kısa süreli 300 V üstü hasar) ve gövde gerilimi sınırı 50 V: Topraklamalar Yön. m.4, m.8 (laboratuvarın kural verisinden, resmi)."""
from __future__ import annotations

import cmath
import math

from .ortak import A, A120, C, G, K, RENK3, S, T, TEMEL, Cizim, ctl, fa, fazor, fnum, num, opt

ID = "notr_kopma"
BASLIK = "Nötr kopması"
IKON = "🧨"
GIRIS = ("Nötr iletkeni koptuğunda hiçbir sigorta atmaz; ama birkaç saniye içinde bir dairenin televizyonu yanar, öbürünün lambaları söner. Çünkü tek fazlı yüklerin ortak noktası "
         "artık şebekenin yıldız noktasına bağlı değildir ve yüklerin büyüklüğüne göre kayar. Faz yüklerini değiştirin; her fazın gerilimini izleyin.")

KONTROLLER = [
    ctl("p1", "L1 fazındaki yük", "sayi", 6.0, min=0.0, max=20, adim=0.1, birim="kW"),
    ctl("p2", "L2 fazındaki yük", "sayi", 1.5, min=0.0, max=20, adim=0.1, birim="kW"),
    ctl("p3", "L3 fazındaki yük", "sayi", 0.3, min=0.0, max=20, adim=0.1, birim="kW"),
    ctl("kopuk", "Nötr iletkeni", "sec", "kopuk", secenek=opt(("saglam", "Sağlam"), ("gevsek", "Gevşek bağlantı (yüksek direnç)"), ("kopuk", "Kopuk"))),
    ctl("rn", "Gevşek bağlantının direnci", "sayi", 5, min=0.1, max=100, adim=0.1, birim="Ω", goster={"kopuk": ["gevsek"]}),
    ctl("sistem", "Sistem", "sec", "tns", secenek=opt(("tns", "TN-S / TT: nötr ve koruma iletkeni ayrı"), ("tnc", "TN-C: ortak iletken (PEN) kopuyor"))),
    ctl("rb", "Tesisin kendi topraklama direnci (TN-C'de)", "sayi", 10, min=0.5, max=200, adim=0.5, birim="Ω", goster={"sistem": ["tnc"]}, yardim="Bina temel topraklaması / eşpotansiyel bara: kopuk PEN'in yerine akımın bir kısmını taşır"),
]


def run(p: dict) -> dict:
    guc = [num(p, "p1", 6.0), num(p, "p2", 1.5), num(p, "p3", 0.3)]
    durum, tnc = str(p.get("kopuk", "kopuk")), p.get("sistem") == "tnc"
    u = 230.0
    e = [complex(u), u * A120 ** -1, u * A120]
    y = [max(g, 1e-6) * 1000 / (u * u) for g in guc]                      # S (sabit empedans)
    rn = 1e-3 if durum == "saglam" else num(p, "rn", 5) if durum == "gevsek" else 1e9
    if tnc and durum == "kopuk":
        rn = num(p, "rb", 10) + 2.0                                        # akım tesisin topraklaması ve toprak üzerinden trafoya döner (trafo işletme topraklaması ≈ 2 Ω)
    yn = 1 / rn
    un = sum(ek * yk for ek, yk in zip(e, y)) / (sum(y) + yn)              # yıldız noktasının kayması
    uf = [ek - un for ek in e]
    i = [ufk * yk for ufk, yk in zip(uf, y)]
    i_n = un * yn
    v = [abs(x) for x in uf]
    en, ek_ = max(range(3), key=lambda k: round(v[k], 3)), min(range(3), key=lambda k: round(v[k], 3))          # eşitlikte ilk faz: yuvarlama farkı sonucu değiştirmesin
    govde = abs(un) * (num(p, "rb", 10) / (num(p, "rb", 10) + 2.0)) if (tnc and durum == "kopuk") else (abs(un) if tnc and durum != "saglam" else 0.0)
    c = Cizim(900, 300)
    for k, yy in enumerate((60, 100, 140)):
        c.hat(f"M40,{yy} H330", f"L{k + 1}", hot=abs(i[k]) > 0.05, w=3)
        c.kutu(330, yy - 14, 150, 28, f"L{k + 1} yükü {fnum(guc[k], 1)} kW", "")
        c.hat(f"M480,{yy} H540 V190", "cizgi", w=1.6)
        col = "#b91c1c" if v[k] > 253 or v[k] < 195 else "#15803d"
        c.yazi(560, yy + 5, f"{fnum(v[k], 0)} V", col, 14, kalin=True); c.yazi(630, yy + 5, ("AŞIRI GERİLİM" if v[k] > 253 else "düşük" if v[k] < 195 else "olağan") + f" · {fa(abs(i[k]), 1)}", col, 11)
    c.hat("M40,190 H250", "N", w=3)
    if durum == "saglam":
        c.hat("M250,190 H540", "N", hot=abs(i_n) > 0.05, w=3, hot_renk="mavi")
    else:
        c.hat("M250,190 l22,-14", "N", w=3); c.hat("M286,190 H540", "N", w=3, kesik=True)
        c.yazi(268, 172, "KOPUK" if durum == "kopuk" else "GEVŞEK", "#b91c1c", 11, kalin=True, anchor="middle")
    c.yazi(40, 208, ("PEN" if tnc else "N") + f" — akım {fa(abs(i_n), 1)}", "#1d4ed8", 11)
    c.yazi(40, 244, f"Yıldız noktası {fnum(abs(un), 0)} V kaydı: en yüksek {fnum(v[en], 0)} V (L{en + 1}, en az yüklü), en düşük {fnum(v[ek_], 0)} V (L{ek_ + 1})", "#b91c1c" if abs(un) > 20 else "#15803d", 12.5, kalin=True)
    if tnc and durum != "saglam":
        c.yazi(40, 268, f"TN-C: gövdeler PEN'e bağlı → gövde gerilimi ≈ {fnum(govde, 0)} V", "#b91c1c" if govde > 50 else "#334155", 12.5, kalin=True)
    else:
        c.yazi(40, 268, "Faz arası gerilimler (400 V) değişmez: üç fazlı motorlar bunu fark etmez.", "#64748b", 11.5)
    fz = {"baslik": "Faz–yıldız noktası gerilimleri", "vektorler": [fazor(f"L{k + 1}", uf[k] / 230, RENK3[k]) for k in range(3)] + [fazor("N′", un / 230, "#dc2626")] + [fazor(f"e{k + 1}", e[k] / 230, "#cbd5e1", True) for k in range(3)],
          "not": "N′: kayan yıldız noktası · kesik: kopmadan önce"}
    ozet = [
        K("Faz gerilimleri", " / ".join(fnum(x, 0) for x in v) + " V", "bad" if max(v) > 253 or min(v) < 195 else "ok", "L1 / L2 / L3"),
        K("Yıldız noktası kayması", f"{fnum(abs(un), 0)} V", "bad" if abs(un) > 20 else "ok", "sağlam nötrde ≈ 0"),
        K("En yüksek gerilim", f"{fnum(v[en], 0)} V", "bad" if v[en] > 253 else "ok", f"L{en + 1} — en az yüklü faz"),
        K("En düşük gerilim", f"{fnum(v[ek_], 0)} V", "bad" if v[ek_] < 195 else "ok", f"L{ek_ + 1} — en çok yüklü faz"),
        K("Gövde gerilimi" if tnc else "Nötr akımı", f"{fnum(govde, 0)} V" if tnc else fa(abs(i_n), 1), ("bad" if govde > 50 else "ok") if tnc else "info", "PEN'e bağlı gövdelerde" if tnc else "sağlamken dengesizlik akımı"),
    ]
    kontroller = [
        C("Bütün fazlarda gerilim kullanılabilir mi?", " / ".join(fnum(x, 0) for x in v) + " V", "207 … 253 V (230 V ± %10)", 207 <= min(v) and max(v) <= 253, "Tek fazlı cihazlar 230 V ± %10 için yapılır; 300 V'un üstünde güç kaynakları ve varistörler saniyeler içinde hasar görür", "ikincil"),
        C("Nötr sürekli mi?", {"saglam": "sağlam", "gevsek": f"gevşek ({fnum(rn, 1)} Ω)", "kopuk": "kopuk"}[durum], "kesintisiz, anahtarsız, sigortasız", durum == "saglam", "Nötr iletkeni tek başına kesilmez, sigortalanmaz; ek ve klemensleri faz iletkenleri kadar sağlam yapılır", "ikincil"),
        C("Gövde gerilimi (TN-C)", f"{fnum(govde, 0)} V" if tnc else "TN-S / TT: gövdeler ayrı iletkende", "≤ 50 V", (govde <= 50) if tnc else None, "Tehlikeli gerilim sınırı 50 V — Topraklamalar Yön. m.4, m.8; PEN koparsa gövdeler yük üzerinden faz gerilimine yaklaşır", "resmi"),
        C("Faz arası gerilimler", "400 V (değişmez)", "bilgi", None, "Kayan yalnız yıldız noktasıdır: faz arası ölçü ve üç fazlı yükler arızayı göstermez", "hesap"),
    ]
    girdiler = [
        G("Faz yükleri", " / ".join(f"{fnum(g, 1)} kW" for g in guc), "Pano analizörü; hangi dairenin hangi fazda olduğu", "Kayma, yüklerin eşitsizliğiyle orantılıdır: yükler eşitse kopma fark edilmez", "U(N′) = Σ Ek·Yk / Σ Yk"),
        G("Nötrün durumu", durum, "Bağlantı kutusu, pano nötr barası, direk üstü ek", "Gevşek bağlantı da aynı etkiyi küçük ölçekte yapar ve ısınır", "seri direnç"),
        G("Sistem", "TN-C (PEN)" if tnc else "TN-S / TT", "Tesisin topraklama şeması", "PEN kopması gerilim kaymasına ek olarak gövdeleri gerilim altında bırakır", "Topraklama laboratuvarı › Şebeke tipleri"),
    ]
    adimlar = [
        A("Yük admitansları", "Yk = Pk / U²", " · ".join(f"{fnum(yk * 1000, 1)} mS" for yk in y), "sabit empedanslı yük kabulü", "anma geriliminde çekilen güçten", "hesap", ["Faz yükleri"]),
        A("Yıldız noktasının kayması", "U(N′) = (E1·Y1 + E2·Y2 + E3·Y3) / (Y1 + Y2 + Y3 + Yn)", f"Yn = {fnum(yn * 1000, 1)} mS", f"{fnum(abs(un), 0)} V ∠ {fnum(math.degrees(cmath.phase(un)) if abs(un) > 1e-9 else 0, 0)}°", "Millman teoremi", "hesap", ["Nötrün durumu"]),
        A("Faz gerilimleri", "Uk = Ek − U(N′)", "fazör farkı", " / ".join(f"{fnum(x, 0)} V" for x in v), TEMEL, "hesap"),
        A("En kötü durum", "iki fazda yük, birinde hiç yok → yüksüz faz 400 V'a yaklaşır", "sınır durum", f"şimdi en yüksek {fnum(v[en], 0)} V", "seri bağlı iki yük faz arası gerilimi paylaşır", "hesap"),
    ]
    ayarlar = [
        S("Gerilim denetim rölesi (aşırı / düşük gerilim, nötr kaybı)", "> 253 V ve < 195 V · 0,1–1 s", "—", "Nötr kopmasını gerilimden algılayan tek koruma; ana kesiciyi açtırır", "saha pratiği", "ikincil"),
        S("Aşırı gerilim koruyucu (parafudr)", "nötr kopmasına karşı korumaz", "—", "Saniyelerce süren 300–400 V'u söndüremez; kendisi yanar", "Topraklama laboratuvarı › Yıldırım ve parafudr", "ikincil"),
        S("PEN'in tesiste yeniden topraklanması", "bina girişinde eşpotansiyel bara + temel topraklaması", "—", "PEN koptuğunda gövde gerilimini sınırlar", "Topraklamalar Yön. m.8", "ikincil"),
    ]
    test = [T("Faz–nötr gerilimleri", "Üç fazı nötre göre, yük altında", " / ".join(f"{fnum(x, 0)} V" for x in v), "üçünün toplamı ≈ 690 V kalırken biri yüksek, biri düşükse nötr kopuktur"),
            T("Nötr sürekliliği", "Enerjisizken, panodan trafoya / ana panoya", "≈ 0 Ω", "gevşek nötr klemensi ısınır: termal kamerada görünür"),
            T("Faz arası gerilim", "L1–L2, L2–L3, L3–L1", "400 V (olağan)", "bu ölçü arızayı göstermez")]
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(fazor=fz),
        "anlatim": [
            "Tek fazlı yükler bir uçlarından faza, öbür uçlarından nötre bağlıdır. Nötr, bu yüklerin ortak noktasını trafonun yıldız noktasına bağlar ve her yükün tam 230 V görmesini sağlar. Fazlar arasındaki yük farkının akımı nötrden döner.",
            ("Nötr kopunca ortak nokta serbest kalır. Üç yük artık yıldız bağlı, yıldız noktası boşta bir devredir; 400 V'luk faz arası gerilimleri empedanslarıyla ters orantılı paylaşırlar."
             if durum != "saglam" else "Nötr sağlam: yükler ne kadar eşitsiz olursa olsun her faz 230 V görür; fark nötr akımı olarak döner."),
            f"Büyük yük küçük empedanstır ve az gerilim alır; küçük yük büyük empedanstır ve çok gerilim alır. Burada L{ek_ + 1} ({fnum(guc[ek_], 1)} kW) {fnum(v[ek_], 0)} V'a düşüyor, L{en + 1} ({fnum(guc[en], 1)} kW) {fnum(v[en], 0)} V'a çıkıyor.",
            "Hiçbir aşırı akım koruması bunu görmez: akımlar küçülmüştür. Faz arası gerilim değişmediği için üç fazlı ölçü de görmez. Arıza, yanan cihazlarla anlaşılır: önce az yüklü fazdaki elektronik cihazlar, televizyonlar, şarj aletleri.",
            ("TN-C sistemde aynı iletken koruma iletkenidir de: kopunca tesisin bütün gövdeleri, yükler üzerinden faza bağlı kalır. Gövde gerilimini yalnız tesisin kendi topraklaması sınırlar: burada yaklaşık " + fnum(govde, 0) + " V."
             if tnc else "TN-S ve TT sistemde koruma iletkeni ayrıdır: nötr kopması cihazları yakar ama gövdeleri gerilim altında bırakmaz."),
            "Gevşek bir nötr bağlantısı aynı olayın yavaş biçimidir: direnç büyüdükçe kayma artar, bağlantı ısınır ve sonunda kopar.",
        ],
        "dersler": [
            "Nötr koparsa az yüklü fazın gerilimi yükselir, çok yüklü fazınki düşer; toplamları sabit kalır.",
            "En kötü durum: bir faz yüksüz → o fazda 400 V'a yakın gerilim.",
            "Sigorta, otomat ve kaçak akım rölesi nötr kopmasını görmez; gerilim denetim rölesi görür.",
            "Nötr tek başına kesilmez ve sigortalanmaz.",
            "TN-C'de PEN kopması can güvenliği arızasıdır: gövdeler gerilim altında kalır.",
        ],
    }
