"""Dengesiz yük ve nötr: tek fazlı yükler fazlara eşit dağılmadığında AG gerilimleri, nötr akımı, yıldız noktasının kayması ve sargı yüklenmesi;
bağlantı grubunun (Dyn, Yzn, Yyn) farkı.

Model: trafo_model.hesapla (faz koordinatlarında devre çözümü). Dyn ve Yzn trafolarda AG'deki sıfır bileşen akımının amper-sarımı YG tarafında karşılanır
(üçgende dolaşarak, zikzakta iki bacağa bölünerek); Yyn trafoda karşılanamaz: sıfır bileşen akısı çekirdekten dışarı (tank, hava) dönmek zorunda kalır ve yıldız
noktası kayar. Üç bacaklı çekirdek için sıfır bileşen mıknatıslanma empedansı 0,6 pu alınmıştır (tipik, tahmini)."""
from __future__ import annotations

import math

from . import trafo_model as M
from .ortak import A, C, G, K, RENK3, S, T, TEMEL, Cizim, ctl, fa, fazor, fnum, num, opt, tr_al, tr_ctl, tr_girdi

ID = "trafo_dengesiz"
BASLIK = "Dengesiz yük ve nötr"
IKON = "⚖"
GIRIS = ("Tek fazlı alıcılar üç faza eşit dağılmaz. Dengesiz yükte nötrden akım akar, AG gerilimleri birbirinden ayrılır ve bir sargı ötekilerden çok ısınır. "
         "Aynı yükü Dyn, Yzn ve Yyn trafoda deneyin: yıldız noktasının neden kaydığını ve dağıtımda neden Dyn / Yzn kullanıldığını izleyin.")

KONTROLLER = tr_ctl() + [
    ctl("grup", "Bağlantı grubu", "sec", "Dyn11", secenek=opt(*[(g, g) for g in M.GRUPLAR])),
    ctl("y1", "L1 fazının yükü", "sayi", 100, min=0, max=150, adim=5, birim="%", yardim="Faz başına anma gücünün yüzdesi (Sn/3)"),
    ctl("y2", "L2 fazının yükü", "sayi", 40, min=0, max=150, adim=5, birim="%"),
    ctl("y3", "L3 fazının yükü", "sayi", 20, min=0, max=150, adim=5, birim="%"),
    ctl("cos", "Güç katsayısı", "sayi", 0.95, min=0.5, max=1.0, adim=0.01),
    ctl("cekirdek", "Çekirdek", "sec", "3", secenek=opt(("3", "Üç bacaklı (dağıtım trafosu)"), ("5", "Beş bacaklı / kabuk tipi / üç ayrı tek fazlı trafo"))),
]


def coz(tr: dict, grup: str, y: list, cosf: float, cek: str) -> dict:
    zk = complex(tr["ur"], tr["ux"]) / 100
    zs = complex(0.1, 1.0) * (tr["sn"] / 1000 / 350)
    return M.hesapla(grup, zk, zs, (False, False, False), {"s": 1.0, "cos": cosf, "motor": 0.0, "tek": y}, cekirdek=cek)


def run(p: dict) -> dict:
    tr = tr_al(p)
    grup, cosf, cek = str(p.get("grup", "Dyn11")), num(p, "cos", 0.95), str(p.get("cekirdek", "3"))
    y = [num(p, "y1", 100) / 100, num(p, "y2", 40) / 100, num(p, "y3", 20) / 100]
    r = coz(tr, grup, y, cosf, cek)
    ua = [abs(x) for x in r["ua"]]; ia = [abs(x) for x in r["ia"]]; iy = [abs(x) for x in r["iy"]]
    inotr = abs(r["inotr"])
    v0, v1, v2 = M.dizi(r["ua"])
    ks = r["k_sargi"]; ks_max = max(ks); k_eq = math.sqrt(r["kayip"])
    toplam = sum(y) / 3
    c = Cizim(900, 330)
    c.daire(120, 110, 34, "cizgi"); c.daire(168, 110, 34, "cizgi")
    c.sarim(116, 110, "ucgen" if grup[0] == "D" else "yildiz", r=16); c.sarim(172, 112, "yildiz", r=16)
    c.yazi(144, 60, f"{grup} · {fnum(tr['sn'], 0)} kVA", "#475569", 10.5, anchor="middle")
    for j, yy in enumerate((80, 110, 140)):
        c.hat(f"M20,{yy} H86", f"L{j + 1}", hot=iy[j] > 0.02, w=3); c.yazi(22, yy - 6, fa(iy[j] * tr["i1"], 1), "#334155", 10)
        c.hat(f"M202,{yy} H520", f"L{j + 1}", hot=ia[j] > 0.02, w=3)
        c.yazi(250, yy - 6, f"{fnum(ia[j] * tr['i2'], 0)} A", "#b91c1c" if ia[j] > 1.0 else "#334155", 11, kalin=ia[j] > 1.0)
        c.kutu(520, yy - 13, 150, 26, f"L{j + 1}–N yükü %{fnum(y[j] * 100, 0)}", "")
        c.yazi(684, yy + 4, f"{fnum(ua[j] * 231, 0)} V", "#15803d" if 0.9 <= ua[j] <= 1.1 else "#b91c1c", 13, kalin=True)
    c.hat("M168,146 V186 H595 V153", "N", hot=inotr > 0.02, w=2.4, hot_renk="mavi"); c.toprak(168, 188)
    c.yazi(330, 180, f"nötr akımı {fnum(inotr * tr['i2'], 0)} A", "#1d4ed8", 12, kalin=True)
    c.yazi(684, 66, "faz–nötr gerilimi", "#64748b", 10)
    c.yazi(20, 232, f"Yıldız noktasının kayması (sıfır bileşen gerilimi): %{fnum(abs(v0) * 100, 1)} = {fnum(abs(v0) * 231, 0)} V", "#b91c1c" if abs(v0) > 0.03 else "#15803d", 13, kalin=True)
    c.yazi(20, 256, f"Sargı yüklenmesi: bacak 1 %{fnum(ks[0] * 100, 0)} · bacak 2 %{fnum(ks[1] * 100, 0)} · bacak 3 %{fnum(ks[2] * 100, 0)} — toplam yük %{fnum(toplam * 100, 0)}", "#b91c1c" if ks_max > 1 else "#334155", 12)
    c.yazi(20, 280, ("Yyn: AG'deki sıfır bileşen akımının YG'de karşılığı yok; akı çekirdekten dışarı dönüyor, yıldız noktası kayıyor." if grup == "Yyn0" else
                     "Dyn: sıfır bileşen akımının amper-sarımı üçgen sargıda karşılanır; yıldız noktası yerinde kalır." if grup[0] == "D" else
                     "Yzn: her AG fazı iki bacağa yayılı; tek fazlı yük YG'de iki faza bölünür, yıldız noktası yerinde kalır."), "#1a4d8f", 11.5)
    c.yazi(20, 304, "Dağıtım trafoları %100 dengesiz yükte sürekli çalışmaya uygun yapılır: sınırlayan, en yüklü sargı ve nötrdür.", "#64748b", 11)
    fz = {"baslik": "AG faz–nötr gerilimleri", "vektorler": [fazor(f"L{j + 1}", r["ua"][j], RENK3[j]) for j in range(3)] + [fazor("V0", v0, "#dc2626")], "not": "V0: yıldız noktasının kayması"}
    fz2 = {"baslik": "AG akımları ve nötr akımı", "vektorler": [fazor(f"L{j + 1}", r["ia"][j], RENK3[j]) for j in range(3)] + [fazor("IN", r["inotr"], "#1d4ed8", True)], "not": "IN = I1 + I2 + I3"}
    ozet = [
        K("Faz–nötr gerilimleri", " / ".join(fnum(u * 231, 0) for u in ua) + " V", "ok" if min(ua) >= 0.9 and max(ua) <= 1.1 else "bad", "L1 / L2 / L3"),
        K("Nötr akımı", f"{fnum(inotr * tr['i2'], 0)} A", "warn" if inotr > 0.5 else "ok", f"anma faz akımının %{fnum(inotr * 100, 0)}'i"),
        K("Yıldız noktası kayması", f"{fnum(abs(v0) * 231, 0)} V", "bad" if abs(v0) > 0.05 else "ok", f"sıfır bileşen %{fnum(abs(v0) * 100, 1)}"),
        K("En yüklü sargı", f"%{fnum(ks_max * 100, 0)}", "bad" if ks_max > 1.0 else "ok", f"toplam yük %{fnum(toplam * 100, 0)}"),
        K("Dengesizlik (V2/V1)", f"%{fnum(abs(v2) / abs(v1) * 100, 1)}", "ok" if abs(v2) / abs(v1) <= 0.02 else "warn", "motorların gördüğü"),
    ]
    kontroller = [
        C("Bütün fazlarda gerilim kullanılabilir mi?", " / ".join(f"%{fnum(u * 100, 0)}" for u in ua), "%90 … %110", min(ua) >= 0.9 and max(ua) <= 1.1, "Az yüklü fazın gerilimi yükselir, çok yüklü fazınki düşer; Yyn trafoda fark büyüktür", "hesap"),
        C("Hiçbir sargı anma akımını aşmıyor mu?", f"en yüklü bacak %{fnum(ks_max * 100, 0)}", "≤ %100", ks_max <= 1.0, "Toplam yük anma gücünün altında olsa da tek bir faz aşırı yüklenebilir", "hesap"),
        C("Nötr akımı", f"{fnum(inotr * tr['i2'], 0)} A", f"≤ {fnum(tr['i2'], 0)} A (faz anma akımı)", inotr <= 1.0, "AG sargısının nötrü hat uçlarıyla aynı yalıtım düzeyinde ve tam kesittedir; nötr iletkeni buna göre seçilir — " + tr["kaynak"], "resmi"),
        C("Dengesiz yükte sürekli çalışma", "%100 dengesiz yüklemeye uygun", "şartname koşulu", None, "Transformatörler %100 dengesiz yüklemede sürekli çalışmaya uygun olacaktır — " + tr["kaynak"] + (" böl. 2.2.12" if tr["tip"] == "kuru" else " böl. 2.2.14"), "resmi"),
        C("Yıldız noktası kayması", f"%{fnum(abs(v0) * 100, 1)}", "≤ %3", abs(v0) <= 0.03, "Sıfır bileşen akımının amper-sarımı YG'de karşılanmazsa çekirdekte sıfır bileşen akısı oluşur", "hesap"),
    ]
    girdiler = tr_girdi(tr) + [
        G("Faz akımları", " / ".join(f"{fnum(x * tr['i2'], 0)} A" for x in ia), "AG ana pano analizörü ya da pens ampermetre, üç faz ve nötr", "Dengesizliği ve nötr akımını yalnız ölçü gösterir; sayaç toplamı göstermez", "IN = I1 + I2 + I3 (fazör toplamı)"),
        G("Bağlantı grubu", grup, "Trafo etiketi", "Sıfır bileşen akımının YG'ye nasıl yansıdığını belirler", "Dyn: üçgende dolaşır · Yzn: iki bacağa bölünür · Yyn: karşılanamaz"),
    ]
    adimlar = [
        A("Nötr akımı", "IN = I1 + I2 + I3", " + ".join(f"{fnum(abs(x) * tr['i2'], 0)} A ∠ {fnum(math.degrees(math.atan2(x.imag, x.real)), 0)}°" for x in r["ia"]), f"{fnum(inotr * tr['i2'], 0)} A", TEMEL, "hesap", ["Faz akımları"]),
        A("Sıfır bileşen akımı", "I0 = IN / 3", f"{fnum(inotr * tr['i2'], 0)} / 3", f"{fnum(inotr * tr['i2'] / 3, 0)} A", "üç fazda aynı yönde akan ortak bileşen", "hesap"),
        A("Sıfır bileşenin YG'deki karşılığı", "Dyn: üçgen sargıda dolaşır · Yzn: iki bacakta zıt yönlü · Yyn: yok", f"grup {grup}", "karşılanıyor" if grup != "Yyn0" else "karşılanmıyor → çekirdekte sıfır bileşen akısı", "bacak başına amper-sarım dengesi", "hesap", ["Bağlantı grubu"]),
        A("Yıldız noktasının kayması", "V0 = I0 · Z0(trafo)", "Z0: Dyn/Yzn'de ≈ uk · Yyn'de sıfır bileşen mıknatıslanma empedansı", f"%{fnum(abs(v0) * 100, 1)} = {fnum(abs(v0) * 231, 0)} V", "üç bacaklı çekirdekte Z0m ≈ 0,6 pu (tipik)", "tahmini" if grup == "Yyn0" else "hesap"),
        A("Sargı yüklenmesi", "her bacakta sargı akımı / anma akımı", "devre çözümünden", f"en yüklü %{fnum(ks_max * 100, 0)} · eşdeğer kayıp yükü %{fnum(k_eq * 100, 0)}", "yük kaybı her sargıda akımın karesiyle oluşur", "hesap"),
    ]
    ayarlar = [
        S("AG ana kesici › nötr koruması", "%50 ya da %100 In", "açtırıcıya göre", "Nötr iletkeni faz kesitindeyse %100; küçükse %50 seçilir", "saha pratiği", "ikincil"),
        S("AG ana kesici › faz aşırı yük (L)", "her faz ayrı ölçülür", "—", "Tek bir fazın aşırı yükü de açtırır; trafonun en yüklü sargısını korur", "saha pratiği", "ikincil"),
        S("Yük dağılımı", "tek fazlı linyeler üç faza eşit dağıtılır", "—", "Dengesizliğin çaresi korumada değil, panodaki faz dağılımındadır", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Faz ve nötr akımları", "Ana panoda üç faz ve nötr, pens ampermetre", " / ".join(f"{fnum(x * tr['i2'], 0)}" for x in ia) + f" A · nötr {fnum(inotr * tr['i2'], 0)} A", "harmonikli yükte nötr akımı fazör toplamından büyük çıkar"),
        T("Faz–nötr gerilimleri", "Ana panoda, yük altında", " / ".join(f"{fnum(u * 231, 0)} V" for u in ua), "fazlar arası fark birkaç volttan fazlaysa dağılım düzeltilir"),
        T("Nötr–toprak gerilimi", "Trafo yıldız noktası ile uzak panodaki nötr arası", "nötr iletkenindeki düşüm kadar (birkaç volt)", "yüksekse nötr bağlantısı gevşek ya da kesit yetersiz"),
    ]
    satir = []
    for g_, ck in (("Dyn11", "3"), ("Yzn11", "3"), ("Yyn0", "3"), ("Yyn0", "5")):
        q = coz(tr, g_, y, cosf, ck); z0 = M.dizi(q["ua"])[0]
        satir.append([g_ + (" (üç bacaklı)" if ck == "3" else " (beş bacaklı)"), " / ".join(fnum(abs(u) * 231, 0) for u in q["ua"]), f"{fnum(abs(z0) * 231, 0)} V", f"%{fnum(max(q['k_sargi']) * 100, 0)}", " / ".join(fa(abs(i) * tr["i1"], 1) for i in q["iy"])])
    cub = {"baslik": "Faz faz: yük, gerilim ve sargı yüklenmesi", "kategoriler": ["L1", "L2", "L3"], "y_ad": "%",
           "seriler": [{"ad": "yük", "renk": "#6b7280", "deger": [round(v * 100, 1) for v in y]}, {"ad": "faz–nötr gerilimi", "renk": "#1a4d8f", "deger": [round(u * 100, 1) for u in ua]},
                       {"ad": "sargı yüklenmesi", "renk": "#dc2626", "deger": [round(x * 100, 1) for x in ks]}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(fazorler=[fz, fz2]), "cubuklar": [cub],
        "anlatim": [
            f"Fazlar %{fnum(y[0] * 100, 0)} / %{fnum(y[1] * 100, 0)} / %{fnum(y[2] * 100, 0)} yüklü. Üç akımın fazör toplamı sıfır değil: fark nötrden döner ({fnum(inotr * tr['i2'], 0)} A).",
            "Nötr akımı üç fazda ortak bir bileşen demektir (sıfır bileşen). AG sargısındaki bu akımın oluşturduğu amper-sarımın YG sargısında bir karşılığı olması gerekir; yoksa çekirdeği mıknatıslar.",
            ("Üçgen sargıda karşılık kendiliğinden oluşur: sıfır bileşen akımı üçgenin içinde dolaşır, YG hatlarına çıkmaz. Çekirdekte fazladan akı oluşmaz, yıldız noktası yerinde kalır." if grup[0] == "D" else
             "Zikzak sargıda her AG fazı iki ayrı bacağa yarı yarıya sarılıdır: sıfır bileşen amper-sarımları her bacakta birbirini götürür. YG yıldız sargısı tek fazlı yükü iki fazdan çeker." if "z" in grup else
             "Yyn trafoda YG yıldız noktası yalıtılmıştır: sıfır bileşen akımı YG'den akamaz. Karşılanmayan amper-sarım üç bacakta aynı yönde akı üretir; bu akı demirden dönemez, tank ve hava üzerinden döner. Sonuç: yıldız noktası yüklü faza doğru kayar."),
            f"Bu trafoda yıldız noktası {fnum(abs(v0) * 231, 0)} V kayıyor: faz–nötr gerilimleri {fnum(ua[0] * 231, 0)} / {fnum(ua[1] * 231, 0)} / {fnum(ua[2] * 231, 0)} V. Faz arası gerilimler neredeyse değişmez; bozulan faz–nötr gerilimleridir.",
            f"En yüklü bacağın sargısı %{fnum(ks_max * 100, 0)} yükleniyor. Trafonun toplam yükü %{fnum(toplam * 100, 0)} olsa da ısınmayı ve ömrü en sıcak sargı belirler.",
        ],
        "dersler": [
            "Dağıtımda Dyn ve Yzn kullanılmasının nedeni budur: tek fazlı yük yıldız noktasını kaydırmaz.",
            "Yyn trafoda (üç bacaklı) nötr yükü sınırlıdır; tank ısınır ve faz–nötr gerilimleri ayrışır.",
            "Trafo «%60 yüklü» olabilir ama bir fazı %100'ün üstünde: sayaç toplamı değil faz akımları izlenir.",
            "Nötr akımı fazör toplamıdır: üç faz eşit ve dengeliyse sıfırdır; üçüncü harmonik akımları ise nötrde toplanır (Topraklama laboratuvarı › Harmonikler).",
        ],
        "tablolar": [{"baslik": "Aynı yük, farklı bağlantı grubu", "cols": ["Grup", "Faz–nötr gerilimleri (V)", "Yıldız noktası kayması", "En yüklü sargı", "YG hat akımları"], "rows": satir,
                      "not": "Yyn trafonun beş bacaklı ya da üç ayrı tek fazlı trafodan kurulu olması durumunda kayma daha da büyür: sıfır bileşen akısı demirden dönebilir, mıknatıslanma empedansı çok büyüktür."}],
    }
