"""Ark enerjisi: ark bir iletken değil, 10 000–20 000 °C'lik bir plazma sütunudur; üstünde gerilim düşer ve güç harcanır. Akıma, ark boyuna ve süreye göre
ark gerilimi, gücü, enerjisi; bu enerjinin erittiği ve buharlaştırdığı metal; AG'de arkın akımı sınırlaması.

Ark gerilimi ≈ 30 V (elektrot düşümleri) + ≈ 12 V/cm (sütun) ve enerjinin elektrotlara giden payı (≈ %10 erime, ≈ %2 buharlaşma) tipik değerlerdir (tahmini).
Metalin erime ve buharlaşma ısıları fizik çizelgelerinden (hesap). Bakır buharının katı hacminin on binlerce katına genleştiği saha eğitimlerinde anılan bir
değerdir (ikincil). AG'de ark akımı için IEEE 1584-2002 bağıntısı bellekten (dogrulanacak)."""
from __future__ import annotations

import math

from . import fizik as F
from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, logsp, num, opt, pts

ID = "ark_enerji"
BASLIK = "Ark enerjisi"
IKON = "☄"
GIRIS = ("Kısa devre akımı metalden metale değil havadan geçiyorsa ortada bir ark vardır: güneşin yüzeyinden sıcak bir plazma sütunu. Arkın üstünde düşen gerilim ile akımın çarpımı "
         "megavatlar eder ve bu güç ışık, ısı, basınç ve erimiş metal olarak çevreye yayılır. Akımı, ark boyunu ve süreyi değiştirin; açığa çıkan enerjiyi izleyin.")
KORUMA = {"sinir": ("Akım sınırlayan sigorta", 0.005), "ark": ("Ark rölesi + kesici", 0.07), "ani": ("Ani aşırı akım + kesici", 0.1), "gecikmeli": ("Gecikmeli aşırı akım + kesici", 0.5), "yedek": ("Yedek koruma (üst kademe)", 1.0)}

KONTROLLER = [
    ctl("u", "Sistem gerilimi", "sec", 34.5, secenek=opt((0.4, "0,4 kV (AG pano)"), (6.3, "6,3 kV"), (10.5, "10,5 kV"), (34.5, "34,5 kV (OG hücre)"))),
    ctl("ik", "Kısa devre akımı (ark yokken)", "sayi", 16.0, min=1, max=65, adim=0.5, birim="kA"),
    ctl("l", "Ark boyu (elektrot aralığı)", "sayi", 30, min=1, max=60, adim=1, birim="cm", yardim="AG panoda 2–5 cm; 36 kV hücrede 25–35 cm"),
    ctl("faz", "Ark", "sec", 3, secenek=opt((3, "Üç fazlı"), (1, "Tek fazlı (faz–toprak)"))),
    ctl("koruma", "Arkı temizleyen koruma", "sec", "gecikmeli", secenek=opt(*[(k, f"{v[0]} (≈ {fnum(v[1] * 1000, 0)} ms)") for k, v in KORUMA.items()])),
    ctl("metal", "Elektrot metali", "sec", "cu", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum"), ("fe", "Çelik"))),
]


def hesap(u: float, ik: float, l: float, faz: int, t: float) -> dict:
    ua = F.ark_gerilimi(l)
    if u < 1.0:                                                    # AG'de ark gerilimi kaynak gerilimine yakındır: akım düşer
        ia = F.ieee1584(u, ik, 0.2, 455, l * 10, True, True, 1.641)["ia"]
        ua = min(ua, 0.75 * u * 1000 / math.sqrt(3))
    else:
        ia = ik * 0.98
    p = faz * ua * ia * 1000 / 1e6                                 # MW
    return {"ua": ua, "ia": ia, "p": p, "e": p * t}                # MJ


def run(p: dict) -> dict:
    u, ik, l, faz = num(p, "u", 34.5), num(p, "ik", 16.0), num(p, "l", 30), int(num(p, "faz", 3))
    kor = str(p.get("koruma", "gecikmeli")); kad, t = KORUMA[kor]
    metal = str(p.get("metal", "cu")); m = F.METAL[metal]
    h = hesap(u, ik, l, faz, t)
    e = h["e"]
    e_eri = (m["c"] * (m["erime"] - 20) + m["le"] * 1e3) / 1e6      # MJ/kg (eritmek)
    kg_eri = 0.10 * e / e_eri
    kg_buh = 0.02 * e / F.metal_enerji(metal)
    litre = kg_buh / m["yog"] * 1000 * 40000                         # buhar hacmi (litre): katı hacminin ≈ 40 000 katı (sıcak buhar; mertebe)
    tnt = e / 4.184
    su = e * 1e6 / (4186 * 80) / 1000                                # kaç m³ suyu 20 → 100 °C ısıtır
    c = Cizim(900, 290)
    c.dikdortgen(120, 60, 26, 150, "cizgi", "#fbbf24" if metal == "cu" else "#cbd5e1"); c.dikdortgen(120 + 26 + min(max(l * 5, 40), 240), 60, 26, 150, "cizgi", "#fbbf24" if metal == "cu" else "#cbd5e1")
    x1, x2 = 146, 146 + min(max(l * 5, 40), 240)
    c.alan(f"M{x1},110 Q{(x1 + x2) / 2},70 {x2},110 L{x2},160 Q{(x1 + x2) / 2},200 {x1},160 Z", "uyari", 0.45, "ariza")
    c.hat(f"M{x1},135 Q{(x1 + x2) / 2},118 {x2},135", "ariza", hot=True, w=5)
    c.yazi((x1 + x2) / 2, 60, f"ark: {fnum(l, 0)} cm · {fnum(h['ua'], 0)} V", "#b91c1c", 12.5, kalin=True, anchor="middle")
    c.yazi((x1 + x2) / 2, 236, "≈ 10 000 – 20 000 °C", "#b45309", 11.5, anchor="middle")
    c.yazi(60, 135, f"{fnum(h['ia'], 1)} kA", "#b91c1c", 12.5, kalin=True, anchor="middle"); c.ok(84, 140, 118, 140, "ariza", 3)
    c.yazi(520, 56, f"Ark gücü {fnum(h['p'], 1)} MW", "#b91c1c", 14, kalin=True)
    c.yazi(520, 82, f"{kad}: {fnum(t * 1000, 0)} ms → {fnum(e, 2)} MJ", "#b91c1c", 13.5, kalin=True)
    c.yazi(520, 108, f"≈ {fnum(tnt, 2)} kg TNT · {fnum(su * 1000, 0)} litre suyu kaynatır", "#334155", 12)
    c.yazi(520, 136, f"Eriyen {m['ad'].lower()} ≈ {fnum(kg_eri * 1000, 0)} g · buharlaşan ≈ {fnum(kg_buh * 1000, 0)} g", "#334155", 12.5)
    c.yazi(520, 160, f"Metal buharı ≈ {fnum(litre, 0)} litre hacim kaplar", "#334155", 12.5)
    if u < 1.0:
        c.yazi(520, 188, f"AG'de ark akımı sınırlar: {fnum(ik, 1)} kA yerine {fnum(h['ia'], 1)} kA", "#1a4d8f", 12, kalin=True)
        c.yazi(520, 206, "(ark gerilimi kaynak geriliminin büyük bir kesri)", "#64748b", 10.5)
    else:
        c.yazi(520, 188, "OG'de ark gerilimi kaynak geriliminin yanında küçüktür:", "#1a4d8f", 12); c.yazi(520, 206, "ark akımı ≈ kısa devre akımı.", "#1a4d8f", 12)
    c.yazi(520, 238, "Enerji = güç × süre: gücü şebeke, süreyi koruma belirler.", "#64748b", 11.5)
    ozet = [
        K("Ark gerilimi", f"{fnum(h['ua'], 0)} V", "info", f"30 V + 12 V/cm × {fnum(l, 0)} cm" + (" (AG'de sınırlı)" if u < 1 else "")),
        K("Ark akımı", f"{fnum(h['ia'], 1)} kA", "warn", f"kısa devre akımının %{fnum(h['ia'] / ik * 100, 0)}'i"),
        K("Ark gücü", f"{fnum(h['p'], 1)} MW", "bad", f"{faz} faz × U(ark) × I"),
        K("Ark enerjisi", f"{fnum(e, 2)} MJ", "bad" if e > 1 else "warn" if e > 0.1 else "ok", f"{fnum(t * 1000, 0)} ms'de · ≈ {fnum(tnt, 2)} kg TNT"),
        K("Buharlaşan metal", f"{fnum(kg_buh * 1000, 0)} g", "bad" if kg_buh > 0.02 else "warn", f"≈ {fnum(litre, 0)} litre buhar · eriyen {fnum(kg_eri * 1000, 0)} g"),
    ]
    e_ark = hesap(u, ik, l, faz, KORUMA["ark"][1])["e"]
    kontroller = [
        C("Ark enerjisi sınırlı mı?", f"{fnum(e, 2)} MJ", "≤ 0,1–0,25 MJ: hasar sınırlı (kablo ve bara yanığı)", e <= 0.25, "Saha deneyiminde yaklaşık 100 kJ'ün altında donanım onarılabilir kalır; üstünde bara ve mahfaza yanar — mertebe", "ikincil"),
        C("Süre kısaltılırsa?", f"ark rölesiyle {fnum(e_ark, 2)} MJ", f"şimdi {fnum(e, 2)} MJ", None, "Enerji süreyle doğru orantılıdır: 500 ms yerine 70 ms, enerjinin yedide biri", "hesap"),
        C("AG'de ark akımı aşırı akım ani eşiğinin üstünde mi?", f"{fnum(h['ia'], 1)} kA", "ani kademe ayarının üstünde olmalı", None if u >= 1 else (h["ia"] > 0.5 * ik),
          "AG'de ark akımı kısa devre akımının yarısına kadar düşebilir; ani kademe buna göre ayarlanmadıysa ark gecikmeli kademede kalır ve enerji katlanır — IEEE 1584-2002 bağıntısı (doğrulanacak)", "dogrulanacak"),
        C("Metalin buharlaşması", f"{fnum(kg_buh * 1000, 0)} g → {fnum(litre, 0)} litre", "bilgi", None, "Bakır buharlaşırken hacmi on binlerce kat büyür: basınç dalgasının bir bölümü buradan gelir; buhar soğuyunca her yüzeye iletken kurum olarak çöker", "ikincil"),
    ]
    girdiler = [
        G("Kısa devre akımı", f"{fnum(ik, 1)} kA", "Kısa devre hesabı: arkın olabileceği noktada", "Arkın gücünü akım belirler", "P = U(ark) × I"),
        G("Ark boyu", f"{fnum(l, 0)} cm", "Faz arası / faz–toprak açıklığı", "Ark gerilimi boyla artar; ark manyetik kuvvetle uzar ve kaçar", "U(ark) ≈ 30 + 12·l"),
        G("Temizleme süresi", f"{fnum(t * 1000, 0)} ms ({kad})", "Koruma ayarları: algılama + kesici açma süresi", "Enerjiyi belirleyen ve değiştirilebilen tek büyüklük", "E = P × t"),
    ]
    adimlar = [
        A("Ark gerilimi", "U ≈ 30 V + 12 V/cm · l", f"30 + 12 × {fnum(l, 0)}", f"{fnum(h['ua'], 0)} V", "elektrot düşümleri + plazma sütunu — tipik", "tahmini", ["Ark boyu"]),
        A("Ark akımı", "OG: ≈ Ik · AG: IEEE 1584 bağıntısı", f"Ik = {fnum(ik, 1)} kA", f"{fnum(h['ia'], 1)} kA", "AG'de ark gerilimi kaynak gerilimine yakın olduğundan akım düşer", "dogrulanacak" if u < 1 else "hesap", ["Kısa devre akımı"]),
        A("Ark gücü", "P = n · U(ark) · I", f"{faz} × {fnum(h['ua'], 0)} V × {fnum(h['ia'], 1)} kA", f"{fnum(h['p'], 1)} MW", "her fazın arkında ayrı güç", "hesap"),
        A("Enerji", "E = P · t", f"{fnum(h['p'], 1)} MW × {fnum(t, 3)} s", f"{fnum(e, 2)} MJ", "güç sabit alınır", "hesap", ["Temizleme süresi"]),
        A("Eriyen ve buharlaşan metal", "m = pay · E / (birim kütle için gereken ısı)", f"eritme {fnum(e_eri, 2)} MJ/kg · buharlaştırma {fnum(F.metal_enerji(metal), 1)} MJ/kg", f"{fnum(kg_eri * 1000, 0)} g · {fnum(kg_buh * 1000, 0)} g", "enerjinin elektrotlara giden payı tipik", "tahmini"),
    ]
    ayarlar = [
        S("Ark rölesi (ışık + akım)", "algılama 2–7 ms; kesiciyle ≈ 60–80 ms", "—", "Arkın ışığını görür: süreyi kesici süresine indirir", "Röle laboratuvarı › Ark koruması", "ikincil"),
        S("Ani aşırı akım kademesi", "ark akımının altında (AG'de Ik'nın %40–50'si)", "—", "Ani kademe ark akımını görmezse ark gecikmeli kademede saniyelerce yanar", "saha pratiği", "ikincil"),
        S("Akım sınırlayan sigorta", "ilk yarım periyotta keser", "—", "Enerjiyi yüzde birler mertebesine indirir; yalnız akım yeterince büyükse sınırlar", "«Akım sınırlama» sayfası", "ikincil"),
        S("Bakım ayarı (geçici düşük ayar)", "çalışma sırasında ani kademe düşürülür", "—", "Panonun önünde insan varken süre kısaltılır", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Ark rölesi deneyi", "Işık algılayıcısına flaş + akım enjeksiyonu", "açma ≤ 10 ms", "yalnız ışıkla açmamalı (akım koşulu)"),
        T("Arktan sonra", "Bara ve kontaklarda erime, mahfazada delinme, her yüzeyde kurum", "kurum iletkendir: temizlenmeden enerjilenmez", "yalıtım direnci ölçülür"),
    ]
    ts = logsp(0.005, 2.0, 40)
    g1 = {"baslik": "Süreye göre ark enerjisi", "x_ad": "Süre (s)", "y_ad": "Enerji (MJ)", "logx": True, "logy": True,
          "seriler": [{"ad": f"{fnum(q, 0)} kA", "renk": rk, "kesik": abs(q - ik) > 0.01, "pts": pts(ts, [hesap(u, q, l, faz, x)["e"] for x in ts], 4)} for q, rk in ((ik, "#dc2626"), (ik / 2, "#b45309"), (ik * 2, "#7c3aed"))],
          "yatay": [{"y": 0.25, "etiket": "hasar sınırlı", "renk": "#15803d"}], "isaretler": [{"x": v[1], "etiket": v[0].split(" ")[0]} for v in KORUMA.values()]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1],
        "ses": [{"ad": "Ark", "not": "sürekli, sert bir gürültü: 100 Hz uğultu ve geniş bantlı kükreme", "sure": 1.5, "zarf": "sonen", "tau": 0.6, "taban": 0.3, "siddet": 1.0,
                 "parcalar": [{"f": 100, "a": 0.8}, {"f": 200, "a": 0.4}, {"f": 300, "a": 0.3}], "gurultu": 1.0, "gurultu_f": 900}],
        "anlatim": [
            "Ark, akımın iyonlaşmış gaz içinden geçmesidir. Gaz, akımı taşıyabilmek için çok sıcak kalmak zorundadır: sütunun ekseni 10 000–20 000 °C'dir. Bu sıcaklığı korumak için arkın üstünde bir gerilim düşer.",
            f"Bu gerilim küçüktür: {fnum(l, 0)} cm'lik arkta yaklaşık {fnum(h['ua'], 0)} V. Ama içinden {fnum(h['ia'], 1)} kA geçer: güç {fnum(h['p'], 1)} MW'tır. Bir kısa devrede en çok ısı, iletkenlerde değil arkın kendisinde açığa çıkar.",
            f"Enerji, gücün süreyle çarpımıdır: {fnum(t * 1000, 0)} ms'de {fnum(e, 2)} MJ. Güç şebekeye aittir, değiştirilemez; süre korumaya aittir. Ark korumasının bütün mantığı budur.",
            f"Enerjinin bir bölümü elektrotların ucuna gider: yaklaşık {fnum(kg_eri * 1000, 0)} g {m['ad'].lower()} erir ve damlalar halinde saçılır, {fnum(kg_buh * 1000, 0)} g buharlaşır. Buhar çok büyük hacim kaplar, soğuyunca çevredeki bütün yalıtkan yüzeylere iletken bir kurum olarak çöker.",
            "Geri kalan enerji ışınım ve sıcak gaz olarak yayılır: kapalı hacimde basınç yükselir (bkz. «Hücrede iç ark»), açık panoda karşısındaki insanı yakar (bkz. «Ark parlaması»).",
            ("AG'de bir incelik vardır: ark gerilimi (100–200 V) faz gerilimine yakındır ve akımı düşürür. Ark akımı kısa devre akımının yarısı kadar olabilir; koruma kısa devre akımına göre ayarlandıysa arkı «küçük bir aşırı yük» sanıp bekler."
             if u < 1 else "OG'de ark gerilimi faz geriliminin yüzde birkaçıdır: akımı sınırlamaz. Ark, kısa devre akımının neredeyse tamamını taşır."),
        ],
        "dersler": [
            "Ark gücü megavat mertebesindedir; enerjiyi belirleyen sürenin kendisidir.",
            "Arkın zararı üç yoldan gelir: ışınım (yanık), basınç (patlama), erimiş metal ve iletken kurum.",
            "AG'de ark akımı kısa devre akımından küçüktür: ani kademe ark akımını görecek biçimde ayarlanır.",
            "500 ms'lik bir ark, 70 ms'lik arkın yedi katı enerji demektir: hücrenin onarılabilmesi ile yenilenmesi arasındaki fark.",
        ],
        "tablolar": [{"baslik": "Korumaya göre ark enerjisi (bu akım ve ark boyu)", "cols": ["Koruma", "Süre", "Enerji", "TNT eşdeğeri", "Buharlaşan metal"],
                      "rows": [[v[0] + (" ◀" if k == kor else ""), f"{fnum(v[1] * 1000, 0)} ms", f"{fnum(hesap(u, ik, l, faz, v[1])['e'], 2)} MJ", f"{fnum(hesap(u, ik, l, faz, v[1])['e'] / 4.184, 2)} kg",
                                f"{fnum(0.02 * hesap(u, ik, l, faz, v[1])['e'] / F.metal_enerji(metal) * 1000, 0)} g"] for k, v in KORUMA.items()],
                      "not": "Akım sınırlayan sigortada akım da küçülür; buradaki değer yalnız sürenin etkisini gösterir (gerçekte daha da düşüktür)."}],
    }
