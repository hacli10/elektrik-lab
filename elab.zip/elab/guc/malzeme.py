"""Malzeme karşılaştırması: iletkenler (bakır, alüminyum, çelik) ve yalıtkanlar (hava, SF6, yağ, yağlı kâğıt, XLPE, PVC, epoksi, porselen, silikon) yan yana.
Aynı akım için kesit, ağırlık, kısa devre dayanımı; aynı gerilim için kalınlık, sıcaklık sınırı, iz dayanımı.

İletken sabitleri (özdirenç, yoğunluk, özgül ısı, erime) fizik çizelgelerinden (hesap). Yalıtkan değerleri (delinme dayanımı, işletme alanı, CTI) tipiktir (tahmini).
Sıcaklık sınırları: XLPE 90 / 250 °C ve PVC 70 / 160 °C TEDAŞ kablo şartnamelerinden, yalıtım sınıfları A 105 °C · F 155 °C · H 180 °C TEDAŞ trafo şartnamelerinden (resmi)."""
from __future__ import annotations

import math

from . import fizik as F
from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, num, opt

ID = "malzeme"
BASLIK = "Malzeme karşılaştırması"
IKON = "🧪"
GIRIS = ("Bakır mı alüminyum mu; epoksi mi porselen mi? Her malzemenin güçlü ve zayıf yanı aynı birkaç sayıdan çıkar: özdirenç, ısı sığası, erime sıcaklığı, dielektrik dayanım, "
         "izin verilen sıcaklık. İki malzeme seçin; aynı işi görmek için birinin ötekine göre ne kadar kesit, ağırlık ya da kalınlık istediğini görün.")
YAL = ("epoksi", "xlpe", "pvc", "kagit", "porselen", "silikon", "yag", "hava", "sf6")

KONTROLLER = [
    ctl("tur", "Karşılaştırma", "sec", "iletken", secenek=opt(("iletken", "İletkenler"), ("yalitkan", "Yalıtkanlar"))),
    ctl("a", "1. malzeme", "sec", "cu", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum"), ("fe", "Çelik")), goster={"tur": ["iletken"]}),
    ctl("b", "2. malzeme", "sec", "al", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum"), ("fe", "Çelik")), goster={"tur": ["iletken"]}),
    ctl("i", "Taşınacak akım", "sayi", 400, min=10, max=4000, adim=10, birim="A", goster={"tur": ["iletken"]}),
    ctl("ya", "1. yalıtkan", "sec", "epoksi", secenek=opt(*[(k, F.YALITKAN[k]["ad"]) for k in YAL]), goster={"tur": ["yalitkan"]}),
    ctl("yb", "2. yalıtkan", "sec", "porselen", secenek=opt(*[(k, F.YALITKAN[k]["ad"]) for k in YAL]), goster={"tur": ["yalitkan"]}),
    ctl("u", "Dayanılacak gerilim (faz–toprak)", "sayi", 20.8, min=0.2, max=100, adim=0.2, birim="kV", goster={"tur": ["yalitkan"]}),
]


def run(p: dict) -> dict:
    if p.get("tur", "iletken") == "iletken":
        a, b, i = str(p.get("a", "cu")), str(p.get("b", "al")), num(p, "i", 400)
        ma, mb = F.METAL[a], F.METAL[b]
        j_a = 2.0                                                       # A/mm² — karşılaştırma tabanı (1. malzeme)
        s_a = i / j_a
        s_b = s_a * mb["ro"] / ma["ro"]                                 # aynı direnç (aynı gerilim düşümü ve kayıp)
        kg_a, kg_b = s_a * 1e-6 * ma["yog"], s_b * 1e-6 * mb["yog"]     # kg/m
        ka, kb = F.k_katsayi(a, 90, 250), F.k_katsayi(b, 90, 250)
        c = Cizim(900, 280)
        ra, rb = math.sqrt(s_a / math.pi), math.sqrt(s_b / math.pi)
        olc = 60 / max(ra, rb)
        for x, m, r_, s_, kg in ((170, ma, ra, s_a, kg_a), (400, mb, rb, s_b, kg_b)):
            c.daire(x, 130, r_ * olc, "cizgi", "#fbbf24" if m["ad"] == "Bakır" else "#cbd5e1" if m["ad"] == "Alüminyum" else "#64748b", w=2)
            c.yazi(x, 40, m["ad"], "#334155", 13, kalin=True, anchor="middle")
            c.yazi(x, 220, f"{fnum(s_, 0)} mm² · {fnum(kg, 2)} kg/m", "#334155", 12, anchor="middle")
        c.yazi(285, 250, "aynı akım, aynı direnç (aynı kayıp ve gerilim düşümü) için kesitler", "#64748b", 10.5, anchor="middle")
        c.yazi(540, 56, f"{mb['ad']} kesiti = {fnum(s_b / s_a, 2)} × {ma['ad'].lower()}", "#1a4d8f", 14, kalin=True)
        c.yazi(540, 82, f"Ağırlığı = {fnum(kg_b / kg_a, 2)} ×", "#1a4d8f", 13, kalin=True)
        c.yazi(540, 110, f"Kısa devrede aynı süre için kesit = {fnum(ka / kb, 2)} ×", "#334155", 12.5)
        c.yazi(540, 134, f"Erime: {ma['erime']} °C / {mb['erime']} °C", "#334155", 12.5)
        c.yazi(540, 158, f"Isıl genleşme ve akma (sünme): alüminyumda bağlantı gevşer", "#64748b", 11)
        c.yazi(540, 176, "→ yaylı rondela, doğru tork, bimetal pabuç.", "#64748b", 11)
        ozet = [
            K("Kesit oranı", f"× {fnum(s_b / s_a, 2)}", "info", f"{mb['ad']} / {ma['ad']} — aynı direnç"),
            K("Ağırlık oranı", f"× {fnum(kg_b / kg_a, 2)}", "ok" if kg_b < kg_a else "warn", f"{fnum(kg_a, 2)} → {fnum(kg_b, 2)} kg/m"),
            K("Özdirenç", f"{fnum(ma['ro'] * 1000, 1)} / {fnum(mb['ro'] * 1000, 1)}", "info", "mΩ·mm²/m, 20 °C"),
            K("k (90 → 250 °C)", f"{fnum(ka, 0)} / {fnum(kb, 0)}", "info", "A·√s/mm²"),
            K("Erime", f"{ma['erime']} / {mb['erime']} °C", "info", "erime ısısı " + f"{ma['le']} / {mb['le']} kJ/kg"),
        ]
        kontroller = [
            C("Aynı direnç için kesit", f"{mb['ad']}: × {fnum(s_b / s_a, 2)}", "özdirençlerin oranı", None, "Direnç R = ρ·l / S: özdirenci yüksek malzeme aynı direnç için orantılı olarak kalın seçilir", "hesap"),
            C("Aynı direnç için ağırlık", f"{mb['ad']}: × {fnum(kg_b / kg_a, 2)}", "özdirenç × yoğunluk oranı", None, "Alüminyum bakırın 1,6 katı kesit ister ama yoğunluğu üçte biridir: aynı iş için yarı ağırlık", "hesap"),
            C("Kısa devre dayanımı", f"k = {fnum(ka, 0)} / {fnum(kb, 0)}", "S = I·√t / k", None, "k, ısı sığası ve özdirençten çıkar — bkz. «Kısa devrede ısı»", "hesap"),
            C("İletken sıcaklık sınırı (yalıtkana göre)", "XLPE 90 → 250 °C · PVC 70 → 160 °C", "şartname değerleri", None, "TEDAŞ-MLZ/96-018.B böl. 2.2.2.2 ve TEDAŞ-MLZ/96-015.A", "resmi"),
        ]
        satir = [[m["ad"], fnum(m["ro"] * 1000, 2), fnum(m["yog"], 0), fnum(m["c"], 0), f"{m['erime']}", f"{m['le']}", fnum(F.k_katsayi(k, 70, 160), 0), fnum(F.k_katsayi(k, 90, 250), 0), fnum(F.metal_enerji(k), 1)] for k, m in F.METAL.items()]
        tablo = {"baslik": "İletkenler", "cols": ["Metal", "Özdirenç (mΩ·mm²/m)", "Yoğunluk (kg/m³)", "Özgül ısı (J/kg·K)", "Erime (°C)", "Erime ısısı (kJ/kg)", "k (70→160)", "k (90→250)", "Buharlaştırma (MJ/kg)"], "rows": satir,
                 "not": "k değerleri bu sabitlerden hesaplanmıştır. Çelik için değerler alaşıma göre değişir."}
        anlatim = [
            f"{ma['ad']} ile {mb['ad'].lower()} aynı akımı aynı kayıpla taşısın: özdirençlerin oranı kadar kesit farkı gerekir. {mb['ad']} {fnum(s_b / s_a, 2)} kat kesit ister.",
            f"Ağırlıkta ise yoğunluk da girer: {mb['ad'].lower()} iletken {fnum(kg_b / kg_a, 2)} kat ağırlıktadır. Havai hatlarda ve büyük kesitli kablolarda alüminyumun tercih edilmesinin nedeni budur.",
            "Kısa devrede ısınmayı özdirenç ile hacimsel ısı sığası birlikte belirler. Alüminyumun birim hacimdeki ısı sığası bakırın üçte ikisi, direnci 1,6 katıdır: aynı kısa devre için bakırın yaklaşık 1,5 katı kesit ister.",
            "Alüminyumun asıl zorluğu bağlantıdadır: yüzeyi anında yalıtkan bir oksitle kaplanır, basınç altında yavaşça akar (sünme) ve bakırla temasında nemli ortamda paslanır. Çaresi: uygun pabuç (bimetal), temas macunu, doğru tork ve yaylı rondela.",
            "Çelik iletken değil taşıyıcıdır: özdirenci bakırın sekiz katıdır. Topraklama şeridi ve hat teli göbeği olarak, mekanik dayanımı ve fiyatı için kullanılır.",
        ]
        dersler = ["Aynı direnç için alüminyum bakırın 1,6 katı kesit, yarısı ağırlık ister.", "Kısa devrede alüminyum bakırın ≈ 1,5 katı kesit ister (k: 143'e karşı 94).",
                   "Alüminyumda arıza iletkende değil bağlantıda çıkar.", "Bakır–alüminyum doğrudan birleştirilmez: bimetal pabuç kullanılır."]
        girdiler = [G("Taşınacak akım", f"{fnum(i, 0)} A", "Yük hesabı", "Kesitin tabanı", f"S = I / J (J ≈ {fnum(j_a, 0)} A/mm² alındı)"), G("Malzeme sabitleri", f"ρ = {fnum(ma['ro'] * 1000, 1)} / {fnum(mb['ro'] * 1000, 1)} mΩ·mm²/m", "Fizik çizelgeleri, kablo kataloğu", "Kesit ve ağırlık oranını belirler", "R = ρ·l / S")]
        adimlar = [A("Kesit oranı", "S(b) / S(a) = ρ(b) / ρ(a)", f"{fnum(mb['ro'] * 1000, 2)} / {fnum(ma['ro'] * 1000, 2)}", f"× {fnum(s_b / s_a, 2)}", "aynı direnç", "hesap", ["Malzeme sabitleri"]),
                   A("Ağırlık oranı", "kesit oranı × yoğunluk oranı", f"{fnum(s_b / s_a, 2)} × {fnum(mb['yog'] / ma['yog'], 2)}", f"× {fnum(kg_b / kg_a, 2)}", "kütle = hacim × yoğunluk", "hesap"),
                   A("Kısa devre için kesit oranı", "S(b) / S(a) = k(a) / k(b)", f"{fnum(ka, 0)} / {fnum(kb, 0)}", f"× {fnum(ka / kb, 2)}", "aynı akım ve süre", "hesap")]
        return {"ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "sahne": c.sahne(), "tablolar": [tablo], "anlatim": anlatim, "dersler": dersler,
                "test": [T("Bağlantı direnci", "Mikroohmmetre: ek ve pabuçlarda", "iletkenin aynı uzunluğunun direncinden büyük olmamalı", "alüminyum bağlantılar ilk yıl içinde yeniden sıkılır"), T("Termal kamera", "Yük altında bağlantılar", "fazlar arası fark < 5–10 K", "ısınan bağlantı gevşemiştir")],
                "ayarlar": [S("Pabuç ve ek", "alüminyum için bimetal / alüminyuma uygun", "—", "Bakır pabuç alüminyum iletkene sıkılmaz", "saha pratiği", "ikincil"), S("Tork", "üretici değeri; alüminyumda yeniden sıkma", "—", "Sünme temas basıncını düşürür", "saha pratiği", "ikincil")]}

    ya, yb, u = str(p.get("ya", "epoksi")), str(p.get("yb", "porselen")), num(p, "u", 20.8)
    a, b = F.YALITKAN[ya], F.YALITKAN[yb]
    da, db = u / a["ei"], u / b["ei"]
    c = Cizim(900, 280)
    olc = 120 / max(da, db)
    for x, m, d_ in ((150, a, da), (380, b, db)):
        c.dikdortgen(x - 50, 70, 100, 12, "cizgi", "#94a3b8"); c.dikdortgen(x - 50, 82, 100, d_ * olc, "cizgi", "#fde68a", kw=1.2, r=0); c.dikdortgen(x - 50, 82 + d_ * olc, 100, 12, "cizgi", "#94a3b8")
        c.yazi(x, 50, m["ad"], "#334155", 12, kalin=True, anchor="middle"); c.yazi(x, 82 + d_ * olc + 34, f"{fnum(d_, 1)} mm", "#1d4ed8", 12.5, kalin=True, anchor="middle")
    c.yazi(265, 262, f"{fnum(u, 1)} kV'u işletme alanında taşıyan kalınlıklar", "#64748b", 10.5, anchor="middle")
    c.yazi(540, 56, f"Kalınlık oranı × {fnum(db / da, 2)}", "#1a4d8f", 14, kalin=True)
    c.yazi(540, 82, f"Dielektrik sabiti {fnum(a['er'], 1)} / {fnum(b['er'], 1)}", "#334155", 12.5)
    c.yazi(540, 106, f"Kısa süreli dayanım {fnum(a['ed'], 0)} / {fnum(b['ed'], 0)} kV/mm", "#334155", 12.5)
    c.yazi(540, 130, "Sürekli sıcaklık " + " / ".join(f"{m['tmax']} °C" if m["tmax"] else "—" for m in (a, b)), "#334155", 12.5)
    c.yazi(540, 154, "İz dayanımı (CTI) " + " / ".join(f"{m['cti']} V" if m["cti"] else "—" for m in (a, b)), "#334155", 12.5)
    c.yazi(540, 184, "Katı yalıtkan delinirse kalıcıdır; gaz ve sıvı kendini onarır.", "#64748b", 11)
    ozet = [K("Kalınlık oranı", f"× {fnum(db / da, 2)}", "info", f"{fnum(da, 1)} → {fnum(db, 1)} mm"), K("İşletme alanı", f"{fnum(a['ei'], 1)} / {fnum(b['ei'], 1)} kV/mm", "info", "OG tasarımında tipik"),
            K("Kısa süreli dayanım", f"{fnum(a['ed'], 0)} / {fnum(b['ed'], 0)} kV/mm", "info", "ince örnek"), K("Sürekli sıcaklık", " / ".join(f"{m['tmax']}" if m["tmax"] else "—" for m in (a, b)) + " °C", "info", "yalıtkanın sınırı"),
            K("İz dayanımı", " / ".join(f"{m['cti']}" if m["cti"] else "—" for m in (a, b)) + " V", "info", "CTI")]
    kontroller = [
        C("Sıcaklık sınırları", "XLPE 90 °C · PVC 70 °C · epoksi F sınıfı 155 °C · yağlı kâğıt A sınıfı 105 °C", "şartname değerleri", None, "TEDAŞ-MLZ/96-018.B, 96-015.A, 99-031.B böl. 2.2.9 ve 99-032.E böl. 2.3.3", "resmi"),
        C("Bina içi mesnet izolatörü malzemesi", "organik malzeme olarak yalnız epoksi reçine", "şartname koşulu", None, "TEDAŞ-MLZ/96-020 böl. 2.3.1", "resmi"),
        C("Delinme dayanımı ve işletme alanı", f"{a['ad']}: {fnum(a['ed'], 0)} / {fnum(a['ei'], 1)} kV/mm · {b['ad']}: {fnum(b['ed'], 0)} / {fnum(b['ei'], 1)} kV/mm", "tipik değerler", None, "Örnek kalınlığına, süreye ve saflığa bağlıdır; mertebe gösterir", "tahmini"),
    ]
    satir = [[v["ad"], fnum(v["er"], 1), fnum(v["ed"], 0), fnum(v["ei"], 1), f"{v['tmax']}" if v["tmax"] else "—", f"{v['cti']}" if v["cti"] else "—",
              {"hava": "kendini onarır; rakım ve nemle zayıflar", "sf6": "havanın ≈ 3 katı; kapalı sistem, kaçak izlenir", "yag": "hem yalıtır hem soğutur; nem ve yaşlanma", "kagit": "yağla birlikte; nem düşmanı",
               "xlpe": "kablo yalıtkanı; boşluksuz üretim şart", "pvc": "ucuz, yanmayı geciktirir; kayıpları yüksek", "epoksi": "her biçime dökülür; iz oluşumuna duyarlı", "porselen": "iz oluşmaz; kırılgan, ağır",
               "silikon": "su tutmaz, hafif; mekanik zayıf"}[k]] for k, v in F.YALITKAN.items()]
    return {"ozet": ozet, "kontroller": kontroller, "sahne": c.sahne(),
            "girdiler": [G("Gerilim", f"{fnum(u, 1)} kV faz–toprak", "Sistem gerilimi / √3", "Kalınlığın tabanı", "d = U / E(işletme)"), G("Ortam", "bina içi / dışı, kirlilik, sıcaklık", "Tesisin yeri", "Malzeme seçimini yüzey ve sıcaklık koşulu belirler", "bkz. «Yüzeysel atlama»")],
            "adimlar": [A("Gereken kalınlık", "d = U / E(işletme)", f"{fnum(u, 1)} / {fnum(a['ei'], 1)} ve {fnum(u, 1)} / {fnum(b['ei'], 1)}", f"{fnum(da, 1)} mm ve {fnum(db, 1)} mm", "düzgün alan kabulüyle; gerçekte alan dağılımı belirler", "tahmini", ["Gerilim"])],
            "ayarlar": [S("Kısmi boşalma sınırı (dökme reçine)", "≤ 10 pC", "—", "Boşluksuz döküm ölçütü", "TEDAŞ-MLZ/99-031.B böl. 2.2.15")],
            "test": [T("Yalıtım direnci / tan δ / kısmi boşalma", "Malzemeye uygun deney", "önceki değerlerle uyumlu", "Topraklama laboratuvarı › Deneyler")],
            "tablolar": [{"baslik": "Yalıtkanlar (tipik değerler)", "cols": ["Yalıtkan", "εr", "Kısa süreli dayanım (kV/mm)", "İşletme alanı (kV/mm)", "Sürekli sıcaklık (°C)", "CTI (V)", "Özelliği"], "rows": satir,
                          "not": "Sıcaklıklar: XLPE ve PVC TEDAŞ kablo şartnamelerinden, epoksi F sınıfı, yağlı kâğıt A sınıfı. Öbür değerler mertebe gösterir."}],
            "anlatim": [
                f"{a['ad']} ve {b['ad'].lower()}: aynı gerilimi ({fnum(u, 1)} kV) işletme alan şiddetinde taşımak için sırasıyla {fnum(da, 1)} mm ve {fnum(db, 1)} mm kalınlık gerekir.",
                "Kısa süreli delinme dayanımı ile işletme alanı arasında on kat fark vardır: yalıtkan otuz yıl dayanacaksa, deneyde dayandığı alanın küçük bir kesriyle çalıştırılır.",
                "Gazlar ve sıvılar delindikten sonra kendini onarır: ark söner, yalıtkanlık geri gelir. Katılar onarmaz: delik kalıcıdır. Bu yüzden hava yalıtımlı hatta tekrar kapama yapılır, kabloda yapılmaz.",
                "Dielektrik sabiti yüksek malzeme, yanındaki havaya daha çok alan iter: porselen ve epoksinin içindeki ya da yüzeyindeki hava boşlukları kısmi boşalmanın başladığı yerdir.",
                "Yüzey davranışı ayrı bir ölçüttür: porselen ve cam arktan etkilenmez; epoksi ve PVC'de ark karbon izi bırakır; silikon suyu tabaka halinde tutmaz. Bina dışında ve kirli ortamda seçimi çoğu zaman yüzey belirler.",
            ],
            "dersler": ["Hava ≈ 3 kV/mm, katı yalıtkanlar 15–50 kV/mm kısa süreli dayanır; işletme alanı bunun onda biridir.", "Gaz ve sıvı kendini onarır, katı onarmaz.",
                        "Malzemeyi çoğu zaman gerilim değil sıcaklık ve yüzey koşulu seçtirir.", "Her yalıtkanın bir düşmanı vardır: havanın rakım ve nem, yağın nem, katının hava boşluğu, organiklerin yüzey arkı."]}
