"""Motorlar — ortak modeller (birim değerlerle; taban: motorun anma gerilimi ve anma akımı).

1) Üç fazlı asenkron motor: bir faz eşdeğer devresi (R1, X1, Xm, R2′, X2′). Rotor direnci kaymayla artar (derin oluk etkisi): R2(s) = R2·(1 + 1,2·s).
   Pozitif bileşen kayması s, negatif bileşen kayması 2 − s. Moment, hava aralığı gücünden: M = 3·I2²·R2/s (senkron watt).
2) Tek fazlı (iki sargılı, kondansatörlü) motor: çift döner alan kuramı, simetrik olmayan iki faz. Ana sargı m, yardımcı sargı a (sarım oranı a = Na/Nm),
   yardımcı sargıya seri kondansatör. İleri ve geri alan empedansları Zf(s), Zb(s) = Zf(2 − s):
       Vm = Im·Z1m + Zf·If + Zb·Ib            If = (Im − j·a·Ia) / 2
       Va = Ia·(Z1a + Zc) + j·a·(Zf·If − Zb·Ib)   Ib = (Im + j·a·Ia) / 2
   Moment ∝ 2·(|If|²·Re Zf − |Ib|²·Re Zb).
Parametreler ders kitabı örnekleri mertebesinde tipik değerlerdir (tahmini); olgunun kendisi temel bağıntıdır."""
from __future__ import annotations

import cmath
import math

from .ortak import A120, S3, coz

# üç fazlı, 4 kutuplu, sincap kafesli motor (orta güç) — birim değerler
UC = {"r1": 0.03, "x1": 0.055, "xm": 3.0, "r2": 0.025, "x2": 0.065}
# tek fazlı kondansatörlü motor (kesirli güç) — ana sargı tabanında birim değerler
TEK = {"r1m": 0.065, "x1m": 0.09, "r2": 0.133, "x2": 0.068, "xm": 2.15, "r1a": 0.23, "x1a": 0.104, "a": 1.18}


def r2s(par: dict, s: float) -> float:
    return par["r2"] * (1 + 1.2 * min(abs(s), 2.0))


def zs(par: dict, s: float, f: float = 1.0) -> complex:
    """Motorun bir fazının kaymaya göre giriş empedansı (pu). f: frekans / anma frekansı (reaktanslar f ile ölçeklenir)."""
    s = s if abs(s) > 1e-6 else 1e-6
    zr = complex(r2s(par, s) / s, par["x2"] * f)
    zm = complex(0, par["xm"] * f)
    return complex(par["r1"], par["x1"] * f) + zm * zr / (zm + zr)


def rotor_akim(par: dict, s: float, v: complex, f: float = 1.0) -> tuple:
    """(stator akımı, rotor akımı) — v: faz gerilimi (pu)."""
    s = s if abs(s) > 1e-6 else 1e-6
    i1 = v / zs(par, s, f)
    zr = complex(r2s(par, s) / s, par["x2"] * f); zm = complex(0, par["xm"] * f)
    return i1, i1 * zm / (zm + zr)


def moment(par: dict, s: float, v1: complex = 1.0, v2: complex = 0.0, f: float = 1.0) -> dict:
    """Pozitif ve negatif bileşen gerilimleriyle moment (pu, anma momenti ≈ anma kaymasındaki değer), akımlar ve rotor kaybı."""
    i1, ir1 = rotor_akim(par, s, v1, f)
    i2, ir2 = rotor_akim(par, 2 - s, v2, f) if abs(v2) > 1e-9 else (0j, 0j)
    sp = s if abs(s) > 1e-6 else 1e-6
    m1 = abs(ir1) ** 2 * r2s(par, sp) / sp / f
    m2 = abs(ir2) ** 2 * r2s(par, 2 - s) / (2 - s) / f
    p_rotor = abs(ir1) ** 2 * r2s(par, sp) + abs(ir2) ** 2 * r2s(par, 2 - s)
    return {"m": m1 - m2, "m1": m1, "m2": m2, "i1": i1, "i2": i2, "p_rotor": p_rotor, "p_stator": (abs(i1) ** 2 + abs(i2) ** 2) * par["r1"]}


SN = 0.03                                    # anma kayması


def anma(par: dict = UC) -> dict:
    """Anma noktası: kayma 0,03'te moment ve akım (ölçekleme için)."""
    m = moment(par, SN)
    return {"m": m["m"], "i": abs(m["i1"]), "cos": math.cos(cmath.phase(m["i1"])) if abs(m["i1"]) else 0.0}


def calisma(par: dict, yuk: float, v1: complex = 1.0, v2: complex = 0.0, f: float = 1.0, fan: bool = False) -> dict:
    """Yük momentine karşılık gelen kayma (ikiye bölme). yuk: anma momentinin katı; fan: yük momenti hızın karesiyle değişir.
    Devrilme momenti yükten küçükse motor devrilir: {"devrildi": True} ve kilitli rotor değerleri döner."""
    mn = anma(UC)["m"]                           # anma momenti motorun kendi (değiştirilmemiş) parametreleriyle tanımlıdır
    def fark(s):
        n = (1 - s) * f
        return moment(par, s, v1, v2, f)["m"] / mn - yuk * (n * n if fan else 1.0)
    # devrilme kaymasına kadar tara
    ss = [0.0005 * 1.12 ** k for k in range(70) if 0.0005 * 1.12 ** k < 1.0]
    tepe = max(ss, key=lambda s: moment(par, s, v1, v2, f)["m"])
    if fark(tepe) < 0:
        m = moment(par, 1.0, v1, v2, f)
        return {"s": 1.0, "devrildi": True, **m}
    lo, hi = 1e-5, tepe
    for _ in range(50):
        mid = (lo + hi) / 2
        if fark(mid) > 0:
            hi = mid
        else:
            lo = mid
    s = (lo + hi) / 2
    return {"s": s, "devrildi": False, **moment(par, s, v1, v2, f)}


def faz_akimlari(i1: complex, i2: complex) -> list:
    a = A120
    return [i1 + i2, a * a * i1 + a * i2, a * i1 + a * a * i2]


# ---------------- tek fazlı motor ----------------
def tek_zf(par: dict, s: float) -> complex:
    s = s if abs(s) > 1e-6 else 1e-6
    zr = complex(par["r2"] / s, par["x2"]); zm = complex(0, par["xm"])
    return zm * zr / (zm + zr)


def tek_coz(par: dict, s: float, zc: complex | None, v: complex = 1.0, yardimci: bool = True) -> dict:
    """Tek fazlı motorun bir kaymadaki çözümü. zc: yardımcı sargıya seri empedans (kondansatör: −j·Xc; None: doğrudan bağlı).
    yardimci=False: yardımcı sargı açık (merkezkaç anahtar açmış ya da kondansatör açık devre)."""
    a = par["a"]
    zf, zb = tek_zf(par, s), tek_zf(par, 2 - s)
    z1m = complex(par["r1m"], par["x1m"])
    if not yardimci:
        im = v / (z1m + (zf + zb) / 2); ia = 0j
    else:
        z1a = complex(par["r1a"], par["x1a"]) + (zc or 0j)
        # Vm = Im·(Z1m + (Zf+Zb)/2) + Ia·(−j·a·(Zf − Zb)/2)
        # Va = Im·( j·a·(Zf − Zb)/2) + Ia·(Z1a + a²·(Zf+Zb)/2)
        m = [[z1m + (zf + zb) / 2, -1j * a * (zf - zb) / 2], [1j * a * (zf - zb) / 2, z1a + a * a * (zf + zb) / 2]]
        im, ia = coz(m, [v, v])
    i_f = (im - 1j * a * ia) / 2; i_b = (im + 1j * a * ia) / 2
    mf = 2 * abs(i_f) ** 2 * zf.real; mb = 2 * abs(i_b) ** 2 * zb.real
    uc = abs(ia * zc) if (zc is not None and yardimci) else 0.0
    return {"im": im, "ia": ia, "if": i_f, "ib": i_b, "m": mf - mb, "mf": mf, "mb": mb, "uc": uc, "ihat": im + ia,
            "p_cu": abs(im) ** 2 * par["r1m"] + abs(ia) ** 2 * par["r1a"]}


def tek_anma(par: dict = TEK) -> dict:
    """Karşılaştırma tabanı: daimi kondansatörlü, anma kaymasında (0,05) moment ve hat akımı."""
    r = tek_coz(par, 0.05, complex(0, -XC_DAIMI))
    return {"m": r["m"], "i": abs(r["ihat"]), "im": abs(r["im"]), "ia": abs(r["ia"])}


XC_DAIMI = 3.2          # daimi (çalışma) kondansatörünün reaktansı (pu) — anma kaymasında alanı daireye yaklaştıran değer
XC_KALKIS = 0.75        # kalkış kondansatörünün reaktansı (pu) — kalkışta yardımcı akımı ana akımın ≈ 90° önüne alan değer


def uf(xc_pu: float, u: float, i_n: float, f: float = 50.0) -> float:
    """Birim değerli kondansatör reaktansından kapasite (µF). Taban empedans = u / i_n."""
    return 1e6 / (2 * math.pi * f * xc_pu * u / i_n) if xc_pu > 0 else 0.0
