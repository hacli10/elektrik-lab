"""Dağıtım trafosunun YG tarafında faz kopması (tek hat ve iki hat): AG gerilimleri, YG ve AG akımları, sargı yüklenmesi, trafonun ve motorların ısınması,
bu durumda ne kadar çalışılabileceği ve hangi korumanın gördüğü.

Model: trafo_model.hesapla — şebeke, açık iletkenler, bağlantı grubuna göre sargılar, üç bacaklı / beş bacaklı çekirdek, AG yükü (sabit empedanslı alıcılar +
sabit güçlü motorlar). Doğrusal modeldir: açık fazdaki kablonun kapasitesiyle çekirdek arasında oluşabilecek ferrorezonans hesaplanmaz (Topraklama laboratuvarı ›
Rezonans ve ferrorezonans sayfası). Dyn trafoda YG'de bir faz açıkken AG'de bir faz tam, iki faz yarım gerilimde ve tam fazın tersinde kalır: SEL teknik makalesi.
Motorun negatif bileşen empedansı kilitli rotor empedansına eşit alınır (≈ 1/6 pu, tipik); termik rölenin süresi sınıf 10 için yaklaşık bağıntıdır (tahmini)."""
from __future__ import annotations

import math

from . import trafo_model as M
from .ortak import A, C, G, K, RENK3, S, S3, SEL_AF, T, TEMEL, Cizim, ctl, fa, fazor, fnum, num, opt, pts, tr_al, tr_ctl, tr_girdi
from .trafo_isil import sure_yaz

ID = "trafo_faz"
BASLIK = "OG'de faz kopması"
IKON = "✂"
GIRIS = ("Trafonun OG tarafında bir sigorta attı, bir jumper koptu ya da bir ayırıcı bıçağı kapanmadı: trafo iki fazla, hatta tek fazla kaldı. AG'de hangi fazda kaç volt olur, "
         "akımlar nereye çıkar, motorlar ve trafo ne kadar dayanır, hangi koruma bunu görür? Kopan fazı, bağlantı grubunu ve yükün türünü değiştirip izleyin.")

KOPUK = {"yok": (False, False, False), "L1": (True, False, False), "L2": (False, True, False), "L3": (False, False, True),
         "L1L2": (True, True, False), "L2L3": (False, True, True), "L1L3": (True, False, True)}
KONTROLLER = tr_ctl() + [
    ctl("grup", "Bağlantı grubu", "sec", "Dyn11", secenek=opt(*[(g, g) for g in M.GRUPLAR]), yardim="Dağıtım trafolarında ≥ 160 kVA Dyn11, ≤ 100 kVA Yzn11; Yyn0 eski trafolarda görülür"),
    ctl("kopuk", "YG'de açık iletken", "sec", "L1", secenek=opt(("yok", "Yok — olağan çalışma"), ("L1", "L1 açık (tek hat kopuk)"), ("L2", "L2 açık"), ("L3", "L3 açık"),
                                                                 ("L1L2", "L1 ve L2 açık (iki hat kopuk)"), ("L2L3", "L2 ve L3 açık"), ("L1L3", "L1 ve L3 açık"))),
    ctl("yuk", "Yük (kopmadan önce)", "sayi", 60, min=0, max=120, adim=5, birim="%"),
    ctl("cos", "Motor dışı yükün güç katsayısı", "sayi", 0.92, min=0.5, max=1.0, adim=0.01),
    ctl("motor", "Yükün içinde motorların payı", "sayi", 50, min=0, max=100, adim=5, birim="%", yardim="Motorlar eksik fazın gerilimini kısmen yeniden üretir ama bunun bedeli olarak çok akım çeker"),
    ctl("cekirdek", "Çekirdek", "sec", "3", secenek=opt(("3", "Üç bacaklı (dağıtım trafosu)"), ("5", "Beş bacaklı / kabuk tipi"))),
    ctl("ta", "Ortam sıcaklığı", "sayi", 30, min=-25, max=50, adim=1, birim="°C"),
]


def termik(m: float) -> float | None:
    """Sınıf 10 termik rölenin yaklaşık açma süresi (s); m = akım / ayar. 1,15'in altında açmaz."""
    if m <= 1.15:
        return None
    return 300.0 * math.log(m * m / (m * m - 1.15 ** 2))


def durum_ad(u: float) -> tuple:
    if u < 0.5:
        return "bad", "çalışmaz: kontaktör düşer, lamba yanmaz"
    if u < 0.85:
        return "bad", "düşük gerilim: kontaktörler titrer, motorlar zorlanır"
    if u <= 1.1:
        return "ok", "olağan"
    return "bad", "aşırı gerilim"


def run(p: dict) -> dict:
    tr = tr_al(p)
    tip = "kuru" if tr["tip"] == "kuru" else "yag"
    grup, kop = str(p.get("grup", "Dyn11")), str(p.get("kopuk", "L1"))
    acik = KOPUK.get(kop, KOPUK["L1"]); nacik = sum(acik)
    s, cosf, mot, ta = num(p, "yuk", 60) / 100, num(p, "cos", 0.92), num(p, "motor", 50) / 100, num(p, "ta", 30)
    cek = str(p.get("cekirdek", "3"))
    zk = complex(tr["ur"], tr["ux"]) / 100
    zs = complex(0.1, 1.0) * (tr["sn"] / 1000 / 350)                       # şebeke 350 MVA (tipik OG barası)
    yuk = {"s": s, "cos": cosf, "motor": mot}
    n0 = M.hesapla(grup, zk, zs, (False, False, False), yuk, cekirdek=cek)
    r = M.hesapla(grup, zk, zs, acik, yuk, cekirdek=cek)
    ua = [abs(x) for x in r["ua"]]
    ull = [abs(r["ua"][i] - r["ua"][(i + 1) % 3]) / S3 for i in range(3)]
    v0, v1, v2 = M.dizi(r["ua"])
    vuf = abs(v2) / abs(v1) * 100 if abs(v1) > 1e-3 else 0.0
    iy = [abs(x) for x in r["iy"]]; ia = [abs(x) for x in r["ia"]]
    ks = r["k_sargi"]; ks_max = max(ks)
    k_eq = math.sqrt(r["kayip"]); k0 = math.sqrt(n0["kayip"])
    # motorlar
    im1 = abs(r["y1m"] * v1); im2 = abs(r["y2m"] * v2); im_n = s * mot * 1.0
    m1 = im1 / im_n if im_n > 0 else 0.0; m2 = im2 / im_n if im_n > 0 else 0.0
    m_faz = min(m1 + m2, 7.5)                                                  # en çok yüklenen motor fazı (≈ I1 + I2)
    t_termik = termik(m_faz) if im_n > 0 else None
    # trafonun ısınması: kopmadan önceki sürekli rejimden başlayarak 12 saat
    rr = tr["pk"] / tr["p0"]
    oran = ks_max / k_eq if k_eq > 1e-6 else 1.0
    from .trafo_isil import _bas
    b = M.benzet(tip, lambda t: k_eq, ta, rr, 720, 2.0, bas=_bas(tip, k0, ta, rr), k_sn_oran=oran)
    sur = M.surekli(tip, k_eq, ta, rr, ks_max)
    sn_sinir = 155.0 if tip == "kuru" else 120.0
    acma_e = M.KURU_ACMA if tip == "kuru" else M.YAG_ACMA
    t_sn = M.ilk_gecis(b["t"], b["sn"], sn_sinir); t_ac = M.ilk_gecis(b["t"], b["pt"], acma_e)
    sag = [i for i in range(3) if ua[i] >= 0.85]
    olu = nacik >= 2 and max(ua) < 0.05

    # ---- şema ----
    c = Cizim(900, 360)
    c.kutu(14, 60, 96, 76, "OG şebeke", f"{fnum(tr['un'], 1)} kV")
    ys = (68, 98, 128)
    for j in range(3):
        y = ys[j]; hot = iy[j] > 0.02
        c.hat(f"M110,{y} H180", f"L{j + 1}", hot=hot, w=3)
        if acik[j]:
            c.hat(f"M180,{y} l26,-16", f"L{j + 1}", w=3); c.yazi(193, y - 20, "AÇIK", "#b91c1c", 10, kalin=True, anchor="middle")
            c.hat(f"M214,{y} H330", f"L{j + 1}", kesik=True, w=2)
        else:
            c.dikdortgen(180, y - 6, 34, 12, "cizgi", "#fff"); c.hat(f"M214,{y} H330", f"L{j + 1}", hot=hot, w=3)
        c.yazi(272, y - 7, fa(iy[j] * tr["i1"], 1) if not acik[j] else "0 A", "#b91c1c" if iy[j] > 1.05 else "#334155", 10.5, anchor="middle")
    c.yazi(197, 152, "sigorta / ayırıcı", "#64748b", 9.5, anchor="middle")
    c.daire(356, 98, 34, "cizgi"); c.daire(404, 98, 34, "cizgi")
    c.sarim(352, 98, "ucgen" if grup[0] == "D" else "yildiz", r=16); c.sarim(408, 100, "yildiz", r=16)
    c.yazi(380, 50, f"{grup} · {fnum(tr['sn'], 0)} kVA", "#475569", 10.5, anchor="middle")
    for j in range(3):
        y = ys[j]; d, ack = durum_ad(ua[j])
        c.hat(f"M438,{y} H560", f"L{j + 1}", hot=ia[j] > 0.02, w=3)
        c.yazi(568, y + 4, f"L{j + 1}–N {fnum(ua[j] * 231, 0)} V (%{fnum(ua[j] * 100, 0)})", "#15803d" if d == "ok" else "#b91c1c", 12, kalin=True)
        c.yazi(730, y + 4, f"{fnum(ia[j] * tr['i2'], 0)} A", "#b91c1c" if ia[j] > 1.05 else "#334155", 11.5)
    c.hat("M404,132 V160 H560", "N", w=2); c.yazi(568, 164, f"N — nötr akımı {fnum(abs(r['inotr']) * tr['i2'], 0)} A", "#1d4ed8", 11)
    c.toprak(404, 162)
    c.yazi(790, 50, "AG akımı", "#64748b", 10, anchor="middle"); c.yazi(640, 50, "AG faz–nötr gerilimi", "#64748b", 10, anchor="middle")
    y = 200
    if nacik == 0:
        c.yazi(20, y, "Olağan çalışma: üç faz dengeli.", "#15803d", 13, kalin=True)
    elif olu:
        c.yazi(20, y, "İki hat açık: trafo tek uçtan besleniyor, akım için kapalı yol yok — AG'de gerilim yok.", "#b91c1c", 13, kalin=True)
    else:
        c.yazi(20, y, f"{'Tek' if nacik == 1 else 'İki'} hat açık: AG'de {len(sag)} faz olağan, {3 - len(sag)} faz düşük. Dengesizlik (V2/V1) %{fnum(vuf, 0)}.", "#b91c1c", 13, kalin=True)
    c.yazi(20, y + 24, f"Sargı yüklenmesi: bacak 1 %{fnum(ks[0] * 100, 0)} · bacak 2 %{fnum(ks[1] * 100, 0)} · bacak 3 %{fnum(ks[2] * 100, 0)}", "#b91c1c" if ks_max > 1.0 else "#334155", 12, kalin=ks_max > 1.0)
    c.yazi(20, y + 46, f"Trafo sürekli böyle kalırsa: sıcak nokta {fnum(sur['sn'], 0)} °C" + (f" · üst yağ {fnum(sur['yag'], 0)} °C" if tip == "yag" else ""), "#b91c1c" if sur["sn"] > sn_sinir else "#334155", 12)
    if im_n > 0 and nacik:
        c.yazi(20, y + 68, ("Motorlar devrildi (kilitli rotor): " if r["devrildi"] else "Motorlar dönüyor: ") + f"en yüklü fazda {fnum(m_faz, 1)} × In — termik röle " + ("açmaz" if t_termik is None else (f"{fnum(t_termik, 0)} s" if t_termik < 90 else sure_yaz(t_termik / 60)) + " içinde açar"),
               "#b91c1c" if m_faz > 1.15 else "#334155", 12, kalin=m_faz > 1.15)
    c.yazi(20, y + 90, "OG sigortası: kalan fazlarda " + f"{fnum(max(iy), 2)} × In — " + ("erimez; arıza OG korumasına görünmez" if max(iy) < 1.6 else "aşırı yüklenir"), "#334155", 12)
    c.yazi(20, y + 112, "Bunu gören: AG gerilim denetim rölesi (faz kaybı / dengesizlik), motor koruma rölesi (46), GES eviricisi (27).", "#1a4d8f", 11.5)
    c.yazi(20, y + 138, "Açık fazdaki kablo ve trafo boşta ise ferrorezonans oluşabilir: bu model onu hesaplamaz.", "#64748b", 10.5)
    fz1 = {"baslik": "AG faz–nötr gerilimleri", "vektorler": [fazor(f"L{j + 1}", r["ua"][j], RENK3[j]) for j in range(3)] + [fazor(f"n{j + 1}", n0["ua"][j], "#cbd5e1", True) for j in range(3)], "not": "kesik: kopmadan önce"}
    fz2 = {"baslik": "YG hat akımları", "vektorler": [fazor(f"L{j + 1}", r["iy"][j], RENK3[j]) for j in range(3)] + [fazor(f"n{j + 1}", n0["iy"][j], "#cbd5e1", True) for j in range(3)], "not": "kesik: kopmadan önce"}

    ozet = [
        K("AG faz–nötr gerilimleri", " / ".join(fnum(u * 231, 0) for u in ua) + " V", "ok" if min(ua) >= 0.9 else "bad", "L1 / L2 / L3"),
        K("Gerilim dengesizliği", f"%{fnum(vuf, 0)}", "ok" if vuf <= 2 else "bad", "negatif / pozitif bileşen (V2/V1)"),
        K("En yüklü sargı", f"%{fnum(ks_max * 100, 0)}", "bad" if ks_max > 1.0 else "ok", f"kopmadan önce %{fnum(max(n0['k_sargi']) * 100, 0)}"),
        K("Motor akımı", f"{fnum(m_faz, 1)} × In" if im_n > 0 else "motor yok", "bad" if m_faz > 1.15 else "ok" if im_n > 0 else "info", ("devrildi · " if r["devrildi"] else "") + (f"I2/I1 = %{fnum(m2 / m1 * 100, 0)}" if m1 > 0 else "")),
        K("Trafo bu durumda", "sürekli çalışabilir" if t_sn is None and t_ac is None else sure_yaz(min(x for x in (t_sn, t_ac) if x is not None)), "ok" if t_sn is None and t_ac is None else "bad",
          "sıcaklık sınırına varmıyor" if t_sn is None and t_ac is None else "sıcaklık sınırına kadar"),
    ]
    kontroller = [
        C("AG gerilimleri kullanılabilir mi?", " / ".join(f"%{fnum(u * 100, 0)}" for u in ua), "her fazda %90 … %110", min(ua) >= 0.9 and max(ua) <= 1.1,
          "Tek fazlı alıcılar bağlı oldukları fazın gerilimini görür; düşük fazdaki alıcılar çalışmaz ya da zarar görür", "hesap"),
        C("Gerilim dengesizliği motorlar için kabul edilebilir mi?", f"V2/V1 = %{fnum(vuf, 1)}", "≤ %2", vuf <= 2.0,
          "Motorun negatif bileşen empedansı kilitli rotor empedansı kadardır: %1 gerilim dengesizliği yaklaşık %6 akım dengesizliği yapar", "ikincil"),
        C("Trafonun hiçbir sargısı aşırı yüklenmiyor mu?", f"en yüklü bacak %{fnum(ks_max * 100, 0)}", "≤ %100", ks_max <= 1.0, "Toplam yük anma gücünün altında olsa bile akım iki faza yığılır: bir bacağın sargısı anma akımını aşabilir", "hesap"),
        C("Trafonun sıcak noktası (sürekli kalırsa)", f"{fnum(sur['sn'], 0)} °C", f"≤ {fnum(sn_sinir, 0)} °C", sur["sn"] <= sn_sinir, "En sıcak sargının yüklenmesi ve toplam kayıpla — «Isınma, aşırı yük ve ömür» sayfasındaki model", "dogrulanacak"),
        C("Motorlar termikten açmadan çalışabiliyor mu?", f"{fnum(m_faz, 2)} × In" if im_n > 0 else "motor yok", "≤ 1,15 × In", (m_faz <= 1.15) if im_n > 0 else None,
          "Sabit yükteki motor, gerilimi düşen fazların eksiğini akımla kapatır; negatif bileşen akımı rotoru ayrıca ısıtır", "tahmini"),
        C("OG koruması bu durumu görür mü?", f"kalan fazlarda {fnum(max(iy), 2)} × In", "sigorta ≈ 2 × In'de bile uzun sürede erir", None,
          "Faz kopması bir aşırı akım arızası değildir: akım anma değerinin dolayındadır. OG sigortası ve aşırı akım rölesi çalışmaz", "hesap"),
        C("Dyn trafoda bir faz açıkken AG gerilimleri", "bir faz tam, iki faz yarım ve ters yönde (yüksüz / dengeli empedans yükünde)", "0,5 / 1,0 / 0,5 pu", None, SEL_AF + " — motor yükü bu dağılımı değiştirir", "ikincil"),
    ]
    girdiler = tr_girdi(tr) + [
        G("Bağlantı grubu ve çekirdek", f"{grup} · {'üç' if cek == '3' else 'beş'} bacaklı", "Trafo etiketi", "Hangi AG fazının sağlam kalacağını ve gerilimlerin nasıl bölüneceğini sargı bağlantısı belirler", "üçgen sargıda bir bacak tam gerilimde kalır; yıldızda iki bacak seri bağlanır"),
        G("Açık iletken", "yok" if nacik == 0 else " + ".join(f"L{j + 1}" for j in range(3) if acik[j]), "OG sigortalarının durumu, ayırıcı bıçakları, hat jumperleri; arıza göstergesi", "Tek hat açıkken trafo iki fazla, iki hat açıkken tek uçla kalır", "açık fazın kaynağı devreden çıkar"),
        G("Yükün türü", f"%{fnum(s * 100, 0)} · motor payı %{fnum(mot * 100, 0)}", "Tesisin yük listesi", "Dirençli yük gerilimi olduğu gibi kabul eder; motorlar eksik fazı üretmeye çalışır ve akımı büyütür", "motor: pozitif bileşende sabit güç, negatif bileşende kilitli rotor empedansı"),
    ]
    adimlar = [
        A("Sağlam kalan bacak", "üçgen sargı: açık olmayan iki hattın arasındaki sargı tam gerilimde" if grup[0] == "D" else "yıldız sargı: iki sağlam faz seri kalır, her biri hat geriliminin yarısını alır",
          "U(bacak) = U(hat arası)" if grup[0] == "D" else "U(bacak) = U(hat arası) / 2 = 0,866 × anma", " · ".join(f"bacak {j + 1}: %{fnum(abs(r['e'][j]) * 100, 0)}" for j in range(3)), TEMEL, "hesap", ["Bağlantı grubu ve çekirdek", "Açık iletken"]),
        A("Öbür iki bacak", "kalan iki sargı seri: gerilimi yüklerinin empedansına göre paylaşır" if grup[0] == "D" else "açık fazın bacağı: üç bacaklı çekirdekte akılar toplamı sıfır olmak zorunda",
          "eşit yükte her birine yarısı" if grup[0] == "D" else "φ1 = −(φ2 + φ3) = 0", " / ".join(f"%{fnum(u * 100, 0)}" for u in ua) + " (AG faz–nötr)", SEL_AF if grup[0] == "D" else TEMEL, "ikincil" if grup[0] == "D" else "hesap"),
        A("Simetrili bileşenler", "V1 = (Va + a·Vb + a²·Vc) / 3 · V2 = (Va + a²·Vb + a·Vc) / 3", "AG faz–nötr gerilimlerinden", f"V1 = %{fnum(abs(v1) * 100, 0)} · V2 = %{fnum(abs(v2) * 100, 0)} · V2/V1 = %{fnum(vuf, 0)}", "Fortescue dönüşümü", "hesap"),
        A("Motor akımı", "I1 ≈ In / V1 (sabit güç) · I2 = V2 / Z(kilitli rotor)", f"V1 = {fnum(abs(v1), 2)} · V2 = {fnum(abs(v2), 2)} · Z2 ≈ 1/6 pu", f"I1 = {fnum(m1, 2)} × In · I2 = {fnum(m2, 2)} × In" if im_n > 0 else "motor yok",
          "negatif bileşen alanı rotora göre ters yönde, yaklaşık iki katı hızda döner: motor ona kilitli rotor gibi görünür", "tahmini", ["Yükün türü"]),
        A("Sargı yüklenmesi", "her bacakta sargı akımı / sargının anma akımı", "devre çözümünden", f"en yüklü bacak %{fnum(ks_max * 100, 0)} · eşdeğer kayıp yükü %{fnum(k_eq * 100, 0)}", "bacak başına amper-sarım dengesi", "hesap"),
        A("Trafonun sıcaklığı", "toplam kayıp → yağ; en yüklü sargı → sıcak nokta" if tip == "yag" else "en yüklü sargı → sıcak nokta", f"K(kayıp) = {fnum(k_eq, 2)} · K(sargı) = {fnum(ks_max, 2)} · ortam {fnum(ta, 0)} °C",
          f"sürekli kalırsa sıcak nokta {fnum(sur['sn'], 0)} °C", "«Isınma, aşırı yük ve ömür» sayfasındaki model", "dogrulanacak"),
    ]
    ayarlar = [
        S("AG gerilim denetim rölesi (faz kaybı, faz sırası, dengesizlik)", "dengesizlik %5–10 · düşük gerilim %85 · gecikme 1–5 s", "cihaza göre", "Faz kopmasını doğrudan gören en ucuz korumadır; AG ana kesicinin açma bobinine ya da motor kontaktörlerine bağlanır", "saha pratiği", "ikincil"),
        S("Motor koruma rölesi › faz dengesizliği (46) / faz kaybı", "I2 > %10–20 In, 1–3 s", "cihaza göre", "Motoru termik röleden çok önce ayırır", "Röle laboratuvarı › Negatif bileşen sayfası", "ikincil"),
        S("OG rölesi › negatif bileşen / kopuk iletken (46BC, I2/I1)", "I2/I1 > %20–30, birkaç saniye", "cihaza göre", "Hücrede röle varsa kopuk iletkeni akımların dengesizliğinden yakalar; yük çok azken çalışmaz", "saha pratiği", "ikincil"),
        S("OG sigortası", "kalan iki sigorta erimez", "—", "Sigorta attıktan sonra trafonun iki fazla kalması, üç fazlı açma yapmayan sigortalı korumanın bilinen sakıncasıdır; darbe pimli sigorta + yük ayırıcısı üç fazı birden açar", "saha pratiği", "ikincil"),
        S("GES eviricisi › düşük gerilim (27)", "< %88 Un → 2,0 s · < %50 Un → 0,2 s", "LÜY ayarı", "AG'ye bağlı evirici düşen fazı görür ve ayrılır", "Lisanssız Elektrik Üretimi Yön. Uygulama Tebliği Ek-2 Tablo-2"),
    ]
    test = [
        T("AG faz–nötr gerilimleri", "Ana panoda üç fazı nötre göre ölç", " / ".join(f"{fnum(u * 231, 0)} V" for u in ua), "bir faz tam, iki faz düşükse OG'de bir faz yoktur"),
        T("AG faz arası gerilimleri", "L1–L2, L2–L3, L3–L1", " / ".join(f"{fnum(u * 400, 0)} V" for u in ull), "Dyn trafoda yüksüzken faz aralarından biri sıfıra yakın çıkar"),
        T("OG akımları", "Hücre ampermetresi / röle ölçüleri", " / ".join(fa(i * tr["i1"], 1) for i in iy), "bir fazda akım yok, öbür ikisinde eşit ve 180° ters"),
        T("OG sigortaları ve ayırıcı", "Enerjisiz ve topraklanmış durumda gözle ve süreklilik ölçüsüyle", "atan sigortanın darbe pimi çıkmıştır", "sigorta değiştirmeden önce neden attığı bulunur: AG tarafında arıza, yıldırım, yaşlanma"),
    ]
    th = [x / 60 for x in b["t"]]
    g1 = {"baslik": "Kopmadan sonra trafonun sıcaklığı", "x_ad": "Zaman (saat)", "y_ad": "Sıcaklık (°C)", "zaman": True,
          "seriler": [{"ad": "en sıcak sargı (sıcak nokta)", "renk": "#dc2626", "pts": pts(th, b["sn"], 1)}] + ([{"ad": "üst yağ", "renk": "#b45309", "pts": pts(th, b["yag"], 1)}] if tip == "yag" else []),
          "yatay": [{"y": sn_sinir, "etiket": "sıcak nokta sınırı", "renk": "#dc2626"}, {"y": acma_e, "etiket": "açma eşiği", "renk": "#7c3aed"}]}
    yukler = [j / 20 for j in range(0, 25)]
    egri = [M.hesapla(grup, zk, zs, acik, {"s": x, "cos": cosf, "motor": mot}, cekirdek=cek) for x in yukler]
    g2 = {"baslik": "Yüke göre en yüklü sargı ve en düşük AG gerilimi (bu kopuklukta)", "x_ad": "Yük (% Sn)", "y_ad": "%", "ymin": 0,
          "seriler": [{"ad": "en yüklü sargı (%)", "renk": "#dc2626", "pts": pts([x * 100 for x in yukler], [max(e["k_sargi"]) * 100 for e in egri], 1)},
                      {"ad": "en düşük faz–nötr gerilimi (%)", "renk": "#1a4d8f", "pts": pts([x * 100 for x in yukler], [min(abs(u) for u in e["ua"]) * 100 for e in egri], 1)}],
          "yatay": [{"y": 100, "etiket": "anma", "renk": "#94a3b8"}], "isaretler": [{"x": s * 100, "etiket": "yük"}]}
    cub = {"baslik": "Faz faz: AG gerilimi ve sargı yüklenmesi", "kategoriler": ["L1 / bacak 1", "L2 / bacak 2", "L3 / bacak 3"], "y_ad": "%",
           "seriler": [{"ad": "AG faz–nötr gerilimi", "renk": "#1a4d8f", "deger": [round(u * 100, 1) for u in ua]}, {"ad": "sargı yüklenmesi", "renk": "#dc2626", "deger": [round(x * 100, 1) for x in ks]},
                       {"ad": "AG akımı", "renk": "#6b7280", "deger": [round(x * 100, 1) for x in ia]}]}
    # tablo: her bağlantı grubu ve kopukluk için yüksüz AG gerilimleri
    satir = []
    for g_ in M.GRUPLAR:
        for ad, ac in (("tek hat (L1)", (True, False, False)), ("iki hat (L1, L2)", (True, True, False))):
            q = M.hesapla(g_, zk, zs, ac, {"s": 0.0}, cekirdek=cek)
            w = M.hesapla(g_, zk, zs, ac, {"s": 0.6, "cos": 0.9, "motor": 0.5}, cekirdek=cek)
            satir.append([g_, ad, " / ".join(fnum(abs(u) * 231, 0) for u in q["ua"]), " / ".join(fnum(abs(u) * 231, 0) for u in w["ua"]), f"%{fnum(max(w['k_sargi']) * 100, 0)}"])
    if nacik == 0:
        ne = "Hiçbir iletken açık değil: üç faz dengeli, gerilimler ve akımlar olağan."
    elif olu:
        ne = "İki hat açık: trafonun YG sargılarına tek bir uçtan gerilim geliyor. Akımın dolaşabileceği kapalı bir yol olmadığı için çekirdekte akı oluşmaz; AG'de üç fazda da gerilim yoktur."
    elif grup[0] == "D":
        ne = ("Üçgen sargıda her bacağın sargısı iki hat arasına bağlıdır. Bir hat açılınca sağlam iki hattın arasındaki sargı tam gerilimde kalır; öbür iki sargı aynı gerilimin altında seri kalır "
              "ve onu yüklerine göre paylaşır. AG'de bir faz tam gerilimde, öbür ikisi yarım gerilim dolayında ve tam fazın tersi yönünde olur.")
    else:
        ne = ("Yıldız sargıda (yıldız noktası yalıtılmış) bir hat açılınca sağlam iki fazın sargıları hat arası gerilimin altında seri kalır: her bacak anma geriliminin 0,866 katını alır. "
              + ("Üç bacaklı çekirdekte akıların toplamı sıfır olmak zorunda olduğundan açık fazın bacağında akı kalmaz." if cek == "3" else "Beş bacaklı çekirdekte açık fazın bacağından da akı geçebilir; gerilimi yük belirler."))
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(fazorler=[fz1, fz2]), "grafikler": [g1, g2], "cubuklar": [cub],
        "anlatim": [
            ne,
            ("Tek fazlı alıcılar bağlı oldukları fazın gerilimini görür: " + ", ".join(f"L{j + 1} {fnum(ua[j] * 231, 0)} V" for j in range(3)) + ". Düşük fazlardaki kontaktörler düşer ya da titrer, elektronik cihazlar kapanır, lambalar söner.") if nacik else
            "Kopukluk seçin: tek hat ve iki hat açıkken gerilimlerin nasıl değiştiğini karşılaştırın.",
            ("Motorlar durumu değiştirir. Dönen bir motor eksik fazın gerilimini kısmen yeniden üretir; bu yüzden gerilimler yüksüz durumdaki kadar bozuk görünmez. Ama motor aynı momenti vermek için pozitif bileşen akımını artırır, "
             f"ayrıca negatif bileşen akımı çeker: en yüklü fazda {fnum(m_faz, 1)} × In." if im_n > 0 and nacik and not olu else "Yük yalnız dirençli alıcılardan oluşuyorsa gerilimleri sargıların bağlantısı belirler; akım düşen gerilimle birlikte azalır."),
            (f"Trafonun YG tarafında kalan iki hattan {fnum(max(iy), 2)} × In akıyor: bu bir kısa devre akımı değildir, OG sigortası ve aşırı akım rölesi için olağan bir yüktür. Arıza OG korumasına görünmez." if nacik and not olu else
             "Olağan çalışmada üç hattan eşit akım akar."),
            (f"Akım iki faza yığıldığı için bir bacağın sargısı %{fnum(ks_max * 100, 0)} yükleniyor (kopmadan önce %{fnum(max(n0['k_sargi']) * 100, 0)}). " if nacik and not olu else "") +
            ("Trafo bu durumda sürekli kalırsa sıcak nokta " + f"{fnum(sur['sn'], 0)} °C'de dengelenir" + ("; sınır aşılmıyor: trafonun kendisi dayanır, dayanmayan yüktür." if sur["sn"] <= sn_sinir else f"; sınır {fnum(sn_sinir, 0)} °C'dir ve {sure_yaz(t_sn) if t_sn is not None else 'saatler'} içinde aşılır.")),
            "Doğru davranış: faz kaybını AG tarafında gerilimden ve motorlarda akım dengesizliğinden algılayıp yükü hemen ayırmak, sonra OG'de kopukluğu bulmak. Sigortayı neden attığını bulmadan değiştirmek arızayı tekrarlatır.",
        ],
        "dersler": [
            "OG'de tek faz kopması AG'de «bir faz tam, iki faz yarım» olarak görünür (Dyn ve Yzn trafolarda). Üç fazın üçü de bozulmaz; bu yüzden gözden kaçar.",
            "İki faz kopunca trafonun çıkışında gerilim kalmaz: tek uçtan beslenen sargıdan akım akamaz.",
            "Faz kopması aşırı akım arızası değildir. OG sigortası ve aşırı akım rölesi görmez; gerilim denetim rölesi ve motor koruması görür.",
            "Asıl zarar motorlardadır: iki fazla dönen motor birkaç dakikada yanar. Trafo çoğu zaman bu durumu saatlerce taşır.",
            "Sigortalı OG korumasında bir sigorta atınca trafo iki fazla kalır. Darbe pimli sigortanın yük ayırıcısını açtırması bu yüzden istenir.",
        ],
        "tablolar": [{"baslik": "Bağlantı grubuna göre AG faz–nötr gerilimleri (L1 / L2 / L3, volt)", "cols": ["Grup", "Kopukluk", "Yüksüz", "%60 yük, yarısı motor", "En yüklü sargı"],
                      "rows": satir, "not": "Yüksüz durumda gerilimleri yalnız sargı bağlantısı ve çekirdek belirler. Motor yükü eksik fazı kısmen ayağa kaldırır ama sargı yüklenmesini büyütür."}],
    }
