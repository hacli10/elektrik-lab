"""Yüzeysel atlama ve iz oluşumu: yalıtkanın yüzeyi boyunca kaçak yolu, kirlilik ve nem; kaçak akım, kuru bant arkı, karbon izi (tracking); epoksi, porselen ve
silikonun farkı.

Kaçak yolu uzunlukları TEDAŞ-MLZ/96-020 (OG mesnet izolatörleri) böl. 2.2'den: kirlenme düzeyi II (orta) için 220 / 240 / 350 / 720 mm, III (ağır) için — / 300 / 438 / 900 mm
(Um 7,2 / 12 / 17,5 / 36 kV; 36 kV'ta 20 ve 25 mm/kV). Düzey I ve IV için 16 ve 31 mm/kV (IEC 60815) bellekten (dogrulanacak). Kaçak akım ve kuru bant modeli
öğretim amaçlı yaklaşık bir modeldir (tahmini): yüzey tabakasının iletkenliği kirlilikle, kuru bandın atlama gerilimi ≈ 0,5 kV/mm alınır. İz dayanımı (CTI) grupları
IEC 60112 / 60664'ten bellekle (dogrulanacak)."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, num, opt, pts

ID = "yuzey"
BASLIK = "Yüzeysel atlama ve iz"
IKON = "🧵"
GIRIS = ("İzolatör, havadan çok daha kısa bir mesafeyi yüzeyi boyunca uzatarak korur. Yüzey kirlenip nemlenince üstünde ince bir iletken tabaka oluşur: kaçak akım akar, yüzeyi yer yer "
         "kurutur, kuruyan bantlarda küçük arklar yanar. Organik yalıtkanda bu arklar karbon izi bırakır ve iz büyür. Kaçak yolunu, kirliliği ve malzemeyi değiştirip izleyin.")
MTEDAS = "TEDAŞ-MLZ/96-020 (OG mesnet izolatörleri şartnamesi) böl. 2.2"
UM = (7.2, 12.0, 17.5, 36.0)
KACAK = {"II": dict(zip(UM, (220, 240, 350, 720))), "III": dict(zip(UM, (None, 300, 438, 900)))}
KIR = {"I": ("I — hafif (kapalı, temiz ortam)", 16.0, 0.06), "II": ("II — orta (sanayi, az toz)", 20.0, 0.12), "III": ("III — ağır (yoğun toz, kıyı)", 25.0, 0.22), "IV": ("IV — çok ağır (çimento, tuz, kimya)", 31.0, 0.30)}
ESIK = 1.5            # mA — kuru bant arklarının başladığı kaçak akım (öğretim modeli)
MALZ = {"porselen": ("Porselen / cam", 600, False, "inorganik: iz oluşmaz, yüzey aşınmaz"), "epoksi": ("Epoksi reçine (bina içi)", 400, True, "organik: ark karbon izi bırakır"),
        "silikon": ("Silikon kauçuk", 600, False, "su tutmaz: tabaka damlacıklara ayrılır"), "pvc": ("PVC / poliamid (AG klemens, pano parçası)", 175, True, "düşük iz dayanımı")}

KONTROLLER = [
    ctl("um", "Donanımın en yüksek gerilimi Um", "sec", 36.0, secenek=opt(*[(k, f"{str(k).replace('.', ',')} kV") for k in UM])),
    ctl("kacak", "Kaçak yolu uzunluğu", "sayi", 720, min=50, max=1400, adim=10, birim="mm", yardim="İzolatörün yüzeyi boyunca, canlı uçtan toprağa en kısa yol (etekler dahil)"),
    ctl("kir", "Kirlenme düzeyi", "sec", "II", secenek=opt(*[(k, v[0]) for k, v in KIR.items()])),
    ctl("nem", "Yüzeyin durumu", "sec", "nemli", secenek=opt(("kuru", "Kuru"), ("nemli", "Nemli (sis, çiy, yoğuşma)"), ("islak", "Islak (yağmur, yıkama)"))),
    ctl("malz", "Yalıtkan malzeme", "sec", "epoksi", secenek=opt(*[(k, v[0]) for k, v in MALZ.items()])),
    ctl("yil", "Bu koşulda geçen süre", "sayi", 5, min=0, max=30, adim=1, birim="yıl"),
]


def run(p: dict) -> dict:
    um, lk, kir, nem, malz, yil = num(p, "um", 36.0), num(p, "kacak", 720), str(p.get("kir", "II")), str(p.get("nem", "nemli")), str(p.get("malz", "epoksi")), num(p, "yil", 5)
    ad, ozgul, ilet = KIR[kir]                                          # mm/kV (faz arası), yüzey iletkenliği (µS)
    mad, cti, organik, mack = MALZ[malz]
    gerek = ozgul * um
    u_fn = um / math.sqrt(3)
    ozg = lk / um
    carp = {"kuru": 0.02, "nemli": 1.0, "islak": 0.6}[nem] * (0.3 if malz == "silikon" else 1.0)          # ıslak yüzey yıkanır; silikon su tutmaz
    g_s = ilet * carp * 1e-6                                            # S (kare başına)
    bicim = lk / (math.pi * 80.0)                                       # biçim katsayısı: uzunluk / çevre (ortalama çap 80 mm)
    i_ka = u_fn * 1e3 * g_s / bicim * 1e3 if bicim else 0                # mA
    # kuru bant: kaçak akım > 1 mA ise yüzey yer yer kurur; bantların üstündeki gerilimle ark yanar
    kuru_bant = i_ka > ESIK
    u_atlama = 0.5 * lk * (1.0 if nem == "kuru" else 0.45 if kir in ("I", "II") else 0.3) * (1.3 if malz == "silikon" else 1.0) / math.sqrt(3) * (16.0 / ozgul if nem != "kuru" else 1.0)          # kV etkin (faz–toprak)
    pay = u_atlama / u_fn
    iz_hizi = (i_ka / 5.0) * (600.0 / cti) ** 2 if (organik and kuru_bant) else 0.0          # mm/yıl
    iz = min(iz_hizi * yil, lk)
    lk_etkin = lk - iz
    pay_son = pay * lk_etkin / lk if lk else 0
    atladi = pay_son < 1.0
    c = Cizim(900, 310)
    c.dikdortgen(150, 40, 60, 18, "cizgi", "#94a3b8"); c.yazi(180, 32, f"canlı uç — {fnum(u_fn, 1)} kV", "#8a4b12", 11.5, kalin=True, anchor="middle")
    renk = "#fde68a" if malz == "epoksi" else "#e2e8f0" if malz == "porselen" else "#fecaca" if malz == "silikon" else "#ddd6fe"
    for j in range(5):                                                   # etekler
        c.dikdortgen(165, 58 + j * 40, 30, 40, "cizgi", renk, kw=1.2, r=0)
        c.dikdortgen(130, 70 + j * 40, 100, 12, "ariza" if (kuru_bant and j % 2 == 1) else "cizgi", renk, kw=1.2, r=5)
        if kuru_bant and j % 2 == 1:
            c.simsek(232, 60 + j * 40, 0.7)
    c.dikdortgen(140, 258, 80, 16, "cizgi", "#94a3b8"); c.toprak(180, 276)
    if iz > 1:
        c.hat(f"M196,{258 - min(iz / lk, 1) * 200:.0f} V258", "ariza", w=4); c.yazi(250, 250, f"karbon izi {fnum(iz, 0)} mm", "#b91c1c", 11, kalin=True)
    c.yazi(60, 160, "kaçak yolu", "#1d4ed8", 11, anchor="middle"); c.yazi(60, 176, f"{fnum(lk, 0)} mm", "#1d4ed8", 12.5, kalin=True, anchor="middle")
    c.yazi(400, 50, "YÜZEYSEL ATLAMA" if atladi else "Kuru bant arkları yanıyor" if kuru_bant else "Yüzey sakin", "#b91c1c" if atladi or kuru_bant else "#15803d", 14, kalin=True)
    c.yazi(400, 76, f"Özgül kaçak yolu {fnum(ozg, 1)} mm/kV — düzey {kir} için ≥ {fnum(ozgul, 0)} mm/kV ({fnum(gerek, 0)} mm)", "#b91c1c" if lk < gerek else "#334155", 12.5, kalin=lk < gerek)
    c.yazi(400, 100, f"Kaçak akım ≈ {fnum(i_ka, 2)} mA" + (" → yüzey yer yer kurur" if kuru_bant else ""), "#b91c1c" if kuru_bant else "#334155", 12.5)
    c.yazi(400, 124, f"Bu durumda yüzeysel atlama gerilimi ≈ {fnum(u_atlama, 0)} kV (pay × {fnum(pay, 1)})", "#b91c1c" if pay < 1.5 else "#334155", 12.5)
    c.yazi(400, 148, f"Malzeme: {mad} — {mack}", "#334155", 12)
    c.yazi(400, 178, (f"İz {fnum(iz_hizi, 1)} mm/yıl ilerliyor: {fnum(yil, 0)} yılda {fnum(iz, 0)} mm → pay × {fnum(pay_son, 1)}" if iz_hizi > 0 else "İz oluşmuyor"), "#b91c1c" if iz_hizi > 0 else "#15803d", 12.5, kalin=iz_hizi > 0)
    c.yazi(400, 212, "Kaçak akım yüzeyi en dar yerden ısıtıp kurutur. Kuru bant bütün gerilimi", "#64748b", 11); c.yazi(400, 228, "üstüne alır ve üstünde ark yanar. Yağmur kiri yıkar; sis ve çiy yıkamadan ıslatır:", "#64748b", 11)
    c.yazi(400, 244, "en tehlikeli hava, uzun kuraklıktan sonraki sisli sabahtır.", "#64748b", 11)
    ozet = [
        K("Özgül kaçak yolu", f"{fnum(ozg, 1)} mm/kV", "bad" if lk < gerek else "ok", f"düzey {kir} için ≥ {fnum(ozgul, 0)} mm/kV"),
        K("Kaçak akım", f"{fnum(i_ka, 2)} mA", "bad" if i_ka > 3 else "warn" if kuru_bant else "ok", "kuru bant eşiği ≈ 1,5 mA"),
        K("Yüzeysel atlama payı", f"× {fnum(pay_son, 1)}", "bad" if pay_son < 1 else "warn" if pay_son < 1.5 else "ok", f"atlama ≈ {fnum(u_atlama * lk_etkin / lk if lk else 0, 0)} kV"),
        K("İz (tracking)", f"{fnum(iz, 0)} mm" if iz_hizi > 0 else "yok", "bad" if iz > 0.2 * lk else "warn" if iz_hizi > 0 else "ok", f"{fnum(iz_hizi, 1)} mm/yıl" if iz_hizi > 0 else mack),
        K("İz dayanımı (CTI)", f"{cti} V", "warn" if cti < 400 else "ok", "malzeme grubu " + ("I" if cti >= 600 else "II" if cti >= 400 else "IIIa" if cti >= 175 else "IIIb")),
    ]
    resmi_var = kir in KACAK and KACAK[kir].get(um)
    kontroller = [
        C("Kaçak yolu kirlenme düzeyine yetiyor mu?", f"{fnum(lk, 0)} mm ({fnum(ozg, 1)} mm/kV)", f"≥ {fnum(gerek, 0)} mm ({fnum(ozgul, 0)} mm/kV)", lk >= gerek - 1e-9,
          (f"Harici tip mesnet izolatörü, Um {str(um).replace('.', ',')} kV, kirlenme düzeyi {kir}: en az {KACAK[kir][um]} mm — " + MTEDAS) if resmi_var else "Özgül kaçak yolu: düzey I 16, II 20, III 25, IV 31 mm/kV (IEC 60815 — asıl metinle doğrulanacak)",
          "resmi" if resmi_var else "dogrulanacak"),
        C("Kaçak akım kuru bant eşiğinin altında mı?", f"{fnum(i_ka, 2)} mA", "< 1,5 mA", not kuru_bant, "Tabakanın direnci kaçak yolunun uzunluğuyla artar, kirlilik ve nemle azalır — yaklaşık model", "tahmini"),
        C("Yüzeysel atlama payı", f"× {fnum(pay_son, 1)}", "≥ 1,5", pay_son >= 1.5, "Kirli ve nemli yüzeyin atlama gerilimi kuru haldekinin üçte biri – yarısı kadardır — yaklaşık model", "tahmini"),
        C("Malzeme iz oluşumuna dayanıklı mı?", f"CTI {cti} V · {'organik' if organik else 'iz oluşmaz'}", "ağır kirlilikte CTI ≥ 600 ya da inorganik", (not organik) or cti >= 600 or kir in ("I", "II"),
          "Bina içi (dahili) mesnet izolatörlerinde organik malzeme olarak yalnız epoksi reçine kullanılır; bina dışı tipler porselen ya da camdır — TEDAŞ-MLZ/96-020 böl. 2.1 ve 2.3.1", "resmi"),
        C("İz kaçak yolunu kısaltıyor mu?", f"{fnum(iz, 0)} mm ({fnum(yil, 0)} yılda)", "iz yok", iz < 1.0, "Karbon izi iletkendir: her ark izi biraz uzatır, kalan yalıtkan yol kısalır, alan artar — hızlanan bir süreçtir", "tahmini"),
    ]
    girdiler = [
        G("Kaçak yolu", f"{fnum(lk, 0)} mm", "İzolatör kataloğu / etiketi; yüzey boyunca ölçü", "Yüzeyden akacak akımın yolunu ve direncini belirler", "özgül kaçak yolu = L / Um"),
        G("Ortamın kirliliği", ad, "Tesisin yeri: sanayi, kıyı, tarım, çimento; hücre içi toz ve yoğuşma", "Gereken kaçak yolunu ortam belirler, gerilim değil", "16 – 20 – 25 – 31 mm/kV"),
        G("Malzeme", f"{mad} · CTI {cti} V", "Üretici verisi", "Arkın yüzeyde kalıcı iz bırakıp bırakmayacağını belirler", "CTI: iz oluşmadan dayanılan gerilim (damla deneyi)"),
    ]
    adimlar = [
        A("Gereken kaçak yolu", "L ≥ (mm/kV) × Um", f"{fnum(ozgul, 0)} × {str(um).replace('.', ',')}", f"{fnum(gerek, 0)} mm", MTEDAS if resmi_var else "IEC 60815 — doğrulanacak", "resmi" if resmi_var else "dogrulanacak", ["Ortamın kirliliği"]),
        A("Yüzey tabakasının direnci", "R = F / G(yüzey) · F = L / (π·D)", f"F = {fnum(bicim, 1)} · G = {fnum(g_s * 1e6, 1)} µS", f"{fnum(bicim / g_s / 1e6, 1)} MΩ" if g_s else "çok büyük", "ince iletken tabaka — yaklaşık", "tahmini", ["Kaçak yolu"]),
        A("Kaçak akım", "I = U(faz–toprak) / R", f"{fnum(u_fn, 1)} kV / {fnum(bicim / g_s / 1e6, 1) if g_s else '∞'} MΩ", f"{fnum(i_ka, 2)} mA", "Ohm yasası", "hesap"),
        A("Kuru bant", "ısınma en dar kesitte en büyüktür: orası kurur, gerilim oraya biner", f"kaçak akım {fnum(i_ka, 2)} mA", "ark yanıyor" if kuru_bant else "yok", "tabakanın birim uzunluktaki gücü I²·r", "tahmini"),
        A("İz hızı", "organik yüzeyde ark sıcaklığı reçineyi karbonlaştırır", f"CTI {cti} V", f"{fnum(iz_hizi, 1)} mm/yıl" if iz_hizi else "iz oluşmaz", "öğretim modeli", "tahmini", ["Malzeme"]),
    ]
    ayarlar = [
        S("Duyarlı toprak arıza koruması", "kaçak akım mA düzeyindedir: görmez", "—", "İz büyüyüp atlama olduğunda toprak arızası olarak görülür", "Röle laboratuvarı › Toprak aşırı akım", "ikincil"),
        S("Hücre ısıtıcısı ve nem denetimi", "yoğuşmayı önler", "—", "Kuru yüzeyde kir iletken değildir", "saha pratiği", "ikincil"),
        S("Temizlik / yıkama / silikon kaplama", "kirli ortamda dönemsel", "—", "Tabakayı kaldırır ya da su tutmaz hale getirir", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Gözle denetim", "Yüzeyde dallanan siyah çizgiler, tebeşirleşme, aşınma olukları", "yok", "iz bir kez başladıysa temizlikle geçmez: parça değiştirilir"),
        T("Kısmi boşalma / ultrasonik dinleme", "Nemli havada, gerilim altında", "cızırtı yok", "yüzey boşalması delinmeden önce duyulur ve koklanır (ozon)"),
        T("Yalıtım direnci", "Meger, kuru ve nemli halde", "nemli halde belirgin düşmemeli", "düşüyorsa yüzey kirlidir"),
    ]
    ls = [um * x for x in (10, 12, 14, 16, 18, 20, 22, 25, 28, 31, 35, 40)]
    g1 = {"baslik": "Kaçak yoluna göre kaçak akım (nemli yüzey)", "x_ad": "Kaçak yolu (mm)", "y_ad": "Kaçak akım (mA)", "logy": True,
          "seriler": [{"ad": v[0].split(" — ")[0] + " — " + v[0].split(" — ")[1].split(" (")[0], "renk": r, "kesik": k != kir, "pts": pts(ls, [max(u_fn * 1e3 * v[2] * 1e-6 / (x / (math.pi * 80)) * 1e3, 1e-3) for x in ls], 3)}
                      for (k, v), r in zip(KIR.items(), ("#15803d", "#1a4d8f", "#b45309", "#dc2626"))],
          "yatay": [{"y": ESIK, "etiket": "kuru bant eşiği", "renk": "#7c3aed"}], "isaretler": [{"x": lk, "etiket": "izolatör"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1],
        "ses": [{"ad": "Kuru bant arkı", "not": "nemli havada duyulan kesik kesik cızırtı", "sure": 3.0, "zarf": "surekli", "siddet": 0.4, "vuru": 3, "parcalar": [{"f": 100, "a": 0.2}], "gurultu": 1.0, "gurultu_f": 4000, "citirti": 0.05}],
        "anlatim": [
            f"İzolatörün canlı ucu ile toprağı arasındaki hava yolu kısadır; yüzey boyunca yol ise eteklerle uzatılmıştır: {fnum(lk, 0)} mm. Temiz ve kuru yüzeyde akım akmaz, belirleyici olan hava aralığıdır.",
            "Yüzeye toz, tuz ya da kurum konar. Kuruyken zararsızdır. Sis ya da çiy tabakayı ıslatınca içindeki tuzlar çözülür ve yüzeyde ince, iletken bir film oluşur: kaçak akım akmaya başlar.",
            f"Kaçak akım şimdi {fnum(i_ka, 2)} mA. Akım yüzeyi ısıtır; en dar yerde (gövdede, eteklerin dibinde) ısınma en büyüktür ve orası önce kurur. Kuruyan bant yalıtkandır: gerilimin tamamı o birkaç milimetrenin üstüne biner ve bant atlar.",
            ("Bu küçük arklar söner, yeniden yanar; yüzeyde gezinir. Porselende ve camda iz bırakmazlar. Organik malzemede ise ark sıcaklığı reçineyi karbonlaştırır: geriye iletken, siyah bir çizgi kalır. Çizgi kaçak yolunu kısaltır, kalan yolda alan büyür, arklar şiddetlenir."
             if organik else "Bu malzemede arklar kalıcı iz bırakmaz: " + mack + ". Tehlike, arkların birleşip bütün yüzeyi köprülemesidir."),
            "Arklar uzayıp birleşirse yüzeyin tamamı köprülenir: yüzeysel atlama. Akım artık kaçak akım değil kısa devre akımıdır. Atlama gerilimi, kirli ve nemli yüzeyde temiz haldekinin yarısının altına inebilir.",
            "Bu yüzden kaçak yolu gerilime göre değil ortama göre seçilir: orta kirlilikte kV başına 20 mm, ağır kirlilikte 25 mm. Bina içinde yoğuşmayı önlemek (ısıtıcı) çoğu zaman uzun izolatörden daha etkilidir.",
        ],
        "dersler": [
            "Kir kuruyken zararsızdır; onu iletken yapan nemdir. Yağmur yıkar, sis yıkamadan ıslatır.",
            "Kaçak yolu ortama göre seçilir: 36 kV'ta orta kirlilikte 720 mm, ağır kirlilikte 900 mm.",
            "Epokside iz bir kez başlarsa temizlikle geçmez ve büyür; porselende iz oluşmaz.",
            "Cızırtı, ozon kokusu ve karanlıkta gezinen küçük kıvılcımlar yüzeysel atlamanın habercisidir.",
            "Hücre ısıtıcısı bir konfor donanımı değil yalıtım donanımıdır.",
        ],
        "tablolar": [{"baslik": "Kirlenme düzeyine göre en küçük kaçak yolu (mm)", "cols": ["Kirlenme düzeyi", "mm/kV", "7,2 kV", "12 kV", "17,5 kV", "36 kV", "Dayanak"],
                      "rows": [[v[0], fnum(v[1], 0)] + [f"{KACAK[k][u]}" if k in KACAK and KACAK[k].get(u) else f"({fnum(v[1] * u, 0)})" for u in UM] + ["TEDAŞ-MLZ/96-020" if k in KACAK else "IEC 60815 (doğrulanacak)"] for k, v in KIR.items()],
                      "not": "Parantez içindeki değerler mm/kV × Um ile hesaplanmıştır; parantezsiz değerler şartname çizelgesindendir."}],
    }
