"""Havada atlama: iki iletken arasındaki hava aralığı hangi gerilimde delinir; elektrot biçiminin, aralığın, rakımın, sıcaklığın ve kirin etkisi; güvenli açıklıklar.

Düzgün alanda delinme: Paschen bağıntısı (küçük aralık) ve Ud = 24,22·δ·d + 6,08·√(δ·d) kV-tepe (d cm) deneysel bağıntısı. Sivri uçlu (düzgün olmayan) alanda atlama
gerilimi için yaklaşık bağıntı ve ıslak / kirli yüzey çarpanı tipiktir (tahmini). En küçük hava açıklıkları Siemens GEAFOL kılavuzunun IEC 60071'e dayanan çizelgesinden,
ark boynuzu aralıkları SGB-SMIT kılavuzundan, rakım düzeltmesi TEDAŞ-MLZ/99-032.E böl. 1.3.2'den (resmi)."""
from __future__ import annotations

import math

from . import fizik as F
from .ortak import A, C, G, K, S, SGB, SIEMENS_K, T, TEDAS_H, Cizim, ctl, fnum, logsp, num, opt, pts

ID = "atlama"
BASLIK = "Havada atlama"
IKON = "⚡"
GIRIS = ("Hava iyi bir yalıtkandır ama sınırı vardır: santimetre başına yaklaşık 30 kV'un üstünde iyonlaşır ve iletken olur. Bu sınır elektrotların biçimine çok bağlıdır: sivri bir uç, "
         "aynı aralıkta üçte bir gerilimde atlatır. Aralığı, biçimi, rakımı ve yüzeyin durumunu değiştirip atlama gerilimini izleyin.")
UM = {7.2: (60, 20, None, 60), 12.0: (75, 28, 120, 85), 17.5: (95, 38, 160, 115), 24.0: (125, 50, 220, 155), 36.0: (170, 70, 320, 220)}      # Um: (LI kV, AC kV, açıklık mm, ark boynuzu mm)
BICIM = {"duzgun": "Düzgün alan (levha – levha, yuvarlatılmış kenar)", "kure": "Küre – küre (yarı düzgün)", "cubuk": "Sivri uç – levha (düzgün olmayan)"}

KONTROLLER = [
    ctl("um", "Donanımın en yüksek gerilimi Um", "sec", 36.0, secenek=opt(*[(k, f"{str(k).replace('.', ',')} kV") for k in UM])),
    ctl("d", "Hava aralığı", "sayi", 320, min=5, max=600, adim=5, birim="mm"),
    ctl("bicim", "Elektrot biçimi", "sec", "cubuk", secenek=opt(*BICIM.items())),
    ctl("rakim", "Rakım", "sayi", 0, min=0, max=3000, adim=100, birim="m"),
    ctl("t", "Hava sıcaklığı", "sayi", 20, min=-25, max=50, adim=5, birim="°C"),
    ctl("yuzey", "Aralıkta yalıtkan yüzey / kir", "sec", "temiz", secenek=opt(("temiz", "Yalnız hava, temiz ve kuru"), ("nemli", "Yoğuşma, nemli toz (≈ %70)"), ("kirli", "Islak kir tabakası (≈ %40)"))),
    ctl("asiri", "Geçici aşırı gerilim katsayısı", "sayi", 1.0, min=1.0, max=4.0, adim=0.1, yardim="1: olağan işletme · 1,73: yalıtılmış şebekede toprak arızası (sağlam fazlar) · 2–4: anahtarlama, yıldırım"),
]
NEM = {"temiz": 1.0, "nemli": 0.7, "kirli": 0.4}


def run(p: dict) -> dict:
    um, d, bicim = num(p, "um", 36.0), num(p, "d", 320), str(p.get("bicim", "cubuk"))
    li, ac, a_min, boynuz = UM.get(um, UM[36.0])
    delta = F.hava_yogunlugu(num(p, "rakim", 0), num(p, "t", 20))
    nem = NEM.get(str(p.get("yuzey", "temiz")), 1.0)
    asiri = num(p, "asiri", 1.0)
    u_at = F.hava_atlama(d, bicim, delta, nem)                       # kV etkin
    u_duz = F.hava_atlama(d, "duzgun", delta, 1.0)
    u_fn = um / math.sqrt(3) * asiri
    pay = u_at / u_fn if u_fn else 0
    e_ort = u_at * math.sqrt(2) / (d / 10)                            # kV tepe / cm
    rak = num(p, "rakim", 0)
    a_duz = a_min * (1 + max(rak - 1000, 0) / 100 * 0.01) if a_min else None
    atladi = pay < 1.0
    c = Cizim(900, 300)
    x1, x2 = 200, 200 + min(max(d * 0.5, 30), 320)
    if bicim == "duzgun":
        c.dikdortgen(x1 - 14, 70, 14, 130, "cizgi", "#cbd5e1", r=6); c.dikdortgen(x2, 70, 14, 130, "cizgi", "#cbd5e1", r=6)
    elif bicim == "kure":
        c.daire(x1 - 26, 135, 26, "cizgi", "#cbd5e1"); c.daire(x2 + 26, 135, 26, "cizgi", "#cbd5e1")
    else:
        c.hat(f"M{x1 - 60},135 L{x1},135", "cizgi", w=8); c.hat(f"M{x1 - 12},127 L{x1},135 L{x1 - 12},143", "cizgi", w=3); c.dikdortgen(x2, 70, 14, 130, "cizgi", "#cbd5e1", r=6)
    c.hat(f"M60,135 H{x1 - (60 if bicim == 'cubuk' else 52 if bicim == 'kure' else 14)}", "L1", hot=True, w=3); c.yazi(60, 122, f"{fnum(u_fn, 1)} kV (faz–toprak)", "#8a4b12", 11.5, kalin=True)
    c.hat(f"M{x2 + (52 if bicim == 'kure' else 14)},135 H{x2 + 110}", "toprak", w=3); c.toprak(x2 + 110, 137)
    if atladi:
        c.hat(f"M{x1},135 L{(x1 + x2) / 2 - 10:.0f},118 L{(x1 + x2) / 2 + 8:.0f},150 L{x2},135", "ariza", hot=True, w=3); c.simsek((x1 + x2) / 2 - 6, 96, 1.4)
    c.hat(f"M{x1},220 H{x2}", "mavi", w=1.4); c.yazi((x1 + x2) / 2, 238, f"{fnum(d, 0)} mm", "#1d4ed8", 12, kalin=True, anchor="middle")
    c.yazi(560, 60, "ATLAMA: aralık bu gerilime dayanmıyor" if atladi else "Aralık dayanıyor", "#b91c1c" if atladi else "#15803d", 14, kalin=True)
    c.yazi(560, 86, f"Atlama gerilimi ≈ {fnum(u_at, 0)} kV (etkin, 50 Hz)", "#334155", 13, kalin=True)
    c.yazi(560, 110, f"Uygulanan {fnum(u_fn, 1)} kV → pay × {fnum(pay, 1)}", "#b91c1c" if pay < 2 else "#334155", 12.5)
    c.yazi(560, 134, f"Ortalama alan {fnum(e_ort, 1)} kV/cm (düzgün alanda ≈ {fnum(F.paschen(d, delta) / (d / 10), 0)})", "#334155", 12)
    c.yazi(560, 158, f"Hava yoğunluğu δ = {fnum(delta, 2)}" + (f" · yüzey çarpanı {fnum(nem, 1)}" if nem < 1 else ""), "#334155", 12)
    c.yazi(560, 188, f"Um {str(um).replace('.', ',')} kV için en küçük açıklık: " + (f"{fnum(a_duz, 0)} mm" if a_duz else "çizelgede yok"), "#1a4d8f", 12.5, kalin=True)
    c.yazi(560, 212, f"(yıldırım darbe dayanımı {li} kV-tepe, 50 Hz dayanımı {ac} kV)", "#64748b", 11)
    c.yazi(60, 270, "Sivri uçta alan uçta yoğunlaşır: orada iyonlaşma (korona) düşük gerilimde başlar ve atlamaya yol açar.", "#64748b", 11.5)
    ozet = [
        K("Atlama gerilimi", f"{fnum(u_at, 0)} kV", "bad" if atladi else "ok", "etkin, 50 Hz"),
        K("Güvenlik payı", f"× {fnum(pay, 1)}", "bad" if pay < 1 else "warn" if pay < 2 else "ok", f"uygulanan {fnum(u_fn, 1)} kV faz–toprak"),
        K("Biçimin etkisi", f"%{fnum(u_at / u_duz / nem * 100, 0)}", "info", "düzgün alandaki atlama geriliminin yüzdesi"),
        K("Hava yoğunluğu", fnum(delta, 2), "warn" if delta < 0.9 else "ok", f"{fnum(rak, 0)} m · {fnum(num(p, 't', 20), 0)} °C"),
        K("Gereken açıklık", f"{fnum(a_duz, 0)} mm" if a_duz else "—", "bad" if a_duz and d < a_duz else "ok", f"Um {str(um).replace('.', ',')} kV · LI {li} kV"),
    ]
    kontroller = [
        C("Aralık, standart açıklığın üstünde mi?", f"{fnum(d, 0)} mm", f"≥ {fnum(a_duz, 0)} mm" if a_duz else "çizelgede değer yok", (d >= a_duz) if a_duz else None,
          f"Um {str(um).replace('.', ',')} kV, yıldırım darbe dayanımı {li} kV için en küçük hava açıklığı (IEC 60071'e göre) — " + SIEMENS_K + " böl. 6.7 çizelgesi" + (f"; rakım düzeltmesiyle {fnum(a_duz, 0)} mm" if rak > 1000 else ""), "resmi"),
        C("Rakım düzeltmesi", f"{fnum(rak, 0)} m", "1000 m'yi aşan her 100 m için açıklık %1 artırılır", None if rak <= 1000 else (d >= (a_duz or 0)), "Hava seyreldikçe delinme dayanımı düşer — " + TEDAS_H + " böl. 1.3.2 (TS EN 60076-3 m.16)", "resmi"),
        C("50 Hz'te atlama payı", f"× {fnum(pay, 1)}", "≥ 2 (geçici aşırı gerilim ve kir için)", pay >= 2.0, "Atlama gerilimi elektrot biçimine, hava yoğunluğuna ve yüzeyin durumuna göre hesaplanmıştır; sivri uç ve kirli yüzey bağıntıları yaklaşık", "tahmini"),
        C("Ark boynuzu aralığı (trafo buşinglerinde)", f"Um {str(um).replace('.', ',')} kV", f"{boynuz} mm (deniz düzeyi)", None, "Ark boynuzu, yıldırım aşırı gerilimini buşingin yüzeyinden uzakta, bilinen bir aralıkta atlatır — " + SGB + " böl. 3.6", "resmi"),
    ]
    girdiler = [
        G("Gerilim", f"Um {str(um).replace('.', ',')} kV → faz–toprak {fnum(um / math.sqrt(3), 1)} kV; LI {li} kV-tepe", "Donanım etiketi (Um, yalıtım düzeyi)", "Açıklığı işletme gerilimi değil dayanması gereken darbe gerilimi belirler", "LI / d ≈ 500 kV/m"),
        G("Aralık ve biçim", f"{fnum(d, 0)} mm · {BICIM[bicim].split(' (')[0]}", "Ölçü: canlı parça ile toprak / öbür faz arası en kısa hava yolu", "Sivri köşe, cıvata ucu, kopuk tel aralığı «düzgün olmayan» yapar", "E(uç) ≫ E(ortalama)"),
        G("Ortam", f"{fnum(rak, 0)} m · {fnum(num(p, 't', 20), 0)} °C · {str(p.get('yuzey', 'temiz'))}", "Tesisin yeri; hücre içi yoğuşma, toz", "Hava yoğunluğu ve yüzey nemi dayanımı doğrudan değiştirir", "δ = (p/p0)·(293/(273+t))"),
    ]
    adimlar = [
        A("Hava yoğunluğu", "δ = (p / p0) · 293 / (273 + t)", f"{fnum(rak, 0)} m, {fnum(num(p, 't', 20), 0)} °C", fnum(delta, 3), "ideal gaz", "hesap", ["Ortam"]),
        A("Düzgün alanda delinme", "Ud = 24,22·δ·d + 6,08·√(δ·d) (kV tepe, d cm)", f"δ·d = {fnum(delta * d / 10, 2)} cm", f"{fnum(F.paschen(d, delta), 0)} kV tepe = {fnum(F.paschen(d, delta) / math.sqrt(2), 0)} kV etkin", "deneysel bağıntı (Paschen yasasının hava için uyarlaması)", "hesap", ["Aralık ve biçim"]),
        A("Biçim etkisi", "düzgün olmayan alanda atlama, uçtaki alan yoğunlaşması yüzünden daha düşük gerilimde olur", BICIM[bicim].split(" (")[0], f"{fnum(F.hava_atlama(d, bicim, delta, 1.0), 0)} kV etkin", "yaklaşık bağıntı", "tahmini"),
        A("Yüzey etkisi", "U = U(hava) × yüzey çarpanı", f"× {fnum(nem, 1)}", f"{fnum(u_at, 0)} kV etkin", "ıslak kir tabakası yüzeyde iletken yol açar — bkz. «Yüzeysel atlama»", "tahmini"),
        A("Pay", "U(atlama) / U(uygulanan)", f"{fnum(u_at, 0)} / {fnum(u_fn, 1)}", f"× {fnum(pay, 1)}", "geçici aşırı gerilim katsayısı dahil", "hesap", ["Gerilim"]),
    ]
    ayarlar = [
        S("Parafudr", "donanımın önünde, olabildiğince yakın", "—", "Yıldırım ve anahtarlama aşırı gerilimini açıklığın dayanım düzeyinin altında tutar", "Topraklama laboratuvarı › Yıldırım ve parafudr", "ikincil"),
        S("Ark rölesi / hızlı koruma", "ışık + akım", "—", "Atlama arka dönüştüğünde süreyi milisaniyelere indirir", "Röle laboratuvarı › Ark koruması", "ikincil"),
        S("Isıtıcı ve havalandırma", "hücre içinde nem denetimi", "—", "Yoğuşma, temiz bir açıklığı kirli yüzeye çevirir", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Açıklık ölçüsü", "Enerjisizken canlı parça – toprak ve faz – faz en kısa mesafe", f"≥ {fnum(a_duz, 0)} mm" if a_duz else "üretici değerine göre", "kablo pabucu, cıvata ucu, sarkan tel mesafeyi kısaltır"),
        T("Şebeke frekanslı dayanım deneyi", f"{ac} kV, 1 dakika", "atlama ve delinme olmaz", "tip / rutin deneyi; sahada azaltılmış gerilimle"),
        T("Korona", "Karanlıkta gözle, ultrasonik dinleyiciyle; ozon kokusu", "ışıma ve cızırtı yok", "korona atlamanın habercisidir: uçta alan sınırı aşılmıştır"),
    ]
    ds = logsp(1, 600, 50)
    g1 = {"baslik": "Aralığa göre atlama gerilimi (50 Hz, etkin)", "x_ad": "Hava aralığı (mm)", "y_ad": "kV", "logx": True, "logy": True,
          "seriler": [{"ad": BICIM[b].split(" (")[0], "renk": r, "kesik": b != bicim, "pts": pts(ds, [F.hava_atlama(x, b, delta, nem) for x in ds], 2)} for b, r in zip(BICIM, ("#15803d", "#1a4d8f", "#dc2626"))],
          "yatay": [{"y": u_fn, "etiket": "uygulanan", "renk": "#7c3aed"}], "isaretler": [{"x": d, "etiket": "aralık"}]}
    rs = list(range(0, 3001, 100))
    g2 = {"baslik": "Rakıma göre atlama gerilimi (bu aralık ve biçim)", "x_ad": "Rakım (m)", "y_ad": "kV (etkin)",
          "seriler": [{"ad": "atlama gerilimi", "renk": "#dc2626", "pts": pts(rs, [F.hava_atlama(d, bicim, F.hava_yogunlugu(x, num(p, "t", 20)), nem) for x in rs], 2)}], "isaretler": [{"x": rak, "etiket": "tesis"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "ses": [{"ad": "Korona cızırtısı", "not": "atlamadan önce: sivri uçta sürekli cızırtı", "sure": 3.0, "zarf": "surekli", "siddet": 0.35, "parcalar": [{"f": 100, "a": 0.15}], "gurultu": 1.0, "gurultu_f": 5000, "citirti": 0.08},
                {"ad": "Atlama", "not": "tek, sert bir patlama", "sure": 0.5, "zarf": "darbe", "siddet": 1.0, "parcalar": [{"f": 90, "a": 0.6}, {"f": 180, "a": 0.4}], "gurultu": 1.0, "gurultu_f": 1500}],
        "anlatim": [
            "Havada her zaman birkaç serbest elektron vardır. Alan yeterince güçlüyse elektron bir sonraki çarpışmaya kadar atomdan elektron koparacak kadar hızlanır; her çarpışma elektron sayısını katlar. Bu çığ karşı elektroda ulaştığında aralık iletken olur.",
            f"Deniz düzeyinde, düzgün alanda bu sınır santimetre başına yaklaşık 30 kV'tur (tepe). Hava seyrekse elektronlar daha uzun yol alır ve daha kolay hızlanır: δ = {fnum(delta, 2)} iken dayanım aynı oranda düşer.",
            ("Sivri uçta alan çizgileri sıkışır: ortalama alan düşükken uçtaki alan sınırı aşar. Uçta sürekli bir iyonlaşma (korona) başlar; gerilim artınca boşalma kanalı karşı elektroda uzanır. Uzun aralıklarda sivri uç, düzgün alanın altıda biri kadar gerilimde atlatır."
             if bicim == "cubuk" else "Kenarları yuvarlatılmış elektrotlar arasında alan her yerde hemen hemen aynıdır: aralığın tamamı aynı anda sınıra gelir. Bu yüzden baralar, ekran halkaları ve kablo başlıkları yuvarlak yapılır."),
            f"Bu aralıkta atlama gerilimi {fnum(u_at, 0)} kV; işletme gerilimine göre pay {fnum(pay, 1)} kat. İşletme geriliminde dayanmak yetmez: yıldırım darbesi ({li} kV-tepe) ve anahtarlama aşırı gerilimi açıklığı belirler.",
            "Atlama bir kez olduğunda hava iyonlaşmıştır: ark, şebekenin kısa devre akımıyla beslenir ve koruma açana kadar sürer. Açıklık havadır, kendini onarır; ama ark yanındaki yalıtkanı ve metali yakar.",
        ],
        "dersler": [
            "Düzgün alanda hava ≈ 30 kV/cm (tepe) dayanır; sivri uçta ortalama 5 kV/cm bile yetmez.",
            "Açıklığı işletme gerilimi değil yıldırım darbe dayanımı belirler: 36 kV'ta 320 mm.",
            "1000 m'nin üstünde her 100 m için açıklık %1 artırılır.",
            "Korona (cızırtı, ozon kokusu, karanlıkta mor ışıma) atlamanın habercisidir.",
            "Yoğuşma ve toz, temiz hava aralığını kirli yüzeye çevirir: dayanım yarının altına iner.",
        ],
        "tablolar": [{"baslik": "Gerilim düzeyine göre yalıtım düzeyi ve en küçük hava açıklığı", "cols": ["Um", "Yıldırım darbe dayanımı", "50 Hz dayanımı (1 dk)", "En küçük hava açıklığı", "Ark boynuzu aralığı"],
                      "rows": [[f"{str(k).replace('.', ',')} kV", f"{v[0]} kV-tepe", f"{v[1]} kV", f"{v[2]} mm" if v[2] else "—", f"{v[3]} mm"] for k, v in UM.items()],
                      "not": "Yalıtım düzeyleri TEDAŞ şartnamelerindeki değerlerdir (7,2 / 12 / 17,5 / 36 kV); açıklıklar Siemens GEAFOL kılavuzu böl. 6.7, ark boynuzu aralıkları SGB-SMIT kılavuzu böl. 3.6."}],
    }
