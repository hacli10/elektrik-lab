"""Trafonun yük altında gerilimi: kısa devre empedansında düşen gerilim, yükün güç katsayısına göre AG uç gerilimi, kapasitif yükte gerilim yükselmesi.

Model: trafo seri empedanstır (ur + j·ux, birim değer); mıknatıslanma kolu ihmal edilir. U2 = U1 − I·(ur + j·ux) fazörle çözülür; yaklaşık bağıntı
ε ≈ K·(ur·cosφ + ux·sinφ) + K²·(ux·cosφ − ur·sinφ)²/200 ile karşılaştırılır. ur yük kaybından (Pk/Sn), ux uk'dan bulunur (TEDAŞ şartname değerleri)."""
from __future__ import annotations

import cmath
import math

from .ortak import A, C, G, K, S, T, TEMEL, Cizim, ctl, fazor, fnum, num, opt, pts, tr_al, tr_ctl, tr_girdi

ID = "trafo_yuk"
BASLIK = "Yük altında gerilim"
IKON = "📉"
GIRIS = ("Trafo yüklendikçe AG uçlarındaki gerilim düşer; ne kadar düşeceğini yük akımı kadar yükün güç katsayısı belirler. Kondansatör fazla kalırsa gerilim düşmez, "
         "yükselir. Yükü ve güç katsayısını değiştirin; fazör diyagramında gerilimin nasıl kaydığını izleyin.")

KONTROLLER = tr_ctl() + [
    ctl("yuk", "Yük", "sayi", 80, min=0, max=150, adim=5, birim="%"),
    ctl("cos", "Güç katsayısı", "sayi", 0.85, min=0.2, max=1.0, adim=0.01),
    ctl("tur", "Yükün türü", "sec", "ind", secenek=opt(("ind", "Endüktif (motor, bobin)"), ("kap", "Kapasitif (fazla kompanzasyon, boşta uzun kablo)"))),
    ctl("u1", "YG gerilimi (kademe geriliminin yüzdesi)", "sayi", 100, min=90, max=110, adim=0.5, birim="%", yardim="Şebeke gerilimi seçili kademe gerilimine eşitse %100"),
]


def u2(tr: dict, k: float, cosf: float, kap: bool, u1: float = 1.0) -> complex:
    """AG uç gerilimi (pu, akım referans alınmadan: U1 gerçek eksende). Sabit akımlı yük: I = k·∠(∓φ) U2'ye göre; iki adımda yakınsar."""
    z = complex(tr["ur"], tr["ux"]) / 100
    fi = math.acos(min(max(cosf, 0.0), 1.0)) * (1 if kap else -1)
    v = complex(u1)
    for _ in range(12):
        i = k * cmath.rect(1, cmath.phase(v) + fi)
        v = u1 - i * z
    return v


def run(p: dict) -> dict:
    tr = tr_al(p)
    k, cosf, kap, u1 = num(p, "yuk", 80) / 100, num(p, "cos", 0.85), p.get("tur") == "kap", num(p, "u1", 100) / 100
    v = u2(tr, k, cosf, kap, u1)
    sinf = math.sqrt(max(1 - cosf * cosf, 0)) * (-1 if kap else 1)
    eps = k * (tr["ur"] * cosf + tr["ux"] * sinf) + k * k * (tr["ux"] * cosf - tr["ur"] * sinf) ** 2 / 200
    du = (u1 - abs(v)) * 100
    u_ff = abs(v) * 400; u_fn = u_ff / math.sqrt(3)
    fi = math.acos(cosf) * (1 if kap else -1)
    i = k * cmath.rect(1, cmath.phase(v) + fi)
    z = complex(tr["ur"], tr["ux"]) / 100
    yukseliyor = du < -0.05

    c = Cizim(900, 250)
    c.kutu(20, 60, 130, 54, "Şebeke", f"{fnum(u1 * tr['un'], 2)} kV")
    c.hat("M150,87 H300", "L1", hot=k > 0, w=3)
    c.daire(322, 87, 22, "cizgi"); c.daire(350, 87, 22, "cizgi")
    c.yazi(336, 50, f"{fnum(tr['sn'], 0)} kVA · uk %{fnum(tr['uk'], 1)}", "#475569", 10.5, anchor="middle")
    c.hat("M372,87 H430", "L1", hot=k > 0, w=3)
    c.direnc(430, 87, f"ur %{fnum(tr['ur'], 2)}", yatay=True, h=40, hot=k > 0)
    c.hat("M470,87 H500", "L1", hot=k > 0, w=3)
    c.bobin(500, 87, 4, yatay=True, ad=f"ux %{fnum(tr['ux'], 2)}")
    c.hat("M540,87 H700", "L1", hot=k > 0, w=3)
    c.kutu(700, 60, 180, 54, "Yük", f"%{fnum(k * 100, 0)} · cosφ {fnum(cosf, 2)} {'kap.' if kap else 'end.'}")
    c.cihaz(560, 130, f"{fnum(u_ff, 1)} V", "AG faz arası gerilim", ok=0.9 * 400 <= u_ff <= 1.1 * 400)
    c.yazi(30, 160, f"Trafonun içinde düşen: %{fnum(du, 2)}" if not yukseliyor else f"Gerilim YÜKSELİYOR: %{fnum(-du, 2)}", "#b91c1c" if abs(du) > 5 else "#15803d" if not yukseliyor else "#b45309", 13, kalin=True)
    c.yazi(30, 182, f"Faz–nötr {fnum(u_fn, 1)} V · akım {fnum(k * tr['i2'], 0)} A", "#334155", 11.5)
    c.yazi(30, 204, "Endüktif yükte akım geride: ux'teki düşüm gerilimi doğrudan azaltır." if not kap else "Kapasitif yükte akım ileride: ux'teki düşüm gerilime eklenir.", "#334155", 11.5)
    c.yazi(30, 226, "Dirençli yükte (cosφ = 1) düşümü ur belirler; ux yalnız açıyı kaydırır.", "#64748b", 11)
    fz = {"baslik": "Fazör diyagramı (birim değer)", "vektorler": [fazor("U1", complex(u1), "#1a4d8f"), fazor("U2", v, "#15803d"), fazor("I·ur", i * z.real, "#dc2626", bas=v),
                                                                  fazor("I·ux", i * complex(0, z.imag), "#b45309", bas=v + i * z.real), fazor("I", i * 0.5, "#6b7280", True)],
          "not": "I vektörü yarı ölçekte çizilmiştir. U1 = U2 + I·ur + j·I·ux"}

    ozet = [
        K("AG uç gerilimi", f"{fnum(u_ff, 1)} V", "ok" if 380 <= u_ff <= 420 else "warn", f"faz–nötr {fnum(u_fn, 1)} V"),
        K("Gerilim değişimi", f"+%{fnum(-du, 2)}" if yukseliyor else f"−%{fnum(du, 2)}", "warn" if abs(du) > 5 or yukseliyor else "ok", "trafonun içinde" + (" — yükselme" if yukseliyor else "")),
        K("Dirençli bileşen ur", f"%{fnum(tr['ur'], 2)}", "info", f"Pk / Sn = {fnum(tr['pk'], 0)} W / {fnum(tr['sn'], 0)} kVA"),
        K("Reaktif bileşen ux", f"%{fnum(tr['ux'], 2)}", "info", "√(uk² − ur²)"),
        K("Yaklaşık bağıntı", ("+%" if eps < 0 else "−%") + fnum(abs(eps), 2), "info", "K·(ur·cosφ + ux·sinφ) + …"),
    ]
    kontroller = [
        C("AG gerilimi anma değerine yakın mı?", f"{fnum(u_ff, 1)} V", "400 V ± %5 (trafo uçlarında)", abs(u_ff - 400) <= 20, "Tüketicide ±%10 sınırı vardır; düşümün bir kısmı AG hattına ayrılır. Uçlarda %5'ten fazla sapma kademe ya da kompanzasyon ayarı ister", "ikincil"),
        C("Gerilim yükseliyor mu?", "evet" if yukseliyor else "hayır", "kapasitif yükte beklenir", None if not yukseliyor else False if u_ff > 420 else None,
          "Akım gerilimin önündeyse reaktansta düşen gerilim kaynağa eklenir: gece kondansatörler devrede kalırsa AG gerilimi yükselir", "hesap"),
        C("Yük anma gücünü aşıyor mu?", f"%{fnum(k * 100, 0)}", "≤ %100", k <= 1.0 + 1e-9, "Anma akımının üstünde düşüm de kayıp da hızla artar — " + tr["kaynak"], "resmi"),
        C("Fazör çözümü ile yaklaşık bağıntı", f"%{fnum(du / u1 if u1 else du, 2)} / %{fnum(eps, 2)}", "fark < 0,3 puan", abs(du / u1 - eps) < 0.3 if u1 else None, "Yaklaşık bağıntı U1 = 1 pu ve küçük açı kabulüyle türetilir", "hesap"),
    ]
    girdiler = tr_girdi(tr) + [
        G("Yük akımı ve güç katsayısı", f"{fnum(k * tr['i2'], 0)} A · cosφ {fnum(cosf, 2)} {'kapasitif' if kap else 'endüktif'}", "AG ana pano analizörü", "Düşümü akımın büyüklüğü kadar açısı belirler", "I = K · I2n"),
        G("YG gerilimi ve kademe", f"kademe geriliminin %{fnum(u1 * 100, 1)}'i", "OG hücresindeki gerilim ölçüsü; kademe göstergesi", "Boştaki AG gerilimi buradan başlar; yük düşümü bunun üstüne biner", "U2(boşta) = 400 V × U1/U(kademe)"),
    ]
    adimlar = [
        A("Dirençli bileşen", "ur = Pk / Sn", f"{fnum(tr['pk'], 0)} / {fnum(tr['sn'] * 1000, 0)}", f"%{fnum(tr['ur'], 2)}", "yük kaybı anma akımında sargı direncinde harcanır", "hesap", ["Kayıplar"]),
        A("Reaktif bileşen", "ux = √(uk² − ur²)", f"√({fnum(tr['uk'], 1)}² − {fnum(tr['ur'], 2)}²)", f"%{fnum(tr['ux'], 2)}", "kısa devre empedansının üçgeni", "hesap", ["Trafo etiketi"]),
        A("Fazör çözümü", "U2 = U1 − I·(ur + j·ux)", f"I = {fnum(k, 2)} ∠ {fnum(math.degrees(fi), 0)}° (U2'ye göre)", f"|U2| = {fnum(abs(v), 4)} pu = {fnum(u_ff, 1)} V", TEMEL, "hesap", ["Yük akımı ve güç katsayısı"]),
        A("Yaklaşık bağıntı", "ε = K·(ur·cosφ + ux·sinφ) + K²·(ux·cosφ − ur·sinφ)² / 200", f"{fnum(k, 2)} × ({fnum(tr['ur'], 2)} × {fnum(cosf, 2)} + {fnum(tr['ux'], 2)} × {fnum(sinf, 2)}) + …", f"%{fnum(eps, 2)}", "fazör diyagramının izdüşümü", "hesap"),
    ]
    ayarlar = [
        S("Enerjisiz kademe değiştirici", "sürekli düşük / yüksek gerilimde bir kademe", "±2 × %2,5 (33 kV'ta 28,5…36 kV)", "Yük düşümünü değil, şebeke geriliminin kalıcı sapmasını düzeltir", tr["kaynak"] + " böl. 2.2.5"),
        S("Kompanzasyon rölesi (cosφ hedefi)", "0,95–1,00 endüktif", "—", "Kapasitif bölgeye geçilmemeli: gerilim yükselir, reaktif ceza doğar", "saha pratiği", "ikincil"),
        S("AG gerilim izleme (aşırı / düşük gerilim rölesi)", "±%10", "—", "Uç geriliminin sınır dışına çıktığını bildirir", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Boşta gerilim", "Yük yokken AG faz arası gerilim", f"≈ {fnum(u1 * 400, 0)} V", "kademe ve şebeke gerilimine bağlı"),
        T("Yükte gerilim", "Aynı noktada, yük varken", f"≈ {fnum(u_ff, 0)} V (fark %{fnum(abs(du), 1)})", "ölçüm trafo AG uçlarında / ana baradan"),
        T("Gece ölçümü", "Yük azken kondansatör kademeleri devrede mi?", "Gerilim gündüzden yüksekse fazla kompanzasyon vardır", "analizörde cosφ kapasitif görünür"),
    ]
    ks = [j / 20 for j in range(0, 31)]
    g1 = {"baslik": "AG gerilimi – yük (güç katsayısına göre)", "x_ad": "Yük (% Sn)", "y_ad": "AG faz arası gerilim (V)",
          "seriler": [{"ad": ad, "renk": r, "pts": pts([x * 100 for x in ks], [abs(u2(tr, x, cf, kp, u1)) * 400 for x in ks], 2)}
                      for ad, r, cf, kp in (("cosφ 1,0", "#15803d", 1.0, False), ("cosφ 0,8 endüktif", "#dc2626", 0.8, False), ("cosφ 0,8 kapasitif", "#1a4d8f", 0.8, True), ("seçilen", "#111827", cosf, kap))],
          "isaretler": [{"x": k * 100, "etiket": "yük"}], "yatay": [{"y": 400, "etiket": "400 V", "renk": "#94a3b8"}]}
    cs = [j / 50 for j in range(10, 51)]
    g2 = {"baslik": f"Gerilim değişimi – güç katsayısı (yük %{fnum(k * 100, 0)})", "x_ad": "cosφ", "y_ad": "Gerilim değişimi (%)",
          "seriler": [{"ad": "endüktif", "renk": "#dc2626", "pts": pts(cs, [(u1 - abs(u2(tr, k, x, False, u1))) * 100 for x in cs], 3)},
                      {"ad": "kapasitif", "renk": "#1a4d8f", "pts": pts(cs, [(u1 - abs(u2(tr, k, x, True, u1))) * 100 for x in cs], 3)}],
          "yatay": [{"y": 0, "etiket": "değişim yok", "renk": "#94a3b8"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(fazor=fz), "grafikler": [g1, g2],
        "anlatim": [
            "Trafo, yük akımına seri bir empedans gibi davranır: küçük bir direnç (sargılar) ve ondan birkaç kat büyük bir reaktans (kaçak akı). İkisinin toplamı etiketteki uk'dır.",
            f"Bu trafoda ur = %{fnum(tr['ur'], 2)}, ux = %{fnum(tr['ux'], 2)}. Güç büyüdükçe ur küçülür: büyük trafoda düşümü neredeyse yalnız reaktans belirler.",
            "Dirençteki düşüm akımla aynı yöndedir, reaktanstaki düşüm akımdan 90° ileridedir. Uç gerilimi, kaynak geriliminden bu iki vektör çıkarılarak bulunur.",
            f"Yük {'kapasitif' if kap else 'endüktif'} ve cosφ = {fnum(cosf, 2)}: " + ("akım gerilimin önünde olduğu için reaktans düşümü kaynak gerilimine eklenir, uç gerilimi kaynaktan büyük olur." if yukseliyor else "reaktans düşümünün büyük kısmı gerilimle aynı doğrultuya düşer ve uç gerilimini azaltır." if not kap else "kapasitif akım reaktans düşümünü tersine çevirir; dirençli bileşen yine de gerilimi düşürür."),
            f"Sonuç: AG uçlarında {fnum(u_ff, 1)} V. Aynı akımda cosφ = 1 olsaydı düşüm yalnız %{fnum((u1 - abs(u2(tr, k, 1.0, False, u1))) * 100, 2)} olurdu.",
        ],
        "dersler": [
            "Gerilim düşümünü akımın büyüklüğü kadar açısı belirler: kompanzasyon yalnız faturayı değil gerilimi de düzeltir.",
            "Fazla kompanzasyon gerilimi yükseltir; en çok gece, yük azken ve kademeler devrede kalmışken görülür.",
            "uk büyük trafoda (%6) düşüm daha büyük, kısa devre akımı daha küçüktür: ikisi aynı sayının iki yüzüdür.",
            "Kademe değiştirici yük düşümünü izlemez; şebeke geriliminin kalıcı sapmasını bir kez düzeltir.",
        ],
        "tablolar": [{"baslik": "Yüke ve güç katsayısına göre AG faz arası gerilim (V)", "cols": ["Yük", "cosφ 1,0", "0,9 end.", "0,8 end.", "0,6 end.", "0,9 kap."],
                      "rows": [[f"%{int(x * 100)}"] + [fnum(abs(u2(tr, x, cf, kp, u1)) * 400, 1) for cf, kp in ((1.0, False), (0.9, False), (0.8, False), (0.6, False), (0.9, True))] for x in (0.25, 0.5, 0.75, 1.0, 1.25)],
                      "not": "YG gerilimi kademe geriliminin %" + fnum(u1 * 100, 1) + "'i alınmıştır."}],
    }
