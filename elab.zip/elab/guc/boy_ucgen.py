"""Kesit – boy – koruma üçgeni: bir devrenin kesitini dört ayrı koşul belirler ve hangisinin belirleyici olduğu boyla değişir: kısa hatta akım taşıma ve kısa devre ısıl dayanımı,
orta boyda gerilim düşümü, uzun hatta açma koşulu.

Hesap «AG kablo boyu» sayfasındaki bağıntılarla yapılır (boy_ag.hal); her boy için dört koşulu ayrı ayrı sağlayan en küçük standart kesit bulunur. Sınırların dayanakları o sayfadaki
gibidir: gerilim düşümü Elektrik İç Tesisleri Yön. m.57, açma süresi Topraklamalar Yön. m.8 Çizelge-2 (resmi); akım taşıma çizelgesi ve Ib ≤ In ≤ Iz kuralı (dogrulanacak)."""
from __future__ import annotations

import math

from ..lab.core import gg_ia, gg_sure, mcb_ia, mcb_sure, ruleset
from . import fizik as F
from . import kablo as KB
from .boy_ag import IN_A, TOP, YON, hal
from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, num, opt, pts

ID = "boy_ucgen"
BASLIK = "Kesit – boy – koruma"
IKON = "🔺"
GIRIS = ("Kesiti ne belirler? Kısa bir hatta akım taşıma kapasitesi, biraz uzayınca gerilim düşümü, daha da uzayınca açma koşulu. Koruma cihazını büyütmek kesiti de büyütür. "
         "Boyu ve korumayı değiştirin; dört koşulun istediği kesitleri ve hangisinin belirleyici olduğunu izleyin.")

KONTROLLER = [
    ctl("faz", "Devre", "sec", 3, secenek=opt((3, "Üç fazlı 400 V"), (1, "Tek fazlı 230 V"))),
    ctl("tur", "Yük türü", "sec", "motor", secenek=opt(("priz", "Aydınlatma / priz (ΔU ≤ %1,5)"), ("motor", "Motor / güç devresi (ΔU ≤ %3)"))),
    ctl("i", "Yük akımı", "sayi", 50, min=1, max=300, adim=1, birim="A"),
    ctl("cos", "Güç katsayısı", "sayi", 0.85, min=0.5, max=1.0, adim=0.01),
    ctl("l", "Kablo boyu", "sayi", 120, min=1, max=600, adim=1, birim="m"),
    ctl("metal", "İletken", "sec", "cu", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum"))),
    ctl("yal", "Yalıtkan", "sec", "pvc", secenek=opt(("pvc", "PVC (70 °C)"), ("xlpe", "XLPE (90 °C)"))),
    ctl("cihaz", "Koruma cihazı", "sec", "C", secenek=opt(("B", "Otomat B"), ("C", "Otomat C / kompakt şalter (10 × In)"), ("D", "Otomat D"), ("gG", "NH sigorta gG"))),
    ctl("in_a", "Anma akımı In", "sec", 63, secenek=opt(*[(k, f"{k} A") for k in IN_A])),
    ctl("devre", "Devrenin yeri", "sec", "son", secenek=opt(("son", "Son devre (açma ≤ 0,4 s)"), ("dagitim", "Dağıtım devresi (açma ≤ 5 s)"))),
    ctl("ik", "Panonun barasında kısa devre akımı", "sayi", 10.0, min=0.5, max=50, adim=0.5, birim="kA"),
]
OLCUT = ("Akım taşıma", "Gerilim düşümü", "Açma koşulu", "Kısa devre ısıl")
RENK = ("#15803d", "#1a4d8f", "#dc2626", "#b45309")


def gereken(p: dict, l: float) -> list:
    """Dört koşulun her biri için en küçük standart kesit (mm²); sağlanamıyorsa None."""
    metal, yal, cihaz, in_a = str(p.get("metal", "cu")), str(p.get("yal", "pvc")), str(p.get("cihaz", "C")), num(p, "in_a", 63)
    gd = ruleset().ictesisler["gerilim_dusumu"]["profil_1995"]
    du_s = gd["baglanti_kutusu_tuketici_aydinlatma_priz_pct"] if p.get("tur") == "priz" else gd["baglanti_kutusu_motor_pct"]
    t_s = 0.4 if p.get("devre", "son") == "son" else 5.0
    ia = gg_ia(in_a, t_s) if cihaz == "gG" else mcb_ia(in_a, cihaz, t_s)
    k = F.k_katsayi(metal, 90.0 if yal == "xlpe" else 70.0, 250.0 if yal == "xlpe" else 160.0)
    ik0 = num(p, "ik", 10.0) * 1000
    t0 = gg_sure(in_a, ik0) if cihaz == "gG" else mcb_sure(in_a, cihaz, ik0)
    s_isil = ik0 * math.sqrt(min(t0, 5.0)) / k
    kes = [x for x in KB.KESIT if not (metal == "al" and x < 16)]
    out = [next((x for x in kes if KB.iz(x, yal, metal) >= max(in_a, num(p, "i", 50))), None)]
    out.append(next((x for x in kes if hal(dict(p, s=x), l)["du"] <= du_s), None))
    out.append(next((x for x in kes if hal(dict(p, s=x), l)["ik1"] >= ia), None))
    out.append(next((x for x in kes if x >= s_isil), None))
    return out


def run(p: dict) -> dict:
    l, i, in_a, cihaz = num(p, "l", 120), num(p, "i", 50), num(p, "in_a", 63), str(p.get("cihaz", "C"))
    g = gereken(p, l)
    eksik = [OLCUT[j] for j, x in enumerate(g) if x is None]
    s_sec = max((x for x in g if x is not None), default=None) if not eksik else None
    j_bel = max(range(4), key=lambda j: g[j] if g[j] is not None else 1e9)
    cihaz_ad = f"NH gG {in_a:g} A" if cihaz == "gG" else f"otomat {cihaz}{in_a:g}"
    c = Cizim(900, 290)
    c.yazi(40, 40, f"{fnum(i, 0)} A · {fnum(l, 0)} m · {cihaz_ad}", "#334155", 13.5, kalin=True)
    for j in range(4):
        y = 70 + j * 42
        w = 0 if g[j] is None else 40 + 46 * math.log2(max(g[j], 1.5) / 1.5)
        c.dikdortgen(220, y, max(w, 6) if g[j] is not None else 500, 26, "ariza" if g[j] is None else "cizgi", RENK[j] if g[j] is not None else "#fee2e2", kw=1, r=3)
        c.yazi(210, y + 18, OLCUT[j], "#334155", 12, kalin=j == j_bel, anchor="end")
        c.yazi(230 + (max(w, 6) if g[j] is not None else 0), y + 18, (f"{str(g[j]).replace('.', ',')} mm²" if g[j] is not None else "300 mm² bile yetmiyor") + ("  ◀ belirleyici" if j == j_bel and g[j] is not None else ""), "#b91c1c" if g[j] is None or j == j_bel else "#334155", 12, kalin=j == j_bel)
    c.yazi(40, 262, (f"Seçilecek kesit: {str(s_sec).replace('.', ',')} mm² — belirleyen {OLCUT[j_bel].lower()}" if s_sec else "Bu koruma ve boyla kesit bulunamıyor: " + ", ".join(eksik).lower() + " sağlanamıyor"), "#1a4d8f" if s_sec else "#b91c1c", 13.5, kalin=True)
    ozet = [K(OLCUT[j], f"{str(g[j]).replace('.', ',')} mm²" if g[j] is not None else "sağlanamıyor", "bad" if g[j] is None else "warn" if j == j_bel else "ok", "belirleyici" if j == j_bel else "") for j in range(4)]
    ozet.append(K("Seçilecek kesit", f"{str(s_sec).replace('.', ',')} mm²" if s_sec else "yok", "ok" if s_sec else "bad", f"belirleyen: {OLCUT[j_bel].lower()}"))
    kontroller = [
        C("Dört koşul birlikte sağlanabiliyor mu?", "evet" if s_sec else "hayır: " + ", ".join(eksik).lower(), "standart kesitlerden biriyle", bool(s_sec), "Sağlanamıyorsa çare kesit değil korumadır: daha düşük manyetik eşik, artık akım koruması ya da devreyi bölmek", "hesap"),
        C("Akım taşıma", f"{str(g[0]).replace('.', ',')} mm²" if g[0] else "—", f"Iz ≥ In = {in_a:g} A", g[0] is not None, "Ib ≤ In ≤ Iz (TS HD 60364-4-43 — asıl metinle doğrulanacak); kesiti yük değil koruma cihazının anma akımı belirler", "dogrulanacak"),
        C("Gerilim düşümü", f"{str(g[1]).replace('.', ',')} mm²" if g[1] else "—", "%1,5 / %3", g[1] is not None, YON + " a.3", "resmi"),
        C("Açma koşulu", f"{str(g[2]).replace('.', ',')} mm²" if g[2] else "—", "Zs · Ia ≤ Uo", g[2] is not None, TOP, "resmi"),
        C("Kısa devre ısıl dayanımı", f"{str(g[3]).replace('.', ',')} mm²" if g[3] else "—", "I²t ≤ k²S² (pano çıkışındaki arıza)", g[3] is not None, "Koruma cihazının açma süresi boyunca kablo sınır sıcaklığını aşmamalı — «Kısa devrede ısı» sayfası", "hesap"),
    ]
    girdiler = [
        G("Yük ve koruma", f"{fnum(i, 0)} A · {cihaz_ad}", "Yük listesi, pano şeması", "Akım taşıma koşulu koruma cihazının anma akımına göre aranır", "Ib ≤ In ≤ Iz"),
        G("Boy", f"{fnum(l, 0)} m", "Güzergâh ölçüsü", "Gerilim düşümü ve açma koşulu boyla doğru orantılı kötüleşir", "ΔU ∝ L · Zs ∝ L"),
        G("Kaynak kısa devre akımı", f"{fnum(num(p, 'ik', 10.0), 1)} kA", "Kısa devre hesabı", "Isıl dayanımı pano çıkışındaki en büyük akım, açma koşulunu hat sonundaki en küçük akım belirler", "iki uç, iki ayrı denetim"),
    ]
    adimlar = [A(OLCUT[j], ("Iz ≥ In", "ΔU(L, S) ≤ sınır", "Uo / Zs(L, S) ≥ Ia", "S ≥ Ik · √t / k")[j], ("çizelgeden", f"L = {fnum(l, 0)} m", f"L = {fnum(l, 0)} m", f"Ik = {fnum(num(p, 'ik', 10.0), 1)} kA")[j],
                 f"{str(g[j]).replace('.', ',')} mm²" if g[j] is not None else "sağlanamıyor", ("akım taşıma çizelgesi — doğrulanacak", YON, TOP, "adyabatik ısınma")[j], ("dogrulanacak", "resmi", "resmi", "hesap")[j]) for j in range(4)]
    ls = [5, 10, 15, 20, 30, 40, 50, 60, 80, 100, 120, 150, 180, 220, 260, 300, 350, 400, 500, 600]
    eg = [gereken(p, x) for x in ls]
    g1 = {"baslik": "Boya göre her koşulun istediği kesit", "x_ad": "Kablo boyu (m)", "y_ad": "Kesit (mm²)", "logx": True, "logy": True,
          "seriler": [{"ad": OLCUT[j], "renk": RENK[j], "pts": pts([x for x, e in zip(ls, eg) if e[j] is not None], [e[j] for e in eg if e[j] is not None], 1)} for j in range(4)], "isaretler": [{"x": l, "etiket": "boy"}]}
    satir = [[f"{x} m", *[(f"{str(e[j]).replace('.', ',')}" if e[j] is not None else "—") for j in range(4)],
              (f"{str(max(e)).replace('.', ',')} mm² ({OLCUT[max(range(4), key=lambda j: e[j])].lower()})" if all(v is not None for v in e) else "sağlanamıyor")] for x, e in zip(ls, eg) if x in (10, 20, 40, 60, 100, 150, 220, 300, 400, 600)]
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "sahne": c.sahne(), "grafikler": [g1],
        "ayarlar": [S("Koruma cihazının anma akımı", f"{in_a:g} A", "yük akımının hemen üstündeki değer", "Gereğinden büyük cihaz, gereğinden büyük kablo ister", "Ib ≤ In ≤ Iz", "dogrulanacak"),
                    S("Manyetik eşik", "B: 5 × In · C: 10 × In · D: 20 × In · ayarlanabilir açtırıcı", "—", "Uzun hatta açma koşulunu eşik belirler", "TS EN 60898-1 (asıl metinle doğrulanacak)", "dogrulanacak"),
                    S("Artık akım koruması", "açma koşulunu boydan bağımsız kılar", "30 / 300 mA", "Kesit yalnız gerilim düşümüne göre seçilir", TOP)],
        "test": [T("Hat sonu çevrim empedansı", "Devreye alma ölçüsü", "Ik(ölçülen) ≥ Ia", "hesapla seçilen kesitin sahadaki doğrulaması")],
        "anlatim": [
            "Bir devrenin kesitini tek bir hesap belirlemez; dört ayrı koşul vardır ve en büyük kesiti isteyen kazanır.",
            f"Akım taşıma: kablo, koruma cihazının anma akımını ({in_a:g} A) sürekli taşıyabilmelidir. Bu koşul boydan bağımsızdır ve kısa hatlarda belirleyicidir: {str(g[0]).replace('.', ',') if g[0] else '—'} mm².",
            f"Gerilim düşümü: boy uzadıkça kesit orantılı büyür. {fnum(l, 0)} m için {str(g[1]).replace('.', ',') if g[1] else '300 üstü'} mm².",
            f"Açma koşulu: hat sonundaki arıza akımı koruma cihazını süresinde açtırmalıdır. Uzun hatta ve yüksek manyetik eşikli cihazda (C, D eğrisi) bu koşul öne geçer: {str(g[2]).replace('.', ',') if g[2] else '300 mm² bile yetmiyor'}" + (" mm²." if g[2] else "."),
            f"Kısa devre ısıl dayanımı: pano çıkışındaki en büyük arıza akımında, cihaz açana kadar kablo sınır sıcaklığını aşmamalıdır. Küçük kesitli çıkışlarda ve büyük kısa devre akımında belirleyicidir: {str(g[3]).replace('.', ',') if g[3] else '—'} mm².",
            (f"Sonuç: {str(s_sec).replace('.', ',')} mm², belirleyen {OLCUT[j_bel].lower()}." if s_sec else "Bu koşullarda kesit büyüterek çözüm bulunamıyor: koruma değişmelidir.") + " Koruma cihazını bir boy büyütmek üç koşulu birden ağırlaştırır.",
        ],
        "dersler": ["Kısa hat: akım taşıma. Orta boy: gerilim düşümü. Uzun hat: açma koşulu.", "Kesiti yük değil koruma cihazının anma akımı ve eğrisi belirler.",
                    "Açma koşulu sağlanamıyorsa kesiti değil korumayı değiştirin: B eğrisi, ayarlı açtırıcı, RCD.", "Isıl dayanım pano çıkışında, açma koşulu hat sonunda denetlenir: biri en büyük, öbürü en küçük akımdır."],
        "tablolar": [{"baslik": "Boya göre gereken kesitler (mm²)", "cols": ["Boy", "Akım taşıma", "Gerilim düşümü", "Açma koşulu", "Kısa devre ısıl", "Seçilecek (belirleyen)"], "rows": satir}],
    }
