"""Gerilim dengesizliğinin motora etkisi: küçük bir gerilim dengesizliği büyük bir akım dengesizliğine, rotor ısınmasına ve güç düşürmeye yol açar.

Model: motor_model — pozitif bileşen gerilimi V1 = 1, negatif bileşen V2 = dengesizlik. Negatif bileşende motor kilitli rotor empedansı gösterir:
I2/In ≈ (V2/V1) × (Ik/In). Güç düşürme eğrisi (NEMA MG 1: %1 → 1,00 · %2 → 0,95 · %3 → 0,88 · %4 → 0,82 · %5 → 0,75) ve «sıcaklık artışı ≈ 2 × (dengesizlik %)²»
kuralı bellekten yazılmıştır (dogrulanacak / ikincil)."""
from __future__ import annotations

import cmath
import math

from . import motor_model as M
from .asenkron import GUCLER, anma_akim
from .ortak import A, C, G, K, RENK3, S, T, TEMEL, Cizim, ctl, fa, fazor, fnum, interp, num, opt, pts

ID = "motor_dengesiz"
BASLIK = "Gerilim dengesizliği ve motor"
IKON = "📊"
GIRIS = ("Üç fazın gerilimleri birkaç volt farklıysa motor bunu çok daha büyük bir akım farkı olarak yaşar: %2 gerilim dengesizliği %12 akım dengesizliği demektir. "
         "Fazlalık rotoru ısıtır ve motorun taşıyabileceği gücü düşürür. Dengesizliği ve yükü değiştirip izleyin.")
NEMA = [(0, 1.0), (1, 1.0), (2, 0.95), (3, 0.88), (4, 0.82), (5, 0.75)]

KONTROLLER = [
    ctl("pn", "Motor gücü", "sec", 15, secenek=opt(*[(g, f"{str(g).replace('.', ',')} kW") for g in GUCLER])),
    ctl("vuf", "Gerilim dengesizliği (V2/V1)", "sayi", 2.0, min=0, max=8, adim=0.25, birim="%"),
    ctl("aci", "Negatif bileşenin açısı", "sayi", 0, min=0, max=330, adim=30, birim="°", yardim="Hangi fazın en çok akım çekeceğini belirler"),
    ctl("yuk", "Yük momenti", "sayi", 90, min=0, max=120, adim=5, birim="%"),
    ctl("u", "Ortalama gerilim", "sayi", 100, min=85, max=110, adim=1, birim="%"),
]


def run(p: dict) -> dict:
    pn, vuf, aci, yuk, u = num(p, "pn", 15), num(p, "vuf", 2.0) / 100, num(p, "aci", 0), num(p, "yuk", 90) / 100, num(p, "u", 100) / 100
    par = M.UC; a0 = M.anma(par); an = anma_akim(pn); amper = an["i"] / a0["i"]
    v2 = u * vuf * cmath.rect(1, math.radians(aci))
    r = M.calisma(par, yuk, u, v2)
    r0 = M.calisma(par, yuk, u, 0j)
    i1, i2 = abs(r["i1"]) / a0["i"], abs(r["i2"]) / a0["i"]
    faz = [abs(x) / a0["i"] for x in M.faz_akimlari(r["i1"], r["i2"])]
    v_faz = [abs(x) for x in M.faz_akimlari(complex(u), v2)]
    rotor0 = M.moment(par, M.SN)["p_rotor"]
    rotor = r["p_rotor"] / rotor0; rotor_d = r0["p_rotor"] / rotor0
    stator = (r["p_stator"]) / M.moment(par, M.SN)["p_stator"]
    carp = interp(NEMA, min(vuf * 100, 5.0)) if vuf * 100 <= 5 else 0.0
    dt = 2 * (vuf * 100) ** 2
    cu_fark = (max(faz) - min(faz)) / (sum(faz) / 3) * 100 if sum(faz) else 0
    c = Cizim(900, 300)
    for j, y in enumerate((60, 100, 140)):
        c.hat(f"M30,{y} H300", f"L{j + 1}", hot=True, w=3)
        c.yazi(40, y - 7, f"{fnum(v_faz[j] * 231, 0)} V", "#334155", 11)
        c.yazi(190, y - 7, fa(faz[j] * amper, 1), "#b91c1c" if faz[j] > 1.05 else "#334155", 12.5, kalin=True, anchor="middle")
        c.yazi(260, y - 7, f"× {fnum(faz[j], 2)}", "#64748b", 10.5, anchor="middle")
    c.daire(350, 100, 50, "cizgi", w=3); c.yazi(350, 96, "M", "#334155", 22, kalin=True, anchor="middle"); c.yazi(350, 116, f"{str(pn).replace('.', ',')} kW", "#64748b", 10.5, anchor="middle")
    c.yazi(40, 40, "faz–nötr", "#64748b", 10); c.yazi(190, 40, "akım", "#64748b", 10, anchor="middle")
    c.yazi(450, 50, f"Gerilim dengesizliği %{fnum(vuf * 100, 2)}", "#334155", 13, kalin=True)
    c.yazi(450, 76, f"Akım dengesizliği (I2/I1) %{fnum(i2 / i1 * 100 if i1 else 0, 0)} — {fnum(i2 / i1 / vuf if vuf and i1 else 0, 1)} katı", "#b91c1c" if i2 / max(i1, 1e-9) > 0.1 else "#334155", 13, kalin=True)
    c.yazi(450, 100, f"En yüklü faz {fnum(max(faz), 2)} × In", "#b91c1c" if max(faz) > 1.05 else "#334155", 12.5)
    c.yazi(450, 124, f"Rotor kaybı × {fnum(rotor, 2)} (dengeli olsaydı × {fnum(rotor_d, 2)})", "#b91c1c" if rotor > 1.15 else "#334155", 12.5)
    c.yazi(450, 148, f"Ek sıcaklık artışı ≈ %{fnum(dt, 0)}", "#b91c1c" if dt > 10 else "#334155", 12.5)
    c.yazi(450, 178, ("Bu dengesizlikte motor çalıştırılmaz (> %5)" if carp == 0 else f"Motor etiket gücünün en çok %{fnum(carp * 100, 0)}'ini taşımalı"), "#b91c1c" if carp < 1 else "#15803d", 13, kalin=True)
    c.yazi(450, 208, "Negatif bileşen alanı rotora göre ters yönde,", "#64748b", 11); c.yazi(450, 224, "yaklaşık iki katı hızda döner: motor ona kilitli", "#64748b", 11); c.yazi(450, 240, "rotor gibi düşük empedans gösterir.", "#64748b", 11)
    c.yazi(30, 200, "Faz akımları eşit değil: fark %" + fnum(cu_fark, 0), "#334155", 12)
    c.yazi(30, 224, "Moment 100 Hz'te titreşir: yatak ve kaplin yorulur.", "#64748b", 11.5)
    fz = {"baslik": "Faz akımları", "vektorler": [fazor(f"L{j + 1}", x / a0["i"], RENK3[j]) for j, x in enumerate(M.faz_akimlari(r["i1"], r["i2"]))]}
    ozet = [
        K("Akım dengesizliği", f"%{fnum(i2 / i1 * 100 if i1 else 0, 0)}", "bad" if i2 / max(i1, 1e-9) > 0.1 else "ok", f"gerilim dengesizliğinin {fnum(i2 / i1 / vuf if vuf and i1 else 0, 1)} katı"),
        K("En yüklü faz", fa(max(faz) * amper, 1), "bad" if max(faz) > 1.05 else "ok", f"{fnum(max(faz), 2)} × In · en az {fnum(min(faz), 2)} × In"),
        K("Rotor kaybı", f"× {fnum(rotor, 2)}", "bad" if rotor > 1.15 else "ok", "anma yükündeki kayba göre"),
        K("Güç düşürme", "çalıştırılmaz" if carp == 0 else f"%{fnum(carp * 100, 0)}", "bad" if carp < yuk else "ok", "taşınabilen güç / etiket gücü"),
        K("Ek sıcaklık artışı", f"≈ %{fnum(dt, 0)}", "bad" if dt > 10 else "ok", "2 × (dengesizlik %)²"),
    ]
    kontroller = [
        C("Gerilim dengesizliği kabul edilebilir mi?", f"%{fnum(vuf * 100, 2)}", "≤ %1 (motor tam güçte) · ≤ %2 (şebeke)", vuf <= 0.02 + 1e-9, "Motor standartları %1'e kadar tam gücü, üstünde güç düşürmeyi öngörür; şebeke gerilim kalitesi sınırı %2'dir — madde numaraları asıl metinle doğrulanacak", "dogrulanacak"),
        C("Yük, düşürülmüş gücün altında mı?", f"yük %{fnum(yuk * 100, 0)}", ("çalıştırılmaz" if carp == 0 else f"≤ %{fnum(carp * 100, 0)}"), carp > 0 and yuk <= carp + 1e-9, "NEMA MG 1 güç düşürme eğrisi: %2 → 0,95 · %3 → 0,88 · %4 → 0,82 · %5 → 0,75; %5'in üstünde çalıştırılmaz — asıl metinle doğrulanacak", "dogrulanacak"),
        C("En yüklü faz akımı", f"{fnum(max(faz), 2)} × In", "≤ 1,05 × In", max(faz) <= 1.05, "Termik röle en yüklü fazı görür; üç fazın ortalaması değil en büyüğü belirleyicidir", "hesap"),
        C("Akım dengesizliği / gerilim dengesizliği", f"{fnum(i2 / i1 / vuf if vuf and i1 else 0, 1)} kat", "≈ Ik/In (6–8 kat)", None, "Negatif bileşen empedansı ≈ kilitli rotor empedansı: I2 ≈ V2 × (Ik/In). Kalkış akımı yüksek (verimli) motorlar dengesizliğe daha duyarlıdır", "hesap"),
    ]
    girdiler = [
        G("Üç faz gerilimi", " / ".join(f"{fnum(x * 231, 0)} V" for x in v_faz), "Motor klemensinde, yük altında, üç faz arası ve faz–nötr", "Dengesizlik motorun bağlandığı noktada ölçülür: uzun kablo, tek fazlı yükler ve gevşek bağlantı onu büyütür", "V2/V1 ≈ (en büyük sapma) / (ortalama)"),
        G("Motorun kalkış akımı oranı", "Ik/In ≈ 6", "Etiket / katalog", "Negatif bileşen akımını bu oran belirler", "I2/In ≈ (V2/V1) · (Ik/In)"),
        G("Yük", f"%{fnum(yuk * 100, 0)}", "Çalışma akımı", "Dengesizlik sabitken yük arttıkça toplam ısınma sınırı aşılır", "güç düşürme eğrisi"),
    ]
    adimlar = [
        A("Negatif bileşen gerilimi", "V2 = dengesizlik × V1", f"{fnum(vuf * 100, 2)} % × {fnum(u * 100, 0)} %", f"{fnum(abs(v2) * 100, 2)} %", "simetrili bileşenler", "hesap", ["Üç faz gerilimi"]),
        A("Negatif bileşen akımı", "I2 = V2 / Z(2 − s)", f"Z(2 − s) ≈ kilitli rotor empedansı = {fnum(abs(M.zs(par, 2 - r['s'])), 3)} pu", f"{fnum(i2, 2)} × In", "geri alana göre kayma ≈ 2", "hesap", ["Motorun kalkış akımı oranı"]),
        A("Faz akımları", "Ia = I1 + I2 · Ib = a²·I1 + a·I2 · Ic = a·I1 + a²·I2", f"I1 = {fnum(i1, 2)} · I2 = {fnum(i2, 2)}", " / ".join(fnum(x, 2) for x in faz) + " × In", TEMEL, "hesap"),
        A("Rotor kaybı", "P = I2r(ileri)²·R2 + I2r(geri)²·R2(2 − s)", "geri alan akımı rotorda ≈ 100 Hz: deri etkisiyle direnç büyür", f"× {fnum(rotor, 2)}", "iki bileşenin kayıpları toplanır", "hesap"),
        A("Güç düşürme", "NEMA eğrisinden ara değer", f"dengesizlik %{fnum(vuf * 100, 2)}", "çalıştırılmaz" if carp == 0 else f"%{fnum(carp * 100, 0)}", "bellekten — doğrulanacak", "dogrulanacak", ["Yük"]),
    ]
    ayarlar = [
        S("Motor koruma rölesi › akım dengesizliği (46)", "I2 > %10–15 In · 5–10 s", "—", "Sürekli dengesizlikte motoru ayırır ya da ihbar verir", "Röle laboratuvarı › Negatif bileşen", "ikincil"),
        S("Termik model › negatif bileşen katsayısı K", "2,25 – 4,5 – 9", "röleye göre", "Isıl modelde negatif bileşen akımı K katı ağırlıkla sayılır: Ieq² = I1² + K·I2²", "Röle laboratuvarı › Isıl model", "ikincil"),
        S("Gerilim denetim rölesi (47)", "dengesizlik > %5–8", "—", "Besleme tarafındaki dengesizliği ve faz kaybını gerilimden görür", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Gerilim dengesizliği", "Üç faz arası gerilim, motor yük altındayken", f"sapma ≤ %1 (≈ {fnum(4, 0)} V)", "dengesizlik % = en büyük sapma / ortalama × 100"),
        T("Akım dengesizliği", "Üç faz akımı", " / ".join(fa(x * amper, 1) for x in faz), "akım dengesizliği gerilim dengesizliğinin 6–8 katı çıkar"),
        T("Kaynağın bulunması", "Motorun fazlarını bir kaydırıp (L1→L2→L3→L1) akımlara yeniden bak", "yüksek akım aynı hatta kalıyorsa şebeke; motorun aynı ucunda kalıyorsa motor", "sargı arızası ile şebeke dengesizliğini ayırmanın pratik yolu"),
    ]
    vs = [k * 0.25 for k in range(0, 33)]
    eg = [M.calisma(par, yuk, u, u * x / 100) for x in vs]
    g1 = {"baslik": f"Dengesizliğe göre faz akımları (yük %{fnum(yuk * 100, 0)})", "x_ad": "Gerilim dengesizliği (%)", "y_ad": "Akım (× In)", "ymin": 0,
          "seriler": [{"ad": "en yüklü faz", "renk": "#dc2626", "pts": pts(vs, [max(abs(x) for x in M.faz_akimlari(q["i1"], q["i2"])) / a0["i"] for q in eg], 3)},
                      {"ad": "en az yüklü faz", "renk": "#1a4d8f", "pts": pts(vs, [min(abs(x) for x in M.faz_akimlari(q["i1"], q["i2"])) / a0["i"] for q in eg], 3)},
                      {"ad": "negatif bileşen I2", "renk": "#7c3aed", "kesik": True, "pts": pts(vs, [abs(q["i2"]) / a0["i"] for q in eg], 3)}],
          "yatay": [{"y": 1.0, "etiket": "In", "renk": "#94a3b8"}], "isaretler": [{"x": vuf * 100, "etiket": "şimdi"}]}
    g2 = {"baslik": "Güç düşürme ve rotor kaybı", "x_ad": "Gerilim dengesizliği (%)", "y_ad": "katsayı", "ymin": 0,
          "seriler": [{"ad": "taşınabilen güç (NEMA)", "renk": "#15803d", "pts": [[a_, b_] for a_, b_ in NEMA]}, {"ad": "rotor kaybı (× anma)", "renk": "#dc2626", "pts": pts(vs, [q["p_rotor"] / rotor0 for q in eg], 3)}],
          "isaretler": [{"x": vuf * 100, "etiket": "şimdi"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(fazor=fz), "grafikler": [g1, g2],
        "anlatim": [
            "Dengesiz üç gerilim, dengeli iki takımın toplamıdır: büyük bir ileri takım (pozitif bileşen) ve küçük bir geri takım (negatif bileşen). Motor ikisine ayrı ayrı tepki verir.",
            "Pozitif bileşene karşı motor, yüküne göre yüksek bir empedans gösterir. Negatif bileşenin alanı ise rotora göre ters yönde, yaklaşık iki katı hızda döner: rotor ona kilitliymiş gibi görünür ve empedans çok düşüktür.",
            f"Sonuç: %{fnum(vuf * 100, 2)} gerilim dengesizliği {fnum(i2, 2)} × In'lik bir negatif bileşen akımı akıtıyor. Bu akım bazı fazlarda yük akımına eklenir, bazılarında çıkar: {fnum(faz[0], 2)} / {fnum(faz[1], 2)} / {fnum(faz[2], 2)} × In.",
            "Negatif bileşen akımı faydalı moment üretmez; rotor çubuklarında 100 Hz dolayında akım dolaştırır. Bu frekansta akım çubuğun yüzeyine sıkışır, direnç ve kayıp büyür: rotor, stator akımlarının gösterdiğinden daha çok ısınır.",
            f"Bu yüzden dengesizlik arttıkça motordan alınabilecek güç düşürülür: %{fnum(vuf * 100, 2)}'de " + ("motor çalıştırılmaz." if carp == 0 else f"etiket gücünün %{fnum(carp * 100, 0)}'i."),
            "Dengesizliğin kaynağı çoğu zaman motorun dışındadır: tek fazlı yüklerin eşit dağıtılmaması, bir fazdaki gevşek bağlantı ya da yanık kontak, açık üçgen bağlı trafo, uzun ve yüklü bir hat.",
        ],
        "dersler": [
            "%1 gerilim dengesizliği ≈ %6–8 akım dengesizliği.",
            "Üç fazın ortalama akımı değil en yüklü fazın akımı ve negatif bileşen motoru yakar.",
            "Dengesizlik %2'yi geçiyorsa motor tam yüklenmez; %5'i geçiyorsa çalıştırılmaz.",
            "Akımlar dengesizse önce gerilimlere bakılır; gerilimler dengeliyse sorun motordadır.",
        ],
    }
