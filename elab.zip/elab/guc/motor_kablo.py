"""Sürücü (frekans çevirici) ile motor arasındaki uzun kablo: darbe genişlik modülasyonlu gerilimin dik kenarı kabloda yürüyen dalga gibi ilerler, motor ucunda
yansır ve gerilim tepesi ikiye katlanabilir. Kablo boyu, yükselme süresi ve süzgecin etkisi.

Model: kayıpsız hat; yayılma hızı v (tipik 150 m/µs), kablonun dalga empedansı Zc, motorun dalga empedansı Zm ≫ Zc (küçük motorda yansıma katsayısı ≈ 0,9).
Kritik boy lk = v·tr/2: bundan uzun kabloda tepe = Udc·(1 + Γ); kısa kabloda yansıma kenar bitmeden geri döner, tepe ≈ Udc·(1 + Γ·l/lk). Motor ucundaki dalga
biçimi sönümlü salınım olarak çizilir. Motor yalıtımının dayanım sınırları (standart motorda ≈ 1 kV tepe, sürücüye uygun yalıtımda ≈ 1,56 kV — IEC TS 60034-17
ve 60034-25) bellekten yazılmıştır (dogrulanacak). Hız, empedans ve sönüm değerleri tipiktir (tahmini)."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, S, T, TEMEL, Cizim, ctl, fnum, num, opt, pts

ID = "motor_kablo"
BASLIK = "Sürücü ve uzun motor kablosu"
IKON = "〰"
GIRIS = ("Sürücü motora sinüs değil, saniyede binlerce kez açılıp kapanan dik kenarlı darbeler gönderir. Kablo uzunsa her kenar motor ucunda yansır ve gerilim, ara devre geriliminin "
         "iki katına yaklaşır: sargının ilk sarımlarının yalıtımı bu darbelerle yıpranır. Kablo boyunu, yükselme süresini ve süzgeci değiştirip izleyin.")
SUZGEC = {"yok": ("Süzgeç yok", 1.0, 0.0), "reaktor": ("Çıkış reaktörü", 4.0, 0.0), "dvdt": ("dU/dt süzgeci", 10.0, 0.0), "sinus": ("Sinüs süzgeci", 0.0, 1.0)}

KONTROLLER = [
    ctl("u", "Şebeke gerilimi", "sec", 400, secenek=opt((400, "400 V"), (500, "500 V"), (690, "690 V"))),
    ctl("l", "Motor kablosunun boyu", "sayi", 60, min=2, max=400, adim=2, birim="m"),
    ctl("tr", "Darbenin yükselme süresi (sürücü çıkışında)", "sayi", 0.1, min=0.05, max=2.0, adim=0.05, birim="µs", yardim="IGBT'li sürücülerde 0,05–0,2 µs; eski ve büyük sürücülerde 0,5–1 µs"),
    ctl("pn", "Motor büyüklüğü", "sec", "kucuk", secenek=opt(("kucuk", "Küçük (< 4 kW): dalga empedansı çok yüksek"), ("orta", "Orta (4–90 kW)"), ("buyuk", "Büyük (> 90 kW)"))),
    ctl("suzgec", "Sürücü çıkışında", "sec", "yok", secenek=opt(*[(k, v[0]) for k, v in SUZGEC.items()])),
    ctl("fs", "Anahtarlama frekansı", "sayi", 4, min=1, max=16, adim=1, birim="kHz"),
    ctl("yalitim", "Motor yalıtımı", "sec", "std", secenek=opt(("std", "Standart motor"), ("guclu", "Sürücüye uygun (güçlendirilmiş) yalıtım"))),
]
V = 150.0            # m/µs
ZC = 80.0            # Ω — ekranlı motor kablosunun dalga empedansı
ZM = {"kucuk": 2000.0, "orta": 800.0, "buyuk": 300.0}


def run(p: dict) -> dict:
    u, l, tr0, boy = num(p, "u", 400), num(p, "l", 60), num(p, "tr", 0.1), str(p.get("pn", "kucuk"))
    sz = str(p.get("suzgec", "yok")); fs = num(p, "fs", 4); guclu = p.get("yalitim") == "guclu"
    udc = u * math.sqrt(2) * 1.0
    ad, kat, sinus = SUZGEC.get(sz, SUZGEC["yok"])
    tr = tr0 * kat if not sinus else 250.0                                   # sinüs süzgeci: kenar kalmaz
    gam = (ZM[boy] - ZC) / (ZM[boy] + ZC)
    lk = V * tr / 2
    oran = 1 + gam * min(l / lk, 1.0) if not sinus else 1.0
    tepe = udc * oran if not sinus else u * math.sqrt(2) / 1.0 * 1.0
    t_git = l / V                                                              # µs
    dvdt = (0.8 * tepe) / max(tr if l < lk else tr, 1e-3) / 1000 if not sinus else 2 * math.pi * 50 * u * math.sqrt(2) / 1e9          # kV/µs
    sinir = (1560.0 if guclu else 1000.0) * (u / 400 if u > 500 else 1.0)
    f_sal = 1 / (4 * t_git) if t_git > 0 else 0                              # MHz
    darbe = fs * 1000 * 2 * 3600 * 8                                           # bir vardiyada kenar sayısı (her periyotta iki kenar)
    ilk_sarim = 0.7 if tr < 0.3 else 0.4 if tr < 1 else 0.15                   # darbenin ilk bobinde kalan payı
    c = Cizim(900, 300)
    c.kutu(20, 70, 130, 60, "Sürücü", f"Udc = {fnum(udc, 0)} V")
    if sz != "yok":
        c.kutu(170, 76, 110, 48, ad, "")
    c.hat(f"M{150 if sz == 'yok' else 280},100 H640", "L1", hot=True, w=3); c.hat("M150,100 H170", "L1", hot=True, w=3) if sz != "yok" else None
    c.yazi(450, 88, f"{fnum(l, 0)} m kablo · gidiş süresi {fnum(t_git, 2)} µs", "#334155", 11.5, anchor="middle")
    c.daire(690, 100, 50, "cizgi", w=3); c.yazi(690, 108, "M", "#334155", 22, kalin=True, anchor="middle")
    c.ok(300, 120, 380, 120, "mavi", 2); c.yazi(300, 138, "giden dalga", "#1d4ed8", 10.5)
    if not sinus:
        c.ok(600, 136, 520, 136, "ariza", 2); c.yazi(520, 154, f"yansıyan dalga (× {fnum(gam, 2)})", "#b91c1c", 10.5)
    c.cihaz(760, 60, f"{fnum(tepe, 0)} V", "motor ucunda tepe", ok=tepe <= sinir)
    c.yazi(20, 190, f"Motor ucunda gerilim tepesi: {fnum(tepe, 0)} V = {fnum(oran, 2)} × Udc", "#b91c1c" if tepe > sinir else "#15803d", 13.5, kalin=True)
    c.yazi(20, 214, f"Kritik kablo boyu {fnum(lk, 1)} m — kablo bundan " + ("uzun: yansıma tam" if l >= lk else "kısa: yansıma kısmen bastırılır"), "#334155", 12)
    c.yazi(20, 236, f"Yalıtımın dayanım sınırı ≈ {fnum(sinir, 0)} V tepe ({'sürücüye uygun' if guclu else 'standart'} motor)", "#334155", 12)
    c.yazi(20, 258, f"Sekiz saatte ≈ {fnum(darbe / 1e6, 0)} milyon kenar; her kenarın ≈ %{fnum(ilk_sarim * 100, 0)}'i ilk bobinde kalır.", "#64748b", 11.5)
    c.yazi(20, 280, "Sinüs süzgeci kenarı tümüyle yok eder; dU/dt süzgeci ve reaktör kenarı yatırarak kritik boyu uzatır.", "#64748b", 11)
    ozet = [
        K("Motor ucunda tepe", f"{fnum(tepe, 0)} V", "bad" if tepe > sinir else "ok", f"{fnum(oran, 2)} × Udc · sınır ≈ {fnum(sinir, 0)} V"),
        K("Kritik kablo boyu", f"{fnum(lk, 1)} m" if not sinus else "—", "warn" if l >= lk and not sinus else "ok", "v · tr / 2"),
        K("Yansıma katsayısı", fnum(gam, 2) if not sinus else "—", "info", f"Zm ≈ {fnum(ZM[boy], 0)} Ω · Zc ≈ {fnum(ZC, 0)} Ω"),
        K("Gerilim dikliği", f"{fnum(dvdt, 1)} kV/µs" if not sinus else "sinüs", "warn" if dvdt > 1 and not sinus else "ok", f"yükselme süresi {fnum(tr, 2)} µs" if not sinus else "kenar yok"),
        K("Salınım frekansı", f"{fnum(f_sal * 1000, 0)} kHz" if not sinus else "—", "info", "1 / (4 · gidiş süresi)"),
    ]
    kontroller = [
        C("Gerilim tepesi yalıtım sınırının altında mı?", f"{fnum(tepe, 0)} V", f"≤ {fnum(sinir, 0)} V", tepe <= sinir, "Standart motor ≈ 1 kV, sürücüye uygun yalıtım ≈ 1,56 kV tepe gerilime dayanır (IEC TS 60034-17 ve 60034-25 — asıl metinle doğrulanacak)", "dogrulanacak"),
        C("Kablo kritik boyun altında mı?", f"{fnum(l, 0)} m", f"< {fnum(lk, 1)} m" if not sinus else "sinüs süzgecinde sınır yok", (l < lk) if not sinus else None, "Kenar süresi kablodaki gidiş–dönüş süresinden kısaysa yansıma tam oluşur: lk = v·tr/2", "hesap"),
        C("Gerilim dikliği", f"{fnum(dvdt, 1)} kV/µs" if not sinus else "sinüs", "standart motor için ≲ 1 kV/µs", (dvdt <= 1.0) if not sinus else None, "Dik kenarda gerilim sargıya eşit dağılmaz: büyük kısmı ilk birkaç sarımda kalır", "ikincil"),
        C("Toprak ve yatak akımları", "ekranlı kablo + iki uçta 360° ekran bağlantısı", "bilgi", None, "Dik kenarlar kablo ve sargı kapasitesi üzerinden toprağa akım akıtır; konu Topraklama laboratuvarı › Sürücü sayfasındadır", "ikincil"),
    ]
    girdiler = [
        G("Sürücünün ara devre gerilimi", f"{fnum(udc, 0)} V", "Udc ≈ √2 × şebeke gerilimi; frenlemede %15–20 yükselir", "Her darbenin yüksekliği budur", "tepe = Udc · (1 + Γ)"),
        G("Yükselme süresi", f"{fnum(tr0, 2)} µs" + (f" → süzgeçle {fnum(tr, 2)} µs" if kat != 1 and not sinus else ""), "Sürücü kataloğu (dU/dt ya da tr)", "Kritik boyu belirler: hızlı sürücüde birkaç metre bile uzundur", "lk = v · tr / 2"),
        G("Kablo boyu ve tipi", f"{fnum(l, 0)} m · v ≈ 150 m/µs · Zc ≈ 80 Ω", "Proje; kablo kataloğu", "Gidiş süresi ve dalga empedansı", "t = l / v"),
        G("Motorun büyüklüğü ve yalıtımı", f"Zm ≈ {fnum(ZM[boy], 0)} Ω · {'güçlendirilmiş' if guclu else 'standart'}", "Motor kataloğu: «sürücüyle çalışmaya uygun», izin verilen tepe gerilim", "Küçük motor dalgayı neredeyse tümüyle yansıtır", "Γ = (Zm − Zc) / (Zm + Zc)"),
    ]
    adimlar = [
        A("Ara devre gerilimi", "Udc = √2 · U", f"1,414 × {fnum(u, 0)}", f"{fnum(udc, 0)} V", "üç fazlı köprü doğrultucu, yüksüz", "hesap", ["Sürücünün ara devre gerilimi"]),
        A("Yansıma katsayısı", "Γ = (Zm − Zc) / (Zm + Zc)", f"({fnum(ZM[boy], 0)} − {fnum(ZC, 0)}) / ({fnum(ZM[boy], 0)} + {fnum(ZC, 0)})", fnum(gam, 2), "hattın ucundaki empedans süreksizliği — empedanslar tipik", "tahmini", ["Motorun büyüklüğü ve yalıtımı"]),
        A("Kritik boy", "lk = v · tr / 2", f"150 × {fnum(tr, 2)} / 2", f"{fnum(lk, 1)} m", "kenar bitmeden yansıma geri dönerse tepe küçülür", "hesap", ["Yükselme süresi", "Kablo boyu ve tipi"]),
        A("Motor ucunda tepe", "U = Udc · (1 + Γ · min(l / lk, 1))", f"{fnum(udc, 0)} × (1 + {fnum(gam, 2)} × {fnum(min(l / lk, 1.0), 2)})" if not sinus else "sinüs süzgeci: kenar yok", f"{fnum(tepe, 0)} V", "giden ve yansıyan dalga motor ucunda toplanır", "hesap"),
        A("Salınım", "f ≈ 1 / (4 · l / v)", f"gidiş süresi {fnum(t_git, 2)} µs", f"{fnum(f_sal * 1000, 0)} kHz", "çeyrek dalga rezonansı; kablo kayıplarıyla söner", "hesap"),
    ]
    ayarlar = [
        S("dU/dt süzgeci / çıkış reaktörü", "kablo kritik boydan uzunsa", "—", "Kenarı yatırır: kritik boy uzar, tepe düşer", "sürücü üreticisinin kablo boyu çizelgesi", "ikincil"),
        S("Sinüs süzgeci", "çok uzun kablo, eski motor, yükseltici trafolu tahrik", "—", "Motora sinüse yakın gerilim verir; yansıma ve yatak akımı sorunu kalmaz", "sürücü üreticisinin kılavuzu", "ikincil"),
        S("Anahtarlama frekansı", f"{fnum(fs, 0)} kHz", "1–16 kHz", "Düşük frekans kenar sayısını ve kablo kapasitif akımını azaltır; motor sesi artar", "sürücü parametresi", "ikincil"),
        S("Motor seçimi", "sürücüye uygun yalıtım; > 100 kW'ta yalıtılmış yatak", "—", "Standart motor uzun kabloda süzgeçsiz çalıştırılmaz", "motor üreticisinin sürücü kılavuzu", "ikincil"),
    ]
    test = [
        T("Motor ucunda gerilim", "Yüksek gerilim diferansiyel probu ve osiloskop, iki faz arası", f"tepe ≈ {fnum(tepe, 0)} V, salınım ≈ {fnum(f_sal * 1000, 0)} kHz", "multimetre bu tepeyi göstermez: etkin değer olağan görünür"),
        T("Sargı yalıtımı", "Darbe (surge) testi / kısmi boşalma başlangıç gerilimi", "kısmi boşalma başlangıcı tepe gerilimin üstünde", "megerle ölçülen yalıtım direnci bu yıpranmayı göstermez"),
        T("Yatak akımı", "Mil gerilimi / yatakta oluklanma izi", "mil gerilimi düşük", "büyük motorlarda ayrı konu: yalıtılmış yatak, mil topraklama fırçası"),
    ]
    ts = [k * 0.02 for k in range(0, 301)]
    tau = 6 * t_git if t_git > 0 else 1
    w = 2 * math.pi * f_sal

    def dalga(t: float) -> float:
        if sinus:
            return udc * 0.0
        kenar = min(max((t - t_git) / max(tr, 1e-3), 0.0), 1.0)                # motor ucuna varış ve yükselme
        asim = udc * (oran - 1) * math.exp(-max(t - t_git, 0) / tau) * math.cos(w * max(t - t_git - tr, 0)) if t > t_git else 0.0
        return udc * kenar + asim * kenar
    g1 = {"baslik": "Bir darbe kenarı: sürücü çıkışında ve motor ucunda", "x_ad": "Zaman (µs)", "y_ad": "Gerilim (V)", "zaman": True,
          "seriler": [{"ad": "sürücü çıkışı", "renk": "#1a4d8f", "pts": pts(ts, [udc * min(max(t / max(tr, 1e-3), 0), 1) if not sinus else 0 for t in ts], 1)},
                      {"ad": "motor ucu", "renk": "#dc2626", "pts": pts(ts, [dalga(t) for t in ts], 1)}],
          "yatay": [{"y": sinir, "etiket": "yalıtım sınırı", "renk": "#dc2626"}, {"y": udc, "etiket": "Udc", "renk": "#94a3b8"}]}
    ls = [2 * 1.12 ** k for k in range(0, 48) if 2 * 1.12 ** k <= 400]
    g2 = {"baslik": "Kablo boyuna göre motor ucundaki tepe", "x_ad": "Kablo boyu (m)", "y_ad": "Tepe gerilim (V)", "logx": True,
          "seriler": [{"ad": nm, "renk": rk, "kesik": key != sz, "pts": pts(ls, [udc * (1 + gam * min(x / (V * tr0 * kt / 2), 1.0)) if not sn else udc for x in ls], 1)}
                      for key, (nm, kt, sn), rk in zip(SUZGEC.keys(), SUZGEC.values(), ("#dc2626", "#b45309", "#1a4d8f", "#15803d"))],
          "yatay": [{"y": sinir, "etiket": "yalıtım sınırı", "renk": "#dc2626"}], "isaretler": [{"x": l, "etiket": "kablo"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"Sürücü, ara devresindeki doğru gerilimi ({fnum(udc, 0)} V) saniyede {fnum(fs * 1000, 0)} kez motora bağlayıp keser. Darbelerin genişliği sinüse göre ayarlanır; motorun sargısı akımı süzer, ama gerilim dik kenarlı kalır.",
            f"Her kenar kabloda saniyede yaklaşık 150 000 km hızla ilerleyen bir dalgadır. {fnum(l, 0)} m'lik kabloyu {fnum(t_git, 2)} µs'de geçer. Kenarın kendisi {fnum(tr, 2)} µs sürüyor: kablo, kenar için «uzun» bir hattır.",
            f"Kablonun dalga empedansı 80 Ω dolayındadır; motor sargısı yüksek frekansta çok daha büyük bir empedans gösterir. Dalga motor ucunda açık uca çarpmış gibi yansır (× {fnum(gam, 2)}) ve gelen dalganın üstüne biner.",
            (f"Kablo kritik boydan ({fnum(lk, 1)} m) uzun: yansıma tam oluşur ve motor ucunda {fnum(tepe, 0)} V görülür. Dalga iki uç arasında gidip gelirken {fnum(f_sal * 1000, 0)} kHz'lik sönümlü bir salınım oluşur." if l >= lk and not sinus else
             f"Kablo kritik boydan ({fnum(lk, 1)} m) kısa: yansıyan dalga, kenar daha yükselirken sürücüye dönüp ters işaretle geri gelir ve tepeyi sınırlar. Motor ucunda {fnum(tepe, 0)} V." if not sinus else
             "Sinüs süzgeci darbeleri süzer: motora sinüse yakın gerilim gider, yansıyacak kenar kalmaz."),
            "Dik kenarlı gerilim sargıya eşit dağılmaz: sargı uzun bir hat gibi davranır ve darbenin büyük bölümü ilk bobinin sarımları arasında kalır. Olağan çalışmada birkaç volt taşıyan sarım yalıtımı yüzlerce volt görür; hava boşluklarında kısmi boşalma başlar.",
            "Tek bir darbe yalıtımı delmez; ama günde milyarlarca darbe, her biri küçük bir boşalmayla, emaye yalıtımı aşındırır. Arıza haftalar ya da aylar sonra, sargının giriş ucuna yakın sarımlar arasında kısa devre olarak ortaya çıkar.",
        ],
        "dersler": [
            "Kritik boy = 150 m/µs × yükselme süresi / 2: hızlı sürücüde 10 m bile uzundur.",
            "Uzun kabloda motor ucundaki tepe, ara devre geriliminin iki katına yaklaşır: 400 V şebekede ≈ 1100 V.",
            "Bu yıpranmayı ne multimetre ne meger gösterir; osiloskop ve darbe testi gösterir.",
            "Çare sırası: sürücüye uygun motor → kısa kablo → dU/dt süzgeci / reaktör → sinüs süzgeci.",
            "Arızanın imzası: sargının giriş ucundaki ilk sarımlar arasında kısa devre.",
        ],
        "tablolar": [{"baslik": "Yükselme süresine göre kritik kablo boyu", "cols": ["Yükselme süresi", "Kritik boy", "Bu boyda tepe (küçük motor)"],
                      "rows": [[f"{fnum(x, 2)} µs", f"{fnum(V * x / 2, 1)} m", f"{fnum(udc * (1 + (ZM['kucuk'] - ZC) / (ZM['kucuk'] + ZC)), 0)} V"] for x in (0.05, 0.1, 0.2, 0.5, 1.0, 2.0)],
                      "not": "Yayılma hızı 150 m/µs alınmıştır (tipik); kablonun yalıtkanına göre 130–170 m/µs arasında değişir."}],
    }
