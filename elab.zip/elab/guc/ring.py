"""OG ring şebeke: iki fider aynı baradan çıkar, trafo merkezlerini dolaşır ve birleşir. Normalde bir noktası açık tutulur (açık ring); bir kablo parçası arızalanınca
arızalı parça iki ucundan ayrılır, açık nokta kapatılır ve bütün trafo merkezleri öbür yönden beslenir.

Hesap: her kablo parçasının akımı, her trafo merkezinin gerilimi, kayıp; açık noktanın yerine göre kayıp; arıza sonrası (tek fiderden besleme) akım ve gerilim düşümü.
Dayanak: gerilim düşümü sınırları (normal %7, arızalı işletme %10) TEDAŞ Elektrik Dağıtım Şebekeleri Teknik Şartnamesi böl. 2.17 (metinden). XLPE iletken sıcaklığı 90 °C:
TEDAŞ-MLZ/96-018.B. Kablo akım taşıma değerleri ve reaktansları katalog mertebesi (tahmini). Yeniden besleme süreleri (elle ≈ 60 dk, uzaktan ≈ 3 dk, kablo onarımı ≈ 8 saat)
örnek değerlerdir (tahmini)."""
from __future__ import annotations

import math

from . import kablo as KB
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, num, opt, pts

ID = "ring"
BASLIK = "Ring şebeke ve yük aktarma"
IKON = "🔁"
GIRIS = ("Radyal hatta bir kablo arızası, arızanın ötesindeki herkesi onarım bitene kadar karanlıkta bırakır. Ring şebekede her trafo merkezine iki yönden gelinebilir: arızalı parça ayrılır, "
         "açık nokta kapatılır, yük öbür fidere aktarılır. Açık noktanın yerini, arızalı parçayı ve kumanda biçimini değiştirin; kimin ne kadar süre enerjisiz kaldığını ve kalan fiderin bunu taşıyıp taşımadığını izleyin.")

SART = "TEDAŞ Elektrik Dağıtım Şebekeleri Teknik Şartnamesi böl. 2.17 (şebeke parametreleri)"
COS = 0.9
SURE = {"elle": 60.0, "uzak": 3.0}          # dk — yük aktarma
ONARIM = 8 * 60.0                             # dk — kablo arızasının onarımı

KONTROLLER = [
    ctl("un", "Şebeke gerilimi", "sec", 34.5, secenek=opt((10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("s", "Kablo kesiti (tek damarlı XLPE)", "sec", 150, secenek=opt(*[(k, f"{k} mm²") for k in KB.OG_KESIT])),
    ctl("metal", "İletken", "sec", "al", secenek=opt(("al", "Alüminyum"), ("cu", "Bakır"))),
    ctl("n", "Ringdeki trafo merkezi sayısı", "sec", 8, secenek=opt((4, "4"), (6, "6"), (8, "8"), (10, "10"))),
    ctl("st", "Her trafo merkezinin yükü", "sayi", 1000, min=100, max=2500, adim=50, birim="kVA"),
    ctl("dagilim", "Yükün dağılımı", "sec", "esit", secenek=opt(("esit", "Eşit"), ("bas", "A fiderine yakın merkezler daha yüklü"), ("son", "B fiderine yakın merkezler daha yüklü"))),
    ctl("l", "İki merkez arası kablo boyu", "sayi", 1.0, min=0.2, max=5.0, adim=0.1, birim="km"),
    ctl("isletme", "İşletme biçimi", "sec", "acik", secenek=opt(("acik", "Açık ring (bir noktası açık)"), ("kapali", "Kapalı ring — kesici yalnız fider başlarında"),
                                                                  ("kapali_dif", "Kapalı ring — her parçada kesici ve yönlü / diferansiyel koruma"), ("radyal", "Radyal (ring bağlantısı yok)"))),
    ctl("acik", "Açık nokta: kaçıncı merkezden sonra", "sayi", 4, min=0, max=10, adim=1, yardim="0: A fiderinin ilk parçası açık, bütün ring B'den beslenir"),
    ctl("ariza", "Arızalı kablo parçası (0 = arıza yok)", "sayi", 0, min=0, max=11, adim=1, yardim="1: bara ile 1. merkez arası; son parça: son merkez ile bara arası"),
    ctl("kumanda", "Ayırıcıların kumandası", "sec", "elle", secenek=opt(("elle", "Elle — ekip merkezlere gider (≈ 60 dk)"), ("uzak", "Uzaktan (SCADA, motorlu ayırıcılar; ≈ 3 dk)"))),
    ctl("an", "Gösterilen an", "sec", "sonra", secenek=opt(("once", "Arıza anı: koruma açtı"), ("sonra", "Yük aktarıldıktan sonra"))),
]


def _radyal(yuk: list, o: int, n: int, k_du: float) -> tuple:
    """Açık parça o (1 … n+1). Dönen: parça akımları [1…n+1] (A), merkez gerilim düşümleri [1…n] (%), besleyen fider [1…n]."""
    ak = [0.0] * (n + 2)
    for k in range(1, o):
        ak[k] = sum(yuk[j] for j in range(k, o))
    for k in range(o + 1, n + 2):
        ak[k] = sum(yuk[j] for j in range(o, k))
    du = [0.0] * (n + 1); fid = [""] * (n + 1)
    t = 0.0
    for j in range(1, o):
        t += ak[j] * k_du; du[j] = t; fid[j] = "A"
    t = 0.0
    for j in range(n, o - 1, -1):
        t += ak[j + 1] * k_du; du[j] = t; fid[j] = "B"
    return ak, du, fid


def _kapali(yuk: list, n: int, k_du: float) -> tuple:
    """İki ucundan beslenen hat (eşit parça boyları): parça akımları işaretli (A → B yönü artı)."""
    ia = sum(yuk[j] * (n + 1 - j) / (n + 1) for j in range(1, n + 1))
    ak = [0.0] * (n + 2); du = [0.0] * (n + 1)
    i = ia; t = 0.0
    for k in range(1, n + 2):
        ak[k] = i
        if k <= n:
            t += i * k_du; du[k] = t; i -= yuk[k]
    return ak, du, ["A+B"] * (n + 1)


def run(p: dict) -> dict:
    un, s, metal, n = num(p, "un", 34.5), num(p, "s", 150), str(p.get("metal", "al")), int(num(p, "n", 8))
    st, dag, l, isl = num(p, "st", 1000), str(p.get("dagilim", "esit")), num(p, "l", 1.0), str(p.get("isletme", "acik"))
    a = int(min(max(num(p, "acik", 4), 0), n)); f = int(min(max(num(p, "ariza", 0), 0), n + 1)); kum, an = str(p.get("kumanda", "elle")), str(p.get("an", "sonra"))
    n = n if n in (4, 6, 8, 10) else 8
    s = s if s in KB.OG_KESIT else 150
    r, x = KB.r_km(s, metal, 90.0), KB.OG_X[s]
    iz = KB.OG_IZ_CU[s] * (0.78 if metal == "al" else 1.0)
    sinf = math.sqrt(1 - COS * COS)
    k_du = math.sqrt(3) * (r * COS + x * sinf) * l / (un * 1000) * 100          # % / A (parça başına)
    agirlik = [1.0] * (n + 1)
    if dag != "esit":
        for j in range(1, n + 1):
            w = 1.6 - 1.2 * (j - 1) / (n - 1)
            agirlik[j] = w if dag == "bas" else 2.0 - w
    yuk = [0.0] + [st * agirlik[j] / (math.sqrt(3) * un) for j in range(1, n + 1)]          # A
    kva = [0.0] + [st * agirlik[j] for j in range(1, n + 1)]
    i_top = sum(yuk)
    radyal = isl == "radyal"; kapali = isl.startswith("kapali")
    o = n + 1 if radyal else a + 1
    if kapali:
        ak0, du0, fid0 = _kapali(yuk, n, k_du)
    else:
        ak0, du0, fid0 = _radyal(yuk, o, n, k_du)

    def kayip(ak):
        return sum(3 * q * q * r * l for q in ak) / 1000

    pk0 = kayip(ak0)
    # ---- arıza ----
    kesik = [False] * (n + 1); kalici = [False] * (n + 1)
    ak1, du1, fid1 = ak0, du0, fid0
    t_akt = SURE.get(kum, 60.0)
    if f > 0:
        if kapali:
            if isl == "kapali":
                kesik = [False] + [True] * n                     # iki fider de açar
            ak1, du1, fid1 = _radyal(yuk, f, n, k_du)
        elif radyal:
            for j in range(1, n + 1):
                kesik[j] = True                                   # fider başındaki kesici açar: hepsi
                kalici[j] = j >= f                                # arızanın ötesi onarıma kadar
            yk = [0.0] + [yuk[j] if j < f else 0.0 for j in range(1, n + 1)]
            ak1, du1, fid1 = _radyal(yk, n + 1, n, k_du)
            fid1 = [""] + ["A" if j < f else "—" for j in range(1, n + 1)]
        else:
            for j in range(1, n + 1):
                kesik[j] = (j < o) if f <= o else (j >= o)
            ak1, du1, fid1 = _radyal(yuk, f, n, k_du)
    pk1 = kayip(ak1)
    n_kesik = sum(kesik)
    ens = sum(kva[j] * COS * ((ONARIM if kalici[j] else t_akt) / 60.0) for j in range(1, n + 1) if kesik[j]) if f > 0 else 0.0          # kWh
    # en kötü tek arıza: bütün ring tek fiderden
    akw, duw, _ = _radyal(yuk, 1, n, k_du)
    i_n1, du_n1 = max(abs(q) for q in akw), max(duw)
    # açık noktanın yerine göre kayıp
    kay_a = [kayip(_radyal(yuk, q + 1, n, k_du)[0]) for q in range(0, n + 1)]
    a_iyi = min(range(0, n + 1), key=lambda q: kay_a[q])
    sonra = f > 0 and an == "sonra"
    ak, du, fid = (ak1, du1, fid1) if sonra else (ak0, du0, fid0)
    i_max, du_max = max(abs(q) for q in ak), max(du)
    i_max0, du_max0 = max(abs(q) for q in ak0), max(du0)
    i_max1, du_max1 = max(abs(q) for q in ak1), max(du1)
    # ---------------- şema ----------------
    cz = Cizim(900, 330)
    dx = 760.0 / (n + 1); x0 = 70.0; y = 110
    cz.dikdortgen(30, 70, 14, 80, "cizgi", "#334155"); cz.dikdortgen(856, 70, 14, 80, "cizgi", "#334155")
    cz.yazi(37, 60, "A fideri", "#334155", 10.5, kalin=True, anchor="middle"); cz.yazi(863, 60, "B fideri", "#334155", 10.5, kalin=True, anchor="middle")
    cz.yazi(450, 34, "aynı OG barası — iki fider" if not radyal else "radyal: yalnız A fideri", "#64748b", 11, anchor="middle")
    o_goster = (f if sonra else o) if not kapali else (f if sonra else 0)
    for k in range(1, n + 2):
        xa, xb = x0 + (k - 1) * dx - (26 if k == 1 else 0), x0 + k * dx + (26 if k == n + 1 else 0)
        xa = max(xa, 44); xb = min(xb, 856)
        if radyal and k == n + 1:
            continue
        acik_mi = k == o_goster
        enerjili = abs(ak[k]) > 1e-6 and not (f > 0 and not sonra and ((kapali and isl == "kapali") or (not kapali and ((k <= o) == (f <= o)))))
        if acik_mi and not (f > 0 and sonra):
            xm = (xa + xb) / 2
            cz.hat(f"M{xa:.0f},{y} H{xm - 8:.0f}", "cizgi", w=3); cz.hat(f"M{xm + 8:.0f},{y} H{xb:.0f}", "cizgi", w=3)
            cz.hat(f"M{xm - 8:.0f},{y} L{xm + 6:.0f},{y - 12}", "ariza", w=2.5)
            cz.yazi(xm, y - 18, "açık", "#b91c1c", 10, kalin=True, anchor="middle")
        elif f == k and f > 0:
            xm = (xa + xb) / 2
            cz.hat(f"M{xa:.0f},{y} H{xb:.0f}", "soluk", w=3, kesik=True)
            cz.simsek(xm, y - 22, 0.9)
            cz.yazi(xm, y + 22, "ayrıldı" if sonra else "arıza", "#b91c1c", 10, kalin=True, anchor="middle")
        else:
            cz.hat(f"M{xa:.0f},{y} H{xb:.0f}", "L1", hot=enerjili, w=3)
            cz.yazi((xa + xb) / 2, y - 8, f"{fnum(abs(ak[k]), 0)} A" if enerjili else "", "#b91c1c" if abs(ak[k]) > iz else "#334155", 9.5, anchor="middle")
    for j in range(1, n + 1):
        xx = x0 + j * dx
        yok = kesik[j] and (not sonra or kalici[j])
        cz.dikdortgen(xx - 15, y - 13, 30, 26, "ariza" if yok else "cizgi", "#fee2e2" if yok else "#ecfdf5", r=3)
        cz.yazi(xx, y + 4, str(j), "#b91c1c" if yok else "#065f46", 11, kalin=True, anchor="middle")
        cz.yazi(xx, y + 34, "enerjisiz" if yok else f"−%{fnum(du[j], 2)}", "#b91c1c" if yok else "#64748b", 9, anchor="middle")
        cz.yazi(xx, y + 48, "" if yok else fid[j], "#94a3b8", 9, anchor="middle")
    durum = "Olağan işletme" if f == 0 else ("Arıza anı: koruma açtı" if not sonra else "Arızalı parça ayrıldı" if radyal else "Yük aktarıldı")
    cz.yazi(40, 196, f"{durum} — en yüklü parça {fnum(i_max, 0)} A (kablo ≈ {fnum(iz, 0)} A), en büyük gerilim düşümü %{fnum(du_max, 2)}", "#b91c1c" if i_max > iz else "#15803d", 12.5, kalin=True)
    if f == 0:
        cz.yazi(40, 220, (f"Kayıp {fnum(pk0, 1)} kW · açık nokta {a}. merkezden sonra (en az kayıp: {a_iyi}. merkezden sonra, {fnum(kay_a[a_iyi], 1)} kW)" if not kapali and not radyal
                          else f"Kayıp {fnum(pk0, 1)} kW" + (" · akım iki yönden paylaşılır" if kapali else " · bütün yük tek fiderde")), "#334155", 12)
        cz.yazi(40, 244, f"En kötü tek arıza: bütün ring tek fiderden — {fnum(i_n1, 0)} A, gerilim düşümü %{fnum(du_n1, 2)}", "#b91c1c" if i_n1 > iz or du_n1 > 10 else "#64748b", 12)
        cz.yazi(40, 268, "Bir kablo parçası seçin: kimin enerjisiz kaldığını ve yükün nasıl aktarıldığını görün", "#64748b", 11.5)
    else:
        cz.yazi(40, 220, f"{f}. parçada arıza: {n_kesik} merkez enerjisiz kaldı" + (f" · {sum(kalici)} merkez onarıma kadar bekler" if radyal else f" · {fnum(t_akt, 0)} dk sonra hepsi yeniden beslenir" if n_kesik else ""),
                "#b91c1c" if n_kesik else "#15803d", 12.5, kalin=True)
        cz.yazi(40, 244, f"Verilemeyen enerji ≈ {fnum(ens, 0)} kWh" + ("" if n_kesik else " — arızalı parçayı iki ucundaki kesiciler ayırdı, kimse kesinti görmedi"), "#334155", 12)
        cz.yazi(40, 268, (f"Aktarmadan sonra en yüklü parça {fnum(i_max1, 0)} A, gerilim düşümü %{fnum(du_max1, 2)} (arızalı işletme sınırı %10)" if not radyal else "Ring bağlantısı olsaydı arızanın ötesi öbür yönden beslenirdi"),
                "#b91c1c" if (i_max1 > iz or du_max1 > 10) else "#64748b", 12)
    ozet = [
        K("En yüklü kablo parçası", fa(i_max, 0), "bad" if i_max > iz else "ok", f"kablo ≈ {fnum(iz, 0)} A · toplam yük {fa(i_top, 0)}"),
        K("En büyük gerilim düşümü", f"%{fnum(du_max, 2)}", "bad" if du_max > (10 if sonra else 7) else "ok", f"sınır %{10 if sonra else 7}"),
        K("Kayıp", f"{fnum(pk1 if sonra else pk0, 1)} kW", "info", f"olağan işletmede {fnum(pk0, 1)} kW"),
        K("Enerjisiz kalan merkez", (f"{n_kesik} / {n}" if f > 0 else "—"), ("bad" if n_kesik > n / 2 else "warn" if n_kesik else "ok") if f > 0 else "info",
          (f"≈ {fnum(ens, 0)} kWh verilemedi" if f > 0 else "arıza seçilmedi")),
        K("Tek fiderden besleme (N-1)", fa(i_n1, 0), "bad" if i_n1 > iz or du_n1 > 10 else "ok", f"gerilim düşümü %{fnum(du_n1, 2)}"),
    ]
    kontroller = [
        C("Olağan işletmede en yüklü parça kablonun kapasitesinin içinde mi?", fa(i_max0, 0), f"≤ {fnum(iz, 0)} A", i_max0 <= iz,
          "Toprakta yonca demet için tipik değer; iletken sıcaklığı 90 °C (TEDAŞ-MLZ/96-018.B). Gerçek kapasite kablo üreticisinin çizelgesinden ve döşeme koşullarından alınır", "tahmini"),
        C("Olağan işletmede gerilim düşümü", f"%{fnum(du_max0, 2)}", "≤ %7", du_max0 <= 7.0, f"{SART}: normal işletmede YG azami gerilim düşümü %7", "resmi"),
        C("Bir fider devre dışıyken öbürü bütün ringi taşıyabiliyor mu?", fa(i_n1, 0), f"≤ {fnum(iz, 0)} A", (i_n1 <= iz) if not radyal else None,
          "Ringin amacı budur: fiderlerden biri (ya da ilk kablo parçası) arızalandığında bütün yük öbür fidere geçer. Kablo kesiti olağan yüke göre değil, bu duruma göre seçilir", "ikincil"),
        C("Tek fiderden beslemede gerilim düşümü", f"%{fnum(du_n1, 2)}", "≤ %10", (du_n1 <= 10.0) if not radyal else None, f"{SART}: arızalı işletmede YG azami gerilim düşümü %10", "resmi"),
        C("Açık nokta kayıp bakımından en iyi yerde mi?", (f"{a}. merkezden sonra · {fnum(kay_a[a], 1)} kW" if isl == "acik" else "açık nokta yok"), f"en az kayıp: {a_iyi}. merkezden sonra · {fnum(kay_a[a_iyi], 1)} kW",
          (kay_a[a] <= kay_a[a_iyi] * 1.1 + 0.05) if isl == "acik" else None, "Açık nokta, iki yönden gelen akımların eşitlendiği (yükün ortalandığı) yere konduğunda kayıp ve gerilim düşümü en küçük olur", "hesap"),
        C("Koruma bu işletme biçimine uygun mu?", {"acik": "fider başında aşırı akım rölesi", "radyal": "fider başında aşırı akım rölesi", "kapali": "yalnız fider başlarında yönsüz aşırı akım",
                                                    "kapali_dif": "her parçada kesici + yönlü / diferansiyel"}[isl], "kapalı ringde arıza iki yönden beslenir", isl != "kapali",
          "Kapalı ringde arıza akımı iki fiderden birden gelir: yönsüz aşırı akım rölesi arızalı parçayı ayırt edemez, iki fider de açar ve bütün ring söner — Röle laboratuvarı › Yönlü aşırı akım", "ikincil"),
    ]
    girdiler = [
        G("Kablo", f"3 × 1 × {fnum(s, 0)} mm² {'Al' if metal == 'al' else 'Cu'} XLPE · parça boyu {fnum(l, 1)} km", "Tek hat şeması, kablo listesi", "Gerilim düşümü, kayıp ve taşıma kapasitesi",
          f"r = {fnum(r, 3)} · x = {fnum(x, 3)} Ω/km · ≈ {fnum(iz, 0)} A"),
        G("Trafo merkezlerinin yükleri", f"{n} merkez · toplam {fnum(sum(kva), 0)} kVA", "Sayaç / SCADA puant değerleri", "Her parçanın akımı, ötesindeki merkezlerin yüklerinin toplamıdır",
          f"toplam akım {fa(i_top, 0)} (cosφ {fnum(COS, 2)})"),
        G("Açık noktanın yeri", (f"{a}. merkezden sonra" if isl == "acik" else "yok"), "İşletme şeması; ayırıcı konum göstergeleri", "Hangi merkezin hangi fiderden beslendiğini belirler", "A: 1 … a · B: a+1 … n"),
        G("Yük aktarma süresi", f"{fnum(t_akt, 0)} dk", "İşletme kayıtları; SCADA olay listesi", "Kesinti süresini ve verilemeyen enerjiyi belirler", "elle: ekip ulaşma + manevra · uzaktan: operatör kararı"),
    ]
    adimlar = [
        A("Merkez akımı", "I = S / (√3 · U)", f"{fnum(st, 0)} kVA / (1,732 × {fnum(un, 1)} kV)", fa(st / (math.sqrt(3) * un), 1), "her merkez için", "hesap", ["Trafo merkezlerinin yükleri"]),
        A("Parça akımları", "I(parça) = Σ ötesindeki merkezlerin akımları", f"en yüklü parça: fider çıkışı", fa(i_max0, 0), "akım açık noktaya doğru azalır", "hesap", ["Açık noktanın yeri"]),
        A("Gerilim düşümü", "ΔU% = Σ √3 · I(parça) · (r·cosφ + x·sinφ) · l / U", f"parça başına {fnum(k_du * 100, 3)} % / 100 A", f"en uzak merkezde %{fnum(du_max0, 2)}", "parçaların düşümleri toplanır", "hesap", ["Kablo"]),
        A("Kayıp", "Pk = Σ 3 · I(parça)² · r · l", f"r·l = {fnum(r * l, 3)} Ω", f"{fnum(pk0, 1)} kW", "akımın karesiyle: yük ortalandığında en az", "hesap"),
        A("Tek fiderden besleme", "bütün yük tek yönden", f"I = {fa(i_top, 0)} · en uzak merkez {n} parça ötede", f"{fa(i_n1, 0)} · %{fnum(du_n1, 2)}", SART + ": arızalı işletmede %10", "resmi"),
        A("Verilemeyen enerji", "E = Σ P(merkez) · t(kesinti)", (f"{n_kesik} merkez × {fnum(t_akt, 0)} dk" + (f" · {sum(kalici)} merkez × {fnum(ONARIM / 60, 0)} saat" if radyal else "")) if f > 0 else "arıza seçilmedi",
          f"{fnum(ens, 0)} kWh", "süreler örnek değerdir", "tahmini", ["Yük aktarma süresi"]),
    ]
    ayarlar = [
        S("Fider başı aşırı akım rölesi", f"başlatma > {fnum(1.2 * i_n1, 0)} A", "tek fiderden besleme akımının üstü", "Yük aktarıldığında fider açmamalı", "Röle laboratuvarı › Aşırı akım", "ikincil"),
        S("Arıza akımı göstergeleri (her merkezde)", "arıza akımının geçtiği son merkezi gösterir", "—", "Ekip arızalı parçayı merkez merkez aramadan bulur", "TEDAŞ-MLZ/2002-043.B (arıza akımı göstergeleri şartnamesi)", "ikincil"),
        S("Motorlu yük ayırıcıları + SCADA", f"aktarma {fnum(SURE['uzak'], 0)} dk (elle {fnum(SURE['elle'], 0)} dk)", "—", "Kesinti süresini ekibin yol süresinden kurtarır", "saha pratiği", "tahmini"),
        S("Kapalı ring koruması", "yönlü aşırı akım (67) ya da kablo diferansiyeli (87L)", "—", "Yalnız arızalı parça ayrılır; kimse kesinti görmez", "Röle laboratuvarı › Yönlü aşırı akım", "ikincil"),
        S("Açık noktada kilitleme", "iki fider farklı baradan ise senkron / gerilim farkı denetimi", "—", "Ring kapatılırken dolaşım akımı doğmasın", "Röle laboratuvarı › Senkron denetimi", "ikincil"),
    ]
    test = [
        T("Açık noktanın iki yanındaki gerilim", "Gerilim göstergeleri / faz karşılaştırma çubuğu", "iki yanda da gerilim var, fazlar aynı sırada", "ring ilk kez kapatılmadan önce faz sırası ve faz karşılığı denenir"),
        T("Yük aktarma manevrası", "Sıra: arızalı parçanın iki ucu açılır → topraklanır → açık nokta kapatılır", "enerjisiz merkezler geri gelir", "ters sıra arızaya kapatmaktır"),
        T("Fider akımı (aktarma sonrası)", "Fider rölesi / ampermetre", f"≈ {fnum(i_max1 if f > 0 else i_n1, 0)} A", f"kablo ≈ {fnum(iz, 0)} A, röle başlatma ayarının altında olmalı"),
    ]
    xs = list(range(0, n + 2))
    g1 = {"baslik": "Ring boyunca gerilim", "x_ad": "Merkez (0 ve son nokta: bara)", "y_ad": "Gerilim (% Un)",
          "seriler": [{"ad": "olağan işletme", "renk": "#1a4d8f", "pts": pts(xs, [100.0] + [100 - du0[j] for j in range(1, n + 1)] + [100.0], 3)}]
          + ([{"ad": "yük aktarıldıktan sonra", "renk": "#dc2626", "pts": pts(xs, [100.0] + [100 - du1[j] for j in range(1, n + 1)] + [100.0], 3)}] if f > 0 else [])
          + [{"ad": "tek fiderden (en kötü)", "renk": "#94a3b8", "pts": pts(xs, [100.0] + [100 - duw[j] for j in range(1, n + 1)] + [100.0], 3)}]}
    g2 = {"baslik": "Açık noktanın yerine göre kayıp", "x_ad": "Açık nokta: kaçıncı merkezden sonra", "y_ad": "Kayıp (kW)", "ymin": 0,
          "seriler": [{"ad": "kayıp", "renk": "#b45309", "pts": pts(list(range(0, n + 1)), kay_a, 2)}], "isaretler": [{"x": a, "etiket": "açık nokta"}] if isl == "acik" else []}
    rows = []
    for j in range(1, n + 1):
        rows.append([f"{j}", fnum(kva[j], 0), fid0[j], f"−%{fnum(du0[j], 2)}", (fid1[j] if f > 0 else "—"), (f"−%{fnum(du1[j], 2)}" if f > 0 and not kalici[j] else "—"),
                     ("—" if f == 0 else "kesinti yok" if not kesik[j] else f"{fnum(ONARIM / 60, 0)} saat (onarım)" if kalici[j] else f"{fnum(t_akt, 0)} dk")])
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"Ring, aynı baradan çıkan iki fiderin {n} trafo merkezini dolaşıp birleşmesidir. Her merkezde iki yük ayırıcısı vardır: biri gelen kabloya, biri giden kabloya. Böylece her merkeze iki yönden ulaşılabilir.",
            ("Olağan işletmede ringin bir noktası açık tutulur: şebeke iki radyal fider gibi çalışır. Bunun nedeni korumadır — radyal fiderde arıza akımı tek yönden gelir ve fider başındaki basit aşırı akım rölesi yeter."
             if isl == "acik" else "Kapalı ringde akım iki yönden paylaşılır: kayıp ve gerilim düşümü azalır. Bedeli korumadır — arıza akımı da iki yönden gelir ve basit aşırı akım rölesi hangi parçanın arızalı olduğunu bilemez."
             if kapali else "Bu şebekede ring bağlantısı yok: bütün merkezler tek fiderden, sırayla beslenir. Akım ve gerilim düşümü en büyük, yedek besleme sıfırdır."),
            f"Her kablo parçası, ötesindeki bütün merkezlerin akımını taşır: fider çıkışında {fa(i_max0, 0)}, açık noktaya doğru azalır. Gerilim düşümleri parça parça toplanır; en uzak merkezde %{fnum(du_max0, 2)}.",
            (f"Açık noktanın yeri kaybı belirler. Yük iki fidere eşit bölündüğünde kayıp en azdır: burada {a_iyi}. merkezden sonra ({fnum(kay_a[a_iyi], 1)} kW). Şimdiki yerinde {fnum(kay_a[a], 1)} kW."
             if isl == "acik" else f"Kapalı ringde akımlar kendiliğinden en az kayıplı dağılımı bulur: {fnum(pk0, 1)} kW. Açık ringin en iyi hali {fnum(kay_a[a_iyi], 1)} kW." if kapali
             else f"Ring bağlantısı kurulup açık nokta ortaya alınsaydı kayıp {fnum(pk0, 1)} kW'tan {fnum(kay_a[a_iyi], 1)} kW'a inerdi."),
            ((f"{f}. kablo parçasında arıza oldu. " + (
                f"Fider başındaki kesici açtı ve o fiderden beslenen {n_kesik} merkez karardı. Ekip arızalı parçayı arıza göstergelerinden bulur, iki ucundaki ayırıcıları açar ve açık noktayı kapatır: {fnum(t_akt, 0)} dakika sonra bütün merkezler yeniden enerjilidir. Kablonun onarımı ise günlerce sürebilir — kimse beklemez."
                if isl == "acik" else "İki fiderin kesicileri de açtı: arıza akımı iki yönden geldiği için röleler arızalı parçayı ayırt edemedi ve bütün ring karardı. Kapalı ring, parça koruması olmadan açık ringden kötüdür."
                if isl == "kapali" else "Arızalı parçanın iki ucundaki kesiciler, yönlü ya da diferansiyel korumayla 100 ms içinde açtı. Hiçbir merkez kesinti görmedi; ring açık ringe dönüştü."
                if isl == "kapali_dif" else f"Fider başındaki kesici açtı, bütün merkezler karardı. Arızalı parça ayrılınca arızadan önceki merkezler geri gelir; arızanın ötesindeki {sum(kalici)} merkez kablo onarılana kadar ({fnum(ONARIM / 60, 0)} saat) enerjisiz kalır."))
             if f > 0 else "Bir kablo parçasında arıza seçin: fider açar, o fiderdeki merkezler kararır; sonra arızalı parça ayrılır ve yük öbür fidere aktarılır."),
            f"Ringin kablosu olağan yüke göre seçilmez. En kötü durumda — fider çıkışındaki parça arızalandığında — bütün yük ({fa(i_top, 0)}) tek fiderden, en uzun yoldan beslenir: gerilim düşümü %{fnum(du_n1, 2)}. Kablo kesiti ve röle ayarı bu duruma göre belirlenir; şartname bu durum için %10'a izin verir.",
            "Kesintinin süresi kablonun değil, manevranın süresidir. Elle kumandada ekibin merkezlere ulaşması bir saati bulur; motorlu ayırıcılar ve SCADA ile birkaç dakikadır. Arıza göstergeleri ise ekibe arızalı parçayı aramadan söyler.",
        ],
        "dersler": [
            "Ring: her merkeze iki yönden ulaşılır; bir kablo arızası kimseyi onarım süresince karanlıkta bırakmaz.",
            "Açık ring radyal gibi korunur; açık nokta yükün ortasına konur.",
            "Kablo kesiti ve röle ayarı, bütün ringin tek fiderden beslendiği duruma göre seçilir (arızalı işletme: ΔU ≤ %10).",
            "Kapalı ring parça koruması (yönlü / diferansiyel) olmadan işletilmez: arızada bütün ring söner.",
            "Kesinti süresini manevra belirler: arıza göstergesi ve uzaktan kumanda saati dakikaya indirir.",
        ],
        "tablolar": [{"baslik": "Trafo merkezleri", "cols": ["Merkez", "Yük (kVA)", "Olağan besleme", "Olağan gerilim", "Arıza sonrası besleme", "Arıza sonrası gerilim", "Kesinti"], "rows": rows,
                      "not": "Süreler örnek değerlerdir: elle manevra ≈ 60 dk, uzaktan kumanda ≈ 3 dk, kablo onarımı ≈ 8 saat."}],
    }
