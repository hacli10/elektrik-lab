"""Kısa devrede ısı: iletkenin birkaç saniye içinde ısınması, yalıtkanın sınır sıcaklığı, tavlanma ve erime; bakır, alüminyum ve çeliğin farkı; gereken en küçük kesit.

Adyabatik ısınma (ısı iletkenin içinde kalır): j²·t = k²·ln((β + θ1)/(β + θ0)); malzeme sabitleri fizik çizelgelerinden (hesap): bakır için PVC'de k = 115, XLPE'de 143 çıkar.
Sınır sıcaklıkları: XLPE 90 → 250 °C (TEDAŞ-MLZ/96-018.B), PVC 70 → 160 °C (TEDAŞ-MLZ/96-015.A); hücre toprak barasında akım yoğunluğu ≤ 200 A/mm² (TEDAŞ-MLZ/95-007.E) — resmi.
Çıplak iletken ve bara için 200–300 °C sınırları (tavlanma, bağlantıların gevşemesi) tipiktir (tahmini)."""
from __future__ import annotations

import math

from . import fizik as F
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, logsp, num, opt, pts

ID = "kd_isi"
BASLIK = "Kısa devrede ısı"
IKON = "🔥"
GIRIS = ("Kısa devre akımı iletkeni saniyeler içinde yüzlerce dereceye ısıtır; ısının dışarı çıkmaya vakti yoktur. Önce yalıtkan bozulur, sonra metal yumuşar, sonunda erir. "
         "Malzemeyi, kesiti, akımı ve süreyi değiştirin; sıcaklığın sınırları ne zaman aştığını ve aynı akımı taşımak için hangi kesitin gerektiğini izleyin.")
KESIT = (1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300, 400, 500, 630)
TUR = {"pvc": ("PVC yalıtkanlı kablo", 70.0, 160.0, "TEDAŞ-MLZ/96-015.A (AG kablo şartnamesi): normal 70 °C, kısa devre 160 °C (≤ 300 mm²)", "resmi"),
       "xlpe": ("XLPE yalıtkanlı kablo", 90.0, 250.0, "TEDAŞ-MLZ/96-018.B (OG XLPE kablo şartnamesi) böl. 2.2.2.2: normal 90 °C, kısa devre 250 °C (en çok 5 s)", "resmi"),
       "bara": ("Çıplak bara / pano barası", 85.0, 200.0, "çıplak bakır 200 °C'nin üstünde tavlanır, cıvatalı ekler gevşer — tipik sınır", "tahmini"),
       "toprak": ("Çıplak topraklama iletkeni", 30.0, 300.0, "çıplak topraklama iletkeni için tipik sınır", "tahmini"),
       "ekran": ("Kablo ekranı (bakır tel / şerit)", 80.0, 350.0, "ekranın altındaki ve üstündeki malzemeye bağlı — tipik", "tahmini")}

KONTROLLER = [
    ctl("tur", "İletkenin türü", "sec", "xlpe", secenek=opt(*[(k, v[0]) for k, v in TUR.items()])),
    ctl("metal", "Metal", "sec", "cu", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum"), ("fe", "Çelik (galvanizli şerit)"))),
    ctl("s", "Kesit", "sec", 120, secenek=opt(*[(k, f"{str(k).replace('.', ',')} mm²") for k in KESIT])),
    ctl("i", "Kısa devre akımı (etkin)", "sayi", 16.0, min=0.1, max=80, adim=0.1, birim="kA"),
    ctl("t", "Arızanın süresi", "sayi", 1.0, min=0.01, max=5, adim=0.01, birim="s"),
    ctl("th0", "Başlangıç sıcaklığı (seçilirse türe göre)", "sayi", 0, min=0, max=120, adim=5, birim="°C", yardim="0 bırakılırsa türün işletme sıcaklığı alınır"),
]


def run(p: dict) -> dict:
    tur, metal, s, i, t = str(p.get("tur", "xlpe")), str(p.get("metal", "cu")), num(p, "s", 120), num(p, "i", 16.0), num(p, "t", 1.0)
    ad, th_is, th_s, kaynak, durum = TUR[tur]
    th0 = num(p, "th0", 0) or th_is
    m = F.METAL[metal]
    j = i * 1000 / s
    r = F.isin(metal, j, t, th0)
    k = F.k_katsayi(metal, th0, th_s)
    s_min = i * 1000 * math.sqrt(t) / k
    s_uygun = next((x for x in KESIT if x >= s_min), None)
    t_sinir = (k * s / (i * 1000)) ** 2
    i2t = (i * 1000) ** 2 * t
    e_m = F.METAL[metal]["yog"] * m["c"] * (min(r["th"], m["erime"]) - th0) * s * 1e-6 / 1000          # kJ/m (hacim: s mm² × 1 m)
    eridi = r["eridi"] > 0
    asti = r["th"] > th_s
    renk = "#94a3b8" if r["th"] < 100 else "#fbbf24" if r["th"] < 250 else "#f97316" if r["th"] < 600 else "#dc2626"
    c = Cizim(900, 290)
    c.dikdortgen(60, 70, 420, 70, "cizgi", "#e2e8f0" if tur in ("pvc", "xlpe") else "#fff", kw=1.4, r=30)
    c.dikdortgen(80, 88, 380, 34, "ariza" if asti else "cizgi", renk, kw=2, r=14)
    c.yazi(270, 110, f"{m['ad']} {str(s).replace('.', ',')} mm²", "#111827", 12, kalin=True, anchor="middle")
    c.yazi(270, 60, ad + (" — yalıtkan" if tur in ("pvc", "xlpe") else ""), "#475569", 11, anchor="middle")
    c.ok(20, 105, 58, 105, "ariza", 3); c.yazi(20, 92, f"{fnum(i, 1)} kA", "#b91c1c", 12, kalin=True)
    c.yazi(60, 170, f"Akım yoğunluğu {fnum(j, 0)} A/mm² · süre {fnum(t, 2)} s", "#334155", 12.5)
    c.yazi(60, 194, "ERİDİ" if r["eridi"] >= 1 else f"ERİYOR (%{fnum(r['eridi'] * 100, 0)})" if eridi else f"Son sıcaklık {fnum(r['th'], 0)} °C (başlangıç {fnum(th0, 0)} °C)", "#b91c1c" if asti else "#15803d", 14, kalin=True)
    c.yazi(60, 218, f"Sınır {fnum(th_s, 0)} °C'ye varış: {fnum(t_sinir, 2)} s · erime ({m['erime']} °C): {fnum(r['t_erime'], 2)} s", "#334155", 12)
    c.yazi(60, 242, f"Bu akım ve sürede gereken en küçük kesit: {fnum(s_min, 0)} mm² → " + (f"{str(s_uygun).replace('.', ',')} mm²" if s_uygun else "> 630 mm²"), "#1a4d8f", 12.5, kalin=True)
    c.yazi(540, 80, f"k = {fnum(k, 0)} A·√s/mm²", "#334155", 13, kalin=True); c.yazi(540, 102, f"({m['ad'].lower()}, {fnum(th0, 0)} → {fnum(th_s, 0)} °C)", "#64748b", 11)
    c.yazi(540, 132, f"I²t = {fnum(i2t / 1e6, 1)} × 10⁶ A²s", "#334155", 12.5)
    c.yazi(540, 156, f"Metrede emilen ısı ≈ {fnum(e_m, 0)} kJ", "#334155", 12.5)
    c.yazi(540, 186, "Isı iletkenden çıkamaz: sıcaklık yalnız", "#64748b", 11); c.yazi(540, 202, "akım yoğunluğunun karesine ve süreye bağlıdır.", "#64748b", 11)
    c.yazi(540, 222, "Kesit iki katına çıkarsa dayanılan süre dört katına çıkar.", "#64748b", 11)
    ozet = [
        K("Son sıcaklık", "eridi" if r["eridi"] >= 1 else f"{fnum(r['th'], 0)} °C", "bad" if asti else "ok", f"sınır {fnum(th_s, 0)} °C · başlangıç {fnum(th0, 0)} °C"),
        K("Akım yoğunluğu", f"{fnum(j, 0)} A/mm²", "bad" if asti else "info", f"{fnum(i, 1)} kA / {str(s).replace('.', ',')} mm²"),
        K("Sınıra kadar süre", f"{fnum(t_sinir, 2)} s", "bad" if t > t_sinir else "ok", f"arıza {fnum(t, 2)} s sürüyor"),
        K("Gereken en küçük kesit", f"{fnum(s_min, 0)} mm²", "bad" if s < s_min else "ok", f"S = I·√t / k · k = {fnum(k, 0)}"),
        K("Erimeye kadar süre", f"{fnum(r['t_erime'], 2)} s", "bad" if eridi else "info", f"{m['ad'].lower()} {m['erime']} °C'de erir"),
    ]
    kontroller = [
        C("Son sıcaklık sınırın altında mı?", f"{fnum(min(r['th'], 9999), 0)} °C", f"≤ {fnum(th_s, 0)} °C", not asti, kaynak, durum),
        C("Kesit yeterli mi?", f"{str(s).replace('.', ',')} mm²", f"≥ {fnum(s_min, 0)} mm²", s >= s_min - 1e-9, "S = I·√t / k; k malzemenin özdirenci, ısı sığası ve izin verilen sıcaklık aralığından hesaplanır (TS HD 60364-5-54 Ek A'daki bağıntı — madde asıl metinle doğrulanacak)", "dogrulanacak"),
        C("Koruma, iletkeni sınır süresinden önce kurtarıyor mu?", f"arıza {fnum(t, 2)} s", f"≤ {fnum(t_sinir, 2)} s", t <= t_sinir + 1e-9, "Korumanın toplam temizleme süresi (röle + kesici) iletkenin dayanma süresinden kısa olmalıdır", "hesap"),
        C("Akım yoğunluğu (hücre toprak barası ölçütü)", f"{fnum(j, 0)} A/mm²", "≤ 200 A/mm² (bakır, 1 s)", (j <= 200) if (metal == "cu" and tur in ("toprak", "bara")) else None,
          "Hücre boyunca uzanan bakır topraklama iletkeni en az 80 mm² ve akım yoğunluğu 200 A/mm²'yi aşmayacak biçimde seçilir — TEDAŞ-MLZ/95-007.E (hava yalıtımlı hücreler şartnamesi)", "resmi"),
        C("Metal eriyor mu?", f"erime {m['erime']} °C · {fnum(r['t_erime'], 2)} s'de", "erimemeli", not eridi, "Erime sıcaklığına varıldıktan sonra erime gizli ısısı da karşılanır; iletken kopar ve ark başlar", "hesap"),
    ]
    girdiler = [
        G("Kısa devre akımı", f"{fnum(i, 1)} kA", "Kısa devre hesabı: iletkenin bulunduğu noktadaki en büyük akım", "Isınma akımın karesiyle artar", "Röle laboratuvarı › Kısa devre"),
        G("Arızanın temizlenme süresi", f"{fnum(t, 2)} s", "Koruma eğrileri: röle süresi + kesici açma süresi; sigortada erime + ark süresi", "Isınma süreyle doğru orantılıdır", "I²t"),
        G("İletken", f"{m['ad']} {str(s).replace('.', ',')} mm² · {ad}", "Proje, kablo etiketi", "k katsayısını metal ve yalıtkanın sınır sıcaklığı belirler", f"k = {fnum(k, 0)}"),
    ]
    adimlar = [
        A("Akım yoğunluğu", "j = I / S", f"{fnum(i * 1000, 0)} / {str(s).replace('.', ',')}", f"{fnum(j, 0)} A/mm²", "akım kesite düzgün dağılır (kısa sürede deri etkisi ihmal)", "hesap", ["Kısa devre akımı", "İletken"]),
        A("k katsayısı", "k = √(Qc·(β + 20) / ρ20 · ln((β + θ1)/(β + θ0)))", f"{m['ad'].lower()}: Qc = {fnum(m['yog'] * m['c'] * 1e-9 * 1000, 2)} mJ/K·mm³ · β = {fnum(m['beta'], 1)} · ρ20 = {fnum(m['ro'] * 1000, 2)} mΩ·mm²/m", f"{fnum(k, 0)} A·√s/mm²",
          "ısı sığası ve dirençten türetilir: direnç sıcaklıkla arttığı için ısınma hızlanır", "hesap"),
        A("Son sıcaklık", "θ1 = (β + θ0)·e^(j²·t / k0²) − β", f"j²·t = {fnum(j * j * t, 0)}", "eridi" if r["eridi"] >= 1 else f"{fnum(r['th'], 0)} °C", "adyabatik: ısı dışarı çıkmaz", "hesap", ["Arızanın temizlenme süresi"]),
        A("Gereken kesit", "S = I · √t / k", f"{fnum(i * 1000, 0)} × √{fnum(t, 2)} / {fnum(k, 0)}", f"{fnum(s_min, 0)} mm²", "aynı bağıntının kesit için çözümü", "hesap"),
        A("Dayanma süresi", "t = (k · S / I)²", f"({fnum(k, 0)} × {str(s).replace('.', ',')} / {fnum(i * 1000, 0)})²", f"{fnum(t_sinir, 2)} s", "bu kesit bu akıma ne kadar dayanır", "hesap"),
    ]
    ayarlar = [
        S("Koruma süresi", f"toplam ≤ {fnum(t_sinir, 2)} s", "—", "Röle gecikmesi + kesici süresi iletkenin dayanma süresinin altında kalmalı", "Röle laboratuvarı › Faz aşırı akım", "ikincil"),
        S("Akım sınırlayan sigorta / kesici", "geçirdiği I²t küçük", "—", "İlk yarım periyotta keser: kablo k²·S² değerinin çok altında enerji görür", "«Akım sınırlama» sayfası", "ikincil"),
        S("Kablo ekranı", "toprak arıza akımı ve süresine göre", "16 – 25 – 35 mm²", "Ekran yalnız toprak arıza akımını taşır; kesiti buna göre seçilir", "Topraklama laboratuvarı › OG kablo ekranı", "ikincil"),
    ]
    test = [
        T("Arızadan sonra gözle denetim", "Yalıtkanda sertleşme, renk değişimi, kılıfta kabarma; bara eklerinde mavileşme", "yok", "bakırda mavi–mor renk 250 °C'nin aşıldığını gösterir"),
        T("Bağlantı direnci", "Mikroohmmetre ile ek ve pabuçlarda", "önceki değerle aynı", "ısınan ek gevşer; bir sonraki arızada orası erir"),
        T("Yalıtım direnci", "Meger", "önceki değerle aynı", "sınırı aşan kablonun yalıtkanı kalıcı olarak zayıflar"),
    ]
    ts = logsp(0.01, 5, 45)
    g1 = {"baslik": "Sıcaklık – süre (bu akım ve kesit)", "x_ad": "Süre (s)", "y_ad": "Sıcaklık (°C)", "logx": True, "ymax": 1200,
          "seriler": [{"ad": F.METAL[mm]["ad"], "renk": rk, "kesik": mm != metal, "pts": pts(ts, [min(F.isin(mm, j, x, th0)["th"], 1200) for x in ts], 1)} for mm, rk in (("cu", "#b45309"), ("al", "#64748b"), ("fe", "#111827"))],
          "yatay": [{"y": th_s, "etiket": f"sınır {fnum(th_s, 0)} °C", "renk": "#dc2626"}], "isaretler": [{"x": t, "etiket": "süre"}]}
    g2 = {"baslik": "Süreye göre gereken en küçük kesit (bu akım)", "x_ad": "Süre (s)", "y_ad": "Kesit (mm²)", "logx": True, "logy": True,
          "seriler": [{"ad": F.METAL[mm]["ad"], "renk": rk, "kesik": mm != metal, "pts": pts(ts, [i * 1000 * math.sqrt(x) / F.k_katsayi(mm, th0, th_s) for x in ts], 2)} for mm, rk in (("cu", "#b45309"), ("al", "#64748b"), ("fe", "#111827"))],
          "yatay": [{"y": s, "etiket": "seçili kesit", "renk": "#7c3aed"}], "isaretler": [{"x": t, "etiket": "süre"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"İletkenden {fnum(i, 1)} kA geçiyor: milimetre kare başına {fnum(j, 0)} A. Olağan çalışmada bu sayı 2–4 A/mm² dolayındadır. Üretilen ısı akım yoğunluğunun karesiyle artar: {fnum((j / 3) ** 2, 0)} kat.",
            "Birkaç saniye içinde ısının yalıtkana ve havaya geçmeye vakti yoktur: tamamı metalin kendi sıcaklığını yükseltir. Sıcaklık yalnız iki şeye bağlıdır: akım yoğunluğunun karesi ve süre. Kablonun boyu, döşeme biçimi, ortam sıcaklığı sonucu değiştirmez.",
            f"Metal ısındıkça direnci de artar ve ısınma hızlanır; bağıntıdaki logaritma buradan gelir. {fnum(t, 2)} saniye sonunda iletken {fnum(th0, 0)} °C'den " + ("erime sıcaklığına ulaşıyor." if eridi else f"{fnum(r['th'], 0)} °C'ye çıkıyor."),
            (f"Sınır {fnum(th_s, 0)} °C aşıldı. " + ("Yalıtkan yumuşar, iletken içine gömülür ya da yalıtkan kavrulur: kablo o noktada bir daha güvenilmez." if tur in ("pvc", "xlpe") else "Bakır tavlanır ve sertliğini yitirir; cıvatalı ekler gevşer, bir sonraki arızada temas direnci büyür.")
             if asti else f"Sınır {fnum(th_s, 0)} °C aşılmadı: iletken bu arızayı hasarsız atlatır. Aynı akım {fnum(t_sinir, 2)} saniyeden uzun sürseydi aşardı."),
            "Aynı akım için alüminyum bakırın yaklaşık 1,5 katı, çelik 2,5 katı kesit ister: alüminyumun direnci yüksek, ısı sığası düşüktür.",
            "Erime bir sınır değil bir sondur: eriyen iletken kopar, uçları arasında ark başlar ve arıza büyür. Sigorta teli bu olayı bilerek kullanır: en ince yeri önce erir.",
        ],
        "dersler": [
            "Kısa devrede iletkeni korumanın tek yolu süreyi kısaltmak ya da kesiti büyütmektir: S = I·√t / k.",
            "k: bakır/PVC 115, bakır/XLPE 143, alüminyum/XLPE 94. Ezberlemek yerine nereden çıktığını bilmek yeter.",
            "Kesit iki katına çıkarsa dayanma süresi dört katına çıkar; akım iki katına çıkarsa dörtte bire iner.",
            "Arızadan sonra «çalışıyor» demek «sağlam» demek değildir: sınırı aşmış yalıtkan ve gevşemiş ek bir sonraki arızayı bekler.",
        ],
        "tablolar": [{"baslik": "k katsayıları (A·√s/mm²) — bu sayfadaki bağıntıyla", "cols": ["İletken türü", "Sıcaklık aralığı", "Bakır", "Alüminyum", "Çelik"],
                      "rows": [[v[0], f"{fnum(v[1], 0)} → {fnum(v[2], 0)} °C"] + [fnum(F.k_katsayi(mm, v[1], v[2]), 0) for mm in ("cu", "al", "fe")] for v in TUR.values()],
                      "not": "Bakır/PVC 115 ve bakır/XLPE 143 değerleri tesisat standartlarındaki çizelge değerleriyle aynıdır."}],
    }
