"""OG sigortası ile dağıtım trafosunun korunması: sigorta demeraj akımına dayanmalı, AG uçlarındaki kısa devreyi trafonun dayanma süresi içinde kesmeli, AG ana kesicisiyle
seçici olmalı ve kesemeyeceği küçük akımlarda (en küçük kesme akımının altında) tek başına bırakılmamalıdır.

Dayanak (metinden): TEDAŞ-MLZ/99-024.B YG sigortalar şartnamesi — anma akımları (2 … 200 A), anma gerilimleri (7,2-12-17,5-24-36 kV), 36 kV'ta kesme kapasitesi 12,5-16 kA,
genel amaçlı / artçı sınıfları, vurucu pim; ekindeki uygulama kılavuzu (TS 60787): If10/In ≤ 6, If0,1/In ≥ 7·(In/100)^0,25, demeraj noktası «0,1 s'de tam yük akımının 10–12 katı»,
sigortanın AG uçlarındaki kısa devreyi kesmesi ve AG korumasıyla seçicilik, en büyük akımlı kademe (33 kV trafoda 28,5 kV; öbürlerinde −2×%2,5), artçı sigortanın küçük kalıcı
arıza akımlarında hasarlanabilmesi. Trafonun kısa devre dayanım süresi 2 s: TEDAŞ-MLZ/99-032.E böl. 2.2.10.
Sigortanın zaman–akım eğrisi bu sınırların içinde kalan tipik bir eğridir (tahmini); en küçük kesme akımı (≈ 3 × In) imalatçı değeridir (tahmini)."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, fsure, interp, logsp, num, opt, pts, tr_al, tr_ctl, tr_durum, tr_girdi

ID = "og_sigorta"
BASLIK = "OG sigortası ve trafo"
IKON = "🧨"
GIRIS = ("Küçük ve orta güçlü dağıtım trafoları kesiciyle değil, OG sigortasıyla korunur. Sigortadan dört şey birden istenir: enerjilendirmede erimesin, AG kısa devresini trafo "
         "zarar görmeden kessin, AG kesicisinden önce atmasın ve kesemeyeceği küçük akımda yalnız kalmasın. Sigortanın anma akımını değiştirin; dördünün birden ne zaman sağlandığını görün.")

SIG = "TEDAŞ-MLZ/99-024.B (YG sigortalar şartnamesi)"
KLV = SIG + " ekindeki uygulama kılavuzu (TS 60787)"
ANMA = (6.3, 10, 16, 20, 25, 31.5, 40, 50, 63, 80, 100, 125, 160, 200)
K10 = 3.2                # If10 / In (kılavuz: ≤ 6)
I3_KAT = 3.0             # artçı sigortanın en küçük kesme akımı / In (imalatçı değeri; mertebe)

KONTROLLER = tr_ctl(1000, 33.0) + [
    ctl("in_s", "Sigortanın anma akımı", "sec", 40, secenek=opt(*[(v, f"{fnum(v, 1) if v < 10 or v == 31.5 else fnum(v, 0)} A") for v in ANMA])),
    ctl("sinif", "Sigorta sınıfı", "sec", "artci", secenek=opt(("artci", "Artçı (back-up): en küçük kesme akımının altını kesemez"), ("genel", "Genel amaçlı: eriten her akımı keser"))),
    ctl("duzen", "Düzen", "sec", "ya", secenek=opt(("ya", "Sigortalı yük ayırıcısı — vurucu pim üç fazı açtırır"), ("sig", "Ayırıcı + sigorta — yalnız eriyen faz açılır"))),
    ctl("tsd", "AG ana kesicisinin kısa devrede açma süresi", "sayi", 0.03, min=0.02, max=0.5, adim=0.01, birim="s", yardim="Ani açma ≈ 0,03 s; seçicilik için geciktirilmiş kesicide 0,1–0,4 s"),
    ctl("dem", "Demeraj akımı (0,1 s eşdeğeri)", "sayi", 12, min=8, max=14, adim=0.5, birim="× In", yardim="Kılavuz: 0,1 s'de tam yük akımının 10–12 katı"),
]


def _egri(in_s: float) -> list:
    """Ön ark (erime) eğrisi: (akım / In, süre s) noktaları."""
    k01 = max(7 * (in_s / 100) ** 0.25 * 1.1, K10 * 1.45)
    k1 = math.sqrt(K10 * k01)
    return [(1.8, 3600.0), (2.0, 1000.0), (2.4, 100.0), (K10, 10.0), (k1, 1.0), (k01, 0.1), (k01 * 2.0, 0.01), (k01 * 4.5, 0.002), (k01 * 20, 0.001)]


def t_erime(i: float, in_s: float) -> float:
    m = i / in_s
    if m < 1.8:
        return math.inf
    return interp(_egri(in_s), m, logx=True, logy=True)


def fs(t: float) -> str:
    return "erimez" if math.isinf(t) else fsure(t)


def run(p: dict) -> dict:
    tr = tr_al(p)
    in_s, sinif, duzen, tsd, dem = num(p, "in_s", 40), str(p.get("sinif", "artci")), str(p.get("duzen", "ya")), num(p, "tsd", 0.03), num(p, "dem", 12)
    un, sn, uk = tr["un"], tr["sn"], tr["uk"]
    i1n = tr["i1"]
    u_min = 28.5 if un > 20 else un * 0.95
    i_kad = sn / (math.sqrt(3) * u_min)                       # en büyük akımlı kademede tam yük akımı
    i_dem = dem * i1n
    ik3 = i1n / (uk / 100)                                     # AG uçlarında üç fazlı kısa devre — YG tarafından görülen
    dyn = tr["grup"].startswith("D")
    ik1 = ik3 / math.sqrt(3) if dyn else ik3 * 2 / 3          # AG faz–nötr kısa devresinde YG hat akımı (Dyn: 0,577; Yzn: 0,667)
    ik2 = ik3                                                  # AG iki fazlı arızada en büyük YG hat akımı (Dyn: bir fazda tam değer)
    eg = _egri(in_s)
    k01 = eg[5][0]
    if01, if10 = k01 * in_s, K10 * in_s
    i3 = I3_KAT * in_s if sinif == "artci" else 1.8 * in_s
    t3, t1 = t_erime(ik3, in_s), t_erime(ik1, in_s)
    t1_izin = 2.0 * (ik3 / ik1) ** 2
    secici = t3 * 0.8 >= tsd
    olu = i3 > i_kad * 1.05                                     # tam yük ile en küçük kesme akımı arasındaki bölge
    oneri = None
    for v in ANMA:
        e2 = _egri(v)
        if v >= 1.4 * i_kad and e2[5][0] * v >= i_dem and t_erime(ik3, v) <= 2.0:
            oneri = v
            break
    um = 7.2 if un < 7 else 12.0 if un < 12 else 17.5 if un < 17.5 else 36.0
    # ---------------- şema ----------------
    cz = Cizim(900, 320)
    cz.kutu(20, 62, 100, 54, "OG bara", f"{fnum(un, 1)} kV")
    cz.hat("M120,89 H200", "L1", hot=True, w=3)
    cz.dikdortgen(200, 78, 70, 22, "mor", "#f5f3ff"); cz.hat("M206,89 H264", "mor", w=1.5)
    cz.yazi(235, 70, f"sigorta {fnum(in_s, 1) if in_s in (6.3, 31.5) else fnum(in_s, 0)} A", "#6d28d9", 11.5, kalin=True, anchor="middle")
    cz.yazi(235, 118, "sigortalı yük ayırıcısı" if duzen == "ya" else "ayırıcı + sigorta", "#64748b", 10, anchor="middle")
    cz.hat("M270,89 H360", "L1", hot=True, w=3)
    cz.sarim(390, 89, "ucgen" if dyn else "yildiz"); cz.sarim(440, 89, "yildiz")
    cz.yazi(415, 46, f"{fnum(sn, 0)} kVA · uk %{fnum(uk, 1)}", "#334155", 11.5, kalin=True, anchor="middle")
    cz.yazi(415, 134, f"I1n = {fa(i1n, 1)}", "#64748b", 10.5, anchor="middle")
    cz.hat("M470,89 H560", "L1", hot=True, w=3)
    cz.kutu(560, 62, 110, 54, "AG ana kesici", f"açma {fsure(tsd)}")
    cz.hat("M670,89 H760", "L1", hot=True, w=3); cz.simsek(770, 70, 1.1)
    cz.yazi(770, 126, "AG kısa devresi", "#b91c1c", 10.5, anchor="middle")
    cz.yazi(40, 170, f"Demeraj {fnum(i_dem, 0)} A (0,1 s) — sigorta 0,1 s'de {fnum(if01, 0)} A'da erir", "#15803d" if if01 >= i_dem else "#b91c1c", 12.5, kalin=True)
    cz.yazi(40, 194, f"AG üç fazlı kısa devre YG'den {fnum(ik3, 0)} A görünür → sigorta {fs(t3)} (trafo 2 s dayanır)", "#15803d" if t3 <= 2 else "#b91c1c", 12.5, kalin=True)
    cz.yazi(40, 218, f"AG faz–nötr kısa devresi YG'den {fnum(ik1, 0)} A → sigorta {fs(t1)} (izin {fsure(t1_izin)})", "#15803d" if t1 <= t1_izin else "#b91c1c", 12)
    cz.yazi(40, 242, f"AG kesicisi {fsure(tsd)} · sigorta en erken {fs(t3 * 0.8)}: " + ("önce kesici açar" if secici else "sigorta kesiciden önce atabilir"), "#15803d" if secici else "#b45309", 12)
    cz.yazi(40, 266, (f"En küçük kesme akımı {fnum(i3, 0)} A: {fnum(i_kad, 0)}–{fnum(i3, 0)} A arasını sigorta kesemez" if sinif == "artci" else "Genel amaçlı sigorta: eriten her akımı keser"),
            "#b91c1c" if (sinif == "artci" and duzen == "sig") else "#64748b", 12, kalin=sinif == "artci" and duzen == "sig")
    cz.yazi(40, 290, ("Vurucu pim yük ayırıcısını açtırır: üç faz birden kesilir, trafo iki fazda kalmaz" if duzen == "ya" else "Tek sigorta atarsa trafo iki fazla beslenir — Dağıtım trafosu › Faz kopması"),
            "#64748b" if duzen == "ya" else "#b45309", 12)
    ozet = [
        K("Sigorta / tam yük akımı", f"{fnum(in_s / i_kad, 2)} ×", "bad" if in_s < 1.3 * i_kad else "ok", f"en büyük akımlı kademede {fa(i_kad, 1)}"),
        K("Demeraja dayanma", f"{fnum(if01, 0)} A ≥ {fnum(i_dem, 0)} A" if if01 >= i_dem else f"{fnum(if01, 0)} A < {fnum(i_dem, 0)} A", "ok" if if01 >= i_dem else "bad", "0,1 s'deki erime akımı ve demeraj"),
        K("AG kısa devresini kesme", fs(t3), "ok" if t3 <= 2 else "bad", f"YG'den {fnum(ik3, 0)} A · trafo 2 s dayanır"),
        K("AG kesicisiyle seçicilik", "var" if secici else "yok", "ok" if secici else "warn", f"sigorta ≥ {fs(t3 * 0.8)} · kesici {fsure(tsd)}"),
        K("Önerilen en küçük sigorta", f"{fnum(oneri, 1) if oneri in (6.3, 31.5) else fnum(oneri, 0)} A" if oneri else "sigortayla korunamaz", "info" if oneri else "bad", "üç koşulu birden sağlayan ilk anma akımı"),
    ]
    kontroller = [
        C("Sigortanın anma akımı trafonun tam yük akımını payla aşıyor mu?", f"{fnum(in_s, 1)} A", f"≥ 1,4 × {fnum(i_kad, 1)} = {fnum(1.4 * i_kad, 1)} A", in_s >= 1.4 * i_kad,
          f"{KLV} m.4-b: anma akımı tam yük akımını; izin verilen aşırı yük, mahfaza içindeki ısınma ve ortam sıcaklığı için payla aşmalıdır. En büyük akımlı kademe: {fnum(u_min, 1)} kV. 1,4 katsayısı uygulama değeridir", "ikincil"),
        C("Sigorta enerjilendirmede erimeden kalıyor mu?", f"0,1 s'de erime akımı {fnum(if01, 0)} A", f"≥ demeraj {fnum(i_dem, 0)} A ({fnum(dem, 1)} × In, 0,1 s)", if01 >= i_dem,
          f"{KLV} m.4-a: en küçük ön ark eğrisi demeraj noktasının sağında olmalı; pratikte bu nokta 0,1 s'de en yüksek sürekli akımın 10–12 katı alınır", "resmi"),
        C("AG uçlarındaki üç fazlı kısa devre trafonun dayanma süresi içinde kesiliyor mu?", fs(t3), "≤ 2 s", t3 <= 2.0,
          "TEDAŞ-MLZ/99-032.E böl. 2.2.10: trafonun kısa devre ısıl dayanım süresi 2 s. " + SIG + ": sigorta sekonder terminallerdeki kısa devreleri kesebilecek", "resmi"),
        C("AG faz–nötr kısa devresi de zamanında kesiliyor mu?", fs(t1), f"≤ {fsure(t1_izin)} (I²t eşdeğeri)", t1 <= t1_izin,
          f"{'Dyn' if dyn else 'Yzn'} trafoda AG faz–nötr arızası YG hat akımına {fnum(ik1 / ik3, 3)} katıyla yansır: sigorta bu arızayı daha küçük görür, daha geç keser", "hesap"),
        C("AG uç arızaları sigortanın en küçük kesme akımının üstünde mi?", f"{fnum(ik1, 0)} A", f"≥ {fnum(i3, 0)} A", ik1 >= i3,
          f"{KLV} m.5-c: küçük kalıcı arıza akımlarında artçı sigorta hasarlanabilir. En küçük kesme akımı imalatçı değeridir (burada ≈ {fnum(I3_KAT, 0)} × In alındı)", "tahmini"),
        C("Kesemeyeceği bölgede sigortayı yalnız bırakmayan bir düzen var mı?", ("vurucu pim + yük ayırıcısı" if duzen == "ya" else "yalnız sigorta") + (" · artçı" if sinif == "artci" else " · genel amaçlı"),
          "artçı sigorta: vurucu pimle açtırılan yük ayırıcısı ya da AG'de aşırı yük koruması", (duzen == "ya" or sinif == "genel") if olu else True,
          f"{KLV} m.5-c: küçük kalıcı arıza akımlarının olası olduğu ve anahtarlama düzeni bulunmayan yerde genel amaçlı sigorta kullanılmalıdır", "resmi"),
        C("AG ana kesicisiyle seçicilik", f"sigorta en erken {fs(t3 * 0.8)} · kesici {fsure(tsd)}", "sigortanın en küçük erime süresi > kesicinin toplam açma süresi", secici,
          f"{KLV} m.4-d: iki eğrinin kesişme noktası, AG korumasının yük tarafındaki en büyük arıza akımından büyük akımda olmalıdır. Erime süresinde −%20 tolerans alındı", "resmi"),
    ]
    girdiler = tr_girdi(tr) + [
        G("Sigorta", f"{fnum(in_s, 1)} A · {fnum(um, 1)} kV · {'artçı' if sinif == 'artci' else 'genel amaçlı'}", "Sigorta gövdesindeki etiket; imalatçının zaman–akım eğrisi ve seçim cetveli",
          "Erime süresini ve kesebildiği en küçük akımı verir", f"If10 = {fnum(if10, 0)} A · If0,1 = {fnum(if01, 0)} A · en küçük kesme ≈ {fnum(i3, 0)} A"),
        G("AG ana kesicisinin kısa devre açma süresi", fsure(tsd), "Kesici ayar etiketi / açma birimi", "Sigortanın kesiciden sonra kalması gerekir", "toplam açma = ayar + kesici mekanizması"),
        G("En büyük akımlı kademe", f"{fnum(u_min, 1)} kV → {fa(i_kad, 1)}", "Trafo etiketi (kademe çizelgesi)", "Aynı güçte en düşük kademe gerilimi en büyük akımı çeker", "I = Sn / (√3 · U(kademe))"),
    ]
    adimlar = [
        A("Tam yük akımı", "I1n = Sn / (√3 · U)", f"{fnum(sn, 0)} / (1,732 × {fnum(un, 1)})", f"{fa(i1n, 1)} · en düşük kademede {fa(i_kad, 1)}", KLV + ": en büyük akımlı ayar kademesi", "resmi", ["Trafo etiketi", "En büyük akımlı kademe"]),
        A("Demeraj noktası", "I = k · I1n (0,1 s)", f"{fnum(dem, 1)} × {fnum(i1n, 1)}", f"{fnum(i_dem, 0)} A", KLV + " m.4-a: 10–12 kat", "resmi"),
        A("Sigortanın 0,1 s ve 10 s erime akımları", "If0,1 ≥ 7·In·(In/100)^0,25 · If10 ≤ 6·In", f"In = {fnum(in_s, 1)} A", f"If0,1 = {fnum(if01, 0)} A · If10 = {fnum(if10, 0)} A", KLV + " m.3 sınırları; eğrinin kendisi tipik", "tahmini", ["Sigorta"]),
        A("AG kısa devresinin YG'den görünüşü", "Ik = I1n / uk", f"{fnum(i1n, 1)} / {fnum(uk / 100, 3)}", f"{fnum(ik3, 0)} A (üç fazlı)", "şebeke empedansı sayılmadı: en büyük değer", "hesap", ["Trafo etiketi"]),
        A("AG faz–nötr arızasında YG hat akımı", "Dyn: Ik / √3 · Yzn: 2·Ik / 3", f"{fnum(ik3, 0)} × {fnum(ik1 / ik3, 3)}", f"{fnum(ik1, 0)} A", "arıza akımı iki YG fazına bölünür", "hesap"),
        A("Erime süreleri", "eğriden", f"{fnum(ik3 / in_s, 1)} × In ve {fnum(ik1 / in_s, 1)} × In", f"{fs(t3)} · {fs(t1)}", "ark süresi eklenir (birkaç ms)", "tahmini"),
        A("Trafonun izin verdiği süre", "t = 2 s · (Ik / I)²", f"2 × ({fnum(ik3, 0)} / {fnum(ik1, 0)})²", fsure(t1_izin), "TEDAŞ-MLZ/99-032.E böl. 2.2.10 (2 s) — küçük akımda I²t eşdeğeri", "resmi"),
        A("Kesilemeyen bölge", "tam yük … en küçük kesme akımı", f"{fnum(i_kad, 0)} … {fnum(i3, 0)} A", "var" if olu else "yok", "bu bölgedeki arıza: sarım arası kısa devre, AG'de dirençli arıza, aşırı yük", "tahmini"),
    ]
    ayarlar = [
        S("OG sigortası", f"{fnum(oneri, 1) if oneri in (6.3, 31.5) else fnum(oneri, 0)} A (en küçük uygun)" if oneri else "uygun sigorta yok: kesici + röle", "imalatçının seçim cetveli",
          "Demeraja dayanır, AG kısa devresini 2 s içinde keser", f"{SIG}: sigorta seçim cetveli imalatçıdan", "tahmini"),
        S("Vurucu pim + yük ayırıcısı", "üç faz birden açar", "—", "Tek sigorta atınca trafo iki fazda kalmaz; kesilemeyen bölgede ayırıcı devreyi keser", "TS EN 62271-105 (sigortalı yük ayırıcısı birleşimleri)", "ikincil"),
        S("AG ana kesicisi — aşırı yük (termik)", f"{fnum(tr['i2'], 0)} A dolayında", "—", "Sigortanın kesemediği aşırı yük bölgesini AG tarafı korur", "saha pratiği", "ikincil"),
        S("Trafo termometresi / koruma rölesi", "ihbar ve açma kontakları yük ayırıcısına", "—", "Yavaş gelişen iç arızayı ve aşırı ısınmayı sigorta görmez", "TEDAŞ-MLZ/99-032.E böl. 2.3.11", "resmi"),
        S("Sigortanın kesme kapasitesi", "36 kV'ta 12,5 – 16 kA" if um > 30 else "şebekenin kısa devre akımından büyük", "—", "OG tarafındaki arızayı akım sınırlayarak keser", f"{SIG} (anma kesme akımları)", "resmi"),
    ]
    test = [
        T("Atmış sigorta", "Vurucu pim dışarı çıkmış; ayırıcı açmış", "üç sigorta birden değiştirilir", "atmayan iki sigorta da zayıflamış olabilir"),
        T("Sigorta direnci", "Mikroohmmetre ile (soğukken)", "üç fazda eşit, imalatçı değerinde", "yüksek direnç: eleman kısmen erimiş"),
        T("Sigorta atmasından sonra", "Trafo ve AG tarafı yalıtım, sargı direnci, oran deneyleri", "nedeni bulunmadan yeni sigorta takılmaz", "Dağıtım trafosu › Trafo deneyleri"),
        T("İki fazda kalmış trafo", "AG gerilimleri: biri tam, ikisi yarım (Dyn)", "motorlar zorlanır, lambalar söner", "Dağıtım trafosu › Faz kopması"),
    ]
    xs = logsp(1.85 * in_s, max(ik3 * 3, 30 * in_s), 60)
    g1 = {"baslik": "Sigortanın erime eğrisi ve trafonun noktaları (YG tarafı)", "x_ad": "Akım (A)", "y_ad": "Süre (s)", "logx": True, "logy": True,
          "seriler": [{"ad": f"sigorta {fnum(in_s, 0)} A (erime)", "renk": "#7c3aed", "pts": pts(xs, [min(t_erime(q, in_s), 3600.0) for q in xs], 4)},
                      {"ad": "trafonun kısa devre dayanımı (I²t)", "renk": "#dc2626", "pts": pts([ik3 * q for q in (0.3, 0.5, 0.7, 1.0)], [2.0 / q ** 2 for q in (0.3, 0.5, 0.7, 1.0)], 3)},
                      {"ad": "demeraj noktası", "renk": "#b45309", "nokta": True, "pts": [[round(i_dem, 1), 0.1]]},
                      {"ad": "AG kesicisi (YG'ye indirgenmiş)", "renk": "#0ea5e9", "pts": [[round(1.5 * i1n, 1), round(tsd, 3)], [round(ik3 * 3, 1), round(tsd, 3)]]}],
          "isaretler": [{"x": ik3, "etiket": "AG 3 faz"}, {"x": ik1, "etiket": "AG faz–nötr"}, {"x": i3, "etiket": "en küçük kesme"}]}
    rows = []
    for v in ANMA:
        e2 = _egri(v); a1 = v >= 1.4 * i_kad; a2 = e2[5][0] * v >= i_dem; tt = t_erime(ik3, v); a3 = tt <= 2.0
        rows.append([(f"{fnum(v, 1) if v in (6.3, 31.5) else fnum(v, 0)} A") + (" ◀" if v == in_s else ""), "✓" if a1 else "✗", "✓" if a2 else "✗", (fs(tt) + (" ✓" if a3 else " ✗")),
                     fs(t_erime(ik1, v)), "✓" if tt * 0.8 >= tsd else "✗", "✓" if (a1 and a2 and a3) else "—"])
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1],
        "anlatim": [
            f"OG sigortası kum dolu bir porselen borunun içindeki ince gümüş şeritlerdir. Büyük akımda şeritler milisaniyeler içinde erir, kum arkı soğutur ve akım daha ilk yarım dalgada, tepesine varmadan kesilir. {fnum(sn, 0)} kVA'lık bir trafoda kesici ve röle yerine bu yüzden sigorta kullanılır: ucuz, hızlı ve bakımsızdır.",
            f"İlk koşul sigortanın olağan olaylarda erimemesidir. Trafo her enerjilendiğinde tam yük akımının {fnum(dem, 0)} katına varan demeraj akımı çeker ({fnum(i_dem, 0)} A, 0,1 s eşdeğeri). Sigortanın 0,1 saniyedeki erime akımı ({fnum(if01, 0)} A) bunun "
            + ("üstünde: sigorta dayanır." if if01 >= i_dem else "altında: sigorta bir gün, yük yokken, trafo enerjilendirilirken atar. Elemanı her demerajda biraz daha yaşlanır."),
            f"İkinci koşul sigortanın arızada yeterince çabuk erimesidir. AG baralarındaki kısa devre YG tarafından {fnum(ik3, 0)} A olarak görünür (I1n / uk). Trafo bu akıma 2 saniye dayanacak biçimde yapılmıştır; sigorta {fs(t3)}'de eriyor.",
            f"AG'de faz–nötr kısa devresi daha zordur: {'üçgen sargı arıza akımını iki YG fazına böler' if dyn else 'zikzak sargı akımı iki bacağa böler'} ve sigorta yalnız {fnum(ik1, 0)} A görür. Aynı arıza YG tarafında küçülmüş görünür, sigorta geç erir ({fs(t1)}).",
            (f"Üçüncü koşul en az bilinendir. Artçı sigorta, anma akımının yaklaşık {fnum(I3_KAT, 0)} katının ({fnum(i3, 0)} A) altındaki akımı eritir ama kesemez: ark kumun içinde sönmez, gövde ısınır ve patlar. {fnum(i_kad, 0)} A ile {fnum(i3, 0)} A arasındaki arızalar — sarım arası kısa devre, AG'de dirençli arıza, uzun süren aşırı yük — bu bölgeye düşer. "
             + ("Burada vurucu pim devreye girer: eriyen sigortanın pimi yük ayırıcısını açtırır ve akımı ayırıcı keser." if duzen == "ya" else "Bu düzende onu kesecek bir anahtar yok: AG tarafındaki aşırı yük koruması ve trafo termometresi bu bölgeyi kapatmak zorundadır.")
             if sinif == "artci" else "Genel amaçlı sigorta, bir saat içinde eritebildiği her akımı kesebilir: kesilemeyen bölge yoktur. Buna karşılık boyutu ve fiyatı büyüktür; dağıtımda çoğunlukla artçı sigorta ve yük ayırıcısı birlikte kullanılır."),
            ("Vurucu pimin ikinci yararı: tek sigorta attığında üç faz birden açılır. Yalnız sigorta bulunan düzende trafo iki fazla beslenmeye devam eder; AG'de bir faz tam, iki faz yarım gerilimde kalır ve motorlar yanar."
             if duzen == "ya" else "Bu düzende tek sigorta attığında trafo iki fazla beslenmeye devam eder: AG'de bir faz tam, iki faz yarım gerilimde kalır; motorlar yol alamaz ve ısınır. «Dağıtım trafosu › Faz kopması» sayfası bu durumu gösterir."),
            ("AG ana kesicisi sigortadan önce açıyor: AG baralarının ötesindeki arızada sigorta sağlam kalır." if secici
             else f"Seçicilik burada sağlanmıyor: AG barasına yakın bir kısa devrede sigorta {fs(t3 * 0.8)}'de eriyebilir, kesici ise {fsure(tsd)}'de açıyor. Kesicinin gecikmesi kısaltılır ya da sigorta bir kademe büyütülür — ama büyüyen sigorta trafoyu daha geç korur. Bu ikilem OG sigortasının doğasıdır."),
        ],
        "dersler": [
            "OG sigortası demerajda erimemeli: 0,1 s'deki erime akımı ≥ 10–12 × trafo anma akımı.",
            "AG uçlarındaki kısa devreyi 2 s içinde kesmeli; faz–nötr arızası YG'den küçük görünür ve daha geç kesilir.",
            "Artçı sigorta anma akımının yaklaşık üç katının altını kesemez: vurucu pim + yük ayırıcısı bu boşluğu kapatır.",
            "Yalnız sigortalı düzende tek sigorta atarsa trafo iki fazda kalır.",
            "Büyük sigorta seçicidir ama geç korur; küçük sigorta iyi korur ama demerajda atar. Seçim cetveli bu ikisinin arasıdır.",
        ],
        "tablolar": [{"baslik": f"Bu trafo için sigorta anma akımları ({fnum(sn, 0)} kVA · {fnum(un, 1)} kV)", "cols": ["Sigorta", "≥ 1,4 × tam yük", "Demeraja dayanır", "AG 3 faz kısa devre", "AG faz–nötr", "AG kesicisiyle seçici", "Uygun"], "rows": rows,
                      "not": "Eğriler, şartname ekindeki kılavuzun sınırları içinde kalan tipik artçı sigorta eğrisidir. Gerçek seçim imalatçının zaman–akım eğrileri ve seçim cetveliyle yapılır."}],
    }
