"""Güç sistemi laboratuvarı — ortak yardımcılar: sonuç kalıpları (röle laboratuvarından), dayanak adları, karmaşık doğrusal denklem çözücü,
grafik yardımcıları ve dağıtım trafosu verileri (TEDAŞ şartnamelerinin toleranssız en yüksek değerleri)."""
from __future__ import annotations

import cmath
import math

from ..lab.cizim import Cizim  # noqa: F401
from ..lab.core import A120, C, K, ctl, fazor, fnum, fsure, interp, num, opt  # noqa: F401
from ..role.ortak import A, G, S, S3, T, aci, fa, fz, kutup, norm, simetrik  # noqa: F401

W = 2 * math.pi * 50
KOK2 = math.sqrt(2)
RENK3 = ("#8a4b12", "#111827", "#6b7280")          # L1, L2, L3

# ---------------- dayanak adları ----------------
TEDAS_H = "TEDAŞ-MLZ/99-032.E (hermetik yağlı dağıtım transformatörleri şartnamesi)"
TEDAS_G = "TEDAŞ-MLZ/95-012.F (genleşme depolu yağlı dağıtım transformatörleri şartnamesi)"
TEDAS_K = "TEDAŞ-MLZ/99-031.B (kuru tip dağıtım transformatörleri şartnamesi)"
SIEMENS_K = "Siemens GEAFOL dökme reçineli trafo işletme kılavuzu"
SGB = "SGB-SMIT yağlı dağıtım trafosu işletme kılavuzu (Operating Instruction B/2021)"
SEL_AF = "SEL teknik makalesi: trafonun YG tarafında faz kaybının AG gerilimlerine etkisi"
IEC7 = "TS 3215 / IEC 60076-7 (yağlı trafolar için yükleme kılavuzu)"
IEC7_ACIK = "IEC 60076-7 denklemleri (açık erişimli aktarım: SAIMechE R&D Journal 2015, 31, s.12-16)"
IEC12 = "IEC 60076-12 (kuru tip trafolar için yükleme kılavuzu)"
IEC5 = "TS EN 60076-5 (kısa devre dayanım yeteneği)"
IEC10 = "TS EN 60076-10 (ses düzeylerinin belirlenmesi)"
IEC909 = "TS EN 60909-0 (kısa devre akımlarının hesabı)"
TEMEL = "temel devre bağıntısı"


# ---------------- sayısal yardımcılar ----------------
def coz(a: list, b: list) -> list:
    """Karmaşık katsayılı A·x = b (kısmi eksen seçmeli Gauss yok etme). a ve b değiştirilmez."""
    n = len(b)
    m = [list(r) + [b[i]] for i, r in enumerate(a)]
    for k in range(n):
        piv = max(range(k, n), key=lambda r: abs(m[r][k]))
        if abs(m[piv][k]) < 1e-300:
            raise ZeroDivisionError("tekil denklem takımı")
        if piv != k:
            m[k], m[piv] = m[piv], m[k]
        pk = m[k]; d = pk[k]
        for r in range(k + 1, n):
            f = m[r][k] / d
            if f != 0:
                row = m[r]
                for c in range(k, n + 1):
                    row[c] -= f * pk[c]
    x = [0j] * n
    for k in range(n - 1, -1, -1):
        s = m[k][n] - sum(m[k][c] * x[c] for c in range(k + 1, n))
        x[k] = s / m[k][k]
    return x


def pts(xs: list, ys: list, n: int = 3, adim: int = 1) -> list:
    """Grafik noktaları [[x, y], …]."""
    return [[round(float(x), 4), round(float(y), n)] for x, y in list(zip(xs, ys))[::adim]]


def lin(a: float, b: float, n: int) -> list:
    return [a + (b - a) * i / (n - 1) for i in range(n)]


def logsp(a: float, b: float, n: int) -> list:
    la, lb = math.log10(a), math.log10(b)
    return [10 ** (la + (lb - la) * i / (n - 1)) for i in range(n)]


def kutupsal(z: complex, n: int = 2, birim: str = "") -> str:
    """|z| ∠ açı biçiminde metin."""
    return f"{fnum(abs(z), n)}{(' ' + birim) if birim else ''} ∠ {fnum(aci(z), 0)}°"


def paralel(*zs: complex) -> complex:
    y = sum(1 / z for z in zs if abs(z) > 1e-300)
    return 1 / y if abs(y) > 1e-300 else complex(math.inf)


def db_topla(*ls: float) -> float:
    """Ses düzeylerinin (dB) enerji toplamı."""
    return 10 * math.log10(sum(10 ** (v / 10) for v in ls))


# ---------------- dağıtım trafosu verileri ----------------
GUCLER = (50, 100, 160, 250, 400, 630, 800, 1000, 1250, 1600, 2000, 2500)
# (P0, Pk) W — toleranssız en yüksek değerler; anahtar: (tip, 33 kV mu)
_YAGLI = {False: {25: (70, 600), 50: (90, 750), 100: (145, 1250), 160: (210, 1750), 250: (300, 2350), 400: (430, 3250), 630: (600, 4600), 800: (650, 6000),
                  1000: (770, 7600), 1250: (950, 9500), 1600: (1200, 12000), 2000: (1450, 15000), 2500: (1750, 18500)},
          True: {25: (81, 660), 50: (105, 825), 100: (170, 1375), 160: (242, 1925), 250: (345, 2585), 400: (495, 3575), 630: (690, 5060), 800: (750, 6600),
                 1000: (885, 8360), 1250: (1095, 10450), 1600: (1380, 13200), 2000: (1670, 16500), 2500: (2015, 20350)}}
_KURU = {False: {400: (750, 4500), 630: (1100, 7100), 800: (1300, 8000), 1000: (1550, 9000), 1250: (1800, 11000), 1600: (2200, 13000), 2000: (2600, 16000), 2500: (3100, 19000)},
         True: {400: (865, 4950), 630: (1265, 7810), 800: (1495, 8800), 1000: (1785, 9900), 1250: (2070, 12100), 1600: (2530, 14300), 2000: (2990, 17600), 2500: (3565, 20900)}}
_SES_YAGLI = {False: dict(zip((25, 50, 100, 160, 250, 400, 630, 800, 1000, 1250, 1600, 2000, 2500), (37, 39, 41, 44, 47, 50, 52, 53, 55, 56, 58, 60, 63))),
              True: dict(zip((25, 50, 100, 160, 250, 400, 630, 800, 1000, 1250, 1600, 2000, 2500), (39, 41, 43, 46, 49, 52, 54, 55, 57, 58, 60, 62, 65)))}
_SES_KURU = {False: dict(zip((400, 630, 800, 1000, 1250, 1600, 2000, 2500), (60, 62, 64, 65, 67, 68, 70, 71))),
             True: dict(zip((400, 630, 800, 1000, 1250, 1600, 2000, 2500), (62, 64, 66, 67, 69, 70, 72, 73)))}
TIPLER = opt(("hermetik", "Yağlı — hermetik (dalga duvarlı, tam dolu)"), ("genlesme", "Yağlı — genleşme depolu"), ("kuru", "Kuru tip — dökme reçineli (F sınıfı)"))
TIP_AD = {"hermetik": "hermetik yağlı", "genlesme": "genleşme depolu yağlı", "kuru": "kuru tip (dökme reçineli)"}
OG_GERILIM = opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (33.0, "33 kV (34,5 kV şebeke)"))


def guc_sec() -> list:
    return opt(*[(v, f"{v} kVA") for v in GUCLER])


def trafo(tip: str, sn: float, un: float) -> dict:
    """Bir dağıtım trafosunun şartname değerleri. tip: hermetik | genlesme | kuru; sn kVA; un kV (YG anma, ana kademe).
    Kuru tipte 400 kVA'nın altı şartname kapsamında değildir: en yakın (400 kVA) satırın değerleri güce oranlanır ve «tahmini» sayılır."""
    yuksek = un > 20
    kuru = tip == "kuru"
    kay = (_KURU if kuru else _YAGLI)[yuksek]
    ses = (_SES_KURU if kuru else _SES_YAGLI)[yuksek]
    kapsam = sn in kay
    if kapsam:
        p0, pk = kay[sn]; lwa = ses[sn]
    else:
        ref = min(kay, key=lambda s: abs(s - sn))
        p0 = kay[ref][0] * (sn / ref) ** 0.75; pk = kay[ref][1] * (sn / ref) ** 0.85; lwa = ses[ref] + 10 * math.log10(sn / ref)
    if kuru:
        uk = 6.0
    else:
        uk = (4.5 if yuksek else 4.0) if sn <= 630 else 6.0
    ur = pk / (sn * 1000) * 100
    ux = math.sqrt(max(uk * uk - ur * ur, 0.0))
    i1 = sn / (S3 * un); i2 = sn / (S3 * 0.4)
    kaynak = TEDAS_K if kuru else TEDAS_G if tip == "genlesme" else TEDAS_H
    return {"tip": tip, "sn": sn, "un": un, "p0": p0, "pk": pk, "uk": uk, "ur": ur, "ux": ux, "lwa": lwa, "i1": i1, "i2": i2, "kapsam": kapsam, "kaynak": kaynak,
            "grup": "Yzn11" if (not kuru and sn <= 100) else "Dyn11",
            "ik2": i2 / (uk / 100),                               # AG uçlarında üç fazlı kısa devre (A), sonsuz güçlü şebeke
            # sıcaklık artış sınırları ve sınıf
            "d_sargi": 100.0 if kuru else 65.0, "d_yag": None if kuru else 60.0, "sinif": "F (155 °C)" if kuru else "A (105 °C)",
            "t_ref": 120.0 if kuru else 75.0}


def kademeler(un: float) -> list:
    """Enerjisiz kademe değiştiricinin YG kademe gerilimleri (kV), 1 no.lu kademe en küçük sarım sayısı (en düşük gerilim)."""
    if un > 20:
        return [28.5, 30.0, 31.5, 33.0, 34.5, 36.0]
    return [round(un * (1 + k * 0.025), 4) for k in (-2, -1, 0, 1, 2)]


def tr_ctl(sn: int = 1000, un: float = 33.0, tip: str = "hermetik") -> list:
    """Trafo seçimi için ortak üç ayar."""
    return [ctl("tip", "Trafo tipi", "sec", tip, secenek=TIPLER),
            ctl("sn", "Anma gücü", "sec", sn, secenek=guc_sec()),
            ctl("un", "YG anma gerilimi", "sec", un, secenek=OG_GERILIM)]


def tr_al(p: dict) -> dict:
    return trafo(str(p.get("tip", "hermetik")), num(p, "sn", 1000), num(p, "un", 33.0))


def tr_durum(tr: dict) -> str:
    """Şartname çizelgesinde bulunan güçler «resmi», çizelge dışı (kuru tipte 400 kVA altı) oranlanmış değerler «tahmini»."""
    return "resmi" if tr["kapsam"] else "tahmini"


def tr_girdi(tr: dict) -> list:
    """Her trafo sayfasında aynı olan iki veri satırı."""
    return [G("Trafo etiketi", f"{fnum(tr['sn'], 0)} kVA · {fnum(tr['un'], 1)}/0,4 kV · {tr['grup']} · uk %{fnum(tr['uk'], 1)}", "Trafo etiketi (işaret plakası); deney raporu",
              "Anma akımları, kısa devre akımı ve gerilim düşümü bu dört değerden çıkar", f"I1n = {fa(tr['i1'], 1)} · I2n = {fa(tr['i2'], 0)}"),
            G("Kayıplar", f"P0 = {fnum(tr['p0'], 0)} W · Pk = {fnum(tr['pk'], 0)} W", "Etiket ya da deney raporu; şartnamedeki değerler toleranssız en yüksek değerlerdir",
              "Isınmayı, verimi ve yağın sıcaklığını kayıplar belirler", f"Pk/P0 = {fnum(tr['pk'] / tr['p0'], 1)}")]
