"""Paralel kablolar: aynı fazı taşıyan birden çok kablo akımı eşit paylaşmaz. Paylaşımı empedanslar belirler: boy farkı, kesit farkı ve tek damarlı kablolarda diziliş
(reaktans farkı). En yüklü kablo, toplamın izin verdiğinden önce sınırına varır.

Hesap: paralel empedanslarda akım bölünmesi Ik = I·(1/Zk)/Σ(1/Zj) (temel devre bağıntısı). Dizilişe göre reaktans farkları tipiktir (tahmini): yonca demetlerde eşit; düz dizilişte
aynı fazın kabloları yan yana konursa dıştaki kabloların reaktansı %30–50 farklıdır. Akım taşıma çizelgesi ve gruplama çarpanı TS HD 60364-5-52'den bellekle (dogrulanacak)."""
from __future__ import annotations

import math

from . import kablo as KB
from .ortak import A, C, G, K, S, T, TEMEL, Cizim, ctl, fa, fnum, num, opt, pts

ID = "paralel_kablo"
BASLIK = "Paralel kablolar"
IKON = "🟰"
GIRIS = ("Tek bir kablonun taşıyamadığı akım için faz başına iki, üç, dört kablo çekilir ve akımın eşit bölüneceği varsayılır. Bölünmez: kısa olan, kalın olan ve reaktansı küçük olan "
         "kablo daha çok akım alır. Boyları ve dizilişi değiştirin; en yüklü kablonun nereye çıktığını izleyin.")
DIZ = {"yonca": ("Her devre ayrı yonca demet (L1-L2-L3 birlikte)", (1.0, 1.0, 1.0, 1.0)), "duz_iyi": ("Düz, fazlar sırayla tekrarlanır (L1L2L3 L1L2L3)", (1.0, 1.06, 1.06, 1.0)),
       "duz_kotu": ("Düz, aynı faz yan yana (L1L1 L2L2 L3L3)", (1.0, 1.45, 1.45, 1.0)), "karisik": ("Bir kablo ayrı tavada / farklı yoldan", (1.0, 1.0, 1.0, 1.8))}

KONTROLLER = [
    ctl("n", "Faz başına kablo sayısı", "sec", 3, secenek=opt((2, "2"), (3, "3"), (4, "4"))),
    ctl("s", "Kesit (tek damarlı)", "sec", 240, secenek=opt(*[(k, f"{k} mm²") for k in (70, 95, 120, 150, 185, 240, 300)])),
    ctl("metal", "İletken", "sec", "cu", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum"))),
    ctl("i", "Toplam akım (faz başına)", "sayi", 1200, min=100, max=4000, adim=50, birim="A"),
    ctl("l", "Kabloların boyu", "sayi", 30, min=3, max=300, adim=1, birim="m"),
    ctl("fark", "En kısa kablonun boyu (ötekilere göre)", "sayi", 100, min=60, max=100, adim=1, birim="%", yardim="Biri kısa yoldan çekildiyse ya da pabuçlar farklı uzunluktaysa"),
    ctl("diz", "Diziliş", "sec", "duz_kotu", secenek=opt(*[(k, v[0]) for k, v in DIZ.items()])),
]


def run(p: dict) -> dict:
    n, s, metal, i, l, fark, diz = int(num(p, "n", 3)), num(p, "s", 240), str(p.get("metal", "cu")), num(p, "i", 1200), num(p, "l", 30), num(p, "fark", 100) / 100, str(p.get("diz", "duz_kotu"))
    r = KB.r_km(s, metal, 70.0) / 1000                                # Ω/m
    x0 = 0.09 / 1000                                                   # Ω/m (tek damarlı, bitişik)
    carp = DIZ[diz][1][:n] if n == 4 else (DIZ[diz][1][0], DIZ[diz][1][1], DIZ[diz][1][3])[:n] if n == 3 else (DIZ[diz][1][0], DIZ[diz][1][3] if diz == "karisik" else DIZ[diz][1][1])
    boy = [l * (fark if k == 0 else 1.0) for k in range(n)]
    z = [complex(r * boy[k], x0 * carp[k] * boy[k]) for k in range(n)]
    ytop = sum(1 / zk for zk in z)
    ik = [abs(i * (1 / zk) / ytop) for zk in z]
    en = max(ik); esit = i / n
    k_gr = {2: 0.88, 3: 0.82, 4: 0.77}[n] if diz != "yonca" else {2: 0.9, 3: 0.85, 4: 0.82}[n]
    iz1 = KB.iz(s, "xlpe", metal) * 1.1 * k_gr                         # tek damarlı kablolar çok damarlıdan biraz fazla taşır (≈ %10)
    dengesizlik = (en / esit - 1) * 100
    tasinabilen = i * iz1 / en
    c = Cizim(900, 290)
    c.hat("M60,60 V250", "cizgi", w=6); c.hat("M560,60 V250", "cizgi", w=6); c.yazi(60, 50, "kaynak barası", "#475569", 10.5, anchor="middle"); c.yazi(560, 50, "yük barası", "#475569", 10.5, anchor="middle")
    for k in range(n):
        y = 90 + k * (150 / max(n - 1, 1)) if n > 1 else 150
        xs = 60 + (500 * (1 - fark) / 2 if k == 0 else 0)
        c.hat(f"M60,{y:.0f} H560", "ariza" if ik[k] > iz1 else "L1", hot=True, w=3 + 4 * ik[k] / en, hot_renk="ariza" if ik[k] > iz1 else None)
        c.yazi(310, y - 9, f"kablo {k + 1}: {fa(ik[k], 0)} (%{fnum(ik[k] / esit * 100, 0)})" + (f" — boy %{fnum(fark * 100, 0)}" if k == 0 and fark < 1 else ""), "#b91c1c" if ik[k] > iz1 else "#334155", 12, kalin=ik[k] == en, anchor="middle")
    c.yazi(600, 80, f"Eşit bölünseydi {fa(esit, 0)}", "#64748b", 12)
    c.yazi(600, 104, f"En yüklü kablo {fa(en, 0)}", "#b91c1c" if en > iz1 else "#334155", 14, kalin=True)
    c.yazi(600, 128, f"dengesizlik +%{fnum(dengesizlik, 0)}", "#b91c1c" if dengesizlik > 10 else "#334155", 12.5)
    c.yazi(600, 156, f"Kablo başına kapasite {fa(iz1, 0)}", "#334155", 12.5)
    c.yazi(600, 180, f"Bu düzenle taşınabilen: {fa(tasinabilen, 0)}", "#1a4d8f", 12.5, kalin=True)
    c.yazi(600, 204, f"(eşit paylaşımda {fa(iz1 * n, 0)})", "#64748b", 11)
    ozet = [
        K("En yüklü kablo", fa(en, 0), "bad" if en > iz1 else "ok", f"eşit paylaşım {fa(esit, 0)}"),
        K("Dengesizlik", f"+%{fnum(dengesizlik, 0)}", "bad" if dengesizlik > 10 else "ok", "en yüklü kablo / ortalama"),
        K("Kablo başına kapasite", fa(iz1, 0), "info", f"gruplama × {fnum(k_gr, 2)}"),
        K("Taşınabilen toplam akım", fa(tasinabilen, 0), "bad" if tasinabilen < i else "ok", f"istenen {fa(i, 0)} · kâğıt üstünde {fa(iz1 * n, 0)}"),
        K("En az yüklü kablo", fa(min(ik), 0), "info", f"%{fnum(min(ik) / esit * 100, 0)}"),
    ]
    kontroller = [
        C("En yüklü kablo kapasitesinin içinde mi?", fa(en, 0), f"≤ {fa(iz1, 0)}", en <= iz1, "Paralel kablolarda her iletken ayrı ayrı denetlenir; kapasite çizelge değeri × gruplama (TS HD 60364-5-52 — doğrulanacak)", "dogrulanacak"),
        C("Akım paylaşımı dengeli mi?", f"+%{fnum(dengesizlik, 0)}", "≤ %10", dengesizlik <= 10.0, "Fark %10'u aşıyorsa kablolar ayrı ayrı korunur ya da düzen düzeltilir (TS HD 60364-4-43 — asıl metinle doğrulanacak)", "dogrulanacak"),
        C("Boylar eşit mi?", f"en kısa %{fnum(fark * 100, 0)}", "eşit", fark >= 0.98, "Direnç ve reaktans boyla orantılıdır: kısa kablo daha çok akım alır", "hesap"),
        C("Diziliş simetrik mi?", DIZ[diz][0].split(" (")[0], "yonca demet ya da fazlar sırayla", diz in ("yonca", "duz_iyi"), "Aynı fazın kabloları yan yana konursa manyetik alanları birbirini güçlendirir: iç ve dış kabloların reaktansı farklı olur — farklar tipik", "tahmini"),
    ]
    girdiler = [
        G("Kablolar", f"{n} × {fnum(s, 0)} mm² {'Al' if metal == 'al' else 'Cu'} tek damarlı · {fnum(l, 0)} m", "Proje, saha ölçüsü (her kablonun gerçek boyu)", "Paylaşımı empedansların oranı belirler", "Ik = I · Yk / ΣY"),
        G("Diziliş", DIZ[diz][0], "Tava / kanal kesiti", "Tek damarlı kabloda reaktans, komşu kabloların hangi faz olduğuna bağlıdır", "X: yonca < düz"),
        G("Toplam akım", fa(i, 0), "Yük hesabı / ölçü", "En yüklü kablo sınıra önce varır", "I(en yüklü) ≤ Iz"),
    ]
    adimlar = [
        A("Kablo empedansları", "Zk = (r + j·x·ck) · Lk", f"r = {fnum(r * 1e6, 0)} µΩ/m · x = {fnum(x0 * 1e6, 0)} µΩ/m", " · ".join(f"{fnum(abs(zk) * 1000, 2)} mΩ" for zk in z), "her kablo için ayrı boy ve reaktans çarpanı", "hesap", ["Kablolar", "Diziliş"]),
        A("Akım paylaşımı", "Ik = I · (1/Zk) / Σ(1/Zj)", f"I = {fnum(i, 0)} A", " / ".join(fa(x, 0) for x in ik), TEMEL, "hesap", ["Toplam akım"]),
        A("Taşınabilen toplam akım", "I(toplam) = I · Iz / I(en yüklü)", f"{fnum(i, 0)} × {fnum(iz1, 0)} / {fnum(en, 0)}", fa(tasinabilen, 0), "en yüklü kablo sınırına geldiğinde", "hesap"),
    ]
    ayarlar = [
        S("Diziliş", "her devre kendi yonca demetinde; demetler arası bir çap boşluk", "—", "Hem akım paylaşımını eşitler hem ekran / tava ısınmasını azaltır", "saha pratiği", "ikincil"),
        S("Boy ve pabuç", "bütün kablolar aynı boy, aynı tip, aynı pabuç ve tork", "—", "Bağlantı direnci farkı da paylaşımı bozar", "saha pratiği", "ikincil"),
        S("Koruma", "paylaşım eşit değilse her kabloya ayrı koruma", "—", "Tek bir büyük sigorta, kopan ya da aşırı yüklenen tek kabloyu görmez", "TS HD 60364-4-43 (doğrulanacak)", "dogrulanacak"),
        S("Çelik tava ve geçişler", "bir devrenin üç fazı aynı delikten", "—", "Tek bir fazın kabloları çelikle çevrilirse çelik ısınır (girdap akımı)", "saha pratiği", "ikincil"),
    ]
    test = [T("Kablo akımları", "Her paralel kabloda ayrı ayrı pens ampermetre, yük altında", " / ".join(fa(x, 0) for x in ik), "fark %10'u aşıyorsa diziliş ve boylar incelenir"),
            T("Termal kamera", "Kablolar ve pabuçlar", "paralel kablolar aynı sıcaklıkta", "sıcak olan daha çok akım taşıyandır ya da bağlantısı kötüdür")]
    fs = [60 + k for k in range(0, 41)]
    def enyuk(f_):
        zz = [complex(r * l * (f_ / 100 if k == 0 else 1.0), x0 * carp[k] * l * (f_ / 100 if k == 0 else 1.0)) for k in range(n)]
        yt = sum(1 / q for q in zz)
        return max(abs(i * (1 / q) / yt) for q in zz) / esit * 100
    g1 = {"baslik": "Boy farkına göre en yüklü kablonun payı", "x_ad": "En kısa kablonun boyu (% ötekiler)", "y_ad": "En yüklü kablo (% eşit pay)",
          "seriler": [{"ad": "bu diziliş", "renk": "#dc2626", "pts": pts(fs, [enyuk(x) for x in fs], 1)}], "yatay": [{"y": 110, "etiket": "+%10", "renk": "#d97706"}, {"y": 100, "etiket": "eşit", "renk": "#94a3b8"}], "isaretler": [{"x": fark * 100, "etiket": "şimdi"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1],
        "anlatim": [
            f"Faz başına {n} kablo paralel: aynı iki bara arasında {n} ayrı yol. Akım bu yollara empedanslarıyla ters orantılı bölünür; eşit bölünmesi için empedansların eşit olması gerekir.",
            "Empedansın iki parçası vardır. Direnç kesite ve boya bağlıdır: kısa kablo ya da gevşek olmayan pabuç daha küçük direnç demektir. Reaktans ise kablonun çevresindeki manyetik alana, yani komşu kabloların hangi fazı taşıdığına bağlıdır.",
            ("Aynı fazın kabloları yan yana dizilmiş: içteki kabloların çevresinde aynı yönlü akımlar var, alanları üst üste biner ve reaktansları büyür. Akım dıştaki kablolara kayar."
             if diz == "duz_kotu" else "Her devre kendi yonca demetinde: üç fazın alanları birbirini götürür, bütün devrelerin reaktansı aynıdır." if diz == "yonca" else
             "Fazlar sırayla tekrarlanıyor: reaktans farkı küçük." if diz == "duz_iyi" else "Bir kablo ayrı yoldan gidiyor: çevrim alanı büyük, reaktansı öbürlerinin neredeyse iki katı. Akımın büyük bölümünü öbür kablolar taşır."),
            f"Sonuç: {' / '.join(fa(x, 0) for x in ik)}. En yüklü kablo eşit payın %{fnum(en / esit * 100, 0)}'ini taşıyor. Kablo başına kapasite {fa(iz1, 0)}: bu düzen toplamda {fa(tasinabilen, 0)} taşıyabilir, kâğıt üstündeki {fa(iz1 * n, 0)} yerine.",
            "Büyük kesitlerde direnç küçülür, reaktansın payı büyür: 240 mm² ve üstünde paylaşımı neredeyse yalnız diziliş belirler. Bu yüzden büyük akımlarda bara kanalı ya da özenle dizilmiş yonca demetler kullanılır.",
        ],
        "dersler": [
            "Paralel kablolar akımı empedanslarına göre paylaşır: eşit boy, eşit kesit, simetrik diziliş şarttır.",
            "Tek damarlı kablolarda aynı fazı yan yana koymak en sık yapılan hatadır: L1L2L3 L1L2L3 ya da yonca demet doğrudur.",
            "Toplam kapasite, en yüklü kablonun sınırıyla belirlenir.",
            "Paylaşım, devreye almada her kabloda ayrı ayrı akım ölçülerek doğrulanır.",
        ],
        "tablolar": [{"baslik": "Dizilişe göre akım paylaşımı (bu kablolar, eşit boy)", "cols": ["Diziliş", "Kablo akımları", "En yüklü / eşit pay"],
                      "rows": [[v[0], " / ".join(fa(abs(i * (1 / q) / sum(1 / w for w in zz)), 0) for q in zz), f"%{fnum(max(abs(i * (1 / q) / sum(1 / w for w in zz)) for q in zz) / esit * 100, 0)}"]
                               for k_, v in DIZ.items() for zz in [[complex(r * l, x0 * cc * l) for cc in (v[1][:n] if n == 4 else (v[1][0], v[1][1], v[1][3])[:n] if n == 3 else (v[1][0], v[1][3] if k_ == "karisik" else v[1][1]))]]],
                      "not": "Reaktans çarpanları tipiktir; gerçek değer kablo aralıklarına bağlıdır."}],
    }
