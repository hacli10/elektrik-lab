"""OG havai hat (ENH): çelik özlü alüminyum iletkenli dağıtım hattında gerilim düşümü, kayıp, akım sınırı, hat sonu kısa devre akımı ve iletkenin kısa devreye ısıl dayanımı.

Dayanak: gerilim düşümü sınırları (normal işletme %7, arızalı işletme %10), iletken başına hat kaybı çizelgesi (%/km) ve OG azami kısa devre akımları (8-12,5-16-25 kA)
TEDAŞ Elektrik Dağıtım Şebekeleri Teknik Şartnamesi (Proje Yapımı Teknik Şartnameleri, 2014) böl. 2.17'den metinden okundu (resmi). İletken dirençleri üretici kataloğu
değerleridir (ASTM B232; ikincil). Akım taşıma değerleri koşula (ortam, rüzgâr, güneş, izin verilen iletken sıcaklığı) çok bağlıdır: burada sıcak ve durgun hava için
temkinli mertebe kullanıldı (tahmini). Reaktans ve kapasite, faz aralığından hesaplanır (hesap)."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, fsure, lin, num, opt, pts

ID = "enh"
BASLIK = "OG havai hat: gerilim düşümü ve kayıp"
IKON = "🗼"
GIRIS = ("Havai hat çıplak iletkendir: direnci kablodan büyük, reaktansı üç kat fazla, kapasitesi yirmide biridir. Bu yüzden uzun hatta sorun şarj akımı değil, gerilim düşümü ve "
         "kayıptır. İletkeni, boyu ve yükü değiştirin; hattın taşıyabildiği «güç × uzaklık» çarpımını ve hat sonunda kısa devre akımının nereye düştüğünü izleyin.")

SART = "TEDAŞ Elektrik Dağıtım Şebekeleri Teknik Şartnamesi böl. 2.17 (şebeke parametreleri)"
# ad, Al kesiti mm², toplam kesit mm², çap mm, R20 Ω/km, akım taşıma A (temkinli mertebe)
ILETKEN = {
    "swallow": ("3 AWG Swallow", 26.7, 31.1, 7.14, 1.0742, 125),
    "raven": ("1/0 AWG Raven", 53.5, 62.4, 10.11, 0.5360, 195),
    "pigeon": ("3/0 AWG Pigeon", 85.0, 99.2, 12.75, 0.3366, 240),
    "partridge": ("266,8 MCM Partridge", 134.9, 156.9, 16.28, 0.2141, 320),
    "hawk": ("477 MCM Hawk", 241.7, 281.1, 21.79, 0.1195, 510),
}
# TEDAŞ çizelgesi: YG hat kayıpları (%/km) — gerilim sırası 6,3 / 10,5 / 15,8 / 33 kV
KAYIP = {"swallow": (3.63, 2.18, 1.45, 0.69), "raven": (2.82, 1.69, 1.12, 0.54), "pigeon": (2.28, 1.37, 0.91, 0.43), "partridge": (2.05, 1.23, 0.82, 0.39), "hawk": (1.66, 1.0, 0.66, 0.32)}
GER = (6.3, 10.5, 15.8, 34.5)
K_AL = 87.0          # A·√s/mm² — alüminyum, 80 → 200 °C (çıplak iletken, mertebe)

KONTROLLER = [
    ctl("un", "Şebeke gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("iletken", "İletken", "sec", "pigeon", secenek=opt(*[(k, f"{v[0]} ({fnum(v[1], 0)} mm² Al)") for k, v in ILETKEN.items()])),
    ctl("l", "Hat boyu", "sayi", 15.0, min=0.5, max=80, adim=0.5, birim="km"),
    ctl("p", "Hattan taşınan güç", "sayi", 4000, min=100, max=25000, adim=100, birim="kW"),
    ctl("cos", "Güç katsayısı", "sayi", 0.9, min=0.7, max=1.0, adim=0.01),
    ctl("dagilim", "Yük nerede?", "sec", "uc", secenek=opt(("uc", "Hat sonunda toplu"), ("yayili", "Hat boyunca eşit yayılı (köy, trafo dizisi)"))),
    ctl("isletme", "İşletme durumu", "sec", "normal", secenek=opt(("normal", "Normal işletme (sınır %7)"), ("arizali", "Arızalı işletme / yedek besleme (sınır %10)"))),
    ctl("sk", "Hat başında kısa devre akımı", "sec", 16.0, secenek=opt((8.0, "8 kA"), (12.5, "12,5 kA"), (16.0, "16 kA"), (25.0, "25 kA"))),
    ctl("t_ac", "Korumanın arızayı temizleme süresi", "sayi", 0.2, min=0.05, max=3.0, adim=0.05, birim="s"),
]


def _hat(un: float, ilet: str) -> tuple:
    ad, s_al, s_top, cap, r20, iz = ILETKEN[ilet]
    dm = 1500.0 if un > 20 else 1000.0                       # fazlar arası geometrik ortalama açıklık (mm), tipik
    gmr = 0.39 * cap                                          # 6/1 – 26/7 örgülü iletken için mertebe
    x = 0.0628 * math.log(dm / gmr)                           # Ω/km
    c = 0.0556 / math.log(dm / (cap / 2))                     # µF/km
    return ad, s_al, s_top, cap, r20, iz, x, c, dm


def run(p: dict) -> dict:
    un, ilet, l, pw, cosf = num(p, "un", 34.5), str(p.get("iletken", "pigeon")), num(p, "l", 15.0), num(p, "p", 4000), num(p, "cos", 0.9)
    dag, isl, ik0, t_ac = str(p.get("dagilim", "uc")), str(p.get("isletme", "normal")), num(p, "sk", 16.0), num(p, "t_ac", 0.2)
    if ilet not in ILETKEN:
        ilet = "pigeon"
    ad, s_al, s_top, cap, r20, iz, x, c_km, dm = _hat(un, ilet)
    sinf = math.sqrt(max(1 - cosf * cosf, 0.0)); tanf = sinf / cosf
    i = pw / (math.sqrt(3) * un * cosf)
    t_il = 40 + 40 * min(i / iz, 1.6) ** 2                     # iletken sıcaklığı: 40 °C ortam + akımın karesiyle artış
    r = r20 * (1 + 0.00403 * (t_il - 20))
    kd, kp = (1.0, 1.0) if dag == "uc" else (0.5, 1 / 3)        # yayılı yükte eşdeğer boy: gerilim düşümü ½, kayıp ⅓
    du = math.sqrt(3) * i * (r * cosf + x * sinf) * l * kd / (un * 1000) * 100
    pk = 3 * i * i * r * l * kp / 1000                            # kW
    pk_y = pk / pw * 100
    sinir = 7.0 if isl == "normal" else 10.0
    moment = sinir * un * un / (100 * (r + x * tanf)) / kd         # MW·km
    l_max = moment * 1000 / pw
    zs = un / (math.sqrt(3) * ik0)                                 # Ω
    zh = complex(r20 * 1.0, x) * l
    ik3 = un / (math.sqrt(3) * abs(complex(0.1 * zs, 0.995 * zs) + zh))
    ik2 = 0.866 * ik3
    i_dayan = K_AL * s_al / math.sqrt(t_ac) / 1000                  # kA — bu sürede iletkenin dayandığı akım
    t_dayan = (K_AL * s_al / (ik0 * 1000)) ** 2                     # hat başındaki akımda dayanma süresi
    w = 100 * math.pi; u0 = un * 1000 / math.sqrt(3)
    ic = w * c_km * 1e-6 * u0 * l
    zc = math.sqrt((x / w) / (c_km * 1e-6)); sil = un * un / zc     # MW
    kay_tab = KAYIP[ilet][GER.index(un)] if un in GER else None
    # ---------------- şema ----------------
    cz = Cizim(900, 310)
    cz.kutu(20, 70, 110, 54, "OG bara", f"{fnum(un, 1)} kV · {fnum(ik0, 1)} kA")
    xe = 760
    cz.hat(f"M130,97 H{xe}", "L1", hot=True, w=3)
    for k in range(6):
        xx = 190 + (xe - 240) * k / 5
        cz.hat(f"M{xx:.0f},86 V150", "cizgi", w=3); cz.hat(f"M{xx - 14:.0f},92 H{xx + 14:.0f}", "cizgi", w=2)
        if dag == "yayili" and k > 0:
            cz.ok(xx, 104, xx, 134, "mavi", 1.6)
    cz.hat(f"M150,150 H{xe + 20}", "toprak", w=1.5, kesik=True)
    cz.kutu(xe, 70, 120, 54, "Yük" if dag == "uc" else "Son trafo", f"{fnum(pw / 1000, 2)} MW")
    cz.yazi(450, 62, f"{fnum(l, 1)} km · 3 × {ad} · {fa(i, 0)} (kapasite {fnum(iz, 0)} A)", "#334155", 11.5, kalin=True, anchor="middle")
    renk = "#b91c1c" if du > sinir else "#15803d"
    cz.yazi(40, 186, f"Gerilim düşümü %{fnum(du, 2)} (sınır %{fnum(sinir, 0)}) — hat sonu {fnum(un * (1 - du / 100), 2)} kV", renk, 13, kalin=True)
    cz.yazi(40, 210, f"Kayıp {fnum(pk, 0)} kW = taşınan gücün %{fnum(pk_y, 2)} kadarı · iletken ≈ {fnum(t_il, 0)} °C", "#b45309", 12.5)
    cz.yazi(40, 234, f"Bu iletken bu sınırla {fnum(moment, 0)} MW·km taşır → bu yükte en çok {fnum(l_max, 1)} km", "#334155", 12)
    cz.yazi(40, 258, f"Kısa devre: hat başı {fnum(ik0, 1)} kA → hat sonu {fnum(ik3, 2)} kA (iki fazlı {fnum(ik2, 2)} kA)", "#334155", 12)
    cz.yazi(40, 282, f"İletken {fnum(ik0, 1)} kA'ya {fsure(t_dayan)} dayanır; koruma {fsure(t_ac)} sürüyor", "#b91c1c" if t_dayan < t_ac else "#64748b", 12, kalin=t_dayan < t_ac)
    ozet = [
        K("Gerilim düşümü", f"%{fnum(du, 2)}", "bad" if du > sinir else "ok", f"sınır %{fnum(sinir, 0)} · hat sonu {fnum(un * (1 - du / 100), 2)} kV"),
        K("Hat kaybı", f"{fnum(pk, 0)} kW", "warn" if pk_y > 5 else "info", f"taşınan gücün %{fnum(pk_y, 2)} kadarı"),
        K("Akım", fa(i, 0), "bad" if i > iz else "ok", f"iletken kapasitesi ≈ {fnum(iz, 0)} A"),
        K("Taşıma momenti", f"{fnum(moment, 0)} MW·km", "info", f"bu yükte en çok {fnum(l_max, 1)} km"),
        K("Hat sonu kısa devre", f"{fnum(ik3, 2)} kA", "warn" if ik2 * 1000 < 2 * i else "info", f"hat başı {fnum(ik0, 1)} kA · iki fazlı {fnum(ik2, 2)} kA"),
    ]
    kontroller = [
        C("Gerilim düşümü sınırın içinde mi?", f"%{fnum(du, 2)}", f"≤ %{fnum(sinir, 0)} ({'normal' if isl == 'normal' else 'arızalı'} işletme)", du <= sinir,
          f"{SART}: normal işletmede YG azami gerilim düşümü %7, arızalı işletmede %10", "resmi"),
        C("Akım iletkenin taşıma kapasitesinin içinde mi?", fa(i, 0), f"≤ {fnum(iz, 0)} A", i <= iz,
          "Çıplak iletkenin kapasitesi ortam sıcaklığına, rüzgâra ve güneşe bağlıdır; buradaki değer sıcak ve durgun hava için temkinli mertebedir, üretici çizelgesiyle doğrulanır", "tahmini"),
        C("İletken hat başındaki kısa devreye, koruma açana kadar dayanır mı?", f"{fnum(ik0, 1)} kA · {fsure(t_ac)}", f"≤ {fnum(i_dayan, 1)} kA ({fsure(t_ac)} için) ya da süre ≤ {fsure(t_dayan)}", ik0 <= i_dayan,
          f"I·√t ≤ k·S: alüminyum için k ≈ {fnum(K_AL, 0)} A·√s/mm² (80 → 200 °C). İnce iletken güçlü baranın yanında tavlanır ve sehimi kalıcı olarak artar — Arıza fiziği › Kısa devrede ısınma", "ikincil"),
        C("Hat sonundaki iki fazlı kısa devre yük akımından ayırt edilebiliyor mu?", f"{fnum(ik2 * 1000, 0)} A", f"≥ 2 × yük akımı = {fnum(2 * i, 0)} A", ik2 * 1000 >= 2 * i,
          "Aşırı akım rölesinin başlatma ayarı yük akımının üstünde, en küçük arıza akımının altında olmalıdır; uzun hatta bu aralık daralır — Röle laboratuvarı › Aşırı akım", "ikincil"),
        C("TEDAŞ çizelgesindeki hat kaybı", (f"%{fnum(kay_tab, 2)} / km" if kay_tab else "—"), f"bu yükte hesap: %{fnum(pk_y / l, 3)} / km", None,
          f"{SART}: YG hat kayıpları (%/km) çizelgesi — çizelgenin hangi akım için düzenlendiği metinde yazmıyor; sizin yükünüz için olan değer hesap satırındadır", "resmi"),
    ]
    girdiler = [
        G("İletken", f"{ad} · Al {fnum(s_al, 1)} mm² · çap {fnum(cap, 2)} mm", "Proje, direk listesi; iletken makarası etiketi", "Direnci kesit, reaktansı çap ve faz aralığı belirler",
          f"R20 = {fnum(r20, 4)} Ω/km → {fnum(t_il, 0)} °C'ta {fnum(r, 3)} Ω/km · x = {fnum(x, 3)} Ω/km"),
        G("Hat boyu ve yükün yeri", f"{fnum(l, 1)} km · {'toplu' if dag == 'uc' else 'yayılı'}", "Profil, tek hat şeması", "Yayılı yükte akım hat boyunca azalır: düşüm yarıya, kayıp üçte bire iner",
          "eşdeğer boy: ΔU için L/2, kayıp için L/3" if dag == "yayili" else "eşdeğer boy = L"),
        G("Taşınan güç", f"{fnum(pw, 0)} kW · cosφ {fnum(cosf, 2)}", "Yük tahmini; fider ölçüsü", "Akımı ve reaktif bileşeni verir", f"I = P / (√3·U·cosφ) = {fa(i, 1)}"),
        G("Hat başındaki kısa devre akımı", f"{fnum(ik0, 1)} kA", "Bağlantı görüşü; trafo merkezi verisi", "İletkenin ısıl dayanımı ve hat sonu arıza akımı buradan çıkar", f"Zs = U / (√3·Ik) = {fnum(zs, 2)} Ω"),
    ]
    adimlar = [
        A("Akım", "I = P / (√3 · U · cosφ)", f"{fnum(pw, 0)} / (1,732 × {fnum(un, 1)} × {fnum(cosf, 2)})", fa(i, 1), "hat başındaki akım", "hesap", ["Taşınan güç"]),
        A("Reaktans", "x = 0,0628 · ln(Dm / GMR)", f"Dm = {fnum(dm / 1000, 1)} m · GMR ≈ {fnum(0.39 * cap, 1)} mm", f"{fnum(x, 3)} Ω/km", "kabloda ≈ 0,12 Ω/km: havai hatta iletkenler birbirinden uzaktır", "hesap", ["İletken"]),
        A("Gerilim düşümü", "ΔU% = √3 · I · (r·cosφ + x·sinφ) · L(eş) / U", f"1,732 × {fnum(i, 1)} × ({fnum(r, 3)}×{fnum(cosf, 2)} + {fnum(x, 3)}×{fnum(sinf, 2)}) × {fnum(l * kd, 1)} km",
          f"%{fnum(du, 2)}", "cosφ düştükçe reaktansın payı büyür", "hesap", ["Hat boyu ve yükün yeri"]),
        A("Kayıp", "Pk = 3 · I² · r · L(eş)", f"3 × {fnum(i, 1)}² × {fnum(r, 3)} × {fnum(l * kp, 1)} km", f"{fnum(pk, 0)} kW (%{fnum(pk_y, 2)})", "akımın karesiyle büyür", "hesap"),
        A("Taşıma momenti", "P · L = ΔU% · U² / (100 · (r + x·tanφ))", f"{fnum(sinir, 0)} × {fnum(un, 1)}² / (100 × ({fnum(r, 3)} + {fnum(x, 3)}×{fnum(tanf, 2)}))", f"{fnum(moment, 0)} MW·km",
          "gerilimin karesiyle büyür: 34,5 kV, 15,8 kV'un beş katını taşır", "hesap"),
        A("Hat sonu kısa devre akımı", "Ik″ = U / (√3 · |Zs + Z(hat)|)", f"Zs = {fnum(zs, 2)} Ω · Z(hat) = {fnum(abs(zh), 2)} Ω", f"{fnum(ik3, 2)} kA", "iki fazlı arıza bunun 0,866 katı", "hesap", ["Hat başındaki kısa devre akımı"]),
        A("İletkenin kısa devre dayanımı", "t = (k · S / Ik)²", f"({fnum(K_AL, 0)} × {fnum(s_al, 1)} / {fnum(ik0 * 1000, 0)})²", fsure(t_dayan), "yalnız alüminyum kesit sayılır", "ikincil"),
        A("Şarj akımı ve doğal yük", "Ic = ω·C·Uo·L · P(doğal) = U² / Zc", f"C = {fnum(c_km * 1000, 1)} nF/km · Zc = {fnum(zc, 0)} Ω", f"{fa(ic, 2)} · {fnum(sil, 1)} MW",
          "kablonun yirmide biri: havai hatta kapasitif reaktif sorun olmaz", "hesap"),
    ]
    ayarlar = [
        S("Aşırı akım rölesi (hat başı)", f"başlatma {fnum(1.3 * i, 0)} … {fnum(ik2 * 1000 / 1.5, 0)} A arasında", "yük akımının üstü, en küçük arıza akımının altı", "Hat sonundaki iki fazlı arızayı da görmeli",
          "Röle laboratuvarı › Aşırı akım", "ikincil"),
        S("Tekrar kapama (79)", "havai hatta kullanılır", "—", "Arızaların çoğu geçicidir: dal, kuş, yıldırım atlaması; ark sönünce hat yeniden enerjilenir", "Röle laboratuvarı › Tekrar kapama", "ikincil"),
        S("Ayırıcı / sigortalı ayırıcı (branşman başı)", "branşmanın en küçük arıza akımında açmalı", "—", "Uzun branşmanın sonundaki arıza ana fider rölesine küçük görünür", "saha pratiği", "ikincil"),
        S("Gerilim regülasyonu", "trafolarda kademe; uzun hatta gerilim düzenleyici", f"hat sonu %{fnum(du, 1)} düşük", "Hat sonundaki trafonun kademesi bu düşümü karşılar", "Dağıtım trafosu › Kademe değiştirme", "ikincil"),
    ]
    test = [
        T("Hat başı ve hat sonu gerilimi", "Aynı anda iki uçta ölçü (röle / analizör)", f"fark ≈ %{fnum(du, 1)} ({fnum(un * du / 100, 2)} kV)", "yük değiştikçe değişir: puant saatinde ölçülür"),
        T("Ek ve klemens sıcaklığı", "Termal kamera, yük altında", "ek yerleri iletkenden sıcak olmamalı", f"iletken hesabı ≈ {fnum(t_il, 0)} °C"),
        T("Sehim", "Açıklık ortasında, sıcak günde", "proje sehim çizelgesiyle", "kısa devre görmüş ince iletkende sehim kalıcı olarak artar"),
    ]
    xs = lin(0, l, 31)
    if dag == "uc":
        us = [100 - du * q / l for q in xs]
    else:
        us = [100 - 2 * du * (q / l - (q / l) ** 2 / 2) for q in xs]
    g1 = {"baslik": "Hat boyunca gerilim", "x_ad": "Hat başından uzaklık (km)", "y_ad": "Gerilim (% Un)", "seriler": [{"ad": "gerilim", "renk": "#1a4d8f", "pts": pts(xs, us, 2)}],
          "yatay": [{"y": 100 - sinir, "etiket": f"sınır −%{fnum(sinir, 0)}", "renk": "#dc2626"}]}
    ls = lin(1, 80, 40)
    renkler = ("#94a3b8", "#0ea5e9", "#1a4d8f", "#7c3aed", "#b45309")
    ser = []
    for n, k in enumerate(ILETKEN):
        _, _, _, _, r2, iz2, x2, _, _ = _hat(un, k)
        r2 *= 1.12
        ser.append({"ad": ILETKEN[k][0], "renk": renkler[n], "pts": pts(ls, [min(math.sqrt(3) * i * (r2 * cosf + x2 * sinf) * q * kd / (un * 1000) * 100, 40) for q in ls], 2)})
    g2 = {"baslik": f"İletkene göre gerilim düşümü ({fnum(pw / 1000, 1)} MW)", "x_ad": "Hat boyu (km)", "y_ad": "ΔU (%)", "ymin": 0, "seriler": ser,
          "yatay": [{"y": sinir, "etiket": f"%{fnum(sinir, 0)}", "renk": "#dc2626"}], "isaretler": [{"x": l, "etiket": "boy"}]}
    rows = []
    for k in ILETKEN:
        a2, s2, _, _, r2, iz2, x2, c2, _ = _hat(un, k)
        m2 = sinir * un * un / (100 * (r2 * 1.12 + x2 * tanf)) / kd
        rows.append([a2 + (" ◀" if k == ilet else ""), fnum(s2, 1), fnum(r2, 4), fnum(x2, 3), fnum(iz2, 0), fnum(math.sqrt(3) * un * iz2 * cosf / 1000, 1),
                     (fnum(KAYIP[k][GER.index(un)], 2) if un in GER else "—"), fnum(m2, 0), fnum(K_AL * s2 / 1000, 1)])
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"Havai hattın iletkeni çıplak, çelik özlü alüminyumdur ve fazlar birbirinden {fnum(dm / 1000, 1)} m kadar uzaktır. Bu uzaklık reaktansı büyütür ({fnum(x, 2)} Ω/km; kabloda ≈ 0,12) ve kapasiteyi küçültür ({fnum(c_km * 1000, 0)} nF/km; kabloda ≈ 200).",
            f"{fnum(pw / 1000, 2)} MW'lık yük {fa(i, 0)} çeker. Bu akım {fnum(l, 1)} km boyunca iletkenin direncinde ve reaktansında gerilim düşürür: %{fnum(du, 2)}. Güç katsayısı düştükçe reaktansın payı büyür; bu yüzden uzun hattın sonunda kompanzasyon gerilimi de düzeltir.",
            ("Yük hat sonunda toplu olduğu için bütün akım bütün boyu kat eder: en kötü durum budur."
             if dag == "uc" else "Yük hat boyunca yayılı olduğu için akım her trafodan sonra azalır: gerilim düşümü toplu yükün yarısı, kayıp üçte biri olur. Gerilim eğrisi doğru değil, yatıklaşan bir paraboldür."),
            f"Bir hattın ne kadar yük taşıyabileceği «güç × uzaklık» çarpımıyla ölçülür. Bu iletken %{fnum(sinir, 0)} sınırıyla {fnum(moment, 0)} MW·km taşır: {fnum(pw / 1000, 1)} MW için en çok {fnum(l_max, 1)} km. Çarpım gerilimin karesiyle büyür; aynı iletken 34,5 kV'ta 15,8 kV'un yaklaşık beş katını taşır.",
            f"Kayıp akımın karesiyle büyür: {fnum(pk, 0)} kW, taşınan gücün %{fnum(pk_y, 2)} kadarı. Yük iki katına çıkarsa kayıp dört katına çıkar; iletken de ısınır ({fnum(t_il, 0)} °C) ve direnci artar.",
            f"Kısa devre akımı hat boyunca hızla düşer: hat başında {fnum(ik0, 1)} kA, sonunda {fnum(ik3, 2)} kA. Bu iki sonuç doğurur. Hat başında ince iletken büyük akıma uzun süre dayanamaz ({fsure(t_dayan)}); hat sonunda ise arıza akımı yük akımına yaklaşır ve röle onu zor ayırt eder.",
            "Havai hat arızalarının çoğu geçicidir: yıldırım atlaması, dal, kuş. Ark söndüğünde yalıtım (hava) kendini yeniler; bu yüzden havai hatta tekrar kapama kullanılır, kabloda kullanılmaz.",
        ],
        "dersler": [
            "Havai hatta sorun gerilim düşümü ve kayıptır; şarj akımı kablonun yirmide biridir.",
            "Taşıma momenti (MW·km) gerilimin karesiyle büyür.",
            "Yayılı yükte gerilim düşümü toplu yükün yarısı, kayıp üçte biridir.",
            "TEDAŞ sınırı: normal işletmede %7, arızalı işletmede (yedek beslemede) %10.",
            "İnce iletken güçlü baranın yanında kısa devreye dayanamaz: hızlı açma ya da kalın iletken gerekir.",
        ],
        "tablolar": [{"baslik": f"İletkenler ({fnum(un, 1)} kV)", "cols": ["İletken", "Al kesit (mm²)", "R20 (Ω/km)", "x (Ω/km)", "Akım (A)", "Güç (MW)", "TEDAŞ kayıp (%/km)", "Moment (MW·km)", "1 s dayanım (kA)"], "rows": rows,
                      "not": "Akım değerleri sıcak ve durgun hava için temkinli mertebedir (rüzgârda ve serin havada üretici çizelgeleri %25–30 fazlasını verir). Kayıp sütunu TEDAŞ şartnamesindeki çizelgedir; moment bu sayfadaki yük ve güç katsayısı için hesaplanmıştır."}],
    }
