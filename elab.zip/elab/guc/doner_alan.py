"""Döner alan: üç sargının akımları uzayda 120° kaymış üç eksen boyunca alan üretir; toplamı sabit büyüklükte dönen bir vektördür.
Faz sırası, eksik faz, ters bağlı sargı ve dengesiz akımda alanın nasıl bozulduğu.

Bileşke amper-sarım F(t) = ia(t) + ib(t)·a + ic(t)·a² (a = 1∠120°, sargı eksenleri 0°, 120°, 240°). Akımların pozitif bileşeni ileri dönen,
negatif bileşeni geri dönen alanı verir: |F ileri| = 1,5·|I1|, |F geri| = 1,5·|I2|. İkisi birlikteyken vektörün ucu elips çizer; eşitlerse alan dönmez, titreşir.
Kalkış momenti ileri ve geri alanların karelerinin farkıyla orantılıdır. Hepsi temel bağıntıdır."""
from __future__ import annotations

import cmath
import math

from .ortak import A, A120, C, G, K, RENK3, S, T, TEMEL, Cizim, ctl, fnum, num, opt, pts, simetrik

ID = "doner_alan"
BASLIK = "Döner alan"
IKON = "🌀"
GIRIS = ("Üç fazlı motor neden kendiliğinden döner, tek fazlı motor neden dönmez? Cevap statorun içindeki alanın biçimindedir: üç faz dengeliyken alan sabit büyüklükte döner; "
         "bir faz eksilince dönmez, yerinde titreşir. Durumu değiştirin; alan vektörünün ucunun çizdiği şekle bakın.")
DURUM = {"normal": "Üç faz dengeli", "ters": "İki fazın yeri değişmiş (faz sırası ters)", "faz_yok": "Bir faz yok (L1 kesik, yıldız bağlı sargı)", "sargi_ters": "Bir sargının uçları ters bağlı (L3)",
         "dengesiz": "L1 akımı farklı (dengesiz)", "tek": "Tek sargı (tek fazlı motorun ana sargısı)", "iki": "İki sargı 90° arayla, akımları 90° kaymış (kondansatörlü motor)"}

KONTROLLER = [
    ctl("durum", "Durum", "sec", "normal", secenek=opt(*DURUM.items())),
    ctl("genlik", "L1 akımının genliği", "sayi", 50, min=0, max=150, adim=5, birim="%", goster={"durum": ["dengesiz"]}),
    ctl("aci", "Yardımcı sargı akımının ana sargıya göre açısı", "sayi", 90, min=0, max=180, adim=5, birim="°", goster={"durum": ["iki"]}, yardim="Kondansatör bu açıyı 90°'ye yaklaştırır; kondansatörsüz 10–30° kalır"),
    ctl("oran", "Yardımcı sargı amper-sarımı / ana sargı", "sayi", 100, min=0, max=150, adim=5, birim="%", goster={"durum": ["iki"]}),
    ctl("kutup", "Kutup sayısı", "sec", 4, secenek=opt((2, "2 kutup"), (4, "4 kutup"), (6, "6 kutup"), (8, "8 kutup"))),
    ctl("f", "Frekans", "sayi", 50, min=5, max=100, adim=1, birim="Hz"),
]
N = 72


def akimlar(p: dict) -> tuple:
    """(fazörler, eksen açıları °) — fazörler tepe değeri 1 olan akımlar."""
    d = str(p.get("durum", "normal"))
    a = A120
    if d in ("tek", "iki"):
        ia = 1 + 0j
        ib = cmath.rect(num(p, "oran", 100) / 100, math.radians(num(p, "aci", 90))) if d == "iki" else 0j
        return [ia, ib], [0.0, -90.0]                # yardımcı sargı ekseni: akımı öndeyken alan ileri (saat yönünün tersine) döner
    i = [1 + 0j, a * a, a]                      # L1 0°, L2 −120°, L3 +120°
    if d == "ters":
        i = [i[0], i[2], i[1]]
    elif d == "faz_yok":
        i = [0j, cmath.rect(math.sqrt(3) / 2, math.radians(-90)), cmath.rect(math.sqrt(3) / 2, math.radians(90))]          # kalan iki sargı seri: akımları eşit ve ters
    elif d == "sargi_ters":
        i = [i[0], i[1], -i[2]]
    elif d == "dengesiz":
        i = [i[0] * num(p, "genlik", 50) / 100, i[1], i[2]]
    return i, [0.0, 120.0, 240.0]


def alan(i: list, eks: list, wt: float) -> complex:
    return sum((x * cmath.exp(1j * wt)).real * cmath.exp(1j * math.radians(e)) for x, e in zip(i, eks))


def bilesen(i: list, eks: list) -> tuple:
    """İleri ve geri dönen alanın genliği: F(t) = Ff·e^(jωt) + Fb·e^(−jωt)."""
    ff = sum(x * cmath.exp(1j * math.radians(e)) for x, e in zip(i, eks)) / 2
    fb = sum(x.conjugate() * cmath.exp(1j * math.radians(e)) for x, e in zip(i, eks)) / 2
    return ff, fb


def run(p: dict) -> dict:
    d = str(p.get("durum", "normal"))
    kutup, f = int(num(p, "kutup", 4)), num(p, "f", 50)
    i, eks = akimlar(p)
    ff, fb = bilesen(i, eks)
    ns = 120 * f / kutup
    buyuk, kucuk = abs(ff) + abs(fb), abs(abs(ff) - abs(fb))
    ileri = abs(ff) >= abs(fb)
    geri_oran = min(abs(ff), abs(fb)) / max(abs(ff), abs(fb), 1e-9)
    tur = "dairesel" if geri_oran < 0.02 else "titreşen (dönmüyor)" if geri_oran > 0.98 else "eliptik"
    ucfaz = len(i) == 3
    ref = 1.5 if ucfaz else 1.0                                  # dengeli durumda ileri bileşen
    kalkis = (abs(ff) ** 2 - abs(fb) ** 2) / ref ** 2
    c = Cizim(900, 340)
    cx, cy, r0 = 230, 170, 120
    olc = r0 / 1.6 * (1.0 if len(i) == 3 else 1.4)
    c.daire(cx, cy, r0 + 26, "cizgi", w=6); c.daire(cx, cy, r0 + 14, "cizgi", w=1, kesik=True)
    for j, e in enumerate(eks):                                 # sargı eksenleri
        x, y = cx + (r0 + 20) * math.cos(math.radians(e)), cy - (r0 + 20) * math.sin(math.radians(e))
        c.hat(f"M{cx},{cy} L{fnum2(x)},{fnum2(y)}", "soluk", kesik=True, w=1.2)
        c.yazi(cx + (r0 + 44) * math.cos(math.radians(e)), cy - (r0 + 44) * math.sin(math.radians(e)) + 4, (f"L{j + 1}" if ucfaz else ("ana", "yardımcı")[j]), RENK3[j], 11.5, kalin=True, anchor="middle")
    yol = [alan(i, eks, 2 * math.pi * k / N) for k in range(N + 1)]
    dyol = "M" + " L".join(f"{fnum2(cx + z.real * olc)},{fnum2(cy - z.imag * olc)}" for z in yol)
    c.hat(dyol, "mavi", w=2.6)
    for k in (0, N // 12, N // 6):                              # üç ardışık an: dönüş yönü
        z = yol[k]
        c.ok(cx, cy, cx + z.real * olc, cy - z.imag * olc, "ariza" if k == 0 else "uyari", 2.4 if k == 0 else 1.4)
    c.yazi(cx, cy + r0 + 62, "mavi eğri: alan vektörünün ucunun bir periyotta çizdiği yol", "#1d4ed8", 10.5, anchor="middle")
    c.yazi(470, 50, DURUM[d].split(" (")[0], "#15803d" if tur == "dairesel" else "#b91c1c", 14, kalin=True)
    c.yazi(470, 78, f"Alan: {tur}", "#334155", 13, kalin=True)
    c.yazi(470, 102, f"İleri dönen bileşen {fnum(abs(ff), 2)} · geri dönen bileşen {fnum(abs(fb), 2)}", "#334155", 12)
    c.yazi(470, 124, f"Vektörün en büyük / en küçük değeri: {fnum(buyuk, 2)} / {fnum(kucuk, 2)}", "#334155", 12)
    c.yazi(470, 146, "Dönüş yönü: " + ("saat yönünün tersi (L1 → L2 → L3)" if ileri and tur != "titreşen (dönmüyor)" else "saat yönü (ters)" if tur != "titreşen (dönmüyor)" else "yok — alan bir eksen boyunca büyüyüp küçülüyor"), "#334155", 12)
    c.yazi(470, 176, f"Senkron hız: 120·f / kutup = {fnum(ns, 0)} d/dk", "#1a4d8f", 12.5, kalin=True)
    c.yazi(470, 200, f"Kalkış momenti (dengeli duruma göre): %{fnum(abs(kalkis) * 100, 0)}" + (" — ters yönde" if kalkis < -1e-6 else ""), "#b91c1c" if abs(kalkis) < 0.05 else "#334155", 12.5, kalin=True)
    c.yazi(470, 236, {"dairesel": "Rotor hep aynı büyüklükte bir alanın peşinden gider: moment düzgün.",
                      "eliptik": "Geri bileşen rotoru ters yöne çeker ve ısıtır: moment titreşir.",
                      "titreşen (dönmüyor)": "İleri ve geri alan eşit: duran rotorda kalkış momenti yok."}[tur], "#64748b", 11.5)
    c.yazi(470, 258, "Rotor bir yöne çevrilirse o yönde yol alır." if tur == "titreşen (dönmüyor)" else "Geri alan rotorda 100 Hz akım ve ek kayıp oluşturur." if tur == "eliptik" else "", "#64748b", 11.5)
    ozet = [
        K("Alanın biçimi", tur, "ok" if tur == "dairesel" else "bad" if tur.startswith("titre") else "warn", f"geri / ileri = %{fnum(geri_oran * 100, 0)}"),
        K("İleri bileşen", fnum(abs(ff), 2), "info", f"dengeli durumda {fnum(ref, 2)}"),
        K("Geri bileşen", fnum(abs(fb), 2), "ok" if abs(fb) < 0.03 else "warn", "sıfır olmalı"),
        K("Kalkış momenti", f"%{fnum(abs(kalkis) * 100, 0)}", "bad" if abs(kalkis) < 0.05 else "ok", "ters yönde" if kalkis < -1e-6 else "dengeli duruma göre"),
        K("Senkron hız", f"{fnum(ns, 0)} d/dk", "info", f"{kutup} kutup · {fnum(f, 0)} Hz"),
    ]
    kontroller = [
        C("Alan dairesel mi?", f"geri / ileri = %{fnum(geri_oran * 100, 0)}", "≈ %0", geri_oran < 0.02, "Akımlar eşit büyüklükte ve sargı eksenleriyle aynı açıda kaymışsa negatif bileşen yoktur: alan sabit büyüklükte döner", "hesap"),
        C("Duran rotor kendiliğinden dönebilir mi?", f"kalkış momenti %{fnum(abs(kalkis) * 100, 0)}", "> %0", abs(kalkis) > 0.05, "Kalkış momenti ileri ve geri alanların karelerinin farkıyla orantılıdır: Mk ∝ Ff² − Fb²", "hesap"),
        C("Dönüş yönü beklenen yönde mi?", "ileri" if ileri else "geri", "ileri (L1 → L2 → L3)", None if tur.startswith("titre") else ileri, "İki fazın yeri değişirse alanın dönüş yönü tersine döner; motor ters döner", "hesap"),
    ]
    girdiler = [
        G("Sargı eksenleri", " · ".join(f"{fnum(e, 0)}°" for e in eks), "Motorun yapısı: üç fazlıda 120°, tek fazlıda ana ve yardımcı sargı 90° arayla", "Alanın dönebilmesi için uzayda kaymış sargılar gerekir", "F = Σ i(t) · e^(jθ)"),
        G("Sargı akımları (genlik ∠ açı)", " · ".join(f"{fnum(abs(x), 2)} ∠ {fnum(math.degrees(cmath.phase(x)) if abs(x) > 1e-9 else 0, 0)}°" for x in i), "Pens ampermetre (genlik); faz sırası ölçeri (sıra)", "Alanın dönebilmesi için akımlar zamanda da kaymış olmalıdır", "uzayda ve zamanda aynı açı → dairesel alan"),
        G("Kutup sayısı ve frekans", f"{kutup} kutup · {fnum(f, 0)} Hz", "Motor etiketi (anma hızından); şebeke / sürücü", "Alanın dönme hızını belirler", "ns = 120·f / kutup"),
    ]
    adimlar = [
        A("Bileşke alan", "F(t) = Σ ik(t) · e^(jθk)", "her an üç sargının katkısı vektörel toplanır", f"en büyük {fnum(buyuk, 2)} · en küçük {fnum(kucuk, 2)}", TEMEL, "hesap", ["Sargı eksenleri", "Sargı akımları (genlik ∠ açı)"]),
        A("İleri ve geri bileşen", "Ff = ½ Σ Ik·e^(jθk) · Fb = ½ Σ Ik*·e^(jθk)", "akım fazörlerinden", f"Ff = {fnum(abs(ff), 2)} · Fb = {fnum(abs(fb), 2)}", "titreşen her alan, zıt yönde dönen iki yarım alanın toplamıdır", "hesap"),
        A("Kalkış momenti", "Mk ∝ Ff² − Fb²", f"({fnum(abs(ff), 2)}² − {fnum(abs(fb), 2)}²) / {fnum(ref, 1)}²", f"%{fnum(kalkis * 100, 0)}", "duran rotorda iki alanın momenti zıt yönlüdür", "hesap"),
        A("Senkron hız", "ns = 120 · f / p", f"120 × {fnum(f, 0)} / {kutup}", f"{fnum(ns, 0)} d/dk", "alan bir periyotta bir kutup çifti kadar ilerler", "hesap", ["Kutup sayısı ve frekans"]),
    ]
    ayarlar = [
        S("Faz sırası rölesi", "sıra ters ise motor devreye girmez", "—", "Pompa, kompresör, asansör gibi ters dönmemesi gereken tahriklerde", "saha pratiği", "ikincil"),
        S("Faz kaybı / dengesizlik koruması (46, 47)", "negatif bileşen > %10–20", "—", "Geri dönen alanı akımdan ya da gerilimden yakalar", "Röle laboratuvarı › Negatif bileşen", "ikincil"),
    ]
    test = [
        T("Faz sırası", "Faz sırası ölçeri motor klemensinde", "L1 → L2 → L3", "ters ise iki fazın yeri değiştirilir"),
        T("Dönüş yönü", "Motor kısa süre boşta çalıştırılır (kaplin ayrık)", "ok yönünde", "pompada ters dönüş basıncı düşürür, motoru yakmaz ama iş görmez"),
        T("Üç faz akımı", "Pens ampermetre, üç fazda", "birbirine yakın (fark < %10)", "bir fazda akım yoksa motor iki fazla çalışıyordur"),
    ]
    ts = [k * 20 / N for k in range(N + 1)]
    g1 = {"baslik": "Sargı akımları (bir periyot)", "x_ad": "Zaman (ms, 50 Hz'e göre)", "y_ad": "Akım (tepe = 1)", "zaman": True,
          "seriler": [{"ad": (f"L{j + 1}" if ucfaz else ("ana", "yardımcı")[j]), "renk": RENK3[j], "pts": pts(ts, [(x * cmath.exp(1j * 2 * math.pi * k / N)).real for k in range(N + 1)], 3)} for j, x in enumerate(i)]}
    g2 = {"baslik": "Alan vektörünün büyüklüğü ve açısı", "x_ad": "Zaman (ms, 50 Hz'e göre)", "y_ad": "büyüklük · açı/100°", "zaman": True,
          "seriler": [{"ad": "büyüklük", "renk": "#dc2626", "pts": pts(ts, [abs(z) for z in yol], 3)},
                      {"ad": "açı / 100°", "renk": "#1a4d8f", "kesik": True, "pts": pts(ts, [(math.degrees(cmath.phase(z)) % 360) / 100 if abs(z) > 1e-6 else 0 for z in yol], 3)}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Her sargı kendi ekseni boyunca, o andaki akımıyla orantılı bir alan üretir: akım yön değiştirince alan da yön değiştirir ama ekseninden çıkamaz. Tek bir sargının alanı dönmez, titreşir.",
            "Üç sargı uzayda 120° arayla yerleştirilir ve akımları zamanda 120° kaymıştır. Bir sargının akımı tepe yaparken öbür ikisi yarı değerde ve ters yöndedir: üçünün toplamı her an aynı büyüklüktedir, yalnız yönü değişir. Bu, dönen alandır.",
            {"normal": "Üç faz dengeli: vektörün ucu tam bir daire çizer. Rotor bu alanın peşinden, biraz geride (kaymayla) döner.",
             "ters": "İki fazın yeri değişince akımların sırası tersine döner: alan aynı büyüklükte ama ters yönde döner. Motor ters döner.",
             "faz_yok": "Bir faz kesilince kalan iki sargı seri kalır; akımları eşit ve terstir. İki titreşen alanın toplamı yine titreşen bir alandır: daire bir çizgiye iner. Duran motor kalkamaz; dönen motor ise dönmeye devam eder ama iki katı akım çeker.",
             "sargi_ters": "Bir sargının uçları ters bağlanınca o sargının alanı 180° döner. Akımların üçte ikisi negatif bileşene geçer: baskın alan ters yönde döner. Motor ters yöne, sarsılarak, yüksek akımla ve düşük momentle döner.",
             "dengesiz": "Bir fazın akımı farklıysa daire elipse döner: küçük bir geri dönen alan ortaya çıkar. Bu alan rotoru yaklaşık iki katı frekansta keser ve onu ısıtır.",
             "tek": "Tek sargının alanı yalnız kendi ekseni boyunca büyür ve küçülür. Bu titreşen alan, zıt yönde dönen iki yarım alanın toplamıdır: duran rotoru iki yöne eşit çekerler.",
             "iki": f"İkinci bir sargı 90° yana konur ve akımı {fnum(num(p, 'aci', 90), 0)}° kaydırılır. Açı 90° ve amper-sarımlar eşitse alan dairedir; açı küçüldükçe elips yassılır, 0°'de çizgiye iner. Kondansatörün görevi bu açıyı büyütmektir."}[d],
            f"Alan her periyotta bir kutup çifti kadar yol alır: {kutup} kutuplu sargıda {fnum(f, 0)} Hz'te dakikada {fnum(ns, 0)} devir. Kutup sayısı arttıkça ya da frekans düştükçe alan yavaşlar.",
            "Elips, zıt yönde dönen iki dairenin toplamıdır. İleri dönen daire motoru çevirir; geri dönen daire fren yapar ve rotoru ısıtır. Koruma röleleri bu geri bileşeni «negatif bileşen» olarak ölçer.",
        ],
        "dersler": [
            "Dönen alan için iki şey gerekir: uzayda kaymış sargılar ve zamanda kaymış akımlar.",
            "İki fazın yeri değişirse motor ters döner; üç fazın hepsi kaydırılırsa (L1→L2→L3→L1) yön değişmez.",
            "Bir fazı kesilen üç fazlı motor ve kondansatörü olmayan tek fazlı motor aynı durumdadır: alan dönmez, kalkış momenti yoktur.",
            "Geri dönen alan = negatif bileşen = rotorda 100 Hz akım = ısı.",
        ],
    }


def fnum2(x: float) -> str:
    return f"{x:.1f}"
