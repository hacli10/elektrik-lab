"""Hücrede iç ark: kapalı bir bölmede yanan ark havayı milisaniyeler içinde ısıtır; basınç yükselir, tahliye kapağı açılır, sıcak gaz dışarı atılır.
Basınç tepesi ve zamanı, kapıya binen kuvvet, enerji; tahliye alanının ve koruma süresinin etkisi.

Model: fizik.basinc — tek hacimli kütle ve enerji dengesi, ideal gaz, sıkıştırılabilir delik akışı. Ark gücünün gaza geçen payı kp ≈ 0,5 ve ark gerilimi tipiktir (tahmini);
akış benzetimi değildir, mertebe gösterir. Hücrelerin iç ark dayanımı 16 kA – 1 s, sınıfı IAC-AFL ve deneyin TS EN 62271-200 madde 6.106'ya göre yapıldığı
TEDAŞ-MLZ/95-007.E'dendir (resmi)."""
from __future__ import annotations

import math

from . import fizik as F
from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, num, opt, pts

ID = "ic_ark"
BASLIK = "Hücrede iç ark"
IKON = "🧨"
GIRIS = ("Metal mahfazalı hücrenin içinde ark yandığında megavatlarca güç birkaç yüz litrelik bir hacme boşalır. Hava ısınır, genleşecek yer bulamaz: basınç 10–20 ms içinde tepe yapar. "
         "Tahliye kapağı açılmazsa kapılar fırlar. Akımı, bölme hacmini, tahliye alanını ve koruma süresini değiştirin; basıncın zamanla değişimini izleyin.")
HUCRE = "TEDAŞ-MLZ/95-007.E (hava yalıtımlı metal mahfazalı hücreler şartnamesi)"
KORUMA = {"ark": ("Ark rölesi + kesici", 70), "ani": ("Ani aşırı akım + kesici", 100), "gecikmeli": ("Gecikmeli aşırı akım + kesici", 500), "deney": ("Tip deneyi süresi", 1000)}

KONTROLLER = [
    ctl("ik", "Ark akımı (kısa devre akımı)", "sayi", 16.0, min=2, max=31.5, adim=0.5, birim="kA"),
    ctl("l", "Ark boyu (faz aralığı)", "sayi", 30, min=10, max=45, adim=1, birim="cm"),
    ctl("v", "Bölmenin hacmi", "sayi", 0.6, min=0.1, max=3.0, adim=0.05, birim="m³", yardim="Kablo bölmesi ≈ 0,3–0,6 m³; bara bölmesi ≈ 0,2 m³; kesici bölmesi ≈ 0,5–1 m³"),
    ctl("kapak", "Tahliye kapağının alanı", "sayi", 0.10, min=0.0, max=0.5, adim=0.01, birim="m²", yardim="0: kapak yok ya da açılamıyor (üstü kapatılmış, tavan çok alçak)"),
    ctl("p_ac", "Kapağın açılma basıncı", "sayi", 0.2, min=0.05, max=1.0, adim=0.05, birim="bar"),
    ctl("kapi", "Kapının alanı", "sayi", 1.2, min=0.3, max=2.5, adim=0.1, birim="m²"),
    ctl("koruma", "Arkı temizleyen koruma", "sec", "gecikmeli", secenek=opt(*[(k, f"{v[0]} ({v[1]} ms)") for k, v in KORUMA.items()])),
]


def run(p: dict) -> dict:
    ik, l, v, kapak, p_ac, kapi = num(p, "ik", 16.0), num(p, "l", 30), num(p, "v", 0.6), num(p, "kapak", 0.10), num(p, "p_ac", 0.2), num(p, "kapi", 1.2)
    kor = str(p.get("koruma", "gecikmeli")); kad, t_ms = KORUMA[kor]
    ua = F.ark_gerilimi(l)
    p_ark = 3 * ua * ik * 1000 / 1e6                                   # MW
    sure = min(t_ms, 300.0)
    b = F.basinc(p_ark, v, sure, p_ac if kapak > 0 else 99.0, max(kapak, 1e-6))
    tepe, t_tepe = b["tepe"], b["t_tepe"]
    f_kapi = tepe * 1e5 * kapi / 1000                                   # kN
    e = p_ark * t_ms / 1000
    hiz = 0.4 * 0.5 * p_ark * 1e6 / v / 1e5                             # bar/s (kapalıyken)
    t_ac = b["t_kapak"]
    c = Cizim(900, 310)
    c.dikdortgen(80, 90, 300, 190, "cizgi", "#f1f5f9", kw=3, r=2)
    c.yazi(230, 300, f"bölme {fnum(v, 2)} m³", "#475569", 10.5, anchor="middle")
    if kapak > 0:
        if t_ac is not None:
            c.hat("M160,90 L130,52", "ariza", w=4); c.hat("M300,90 L330,52", "ariza", w=4)
            for dx in (-40, 0, 40):
                c.ok(230 + dx, 84, 230 + dx * 1.6, 30, "uyari", 2.4)
            c.yazi(230, 22, f"tahliye kapağı {fnum(t_ac, 0)} ms'de açtı — sıcak gaz yukarı", "#b45309", 11.5, kalin=True, anchor="middle")
        else:
            c.hat("M160,90 H300", "cizgi", w=5); c.yazi(230, 78, "tahliye kapağı (kapalı)", "#475569", 10.5, anchor="middle")
    else:
        c.yazi(230, 78, "tahliye yok", "#b91c1c", 11.5, kalin=True, anchor="middle")
    c.hat("M200,170 Q230,140 260,170", "ariza", hot=True, w=6); c.simsek(222, 176, 1.6)
    c.yazi(230, 232, f"ark {fnum(p_ark, 0)} MW", "#b91c1c", 13, kalin=True, anchor="middle")
    c.hat("M380,110 V260", "ariza" if tepe > 0.5 else "cizgi", w=6); c.ok(384, 185, 440, 185, "ariza", 3)
    c.yazi(392, 174, f"kapı: {fnum(f_kapi, 0)} kN", "#b91c1c", 12, kalin=True); c.yazi(392, 204, f"≈ {fnum(f_kapi / 9.81, 1)} ton", "#b91c1c", 11.5)
    c.yazi(540, 56, f"Basınç tepesi {fnum(tepe, 2)} bar — {fnum(t_tepe, 0)} ms'de", "#b91c1c" if tepe > 1 else "#b45309", 14, kalin=True)
    c.yazi(540, 82, f"Kapalıyken yükselme hızı ≈ {fnum(hiz, 0)} bar/s", "#334155", 12.5)
    c.yazi(540, 106, f"Kapıya binen kuvvet {fnum(f_kapi, 0)} kN ({fnum(kapi, 1)} m²)", "#334155", 12.5)
    c.yazi(540, 130, f"{kad}: {t_ms} ms → {fnum(e, 1)} MJ", "#b91c1c" if e > 2 else "#334155", 12.5, kalin=True)
    c.yazi(540, 160, "Basınç ilk 10–30 ms'nin olayıdır: koruma onu değiştiremez,", "#64748b", 11); c.yazi(540, 176, "yalnız hacim ve tahliye alanı değiştirir.", "#64748b", 11)
    c.yazi(540, 200, "Koruma, sonrasını belirler: yanma süresini, delinen sacı,", "#64748b", 11); c.yazi(540, 216, "atılan sıcak gazın miktarını.", "#64748b", 11)
    c.yazi(540, 246, "Şartname: iç ark dayanımı 16 kA – 1 s, sınıf IAC-AFL", "#1a4d8f", 12, kalin=True)
    ozet = [
        K("Basınç tepesi", f"{fnum(tepe, 2)} bar", "bad" if tepe > 1.0 else "warn" if tepe > 0.4 else "ok", f"{fnum(t_tepe, 0)} ms'de · atmosfere göre"),
        K("Kapıya binen kuvvet", f"{fnum(f_kapi, 0)} kN", "bad" if f_kapi > 100 else "warn", f"≈ {fnum(f_kapi / 9.81, 1)} ton · {fnum(kapi, 1)} m²"),
        K("Tahliye kapağı", "yok" if kapak <= 0 else "açmadı" if t_ac is None else f"{fnum(t_ac, 0)} ms'de açtı", "bad" if kapak <= 0 else "ok", f"{fnum(kapak, 2)} m² · {fnum(p_ac, 2)} bar"),
        K("Ark gücü", f"{fnum(p_ark, 0)} MW", "bad", f"3 × {fnum(ua, 0)} V × {fnum(ik, 1)} kA"),
        K("Ark enerjisi", f"{fnum(e, 1)} MJ", "bad" if e > 2 else "warn", f"{t_ms} ms'de"),
    ]
    kontroller = [
        C("Ark akımı ve süresi, hücrenin iç ark sınıfının içinde mi?", f"{fnum(ik, 1)} kA · {t_ms} ms", "≤ 16 kA ve ≤ 1 s", ik <= 16.0 + 1e-9 and t_ms <= 1000, "İç ark dayanımı 16 kA-etken, 1 saniye; iç ark sınıfı IAC-AFL (ön, yan: A tipi erişim) — " + HUCRE, "resmi"),
        C("Tahliye yolu açık mı?", "yok" if kapak <= 0 else f"{fnum(kapak, 2)} m²", "kapak ve üstündeki boşluk tip deneyindeki gibi", kapak > 0, "İç ark deneyi belirli bir tavan yüksekliği ve tahliye düzeniyle yapılır (TS EN 62271-200 madde 6.106); kapağın üstü kapatılırsa sınıf geçerliliğini yitirir — " + HUCRE, "resmi"),
        C("Basınç tepesi sınırlı mı?", f"{fnum(tepe, 2)} bar", "≲ 1 bar (mahfazanın dayanımı tip deneyiyle belirlidir)", tepe <= 1.0, "Tek hacimli enerji dengesiyle kestirim: 2 mm çelik sac mahfaza için mertebe", "tahmini"),
        C("Mahfaza ve iç arıza önlemleri", "mahfaza ≥ 2 mm çelik sac", "şartname koşulu", None, "Oluşabilecek arkın süresi ve sonuçları sınırlandırılacak, en yüksek koruma derecesi sağlanacaktır — " + HUCRE + " böl. 3.4.2", "resmi"),
        C("Süre kısaltılabilir mi?", f"{kad}: {fnum(e, 1)} MJ", f"ark rölesiyle {fnum(p_ark * 0.07, 1)} MJ", None, "Enerji süreyle doğru orantılıdır; basınç tepesi ise süreden bağımsızdır", "hesap"),
    ]
    girdiler = [
        G("Kısa devre akımı", f"{fnum(ik, 1)} kA", "Kısa devre hesabı: hücrenin barasında", "Ark gücünü ve basıncın yükselme hızını belirler", "P = 3·U(ark)·I"),
        G("Bölme hacmi ve tahliye", f"{fnum(v, 2)} m³ · kapak {fnum(kapak, 2)} m² @ {fnum(p_ac, 2)} bar", "Hücre kataloğu, iç ark deney raporu; montajda tavan yüksekliği", "Basınç tepesi hacimle ters orantılıdır; tahliye alanı tepeyi keser", "dp/dt = (κ−1)·kp·P / V"),
        G("Koruma süresi", f"{t_ms} ms ({kad})", "Röle ayarı + kesici açma süresi", "Enerjiyi, yanmayı ve atılan gazı belirler", "E = P · t"),
    ]
    adimlar = [
        A("Ark gücü", "P = 3 · U(ark) · I", f"3 × {fnum(ua, 0)} V × {fnum(ik, 1)} kA", f"{fnum(p_ark, 1)} MW", "ark gerilimi ≈ 30 V + 12 V/cm — tipik", "tahmini", ["Kısa devre akımı"]),
        A("Basıncın yükselme hızı (kapalı hacim)", "dp/dt = (κ − 1) · kp · P / V", f"0,4 × 0,5 × {fnum(p_ark, 1)} MW / {fnum(v, 2)} m³", f"{fnum(hiz, 0)} bar/s", "sabit hacimde gaza verilen ısı basıncı artırır; kp: gücün gaza geçen payı — tipik", "tahmini", ["Bölme hacmi ve tahliye"]),
        A("Kapağın açılması", "p = p(açma)", f"{fnum(p_ac, 2)} bar / {fnum(hiz, 0)} bar/s", f"{fnum(t_ac, 1)} ms" if t_ac is not None else "açmıyor", "kapak ataleti ihmal", "tahmini"),
        A("Basınç tepesi", "kütle ve enerji dengesi + delik akışı (adım adım)", f"tahliye {fnum(kapak, 2)} m²", f"{fnum(tepe, 2)} bar — {fnum(t_tepe, 0)} ms", "çıkan gaz enerjiyi de götürür", "tahmini"),
        A("Kapıya binen kuvvet", "F = p · A", f"{fnum(tepe, 2)} bar × {fnum(kapi, 1)} m²", f"{fnum(f_kapi, 0)} kN", "1 bar = 100 kN/m² = 10 ton/m²", "hesap"),
    ]
    ayarlar = [
        S("Ark rölesi (ışık + akım)", "≈ 7 ms + kesici 60 ms", "—", "Basınç tepesini değil, sonrasındaki yanmayı keser", "Röle laboratuvarı › Ark koruması", "ikincil"),
        S("Bara koruması / ters kilitleme", "100–150 ms", "—", "Bara arızasında gecikmeyi kısaltır", "Röle laboratuvarı › Ters kilitleme", "ikincil"),
        S("Tahliye kanalı ve tavan boşluğu", "üretici kılavuzundaki en küçük yükseklik", "—", "Gaz, çalışanın bulunduğu yöne değil yukarı ya da kanala atılır", HUCRE),
    ]
    test = [
        T("Montaj denetimi", "Tahliye kapaklarının üstü, tavan yüksekliği, kablo kanalı kapakları, kapı cıvataları", "tip deneyindeki düzenle aynı", "eksik cıvata, açık bırakılan kapak iç ark sınıfını geçersiz kılar"),
        T("İç ark deney raporu", "Üreticiden: akım, süre, erişim tipi, göstergelerin (pamuk bez) tutuşmaması", "16 kA – 1 s, IAC-AFL", "TS EN 62271-200 madde 6.106"),
    ]
    g1 = {"baslik": "Bölme basıncının zamanla değişimi", "x_ad": "Zaman (ms)", "y_ad": "Basınç (bar, atmosfere göre)", "zaman": True, "ymin": 0,
          "seriler": [{"ad": f"tahliye {fnum(kapak, 2)} m²", "renk": "#dc2626", "pts": pts(b["t"], [max(x, 0) for x in b["p"]], 3, adim=10)}] +
                     [{"ad": f"tahliye {fnum(a_, 2)} m²", "renk": rk, "kesik": True, "pts": pts(q["t"], [max(x, 0) for x in q["p"]], 3, adim=10)}
                      for a_, rk in ((0.03, "#7c3aed"), (0.25, "#15803d")) for q in [F.basinc(p_ark, v, sure, p_ac, a_)]],
          "yatay": [{"y": p_ac, "etiket": "kapak açar", "renk": "#94a3b8"}]}
    vs = [0.1 * 1.15 ** k for k in range(0, 25) if 0.1 * 1.15 ** k <= 3.0]
    g2 = {"baslik": "Bölme hacmine göre basınç tepesi", "x_ad": "Bölme hacmi (m³)", "y_ad": "Basınç tepesi (bar)", "logx": True, "ymin": 0,
          "seriler": [{"ad": f"{fnum(q, 0)} kA", "renk": rk, "pts": pts(vs, [F.basinc(3 * ua * q * 1000 / 1e6, x, 150, p_ac if kapak > 0 else 99.0, max(kapak, 1e-6), dt_ms=0.25)["tepe"] for x in vs], 3)}
                      for q, rk in ((ik, "#dc2626"), (ik / 2, "#1a4d8f"))], "isaretler": [{"x": v, "etiket": "bölme"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "ses": [{"ad": "İç ark", "not": "patlama, ardından kükreme", "sure": 1.2, "zarf": "sonen", "tau": 0.25, "taban": 0.35, "siddet": 1.0, "parcalar": [{"f": 60, "a": 1.0}, {"f": 100, "a": 0.8}, {"f": 200, "a": 0.4}], "gurultu": 1.0, "gurultu_f": 700}],
        "anlatim": [
            f"Bölmenin içinde ark yandı: {fnum(p_ark, 0)} MW'lık bir ısı kaynağı, {fnum(v, 2)} m³ havanın ortasında. Hava kapalı hacimde ısıtılınca genleşemez; sıcaklığı da basıncı da birlikte yükselir.",
            f"Kapak kapalıyken basınç saniyede yaklaşık {fnum(hiz, 0)} bar hızla artar. " + (f"Açılma basıncına ({fnum(p_ac, 2)} bar) {fnum(t_ac, 0)} ms'de varılır: kapak açılır ve gaz dışarı akmaya başlar." if t_ac is not None else "Tahliye yolu yok: basınç, mahfaza bir yerinden yırtılana kadar yükselir."),
            f"Çıkan gaz hem kütleyi hem enerjiyi dışarı taşır; içerideki basınç bir tepe yapar ve düşer: {fnum(tepe, 2)} bar, {fnum(t_tepe, 0)} ms'de. Bu tepe ark akımına, hacme ve tahliye alanına bağlıdır; koruma süresine bağlı değildir, çünkü hiçbir kesici bu kadar çabuk açamaz.",
            f"Bu basınç {fnum(kapi, 1)} m²'lik kapıya {fnum(f_kapi, 0)} kN, yani yaklaşık {fnum(f_kapi / 9.81, 1)} tonluk bir kuvvet uygular. Kapı menteşeleri, kilit cıvataları ve sac kalınlığı bunun için boyutlandırılır ve iç ark deneyiyle doğrulanır.",
            "Basınç düştükten sonra ikinci evre başlar: ark yanmaya devam eder, bara ve mahfaza sacı erir ve yanar, sıcak gaz ve erimiş metal tahliye yolundan atılır. Bu evrenin süresini koruma belirler.",
            "İç ark sınıfı (IAC-AFL) şunu söyler: hücrenin önünde ve yanında duran bir kişi, belirtilen akım ve sürede yanan iç arktan zarar görmez. Bu, hücrenin deneydeki gibi kurulmuş olmasına bağlıdır: kapaklar kapalı, cıvatalar tam, tahliye yolu açık.",
        ],
        "dersler": [
            "İç arkta iki ayrı olay vardır: basınç (ilk 10–30 ms) ve yanma (koruma açana kadar).",
            "Basıncı hacim ve tahliye alanı belirler; yanmayı koruma süresi belirler.",
            "1 bar, metrekareye 10 ton demektir: kapı cıvatasının eksik olması ölümcül bir eksiktir.",
            "IAC sınıfı ancak hücre deneydeki gibi kurulduysa geçerlidir: tahliye kapağının üstü kapatılmaz.",
            "TEDAŞ şartnamesi: iç ark dayanımı 16 kA – 1 s, sınıf IAC-AFL.",
        ],
        "tablolar": [{"baslik": "Tahliye alanına göre basınç tepesi (bu akım ve hacim)", "cols": ["Tahliye alanı", "Basınç tepesi", "Tepe zamanı", "Kapıya binen kuvvet"],
                      "rows": [[f"{fnum(a_, 2)} m²" if a_ > 0 else "yok", f"{fnum(q['tepe'], 2)} bar", f"{fnum(q['t_tepe'], 0)} ms" + (" (yükseliyor)" if a_ <= 0 else ""), f"{fnum(q['tepe'] * 1e5 * kapi / 1000, 0)} kN"]
                               for a_ in (0.0, 0.02, 0.05, 0.10, 0.20, 0.40) for q in [F.basinc(p_ark, v, 150, p_ac if a_ > 0 else 99.0, max(a_, 1e-6), dt_ms=0.25)]],
                      "not": "«yok» satırında basınç 150 ms'de hâlâ yükselmektedir: gerçekte mahfaza çok daha önce açılır."}],
    }
