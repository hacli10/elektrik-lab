"""Adalanma: fider kesicisi açtığında santral, fiderde kalan yükle baş başa kalır. Üretim ile yük dengedeyse gerilim ve frekans yerinde durur, koruma olayı fark etmez
ve hat enerjili kalır. Dengesizlik büyüdükçe gerilim ve frekans kayar, korumalar ayırır.

Model: evirici sabit aktif güç basan, reaktif güç vermeyen akım kaynağı; yük paralel R–L–C. Ada gerilimi V′ = V·√(Ppv / Pyük); ada frekansı yükün rezonans frekansı
f′ = f·√(QL / QC). Geçiş zaman sabitleri (gerilim ≈ 30 ms, frekans ≈ 0,1 s + 2·Qf/ω) ve etkin ada tespitinin süresi mertebedir (tahmini).
Dayanak (metinden): TEDAŞ «Dağıtım Tesislerine Bağlanacak Üretim Santralleri İçin Fider Kriterleri» (2008) m.3–4 (yönlü aşırı akım, 81, 27/59; hatta enerji kesildiği anda
adalanma oluşmaması için santral şebekeye hiçbir şekilde elektrik vermeyecek); Lisanssız Elektrik Üretimi Yön. Uygulama Tebliği Ek-2 Tablo-2 (V ≥ %120 → 0,2 s;
%110–%120 → 1,0 s; %50–%88 → 2,0 s; < %50 → 0,2 s; f > 51 Hz ve f < 47 Hz → 0,2 s; ROCOF 0,5–2,5 Hz/s, 0,2 s); TEDAŞ LÜY 50 kWe GES Tip Şartnamesi böl. 2.3 (adalanmanın
önlenmesi). Eviricinin ada tespit deneyi (IEC 62116: dengeli yük, Qf = 1, 2 s içinde ayrılma) bellekten yazıldı (dogrulanacak)."""
from __future__ import annotations

import math

from ..role.ortak import LUY
from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, fsure, lin, num, opt, pts

ID = "adalanma"
BASLIK = "Adalanma"
IKON = "🏝️"
GIRIS = ("Şebeke kesildiğinde santralin de durması gerekir: hat üzerinde çalışan ekip onu enerjisiz sanır, tekrar kapama onu şebekeyle ters fazda buluşturabilir. "
         "Santral şebekenin gittiğini ancak gerilim ve frekans kaydığında anlar. Üretimi ve yükü birbirine yaklaştırın; korumaların göremediği bölgeyi (kör bölge) bulun.")

FID = "TEDAŞ Dağıtım Tesislerine Bağlanacak Üretim Santralleri İçin Fider Kriterleri (2008)"
GES = "TEDAŞ LÜY 50 kWe GES Tip Şartnamesi"
V_SINIR = [(120.0, 1e9, 0.2), (110.0, 120.0, 1.0), (50.0, 88.0, 2.0), (-1.0, 50.0, 0.2)]          # (alt, üst, temizleme süresi)
F_UST, F_ALT, T_F = 51.0, 47.0, 0.2

KONTROLLER = [
    ctl("p_pv", "Santralin o andaki üretimi", "sayi", 800, min=50, max=2000, adim=10, birim="kW"),
    ctl("p_yuk", "Adada kalan yük", "sayi", 600, min=50, max=3000, adim=10, birim="kW"),
    ctl("cos", "Yükün güç katsayısı (endüktif)", "sayi", 0.95, min=0.7, max=1.0, adim=0.01),
    ctl("qc", "Adada kalan kondansatör ve kablo kapasitif gücü", "sayi", 150, min=0, max=1500, adim=10, birim="kvar"),
    ctl("yontem", "Ada tespiti", "sec", "aktif", secenek=opt(("pasif", "Yalnız gerilim ve frekans koruması"), ("rocof", "Gerilim, frekans + frekans değişim hızı (ROCOF)"),
                                                               ("aktif", "Gerilim, frekans + eviricinin etkin ada tespiti"))),
    ctl("rocof", "ROCOF ayarı", "sayi", 1.0, min=0.5, max=2.5, adim=0.1, birim="Hz/s", goster={"yontem": ["rocof"]}),
    ctl("t_tk", "Fiderde tekrar kapama bekleme süresi", "sayi", 0.5, min=0.2, max=10, adim=0.1, birim="s", yardim="Fider kesicisi bu süre sonunda yeniden kapatır"),
]


def yz(x: float) -> str:
    """İşaretli yüzde: +%12 / −%25."""
    return ("+" if x >= 0 else "−") + "%" + fnum(abs(x), 0)


def run(p: dict) -> dict:
    p_pv, p_yuk, cosf, qc, yon, roc, t_tk = num(p, "p_pv", 800), num(p, "p_yuk", 600), num(p, "cos", 0.95), num(p, "qc", 150), str(p.get("yontem", "aktif")), num(p, "rocof", 1.0), num(p, "t_tk", 0.5)
    ql = p_yuk * math.tan(math.acos(min(cosf, 1.0)))
    v_ada = math.sqrt(p_pv / p_yuk) * 100
    rez = ql > 1e-6 and qc > 1e-6
    f_ada = 50 * math.sqrt(ql / qc) if rez else (65.0 if ql > qc else 35.0)
    f_ada = min(max(f_ada, 35.0), 65.0)
    qf = math.sqrt(ql * qc) / p_yuk if rez else 0.0
    tau_f = 0.10 + 2 * qf / (100 * math.pi)
    tau_v = 0.03
    d_p = (p_yuk - p_pv) / p_pv * 100
    d_q = (ql - qc) / p_pv * 100
    # ---- korumaların açma süreleri ----
    t_v = math.inf
    for alt, ust, ts in V_SINIR:
        if alt < v_ada < ust or (ust > 1e8 and v_ada >= alt):
            t_v = ts
    t_f = math.inf
    if f_ada > F_UST:
        t_f = tau_f * math.log((f_ada - 50) / (f_ada - F_UST)) + T_F
    elif f_ada < F_ALT:
        t_f = tau_f * math.log((50 - f_ada) / (F_ALT - f_ada)) + T_F
    dfdt0 = abs(f_ada - 50) / tau_f
    dfdt_ort = abs(f_ada - 50) * (1 - math.exp(-0.2 / tau_f)) / 0.2          # ilk 0,2 s'nin ortalaması
    t_r = 0.2 + 0.1 if (yon == "rocof" and dfdt_ort >= roc) else math.inf
    t_a = min(2.0, 0.3 + 0.5 * max(qf, 0.2)) if yon == "aktif" else math.inf
    adaylar = [("gerilim koruması (27/59)", t_v), ("frekans koruması (81)", t_f), ("ROCOF (81R)", t_r), ("eviricinin etkin ada tespiti", t_a)]
    kim, t_ac = min(adaylar, key=lambda q: q[1])
    ayrildi = not math.isinf(t_ac)
    kor = math.isinf(t_v) and math.isinf(t_f)                                # gerilim ve frekans korumasının kör bölgesi
    # tekrar kapama anındaki faz farkı
    t_son = min(t_ac, t_tk)
    aci = 360 * ((f_ada - 50) * (t_son - tau_f * (1 - math.exp(-t_son / tau_f)))) % 360
    aci = aci if aci <= 180 else 360 - aci
    u_fark = 2 * (v_ada / 100) * math.sin(math.radians(aci) / 2) if not ayrildi or t_ac > t_tk else 0.0
    ters = (not ayrildi) or t_ac > t_tk
    cz = Cizim(900, 320)
    cz.kutu(20, 60, 100, 54, "Şebeke", "TM barası")
    cz.hat("M120,87 H190", "cizgi", w=3)
    cz.hat("M190,87 L226,66", "ariza", w=3); cz.yazi(208, 54, "fider kesicisi açık", "#b91c1c", 10.5, kalin=True, anchor="middle")
    canli = not ayrildi
    cz.hat("M230,87 H700", "L1", hot=canli, w=3)
    cz.yazi(465, 76, "ada: fider enerjili kaldı" if canli else f"santral {fsure(t_ac)} sonra ayrıldı — fider enerjisiz", "#b91c1c" if canli else "#15803d", 12, kalin=True, anchor="middle")
    cz.hat("M360,87 V120", "L1", hot=canli, w=2); cz.direnc(360, 120, "R", hot=canli); cz.toprak(360, 156)
    cz.hat("M430,87 V120", "L1", hot=canli, w=2); cz.bobin(430, 122, ad="L"); cz.toprak(430, 156)
    cz.hat("M500,87 V118", "L1", hot=canli, w=2); cz.kap(500, 118, 132, ad="C"); cz.hat("M500,132 V156", "cizgi", w=2); cz.toprak(500, 156)
    cz.yazi(430, 182, f"yük {fnum(p_yuk, 0)} kW · {fnum(ql, 0)} kvar endüktif · {fnum(qc, 0)} kvar kapasitif", "#334155", 11, anchor="middle")
    cz.kutu(700, 60, 150, 54, "GES eviricileri", f"{fnum(p_pv, 0)} kW · cosφ 1", "normal" if canli else "pasif")
    cz.yazi(40, 214, f"Ada gerilimi %{fnum(v_ada, 0)} · ada frekansı {fnum(f_ada, 1)} Hz" + (" (sınırda kesildi)" if f_ada in (35.0, 65.0) else ""), "#b91c1c" if canli else "#334155", 13, kalin=True)
    cz.yazi(40, 238, f"Güç farkı: aktif {yz(d_p)}, reaktif {yz(d_q)} (üretime göre) · yükün kalite çarpanı Qf = {fnum(qf, 2)}", "#334155", 12)
    cz.yazi(40, 262, ("Gerilim ve frekans sınırların içinde kaldı: klasik korumalar adayı göremiyor (kör bölge)" if kor else f"İlk gören: {kim} — {fsure(t_ac)}"), "#b91c1c" if kor else "#15803d", 12.5, kalin=True)
    cz.yazi(40, 286, (f"Tekrar kapama {fsure(t_tk)} sonra: ada hâlâ enerjili, faz farkı ≈ {fnum(aci, 0)}° → fark gerilimi {fnum(u_fark, 2)} × Un" if ters else f"Tekrar kapama {fsure(t_tk)} sonra: hat enerjisiz, kapama sorunsuz"),
            "#b91c1c" if ters else "#64748b", 12)
    ozet = [
        K("Ada gerilimi", f"%{fnum(v_ada, 0)}", "bad" if v_ada > 120 else "warn" if (v_ada > 110 or v_ada < 88) else "info", "V′ = V · √(Ppv / Pyük)"),
        K("Ada frekansı", f"{fnum(f_ada, 1)} Hz", "warn" if (f_ada > F_UST or f_ada < F_ALT) else "info", "yükün rezonans frekansı"),
        K("Santralin ayrılması", fsure(t_ac) if ayrildi else "ayrılmıyor", "ok" if ayrildi and t_ac <= t_tk else "bad", kim if ayrildi else "ada sürüyor"),
        K("Kör bölge", "içinde" if kor else "dışında", "bad" if kor and yon == "pasif" else "warn" if kor else "ok", "gerilim ve frekans korumasına göre"),
        K("Tekrar kapamada faz farkı", f"≈ {fnum(aci, 0)}°" if ters else "—", "bad" if ters else "ok", f"fark gerilimi {fnum(u_fark, 2)} × Un" if ters else "hat enerjisiz"),
    ]
    kontroller = [
        C("Şebeke kesildiğinde santral ayrılıyor mu?", fsure(t_ac) if ayrildi else "ayrılmıyor: ada sürüyor", "ayrılmalı", ayrildi,
          f"{FID} m.4: dağıtım şirketi hattında enerji kesildiği anda adalanma oluşmaması için üretim santrali dağıtım şebekesine hiçbir şekilde elektrik vermeyecektir", "resmi"),
        C("Santral tekrar kapamadan önce ayrılıyor mu?", fsure(t_ac) if ayrildi else "ayrılmıyor", f"< {fsure(t_tk)} (tekrar kapama bekleme süresi)", ayrildi and t_ac < t_tk,
          "Ada sürerken fider yeniden kapatılırsa iki sistem faz farkıyla birleşir: evirici köprüleri ve döner makineler darbe görür — Röle laboratuvarı › Tekrar kapama, Senkron denetimi", "ikincil"),
        C("Güç dengesi korumaların kör bölgesinin dışında mı?", f"ΔP {yz(d_p)} · ΔQ {yz(d_q)}", "gerilim %88–%110 ve frekans 47–51 Hz dışına çıkmalı", not kor,
          f"{LUY}: gerilim ve frekans bu aralıkta kaldıkça koruma başlamaz. Üretim yüke, yükün endüktif gücü kapasitif güce yakınsa ada bu aralıkta kalır", "resmi"),
        C("Ada gerilimi yükler için tehlikeli mi?", f"%{fnum(v_ada, 0)}" + (f" · {fsure(t_ac)} boyunca" if ayrildi else ""), "≤ %120", v_ada <= 120,
          "Üretim yükten çok büyükse evirici aynı gücü küçük yüke basar: gerilim sıçrar. Koruma 0,2 s içinde ayırsa da bu süre elektronik yüklere zarar verebilir (yük atma aşırı gerilimi)", "ikincil"),
        C("Evirici ada tespit süresi", fsure(t_a) if yon == "aktif" else "etkin tespit yok", "≤ 2 s (IEC 62116 deneyi: dengeli yük, Qf = 1)", (t_a <= 2.0) if yon == "aktif" else None,
          "Etkin yöntemde evirici frekansı ya da reaktif gücü sürekli dürter: şebeke varken etkisizdir, ada kalınca frekans kaçar. Deney koşulu ve süre asıl standartla doğrulanacak", "dogrulanacak"),
    ]
    girdiler = [
        G("Üretim ve yük", f"{fnum(p_pv, 0)} kW üretim · {fnum(p_yuk, 0)} kW yük", "Santral ve fider ölçüleri (öğle ve hafif yük saatleri)", "Aradaki fark ada gerilimini belirler", f"ΔP = {yz(d_p)}"),
        G("Yükün reaktif gücü", f"{fnum(ql, 0)} kvar endüktif (cosφ {fnum(cosf, 2)}) · {fnum(qc, 0)} kvar kapasitif", "Fider ölçüsü; kompanzasyon ve kablo boyları", "Endüktif ve kapasitif gücün oranı ada frekansını belirler",
          f"Qf = √(QL·QC) / P = {fnum(qf, 2)}"),
        G("Koruma ayarları", "V: %88 / %110 / %120 · f: 47 / 51 Hz" + (f" · ROCOF {fnum(roc, 1)} Hz/s" if yon == "rocof" else ""), "Bağlantı görüşü; koruma ayar tutanağı", "Kör bölgenin sınırlarını çizer", LUY),
        G("Tekrar kapama bekleme süresi", fsure(t_tk), "Dağıtım şirketi fider rölesi ayarı", "Santral bu süreden önce ayrılmış olmalı", "hızlı tekrar kapama: 0,3–0,5 s"),
    ]
    adimlar = [
        A("Ada gerilimi", "V′ = V · √(Ppv / Pyük)", f"√({fnum(p_pv, 0)} / {fnum(p_yuk, 0)})", f"%{fnum(v_ada, 0)}", "evirici gücünü sabit tutar; direnç yükte P = V²/R", "hesap", ["Üretim ve yük"]),
        A("Ada frekansı", "f′ = f · √(QL / QC)", f"50 × √({fnum(ql, 0)} / {fnum(qc, 0)})" if rez else "rezonans yok: frekans kaçar", f"{fnum(f_ada, 1)} Hz", "evirici reaktif vermediği için yükün endüktif ve kapasitif gücü eşitlenene kadar frekans kayar", "hesap", ["Yükün reaktif gücü"]),
        A("Gerilim koruması", "Tebliğ Ek-2 Tablo-2", f"%{fnum(v_ada, 0)}", fsure(t_v) if not math.isinf(t_v) else "başlamaz", LUY, "resmi", ["Koruma ayarları"]),
        A("Frekans koruması", "Tebliğ Ek-2 Tablo-2 + geçiş süresi", f"{fnum(f_ada, 1)} Hz · τ ≈ {fnum(tau_f, 2)} s", fsure(t_f) if not math.isinf(t_f) else "başlamaz", LUY + " — geçiş zaman sabiti mertebe", "resmi"),
        A("Frekans değişim hızı", "df/dt ≈ (f′ − 50) / τ", f"({fnum(f_ada, 1)} − 50) / {fnum(tau_f, 2)}", f"başta {fnum(dfdt0, 1)} Hz/s · ilk 0,2 s ortalaması {fnum(dfdt_ort, 1)} Hz/s", "ROCOF ayarı 0,5–2,5 Hz/s (Tebliğ Ek-2)", "tahmini"),
        A("Kör bölgenin sınırları", "ΔP: 1/1,1² − 1 … 1/0,88² − 1 · ΔQ: Qf·((47/50)² − 1) … Qf·((51/50)² − 1)", f"Qf = {fnum(qf, 2)}", f"ΔP −%17 … +%29 · ΔQ {yz(-11.6 * qf)} … {yz(4.0 * qf)}", "gerilim ve frekans sınırlarından", "hesap"),
        A("Tekrar kapamadaki faz farkı", "Δθ = 360° · ∫(f − 50) dt", f"{fsure(t_son)} boyunca", f"≈ {fnum(aci, 0)}°", "fark gerilimi 2·V·sin(Δθ/2)", "hesap", ["Tekrar kapama bekleme süresi"]),
    ]
    ayarlar = [
        S("Gerilim korumaları (27 / 59)", "%88 → 2,0 s · %110 → 1,0 s · %120 → 0,2 s · < %50 → 0,2 s", "Tebliğ Ek-2 Tablo-2", "Büyük aktif güç dengesizliğini görür", LUY, "resmi"),
        S("Frekans korumaları (81)", "47 Hz ve 51 Hz → 0,2 s", "Tebliğ Ek-2 Tablo-2", "Reaktif güç dengesizliğini görür", LUY, "resmi"),
        S("ROCOF / vektör kayması", f"{fnum(roc, 1)} Hz/s · 0,2 s" if yon == "rocof" else "dağıtım şirketi etüdüne göre", "0,5–2,5 Hz/s", "Kör bölgeyi daraltır; şebeke olaylarında yanlış açabilir", LUY, "resmi"),
        S("Eviricinin etkin ada tespiti", "açık (fabrika ayarı)", "—", "Kör bölgeyi kapatır: denge tam olsa da frekansı kaçırır", f"{GES} böl. 2.3 (adalanmanın önlenmesi)", "resmi"),
        S("Fider koruması (santral fideri)", "yönlü aşırı akım + toprak (67), 81, 27/59", "—", "Dağıtım tarafındaki fider kriteri", f"{FID} m.3", "resmi"),
        S("Hat enerjili kilitlemesi", "hatta gerilim varken hat kesicisi ve toprak bıçağı kapatılamaz", "—", "Adaya kapamayı ve enerjili hattı topraklamayı önler", f"{FID} m.5–6", "resmi"),
    ]
    test = [
        T("Ada tespit deneyi", "Santral üretimdeyken bağlantı kesicisi açılır", "eviriciler 2 s içinde durur", "üretim ≈ yük koşulu sahada zor kurulur: evirici tip deney raporu istenir"),
        T("Gerilim ve frekans kademeleri", "Sekonder enjeksiyon seti ile röleye", "Tebliğ sürelerinde açma", "Röle laboratuvarı › Gerilim, Frekans, ROCOF"),
        T("Hat enerjili göstergesi", "Santral çalışırken şebeke tarafı açılır", "«hat enerjili» lambası söner", "sönmüyorsa ada sürüyor demektir"),
    ]
    ts = lin(0, 3, 61)
    fs = [50 + (f_ada - 50) * (1 - math.exp(-q / tau_f)) if q <= t_ac else None for q in ts]
    vs = [100 + (v_ada - 100) * (1 - math.exp(-q / tau_v)) if q <= t_ac else None for q in ts]
    g1 = {"baslik": "Kesici açtıktan sonra ada frekansı", "x_ad": "Süre (s)", "y_ad": "Frekans (Hz)",
          "seriler": [{"ad": "ada frekansı", "renk": "#dc2626", "pts": [[round(a, 3), round(b, 3)] for a, b in zip(ts, fs) if b is not None]}],
          "yatay": [{"y": F_UST, "etiket": "51 Hz", "renk": "#b45309"}, {"y": F_ALT, "etiket": "47 Hz", "renk": "#b45309"}],
          "isaretler": ([{"x": min(t_ac, 3), "etiket": "ayrılma"}] if ayrildi and t_ac <= 3 else []) + ([{"x": t_tk, "etiket": "tekrar kapama"}] if t_tk <= 3 else [])}
    g2 = {"baslik": "Kesici açtıktan sonra ada gerilimi", "x_ad": "Süre (s)", "y_ad": "Gerilim (% Un)", "ymin": 0,
          "seriler": [{"ad": "ada gerilimi", "renk": "#1a4d8f", "pts": [[round(a, 3), round(b, 2)] for a, b in zip(ts, vs) if b is not None]}],
          "yatay": [{"y": 120, "etiket": "%120", "renk": "#dc2626"}, {"y": 110, "etiket": "%110", "renk": "#b45309"}, {"y": 88, "etiket": "%88", "renk": "#b45309"}],
          "isaretler": ([{"x": min(t_ac, 3), "etiket": "ayrılma"}] if ayrildi and t_ac <= 3 else [])}
    q1, q2 = -11.64 * max(qf, 0.05), 4.04 * max(qf, 0.05)
    g3 = {"baslik": "Kör bölge: gerilim ve frekans korumasının göremediği güç farkları", "x_ad": "Aktif güç farkı ΔP (% üretim)", "y_ad": "Reaktif güç farkı ΔQ (% üretim)",
          "seriler": [{"ad": "kör bölgenin sınırı", "renk": "#b45309", "pts": [[-17.4, q1], [29.1, q1], [29.1, q2], [-17.4, q2], [-17.4, q1]]},
                      {"ad": "bu durum", "renk": "#dc2626", "nokta": True, "pts": [[round(min(max(d_p, -90), 200), 1), round(min(max(d_q, -150), 150), 1)]]}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1, g2, g3],
        "anlatim": [
            "Şebeke bağlıyken gerilimi ve frekansı şebeke tutar: santral ne kadar üretirse üretsin ikisi de yerinden oynamaz. Fider kesicisi açtığında bu çapa kalkar. Santral, fiderde kalan yükle baş başa kalır: bir ada.",
            f"Evirici gücünü sabit tutmaya çalışan bir akım kaynağıdır. {fnum(p_pv, 0)} kW'ı {fnum(p_yuk, 0)} kW'lık yüke basar: yük direnç gibi davrandığı için gerilim, güçlerin oranının kareköküyle değişir — %{fnum(v_ada, 0)}. "
            + ("Üretim yükten fazla: gerilim yükselir." if v_ada > 102 else "Üretim yükten az: gerilim düşer." if v_ada < 98 else "Üretim ve yük dengede: gerilim yerinde kalır."),
            (f"Frekansı reaktif güç belirler. Evirici reaktif vermez; adadaki endüktif yük ({fnum(ql, 0)} kvar) gereksinimini ancak kondansatörlerden ve kablo kapasitesinden ({fnum(qc, 0)} kvar) alabilir. İkisi eşit değilse frekans, eşitlenecekleri noktaya — yükün rezonans frekansına — kayar: {fnum(f_ada, 1)} Hz."
             if rez else "Adada rezonans devresi kuracak kapasite ya da endüktans yok: frekansı tutacak hiçbir şey kalmaz ve hızla kaçar. Bu, tespit açısından en kolay durumdur."),
            (f"Bu örnekte gerilim ve frekans sınırların içinde kalıyor: %88–%110 ve 47–51 Hz. Gerilim ve frekans koruması için hiçbir şey olmamıştır. Bu duruma kör bölge denir; üretim yüke, endüktif güç kapasitif güce yakın oldukça içine düşülür. Kompanzasyonlu bir fiderde, öğle saatinde bu hiç de uzak bir olasılık değildir."
             if kor else f"Burada denge yeterince bozuk: {kim} {fsure(t_ac)} içinde ayırıyor."),
            ("Etkin ada tespiti bu yüzden vardır. Evirici frekansı ya da reaktif gücü sürekli, küçük adımlarla dürter. Şebeke bağlıyken bu dürtmenin etkisi olmaz — şebeke çok güçlüdür. Ada kalınca aynı dürtme frekansı kaydırır, kayma dürtmeyi büyütür ve frekans birkaç yüz milisaniyede sınırın dışına çıkar."
             if yon == "aktif" else "ROCOF, frekansın kendisine değil değişim hızına bakar: kör bölgeyi daraltır ama kapatmaz, şebekedeki büyük olaylarda da yanlış açabilir. Röle üreticileri bu işlevi şebeke kaybı tespiti için önermez."
             if yon == "rocof" else "Yalnız gerilim ve frekans korumasıyla kör bölge açıktır: denge tutarsa ada dakikalarca sürebilir."),
            (f"Adanın sürmesi iki tehlike doğurur. Birincisi insan: hattı enerjisiz sanan ekip. İkincisi tekrar kapama: fider {fsure(t_tk)} sonra yeniden kapatıldığında ada şebekeden {fnum(aci, 0)}° kaymıştır; iki sistem arasındaki fark gerilimi {fnum(u_fark, 2)} × Un'dir ve bu gerilim evirici köprülerine ve motorlara darbe olarak biner."
             if ters else f"Santral {fsure(t_ac)} içinde ayrıldığı için tekrar kapama ({fsure(t_tk)}) enerjisiz hatta yapılır: sorun yok."),
            "Dağıtım tarafında da önlem alınır: santral fiderinde yönlü aşırı akım, frekans ve gerilim röleleri; hat enerjiliyken kesicinin ve toprak bıçağının kapatılmasını engelleyen kilitleme; «hat enerjili» göstergesi.",
        ],
        "dersler": [
            "Ada gerilimini aktif güç dengesi, ada frekansını reaktif güç dengesi belirler.",
            "Üretim ≈ yük ve QL ≈ QC ise gerilim ve frekans koruması adayı göremez: kör bölge.",
            "Eviricinin etkin ada tespiti kör bölgeyi kapatır; ROCOF yalnız daraltır.",
            "Santral tekrar kapamadan önce ayrılmış olmalıdır: aksi halde iki sistem faz farkıyla birleşir.",
            "Üretim yükten çok büyükse ada gerilimi sıçrar: yük atma aşırı gerilimi.",
        ],
        "tablolar": [{"baslik": "Korumaların bu durumdaki açma süreleri", "cols": ["Koruma", "Gördüğü büyüklük", "Açma süresi", "Dayanak"],
                      "rows": [["Gerilim (27 / 59)", f"%{fnum(v_ada, 0)}", fsure(t_v) if not math.isinf(t_v) else "başlamaz", "Tebliğ Ek-2 Tablo-2"],
                               ["Frekans (81)", f"{fnum(f_ada, 1)} Hz", fsure(t_f) if not math.isinf(t_f) else "başlamaz", "Tebliğ Ek-2 Tablo-2"],
                               ["ROCOF (81R)", f"{fnum(dfdt_ort, 1)} Hz/s", (fsure(t_r) if not math.isinf(t_r) else "başlamaz") if yon == "rocof" else "kullanılmıyor", "Tebliğ Ek-2 (0,5–2,5 Hz/s)"],
                               ["Etkin ada tespiti", f"Qf = {fnum(qf, 2)}", fsure(t_a) if yon == "aktif" else "kullanılmıyor", "evirici tip deneyi"]],
                      "not": "Geçiş süreleri ve etkin tespit süresi mertebedir; gerçek davranış eviricinin denetim yapısına bağlıdır."}],
    }
