"""Tek fazlı motor ve kondansatör: ana sargı tek başına neden kalkamaz; yardımcı sargı ve kondansatör ne yapar; kondansatör olmasaydı, açık devre olsaydı,
kısa devre olsaydı, değeri yanlış olsaydı; merkezkaç anahtar açmasaydı ne olurdu — hangi sargıdan ne akım geçer, hangisi yanar.

Model: motor_model.tek_coz (çift döner alan kuramı, simetrik olmayan iki faz). Motor, kalkıştan çalışma hızına kadar hız hız çözülür; merkezkaç anahtar senkron
hızın %75'inde açar. Parametreler kesirli güçte kondansatörlü bir motorun ders kitabı mertebesindeki değerleridir (tahmini); kondansatör değerleri bu parametrelere
göre seçilmiştir (daimi: anma kaymasında alanı daireye getiren; kalkış: kalkışta yardımcı akımı ≈ 90° öne alan). Gerçek motorda değerler etiketten okunur."""
from __future__ import annotations

import cmath
import math

from . import motor_model as M
from .ortak import A, C, G, K, S, T, TEMEL, Cizim, ctl, fa, fnum, num, opt, pts

ID = "tek_faz_motor"
BASLIK = "Tek fazlı motor ve kondansatör"
IKON = "🔋"
GIRIS = ("Tek fazlı motorun ana sargısı tek başına dönen bir alan üretemez: motor uğuldar ama kalkmaz. Yardımcı sargı ve kondansatör ikinci bir faz yaratır. "
         "Kondansatör olmasaydı, bozulsaydı ya da merkezkaç anahtar açmasaydı ne olurdu? Motor tipini ve arızayı seçin; hangi sargıdan ne akım geçtiğini izleyin.")
TUR = {"daimi": "Daimi kondansatörlü (fan, pompa, çamaşır makinesi)", "kalkis": "Kalkış kondansatörlü + merkezkaç anahtar (kompresör)", "cift": "Kalkış + daimi kondansatörlü",
       "direnc": "Kondansatörsüz, yardımcı sargılı (direnç fazlı)"}
KOND = {"saglam": "Sağlam", "acik": "Yok / açık devre (kopmuş, kurumuş)", "kisa": "Kısa devre (delinmiş)", "yarim": "Kapasitesi yarıya düşmüş (yaşlanmış)", "iki": "İki katı değerde takılmış"}
ANAHTAR = {"saglam": "Sağlam (hızın %75'inde açar)", "yapisik": "Kontak yapışmış (açmıyor)", "acik": "Kapanmıyor (kalkışta yardımcı devre yok)"}
GUC = {0.18: 1.9, 0.37: 3.2, 0.55: 4.3, 0.75: 5.4, 1.1: 7.5, 1.5: 9.8, 2.2: 13.5}             # kW → anma akımı (A, 230 V; tipik)
DIRENC = dict(M.TEK, a=0.75, r1a=0.55, x1a=0.07)                                               # direnç fazlı motorun yardımcı sargısı: az sarım, ince tel
N_ANAHTAR = 0.75

KONTROLLER = [
    ctl("tur", "Motor tipi", "sec", "daimi", secenek=opt(*TUR.items())),
    ctl("kond", "Kondansatörün durumu", "sec", "saglam", secenek=opt(*KOND.items()), goster={"tur": ["daimi", "kalkis", "cift"]}),
    ctl("anahtar", "Merkezkaç anahtarın durumu", "sec", "saglam", secenek=opt(*ANAHTAR.items()), goster={"tur": ["kalkis", "cift", "direnc"]}),
    ctl("yuk", "Yük momenti (çalışma hızında)", "sayi", 80, min=0, max=150, adim=5, birim="%", yardim="Anma momentinin yüzdesi"),
    ctl("yuk_tip", "Yükün türü", "sec", "fan", secenek=opt(("fan", "Hızla artan (fan, santrifüj pompa): kalkışta hafif"), ("sabit", "Sabit (kompresör, konveyör): kalkışta da tam"))),
    ctl("u", "Şebeke gerilimi", "sayi", 100, min=75, max=110, adim=1, birim="%"),
    ctl("pn", "Motor gücü", "sec", 0.75, secenek=opt(*[(k, f"{str(k).replace('.', ',')} kW") for k in GUC])),
]


def devre(tur: str, kond: str, anahtar: str, n: float) -> tuple:
    """Bu hızda yardımcı devrenin durumu: (par, yardımcı bağlı mı, seri empedans, kısa açıklama)."""
    par = DIRENC if tur == "direnc" else M.TEK
    anahtarli = tur in ("kalkis", "cift", "direnc")
    kapali = (anahtar == "yapisik") or (anahtar == "saglam" and n < N_ANAHTAR) if anahtarli else True
    if anahtar == "acik" and anahtarli:
        kapali = False
    kat = {"saglam": 1.0, "yarim": 2.0, "iki": 0.5}.get(kond, 1.0)          # reaktans çarpanı
    if tur == "direnc":
        return par, kapali, None, "yardımcı sargı doğrudan" if kapali else "yalnız ana sargı"
    if kond == "acik":
        return par, False, None, "kondansatör açık devre: yalnız ana sargı"
    if kond == "kisa":
        if tur == "daimi" or kapali or tur == "cift":
            return par, True, 0j, "kondansatör kısa devre: yardımcı sargı doğrudan şebekede"
        return par, False, None, "yalnız ana sargı"
    if tur == "daimi":
        return par, True, complex(0, -M.XC_DAIMI * kat), "daimi kondansatör devrede"
    if tur == "kalkis":
        return (par, True, complex(0, -M.XC_KALKIS * kat), "kalkış kondansatörü devrede") if kapali else (par, False, None, "anahtar açtı: yalnız ana sargı")
    xk, xd = M.XC_KALKIS * kat, M.XC_DAIMI * kat                             # cift
    return (par, True, complex(0, -xk * xd / (xk + xd)), "kalkış + daimi kondansatör devrede") if kapali else (par, True, complex(0, -xd), "anahtar açtı: daimi kondansatör devrede")


def coz(tur: str, kond: str, anahtar: str, n: float, u: float) -> dict:
    par, bagli, zc, ack = devre(tur, kond, anahtar, n)
    r = M.tek_coz(par, max(1 - n, 1e-4), zc, u, bagli)
    r["ack"] = ack; r["bagli"] = bagli; r["zc"] = zc
    return r


def ml(yuk: float, n: float, fan: bool) -> float:
    """Yük momenti: fan türünde hızın karesiyle artar (dururken %10'u: sürtünme)."""
    return yuk * (0.1 + 0.9 * n * n) if fan else yuk


def yolal(tur: str, kond: str, anahtar: str, yuk: float, u: float, fan: bool = False) -> dict:
    """Kalkıştan itibaren hız hız: moment yük momentinden büyük kaldıkça hızlanır. Dönen: n (çalışma hızı, pu), kalkti, eğri."""
    mn = M.tek_anma()["m"]
    ns = [k / 250 for k in range(0, 250)]
    egri = [coz(tur, kond, anahtar, n, u) for n in ns]
    ms = [e["m"] / mn for e in egri]
    fark = [m - ml(yuk, n, fan) for m, n in zip(ms, ns)]
    kalkti = fark[0] > 0.02
    k = 0
    if kalkti:
        while k < len(ns) - 1 and fark[k + 1] > 0:
            k += 1
        if k < len(ns) - 1 and fark[k] > 0 >= fark[k + 1] and fark[k] != fark[k + 1]:          # kesişimi doğrusal ara değerle yakala
            n = ns[k] + (ns[k + 1] - ns[k]) * fark[k] / (fark[k] - fark[k + 1])
            return {"n": n, "kalkti": True, "takildi": n < 0.8, "ns": ns, "ms": ms, "egri": egri, "r": coz(tur, kond, anahtar, n, u)}
    return {"n": ns[k], "kalkti": kalkti, "takildi": kalkti and ns[k] < 0.8, "ns": ns, "ms": ms, "egri": egri, "r": egri[k]}


def ozetle(tur: str, kond: str, anahtar: str, yuk: float, u: float, ref: dict, fan: bool = False) -> dict:
    y = yolal(tur, kond, anahtar, yuk, u, fan)
    r = y["r"]
    return {"devrede": bool(r["bagli"]), "m0": y["ms"][0], "n": y["n"], "kalkti": y["kalkti"], "takildi": y["takildi"], "im": abs(r["im"]) / ref["im"], "ia": abs(r["ia"]) / ref["ia"] if ref["ia"] > 0 else 0.0,
            "uc": r["uc"], "hat": abs(r["ihat"]) / ref["hat"], "geri": abs(r["ib"]) / max(abs(r["if"]), 1e-9), "y": y}


def referans(tur: str) -> dict:
    """Sağlam motorun anma yükündeki akımları: ana sargı sürekli; yardımcı sargı daimi tiplerde sürekli, kalkış tiplerinde kalkıştaki (kısa süreli) akım."""
    r = coz(tur, "saglam", "saglam", 0.95, 1.0)                               # sağlam motor, çalışma hızında (kayma 0,05)
    surekli = tur in ("daimi", "cift")
    ia = abs(r["ia"]) if surekli else abs(coz(tur, "saglam", "saglam", 0.0, 1.0)["ia"])
    return {"im": abs(r["im"]), "ia": ia, "hat": abs(r["ihat"]), "n": 0.95, "surekli": surekli}


def sonuc(o: dict, ref: dict) -> tuple:
    """(durum, kısa hüküm)"""
    if not o["kalkti"]:
        return "bad", "kalkamaz: uğuldar, kilitli rotor akımı çeker; ana sargı saniyeler içinde aşırı ısınır"
    if o["takildi"]:
        return "bad", f"yol alır ama hızlanamaz (%{fnum(o['n'] * 100, 0)} hızda kalır); sargılar aşırı ısınır"
    if o["devrede"] and not ref["surekli"]:
        return "bad", "döner ama yardımcı sargı devrede kalır: kısa süre için sarılmış sargı dakikalar içinde yanar"
    if o["ia"] > 1.3:
        return "bad", "döner ama yardımcı sargı aşırı akım çeker ve yanar"
    if o["im"] > 1.15:
        return "warn", "döner ama ana sargı aşırı yüklüdür: ısınır, termik atar"
    return "ok", "kalkar ve olağan çalışır"


def run(p: dict) -> dict:
    tur, kond, anahtar = str(p.get("tur", "daimi")), str(p.get("kond", "saglam")), str(p.get("anahtar", "saglam"))
    if tur == "direnc":
        kond = "saglam"
    if tur == "daimi":
        anahtar = "saglam"
    yuk, u, pn = num(p, "yuk", 80) / 100, num(p, "u", 100) / 100, num(p, "pn", 0.75)
    fan = p.get("yuk_tip", "fan") == "fan"
    i_n = GUC.get(pn, 5.4)
    ref = referans(tur)
    o = ozetle(tur, kond, anahtar, yuk, u, ref, fan); y = o["y"]; r = y["r"]
    d, hukum = sonuc(o, ref)
    amper = i_n / ref["hat"]                                                 # pu → A
    zb = 230 / amper
    c_d = 1e6 / (100 * math.pi * M.XC_DAIMI * zb); c_k = 1e6 / (100 * math.pi * M.XC_KALKIS * zb)
    uc_v = o["uc"] * 230
    ana_isi, yard_isi = o["im"] ** 2, o["ia"] ** 2

    c = Cizim(900, 350)
    c.hat("M40,50 H520", "L1", hot=True, w=3); c.yazi(30, 54, "L", "#8a4b12", 12, kalin=True, anchor="end")
    c.hat("M40,290 H520", "N", w=3); c.yazi(30, 294, "N", "#1d4ed8", 12, kalin=True, anchor="end")
    c.hat("M140,50 V120", "L1", hot=True, w=2.4); c.bobin(140, 120, 6, renk="ariza" if o["im"] > 1.15 else "cizgi"); c.hat("M140,180 V290", "L1", hot=True, w=2.4)
    c.yazi(60, 150, "ana sargı", "#334155", 11.5, kalin=True); c.yazi(60, 168, f"{fa(abs(r['im']) * amper, 1)}", "#b91c1c" if o["im"] > 1.15 else "#15803d", 12.5, kalin=True)
    c.yazi(60, 186, f"anma × {fnum(o['im'], 1)}", "#64748b", 10.5)
    bagli = r["bagli"]
    xk = 360
    c.hat(f"M{xk},50 V80", "L1", hot=bagli, w=2.4)
    yv = 80
    if tur != "direnc":
        if kond == "acik":
            c.kap(xk, yv, yv + 30, "ariza"); c.yazi(xk + 16, yv + 12, "kondansatör AÇIK", "#b91c1c", 10.5, kalin=True)
        elif kond == "kisa":
            c.hat(f"M{xk},{yv} v30", "ariza", w=3); c.yazi(xk + 16, yv + 12, "kondansatör KISA DEVRE", "#b91c1c", 10.5, kalin=True)
        else:
            c.kap(xk, yv, yv + 30, "cizgi"); c.yazi(xk + 16, yv + 12, ("daimi " if tur == "daimi" else "kalkış " if tur == "kalkis" else "kalkış ∥ daimi ") + f"kondansatör{'' if kond == 'saglam' else ' — ' + ('yarım' if kond == 'yarim' else '2×')}", "#334155", 10.5)
            c.yazi(xk + 16, yv + 28, f"üstünde {fnum(uc_v, 0)} V", "#b91c1c" if uc_v > 450 else "#334155", 11, kalin=uc_v > 450)
        yv += 30
    if tur != "daimi":
        if (anahtar == "yapisik") or (anahtar == "saglam" and y["n"] < N_ANAHTAR):
            c.hat(f"M{xk},{yv} v26", "ariza" if anahtar == "yapisik" else "cizgi", hot=bagli, w=2.4)
            c.yazi(xk + 16, yv + 16, "anahtar kapalı" + (" (YAPIŞIK)" if anahtar == "yapisik" else ""), "#b91c1c" if anahtar == "yapisik" else "#334155", 10.5, kalin=anahtar == "yapisik")
        else:
            c.hat(f"M{xk},{yv} l14,22", "cizgi", w=2.4); c.yazi(xk + 20, yv + 16, "anahtar açık" + (" (KAPANMIYOR)" if anahtar == "acik" else ""), "#b91c1c" if anahtar == "acik" else "#334155", 10.5, kalin=anahtar == "acik")
        yv += 26
    c.hat(f"M{xk},{yv} V160", "L1", hot=bagli, w=2.4); c.bobin(xk, 160, 6, renk="ariza" if yard_isi > 1.7 else "cizgi"); c.hat(f"M{xk},220 V290", "L1", hot=bagli, w=2.4)
    c.yazi(xk - 16, 190, "yardımcı sargı", "#334155", 11.5, kalin=True, anchor="end"); c.yazi(xk - 16, 208, fa(abs(r["ia"]) * amper, 1), "#b91c1c" if yard_isi > 1.7 else "#15803d" if bagli else "#64748b", 12.5, kalin=True, anchor="end")
    c.yazi(xk - 16, 226, ("devrede değil" if not bagli else f"{'anma' if ref['surekli'] else 'kalkış akımı'} × {fnum(o['ia'], 1)}"), "#64748b", 10.5, anchor="end")
    # alanın biçimi
    ex, ey, er = 740, 150, 78
    c.daire(ex, ey, er + 8, "soluk", w=1, kesik=True)
    fi, bi = r["if"], r["ib"]
    olc = er / max(abs(fi) + abs(bi), 1e-9)
    yol = [fi * cmath.exp(1j * 2 * math.pi * k / 48) + bi * cmath.exp(-1j * 2 * math.pi * k / 48) for k in range(49)]
    c.hat("M" + " L".join(f"{ex + z.real * olc:.1f},{ey - z.imag * olc:.1f}" for z in yol), "mavi", w=2.6)
    c.ok(ex, ey, ex + yol[0].real * olc, ey - yol[0].imag * olc, "ariza", 2)
    c.yazi(ex, ey + er + 30, "alanın biçimi (bu hızda)", "#1d4ed8", 10.5, anchor="middle")
    c.yazi(ex, ey + er + 46, "daire: düzgün · elips: geri alan var · çizgi: dönmez", "#64748b", 9.5, anchor="middle")
    c.yazi(560, 290, f"Kalkış momenti: %{fnum(o['m0'] * 100, 0)} (yük dururken %{fnum(ml(yuk, 0, fan) * 100, 0)})", "#b91c1c" if not o["kalkti"] else "#15803d", 12.5, kalin=True)
    c.yazi(560, 312, ("KALKAMIYOR" if not o["kalkti"] else f"Hız: senkron hızın %{fnum(y['n'] * 100, 1)}'i"), "#b91c1c" if d == "bad" else "#334155", 12.5, kalin=True)
    c.yazi(40, 330, "Sonuç: " + hukum, "#b91c1c" if d == "bad" else "#b45309" if d == "warn" else "#15803d", 12.5, kalin=True)

    ozet = [
        K("Kalkış momenti", f"%{fnum(o['m0'] * 100, 0)}", "bad" if not o["kalkti"] else "ok", f"yük dururken %{fnum(ml(yuk, 0, fan) * 100, 0)} — " + ("kalkar" if o["kalkti"] else "kalkamaz")),
        K("Çalışma hızı", "duruyor" if not o["kalkti"] else f"%{fnum(y['n'] * 100, 1)}", "bad" if not o["kalkti"] or o["takildi"] else "ok", "senkron hıza göre"),
        K("Ana sargı akımı", fa(abs(r["im"]) * amper, 1), "bad" if o["im"] > 1.15 else "ok", f"anma × {fnum(o['im'], 1)} · ısınma × {fnum(ana_isi, 1)}"),
        K("Yardımcı sargı akımı", fa(abs(r["ia"]) * amper, 1) if bagli else "devrede değil", "bad" if yard_isi > 1.7 else "info" if not bagli else "ok",
          (f"{'anma' if ref['surekli'] else 'kalkış akımı'} × {fnum(o['ia'], 1)}" if bagli else "anahtar ya da kondansatör açık")),
        K("Kondansatör gerilimi", f"{fnum(uc_v, 0)} V" if uc_v > 0 else "—", "bad" if uc_v > 450 else "ok" if uc_v > 0 else "info", "şebekeden yüksek olabilir" if uc_v > 230 * u else ""),
    ]
    kontroller = [
        C("Motor kalkabiliyor mu?", f"kalkış momenti %{fnum(o['m0'] * 100, 0)}", f"> dururken yük momenti %{fnum(ml(yuk, 0, fan) * 100, 0)}", o["kalkti"], "Yalnız ana sargıyla ileri ve geri alan eşittir: kalkış momenti sıfırdır. Yardımcı sargı akımı ana sargı akımından ne kadar kaymışsa moment o kadar büyür", "hesap"),
        C("Çalışma hızına çıkabiliyor mu?", "duruyor" if not o["kalkti"] else f"%{fnum(y['n'] * 100, 1)}", "> %80", o["kalkti"] and not o["takildi"], "Moment–hız eğrisi yük doğrusunun üstünde kaldıkça motor hızlanır", "hesap"),
        C("Ana sargı akımı", f"anma × {fnum(o['im'], 2)}", "≤ 1,15", o["im"] <= 1.15, "Sargının ısınması akımın karesiyle artar: 2 kat akım 4 kat ısı", "hesap"),
        C("Yardımcı sargı akımı", ("devrede değil" if not bagli else f"{'anma' if ref['surekli'] else 'kalkış akımı'} × {fnum(o['ia'], 2)}" + ("" if ref["surekli"] else " — sürekli akıyor" if y["n"] > 0.8 else "")), "sürekli tiplerde ≤ 1,3 · kalkış tiplerinde çalışırken devrede olmamalı",
          (o["ia"] <= 1.3) if ref["surekli"] else not bagli, "Kalkış sargısı ve kalkış kondansatörü birkaç saniyelik çalışma için yapılır; devrede kalırsa yanar", "ikincil"),
        C("Kondansatör gerilimi", f"{fnum(uc_v, 0)} V" if uc_v > 0 else "—", "≤ 450 V (daimi kondansatörün tipik anma gerilimi)", (uc_v <= 450) if uc_v > 0 else None, "Kondansatör ile yardımcı sargı seri rezonansa yakın çalışır: kondansatörün üstündeki gerilim şebeke geriliminden yüksektir", "tahmini"),
        C("Alan dairesel mi?", f"geri / ileri = %{fnum(o['geri'] * 100, 0)}", "≈ %0 (daimi kondansatörlü, anma yükünde)", None, "Geri dönen alan momenti azaltır, 100 Hz titreşim ve ek ısı üretir. Yalnız ana sargıyla çalışan motorda hep vardır", "hesap"),
    ]
    girdiler = [
        G("Motor etiketi", f"{str(pn).replace('.', ',')} kW · 230 V · ≈ {fa(i_n, 1)}", "Etiket", "Akımlar ve kondansatör değeri motorun büyüklüğüyle ölçeklenir", "Z(taban) = U / I"),
        G("Kondansatör değeri", (f"daimi ≈ {fnum(c_d, 0)} µF" if tur in ("daimi", "cift") else "") + (" · " if tur == "cift" else "") + (f"kalkış ≈ {fnum(c_k, 0)} µF" if tur in ("kalkis", "cift") else "") + ("yok" if tur == "direnc" else ""),
          "Motor etiketi / kondansatörün üstü; LCR metre ile ölçü", "Yardımcı sargı akımının açısını ve büyüklüğünü belirler", "Xc = 1 / (2π·f·C)"),
        G("Sargı dirençleri", "ana sargı düşük, yardımcı sargı yüksek dirençli", "Multimetre: ortak uç – ana, ortak uç – yardımcı", "Hangi ucun hangi sargı olduğu dirençten anlaşılır; kopuk sargı sonsuz okunur", "R(yardımcı) > R(ana)"),
    ]
    adimlar = [
        A("Yalnız ana sargı", "Mk ∝ |If|²·Re Zf − |Ib|²·Re Zb", "dururken Zf = Zb ve If = Ib", "kalkış momenti = 0", "titreşen alan = zıt yönde dönen iki eşit alan", "hesap", ["Motor etiketi"]),
        A("Yardımcı devre", "Ia = f(V, Z1a + Zc, Zf, Zb)", r["ack"], f"Ia = {fnum(abs(r['ia']) * amper, 1)} A, ana akıma göre {fnum(math.degrees(cmath.phase(r['ia'] / r['im'])) if abs(r['ia']) > 1e-9 else 0, 0)}°", "iki sargının ortak döner alan denklemleri", "hesap", ["Kondansatör değeri"]),
        A("İleri ve geri alan", "If = (Im − j·a·Ia)/2 · Ib = (Im + j·a·Ia)/2", f"a = {fnum((DIRENC if tur == 'direnc' else M.TEK)['a'], 2)}", f"geri / ileri = %{fnum(o['geri'] * 100, 0)}", "iki fazlı simetrili bileşenler", "hesap"),
        A("Kalkış momenti", "bu bağlantıyla, dururken", f"gerilim %{fnum(u * 100, 0)}", f"%{fnum(o['m0'] * 100, 0)} (anma momentine göre)", TEMEL, "hesap"),
        A("Çalışma noktası", "M(n) = M(yük)", f"yük %{fnum(yuk * 100, 0)} ({'hızla artan' if fan else 'sabit'})", "kalkamaz" if not o["kalkti"] else f"hız %{fnum(y['n'] * 100, 1)}", "hızlanma, motor momenti yük momentinin üstünde kaldıkça sürer", "hesap"),
        A("Sargıların ısınması", "P ∝ I²", f"ana × {fnum(o['im'], 2)} · yardımcı × {fnum(o['ia'], 2)}", f"ana × {fnum(ana_isi, 1)} · yardımcı × {fnum(yard_isi, 1)}", "bakır kaybı akımın karesiyle orantılıdır", "hesap"),
    ]
    ayarlar = [
        S("Termik koruyucu (sargıya gömülü ya da harici)", f"≈ {fa(i_n * 1.1, 1)}", "anma akımının 1,05–1,15 katı", "Kalkamayan ya da aşırı yüklenen motoru ayırır; kendiliğinden kapanan tipte motor soğuyunca yeniden dener", "saha pratiği", "ikincil"),
        S("Kondansatör", (f"daimi ≈ {fnum(c_d, 0)} µF / 450 V" if tur in ("daimi", "cift") else "") + (" · " if tur == "cift" else "") + (f"kalkış ≈ {fnum(c_k, 0)} µF / 250–330 V, kısa süreli" if tur in ("kalkis", "cift") else "") + ("—" if tur == "direnc" else ""),
          "etiketteki değer ±%5", "Daimi kondansatör sürekli çalışmaya, kalkış kondansatörü (elektrolitik) saniyelik çalışmaya göredir; biri ötekinin yerine takılmaz", "tipik değerler", "tahmini"),
        S("Merkezkaç anahtar / kalkış rölesi", "senkron hızın ≈ %75'inde açar", "—", "Kalkış sargısını ve kalkış kondansatörünü devreden çıkarır", "tipik", "tahmini"),
    ]
    test = [
        T("Sargı dirençleri", "Enerjisizken multimetreyle üç uç arasında", "ana < yardımcı; ikisinin toplamı üçüncü ölçüye eşit", "sonsuz: sargı kopuk · çok düşük: sarımlar arası kısa devre"),
        T("Kondansatör", "Boşaltıldıktan sonra kapasite ölçer ile", (f"daimi ≈ {fnum(c_d, 0)} µF" if tur in ("daimi", "cift") else f"kalkış ≈ {fnum(c_k, 0)} µF" if tur == "kalkis" else "—") + " (±%5–10)", "şişmiş, sızdırmış ya da kapasitesi düşmüş kondansatör değiştirilir"),
        T("Akımlar", "Pens ampermetreyle ana ve yardımcı uçta, çalışırken", f"ana ≈ {fa(ref['im'] * amper, 1)}" + (f" · yardımcı ≈ {fa(ref['ia'] * amper, 1)}" if ref["surekli"] else " · yardımcı: kalkıştan sonra 0 A"), "yardımcı uçta sürekli akım: anahtar yapışık"),
        T("Kondansatör gerilimi", "Çalışırken kondansatör uçlarında (yalıtılmış proplarla)", f"≈ {fnum(M.tek_coz(M.TEK, 0.05, complex(0, -M.XC_DAIMI))['uc'] * 230, 0)} V" if tur in ("daimi", "cift") else "kalkıştan sonra devre dışı", "şebekeden yüksek çıkması olağandır"),
    ]
    xs = [n * 100 for n in y["ns"]]
    yalniz = [M.tek_coz(M.TEK, max(1 - n, 1e-4), None, u, False)["m"] / M.tek_anma()["m"] for n in y["ns"]]
    g1 = {"baslik": "Moment – hız", "x_ad": "Hız (% senkron hız)", "y_ad": "Moment (% anma)",
          "seriler": [{"ad": "bu bağlantı", "renk": "#dc2626", "pts": pts(xs, [m * 100 for m in y["ms"]], 1)}, {"ad": "yalnız ana sargı", "renk": "#94a3b8", "kesik": True, "pts": pts(xs, [m * 100 for m in yalniz], 1)},
                      {"ad": "yük", "renk": "#15803d", "pts": pts(xs, [ml(yuk, n, fan) * 100 for n in y["ns"]], 1)}],
          "isaretler": ([{"x": N_ANAHTAR * 100, "etiket": "anahtar açar"}] if tur != "daimi" and anahtar == "saglam" else []) + [{"x": y["n"] * 100, "etiket": "çalışma"}]}
    g2 = {"baslik": "Sargı akımları – hız", "x_ad": "Hız (% senkron hız)", "y_ad": "Akım (A)", "ymin": 0,
          "seriler": [{"ad": "ana sargı", "renk": "#1a4d8f", "pts": pts(xs, [abs(e["im"]) * amper for e in y["egri"]], 2)}, {"ad": "yardımcı sargı", "renk": "#b45309", "pts": pts(xs, [abs(e["ia"]) * amper for e in y["egri"]], 2)},
                      {"ad": "hat", "renk": "#111827", "kesik": True, "pts": pts(xs, [abs(e["ihat"]) * amper for e in y["egri"]], 2)}], "isaretler": [{"x": y["n"] * 100, "etiket": "çalışma"}]}
    grafikler = [g1, g2]
    if tur != "direnc":
        grafikler.append({"baslik": "Kondansatör gerilimi – hız", "x_ad": "Hız (% senkron hız)", "y_ad": "Gerilim (V)", "ymin": 0,
                          "seriler": [{"ad": "kondansatör", "renk": "#7c3aed", "pts": pts(xs, [e["uc"] * 230 for e in y["egri"]], 1)}],
                          "yatay": [{"y": 230 * u, "etiket": "şebeke", "renk": "#94a3b8"}, {"y": 450, "etiket": "450 V", "renk": "#dc2626"}]})
    # «ne olurdu?» çizelgesi
    senaryo = [("Sağlam", "saglam", "saglam")]
    if tur != "direnc":
        senaryo += [("Kondansatör yok / açık devre", "acik", "saglam"), ("Kondansatör kısa devre", "kisa", "saglam"), ("Kapasite yarıya düşmüş", "yarim", "saglam"), ("İki katı değerde kondansatör", "iki", "saglam")]
    if tur != "daimi":
        senaryo += [("Merkezkaç anahtar yapışık", "saglam", "yapisik"), ("Merkezkaç anahtar kapanmıyor", "saglam", "acik")]
    satir = []
    for ad, kd, an in senaryo:
        q = ozetle(tur, kd, an, yuk, u, ref, fan)
        satir.append([ad + (" ◀" if (kd, an) == (kond, anahtar) else ""), f"%{fnum(q['m0'] * 100, 0)}", "kalkamaz" if not q["kalkti"] else f"%{fnum(q['n'] * 100, 0)}", f"× {fnum(q['im'], 1)}",
                      "—" if abs(q["y"]["r"]["ia"]) < 1e-9 else f"× {fnum(q['ia'], 1)}", f"{fnum(q['uc'] * 230, 0)} V" if q["uc"] > 0 else "—", sonuc(q, ref)[1]])
    ses = [{"ad": "Olağan çalışma", "not": "düzgün uğultu ve fan sesi", "sure": 2.5, "zarf": "surekli", "siddet": 0.3, "parcalar": [{"f": 100, "a": 0.5}, {"f": 200, "a": 0.2}, {"f": 48, "a": 0.35}], "gurultu": 0.25, "gurultu_f": 900}]
    if not o["kalkti"]:
        ses.append({"ad": "Kalkamayan motor", "not": "yüksek, sabit 100 Hz uğultu; birkaç saniye sonra termik atar", "sure": 3.0, "zarf": "surekli", "siddet": 0.9, "parcalar": [{"f": 100, "a": 1.0}, {"f": 200, "a": 0.45}, {"f": 300, "a": 0.25}, {"f": 50, "a": 0.3}]})
    elif o["geri"] > 0.3:
        ses.append({"ad": "Geri alanlı çalışma", "not": "uğultu belirgin, motor titrer", "sure": 3.0, "zarf": "surekli", "siddet": 0.55, "vuru": 4, "parcalar": [{"f": 100, "a": 1.0}, {"f": 200, "a": 0.3}, {"f": 47, "a": 0.3}], "gurultu": 0.2, "gurultu_f": 900})
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": grafikler, "ses": ses,
        "anlatim": [
            "Ana sargının alanı kendi ekseni boyunca titreşir. Bu alan, zıt yönde dönen iki eşit alanın toplamıdır: duran rotoru iki yöne eşit kuvvetle çeker. Motor uğuldar, kilitli rotor akımı çeker ama dönmez.",
            "Rotor bir yöne çevrilirse durum değişir: o yönde dönen alana göre kayma küçülür, ötekine göre büyür. İleri alanın momenti baskın çıkar ve motor yol alır. Bu yüzden tek fazlı motor dönerken ana sargısıyla çalışmaya devam edebilir.",
            ("Kalkış için ikinci bir sargı 90° yana yerleştirilir ve akımı zamanda kaydırılır. Kondansatör yardımcı sargının akımını öne alır: iki sargının akımları arasındaki açı 90°'ye yaklaşır ve alan dönmeye başlar."
             if tur != "direnc" else "Direnç fazlı motorda kondansatör yoktur: yardımcı sargı ince telle az sarımlıdır, direnci yüksektir. Akımı ana sargıya göre yalnız 20–30° kayar; alan yassı bir elipstir, kalkış momenti düşüktür ama küçük yükler için yeter."),
            {"daimi": "Daimi kondansatörlü motorda kondansatör hep devrededir ve küçüktür: çalışma hızında alanı daireye yaklaştırır, kalkışta ise yardımcı akım küçük kalır. Kalkış momenti düşüktür: fan ve pompa gibi hafif kalkan yükler içindir.",
             "kalkis": "Kalkış kondansatörü büyüktür: dururken yardımcı sargıya büyük ve iyi kaymış bir akım verir, moment yüksektir. Bu sargı ve elektrolitik kondansatör yalnız birkaç saniye taşıyabilir; merkezkaç anahtar hızın %75'inde ikisini de devreden çıkarır.",
             "cift": "Kalkışta iki kondansatör paraleldir (büyük kapasite, yüksek moment); anahtar açınca yalnız küçük daimi kondansatör kalır (düzgün alan, düşük akım). Kompresör gibi ağır kalkan ve sürekli çalışan yüklerde kullanılır.",
             "direnc": "Yardımcı sargı yüksek akım yoğunluğuyla çalışır ve birkaç saniyeden fazla devrede kalamaz; merkezkaç anahtar onu ayırır."}[tur],
            f"Şimdiki durum: {r['ack']}. {hukum[0].upper() + hukum[1:]}.",
            ("Kondansatör açık devreyse yardımcı sargıdan akım geçmez: motor yalnız ana sargılı bir motordur. Dururken kalkamaz ve ana sargı kilitli rotor akımıyla ısınır; dönerken devreden çıkarsa daha düşük momentle ve daha yüksek akımla dönmeye devam eder."
             if kond == "acik" else "Kondansatör kısa devreyse yardımcı sargı doğrudan şebekeye bağlanır: akımı ana sargıyla neredeyse aynı fazdadır, alan döndürmez; üstelik sargıyı sınırlayan kondansatör reaktansı kalmadığı için akım çok büyür. Yanan, yardımcı sargıdır."
             if kond == "kisa" else "Kapasite düştükçe yardımcı akım küçülür: alan elipsleşir, kalkış ve devrilme momenti düşer, ana sargı daha çok akım çeker. Yaşlanan kondansatörün ilk belirtisi «motor zor kalkıyor, ısınıyor» şikâyetidir."
             if kond == "yarim" else "Büyük kondansatör kalkışı kolaylaştırır ama çalışma hızında yardımcı sargıyı aşırı yükler ve kondansatör gerilimini yükseltir: «daha büyüğü daha iyi» değildir."
             if kond == "iki" else "Anahtar açmazsa kalkış sargısı ve kalkış kondansatörü devrede kalır: ikisi de saniyelik çalışmaya göre yapılmıştır, dakikalar içinde yanar ya da patlar."
             if anahtar == "yapisik" else "Anahtar kapanmıyorsa kalkışta yardımcı devre yoktur: motor yalnız ana sargıyla kalkmaya çalışır ve kalkamaz."
             if anahtar == "acik" else "Aşağıdaki çizelge aynı motorda kondansatörün ve anahtarın her arızasında ne olacağını gösterir."),
        ],
        "dersler": [
            "Kondansatör motoru çalıştırmaz; yardımcı sargının akımını kaydırarak alanı döndürür.",
            "Kondansatörsüz (ya da kondansatörü açık) motor dururken kalkamaz, dönerken dönmeye devam eder.",
            "Kısa devre kondansatörde yanan yardımcı sargıdır; kalkamayan motorda yanan ana sargıdır.",
            "Kondansatörün üstündeki gerilim şebeke geriliminden yüksektir: 230 V motorda 400–450 V'luk kondansatör kullanılmasının nedeni budur.",
            "Kalkış kondansatörü ve kalkış sargısı saniyelik çalışır; merkezkaç anahtar yapışırsa ikisi de gider.",
            "Dönüş yönü, yardımcı sargının uçları (ya da kondansatörün bağlandığı uç) değiştirilerek tersine çevrilir.",
        ],
        "tablolar": [{"baslik": f"Ne olurdu? — {TUR[tur].split(' (')[0]}, yük %{fnum(yuk * 100, 0)} ({'fan türü' if fan else 'sabit'})", "cols": ["Durum", "Kalkış momenti", "Hız", "Ana sargı", "Yardımcı sargı", "Kondansatör gerilimi", "Sonuç"], "rows": satir,
                      "not": "Akımlar sağlam motorun değerlerinin katıdır: ana sargı için anma yükündeki akım, yardımcı sargı için " + ("anma yükündeki akım." if ref["surekli"] else "kalkıştaki (kısa süreli) akım.")}],
    }
