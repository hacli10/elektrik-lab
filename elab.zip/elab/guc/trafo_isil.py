"""Trafonun ısınması, aşırı yük ve ömür: ön yükten sonra belirli süre aşırı yük; üst yağ ve sargı sıcak nokta sıcaklığının zamanla değişimi,
ihbar / açma eşiklerine varış süresi, tüketilen ömür, bu ön yük ve ortamda izin verilen aşırı yük süreleri.

Yağlı tipler: IEC 60076-7 fark denklemleri (üst yağ + sıcak nokta). Denklemler açık erişimli bir yayından alınmıştır; standardın dağıtım trafosu için
verdiği katsayılar (x 0,8 · y 1,6 · k11 1,0 · k21 1,0 · k22 2,0 · τo 180 dk · τw 4 dk) ve yük sınırları (olağan çevrimsel 1,5 pu / 120 °C / 105 °C; uzun acil
1,8 / 140 / 115; kısa acil 2,0 / — / 115) asıl metinden teyit edilmemiştir (dogrulanacak). Anma artışları: üst yağ 60 K (TEDAŞ sınırı), sıcak nokta yağın
18 K üstünde (20 °C ortamda 98 °C: yaşlanma hızı 1). Kuru tip: sargı sıcak noktası tek zaman sabitiyle (45 dk, tahmini), anma artışı 115 K (40 °C ortamda 155 °C);
PT100 ölçüm noktası sıcak noktadan soğuktur (anma artışı ≈ 90 K, tahmini); ihbar 130 °C,
açma 150 °C, fan 100 / 80 °C (Siemens kılavuzu). Yağlı trafonun termometre ayarları (90 / 100 °C) tipik değerdir (tahmini)."""
from __future__ import annotations

from . import trafo_model as M
from .ortak import A, C, G, IEC7, IEC7_ACIK, IEC12, K, S, SIEMENS_K, T, TEDAS_G, TEDAS_H, Cizim, ctl, fnum, num, pts, tr_al, tr_ctl, tr_girdi

ID = "trafo_isil"
BASLIK = "Isınma, aşırı yük ve ömür"
IKON = "🌡"
GIRIS = ("Trafo anma gücünün üstünde ne kadar süre çalışabilir? Cevap yükün yüzdesine değil, o andaki yağ ve sargı sıcaklığına bağlıdır: önceki yük, ortam sıcaklığı "
         "ve aşırı yükün süresi birlikte belirler. Ön yükü, aşırı yükü ve süreyi değiştirin; sıcaklıkların eşiklere ne zaman vardığını ve ne kadar ömür tüketildiğini izleyin.")

KONTROLLER = tr_ctl() + [
    ctl("ta", "Ortam sıcaklığı", "sayi", 30, min=-25, max=50, adim=1, birim="°C", yardim="Trafo odasında ölçülen hava sıcaklığı; şartname sınırı 40 °C, günlük ortalama 35 °C"),
    ctl("on", "Ön yük (aşırı yükten önce)", "sayi", 70, min=0, max=100, adim=5, birim="%"),
    ctl("asiri", "Aşırı yük", "sayi", 130, min=50, max=200, adim=5, birim="%"),
    ctl("sure", "Aşırı yükün süresi", "sayi", 2.0, min=0.25, max=12, adim=0.25, birim="saat"),
    ctl("fan", "Kuru tip › fan var", "onay", True, goster={"tip": ["kuru"]}),
]
T0 = 60.0          # aşırı yük başlangıcı (dk)


def profil(on: float, asiri: float, sure_dk: float):
    return lambda t: asiri if T0 <= t < T0 + sure_dk else on


def izinli_sure(tip: str, on: float, k: float, ta: float, r: float, sn_sinir: float, yag_sinir: float | None, fan: bool) -> float | None:
    """Ön yükten sonra k yükünde sınırlar aşılmadan çalışılabilecek süre (dk); 24 saatte aşılmıyorsa None."""
    b = M.benzet(tip, lambda t: k, ta, r, 1440, 2.0, bas=_bas(tip, on, ta, r), fan_oto=fan)
    t1 = M.ilk_gecis(b["t"], b["pt"] if tip == "kuru" else b["sn"], sn_sinir)
    t2 = M.ilk_gecis(b["t"], b["yag"], yag_sinir) if yag_sinir is not None else None
    ts = [x for x in (t1, t2) if x is not None]
    return min(ts) if ts else None


def _bas(tip: str, on: float, ta: float, r: float) -> dict:
    if tip == "kuru":
        return {"d": M.KURU["d_hr"] * on ** M.KURU["q"]}
    c = M.YAG
    return {"yag": ta + c["d_or"] * ((1 + r * on * on) / (1 + r)) ** c["x"], "d1": c["k21"] * c["d_hr"] * on ** c["y"], "d2": (c["k21"] - 1) * c["d_hr"] * on ** c["y"]}


def sure_yaz(t) -> str:
    if t is None:
        return "sürekli"
    if t < 1:
        return "hemen"
    return f"{fnum(t, 0)} dk" if t < 120 else f"{fnum(t / 60, 1)} saat"


def run(p: dict) -> dict:
    tr = tr_al(p)
    tip = "kuru" if tr["tip"] == "kuru" else "yag"
    ta, on, asiri, sure = num(p, "ta", 30), num(p, "on", 70) / 100, num(p, "asiri", 130) / 100, num(p, "sure", 2.0) * 60
    fan = bool(p.get("fan", True)) and tip == "kuru"
    r = tr["pk"] / tr["p0"]
    toplam = max(600.0, T0 + sure + 360)
    b = M.benzet(tip, profil(on, asiri, sure), ta, r, toplam, 2.0, fan_oto=fan)
    sn_max = max(b["sn"]); pt_max = max(b["pt"]); yag_max = max(x for x in b["yag"]) if tip == "yag" else None
    if tip == "kuru":
        ihbar, acma, sinir, sinir_ad = M.KURU_IHBAR, M.KURU_ACMA, 155.0, "F sınıfı sıcak nokta sınırı"
        t_ihbar = M.ilk_gecis(b["t"], b["pt"], ihbar); t_acma = M.ilk_gecis(b["t"], b["pt"], acma)
    else:
        ihbar, acma = M.YAG_IHBAR, M.YAG_ACMA
        sinir, sinir_ad = M.SINIR_YAG["olagan"][1], "olağan çevrimsel yükleme sıcak nokta sınırı"
        t_ihbar = M.ilk_gecis(b["t"], b["yag"], ihbar); t_acma = M.ilk_gecis(b["t"], b["yag"], acma)
    t_sinir = M.ilk_gecis(b["t"], b["sn"], sinir)
    omur = b["omur"][-1]; olagan = toplam / 60
    sur = M.surekli(tip, asiri, ta, r, fan=fan)
    k_sur = M.izinli_k(tip, ta, r, 145.0 if tip == "kuru" else 98.0)        # anma sıcak nokta sıcaklığını aşmayan sürekli yük
    ts = lambda t: None if t is None else t - T0                                                                    # noqa: E731 — aşırı yükün başından itibaren
    c = Cizim(900, 300)
    if tip == "yag":
        c.dikdortgen(60, 60, 240, 200, "cizgi", "#fef9c3", kw=2.4)
        c.dikdortgen(140, 100, 80, 140, "cizgi", "#fff"); c.yazi(180, 175, "sargı", "#475569", 10.5, anchor="middle")
        c.daire(180, 120, 9, "ariza", "#fecaca"); c.yazi(196, 124, f"sıcak nokta {fnum(sn_max, 0)} °C", "#b91c1c", 11.5, kalin=True)
        c.hat("M70,74 H290", "uyari", w=3); c.yazi(74, 54, f"üst yağ {fnum(yag_max, 0)} °C (en yüksek)", "#b45309", 11.5, kalin=True)
        c.cihaz(330, 40, f"{fnum(yag_max, 0)} °C", "termometre (üst yağ)", ok=yag_max < ihbar)
        c.yazi(330, 116, f"ihbar {fnum(ihbar, 0)} °C · açma {fnum(acma, 0)} °C (tipik ayar)", "#64748b", 10.5)
    else:
        for j in range(3):
            c.dikdortgen(70 + j * 80, 70, 60, 180, "#b45309", "#fde68a", kw=2)
        c.daire(180, 130, 9, "ariza", "#fecaca"); c.yazi(60, 54, f"sargı sıcak noktası {fnum(sn_max, 0)} °C (en yüksek)", "#b91c1c", 11.5, kalin=True)
        c.cihaz(330, 40, f"{fnum(pt_max, 0)} °C", "sıcaklık denetimi (PT100)", ok=pt_max < ihbar)
        c.yazi(330, 116, f"fan {fnum(M.KURU_FAN_AC, 0)} °C · ihbar {fnum(ihbar, 0)} °C · açma {fnum(acma, 0)} °C", "#64748b", 10.5)
        if fan and any(b["fan"]):
            c.kutu(330, 240, 150, 40, "Fan çalıştı", "soğutma arttı", "acti")
    c.yazi(520, 60, f"Ortam {fnum(ta, 0)} °C · ön yük %{fnum(on * 100, 0)}", "#334155", 12)
    c.yazi(520, 82, f"Aşırı yük %{fnum(asiri * 100, 0)} · {sure_yaz(sure)}", "#334155", 12, kalin=True)
    c.yazi(520, 112, "Açma eşiğine varış: " + ("varmıyor" if t_acma is None else sure_yaz(ts(t_acma)) + " sonra"), "#b91c1c" if t_acma is not None else "#15803d", 12.5, kalin=True)
    c.yazi(520, 134, "İhbar eşiğine varış: " + ("varmıyor" if t_ihbar is None else sure_yaz(ts(t_ihbar)) + " sonra"), "#b45309" if t_ihbar is not None else "#15803d", 12)
    c.yazi(520, 164, f"Bu yük sürekli kalsaydı: sıcak nokta {fnum(sur['sn'], 0)} °C", "#334155", 11.5)
    c.yazi(520, 186, f"Tüketilen ömür: {fnum(omur, 1)} saat ({fnum(olagan, 1)} saatte)", "#b91c1c" if omur > 2 * olagan else "#334155", 11.5, kalin=omur > 2 * olagan)
    c.yazi(520, 208, f"Bu ortamda sürekli taşınabilen yük: %{fnum(k_sur * 100, 0)}", "#1a4d8f", 11.5)
    c.yazi(520, 244, "Sıcaklık yükü gecikmeyle izler:", "#64748b", 11); c.yazi(520, 260, "sargı dakikalar, yağ saatler içinde ısınır." if tip == "yag" else "dökme reçineli sargı on dakikalar içinde ısınır.", "#64748b", 11)

    ozet = [
        K("En yüksek sıcak nokta", f"{fnum(sn_max, 0)} °C", "bad" if sn_max > sinir else "warn" if t_ihbar is not None else "ok", f"sınır {fnum(sinir, 0)} °C"),
        K("En yüksek üst yağ", f"{fnum(yag_max, 0)} °C" if tip == "yag" else "—", "info" if tip != "yag" else "bad" if yag_max >= acma else "warn" if yag_max >= ihbar else "ok", "termometre ihbar 90 / açma 100 °C" if tip == "yag" else "kuru tipte yağ yok"),
        K("Açmaya kadar süre", "açmıyor" if t_acma is None else sure_yaz(ts(t_acma)), "bad" if t_acma is not None else "ok", "aşırı yükün başından itibaren" + ("" if tip == "yag" else f" · PT100 en çok {fnum(pt_max, 0)} °C")),
        K("Tüketilen ömür", f"{fnum(omur, 1)} saat", "warn" if omur > 2 * olagan else "ok", f"{fnum(olagan, 1)} saatlik çalışmada · olağan hızın {fnum(omur / olagan, 1)} katı"),
        K("Sürekli taşınabilen yük", f"%{fnum(k_sur * 100, 0)}", "info", f"{fnum(ta, 0)} °C ortamda, ömür kaybetmeden"),
    ]
    if tip == "yag":
        kontroller = [
            C("Sıcak nokta sınırı (olağan çevrimsel yükleme)", f"{fnum(sn_max, 0)} °C", "≤ 120 °C", sn_max <= 120.0, IEC7 + " — dağıtım trafosu sınırı; asıl metinle doğrulanacak", "dogrulanacak"),
            C("Üst yağ sınırı (olağan çevrimsel yükleme)", f"{fnum(yag_max, 0)} °C", "≤ 105 °C", yag_max <= 105.0, IEC7 + " — asıl metinle doğrulanacak", "dogrulanacak"),
            C("Akım sınırı (olağan çevrimsel yükleme)", f"{fnum(max(on, asiri), 2)} pu", "≤ 1,5 pu", max(on, asiri) <= 1.5 + 1e-9, IEC7 + " — asıl metinle doğrulanacak", "dogrulanacak"),
            C("Termometre açma eşiği", f"üst yağ {fnum(yag_max, 0)} °C", f"< {fnum(acma, 0)} °C", yag_max < acma, "Çift kontaklı termometre / çok fonksiyonlu röle: 1. kademe ihbar, 2. kademe açma — " + (TEDAS_G if tr["tip"] == "genlesme" else TEDAS_H) + " böl. 2.3.11; eşik değerleri tipik", "tahmini"),
            C("Anma sıcaklık artışları", "üst yağ 60 K · sargı 65 K", "ortam ≤ 40 °C, günlük ortalama < 35 °C", ta <= 40, tr["kaynak"] + " böl. 2.2.7 ve 1.3.1", "resmi"),
            C("Aşırı yüklemenin dayanağı", "TS 3215 / IEC 60076-7", "şartname bu standarda bağlar", None, tr["kaynak"] + " böl. 2.2.16", "resmi"),
        ]
    else:
        kontroller = [
            C("Sıcak nokta — F sınıfı sınırı", f"{fnum(sn_max, 0)} °C", "≤ 155 °C", sn_max <= 155.0, tr["kaynak"] + " böl. 2.2.9 (yalıtım sistemi sıcaklığı)", "resmi"),
            C("Sıcaklık denetimi açma eşiği", f"PT100 {fnum(pt_max, 0)} °C", f"< {fnum(acma, 0)} °C", pt_max < acma, SIEMENS_K + " böl. 7.1 (açma 150 °C, ihbar 130 °C)", "resmi"),
            C("PT100 ile sıcak nokta arasındaki fark", f"PT100 {fnum(pt_max, 0)} °C · sıcak nokta {fnum(sn_max, 0)} °C", "bilgi", None, "Algılayıcı sargının en sıcak yerinde değildir; anma yükünde fark ≈ 25 K alınmıştır", "tahmini"),
            C("Ortam sıcaklığı", f"{fnum(ta, 0)} °C", "≤ 40 °C", ta <= 40, tr["kaynak"] + " böl. 1.3", "resmi"),
            C("Aşırı yüklemenin dayanağı", "IEC 60076-12", "şartname bu standarda bağlar; 10 / 20 / 30 °C eğrileri teklifte istenir", None, tr["kaynak"] + " böl. 2.2.17", "resmi"),
        ]
    girdiler = tr_girdi(tr) + [
        G("Ortam sıcaklığı", f"{fnum(ta, 0)} °C", "Trafo odası / köşk içi termometre", "Bütün sıcaklıklar ortamın üstüne eklenir: 10 °C sıcak ortam, 10 °C sıcak sargı demektir", "θ = θ(ortam) + artış"),
        G("Yük eğrisi", f"ön yük %{fnum(on * 100, 0)} → %{fnum(asiri * 100, 0)}, {sure_yaz(sure)}", "Sayaç yük profili / analizör kaydı", "Aşırı yükün başındaki sıcaklığı ön yük belirler", "K = I / In"),
        G("Isıl zaman sabitleri", "yağ 180 dk · sargı 4 dk" if tip == "yag" else "sargı ≈ 45 dk", "Isınma deney raporu; yoksa standart varsayılanı", "Sıcaklığın yüke ne kadar gecikmeyle yetişeceğini belirler", "dθ/dt = (hedef − θ) / τ"),
    ]
    if tip == "yag":
        c7 = M.YAG
        adimlar = [
            A("Kayıp oranı", "R = Pk / P0", f"{fnum(tr['pk'], 0)} / {fnum(tr['p0'], 0)}", fnum(r, 1), "yük kaybının boşta kayba oranı: toplam kaybın yükle nasıl arttığını verir", "hesap", ["Kayıplar"]),
            A("Üst yağın sürekli artışı", "Δθo = Δθor · [(1 + R·K²) / (1 + R)]^x", f"60 × [(1 + {fnum(r, 1)} × {fnum(asiri, 2)}²) / (1 + {fnum(r, 1)})]^0,8", f"{fnum(sur['yag'] - ta, 0)} K → {fnum(sur['yag'], 0)} °C", IEC7_ACIK + " denk. 1; x = 0,8 doğrulanacak", "dogrulanacak", ["Yük eğrisi", "Ortam sıcaklığı"]),
            A("Sıcak noktanın yağ üstü artışı", "Δθh = Δθhr · K^y", f"18 × {fnum(asiri, 2)}^1,6", f"{fnum(c7['d_hr'] * asiri ** c7['y'], 0)} K → sıcak nokta {fnum(sur['sn'], 0)} °C", IEC7_ACIK + " denk. 10–13; y = 1,6 doğrulanacak", "dogrulanacak"),
            A("Zamanla değişim", "dθo/dt = (hedef − θo) / (k11·τo)", "τo = 180 dk, τw = 4 dk, adım 2 dk", f"{sure_yaz(sure)} sonunda üst yağ {fnum(yag_max, 0)} °C, sıcak nokta {fnum(sn_max, 0)} °C", IEC7_ACIK + " denk. 2, 9", "dogrulanacak", ["Isıl zaman sabitleri"]),
            A("Yaşlanma hızı", "V = 2^((θh − 98) / 6)", f"θh = {fnum(sn_max, 0)} °C", f"en yüksek {fnum(M.yaslanma('yag', sn_max), 1)} kat", IEC7_ACIK + " denk. 6 (ısıl iyileştirilmemiş kâğıt)", "ikincil"),
            A("Tüketilen ömür", "L = ∫ V dt", f"{fnum(olagan, 1)} saatlik benzetim", f"{fnum(omur, 1)} saat", IEC7_ACIK + " denk. 8", "ikincil"),
        ]
    else:
        adimlar = [
            A("Sargı sıcak noktasının sürekli artışı", "Δθ = Δθr · K^1,6" + (" × 0,6 (fan)" if fan else ""), f"115 × {fnum(asiri, 2)}^1,6", f"{fnum(sur['sn'] - ta, 0)} K → {fnum(sur['sn'], 0)} °C", IEC12 + " — üs ve sıcak nokta katsayısı asıl metinle doğrulanacak", "dogrulanacak", ["Yük eğrisi", "Ortam sıcaklığı"]),
            A("Zamanla değişim", "dΔθ/dt = (hedef − Δθ) / τ", "τ ≈ 45 dk (dökme reçineli sargı, tipik)", f"{sure_yaz(sure)} sonunda {fnum(sn_max, 0)} °C", "tek zaman sabitli ısınma", "tahmini", ["Isıl zaman sabitleri"]),
            A("Fan", "100 °C'de girer, 80 °C'de çıkar", "zorlamalı hava artışı ≈ 0,6 katına indirir (tipik)", "çalıştı" if any(b["fan"]) else "çalışmadı", SIEMENS_K + " böl. 7.1 (eşikler); etki tipik", "tahmini"),
            A("Tüketilen ömür", "V = 2^((θh − 145) / 10); L = ∫ V dt", f"{fnum(olagan, 1)} saatlik benzetim", f"{fnum(omur, 1)} saat", "Arrhenius yaklaşımı — sabitler tipik", "tahmini"),
        ]
    ayarlar = ([
        S("Termometre / çok fonksiyonlu röle › ihbar", f"{fnum(ihbar, 0)} °C (üst yağ)", "ayarlanabilir", "Operatöre yükü azaltması için zaman bırakır", "tipik ayar; cihazın kendi kılavuzuna bakılır", "tahmini"),
        S("Termometre / çok fonksiyonlu röle › açma", f"{fnum(acma, 0)} °C (üst yağ)", "ayarlanabilir", "Üst yağ 105 °C sınırına varmadan devre dışı bırakır", "tipik ayar; cihazın kendi kılavuzuna bakılır", "tahmini"),
        S("OG aşırı akım rölesi › termik (49) ya da I>", "≈ 1,1–1,3 × In", "—", "Sıcaklık ölçülmüyorsa aşırı yük akımdan izlenir; ısıl gecikmeyi röle modeller", "Röle laboratuvarı › Termik aşırı yük sayfası", "ikincil"),
    ] if tip == "yag" else [
        S("Sıcaklık denetim cihazı › ihbar", "130 °C", "üretici ayarı", "F sınıfı sınırının 25 °C altında uyarı", SIEMENS_K + " böl. 7.1"),
        S("Sıcaklık denetim cihazı › açma", "150 °C", "üretici ayarı", "Sınıf sıcaklığına (155 °C) varmadan devre dışı", SIEMENS_K + " böl. 7.1"),
        S("Fan › devreye girme / çıkma", "100 °C / 80 °C", "üretici ayarı", "Geçici aşırı yükte soğutmayı artırır", SIEMENS_K + " böl. 7.1"),
    ])
    test = [
        T("Sıcaklık okuma", "Termometre / denetim cihazı göstergesi; yük ve ortam sıcaklığı ile birlikte not edilir", f"bu yükte sürekli rejim: {'üst yağ ' + fnum(sur['yag'], 0) + ' °C' if tip == 'yag' else 'sargı ' + fnum(sur['sn'], 0) + ' °C'}", "aynı yük ve ortamda sıcaklık yıldan yıla artıyorsa soğutma kirlenmiştir"),
        T("İhbar ve açma kontakları", "Termometre ibresi elle eşiğe getirilir (ya da PT100 yerine direnç kutusu bağlanır)", "ihbar kontağı, sonra açma kontağı çalışır; kesici açar", "yılda bir"),
        T("Termal kamera", "AG ve YG bağlantıları, buşingler", "fazlar arası fark birkaç °C'yi geçmemeli", "gevşek bağlantı yerel ısınma yapar; trafo ısıl modeli bunu görmez"),
    ]
    th = [x / 60 for x in b["t"]]
    g1 = {"baslik": "Sıcaklıkların zamanla değişimi", "x_ad": "Zaman (saat)", "y_ad": "Sıcaklık (°C)", "zaman": True,
          "seriler": [{"ad": "sargı sıcak noktası", "renk": "#dc2626", "pts": pts(th, b["sn"], 1)}] + ([{"ad": "üst yağ", "renk": "#b45309", "pts": pts(th, b["yag"], 1)}] if tip == "yag" else []),
          "yatay": [{"y": sinir, "etiket": sinir_ad, "renk": "#dc2626"}, {"y": acma, "etiket": "açma", "renk": "#7c3aed"}, {"y": ihbar, "etiket": "ihbar", "renk": "#d97706"}],
          "isaretler": [{"x": T0 / 60, "etiket": "aşırı yük başlar"}, {"x": (T0 + sure) / 60, "etiket": "biter"}]}
    g2 = {"baslik": "Yük ve tüketilen ömür", "x_ad": "Zaman (saat)", "y_ad": "Yük (pu) · ömür (saat)", "ymin": 0,
          "seriler": [{"ad": "yük (pu)", "renk": "#1a4d8f", "pts": pts(th, b["k"], 2)}, {"ad": "tüketilen ömür (saat)", "renk": "#dc2626", "pts": pts(th, b["omur"], 2)},
                      {"ad": "olağan hızda ömür", "renk": "#94a3b8", "kesik": True, "pts": [[0, 0], [round(th[-1], 2), round(th[-1], 2)]]}]}
    yukler = (1.1, 1.2, 1.3, 1.4, 1.5, 1.75, 2.0)
    if tip == "yag":
        satirlar = [[f"%{int(x * 100)}", sure_yaz(izinli_sure(tip, on, x, ta, r, 120.0, 105.0, False)), sure_yaz(izinli_sure(tip, on, x, ta, r, 140.0, 115.0, False)),
                     sure_yaz(izinli_sure(tip, on, x, ta, r, 1e9, acma, False)), f"{fnum(M.surekli(tip, x, ta, r)['sn'], 0)} °C"] for x in yukler]
        tablo = {"baslik": f"Bu ön yük (%{fnum(on * 100, 0)}) ve ortamda ({fnum(ta, 0)} °C) aşırı yük süreleri", "cols": ["Aşırı yük", "Olağan sınıra kadar (120 / 105 °C)", "Acil sınıra kadar (140 / 115 °C)", "Termometre açmasına kadar", "Sürekli kalırsa sıcak nokta"],
                 "rows": satirlar, "not": "«sürekli»: 24 saat içinde sınıra varılmıyor. 1,5 pu üstü akımlar olağan çevrimsel yüklemenin akım sınırını da aşar. Sınır değerleri IEC 60076-7'dendir (dogrulanacak)."}
    else:
        satirlar = [[f"%{int(x * 100)}", sure_yaz(izinli_sure(tip, on, x, ta, r, ihbar, None, fan)), sure_yaz(izinli_sure(tip, on, x, ta, r, acma, None, fan)), f"{fnum(M.surekli(tip, x, ta, r, fan=fan)['sn'], 0)} °C"] for x in yukler]
        tablo = {"baslik": f"Bu ön yük (%{fnum(on * 100, 0)}) ve ortamda ({fnum(ta, 0)} °C) aşırı yük süreleri" + (" — fanlı" if fan else " — fansız"), "cols": ["Aşırı yük", "İhbara kadar (130 °C)", "Açmaya kadar (150 °C)", "Sürekli kalırsa sıcak nokta"],
                 "rows": satirlar, "not": "Isıl zaman sabiti ve fanın etkisi tipik değerdir; gerçek süreler üreticinin aşırı yük eğrilerinden okunur (şartname bu eğrileri teklifte ister)."}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2], "tablolar": [tablo],
        "anlatim": [
            "Trafoyu sınırlayan akım değil sıcaklıktır. Kayıplar ısıya dönüşür; ısı sargıdan " + ("yağa, yağdan tank yüzeyine, oradan havaya geçer." if tip == "yag" else "doğrudan havaya geçer."),
            ("Sargının bakırı küçük bir kütledir ve dakikalar içinde ısınır; yağ ve tank büyük bir kütledir, saatler içinde ısınır. Aşırı yük başladığında sıcak nokta önce hızla, sonra yağla birlikte yavaşça yükselir."
             if tip == "yag" else "Dökme reçineli sargı tek bir büyük kütledir: yüke on dakikalar içinde yetişir. Yağın sağladığı uzun gecikme burada yoktur; aşırı yük süresi yağlı trafoya göre kısadır."),
            f"Ön yük %{fnum(on * 100, 0)}, ortam {fnum(ta, 0)} °C: aşırı yük başlarken sıcak nokta {fnum(b['sn'][0], 0)} °C. Trafo soğukken aynı aşırı yük çok daha uzun süre taşınır.",
            f"%{fnum(asiri * 100, 0)} yük {sure_yaz(sure)} sürüyor: sıcak nokta {fnum(sn_max, 0)} °C'ye çıkıyor. Bu yük hiç kalkmasaydı {fnum(sur['sn'], 0)} °C'de dengelenirdi.",
            ("Yalıtım kâğıdı sıcaklıkla yaşlanır: sıcak nokta 98 °C'de ömür olağan hızda tükenir, her 6 °C artışta hız iki katına çıkar. " if tip == "yag" else "Reçine yalıtımı sıcaklıkla yaşlanır; sınıf sıcaklığına yaklaştıkça hız katlanarak artar. ")
            + f"Bu çevrimde {fnum(olagan, 1)} saatte {fnum(omur, 1)} saatlik ömür tüketildi.",
            "Aşırı yük bittikten sonra sıcaklık hemen düşmez; " + ("yağ saatlerce sıcak kalır ve ikinci bir aşırı yüke yer bırakmaz." if tip == "yag" else "sargı zaman sabiti kadar bir sürede soğur."),
        ],
        "dersler": [
            "«%130 yükte ne kadar çalışır?» sorusunun tek cevabı yoktur: ön yük, ortam sıcaklığı ve trafonun tipi belirler.",
            "Yağlı trafoda kısa aşırı yükü yağın ısıl kütlesi taşır; kuru tipte bu yedek küçüktür.",
            "Ortam sıcaklığındaki her derece sıcak noktaya aynen eklenir: havalandırması kötü bir trafo odası, trafonun gücünü düşürür.",
            "Sıcak nokta 6 °C artınca yağlı trafonun kâğıt yalıtımı iki kat hızlı yaşlanır; bir günlük ağır aşırı yük haftalarca ömür götürebilir.",
            "Termometre üst yağı gösterir; sargının en sıcak yeri ondan daha sıcaktır ve yüke daha hızlı tepki verir.",
        ],
    }
