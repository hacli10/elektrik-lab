"""Dağıtım trafosu tipleri ve etiket değerleri: hermetik yağlı, genleşme depolu yağlı, kuru tip (dökme reçineli).

Etiketten okunan dört değerden (güç, gerilim, uk, kayıplar) anma akımları, AG kısa devre akımı, verim ve yıllık kayıp enerjisi çıkar.
Değerler TEDAŞ şartnamelerinin toleranssız en yüksek değerleridir (99-032.E hermetik, 95-012.F genleşme depolu, 99-031.B kuru tip); gerçek bir trafonun
değerleri etiketinde ve deney raporunda yazar. Kuru tipte 400 kVA'nın altı şartname kapsamında değildir: değerler oranlanır (tahmini)."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, S, S3, SGB, SIEMENS_K, T, TEDAS_G, TEDAS_H, TEDAS_K, TIP_AD, Cizim, ctl, fa, fnum, num, pts, tr_al, tr_ctl, tr_durum, tr_girdi, trafo

ID = "trafo_tip"
BASLIK = "Trafo tipleri ve etiket"
IKON = "🏷"
GIRIS = ("Aynı güçte üç ayrı trafo: hermetik yağlı, genleşme depolu yağlı ve kuru tip. Hangisinde ne var, kayıpları ve sesi ne kadar, koruma donanımı ne? "
         "Tipi, gücü ve yükü değiştirin; etiketteki dört değerden akımların, kısa devre akımının, verimin ve yıllık kayıp enerjisinin nasıl çıktığını izleyin.")

KONTROLLER = tr_ctl() + [
    ctl("yuk", "Yük", "sayi", 60, min=0, max=130, adim=5, birim="%", yardim="Anma gücünün yüzdesi"),
    ctl("cos", "Yükün güç katsayısı", "sayi", 0.90, min=0.5, max=1.0, adim=0.01),
    ctl("saat", "Yılda yükte çalışma süresi", "sayi", 4000, min=500, max=8760, adim=100, birim="saat", yardim="Kalan sürede trafo enerjili ama boşta sayılır"),
]


def verim(tr: dict, k: float, cosf: float) -> float:
    p2 = k * tr["sn"] * 1000 * cosf
    return p2 / (p2 + tr["p0"] + k * k * tr["pk"]) if p2 > 0 else 0.0


def sema(tr: dict, k: float) -> Cizim:
    tip = tr["tip"]
    c = Cizim(900, 330)
    x0, y0, w, h = 250, 90, 300, 190
    if tip == "kuru":
        c.dikdortgen(x0, y0 - 10, w, 24, "cizgi", "#e2e8f0")                              # üst boyunduruk
        c.dikdortgen(x0, y0 + h - 14, w, 24, "cizgi", "#e2e8f0")
        for j in range(3):
            xb = x0 + 25 + j * 95
            c.dikdortgen(xb, y0 + 18, 60, h - 36, "#b45309", "#fde68a", kw=2)             # dökme reçineli OG sargısı
            c.dikdortgen(xb + 16, y0 + 30, 28, h - 60, "cizgi", "#fff")
            c.yazi(xb + 30, y0 + h / 2 + 4, "L" + str(j + 1), "#78350f", 11, kalin=True, anchor="middle")
        c.yazi(x0 + w / 2, y0 - 22, "çekirdek (boyunduruk)", "#475569", 10, anchor="middle")
        c.yazi(x0 - 8, y0 + 60, "epoksi dökme", "#78350f", 10.5, anchor="end"); c.yazi(x0 - 8, y0 + 74, "OG sargısı", "#78350f", 10.5, anchor="end")
        c.hat(f"M{x0 + 55},{y0 + 40} h-70 v-70", "mavi", kesik=True, w=1.4); c.kutu(100, 20, 130, 40, "PT100 + denetim", "130 °C ihbar · 150 °C açma")
        c.kutu(600, 226, 150, 40, "Fan (seçmeli)", "100 °C'de girer")
        c.ok(600, 246, 560, 246, "mavi", 1.6)
        c.yazi(600, 100, "Hava ile soğur (AN)", "#1d4ed8", 11.5, kalin=True); c.yazi(600, 118, "Yağ yok: yangın yükü düşük (F1)", "#334155", 11)
        c.yazi(600, 136, "Mahfazasız IP00 / mahfazalı IP20", "#334155", 11); c.yazi(600, 154, "Kısmi boşalma ≤ 10 pC", "#334155", 11)
        c.yazi(600, 172, "Kademe: bağlantı köprüleri (enerjisiz)", "#334155", 11)
    else:
        c.dikdortgen(x0, y0, w, h, "cizgi", "#fef9c3", kw=2.4)                            # tank (yağ dolu)
        for j in range(3):
            xb = x0 + 45 + j * 85
            c.dikdortgen(xb, y0 + 40, 44, h - 70, "cizgi", "#fff")
            c.yazi(xb + 22, y0 + h / 2 + 12, "L" + str(j + 1), "#475569", 10.5, anchor="middle")
            c.hat(f"M{xb + 12},{y0} v-34", "cizgi", w=4); c.hat(f"M{xb + 34},{y0} v-18", "cizgi", w=3)
        c.yazi(x0 + 20, y0 - 40, "YG buşingleri", "#475569", 10); c.yazi(x0 + 190, y0 - 24, "AG buşingleri", "#475569", 10)
        c.yazi(x0 + w / 2, y0 + 26, "yalıtım yağı", "#a16207", 11, anchor="middle")
        if tip == "hermetik":
            for j in range(9):
                c.hat(f"M{x0 - 4 - (j % 2) * 14},{y0 + 12 + j * 20} h-14", "cizgi", w=2); c.hat(f"M{x0 + w + 4 + (j % 2) * 14},{y0 + 12 + j * 20} h14", "cizgi", w=2)
            c.yazi(x0 - 40, y0 + h + 22, "dalga duvar: yağ genleşince esner", "#a16207", 10.5, anchor="middle")
            c.kutu(600, 30, 180, 40, "Çok fonksiyonlu röle", "sıcaklık · basınç · gaz · seviye")
            c.hat(f"M600,50 H{x0 + w - 20} V{y0}", "mavi", kesik=True, w=1.4)
            c.dikdortgen(x0 + 14, y0 - 16, 20, 16, "ariza", "#fee2e2"); c.yazi(x0 - 4, y0 - 20, "basınç emniyet valfi", "#b91c1c", 10, anchor="end")
            c.yazi(600, 100, "Tank tamamen dolu, atmosfere kapalı", "#1d4ed8", 11.5, kalin=True); c.yazi(600, 118, "Yağ hava ile temas etmez: yaşlanmaz", "#334155", 11)
            c.yazi(600, 136, "Genleşme kabı ve nem alıcı yok", "#334155", 11); c.yazi(600, 154, "Doldurma tapası açılmaz", "#334155", 11)
            c.yazi(600, 172, "Kademe: enerjisiz, kapaktaki kolla", "#334155", 11)
        else:
            c.dikdortgen(x0 + 150, 18, 190, 34, "cizgi", "#fef9c3", kw=2)                # genleşme kabı
            c.dikdortgen(x0 + 150, 18, 190, 14, "cizgi", "#fff", kw=0.5)
            c.yazi(x0 + 245, 12, "genleşme kabı (yarısı yağ, üstü hava)", "#a16207", 10.5, anchor="middle")
            c.hat(f"M{x0 + 170},52 V{y0}", "cizgi", w=3)
            c.dikdortgen(x0 + 160, 62, 20, 16, "mavi", "#dbeafe"); c.yazi(x0 + 150, 74, "Buchholz", "#1d4ed8", 10.5, anchor="end")
            c.hat(f"M{x0 + 340},30 h30 v40", "cizgi", w=1.6); c.dikdortgen(x0 + 360, 70, 20, 30, "uyari", "#ffedd5")
            c.yazi(x0 + 386, 90, "nem alıcı", "#b45309", 10.5)
            for j in range(5):
                c.dikdortgen(x0 - 60 + j * 11, y0 + 20, 7, h - 40, "cizgi", "#fff", kw=1.2)
            c.yazi(x0 - 34, y0 + h + 4, "radyatör", "#475569", 10, anchor="middle")
            c.kutu(600, 226, 170, 40, "Termometre", "çift kontak: ihbar · açma")
            c.yazi(600, 118, "Yağ genleşince kaba çıkar; kap", "#1d4ed8", 11.5, kalin=True); c.yazi(600, 134, "nem alıcıdan nefes alır", "#1d4ed8", 11.5, kalin=True)
            c.yazi(600, 154, "Nem alıcı tanesi renk değiştirirse yenilenir", "#334155", 11); c.yazi(600, 172, "Buchholz: gaz birikmesi ve yağ akışı", "#334155", 11)
            c.yazi(600, 190, "Yağ seviyesi göstergeden izlenir", "#334155", 11)
    c.kutu(20, 150, 150, 54, "Etiket", f"{fnum(tr['sn'], 0)} kVA · uk %{fnum(tr['uk'], 1)}")
    c.yazi(20, 228, f"I1n = {fa(tr['i1'], 1)}", "#334155", 11.5); c.yazi(20, 246, f"I2n = {fa(tr['i2'], 0)}", "#334155", 11.5)
    c.yazi(20, 264, f"AG'de Ik = {fnum(tr['ik2'] / 1000, 1)} kA", "#b91c1c", 11.5, kalin=True)
    c.yazi(20, 300, f"Şimdi: yük %{fnum(k * 100, 0)} → kayıp {fnum((tr['p0'] + k * k * tr['pk']) / 1000, 2)} kW", "#334155", 11.5)
    return c


def run(p: dict) -> dict:
    tr = tr_al(p)
    k, cosf, saat = num(p, "yuk", 60) / 100, num(p, "cos", 0.9), num(p, "saat", 4000)
    eta = verim(tr, k, cosf)
    k_opt = math.sqrt(tr["p0"] / tr["pk"])
    kayip = tr["p0"] + k * k * tr["pk"]
    e_yil = (tr["p0"] * 8760 + k * k * tr["pk"] * saat) / 1000
    dur = tr_durum(tr)
    uc = [trafo(t, tr["sn"], tr["un"]) for t in ("hermetik", "genlesme", "kuru")]
    kuru = tr["tip"] == "kuru"
    ozet = [
        K("Anma akımları", f"{fa(tr['i1'], 1)} / {fa(tr['i2'], 0)}", "info", f"YG {fnum(tr['un'], 1)} kV / AG 0,4 kV"),
        K("AG'de kısa devre akımı", f"{fnum(tr['ik2'] / 1000, 1)} kA", "warn", f"I2n / uk = {fnum(tr['i2'], 0)} / %{fnum(tr['uk'], 1)} (şebeke sonsuz güçlü)"),
        K("Kayıplar", f"{fnum(tr['p0'], 0)} + {fnum(tr['pk'], 0)} W", "info", "boşta + anma yükünde"),
        K("Verim", f"%{fnum(eta * 100, 2)}", "ok", f"yük %{fnum(k * 100, 0)}, cosφ {fnum(cosf, 2)} · en yüksek verim yükü %{fnum(k_opt * 100, 0)}"),
        K("Ses gücü düzeyi", f"{fnum(tr['lwa'], 0)} dB(A)", "info", "LwA — en yüksek değer"),
    ]
    kontroller = [
        C("Kısa devre empedansı", f"%{fnum(tr['uk'], 1)}", "≤ 630 kVA: %4 (33 kV'ta %4,5) · üstü %6 · kuru tip %6", None, tr["kaynak"] + (" böl. 2.2.7" if kuru else " böl. 2.2.9"), "resmi"),
        C("Kayıplar şartname sınırında mı?", f"P0 {fnum(tr['p0'], 0)} W · Pk {fnum(tr['pk'], 0)} W", "toleranssız en yüksek değerler", None, tr["kaynak"] + (" böl. 2.2.14" if kuru else " böl. 2.2.13"), dur),
        C("Sıcaklık artış sınırı", ("sargı 100 K (F sınıfı, sıcak nokta 155 °C)" if kuru else "sargı 65 K · üst yağ 60 K"), "ortam en çok 40 °C, günlük ortalama < 35 °C", None,
          tr["kaynak"] + (" böl. 2.2.9" if kuru else " böl. 2.2.7"), "resmi"),
        C("Yük anma gücünü aşıyor mu?", f"%{fnum(k * 100, 0)}", "≤ %100 (sürekli)", k <= 1.0 + 1e-9, "Anma gücü, sıcaklık artış sınırları aşılmadan sürekli verilebilen güçtür; üstü «Isınma ve aşırı yük» sayfasında incelenir — " + tr["kaynak"], "resmi"),
        C("Bağlantı grubu", tr["grup"], "≤ 100 kVA Yzn11 · ≥ 160 kVA Dyn11 (yağlı); kuru tip Dyn11", None, tr["kaynak"] + (" böl. 2.2.6" if kuru else " böl. 2.2.8"), "resmi"),
    ]
    girdiler = tr_girdi(tr) + [
        G("Yük ve güç katsayısı", f"%{fnum(k * 100, 0)} · cosφ {fnum(cosf, 2)}", "Sayaç / analizör; AG ana pano", "Yük kaybı akımın karesiyle artar; verim cosφ ile değişir", "Pk(yük) = K² · Pk"),
        G("Yıllık çalışma süresi", f"{fnum(saat, 0)} saat yükte", "Yük eğrisi", "Boşta kayıp 8760 saat, yük kaybı yalnız yükte harcanır", "E = P0·8760 + K²·Pk·t"),
    ]
    adimlar = [
        A("YG anma akımı", "I1n = Sn / (√3 · U1n)", f"{fnum(tr['sn'], 0)} / (1,732 × {fnum(tr['un'], 1)})", fa(tr["i1"], 2), "üç fazlı güç bağıntısı", "hesap", ["Trafo etiketi"]),
        A("AG anma akımı", "I2n = Sn / (√3 · 0,4)", f"{fnum(tr['sn'], 0)} / (1,732 × 0,4)", fa(tr["i2"], 0), "üç fazlı güç bağıntısı", "hesap", ["Trafo etiketi"]),
        A("AG uçlarında kısa devre akımı", "Ik = I2n / uk", f"{fnum(tr['i2'], 0)} / {fnum(tr['uk'] / 100, 3)}", f"{fnum(tr['ik2'] / 1000, 1)} kA", "uk: anma akımını geçirmek için gereken gerilimin yüzdesi; tam gerilimde akım 1/uk katı olur", "hesap", ["Trafo etiketi"]),
        A("Bu yükteki kayıp", "P = P0 + K² · Pk", f"{fnum(tr['p0'], 0)} + {fnum(k, 2)}² × {fnum(tr['pk'], 0)}", f"{fnum(kayip, 0)} W", "boşta kayıp gerilime, yük kaybı akımın karesine bağlıdır", "hesap", ["Kayıplar", "Yük ve güç katsayısı"]),
        A("Verim", "η = P2 / (P2 + P0 + K²·Pk)", f"P2 = {fnum(k * tr['sn'] * cosf, 0)} kW", f"%{fnum(eta * 100, 2)}", "çıkış gücünün giriş gücüne oranı", "hesap"),
        A("En yüksek verim yükü", "K = √(P0 / Pk)", f"√({fnum(tr['p0'], 0)} / {fnum(tr['pk'], 0)})", f"%{fnum(k_opt * 100, 0)}", "boşta kayıp = yük kaybı olduğunda verim en yüksektir", "hesap", ["Kayıplar"]),
        A("Yıllık kayıp enerjisi", "E = P0 · 8760 + K² · Pk · t", f"{fnum(tr['p0'], 0)} × 8760 + {fnum(k * k * tr['pk'], 0)} × {fnum(saat, 0)}", f"{fnum(e_yil, 0)} kWh", "boşta kayıp trafo enerjili olduğu sürece harcanır", "hesap", ["Yıllık çalışma süresi"]),
    ]
    if kuru:
        ayarlar = [
            S("Sargı sıcaklık denetimi (PT100) › ihbar", "130 °C", "üretici ayarı", "F sınıfı yalıtımın sıcak nokta sınırı 155 °C'nin altında uyarı", SIEMENS_K + " böl. 7.1"),
            S("Sargı sıcaklık denetimi › açma", "150 °C", "üretici ayarı", "Sınıf sıcaklığına varmadan trafo devre dışı kalır", SIEMENS_K + " böl. 7.1"),
            S("Fan › devreye girme / çıkma", "100 °C / 80 °C", "üretici ayarı", "Fan ilavesiyle geçici aşırı yük taşınır", SIEMENS_K + " böl. 7.1"),
            S("Koruma sınıfları", "E2 · C2 · F1", "—", "Yoğuşma ve kirlilik, soğuk iklim, yangın davranışı", TEDAS_K + " böl. 1.3"),
        ]
    elif tr["tip"] == "hermetik":
        ayarlar = [
            S("Basınç emniyet valfi", "her güçte bulunur", "—", "Beklenmedik basınç yükselmesinde tankı korur", TEDAS_H + " böl. 2.3.6"),
            S("Çok fonksiyonlu koruma rölesi", "≥ 630 kVA" if tr["sn"] >= 630 else "bu güçte zorunlu değil", "sıcaklık (ihbar, açma) · yağ kaçağı · gaz birikmesi · basınç", "Tek cihazda dört koruma; kontakları OG kesicisine ya da ihbara gider", TEDAS_H + " böl. 2.3.11"),
            S("Termometre cebi ve yağ seviye göstergesi", "≤ 400 kVA" if tr["sn"] <= 400 else "bu güçte röle üstlenir", "—", "Küçük güçlerde röle yerine gözle izleme", TEDAS_H + " böl. 2.3.6"),
            S("Hermetik basınç ayarı", "etikette: doldurma sıcaklığı", "—", "Tank referans sıcaklıkta basınçsızdır; üstünde aşırı, altında eksik basınç", SGB + " böl. 1"),
        ]
    else:
        ayarlar = [
            S("Buchholz rölesi", "≥ 630 kVA, iki kademeli" if tr["sn"] >= 630 else "bu güçte zorunlu değil", "1. kademe ihbar (gaz) · 2. kademe açma (yağ akışı)", "İç arızada oluşan gazı ve yağ hareketini yakalar", TEDAS_G + " böl. 2.3.11"),
            S("Termometre", "≥ 630 kVA, çift kontaklı" if tr["sn"] >= 630 else "termometre cebi", "ihbar · açma", "Üst yağ sıcaklığı izlenir", TEDAS_G + " böl. 2.3.11"),
            S("Manyetik yağ seviye göstergesi", "genleşme kabında", "—", "Seviye yağ sıcaklığıyla yükselir ve düşer", TEDAS_G + " böl. 2.3.8"),
            S("Nem alıcı", "tanelerin 2/3'ü renk değiştirince yenilenir", "—", "Kap nefes alırken havanın nemini tutar", SGB + " böl. 3.3"),
        ]
    test = [
        T("Etiket okuma", "Güç, gerilimler, uk, bağlantı grubu, kademe gerilimleri", f"I2n = {fa(tr['i2'], 0)}, Ik ≈ {fnum(tr['ik2'] / 1000, 1)} kA", "AG ana kesicinin kesme kapasitesi bu akımın üstünde olmalı"),
        T("Boşta çalışma", "AG tarafı açık, YG enerjili; pens ampermetre ile YG akımı", f"anma akımının yüzde birkaçı; kayıp ≈ {fnum(tr['p0'], 0)} W", "boşta akım toleransı +%30"),
        T("Ses", "1 m'den dinleme / ses ölçer", f"ses gücü ≤ {fnum(tr['lwa'], 0)} dB(A); düzgün 100 Hz uğultu", "tıkırtı, çıtırtı, dalgalanan uğultu olağan değildir"),
    ]
    ks = [i / 50 for i in range(1, 66)]
    g1 = {"baslik": "Verim – yük (üç tip, aynı güç)", "x_ad": "Yük (% Sn)", "y_ad": "Verim (%)",
          "seriler": [{"ad": TIP_AD[t["tip"]], "renk": r, "kesik": t["tip"] != tr["tip"], "pts": pts([x * 100 for x in ks], [verim(t, x, cosf) * 100 for x in ks], 3)}
                      for t, r in zip(uc, ("#1a4d8f", "#15803d", "#b45309"))], "isaretler": [{"x": k * 100, "etiket": "yük"}]}
    g2 = {"baslik": "Kayıp – yük", "x_ad": "Yük (% Sn)", "y_ad": "Kayıp (kW)", "ymin": 0,
          "seriler": [{"ad": "toplam", "renk": "#dc2626", "pts": pts([x * 100 for x in ks], [(tr["p0"] + x * x * tr["pk"]) / 1000 for x in ks], 3)},
                      {"ad": "boşta kayıp", "renk": "#64748b", "kesik": True, "pts": [[0, round(tr["p0"] / 1000, 3)], [130, round(tr["p0"] / 1000, 3)]]}],
          "isaretler": [{"x": k_opt * 100, "etiket": "en yüksek verim"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": sema(tr, k).sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"Seçilen trafo {TIP_AD[tr['tip']]}, {fnum(tr['sn'], 0)} kVA. Etiketteki güç, sıcaklık artış sınırları aşılmadan sürekli verilebilen güçtür; akımlar bu güçten ve gerilimden çıkar.",
            f"uk = %{fnum(tr['uk'], 1)}: AG uçları kısa devre edilip YG'ye anma geriliminin bu yüzdesi uygulanınca anma akımı geçer. Tam gerilimde akım 1/uk katına çıkar: {fnum(tr['ik2'] / 1000, 1)} kA.",
            f"Boşta kayıp ({fnum(tr['p0'], 0)} W) çekirdekte oluşur ve trafo enerjili olduğu sürece harcanır. Yük kaybı ({fnum(tr['pk'], 0)} W) sargılarda oluşur ve akımın karesiyle değişir.",
            "Yağlı trafoda yağ hem yalıtkan hem soğutucudur. Hermetik tipte tank tamamen doludur ve atmosfere kapalıdır; yağın genleşmesini dalga duvar esneyerek karşılar. Genleşme depolu tipte yağ kaba yükselir, kap nem alıcıdan nefes alır.",
            "Kuru tipte OG sargısı vakum altında epoksi reçineyle dökülür; soğutma havayladır. Yağ olmadığı için yangın yükü düşüktür ama kayıpları ve sesi yağlı tipten yüksektir; kısmi boşalma düzeyi yalıtımın sağlığını gösterir.",
            "Koruma donanımı tipe göre değişir: hermetikte çok fonksiyonlu röle ve basınç valfi, genleşme depoluda Buchholz ve termometre, kuru tipte sargıya gömülü PT100 ve sıcaklık denetim cihazı.",
        ],
        "dersler": [
            "AG kısa devre akımı = I2n / uk. uk küçüldükçe gerilim düşümü azalır ama kısa devre akımı büyür.",
            "Boşta kayıp 8760 saat harcanır: az yüklü trafoda yıllık kaybın büyük kısmı boşta kayıptır.",
            "En yüksek verim, yük kaybının boşta kayba eşit olduğu yüktedir; dağıtım trafolarında bu %25–40 dolayındadır.",
            "Hermetik trafonun doldurma tapası açılmaz: içeri hava girerse hermetiklik ve basınç ayarı bozulur.",
            "Kuru tip trafoda sıcaklık sargının içinden (PT100) ölçülür; yağlı tipte yağın üstünden.",
        ],
        "tablolar": [{"baslik": f"Üç tipin karşılaştırması ({fnum(tr['sn'], 0)} kVA, {fnum(tr['un'], 1)} kV)", "cols": ["Özellik", "Hermetik yağlı", "Genleşme depolu", "Kuru tip"],
                      "rows": [["Boşta kayıp P0 (W)"] + [fnum(t["p0"], 0) for t in uc], ["Yük kaybı Pk (W)"] + [fnum(t["pk"], 0) for t in uc], ["uk (%)"] + [fnum(t["uk"], 1) for t in uc],
                               ["Ses gücü LwA (dB)"] + [fnum(t["lwa"], 0) for t in uc], ["Sargı sıcaklık artışı"] + ["65 K", "65 K", "100 K (F)"], ["Yalıtım sınıfı"] + [t["sinif"] for t in uc],
                               ["Kayıpların verildiği sıcaklık"] + ["75 °C", "75 °C", "120 °C"], ["Yağın genleşmesi"] + ["dalga duvar esner", "genleşme kabı", "yağ yok"],
                               ["İç arıza koruması"] + ["çok fonksiyonlu röle", "Buchholz", "sargı sıcaklığı (PT100)"], ["Kullanım"] + ["bina içi ve dışı", "bina içi ve dışı", "bina içi"]],
                      "not": "Kayıp, uk ve ses değerleri şartnamelerin toleranssız en yüksek değerleridir." + ("" if uc[2]["kapsam"] else " Kuru tip şartnamesi 400 kVA'dan başlar: bu güçteki kuru tip değerleri oranlanmıştır (tahmini).")}],
    }
