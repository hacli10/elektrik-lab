"""Kompanzasyon: reaktif gücün yerinde üretilmesi; gereken kondansatör gücü; kondansatörün şebekeyle paralel rezonansı ve harmoniklerin büyümesi; reaktörlü kademe;
kondansatörün devreye girme akımı; fazla kompanzasyon.

Bağıntılar temel devre bağıntılarıdır (hesap): Qc = P·(tanφ1 − tanφ2); rezonans mertebesi n = √(Sk″/Qc); reaktörlü kademede akort frekansı f0 = 50/√p; devreye girme akımı
î ≈ √2·In·√(Sk″/Qc). Reaktif enerji sınırları (endüktif %20, kapasitif %15) tarife uygulamasından bellekle (dogrulanacak). Harmonik büyütme katsayısı için sönüm tipiktir (tahmini)."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, guc_sec, num, opt, pts, trafo

ID = "kompanzasyon"
BASLIK = "Kompanzasyon ve rezonans"
IKON = "🔋"
GIRIS = ("Motorların çektiği reaktif güç şebekeden gelmek zorunda değildir: yanlarına konan kondansatör onu yerinde üretir. Ama kondansatör, trafonun endüktansıyla birlikte bir "
         "rezonans devresidir; frekansı bir harmoniğe denk gelirse o harmonik katlanarak büyür. Yükü, kondansatör gücünü ve harmonik akımını değiştirip izleyin.")

KONTROLLER = [
    ctl("sn", "Trafo gücü", "sec", 1000, secenek=guc_sec()),
    ctl("p", "Aktif yük", "sayi", 500, min=10, max=2000, adim=10, birim="kW"),
    ctl("cos1", "Yükün güç katsayısı", "sayi", 0.78, min=0.5, max=0.99, adim=0.01),
    ctl("qc", "Devredeki kondansatör gücü", "sayi", 320, min=0, max=1200, adim=10, birim="kvar"),
    ctl("p_r", "Kademelerdeki reaktör", "sec", 7, secenek=opt((0, "Reaktörsüz"), (5.67, "%5,67 (210 Hz)"), (7, "%7 (189 Hz)"), (14, "%14 (134 Hz)"))),
    ctl("ih", "Yükün 5. harmonik akımı", "sayi", 10, min=0, max=40, adim=1, birim="% I1", yardim="Sürücü ve doğrultucu yüklerinde tipik %20–40; 7. harmonik bunun 0,7'si alınır"),
    ctl("kademe", "En büyük kademe gücü", "sayi", 50, min=5, max=200, adim=5, birim="kvar"),
]
HARM = (5, 7, 11, 13)


def buyutme(n: float, h: int, p_r: float, q_sonum: float = 5.0) -> float:
    """Yükün h. harmonik akımının şebeke tarafında kaç katına çıktığı (paralel devre). n: rezonans mertebesi (reaktörsüz); p_r: reaktör yüzdesi."""
    if p_r > 0:
        hr = 1 / math.sqrt(p_r / 100)                               # seri akort mertebesi
        xc = n * n                                                    # şebeke reaktansına göre kondansatör reaktansı (50 Hz'te): Xc/Xs = n²
        zk = complex(0.05 * xc * h / hr, xc * (h * p_r / 100 - 1 / h)) # kademe: reaktör + kondansatör (pu, Xs = 1)
    else:
        zk = complex(0.02 * n * n / h, -n * n / h)
    zs = complex(h / q_sonum * 0.2, h)                              # şebeke + trafo (Xs = 1 pu at 50 Hz)
    return abs(zk / (zs + zk))


def run(p: dict) -> dict:
    sn, pw, cos1, qc, p_r, ih, kad = num(p, "sn", 1000), num(p, "p", 500), num(p, "cos1", 0.78), num(p, "qc", 320), num(p, "p_r", 7), num(p, "ih", 10) / 100, num(p, "kademe", 50)
    tr = trafo("hermetik", sn, 33.0)
    sk = sn / (tr["uk"] / 100) / 1000                                # MVA (AG barasında, şebeke sonsuz güçlü)
    q1 = pw * math.tan(math.acos(cos1))
    q_net = q1 - qc
    cos2 = pw / math.hypot(pw, q_net)
    kap = q_net < 0
    s1, s2 = math.hypot(pw, q1), math.hypot(pw, q_net)
    i1, i2 = s1 / (math.sqrt(3) * 0.4), s2 / (math.sqrt(3) * 0.4)
    q_gerek = pw * (math.tan(math.acos(cos1)) - math.tan(math.acos(0.98)))
    n = math.sqrt(sk * 1000 / qc) if qc > 0 else 99.0
    ihs = {5: ih, 7: ih * 0.7, 11: ih * 0.3, 13: ih * 0.2}
    buy = {h: buyutme(n, h, p_r) if qc > 0 else 1.0 for h in HARM}
    i_kond = {h: abs(1 - buy[h]) if p_r == 0 else buy[h] for h in HARM}
    thd_u = math.sqrt(sum((ihs[h] * (i2 / tr["i2"]) * buy[h] * h * tr["uk"] / 100) ** 2 for h in HARM)) * 100
    en = max(HARM, key=lambda h: buy[h])
    in_kad = kad / (math.sqrt(3) * 0.4)
    i_gir = math.sqrt(2) * in_kad * math.sqrt(sk * 1000 / kad)
    i_gir_b2b = math.sqrt(2) * in_kad * math.sqrt(max(qc - kad, 1) / kad) * 40 if qc > kad else 0          # paralel kademeler arası: aradaki endüktans çok küçük (≈ 1 µH) → onlarca In
    oran_end, oran_kap = max(q_net, 0) / pw * 100, max(-q_net, 0) / pw * 100
    rez_tehlike = p_r == 0 and qc > 0 and min(abs(n - h) for h in HARM) < 0.7 and ih > 0.03
    c = Cizim(900, 300)
    c.daire(90, 87, 20, "cizgi"); c.daire(116, 87, 20, "cizgi"); c.yazi(103, 52, f"{fnum(sn, 0)} kVA", "#475569", 10.5, anchor="middle")
    c.hat("M136,87 H220", "L1", hot=True, w=3); c.hat("M220,50 V230", "cizgi", w=5); c.yazi(220, 40, "AG bara", "#475569", 10.5, anchor="middle")
    c.yazi(178, 76, fa(i2, 0), "#b91c1c" if kap else "#334155", 11.5, kalin=True, anchor="middle")
    c.hat("M220,100 H330", "cizgi", w=2.4); c.kutu(330, 76, 150, 48, "Yük", f"{fnum(pw, 0)} kW · cosφ {fnum(cos1, 2)}")
    c.hat("M220,190 H300", "cizgi", w=2.4)
    if p_r > 0:
        c.bobin(300, 190, 3, yatay=True, ad=f"%{str(p_r).replace('.', ',')}"); c.hat("M330,190 H350", "cizgi", w=2.4)
    else:
        c.hat("M300,190 H350", "cizgi", w=2.4)
    c.kap(190, 350, 372, "ariza" if rez_tehlike else "cizgi", yatay=True, ad=f"{fnum(qc, 0)} kvar"); c.hat("M372,190 H400", "cizgi", w=2.4); c.toprak(400, 192)
    c.yazi(520, 56, f"cosφ {fnum(cos1, 2)} → {fnum(cos2, 2)}" + (" KAPASİTİF" if kap else ""), "#b91c1c" if kap else "#15803d", 14, kalin=True)
    c.yazi(520, 82, f"Trafo akımı {fa(i1, 0)} → {fa(i2, 0)} (%{fnum(i2 / tr['i2'] * 100, 0)} yüklenme)", "#334155", 12.5)
    c.yazi(520, 106, f"Rezonans mertebesi n = {fnum(n, 1)} ({fnum(n * 50, 0)} Hz)" if qc > 0 and p_r == 0 else f"Akort: {fnum(50 / math.sqrt(p_r / 100), 0)} Hz — 5. harmoniğin altında" if p_r > 0 else "kondansatör yok", "#b91c1c" if rez_tehlike else "#334155", 12.5, kalin=rez_tehlike)
    c.yazi(520, 130, f"{en}. harmonik şebekede × {fnum(buy[en], 1)} büyüyor" if buy[en] > 1.05 else "Harmonikler büyümüyor", "#b91c1c" if buy[en] > 2 else "#334155", 12.5)
    c.yazi(520, 154, f"Gerilimde harmonik bozulma ≈ %{fnum(thd_u, 1)}", "#b91c1c" if thd_u > 8 else "#334155", 12.5)
    c.yazi(520, 184, f"{fnum(kad, 0)} kvar kademe devreye girerken ≈ {fnum(i_gir / in_kad, 0)} × In tepe", "#64748b", 11.5)
    c.yazi(520, 204, "(yanında dolu kademeler varsa çok daha büyük)", "#64748b", 10.5)
    c.yazi(40, 262, f"Hedef cosφ 0,98 için gereken: {fnum(q_gerek, 0)} kvar · şimdi {fnum(qc, 0)} kvar devrede", "#1a4d8f", 12.5, kalin=True)
    ozet = [
        K("Güç katsayısı", f"{fnum(cos2, 2)}" + (" kap." if kap else ""), "bad" if kap or cos2 < 0.95 else "ok", f"kompanzasyonsuz {fnum(cos1, 2)}"),
        K("Reaktif oran", f"%{fnum(oran_kap if kap else oran_end, 0)} " + ("kapasitif" if kap else "endüktif"), "bad" if oran_kap > 15 or oran_end > 20 else "ok", "sınır: endüktif %20 · kapasitif %15"),
        K("Rezonans", f"n = {fnum(n, 1)}" if qc > 0 and p_r == 0 else "reaktörlü" if p_r > 0 else "—", "bad" if rez_tehlike else "ok", f"{fnum(n * 50, 0)} Hz" if qc > 0 and p_r == 0 else f"akort {fnum(50 / math.sqrt(p_r / 100), 0)} Hz" if p_r > 0 else ""),
        K("Harmonik büyütme", f"× {fnum(buy[en], 1)}", "bad" if buy[en] > 2 else "ok", f"{en}. harmonik, şebeke tarafında"),
        K("Trafo akımı", fa(i2, 0), "ok" if i2 <= tr["i2"] else "bad", f"kompanzasyonsuz {fa(i1, 0)}"),
    ]
    kontroller = [
        C("Reaktif oran sınırların içinde mi?", f"endüktif %{fnum(oran_end, 0)} · kapasitif %{fnum(oran_kap, 0)}", "endüktif ≤ %20 · kapasitif ≤ %15", oran_end <= 20 and oran_kap <= 15, "Aylık reaktif / aktif enerji oranı sınırları (tarife uygulaması — sınır değerleri asıl metinle doğrulanacak)", "dogrulanacak"),
        C("Rezonans bir harmoniğe yakın mı?", f"n = {fnum(n, 1)}" if qc > 0 and p_r == 0 else "reaktörlü kademe" if p_r > 0 else "kondansatör yok", "5, 7, 11, 13'ten en az 0,7 uzak ya da reaktörlü", not rez_tehlike, "n = √(Sk″ / Qc): kondansatör gücü ve kademe sayısı değiştikçe rezonans frekansı kayar", "hesap"),
        C("Harmonikler büyüyor mu?", f"{en}. harmonik × {fnum(buy[en], 1)}", "≤ × 2", buy[en] <= 2.0, "Paralel rezonansta yükün harmonik akımı kondansatör ile şebeke arasında dolaşarak büyür — sönüm tipik", "tahmini"),
        C("Gerilimde harmonik bozulma", f"≈ %{fnum(thd_u, 1)}", "≤ %8 (AG şebekesi)", thd_u <= 8.0, "Gerilim kalitesi sınırı (TS EN 50160 — asıl metinle doğrulanacak)", "dogrulanacak"),
        C("Trafo aşırı yüklenmiyor mu?", fa(i2, 0), f"≤ {fa(tr['i2'], 0)}", i2 <= tr["i2"], "Kompanzasyon trafonun akımını düşürür; fazla kompanzasyon yeniden artırır", "hesap"),
    ]
    girdiler = [
        G("Yük", f"{fnum(pw, 0)} kW · cosφ {fnum(cos1, 2)} → Q = {fnum(q1, 0)} kvar", "Analizör, fatura endeksleri", "Gereken kondansatör gücü buradan çıkar", "Qc = P·(tanφ1 − tanφ2)"),
        G("Barada kısa devre gücü", f"{fnum(sk, 1)} MVA", "Trafo gücü ve uk", "Rezonans frekansını belirler", "n = √(Sk″ / Qc)"),
        G("Yükün harmonik akımları", f"5.: %{fnum(ih * 100, 0)} · 7.: %{fnum(ih * 70, 0)}", "Analizör (akım harmonikleri)", "Rezonansı uyaran kaynak", "sürücü, doğrultucu, UPS, LED"),
    ]
    adimlar = [
        A("Gereken kondansatör gücü", "Qc = P · (tanφ1 − tanφ2)", f"{fnum(pw, 0)} × ({fnum(math.tan(math.acos(cos1)), 2)} − {fnum(math.tan(math.acos(0.98)), 2)})", f"{fnum(q_gerek, 0)} kvar (cosφ 0,98 için)", "güç üçgeni", "hesap", ["Yük"]),
        A("Yeni güç katsayısı", "cosφ2 = P / √(P² + (Q − Qc)²)", f"Q − Qc = {fnum(q_net, 0)} kvar", f"{fnum(cos2, 2)}" + (" kapasitif" if kap else ""), "güç üçgeni", "hesap"),
        A("Rezonans mertebesi", "n = √(Sk″ / Qc)", f"√({fnum(sk * 1000, 0)} / {fnum(qc, 0)})" if qc > 0 else "—", f"{fnum(n, 1)} → {fnum(n * 50, 0)} Hz" if qc > 0 else "—", "kondansatör ile şebeke endüktansının paralel rezonansı", "hesap", ["Barada kısa devre gücü"]),
        A("Reaktörlü kademe", "f0 = 50 / √p", f"p = %{str(p_r).replace('.', ',')}" if p_r > 0 else "reaktör yok", f"{fnum(50 / math.sqrt(p_r / 100), 0)} Hz" if p_r > 0 else "—", "akort frekansının altında kademe kapasitif, üstünde endüktiftir: 5. harmonik için rezonans oluşmaz", "hesap"),
        A("Devreye girme akımı", "î ≈ √2 · In · √(Sk″ / Q(kademe))", f"√2 × {fnum(in_kad, 0)} A × √({fnum(sk * 1000, 0)} / {fnum(kad, 0)})", f"{fnum(i_gir, 0)} A tepe ({fnum(i_gir / in_kad, 0)} × In)", "boş kondansatör kısa devre gibidir; akımı şebeke endüktansı sınırlar", "hesap"),
    ]
    ayarlar = [
        S("Reaktif güç rölesi › hedef cosφ", "0,98–1,00 endüktif", "—", "Kapasitif bölgeye geçmeden", "TEDAŞ-MLZ/2024-080 reaktif güç merkezi şartnamesi (ayrıntı asıl metinden)", "ikincil"),
        S("Kademe yapısı", "en küçük kademe ≈ en küçük yük değişimi", "1:1:2:4…", "Avlanmadan (sürekli girip çıkmadan) izleme", "saha pratiği", "ikincil"),
        S("Reaktör", "harmonikli tesiste %7 (189 Hz); 3. harmonik varsa %14", "—", "Rezonansı 5. harmoniğin altına çeker; kondansatör gerilimi 440 V seçilir", "saha pratiği", "ikincil"),
        S("Kondansatör kontaktörü", "ön dirençli", "—", "Devreye girme akımını sınırlar", "saha pratiği", "ikincil"),
        S("Deşarj süresi", "yeniden devreye almadan önce beklenir", "—", "Dolu kondansatör ters fazda bağlanırsa akım iki katına çıkar", "saha pratiği", "ikincil"),
    ]
    test = [T("Kondansatör akımı", "Her kademede pens ampermetre", f"≈ anma akımı ({fa(in_kad, 0)}); 1,3 katını aşmamalı", "yüksekse harmonik çekiyor; düşükse kapasite kaybı"),
            T("Harmonik ölçüsü", "Kademeler devredeyken ve değilken gerilim THD ve 5., 7. akımlar", f"kademeler girince THD artıyorsa rezonans", "rezonans kademe sayısına göre gelir gider"),
            T("Reaktif endeksler", "Aylık endüktif ve kapasitif oran", "≤ %20 / ≤ %15", "gece ve hafta sonu kapasitif kayması izlenir")]
    qs = [10 * k for k in range(1, 121)]
    g1 = {"baslik": "Kondansatör gücüne göre rezonans mertebesi", "x_ad": "Devredeki kondansatör gücü (kvar)", "y_ad": "Rezonans mertebesi n", "ymax": 20,
          "seriler": [{"ad": "n = √(Sk″/Qc)", "renk": "#dc2626", "pts": pts(qs, [min(math.sqrt(sk * 1000 / x), 20) for x in qs], 2)}],
          "yatay": [{"y": h, "etiket": f"{h}. harmonik", "renk": "#94a3b8"} for h in HARM], "isaretler": [{"x": max(qc, 10), "etiket": "şimdi"}]}
    hs = [2 + 0.1 * k for k in range(0, 131)]
    g2 = {"baslik": "Frekansa göre harmonik büyütme (şebeke tarafı)", "x_ad": "Harmonik mertebesi", "y_ad": "Büyütme", "logy": True,
          "seriler": [{"ad": "reaktörsüz", "renk": "#dc2626", "kesik": p_r > 0, "pts": pts(hs, [max(buyutme(n, x, 0), 0.01) for x in hs], 3)}] +
                     ([{"ad": f"%{str(p_r).replace('.', ',')} reaktörlü", "renk": "#15803d", "pts": pts(hs, [max(buyutme(n, x, p_r), 0.01) for x in hs], 3)}] if p_r > 0 else []),
          "yatay": [{"y": 1.0, "etiket": "büyütme yok", "renk": "#94a3b8"}], "isaretler": [{"x": 5, "etiket": "5."}, {"x": 7, "etiket": "7."}]} if qc > 0 else None
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g for g in (g1, g2) if g],
        "anlatim": [
            f"Motorlar ve trafolar manyetik alan kurmak için reaktif güç çeker: burada {fnum(q1, 0)} kvar. Bu güç iş yapmaz ama akım olarak trafodan ve hattan geçer: {fa(i1, 0)}.",
            f"Kondansatör aynı reaktif gücü ters yönde üretir. {fnum(qc, 0)} kvar devredeyken şebekeden çekilen reaktif {fnum(abs(q_net), 0)} kvar'a iner, akım {fa(i2, 0)} olur, cosφ {fnum(cos2, 2)}." + (" Kondansatör yükün ihtiyacından büyük: tesis şebekeye reaktif veriyor, gerilim yükseliyor, kapasitif ceza doğuyor." if kap else ""),
            f"Kondansatör ile trafonun endüktansı paralel bir rezonans devresi oluşturur. Frekansı kondansatör gücüne bağlıdır: şimdi {fnum(n * 50, 0)} Hz ({fnum(n, 1)}. mertebe). Kademeler girip çıktıkça bu frekans gezinir." if qc > 0 else "Kondansatör yokken rezonans da yoktur.",
            ("Yükün harmonik akımı bu frekansa yakınsa devre onu büyütür: harmonik akım kondansatör ile trafo arasında dolaşır, kondansatör aşırı ısınır, gerilim bozulur, sigortalar nedensiz atar. Şimdi " + f"{en}. harmonik {fnum(buy[en], 1)} kat büyüyor."
             if p_r == 0 and qc > 0 else "Her kademeye seri reaktör konunca kademe, akort frekansının üstünde endüktif davranır: 5. ve üstü harmonikler için kondansatör yoktur, rezonans oluşmaz. Bedeli: kondansatörün üstündeki gerilim yükselir, bu yüzden 440 V'luk kondansatör kullanılır." if p_r > 0 else ""),
            f"Boş bir kondansatör devreye girdiği an kısa devre gibidir: akımı yalnız şebekenin endüktansı sınırlar ve anma akımının {fnum(i_gir / in_kad, 0)} katı kadar bir tepe oluşur. Yanında dolu kademeler varsa onlar da bu kademeye boşalır; tepe yüz katı aşabilir. Ön dirençli kontaktör bunun içindir.",
        ],
        "dersler": [
            "Qc = P·(tanφ1 − tanφ2). Fazlası kapasitif cezadır.",
            "Rezonans mertebesi n = √(Sk″/Qc): kademe sayısıyla gezinir; 5 ve 7'ye yaklaşması tehlikelidir.",
            "Harmonikli tesiste kompanzasyon reaktörlü yapılır (%7 → 189 Hz).",
            "Kondansatör akımı anma değerinin 1,3 katını aşıyorsa harmonik çekiyordur.",
            "Kademe, kondansatör boşalmadan yeniden devreye alınmaz.",
        ],
    }
