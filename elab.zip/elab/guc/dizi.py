"""PV dizi boyutlandırma: bir diziye kaç modül, bir MPPT girişine kaç dizi; kışın en yüksek gerilim, yazın en düşük gerilim; dizi sigortası ve dizi kablosu.

Dayanak (metinden): TEDAŞ LÜY 50 kWe GES Tip Şartnamesi — böl. 2.1.2 (DC bileşenler: Voc(STC) × 1,15 ve Isc(STC) × 1,25), böl. 2.1.3 (dizi açık devre gerilimi 1000 V DC'yi
geçerse bina üzerine kurulmaz), böl. 2.1.4.1 (dizi – evirici arası toplam DC gerilim düşümü < %2, STC'de), böl. 2.1.5 (sigortasız N paralel dizide kablo akımı > Isc × (N−1) × 1,25),
böl. 2.1.10.1 ((N−1) × Isc > modülün en büyük seri sigorta değeri ise dizi sigortası; iki kutba; gPV; 1,5 × Isc < In ≤ 2,4 × Isc ve In ≤ en büyük seri sigorta değeri),
böl. 2.3.4.1 (eviricinin DC gerilim aralığı düşük sıcaklıkta bile dizi açık devre gerilimini kapsamalı; MPP gerilim aralığı). PV kablosu: TEDAŞ-MLZ/2015-061 (1,5/1,5 kV DC,
izin verilen en yüksek 1,8 kV; iletken 90 °C). Kablo akım taşıma değerleri TS EN 50618 Tablo A.3 mertebesidir (dogrulanacak). Modül ve evirici değerleri tipiktir (tahmini)."""
from __future__ import annotations

import math

from . import pv_model as PV
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, lin, num, opt, pts

ID = "dizi"
BASLIK = "PV dizi boyutlandırma"
IKON = "🧮"
GIRIS = ("Bir diziye bağlanacak modül sayısını iki sıcaklık belirler: en soğuk sabahta açık devre gerilimi eviricinin dayanacağı gerilimi aşmamalı, en sıcak öğlede çalışma gerilimi "
         "MPPT aralığının altına düşmemelidir. Modül sayısını, paralel dizi sayısını ve sıcaklıkları değiştirin; pencerenin nerede açılıp kapandığını görün.")

GES = "TEDAŞ LÜY 50 kWe GES Tip Şartnamesi"
IZ_PV = {4: 55.0, 6: 70.0, 10: 98.0}             # A — tek kablo, serbest havada (60 °C ortam, 120 °C iletken)
SIG = (15, 20, 25, 30, 32)

KONTROLLER = [
    ctl("modul", "Modül", "sec", "m550", secenek=PV.secenek()),
    ctl("n", "Dizideki modül sayısı", "sayi", 18, min=4, max=40, adim=1),
    ctl("np", "Bir MPPT girişine paralel dizi sayısı", "sayi", 2, min=1, max=6, adim=1),
    ctl("vmax", "Eviricinin en yüksek DC giriş gerilimi", "sec", 1100, secenek=opt((600, "600 V"), (1000, "1000 V"), (1100, "1100 V"), (1500, "1500 V"))),
    ctl("vmp_min", "MPPT aralığının alt gerilimi", "sayi", 200, min=80, max=900, adim=10, birim="V"),
    ctl("imax", "MPPT girişinin en büyük kısa devre akımı", "sayi", 40, min=10, max=120, adim=1, birim="A"),
    ctl("tmin", "Sahanın en düşük sıcaklığı", "sayi", -15, min=-35, max=10, adim=1, birim="°C"),
    ctl("tmax", "Sahanın en yüksek sıcaklığı", "sayi", 40, min=20, max=50, adim=1, birim="°C"),
    ctl("montaj", "Montaj", "sec", "arazi", secenek=opt(("arazi", "Açık arazi"), ("cati", "Bina çatısı (çatıya paralel)"))),
    ctl("sig", "Dizi sigortası", "sec", 0, secenek=opt((0, "Yok")) + opt(*[(v, f"{v} A gPV") for v in SIG])),
    ctl("s", "Dizi kablosu kesiti", "sec", 6, secenek=opt((4, "4 mm²"), (6, "6 mm²"), (10, "10 mm²"))),
    ctl("l", "Dizi kablosu boyu (tek yön)", "sayi", 60, min=5, max=300, adim=5, birim="m"),
]


def run(p: dict) -> dict:
    mk = str(p.get("modul", "m550")); m = PV.MODUL.get(mk, PV.MODUL["m550"])
    n, npar, vmax, vmp_min, imax = int(num(p, "n", 18)), int(num(p, "np", 2)), num(p, "vmax", 1100), num(p, "vmp_min", 200), num(p, "imax", 40)
    tmin, tmax, montaj, sig, s, l = num(p, "tmin", -15), num(p, "tmax", 40), str(p.get("montaj", "arazi")), num(p, "sig", 0), int(num(p, "s", 6)), num(p, "l", 60)
    s = s if s in IZ_PV else 6
    stc = PV.nokta(m, 1000, 25)
    soguk = PV.nokta(m, 1000, tmin)                                # soğuk sabah: hücre = ortam, ışınım tam
    tc_max = PV.hucre_sicakligi(tmax, 1000, m["noct"], 10.0 if montaj == "cati" else 0.0)
    sicak = PV.nokta(m, 1000, tc_max)
    voc_max, vmp_sicak, vmp_soguk = n * soguk["voc"], n * sicak["vmp"], n * soguk["vmp"]
    n_ust = int(vmax // soguk["voc"]); n_alt = int(math.ceil(vmp_min / sicak["vmp"]))
    isc_125 = stc["isc"] * 1.25
    i_ters = (npar - 1) * stc["isc"]
    sig_gerek = i_ters > m["sigorta"]
    iz = IZ_PV[s] * (0.58 if montaj == "cati" else 0.72)              # sıcak ortam ve demet düzeltmesi (mertebe)
    i_kablo = max(isc_125, sig) if sig else max(isc_125, (npar - 1) * isc_125)
    r = 0.0178 * 1.28 / s                                             # Ω/m — bakır, ≈ 90 °C
    du = 2 * l * r * stc["imp"] / (n * stc["vmp"]) * 100
    pk = 2 * l * r * stc["imp"] ** 2
    v_malz = n * stc["voc"] * 1.15
    p_dizi = n * m["pmax"]
    ok_v, ok_alt, ok_i = voc_max <= vmax, vmp_sicak >= vmp_min, npar * isc_125 <= imax
    cz = Cizim(900, 320)
    w = min(26.0, 560.0 / n)
    for k in range(min(npar, 3)):
        y = 56 + k * 34
        for j in range(n):
            cz.dikdortgen(40 + j * w, y, w - 2, 24, "cizgi", "#1e3a8a", kw=0.7, r=2)
        xs = 40 + n * w + 6
        if sig:
            cz.dikdortgen(xs, y + 6, 22, 12, "mor", "#f5f3ff", kw=1.2, r=2)
        cz.hat(f"M{xs + (22 if sig else 0):.0f},{y + 12} H660", "L1", hot=True, w=2)
    if npar > 3:
        cz.yazi(40, 56 + 3 * 34 + 12, f"… toplam {npar} paralel dizi", "#64748b", 10.5)
    cz.hat("M660,60 V160", "L1", hot=True, w=2.5)
    cz.kutu(690, 78, 150, 70, "Evirici — MPPT girişi", f"≤ {fnum(vmax, 0)} V · ≥ {fnum(vmp_min, 0)} V · {fnum(imax, 0)} A", "normal" if (ok_v and ok_alt and ok_i) else "gecersiz")
    cz.hat("M660,112 H690", "L1", hot=True, w=2.5)
    cz.yazi(40, 44, f"{n} × {fnum(m['pmax'], 0)} Wp = {fnum(p_dizi / 1000, 2)} kWp / dizi" + (f" · sigorta {fnum(sig, 0)} A" if sig else " · sigortasız"), "#334155", 11.5, kalin=True)
    cz.yazi(40, 196, f"En soğuk sabah ({fnum(tmin, 0)} °C): açık devre {fnum(voc_max, 0)} V — evirici sınırı {fnum(vmax, 0)} V", "#15803d" if ok_v else "#b91c1c", 13, kalin=True)
    cz.yazi(40, 220, f"En sıcak öğle (hücre {fnum(tc_max, 0)} °C): çalışma gerilimi {fnum(vmp_sicak, 0)} V — MPPT alt sınırı {fnum(vmp_min, 0)} V", "#15803d" if ok_alt else "#b91c1c", 12.5, kalin=True)
    cz.yazi(40, 244, f"İzin verilen modül sayısı: {n_alt} … {n_ust}" if n_alt <= n_ust else "Bu evirici ve bu modülle uygun modül sayısı yok", "#334155", 12)
    cz.yazi(40, 268, f"{npar} dizi × Isc × 1,25 = {fnum(npar * isc_125, 1)} A (giriş {fnum(imax, 0)} A) · ters akım {fnum(i_ters, 1)} A, modül sigorta değeri {fnum(m['sigorta'], 0)} A",
            "#b91c1c" if (not ok_i or (sig_gerek and not sig)) else "#64748b", 12)
    cz.yazi(40, 292, f"Dizi kablosu {s} mm², {fnum(l, 0)} m: gerilim düşümü %{fnum(du, 2)} (sınır %2) · kayıp {fnum(pk, 0)} W", "#b91c1c" if du > 2 else "#64748b", 12)
    ozet = [
        K("En yüksek dizi gerilimi", f"{fnum(voc_max, 0)} V", "ok" if ok_v else "bad", f"{fnum(tmin, 0)} °C'ta açık devre · sınır {fnum(vmax, 0)} V"),
        K("En düşük çalışma gerilimi", f"{fnum(vmp_sicak, 0)} V", "ok" if ok_alt else "bad", f"hücre {fnum(tc_max, 0)} °C · MPPT alt {fnum(vmp_min, 0)} V"),
        K("Uygun modül sayısı", f"{n_alt} … {n_ust}" if n_alt <= n_ust else "yok", "ok" if n_alt <= n <= n_ust else "bad", f"seçilen {n}"),
        K("MPPT girişindeki akım", f"{fnum(npar * isc_125, 1)} A", "ok" if ok_i else "bad", f"{npar} × Isc × 1,25 · giriş {fnum(imax, 0)} A"),
        K("Dizi sigortası", "gerekli" if sig_gerek else "gerekmez", ("ok" if sig else "bad") if sig_gerek else "info", f"ters akım {fnum(i_ters, 1)} A · modül {fnum(m['sigorta'], 0)} A"),
    ]
    kontroller = [
        C("En soğuk sabahta dizi açık devre gerilimi eviricinin sınırının altında mı?", f"{fnum(voc_max, 0)} V", f"≤ {fnum(vmax, 0)} V", ok_v,
          f"{GES} böl. 2.3.4.1: eviricinin DC gerilim çalışma aralığı düşük sıcaklıklarda bile dizi açık devre gerilimini kapsamalıdır. Aşılırsa evirici giriş katı delinir; garanti kapsamı dışıdır", "resmi"),
        C("En sıcak öğlede çalışma gerilimi MPPT aralığının içinde mi?", f"{fnum(vmp_sicak, 0)} V", f"≥ {fnum(vmp_min, 0)} V", ok_alt,
          f"{GES} böl. 2.3.4.1: eviricinin MPP gerilim aralığı. Altına düşülürse evirici en büyük güç noktasını izleyemez; yazın öğle saatlerinde üretim kırpılır", "resmi"),
        C("DC malzemenin anma gerilimi yeterli mi?", f"Voc(STC) × {n} × 1,15 = {fnum(v_malz, 0)} V", f"≤ {fnum(m['vsis'], 0)} V (modül sistem gerilimi; PV kablosu 1,5 kV DC)", v_malz <= m["vsis"],
          f"{GES} böl. 2.1.2 ve 2.1.5: dizi kablosu, sigorta ve ayırıcı gerilimi > Voc(STC) × M × 1,15. PV kablosu: TEDAŞ-MLZ/2015-061 (1,5/1,5 kV DC)", "resmi"),
        C("MPPT girişinin akımı yeterli mi?", f"{npar} × {fnum(isc_125, 1)} = {fnum(npar * isc_125, 1)} A", f"≤ {fnum(imax, 0)} A", ok_i,
          f"{GES} böl. 2.1.2: akım Isc(STC) × 1,25 alınır; böl. 2.3.4.1: evirici en büyük dizi akımına güvenle dayanmalıdır", "resmi"),
        C("Dizi sigortası gerekiyor mu, varsa doğru seçilmiş mi?", (f"ters akım (N−1)·Isc = {fnum(i_ters, 1)} A · sigorta " + (f"{fnum(sig, 0)} A" if sig else "yok")),
          (f"gerekli: {fnum(1.5 * stc['isc'], 1)} A < In ≤ {fnum(min(2.4 * stc['isc'], m['sigorta']), 1)} A" if sig_gerek else f"gerekmez: (N−1)·Isc ≤ {fnum(m['sigorta'], 0)} A"),
          ((1.5 * stc["isc"] < sig <= min(2.4 * stc["isc"], m["sigorta"])) if sig else not sig_gerek),
          f"{GES} böl. 2.1.10.1: (N−1) × Isc modülün en büyük seri sigorta değerinden büyükse bütün dizilere, iki kutba da gPV sigorta; In > 1,5 × Isc, In ≤ 2,4 × Isc, In ≤ en büyük seri sigorta değeri", "resmi"),
        C("Dizi kablosu akımı taşıyor mu?", f"gereken {fnum(i_kablo, 1)} A", f"≤ Iz ≈ {fnum(iz, 0)} A ({s} mm², düzeltilmiş)", i_kablo <= iz,
          f"{GES} böl. 2.1.5: sigortasız N paralel dizide kablo akımı > Isc × (N−1) × 1,25; sigortalıysa Iz hem sigorta değerinden hem Isc × 1,25'ten büyük. Taşıma değeri TS EN 50618 Tablo A.3 mertebesi, düzeltme katsayısı tahmini", "dogrulanacak"),
        C("DC gerilim düşümü", f"%{fnum(du, 2)}", "< %2", du < 2.0, f"{GES} böl. 2.1.4.1: STC'deki en büyük çalışma gücünde dizi ile evirici arasındaki toplam gerilim düşümü %2'nin altında kalmalıdır", "resmi"),
        C("Bina üzerinde 1000 V DC sınırı", f"{fnum(voc_max, 0)} V" + (" · bina çatısı" if montaj == "cati" else " · açık arazi"), "bina üzerinde ≤ 1000 V DC", (voc_max <= 1000) if montaj == "cati" else None,
          f"{GES} böl. 2.1.3: dizi açık devre gerilimi 1000 V DC'yi geçerse dizi bina üzerine kurulmamalı, erişim yalnız yetkili personele açık olmalıdır", "resmi"),
    ]
    girdiler = [
        G("Modül veri sayfası", f"Voc {fnum(m['voc'], 1)} V · Vmp {fnum(m['vmp'], 1)} V · Isc {fnum(m['isc'], 2)} A · β %{fnum(m['b'], 2)}/°C", "Modül veri sayfası", "Gerilimin sıcaklıkla değişimi modül sayısını belirler",
          f"en büyük seri sigorta {fnum(m['sigorta'], 0)} A · sistem gerilimi {fnum(m['vsis'], 0)} V"),
        G("Evirici veri sayfası", f"en yüksek DC {fnum(vmax, 0)} V · MPPT ≥ {fnum(vmp_min, 0)} V · giriş {fnum(imax, 0)} A", "Evirici veri sayfası (DC giriş bölümü)", "Pencerenin üst ve alt sınırı",
          "üst sınır aşılmaz; alt sınırın altında üretim kırpılır"),
        G("Sahanın uç sıcaklıkları", f"{fnum(tmin, 0)} °C … {fnum(tmax, 0)} °C", "Meteoroloji uzun yıllar verisi (en düşük ve en yüksek)", "Soğuk gerilimi yükseltir, sıcak düşürür",
          f"yazın hücre {fnum(tc_max, 0)} °C'a çıkar"),
        G("Dizi kablosu", f"{s} mm² Cu · {fnum(l, 0)} m (tek yön)", "Yerleşim planı; en uzak dizi", "Gerilim düşümü ve kayıp", f"R = 2 · L · ρ / S = {fnum(2 * l * r, 3)} Ω"),
    ]
    adimlar = [
        A("Soğukta açık devre gerilimi", "Voc(T) = Voc(STC) · (1 + β · (T − 25))", f"{fnum(m['voc'], 1)} × (1 − {fnum(abs(m['b']) / 100, 4)} × ({fnum(tmin, 0)} − 25))", f"{fnum(soguk['voc'], 1)} V / modül", "soğuk sabah, güneş doğarken: hücre ortam sıcaklığında",
          "hesap", ["Modül veri sayfası", "Sahanın uç sıcaklıkları"]),
        A("En çok modül", "n ≤ Vmax / Voc(Tmin)", f"{fnum(vmax, 0)} / {fnum(soguk['voc'], 1)}", f"{n_ust}", f"{GES} böl. 2.3.4.1", "resmi", ["Evirici veri sayfası"]),
        A("Sıcakta çalışma gerilimi", "Vmp(Tc) · Tc = Ta + (NOCT − 20) · G / 800", f"hücre {fnum(tc_max, 0)} °C", f"{fnum(sicak['vmp'], 1)} V / modül", "yaz öğlesi", "hesap"),
        A("En az modül", "n ≥ Vmppt(min) / Vmp(Tmax)", f"{fnum(vmp_min, 0)} / {fnum(sicak['vmp'], 1)}", f"{n_alt}", f"{GES} böl. 2.3.4.1", "resmi"),
        A("Giriş akımı", "I = N · Isc(STC) · 1,25", f"{npar} × {fnum(stc['isc'], 2)} × 1,25", f"{fnum(npar * isc_125, 1)} A", f"{GES} böl. 2.1.2", "resmi"),
        A("Ters akım", "IR = (N − 1) · Isc", f"({npar} − 1) × {fnum(stc['isc'], 2)}", f"{fnum(i_ters, 1)} A", f"{GES} böl. 2.1.10: arızalı diziye öbür dizilerden akan akım", "resmi"),
        A("DC gerilim düşümü", "ΔU% = 2 · L · ρ/S · Imp / (n · Vmp)", f"2 × {fnum(l, 0)} × {fnum(r * 1000, 2)} mΩ/m × {fnum(stc['imp'], 2)} A / {fnum(n * stc['vmp'], 0)} V", f"%{fnum(du, 2)}", f"{GES} böl. 2.1.4.1: < %2", "resmi", ["Dizi kablosu"]),
    ]
    ayarlar = [
        S("Dizi sigortası (gPV)", (f"{fnum(sig, 0)} A" if sig else "yok") + (" — gerekli" if sig_gerek and not sig else ""), f"{fnum(1.5 * stc['isc'], 1)} A < In ≤ {fnum(min(2.4 * stc['isc'], m['sigorta']), 1)} A", "Arızalı diziye öbür dizilerden akan ters akımı keser",
          f"{GES} böl. 2.1.10.1", "resmi"),
        S("DC ayırıcı", f"≥ {fnum(v_malz, 0)} V · ≥ {fnum(npar * isc_125, 0)} A", "DC-PV2 sınıfı", "Yük altında DC akımı keser", f"{GES} böl. 2.1.2", "resmi"),
        S("DC parafudr (tip 2)", f"Ucpv ≥ {fnum(v_malz, 0)} V", "—", "Uzun DC kablolarında yıldırım endüksiyonu", "Topraklama laboratuvarı › Parafudr seçimi", "ikincil"),
        S("Evirici › yalıtım direnci eşiği", "evirici devreye girmeden önce ölçer", "—", "DC toprak arızası aşırı akımla bulunamaz", "evirici kılavuzu", "ikincil"),
    ]
    test = [
        T("Dizi açık devre gerilimi", "Devreye almada, her dizi ayrı ayrı", f"≈ {fnum(n * PV.nokta(m, 800, PV.hucre_sicakligi(20, 800, m['noct']))['voc'], 0)} V (20 °C, 800 W/m²)", "diziler arasında ±%2'den fazla fark: eksik / fazla modül"),
        T("Kutup denetimi", "Voltmetre ile, eviriciye bağlamadan önce", "artı – eksi doğru", "ters dizi paralel bağlanırsa iki dizinin gerilimi toplanır"),
        T("Yalıtım direnci", "DC+ ve DC− ile toprak arası, megger", "megaohmlar düzeyinde", "Topraklama laboratuvarı › Yalıtım direnci ölçümü"),
        T("Dizi akımı", "DC pens ampermetre, aynı anda ışınım ölçüsü", f"≈ {fnum(stc['imp'], 1)} A × (ışınım / 1000)", "paralel diziler arasında fark: gölge, kir, arızalı modül"),
    ]
    ts = lin(-35, 85, 25)
    g1 = {"baslik": "Hücre sıcaklığına göre dizi gerilimi", "x_ad": "Hücre sıcaklığı (°C)", "y_ad": "Gerilim (V)", "ymin": 0,
          "seriler": [{"ad": "açık devre (Voc)", "renk": "#dc2626", "pts": pts(ts, [n * PV.nokta(m, 1000, q)["voc"] for q in ts], 1)}, {"ad": "çalışma (Vmp)", "renk": "#1a4d8f", "pts": pts(ts, [n * PV.nokta(m, 1000, q)["vmp"] for q in ts], 1)}],
          "yatay": [{"y": vmax, "etiket": f"evirici en yüksek {fnum(vmax, 0)} V", "renk": "#dc2626"}, {"y": vmp_min, "etiket": f"MPPT alt {fnum(vmp_min, 0)} V", "renk": "#b45309"}],
          "isaretler": [{"x": tmin, "etiket": "en soğuk"}, {"x": tc_max, "etiket": "en sıcak hücre"}]}
    ns = list(range(4, 41))
    g2 = {"baslik": "Modül sayısına göre uç gerilimler", "x_ad": "Dizideki modül sayısı", "y_ad": "Gerilim (V)", "ymin": 0,
          "seriler": [{"ad": f"Voc ({fnum(tmin, 0)} °C)", "renk": "#dc2626", "pts": pts(ns, [q * soguk["voc"] for q in ns], 1)}, {"ad": f"Vmp (hücre {fnum(tc_max, 0)} °C)", "renk": "#1a4d8f", "pts": pts(ns, [q * sicak["vmp"] for q in ns], 1)}],
          "yatay": [{"y": vmax, "etiket": f"{fnum(vmax, 0)} V", "renk": "#dc2626"}, {"y": vmp_min, "etiket": f"{fnum(vmp_min, 0)} V", "renk": "#b45309"}], "isaretler": [{"x": n, "etiket": "seçilen"}]}
    rows = [[f"{v:.0f} V", f"{int(v // soguk['voc'])}", fnum(int(v // soguk["voc"]) * m["pmax"] / 1000, 2), fnum(int(v // soguk["voc"]) * stc["vmp"], 0)] for v in (600, 1000, 1100, 1500)]
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"Modüller seri bağlandıkça gerilim toplanır: {n} modül STC'de {fnum(n * stc['voc'], 0)} V açık devre, {fnum(n * stc['vmp'], 0)} V çalışma gerilimi verir. Yüksek gerilim iyidir — aynı güç daha küçük akımla, daha ince kabloyla taşınır. Sınırı evirici koyar.",
            f"Üst sınır kışın aşılır. Modülün gerilimi soğukta yükselir (%{fnum(abs(m['b']), 2)}/°C): {fnum(tmin, 0)} °C'lık açık bir sabah, güneş modüle vurduğu ilk anda hücre henüz ısınmamıştır ve evirici devreye girmemiştir. Dizi tam açık devre gerilimindedir: {fnum(voc_max, 0)} V. "
            + ("Eviricinin sınırının altında." if ok_v else f"Bu, eviricinin {fnum(vmax, 0)} V'luk sınırını aşıyor: giriş katındaki yarı iletkenler delinir. Bu arıza yılda bir kez, en soğuk sabahta olur ve garanti kapsamında değildir."),
            f"Alt sınır yazın görülür. Öğle sıcağında hücre {fnum(tc_max, 0)} °C'a çıkar, çalışma gerilimi {fnum(vmp_sicak, 0)} V'a iner. "
            + ("MPPT aralığının içinde kalıyor." if ok_alt else f"MPPT aralığının alt sınırı {fnum(vmp_min, 0)} V: evirici en büyük güç noktasına inemez, yılın en verimli saatlerinde üretim kırpılır.")
            + (f" Bu evirici ve modülle dizide {n_alt} ile {n_ust} arasında modül olabilir." if n_alt <= n_ust else ""),
            f"Paralel dizilerde akım toplanır: {npar} dizi, Isc × 1,25 payıyla {fnum(npar * isc_125, 1)} A. Asıl soru arızada ne olacağıdır. Bir dizide kısa devre ya da toprak arızası olduğunda öbür {npar - 1} dizi o diziye ters yönde akım basar: {fnum(i_ters, 1)} A. Modülün dayanabildiği ters akım, etiketindeki «en büyük seri sigorta» değeridir: {fnum(m['sigorta'], 0)} A.",
            (f"Ters akım bu değeri aştığı için dizi sigortası gerekir. Sigorta kısa devre akımını değil — o zaten küçüktür — öbür dizilerden gelen ters akımı keser; bu yüzden anma akımı Isc'nin 1,5 ile 2,4 katı arasında seçilir ve iki kutba da konur."
             if sig_gerek else "Ters akım bu değerin altında kaldığı için dizi sigortası gerekmez: iki paralel dizide arızalı diziye yalnız bir dizinin akımı akar. Üç ve daha çok dizide sigorta zorunlu hale gelir."),
            f"Dizi kablosu akımdan çok gerilim düşümüne göre seçilir. {fnum(l, 0)} m'lik {s} mm² kabloda düşüm %{fnum(du, 2)}, kayıp {fnum(pk, 0)} W. Şartname %2 sınırını koyar; kayıp 25 yıl boyunca her güneşli saatte ödenir.",
            ("Bina üzerindeki dizilerde ayrıca 1000 V DC sınırı vardır: daha yüksek gerilimli diziler çatıya kurulmaz." if montaj == "cati" else "Açık arazide 1500 V'luk sistemler kullanılır: daha uzun diziler, daha az kablo ve birleştirme kutusu."),
        ],
        "dersler": [
            "En çok modül sayısını en soğuk sabahın açık devre gerilimi belirler.",
            "En az modül sayısını en sıcak öğlenin çalışma gerilimi belirler.",
            "DC malzeme: gerilim Voc × 1,15, akım Isc × 1,25 (TEDAŞ GES tip şartnamesi).",
            "(N−1) × Isc modülün seri sigorta değerini aşıyorsa dizi sigortası zorunludur: pratikte üç ve daha çok paralel dizide.",
            "DC gerilim düşümü < %2; bina üzerinde dizi gerilimi ≤ 1000 V DC.",
        ],
        "tablolar": [{"baslik": f"Evirici gerilimine göre en uzun dizi ({fnum(tmin, 0)} °C)", "cols": ["Evirici en yüksek DC gerilimi", "En çok modül", "Dizi gücü (kWp)", "STC çalışma gerilimi (V)"], "rows": rows,
                      "not": "Modül ve evirici değerleri tipiktir; gerçek tasarım üreticilerin veri sayfaları ve evirici üreticisinin boyutlandırma yazılımıyla yapılır."}],
    }
