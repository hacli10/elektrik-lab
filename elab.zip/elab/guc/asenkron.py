"""Üç fazlı asenkron motor: eşdeğer devre, moment–hız ve akım–hız eğrileri, kayma; gerilimin, frekansın ve rotor direncinin etkisi; devrilme.

Model: motor_model (bir faz eşdeğer devresi, derin oluk etkisiyle kaymaya bağlı rotor direnci). Parametreler orta güçte 4 kutuplu sincap kafesli bir motorun
tipik birim değerleridir (tahmini): kalkış akımı ≈ 6 × In, kalkış momenti ≈ 2,4 × Mn, devrilme momenti ≈ 3 × Mn. Anma akımı, güçten tipik verim ve güç katsayısıyla
bulunur (tahmini). Moment gerilimin karesiyle, senkron hız frekansla orantılıdır (temel bağıntı)."""
from __future__ import annotations

import cmath
import math

from . import motor_model as M
from .ortak import A, C, G, K, S, S3, T, TEMEL, Cizim, ctl, fa, fnum, num, opt, pts

ID = "asenkron"
BASLIK = "Asenkron motor"
IKON = "⚙"
GIRIS = ("Asenkron motorun rotoru alanın gerisinde kalarak döner; bu fark (kayma) ne kadar büyükse rotorda o kadar akım ve moment oluşur. Gerilim düşünce moment karesiyle düşer, "
         "motor aynı yükü taşımak için daha çok kayar ve daha çok akım çeker; fazla düşerse devrilir. Gerilimi, frekansı ve yükü değiştirip izleyin.")
GUCLER = (0.75, 1.5, 3, 5.5, 7.5, 11, 15, 22, 30, 45, 55, 75, 90, 110, 160, 250)

KONTROLLER = [
    ctl("pn", "Motor gücü", "sec", 15, secenek=opt(*[(g, f"{str(g).replace('.', ',')} kW") for g in GUCLER])),
    ctl("kutup", "Kutup sayısı", "sec", 4, secenek=opt((2, "2 kutup"), (4, "4 kutup"), (6, "6 kutup"), (8, "8 kutup"))),
    ctl("yuk", "Yük momenti", "sayi", 100, min=0, max=200, adim=5, birim="%"),
    ctl("yuk_tip", "Yükün türü", "sec", "sabit", secenek=opt(("sabit", "Sabit moment (konveyör, kompresör, vinç)"), ("fan", "Hızın karesiyle artan (fan, pompa)"))),
    ctl("u", "Gerilim", "sayi", 100, min=50, max=115, adim=1, birim="%"),
    ctl("f", "Frekans", "sayi", 50, min=10, max=60, adim=1, birim="Hz"),
    ctl("vf", "Sürücü: gerilim frekansla birlikte değişiyor (U/f sabit)", "onay", False, yardim="İşaretliyse gerilim = frekans / 50 × anma gerilimi × yukarıdaki yüzde"),
    ctl("r2", "Rotor direnci çarpanı", "sayi", 1.0, min=1, max=6, adim=0.5, yardim="Bilezikli motorda rotora eklenen direnç; sincap kafeste yüksek kaymalı rotor"),
]


def anma_akim(pn: float, u: float = 400.0) -> dict:
    eta = min(0.80 + 0.045 * math.log10(max(pn, 0.5)) + 0.05, 0.965)
    cosf = min(0.78 + 0.04 * math.log10(max(pn, 0.5)) + 0.03, 0.90)
    return {"i": pn * 1000 / (S3 * u * eta * cosf), "eta": eta, "cos": cosf}


def run(p: dict) -> dict:
    pn, kutup, yuk, fan = num(p, "pn", 15), int(num(p, "kutup", 4)), num(p, "yuk", 100) / 100, p.get("yuk_tip") == "fan"
    f = num(p, "f", 50); fo = f / 50
    u = num(p, "u", 100) / 100 * (fo if p.get("vf") else 1.0)
    par = dict(M.UC, r2=M.UC["r2"] * num(p, "r2", 1.0))
    a0 = M.anma(M.UC); an = anma_akim(pn)
    amper = an["i"] / a0["i"]
    ns = 120 * f / kutup
    mn_nm = pn * 1000 / (2 * math.pi * (120 * 50 / kutup) * (1 - M.SN) / 60)
    c0 = M.calisma(par, yuk, u, 0j, fo, fan)
    s = c0["s"]; n = ns * (1 - s)
    i_pu = abs(c0["i1"]) / a0["i"]
    kalkis = M.moment(par, 1.0, u, 0j, fo)
    ss = [0.002 * 1.06 ** k for k in range(110) if 0.002 * 1.06 ** k < 1.0] + [1.0]
    ms = [M.moment(par, x, u, 0j, fo)["m"] / a0["m"] for x in ss]
    k_tepe = max(range(len(ss)), key=lambda k: ms[k]); m_dev, s_dev = ms[k_tepe], ss[k_tepe]
    aki = u / fo                                                             # akı ∝ U/f
    cosf = math.cos(cmath.phase(c0["i1"])) if abs(c0["i1"]) else 0.0
    p_mek = c0["m"] * (1 - s) * fo
    p_el = (u * c0["i1"].conjugate()).real * 3 / 3
    eta = p_mek / p_el if p_el > 1e-9 and not c0["devrildi"] else 0.0

    c = Cizim(900, 300)
    c.hat("M40,90 H110", "L1", hot=True, w=3)
    c.direnc(110, 90, "R1", yatay=True, h=36, hot=True); c.hat("M146,90 H170", "L1", hot=True, w=3); c.bobin(170, 90, 4, yatay=True, ad="X1")
    c.hat("M210,90 H330", "L1", hot=True, w=3); c.hat("M270,90 V120", "cizgi", w=2); c.bobin(270, 120, 5, ad="Xm (mıknatıslanma)"); c.hat("M270,170 V220", "cizgi", w=2)
    c.bobin(330, 90, 4, yatay=True, ad="X2′"); c.hat("M370,90 H400", "L1", hot=True, w=3); c.direnc(400, 90, "R2′ / s", yatay=True, h=60, hot=True); c.hat("M460,90 H500 V220 H40", "L1", hot=True, w=3)
    c.yazi(40, 70, f"U = %{fnum(u * 100, 0)}", "#8a4b12", 11.5, kalin=True); c.yazi(40, 240, "bir fazın eşdeğer devresi", "#64748b", 10.5)
    c.yazi(400, 130, f"s = %{fnum(s * 100, 2)}", "#b91c1c", 12, kalin=True); c.yazi(400, 148, "kayma küçüldükçe bu direnç büyür:", "#64748b", 10); c.yazi(400, 162, "akım azalır, moment düşer", "#64748b", 10)
    c.yazi(560, 60, "DEVRİLDİ — motor duruyor" if c0["devrildi"] else f"Hız {fnum(n, 0)} d/dk (senkron {fnum(ns, 0)})", "#b91c1c" if c0["devrildi"] else "#15803d", 14, kalin=True)
    c.yazi(560, 86, f"Akım {fa(abs(c0['i1']) * amper, 1)} = {fnum(i_pu, 2)} × In", "#b91c1c" if i_pu > 1.1 else "#334155", 13, kalin=True)
    c.yazi(560, 110, f"Moment {fnum(c0['m'] / a0['m'] * 100, 0)} % · devrilme momenti %{fnum(m_dev * 100, 0)}", "#334155", 12)
    c.yazi(560, 132, f"Kalkış: {fnum(abs(kalkis['i1']) / a0['i'], 1)} × In · %{fnum(kalkis['m'] / a0['m'] * 100, 0)} moment", "#334155", 12)
    c.yazi(560, 154, f"cosφ {fnum(cosf, 2)} · verim %{fnum(eta * 100, 0)}", "#334155", 12)
    c.yazi(560, 184, f"Akı (U/f): anma değerinin %{fnum(aki * 100, 0)}'i", "#b91c1c" if aki > 1.08 else "#b45309" if aki < 0.9 else "#15803d", 12, kalin=True)
    c.yazi(560, 206, "Moment gerilimin karesiyle orantılıdır:", "#64748b", 11); c.yazi(560, 222, f"%{fnum(u / fo * 100, 0)} akıda devrilme momenti ≈ %{fnum((u / fo) ** 2 * 100, 0)}'e iner.", "#64748b", 11)

    ozet = [
        K("Hız", "duruyor" if c0["devrildi"] else f"{fnum(n, 0)} d/dk", "bad" if c0["devrildi"] else "ok", f"senkron {fnum(ns, 0)} · kayma %{fnum(s * 100, 2)}"),
        K("Akım", fa(abs(c0["i1"]) * amper, 1), "bad" if i_pu > 1.1 else "ok", f"{fnum(i_pu, 2)} × In (In = {fa(an['i'], 1)})"),
        K("Devrilme momenti", f"%{fnum(m_dev * 100, 0)}", "bad" if m_dev < yuk else "warn" if m_dev < 1.3 * yuk else "ok", f"kayma %{fnum(s_dev * 100, 0)}'de"),
        K("Kalkış", f"{fnum(abs(kalkis['i1']) / a0['i'], 1)} × In", "info", f"moment %{fnum(kalkis['m'] / a0['m'] * 100, 0)}"),
        K("Güç katsayısı · verim", f"{fnum(cosf, 2)} · %{fnum(eta * 100, 0)}", "info", "bu çalışma noktasında"),
    ]
    kontroller = [
        C("Motor yükü taşıyabiliyor mu?", f"devrilme momenti %{fnum(m_dev * 100, 0)}", f"> yük %{fnum(yuk * 100, 0)}", not c0["devrildi"], "Yük momenti eğrinin tepesini aşarsa kararlı çalışma noktası kalmaz: motor yavaşlar ve durur (devrilir)", "hesap"),
        C("Akım anma değerini aşıyor mu?", f"{fnum(i_pu, 2)} × In", "≤ 1,05 × In (sürekli)", i_pu <= 1.05, "Anma akımının üstünde sargı sıcaklığı sınıf sınırını aşar; termik röle bu bölgede çalışır", "ikincil"),
        C("Akı anma değerine yakın mı?", f"%{fnum(aki * 100, 0)}", "%90 … %108", 0.9 <= aki <= 1.08, "Akı ∝ U/f: düşük frekansta gerilim aynı kalırsa çekirdek doyar, mıknatıslanma akımı fırlar; gerilim düşükse moment karesiyle azalır", "hesap"),
        C("Model sınırı: çekirdek doyması", f"akı %{fnum(aki * 100, 0)}", "akı > %110 ise sonuçlar iyimserdir", None if aki <= 1.1 else False,
          "Bu model doğrusaldır: aşırı akıda çekirdek doyar, mıknatıslanma akımı anma akımını aşar ve motor yanar. Frekans düşürülürken gerilim de düşürülmelidir", "tahmini"),
        C("Kalkabilir mi?", f"kalkış momenti %{fnum(kalkis['m'] / a0['m'] * 100, 0)}", f"> dururken yük momenti %{fnum((0.0 if fan else yuk) * 100, 0)}", kalkis["m"] / a0["m"] > (0.0 if fan else yuk), "Kalkış momenti de gerilimin karesiyle değişir: yıldız–üçgende üçte bire, %80 gerilimde %64'e iner", "hesap"),
    ]
    girdiler = [
        G("Motor etiketi", f"{str(pn).replace('.', ',')} kW · 400 V · {kutup} kutup · ≈ {fa(an['i'], 1)}", "Etiket", "Anma akımı, hız ve moment buradan çıkar", f"Mn ≈ {fnum(mn_nm, 0)} Nm"),
        G("Kalkış verileri", "Ik / In ≈ 6 · Mk / Mn ≈ 2,4 · Md / Mn ≈ 3", "Üretici kataloğu", "Eşdeğer devre parametreleri bu üç orandan geri hesaplanabilir", "X1 + X2′ ≈ 1 / (Ik/In)"),
        G("Besleme", f"%{fnum(u * 100, 0)} gerilim · {fnum(f, 0)} Hz", "Motor klemensinde ölçü (yük altında)", "Moment gerilimin karesiyle, senkron hız frekansla değişir", "ns = 120·f / p"),
        G("Yük", f"%{fnum(yuk * 100, 0)} · {'hızla artan' if fan else 'sabit'}", "Tahrik edilen makinenin moment–hız eğrisi", "Çalışma noktası iki eğrinin kesiştiği yerdir", "M(motor) = M(yük)"),
    ]
    adimlar = [
        A("Senkron hız", "ns = 120 · f / p", f"120 × {fnum(f, 0)} / {kutup}", f"{fnum(ns, 0)} d/dk", TEMEL, "hesap", ["Motor etiketi", "Besleme"]),
        A("Rotor akımı", "I2′ = U / |R1 + R2′/s + j(X1 + X2′)| (mıknatıslanma kolu ayrıca)", f"s = {fnum(s, 4)}", f"stator akımı {fnum(i_pu, 2)} × In", "bir faz eşdeğer devresi", "hesap"),
        A("Moment", "M = 3 · I2′² · (R2′/s) / ωs", f"U = %{fnum(u * 100, 0)}", f"%{fnum(c0['m'] / a0['m'] * 100, 0)}", "hava aralığı gücü / senkron açısal hız", "hesap"),
        A("Devrilme", "s(dev) ≈ R2′ / (X1 + X2′) · M(dev) ∝ U² / (X1 + X2′)", f"rotor direnci × {fnum(num(p, 'r2', 1.0), 1)}", f"kayma %{fnum(s_dev * 100, 0)}'de %{fnum(m_dev * 100, 0)}", "rotor direnci devrilme momentini değiştirmez, yalnız yerini kaydırır", "hesap"),
        A("Çalışma noktası", "M(motor, s) = M(yük, n)", f"yük %{fnum(yuk * 100, 0)}", "kararlı nokta yok: devrilir" if c0["devrildi"] else f"kayma %{fnum(s * 100, 2)} → {fnum(n, 0)} d/dk", "ikiye bölme ile", "hesap", ["Yük"]),
    ]
    ayarlar = [
        S("Termik röle / motor koruma rölesi (49)", f"{fa(an['i'], 1)} (etiket akımı)", "0,9–1,0 × In", "Sürekli aşırı akımı ısıl modelle izler", "Röle laboratuvarı › Termik aşırı yük", "ikincil"),
        S("Kilitli rotor / uzun yol alma (51LR, 48)", "≈ 2 × In üstünde, kalkış süresinden uzun", "—", "Devrilen ya da kalkamayan motoru ayırır", "Röle laboratuvarı › Motor yol alma", "ikincil"),
        S("Düşük gerilim (27)", "%80 Un, 0,5–2 s", "—", "Gerilim çöküşünde motorlar devrilmeden önce ayrılır; gerilim dönünce hepsi birden kalkmaz", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Boşta akım", "Kaplin ayrık, anma geriliminde", "anma akımının %25–40'ı", "yüksekse hava aralığı / sargı sorunu"),
        T("Yükte akım ve hız", "Pens ampermetre + takometre", f"≈ {fa(abs(c0['i1']) * amper, 1)}, {fnum(n, 0)} d/dk", "kayma arttıysa yük artmış ya da gerilim düşmüştür"),
        T("Klemens gerilimi", "Motor çalışırken ve kalkışta", f"%{fnum(u * 100, 0)}; kalkışta %85'in altına inmemeli", "uzun kabloda kalkış çökmesi momenti düşürür"),
    ]
    hiz = [(1 - x) * 100 for x in ss]
    g1 = {"baslik": "Moment – hız", "x_ad": "Hız (% senkron hız)", "y_ad": "Moment (% anma)",
          "seriler": [{"ad": "bu besleme", "renk": "#dc2626", "pts": pts(hiz, [m * 100 for m in ms], 1)},
                      {"ad": "anma gerilim ve frekans", "renk": "#94a3b8", "kesik": True, "pts": pts(hiz, [M.moment(M.UC, x)["m"] / a0["m"] * 100 for x in ss], 1)},
                      {"ad": "yük", "renk": "#15803d", "pts": pts(hiz, [yuk * ((1 - x) ** 2 if fan else 1) * 100 for x in ss], 1)}], "isaretler": [{"x": (1 - s) * 100, "etiket": "çalışma"}]}
    g2 = {"baslik": "Akım – hız", "x_ad": "Hız (% senkron hız)", "y_ad": "Akım (× In)", "ymin": 0,
          "seriler": [{"ad": "stator akımı", "renk": "#1a4d8f", "pts": pts(hiz, [abs(M.moment(par, x, u, 0j, fo)["i1"]) / a0["i"] for x in ss], 2)}], "yatay": [{"y": 1.0, "etiket": "In", "renk": "#94a3b8"}], "isaretler": [{"x": (1 - s) * 100, "etiket": "çalışma"}]}
    us = [0.5 + 0.025 * k for k in range(0, 27)]
    sat = [M.calisma(par, yuk, x * (fo if p.get("vf") else 1.0), 0j, fo, fan) for x in us]
    g3 = {"baslik": "Gerilime göre akım ve kayma (bu yükte)", "x_ad": "Gerilim (% anma)", "y_ad": "akım (× In) · kayma (× 10 %)", "ymin": 0,
          "seriler": [{"ad": "akım (× In)", "renk": "#dc2626", "pts": pts([x * 100 for x in us], [abs(q["i1"]) / a0["i"] for q in sat], 2)}, {"ad": "kayma (%/10)", "renk": "#1a4d8f", "pts": pts([x * 100 for x in us], [q["s"] * 10 for q in sat], 3)}],
          "isaretler": [{"x": num(p, "u", 100), "etiket": "şimdi"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2, g3],
        "anlatim": [
            f"Stator alanı dakikada {fnum(ns, 0)} devir döner. Rotor bundan biraz yavaştır; aradaki fark (kayma) rotor çubuklarında gerilim endükler, akım akıtır ve moment üretir. Rotor alanı yakalasaydı çubuklarda gerilim olmaz, moment sıfıra inerdi.",
            "Eşdeğer devrede bu, kaymaya bağlı bir dirençle gösterilir: R2′/s. Boşta kayma çok küçük, direnç çok büyüktür; yük arttıkça kayma büyür, direnç küçülür, akım artar.",
            f"Şimdi kayma %{fnum(s * 100, 2)}: motor {fnum(i_pu, 2)} × In çekiyor. " + ("Yük devrilme momentini aştı: motor yavaşladıkça moment de azalır, durana kadar düşer; akım kalkış akımına çıkar." if c0["devrildi"] else "Eğrinin tepesinin sağında (küçük kaymalarda) çalışma kararlıdır: yük artarsa motor yavaşlar, moment artar, denge yeniden kurulur."),
            f"Gerilim %{fnum(u * 100, 0)}: akı ve rotor akımı gerilimle, moment ikisinin çarpımıyla orantılıdır. Devrilme momenti gerilimin karesiyle değişir: %80 gerilimde %64'e, %70'te yarısına iner.",
            "Gerilim düşünce motor aynı yükü taşımak için daha çok kayar ve daha çok akım çeker: düşük gerilim motoru soğutmaz, ısıtır. Şebekedeki bir çöküşte motorların devrilip kalkış akımı çekmesi çöküşü daha da derinleştirir.",
            "Rotor direncini artırmak devrilme momentini değiştirmez, tepeyi düşük hızlara kaydırır: kalkış momenti büyür, kalkış akımı küçülür. Bilezikli motorun yol verme direnci bunu yapar; bedeli çalışırken yüksek kayma ve kayıptır.",
            "Sürücüyle frekans düşürülürken gerilim de aynı oranda düşürülür (U/f sabit): akı sabit kalır, eğri biçimini koruyarak sola kayar. Düşük frekansta stator direncinin payı büyür; bu yüzden sürücüler alt hızlarda gerilimi biraz yükseltir.",
        ],
        "dersler": [
            "Moment ∝ U²: %10 gerilim düşümü %19 moment kaybıdır.",
            "Düşük gerilimde motor daha çok akım çeker; yanma nedeni çoğu zaman yüksek değil düşük gerilimdir.",
            "Kayma, motorun yükünü gösterir: hız ölçmek akım ölçmek kadar bilgi verir.",
            "Devrilen motor kalkış akımı çeker ve saniyeler içinde ısınır: kilitli rotor koruması bunun içindir.",
            "U/f sabit tutulursa motor her hızda aynı momenti verebilir; yalnız frekans düşürülürse çekirdek doyar.",
        ],
    }
