"""GES'te kablo boyu: DC dizi kablosunda kayıp ve gerilim düşümü; AC tarafta evirici ucunda gerilimin yükselmesi ve eviricinin aşırı gerilimden devreden çıkması;
reaktif güç çekerek (cosφ) yükselmenin azaltılması.

Bağıntılar temel devre bağıntılarıdır (hesap). Modül değerleri 550 Wp sınıfı tipik bir modülün katalog mertebesindedir (tahmini). DC kayıp için ≤ %1–1,5 ve AC gerilim yükselmesi için
≈ %3 ölçütleri uygulama değerleridir (ikincil). Eviricinin aşırı gerilim açma ayarı (≈ %110 Un) Lisanssız Elektrik Üretimi Yön. Uygulama Tebliği Ek-2'deki ayarlardan alınır; bu sayfadaki
değer asıl metinden teyit edilmemiştir (dogrulanacak). Düşük gerilim ayarları (< %88 Un → 2,0 s) aynı tablodan doğrulanmıştır."""
from __future__ import annotations

import math

from . import kablo as KB
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, logsp, num, opt, pts

ID = "boy_ges"
BASLIK = "GES kablo boyu"
IKON = "☀"
GIRIS = ("GES'te kablo iki ayrı yerde iş başındadır. DC tarafta uzun dizi kablosu enerjiyi ısıya çevirir. AC tarafta uzun kablo daha sinsi bir şey yapar: evirici şebekeye akım bastıkça "
         "kendi ucundaki gerilim yükselir ve öğle saatinde aşırı gerilim korumasından devreden çıkar. Boyları ve kesitleri değiştirip izleyin.")
MOD = {"voc": 49.8, "vmp": 41.9, "imp": 13.1, "p": 550}

KONTROLLER = [
    ctl("n", "Dizideki modül sayısı", "sayi", 18, min=8, max=28, adim=1),
    ctl("l_dc", "Dizi kablosu boyu (tek yön)", "sayi", 60, min=5, max=300, adim=5, birim="m"),
    ctl("s_dc", "Dizi kablosu kesiti", "sec", 6, secenek=opt((4, "4 mm²"), (6, "6 mm²"), (10, "10 mm²"))),
    ctl("p_ac", "Evirici gücü", "sayi", 100, min=5, max=350, adim=5, birim="kW"),
    ctl("l_ac", "AC kablo boyu (evirici – bağlantı noktası)", "sayi", 100, min=5, max=800, adim=5, birim="m"),
    ctl("s_ac", "AC kablo kesiti", "sec", 95, secenek=opt(*[(k, f"{k} mm²") for k in KB.KESIT if k >= 6])),
    ctl("metal", "AC iletken", "sec", "al", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum"))),
    ctl("u_seb", "Bağlantı noktasındaki gerilim", "sayi", 104, min=95, max=112, adim=0.5, birim="%", yardim="Öğle saatinde, yük azken şebeke gerilimi yüksektir"),
    ctl("cos", "Eviricinin güç katsayısı", "sayi", 1.00, min=0.80, max=1.0, adim=0.01, yardim="1'in altında evirici reaktif güç çeker (endüktif çalışır): gerilim yükselmesini azaltır"),
    ctl("u_ac", "Evirici aşırı gerilim açma ayarı", "sayi", 110, min=105, max=115, adim=0.5, birim="%"),
]


def run(p: dict) -> dict:
    n, l_dc, s_dc = int(num(p, "n", 18)), num(p, "l_dc", 60), num(p, "s_dc", 6)
    p_ac, l_ac, s_ac, metal = num(p, "p_ac", 100), num(p, "l_ac", 100), num(p, "s_ac", 95), str(p.get("metal", "al"))
    u_seb, cosf, u_ac = num(p, "u_seb", 104) / 100, num(p, "cos", 1.0), num(p, "u_ac", 110) / 100
    v_dizi, i_dizi = n * MOD["vmp"], MOD["imp"]
    r_dc = 2 * l_dc / 1000 * KB.r_km(s_dc, "cu", 70.0)
    du_dc = i_dizi * r_dc / v_dizi * 100
    p_dc_k = i_dizi ** 2 * r_dc
    p_dizi = n * MOD["p"]
    i_ac = p_ac * 1000 / (math.sqrt(3) * 400 * u_seb * cosf)
    r_ac, x_ac = KB.r_km(s_ac, metal, 70.0) * l_ac / 1000, KB.X_AG * l_ac / 1000
    sinf = math.sqrt(max(1 - cosf * cosf, 0))
    yuk = math.sqrt(3) * i_ac * (r_ac * cosf - x_ac * sinf) / 400 * 100                 # evirici reaktif çekerken (endüktif): reaktans terimi yükselmeyi azaltır
    u_ev = u_seb * 100 + yuk
    p_ac_k = 3 * i_ac ** 2 * r_ac
    iz = KB.iz(s_ac, "xlpe", metal)
    acti = u_ev >= u_ac * 100
    pay = u_ac * 100 - u_ev
    q = p_ac * math.tan(math.acos(cosf))
    c = Cizim(900, 310)
    for k in range(4):
        c.dikdortgen(30 + k * 34, 60, 28, 46, "mavi", "#dbeafe", kw=1.2, r=2)
    c.yazi(96, 50, f"{n} modül · {fnum(v_dizi, 0)} V · {fnum(i_dizi, 1)} A", "#1d4ed8", 11, kalin=True, anchor="middle")
    c.hat("M166,83 H300", "L1", hot=True, w=2.6); c.yazi(232, 74, f"DC {fnum(l_dc, 0)} m · {fnum(s_dc, 0)} mm²", "#334155", 10.5, anchor="middle"); c.yazi(232, 102, f"−%{fnum(du_dc, 2)} · {fnum(p_dc_k, 0)} W", "#b45309", 11, kalin=True, anchor="middle")
    c.kutu(300, 56, 110, 54, "Evirici", f"{fnum(p_ac, 0)} kW")
    c.hat("M410,83 H660", "L1", hot=True, w=3); c.yazi(535, 74, f"AC {fnum(l_ac, 0)} m · {fnum(s_ac, 0)} mm² {'Al' if metal == 'al' else 'Cu'}", "#334155", 10.5, anchor="middle")
    c.yazi(535, 102, f"{fa(i_ac, 0)} · {fnum(p_ac_k, 0)} W", "#b45309", 11, kalin=True, anchor="middle")
    c.kutu(660, 56, 130, 54, "Bağlantı noktası", f"%{fnum(u_seb * 100, 1)} Un")
    c.cihaz(300, 130, f"%{fnum(u_ev, 1)}", "evirici ucunda gerilim", ok=not acti)
    c.yazi(450, 152, f"= {fnum(u_ev / 100 * 400, 0)} V · yükselme +%{fnum(yuk, 2)}", "#b91c1c" if acti else "#334155", 12.5, kalin=True)
    c.yazi(450, 174, ("EVİRİCİ AÇIYOR: aşırı gerilim" if acti else f"açma ayarına pay: %{fnum(pay, 1)}"), "#b91c1c" if acti or pay < 2 else "#15803d", 12.5, kalin=True)
    c.yazi(40, 222, "Evirici akım basar; akım şebekeye doğru aktığı için gerilim, kaynağa (eviriciye) yaklaştıkça yükselir.", "#64748b", 11.5)
    c.yazi(40, 244, f"Toplam kablo kaybı: DC {fnum(p_dc_k, 0)} W/dizi (%{fnum(p_dc_k / p_dizi * 100, 2)}) + AC {fnum(p_ac_k / 1000, 2)} kW (%{fnum(p_ac_k / (p_ac * 1000) * 100, 2)})", "#334155", 12)
    c.yazi(40, 268, (f"Evirici {fnum(q, 0)} kvar reaktif çekiyor: yükselme azalır, akım ve kayıp artar." if cosf < 0.999 else "cosφ = 1: yükselme en büyük, akım en küçük."), "#1a4d8f", 12)
    ozet = [
        K("Evirici ucunda gerilim", f"%{fnum(u_ev, 1)}", "bad" if acti else "warn" if pay < 2 else "ok", f"{fnum(u_ev / 100 * 400, 0)} V · açma %{fnum(u_ac * 100, 1)}"),
        K("AC gerilim yükselmesi", f"+%{fnum(yuk, 2)}", "warn" if yuk > 3 else "ok", f"{fnum(l_ac, 0)} m · {fnum(s_ac, 0)} mm²"),
        K("DC gerilim düşümü", f"%{fnum(du_dc, 2)}", "warn" if du_dc > 1.5 else "ok", f"{fnum(p_dc_k, 0)} W / dizi"),
        K("AC kablo kaybı", f"{fnum(p_ac_k / 1000, 2)} kW", "warn" if p_ac_k / (p_ac * 1000) > 0.02 else "ok", f"%{fnum(p_ac_k / (p_ac * 1000) * 100, 2)} · {fa(i_ac, 0)}"),
        K("Evirici", "AÇIYOR" if acti else "çalışıyor", "bad" if acti else "ok", f"pay %{fnum(pay, 1)}"),
    ]
    kontroller = [
        C("Evirici ucundaki gerilim açma ayarının altında mı?", f"%{fnum(u_ev, 1)}", f"< %{fnum(u_ac * 100, 1)}", not acti, "Eviricinin gerilim koruma ayarları Lisanssız Elektrik Üretimi Yön. Uygulama Tebliği Ek-2'deki tablodan alınır; aşırı gerilim eşiği asıl metinle doğrulanacak", "dogrulanacak"),
        C("AC gerilim yükselmesi", f"+%{fnum(yuk, 2)}", "≤ %3 (evirici – bağlantı noktası arası)", yuk <= 3.0, "Uygulama ölçütü: bağlantı noktasındaki gerilim yüksekken bile eviricinin açmaması için pay bırakılır", "ikincil"),
        C("DC kablo kaybı", f"%{fnum(du_dc, 2)}", "≤ %1,5", du_dc <= 1.5, "Tasarım ölçütü: dizi kablosundaki kayıp yıllık üretimi doğrudan azaltır", "ikincil"),
        C("AC kablo akım taşıma", fa(i_ac, 0), f"≤ {fnum(iz, 0)} A", i_ac <= iz, "Evirici anma akımını sürekli verir (yük eşzamanlılığı yoktur): kablo tam akıma göre seçilir — Iz çizelge değeri (doğrulanacak)", "dogrulanacak"),
        C("Düşük gerilimde davranış", "< %88 Un → 2,0 s · < %50 Un → 0,2 s", "LÜY ayarı", None, "Lisanssız Elektrik Üretimi Yön. Uygulama Tebliği Ek-2 Tablo-2", "resmi"),
    ]
    girdiler = [
        G("Dizi", f"{n} × {MOD['p']} Wp · Vmp {fnum(v_dizi, 0)} V · Imp {fnum(i_dizi, 1)} A", "Modül veri sayfası, dizi şeması", "DC kaybı akımın karesi ve kablo direnci belirler", "P = I² · R"),
        G("AC kablo", f"{fnum(l_ac, 0)} m · {fnum(s_ac, 0)} mm² {'Al' if metal == 'al' else 'Cu'}", "Proje, güzergâh", "Yükselme kablo direnci ve akımla orantılıdır", "ΔU = √3·I·(R·cosφ − X·sinφ)"),
        G("Bağlantı noktasındaki gerilim", f"%{fnum(u_seb * 100, 1)} Un", "Analizör kaydı: öğle saatleri, hafta sonu", "Yükselme bunun üstüne eklenir; şebeke zaten yüksekse pay kalmaz", "U(evirici) = U(şebeke) + ΔU"),
    ]
    adimlar = [
        A("DC gerilim düşümü", "ΔU% = 2·L·r·I / V(dizi)", f"2 × {fnum(l_dc, 0)} m × {fnum(KB.r_km(s_dc, 'cu', 70.0), 2)} Ω/km × {fnum(i_dizi, 1)} A / {fnum(v_dizi, 0)} V", f"%{fnum(du_dc, 2)} · {fnum(p_dc_k, 0)} W", "gidiş + dönüş", "hesap", ["Dizi"]),
        A("AC akımı", "I = P / (√3 · U · cosφ)", f"{fnum(p_ac, 0)} kW / (1,732 × {fnum(400 * u_seb, 0)} V × {fnum(cosf, 2)})", fa(i_ac, 0), "evirici anma gücünde", "hesap"),
        A("AC gerilim yükselmesi", "ΔU% = √3·I·(R·cosφ − X·sinφ) / U", f"R = {fnum(r_ac * 1000, 0)} mΩ · X = {fnum(x_ac * 1000, 0)} mΩ", f"+%{fnum(yuk, 2)}", "akım eviriciden şebekeye akar: düşüm, evirici tarafında yükselme olarak görünür", "hesap", ["AC kablo"]),
        A("Evirici ucunda gerilim", "U = U(bağlantı) + ΔU", f"%{fnum(u_seb * 100, 1)} + %{fnum(yuk, 2)}", f"%{fnum(u_ev, 1)}", "eviricinin gerilim koruması bu noktayı ölçer", "hesap", ["Bağlantı noktasındaki gerilim"]),
        A("Reaktif gücün etkisi", "Q = P · tanφ", f"cosφ = {fnum(cosf, 2)}", f"{fnum(q, 0)} kvar endüktif", "reaktansta ters yönlü gerilim düşümü oluşur", "hesap"),
    ]
    ayarlar = [
        S("Evirici › cosφ sabit ya da Q(U)", "0,95 endüktif ya da gerilime bağlı reaktif", "—", "Gerilim yükseldikçe evirici reaktif çeker: yükselme azalır", "evirici kılavuzu; dağıtım şirketi bağlantı koşulları", "ikincil"),
        S("Evirici › P(U) (gerilime bağlı güç kısma)", "açma eşiğinin birkaç puan altında başlar", "—", "Açıp kapanmak yerine gücü kısar: üretim kaybı küçülür", "evirici kılavuzu", "ikincil"),
        S("Trafo kademesi", "AG gerilimini düşüren kademe", "—", "Bağlantı noktasındaki gerilim sürekli yüksekse kök neden budur", "«Kademe değiştirme» sayfası", "ikincil"),
        S("AC kablo kesiti", "yükselme ≤ %1–3 olacak biçimde", "—", "Akım taşımaya göre yeterli kesit, gerilim yükselmesine göre yetmeyebilir", "hesap", "hesap"),
    ]
    test = [
        T("Evirici kaydı", "Öğle saatinde AC gerilim ve hata kayıtları", f"gerilim ≈ %{fnum(u_ev, 1)}; «şebeke aşırı gerilimi» hatası yok", "hata yalnız güneşli, yükün az olduğu saatlerde çıkıyorsa neden yükselmedir"),
        T("İki uçta gerilim", "Evirici klemensi ve bağlantı noktası, aynı anda", f"fark ≈ %{fnum(yuk, 1)} ({fnum(yuk / 100 * 400, 0)} V)", "fark hesaptan büyükse bağlantı direnci ya da nötr sorunu"),
        T("Dizi akımı ve gerilimi", "DC pens ve voltmetre, evirici girişinde", f"≈ {fnum(i_dizi, 1)} A · {fnum(v_dizi * (1 - du_dc / 100), 0)} V (tam ışınımda)", "diziler arası fark gölge ya da arıza belirtisi"),
    ]
    ls = [5 * 1.2 ** k for k in range(0, 29) if 5 * 1.2 ** k <= 800]
    def yuks(l, s_, cf):
        ii = p_ac * 1000 / (math.sqrt(3) * 400 * u_seb * cf)
        return math.sqrt(3) * ii * (KB.r_km(s_, metal, 70.0) * l / 1000 * cf - KB.X_AG * l / 1000 * math.sqrt(1 - cf * cf)) / 400 * 100
    g1 = {"baslik": "AC kablo boyuna göre evirici ucundaki gerilim", "x_ad": "AC kablo boyu (m)", "y_ad": "Gerilim (% Un)",
          "seriler": [{"ad": f"{fnum(s_ac, 0)} mm², cosφ {fnum(cosf, 2)}", "renk": "#dc2626", "pts": pts(ls, [u_seb * 100 + yuks(x, s_ac, cosf) for x in ls], 2)},
                      {"ad": f"{fnum(s_ac, 0)} mm², cosφ 0,95 end.", "renk": "#1a4d8f", "kesik": True, "pts": pts(ls, [u_seb * 100 + yuks(x, s_ac, 0.95) for x in ls], 2)}] +
                     ([{"ad": f"{next(k for k in KB.KESIT if k > s_ac)} mm², cosφ {fnum(cosf, 2)}", "renk": "#15803d", "kesik": True, "pts": pts(ls, [u_seb * 100 + yuks(x, next(k for k in KB.KESIT if k > s_ac), cosf) for x in ls], 2)}] if s_ac < 300 else []),
          "yatay": [{"y": u_ac * 100, "etiket": "evirici açar", "renk": "#dc2626"}, {"y": u_seb * 100, "etiket": "bağlantı noktası", "renk": "#94a3b8"}], "isaretler": [{"x": l_ac, "etiket": "boy"}]}
    ld = [5 * 1.2 ** k for k in range(0, 24) if 5 * 1.2 ** k <= 300]
    g2 = {"baslik": "Dizi kablosu boyuna göre DC kaybı", "x_ad": "Dizi kablosu boyu, tek yön (m)", "y_ad": "Kayıp (%)", "ymin": 0,
          "seriler": [{"ad": f"{k} mm²", "renk": rk, "kesik": k != s_dc, "pts": pts(ld, [i_dizi * 2 * x / 1000 * KB.r_km(k, "cu", 70.0) / v_dizi * 100 for x in ld], 3)} for k, rk in ((4, "#dc2626"), (6, "#1a4d8f"), (10, "#15803d"))],
          "yatay": [{"y": 1.5, "etiket": "%1,5", "renk": "#94a3b8"}], "isaretler": [{"x": l_dc, "etiket": "boy"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"DC tarafta her dizi yaklaşık {fnum(i_dizi, 1)} A taşır; gerilimi modül sayısıyla büyür ({fnum(v_dizi, 0)} V). Akım küçük, gerilim yüksek olduğu için kayıp yüzde olarak küçüktür: {fnum(l_dc, 0)} m'de %{fnum(du_dc, 2)}. Diziyi uzatmak (daha çok modül) aynı kabloda kaybı azaltır.",
            f"AC tarafta durum terstir: gerilim düşük (400 V), akım büyüktür ({fa(i_ac, 0)}). {fnum(l_ac, 0)} m kabloda {fnum(p_ac_k / 1000, 2)} kW ısıya gider.",
            "Asıl mesele gerilimdir. Tüketim devresinde akım kaynaktan yüke akar ve gerilim yüke doğru düşer. GES'te akım eviriciden şebekeye akar: aynı «düşüm» bu kez eviricinin ucunda bir yükselme olarak görünür.",
            f"Bağlantı noktasında gerilim %{fnum(u_seb * 100, 1)}; kablodaki yükselme +%{fnum(yuk, 2)}: evirici kendi ucunda %{fnum(u_ev, 1)} görüyor. " + ("Bu, aşırı gerilim açma ayarının üstünde: evirici devreden çıkıyor. Çıkınca akım kesilir, gerilim düşer, evirici yeniden girer: öğle saatlerinde tekrarlayan aç-kapa."
                                                                                                                                     if acti else f"Açma ayarına %{fnum(pay, 1)} pay var."),
            "Çareler sırasıyla: AC kabloyu kalınlaştırmak ya da kısaltmak (eviriciyi bağlantı noktasına yaklaştırmak), eviriciye reaktif güç çektirmek (cosφ < 1 ya da Q(U)), trafonun kademesini düzeltmek. Reaktif çekmek yükselmeyi azaltır ama akımı ve kaybı artırır; reaktif sayacına da yansır.",
            "Yükselme sorunu yalnız güneşli ve yükün az olduğu saatlerde ortaya çıkar: kabul sırasında değil, ilk bahar öğlesinde fark edilir.",
        ],
        "dersler": [
            "GES'te AC kablo gerilimi düşürmez, evirici ucunda yükseltir.",
            "Akım taşımaya göre yeterli kesit, gerilim yükselmesine göre yetmeyebilir: AC kablo ≤ %1–3 yükselmeye göre seçilir.",
            "Öğle saatinde tekrarlayan «şebeke aşırı gerilimi» hatası kablo yükselmesi + yüksek şebeke gerilimidir.",
            "Reaktif çekmek (cosφ 0,95 endüktif, Q(U)) yükselmeyi azaltır; bedeli akım ve kayıptır.",
            "DC tarafta kaybı azaltmanın yolu kalın kablo ya da uzun dizidir (yüksek gerilim, düşük akım).",
        ],
    }
