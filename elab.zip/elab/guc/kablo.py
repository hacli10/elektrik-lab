"""Kablo verileri (ortak): AG ve OG kablolarının direnci, reaktansı, akım taşıma kapasitesi ve kapasitesi; gerilim düşümü ve çevrim empedansı yardımcıları.

İletken dirençleri (20 °C, Ω/km) sınıf 2 iletkenler için bilinen çizelge değerleridir (TS EN 60228 — dogrulanacak). Akım taşıma kapasiteleri çok damarlı kablo, delikli tava,
30 °C hava, üç yüklü iletken için tipik çizelge değerleridir (TS HD 60364-5-52 — dogrulanacak). Reaktans ve OG kablo kapasiteleri katalog mertebesindedir (tahmini)."""
from __future__ import annotations

import math

KESIT = (1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240, 300)
R20_CU = dict(zip(KESIT, (12.1, 7.41, 4.61, 3.08, 1.83, 1.15, 0.727, 0.524, 0.387, 0.268, 0.193, 0.153, 0.124, 0.0991, 0.0754, 0.0601)))
R20_AL = {16: 1.91, 25: 1.20, 35: 0.868, 50: 0.641, 70: 0.443, 95: 0.320, 120: 0.253, 150: 0.206, 185: 0.164, 240: 0.125, 300: 0.100}
IZ_PVC = dict(zip(KESIT, (18.5, 25, 34, 43, 60, 80, 101, 126, 153, 196, 238, 276, 319, 364, 430, 497)))
IZ_XLPE = dict(zip(KESIT, (23, 32, 42, 54, 75, 100, 127, 158, 192, 246, 298, 346, 399, 456, 538, 621)))
X_AG = 0.08                                   # Ω/km — çok damarlı AG kablosu
# OG tek damarlı XLPE (20,3/35 kV), yonca demet: kapasite µF/km ve reaktans Ω/km
OG_KESIT = (50, 70, 95, 120, 150, 185, 240, 300, 400)
OG_C = dict(zip(OG_KESIT, (0.13, 0.15, 0.16, 0.18, 0.19, 0.20, 0.22, 0.24, 0.27)))
OG_X = dict(zip(OG_KESIT, (0.150, 0.142, 0.135, 0.130, 0.126, 0.122, 0.117, 0.113, 0.108)))
OG_IZ_CU = dict(zip(OG_KESIT, (220, 270, 325, 370, 415, 470, 545, 615, 700)))            # toprakta, yonca, tipik
R20_AL.update({400: 0.0778}); R20_CU.update({400: 0.0470})


def r_km(kesit: float, metal: str = "cu", t_c: float = 70.0) -> float:
    """İletken direnci (Ω/km) işletme sıcaklığında."""
    tab = R20_AL if metal == "al" else R20_CU
    r20 = tab.get(kesit) or (28.264 if metal == "al" else 17.241) / kesit * 1.02
    alfa = 0.00403 if metal == "al" else 0.00393
    return r20 * (1 + alfa * (t_c - 20))


def iz(kesit: float, yalitkan: str = "pvc", metal: str = "cu") -> float:
    """Akım taşıma kapasitesi (A): çok damarlı, delikli tava, 30 °C. Alüminyum için bakırın 0,78'i."""
    tab = IZ_XLPE if yalitkan == "xlpe" else IZ_PVC
    v = tab.get(kesit) or tab[min(tab, key=lambda k: abs(k - kesit))]
    return v * (0.78 if metal == "al" else 1.0)


def du_3f(i: float, l_m: float, kesit: float, cosf: float = 0.85, metal: str = "cu", t_c: float = 70.0, x: float = X_AG, u: float = 400.0) -> float:
    """Üç fazlı gerilim düşümü (%): ΔU = √3·I·L·(r·cosφ + x·sinφ)."""
    sinf = math.sqrt(max(1 - cosf * cosf, 0))
    return math.sqrt(3) * i * l_m / 1000 * (r_km(kesit, metal, t_c) * cosf + x * sinf) / u * 100


def du_1f(i: float, l_m: float, kesit: float, cosf: float = 0.95, metal: str = "cu", t_c: float = 70.0, x: float = X_AG, u: float = 230.0) -> float:
    """Tek fazlı gerilim düşümü (%): gidiş + dönüş."""
    sinf = math.sqrt(max(1 - cosf * cosf, 0))
    return 2 * i * l_m / 1000 * (r_km(kesit, metal, t_c) * cosf + x * sinf) / u * 100


def z_cevrim(l_m: float, s_faz: float, s_pe: float, metal: str = "cu", t_c: float = 80.0, x: float = X_AG) -> complex:
    """Faz + koruma iletkeni çevriminin empedansı (Ω): arıza sırasındaki (yüksek) iletken sıcaklığıyla."""
    return complex((r_km(s_faz, metal, t_c) + r_km(s_pe, metal, t_c)) * l_m / 1000, 2 * x * l_m / 1000)
