"""Kısa devrede trafo: AG uçlarındaki arızanın tipine göre (üç faz, iki faz, faz–nötr, iki faz–nötr) AG ve OG akımları, sargı akımları, tepe akım, sargılara
etkiyen kuvvet, sargının ısınması ve dayanım süresi; OG uçlarındaki arıza; sarımlar arası (iç) kısa devre.

Akımlar trafo_model.hesapla ile (şebeke Thevenin eşdeğeri + bağlantı grubuna göre sargılar) çözülür; gerilim katsayısı c = 1 alınır (IEC 60909 hesabı Röle
laboratuvarı › Kısa devre sayfasındadır). Tepe akım κ = 1,02 + 0,98·e^(−3R/X). Kısa devre ısıl dayanım süresi 2 s: TEDAŞ-MLZ/99-032.E böl. 2.2.10.
Sargı sıcaklığı adyabatik bağıntıyla: bakır θ1 = θ0 + 2(θ0 + 235) / (106000 / (J²·t) − 1), alüminyum θ1 = θ0 + 2(θ0 + 225) / (45700 / (J²·t) − 1) ve sınırlar
(yağlı bakır 250 °C, alüminyum 200 °C; kuru F sınıfı bakır 350 °C) TS EN 60076-5'ten bellekle yazılmıştır (dogrulanacak). Anma akım yoğunluğu tipiktir (tahmini).
Sarımlar arası kısa devrede uç akımındaki değişim ΔI ≈ f²/uk kaba bir kabuldür (tahmini)."""
from __future__ import annotations

import math

from . import trafo_model as M
from ..role import dalga as D
from .ortak import A, C, G, IEC5, IEC909, K, RENK3, S, T, TEDAS_H, Cizim, ctl, fa, fazor, fnum, num, opt, pts, tr_al, tr_ctl, tr_girdi

ID = "trafo_kd"
BASLIK = "Kısa devrede trafo"
IKON = "💥"
GIRIS = ("AG barasında kısa devre olduğunda trafonun içinden anma akımının 15–25 katı geçer. Bu akım sargıları saniyeler içinde yüzlerce dereceye ısıtır, tepe değeri sargıları "
         "birbirinden ayırmaya çalışır. Arıza tipine göre hangi sargıdan ne akar, OG tarafı bunu nasıl görür, trafo kaç saniye dayanır? Tipi, yeri ve süreyi değiştirip izleyin.")
TIP_AD = {"3f": "üç faz", "2f": "iki faz (L2–L3)", "1f": "faz–nötr (L1–N)", "2ft": "iki faz–nötr (L2–L3–N)"}

KONTROLLER = tr_ctl() + [
    ctl("grup", "Bağlantı grubu", "sec", "Dyn11", secenek=opt(*[(g, g) for g in M.GRUPLAR])),
    ctl("yer", "Arıza yeri", "sec", "ag", secenek=opt(("ag", "AG uçları / AG ana bara"), ("og", "OG uçları (trafonun girişi)"), ("ic", "Sargının içi (sarımlar arası)"))),
    ctl("ariza", "Arıza tipi", "sec", "3f", secenek=opt(*TIP_AD.items()), goster={"yer": ["ag", "og"]}),
    ctl("sk", "Şebeke kısa devre gücü (OG barası)", "sayi", 350, min=20, max=1500, adim=10, birim="MVA"),
    ctl("t", "Arızanın süresi (korumanın temizleme süresi)", "sayi", 0.5, min=0.05, max=5, adim=0.05, birim="s", goster={"yer": ["ag"]}),
    ctl("iletken", "Sargı iletkeni", "sec", "cu", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum")), goster={"yer": ["ag"]}),
    ctl("f", "Kısa devre olan sarım oranı", "sayi", 5, min=1, max=30, adim=1, birim="%", goster={"yer": ["ic"]}),
    ctl("in_og", "OG nötr direnci toprak arıza akımı sınırı", "sayi", 1000, min=100, max=2000, adim=50, birim="A", goster={"yer": ["og"]}, yardim="Besleyen trafo merkezinin OG nötr direnciyle sınırlanan akım; 34,5 kV'ta 20 Ω direnç ≈ 1000 A"),
]


def adyabatik(j: float, t: float, th0: float, al: bool) -> float:
    """Kısa devre sonunda sargının ortalama sıcaklığı (°C). j: akım yoğunluğu (A/mm²)."""
    a, b = (45700.0, 225.0) if al else (106000.0, 235.0)
    payda = a / max(j * j * t, 1e-9) - 1
    return th0 + 2 * (th0 + b) / payda if payda > 0 else 1e4


def run(p: dict) -> dict:
    tr = tr_al(p); kuru = tr["tip"] == "kuru"
    grup, yer, tip = str(p.get("grup", "Dyn11")), str(p.get("yer", "ag")), str(p.get("ariza", "3f"))
    sk, t, al, f = num(p, "sk", 350), num(p, "t", 0.5), p.get("iletken") == "al", num(p, "f", 5) / 100
    zk = complex(tr["ur"], tr["ux"]) / 100
    zs = complex(0.0995, 0.995) * (tr["sn"] / 1000 / sk)
    xr = (zk.imag + zs.imag) / (zk.real + zs.real)
    kappa = D.kappa(xr)
    ik3_og = sk * 1000 / (math.sqrt(3) * tr["un"])                         # OG barasında üç fazlı kısa devre (A)
    th0 = 140.0 if kuru else 105.0
    sinir = (200.0 if al else 350.0) if kuru else (200.0 if al else 250.0)
    jn = (1.6 if al else 2.4) if kuru else (2.0 if al else 3.0)
    c = Cizim(900, 330)
    c.kutu(14, 50, 110, 54, "Şebeke", f"{fnum(sk, 0)} MVA")
    c.dikdortgen(190, 67, 20, 20, "cizgi", "#fff"); c.yazi(200, 108, "OG koruma", "#475569", 10, anchor="middle")
    c.daire(322, 77, 26, "cizgi"); c.daire(358, 77, 26, "cizgi"); c.yazi(340, 36, f"{grup} · uk %{fnum(tr['uk'], 1)}", "#475569", 10.5, anchor="middle")
    c.dikdortgen(470, 67, 20, 20, "cizgi", "#fff"); c.yazi(480, 108, "AG ana kesici", "#475569", 10, anchor="middle")
    girdiler = tr_girdi(tr) + [G("Şebeke kısa devre gücü", f"{fnum(sk, 0)} MVA → OG'de Ik″ = {fnum(ik3_og / 1000, 1)} kA", "Dağıtım şirketinin bağlantı görüşü", "Trafonun önündeki empedans: zayıf şebekede AG kısa devre akımı da küçülür", "Zs = Sn / Sk″ (trafo tabanında)")]

    if yer == "ag":
        r = M.hesapla(grup, zk, zs, (False, False, False), {"s": 0.0}, ariza={"tip": tip, "rf": 0.0})
        ia = [abs(x) for x in r["ia"]]; iy = [abs(x) for x in r["iy"]]; ks = r["k_sargi"]; ks_max = max(ks)
        ia_max = max(ia); ip = kappa * math.sqrt(2) * ia_max * tr["i2"]
        kuvvet = (kappa * ia_max) ** 2
        j = jn * ks_max
        th1 = adyabatik(j, t, th0, al); th2 = adyabatik(j, 2.0, th0, al)
        t_sinir = next((x / 100 for x in range(1, 2001) if adyabatik(j, x / 100, th0, al) > sinir), None)
        r3 = M.hesapla(grup, zk, zs, (False, False, False), {"s": 0.0}, ariza={"tip": "3f", "rf": 0.0})
        c.hat("M124,77 H190", "L1", hot=True, w=3); c.hat("M210,77 H296", "L1", hot=True, w=3); c.hat("M384,77 H470", "L1", hot=True, w=3); c.hat("M490,77 H640", "L1", hot=True, w=3)
        c.simsek(634, 66, 1.3); c.hat("M640,77 V118", "ariza", hot=True, w=2); c.toprak(640, 120, "ariza")
        c.yazi(660, 70, f"AG'de {TIP_AD[tip]}", "#b91c1c", 12.5, kalin=True); c.yazi(660, 90, f"Ik = {fnum(ia_max * tr['i2'] / 1000, 1)} kA", "#b91c1c", 13, kalin=True)
        c.yazi(660, 110, f"tepe {fnum(ip / 1000, 1)} kA (κ = {fnum(kappa, 2)})", "#334155", 11.5)
        c.yazi(250, 60, f"{fnum(max(iy) * tr['i1'], 0)} A", "#b91c1c", 11.5, kalin=True, anchor="middle"); c.yazi(250, 130, f"= {fnum(max(iy), 1)} × In", "#334155", 10.5, anchor="middle")
        c.yazi(20, 170, "Faz faz akımlar (anma akımının katı):", "#334155", 12, kalin=True)
        c.yazi(20, 192, "AG:  " + "   ".join(f"L{k + 1} {fnum(ia[k], 1)}" for k in range(3)), "#b91c1c", 12.5)
        c.yazi(20, 214, "OG:  " + "   ".join(f"L{k + 1} {fnum(iy[k], 1)}" for k in range(3)), "#1a4d8f", 12.5)
        c.yazi(20, 236, "Sargı (bacak):  " + "   ".join(f"{k + 1}: {fnum(ks[k], 1)}" for k in range(3)), "#334155", 12.5)
        c.yazi(470, 170, f"Sargılara etkiyen kuvvet: anma akımındakinin {fnum(kuvvet, 0)} katı", "#b91c1c", 12.5, kalin=True)
        c.yazi(470, 192, f"{fnum(t, 2)} s sonunda sargı {fnum(min(th1, 9999), 0)} °C (başlangıç {fnum(th0, 0)} °C)", "#b91c1c" if th1 > sinir else "#334155", 12.5, kalin=th1 > sinir)
        c.yazi(470, 214, f"Sınır {fnum(sinir, 0)} °C'ye varış: " + (f"{fnum(t_sinir, 2)} s" if t_sinir else "20 s içinde varmıyor"), "#334155", 12)
        c.yazi(470, 236, "Kuvvet tepe akımın karesiyle, ısınma etkin akımın karesi × süreyle artar.", "#64748b", 11)
        c.yazi(20, 276, ("OG tarafında iki fazda akım, üçüncüde yok: AG'deki faz–nötr arızası üçgen sargının yalnız bir bacağından geçer." if tip == "1f" and grup[0] == "D" else
                         "OG tarafında 1 : 1 : 2 dağılımı: AG'deki iki faz arızası üçgen–yıldız trafodan böyle geçer." if tip == "2f" and grup[0] == "D" else
                         "OG tarafında üç fazda eşit akım." if tip == "3f" else "Arızanın OG tarafındaki görüntüsü bağlantı grubuna göre değişir: «Arızanın trafodan geçişi» sayfası."), "#1a4d8f", 11.5)
        c.yazi(20, 300, "Her kısa devre sargıları biraz gevşetir: dayanım birikimlidir, ilk arızadaki gibi kalmaz.", "#64748b", 11)
        ozet = [
            K("AG arıza akımı", f"{fnum(ia_max * tr['i2'] / 1000, 1)} kA", "bad", f"{fnum(ia_max, 1)} × In · {TIP_AD[tip]}"),
            K("OG tarafında görülen", f"{fnum(max(iy) * tr['i1'], 0)} A", "warn", f"{fnum(max(iy), 1)} × In (en büyük faz)"),
            K("Tepe akım", f"{fnum(ip / 1000, 1)} kA", "warn", f"κ = {fnum(kappa, 2)} · X/R = {fnum(xr, 1)}"),
            K("Kuvvet", f"× {fnum(kuvvet, 0)}", "bad", "anma akımındaki kuvvete göre"),
            K("Sargı sıcaklığı", f"{fnum(min(th1, 9999), 0)} °C", "bad" if th1 > sinir else "ok", f"{fnum(t, 2)} s sonunda · sınır {fnum(sinir, 0)} °C"),
        ]
        kontroller = [
            C("Arıza süresi ısıl dayanım süresinin içinde mi?", f"{fnum(t, 2)} s", "≤ 2 s", t <= 2.0 + 1e-9, "Kısa devreye karşı ısıl dayanım yeteneğinin hesabında akımın süresi 2 saniyedir — " + TEDAS_H + " böl. 2.2.10", "resmi"),
            C("Sargı sıcaklığı sınırın altında mı?", f"{fnum(min(th1, 9999), 0)} °C", f"≤ {fnum(sinir, 0)} °C", th1 <= sinir, IEC5 + " — adyabatik bağıntı ve sınır değerleri asıl metinle doğrulanacak; akım yoğunluğu tipik", "dogrulanacak"),
            C("2 saniyede sargı sıcaklığı", f"{fnum(min(th2, 9999), 0)} °C", f"≤ {fnum(sinir, 0)} °C", th2 <= sinir, "Trafo uçlarındaki kısa devrede 2 s boyunca hasar görmeyecek biçimde tasarlanır — " + TEDAS_H + " böl. 2.2.10 ve 2.3.2", "resmi"),
            C("AG ana kesicinin kesme kapasitesi", f"Ik = {fnum(max(abs(x) for x in r3['ia']) * tr['i2'] / 1000, 1)} kA (üç faz)", "Icu ≥ bu değer", None, "Kesici, bulunduğu noktadaki en büyük kısa devre akımını kesebilmelidir; trafo büyüdükçe ve uk küçüldükçe akım artar", "hesap"),
            C("Tepe akım — AG bara ve pano dayanımı", f"{fnum(ip / 1000, 1)} kA", "Ipk ≥ bu değer", None, "Baraları ve mesnetleri zorlayan tepe akımdır — " + IEC909 + " (κ bağıntısı; doğrulanacak)", "dogrulanacak"),
        ]
        girdiler += [G("Korumanın temizleme süresi", f"{fnum(t, 2)} s", "OG rölesi / sigortası ve AG kesicisinin açma eğrileri", "Sargının ısınması süreyle doğru orantılıdır", "θ artışı ∝ J² · t"),
                     G("Sargı iletkeni ve akım yoğunluğu", f"{'alüminyum' if al else 'bakır'} · ≈ {fnum(jn, 1)} A/mm² (anma)", "Üretici verisi; etikette yazmaz", "Kısa devrede yoğunluk akımla aynı oranda büyür", "J = Jn · (I / In)")]
        adimlar = [
            A("Toplam empedans", "Z = Zs + Zk", f"Zs = Sn/Sk″ = {fnum(abs(zs) * 100, 2)} % · Zk = {fnum(tr['uk'], 1)} %", f"{fnum(abs(zs + zk) * 100, 2)} %", "birim değerlerle, trafo tabanında", "hesap", ["Trafo etiketi", "Şebeke kısa devre gücü"]),
            A("Üç fazlı kısa devre akımı", "Ik = In / Z", f"{fnum(tr['i2'], 0)} / {fnum(abs(zs + zk), 4)}", f"{fnum(max(abs(x) for x in r3['ia']) * tr['i2'] / 1000, 1)} kA", "trafo ve şebeke empedansı seri", "hesap"),
            A("Bu arıza tipinde akımlar", "devre çözümü: sargı bağlantısı + arıza", TIP_AD[tip], f"AG en büyük {fnum(ia_max, 1)} × In · OG en büyük {fnum(max(iy), 1)} × In", "bacak başına amper-sarım dengesi", "hesap"),
            A("Tepe akım", "ip = κ · √2 · Ik · κ = 1,02 + 0,98·e^(−3R/X)", f"X/R = {fnum(xr, 1)} → κ = {fnum(kappa, 2)}", f"{fnum(ip / 1000, 1)} kA", IEC909 + " — doğrulanacak", "dogrulanacak"),
            A("Kuvvet oranı", "F ∝ i² → (ip / (√2·In))²", f"({fnum(kappa, 2)} × {fnum(ia_max, 1)})²", f"× {fnum(kuvvet, 0)}", "paralel iletkenler arası kuvvet akımların çarpımıyla orantılıdır", "hesap"),
            A("Sargının ısınması", "θ1 = θ0 + 2(θ0 + " + ("225) / (45700" if al else "235) / (106000") + " / (J²·t) − 1)", f"J = {fnum(jn, 1)} × {fnum(ks_max, 1)} = {fnum(j, 0)} A/mm² · t = {fnum(t, 2)} s · θ0 = {fnum(th0, 0)} °C",
              f"{fnum(min(th1, 9999), 0)} °C", IEC5 + " — doğrulanacak; ısı sargıda kalır (adyabatik)", "dogrulanacak", ["Korumanın temizleme süresi", "Sargı iletkeni ve akım yoğunluğu"]),
        ]
        ayarlar = [
            S("AG ana kesici › kısa devre (S / I)", "anında ya da ≤ 0,3 s", "—", "AG bara arızasını trafoya en yakın noktada keser", "saha pratiği", "ikincil"),
            S("OG rölesi › I>>", f"AG arızasının OG'deki karşılığının üstünde: > {fnum(max(abs(x) for x in r3['iy']), 1)} × In", "—", "Ani kademe AG arızasında çalışmamalı (seçicilik); trafo içi arızada çalışmalı", "Röle laboratuvarı › Faz aşırı akım", "ikincil"),
            S("OG rölesi › I> (gecikmeli)", "AG kesicisinin üstünde zaman kademesi; toplam ≤ 2 s", "—", "AG kesicisi açamazsa trafoyu ısıl dayanım süresi içinde kurtarır", TEDAS_H + " böl. 2.2.10"),
            S("OG sigortası", "AG uç arızasını 2 s içinde eritmeli", "—", "Sigortalı korumada erime süresi AG arıza akımının OG karşılığından okunur", "saha pratiği", "ikincil"),
        ]
        test = [
            T("Arıza kaydı", "OG rölesinin / AG açtırıcının olay kaydı", f"AG'de ≈ {fnum(ia_max * tr['i2'] / 1000, 1)} kA, OG'de ≈ {fnum(max(iy) * tr['i1'], 0)} A; süre", "süre 2 s'yi aştıysa trafo deneyden geçirilir"),
            T("Arızadan sonra trafo", "Sargı direnci, çevirme oranı, yalıtım direnci; mümkünse kısa devre empedansı / SFRA", "önceki değerlerle aynı", "uk'daki %2–3'lük değişim sargı kaymasını gösterir"),
            T("Ses ve gaz", "Arıza anında gürleme; sonrasında Buchholz / çok fonksiyonlu rölede gaz", "gaz yok, ses olağan", "gaz varsa iç hasar"),
        ]
        ts = [k / 2000 for k in range(0, 201)]
        j0 = max(range(3), key=lambda k: ia[k])
        g1 = {"baslik": "Kısa devre akımının dalga biçimi (en büyük AG fazı, en kötü kapama anı)", "x_ad": "Zaman (ms)", "y_ad": "Akım (kA)", "zaman": True,
              "seriler": [{"ad": f"L{j0 + 1}", "renk": "#dc2626", "pts": pts([x * 1000 for x in ts], [D.kd_akim(ia_max * tr["i2"] / 1000, xr, math.degrees(math.atan(xr)) - 90, x) for x in ts], 2)}],
              "yatay": [{"y": ip / 1000, "etiket": "tepe", "renk": "#7c3aed"}]}
        tt = [0.05 * k for k in range(1, 101)]
        g2 = {"baslik": "Sargı sıcaklığı – arıza süresi", "x_ad": "Süre (s)", "y_ad": "Sargı sıcaklığı (°C)", "ymax": 600,
              "seriler": [{"ad": TIP_AD[tip], "renk": "#dc2626", "pts": pts(tt, [min(adyabatik(j, x, th0, al), 600) for x in tt], 1)}],
              "yatay": [{"y": sinir, "etiket": f"sınır {fnum(sinir, 0)} °C", "renk": "#dc2626"}], "isaretler": [{"x": t, "etiket": "süre"}, {"x": 2.0, "etiket": "2 s"}]}
        satir = []
        for tp in ("3f", "2f", "1f", "2ft"):
            q = M.hesapla(grup, zk, zs, (False, False, False), {"s": 0.0}, ariza={"tip": tp, "rf": 0.0})
            satir.append([TIP_AD[tp], " / ".join(fnum(abs(x), 1) for x in q["ia"]), " / ".join(fnum(abs(x), 1) for x in q["iy"]), " / ".join(fnum(x, 1) for x in q["k_sargi"]),
                          f"{fnum(max(abs(x) for x in q['ia']) * tr['i2'] / 1000, 1)} kA", f"{fnum(max(abs(x) for x in q['iy']) * tr['i1'], 0)} A"])
        fz = {"baslik": "OG hat akımları", "vektorler": [fazor(f"L{k + 1}", r["iy"][k], RENK3[k]) for k in range(3)]}
        fz2 = {"baslik": "AG akımları", "vektorler": [fazor(f"L{k + 1}", r["ia"][k], RENK3[k]) for k in range(3)]}
        return {
            "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(fazorler=[fz2, fz]), "grafikler": [g1, g2],
            "ses": [{"ad": "Kısa devre anı", "not": "sargılar ve tank 100 Hz'lik kuvvetle sarsılır: kısa, sert bir gürleme", "sure": 0.9, "zarf": "sonen", "tau": 0.12, "taban": 0.0, "siddet": 1.0,
                     "parcalar": [{"f": 100, "a": 1.0}, {"f": 50, "a": 0.7}, {"f": 200, "a": 0.5}, {"f": 300, "a": 0.3}], "gurultu": 0.5, "gurultu_f": 600}],
            "anlatim": [
                f"AG'de {TIP_AD[tip]} kısa devresi: akımı yalnız trafonun kısa devre empedansı (%{fnum(tr['uk'], 1)}) ve önündeki şebeke sınırlar. En büyük fazda {fnum(ia_max, 1)} × In = {fnum(ia_max * tr['i2'] / 1000, 1)} kA.",
                "Arıza tipi sargılardaki dağılımı değiştirir: üç fazda üç bacak eşit yüklenir; iki fazda ve faz–nötr arızasında akım bir ya da iki bacağa yığılır. OG hatlarında görülen dağılımı sargı bağlantısı belirler.",
                f"Akımın ilk tepesi simetrik tepenin {fnum(kappa, 2)} katıdır (doğru bileşen). Kuvvet akımın karesiyle orantılı olduğundan sargılar anma akımındakinin {fnum(kuvvet, 0)} katı kuvvetle zorlanır: iç sargı içe ezilir, dış sargı dışa gerilir, sarımlar eksen boyunca sıkışır.",
                f"Isı sargıdan çıkmaya fırsat bulamaz: bakırın ya da alüminyumun kendi ısı sığası ısınır. {fnum(t, 2)} saniyede sargı {fnum(th0, 0)} °C'den {fnum(min(th1, 9999), 0)} °C'ye çıkar.",
                "Trafo bu zorlamaya 2 saniye dayanacak biçimde yapılır. Koruma bu süreyi aşarsa yalıtım kavrulur; aşmasa bile her arıza sıkıştırma takozlarını biraz gevşetir.",
                "Kuvvetin frekansı 100 Hz'dir: arıza anında duyulan sert gürleme sargıların ve tankın bu kuvvetle sarsılmasıdır.",
            ],
            "dersler": [
                "AG kısa devre akımı ≈ I2n / uk. %4'lük trafo %6'lıktan 1,5 kat fazla akım verir ve kendisi de o kadar zorlanır.",
                "Kuvvet tepe akımın karesiyle, ısınma etkin akımın karesi × süreyle büyür: ilki ilk yarım periyotta, ikincisi koruma açana kadar.",
                "Faz–nötr arızası Dyn trafoda OG'de iki fazda ve 0,577 katı görünür: OG koruması üç faz arızasına göre daha yavaş açar.",
                "Trafonun kısa devre dayanımı birikimlidir. Ağır bir arızadan sonra oran, direnç ve empedans ölçülmeden yeniden enerjilendirmek kumardır.",
                "2 saniye bir tasarım süresidir, izin değil: koruma ne kadar hızlıysa trafo o kadar uzun yaşar.",
            ],
            "tablolar": [{"baslik": f"Arıza tipine göre akımlar ({grup}, anma akımının katı — L1 / L2 / L3)", "cols": ["Arıza", "AG akımları", "OG hat akımları", "Sargı (bacak 1 / 2 / 3)", "AG en büyük", "OG en büyük"], "rows": satir,
                          "not": "OG tarafındaki dağılım korumanın gördüğüdür. Dyn trafoda faz–nötr arızası OG'de 0,577 : 0,577 : 0, iki faz arızası 0,5 : 0,5 : 1 oranında görünür."}],
        }

    if yer == "og":
        oran = {"3f": 1.0, "2f": math.sqrt(3) / 2, "2ft": 1.0}
        i_f = num(p, "in_og", 1000) if tip == "1f" else ik3_og * oran[tip]
        c.hat("M124,77 H190", "L1", hot=True, w=3); c.hat("M210,77 H280", "L1", hot=True, w=3); c.hat("M384,77 H470", "L1", w=3); c.hat("M490,77 H640", "L1", w=3)
        c.simsek(274, 66, 1.3); c.hat("M280,77 V118", "ariza", hot=True, w=2); c.toprak(280, 120, "ariza")
        c.kutu(640, 50, 130, 54, "AG yükü", "gerilimsiz kalır")
        c.yazi(20, 170, f"OG uçlarında {TIP_AD[tip].replace('nötr', 'toprak').replace('L1–N', 'L1–toprak').replace('L2–L3–N', 'L2–L3–toprak')}: {fnum(i_f / 1000, 2)} kA — akımı şebeke verir.", "#b91c1c", 13, kalin=True)
        c.yazi(20, 194, "Trafonun sargılarından arıza akımı geçmez: trafo arızanın arkasındadır.", "#334155", 12)
        c.yazi(20, 216, "Yalnız AG'deki dönen motorlar birkaç periyot boyunca küçük bir katkı verir.", "#334155", 12)
        c.yazi(20, 238, ("Toprak arıza akımını şebekenin empedansı değil, trafo merkezindeki nötr direnci sınırlar." if tip == "1f" else "İki faz arızası üç faz arızasının 0,866 katıdır." if tip == "2f" else
                         "Üç faz arızası OG barasının kısa devre gücünü olduğu gibi yansıtır." if tip == "3f" else "İki faz–toprak arızasında faz akımları üç faz arızası mertebesindedir; toprak akımı nötr direnciyle sınırlıdır."), "#1a4d8f", 12)
        c.yazi(20, 270, "Bu arızayı OG hücresinin koruması (aşırı akım / toprak) temizler; trafonun kendi korumaları görmez.", "#64748b", 11.5)
        ozet = [K("OG arıza akımı", f"{fnum(i_f / 1000, 2)} kA", "bad", TIP_AD[tip].replace("nötr", "toprak").replace("L1–N", "L1–toprak").replace("L2–L3–N", "L2–L3–toprak")), K("Trafodan geçen", "≈ 0", "ok", "trafo arızanın arkasında"),
                K("Trafo anma akımına oranı", f"× {fnum(i_f / tr['i1'], 0)}", "info", f"I1n = {fa(tr['i1'], 1)}"), K("OG'de Ik″ (üç faz)", f"{fnum(ik3_og / 1000, 1)} kA", "info", f"{fnum(sk, 0)} MVA"),
                K("AG tarafı", "gerilimsiz", "warn", "arıza süresince")]
        kontroller = [
            C("Arıza akımını kim verir?", "şebeke", "trafo değil", None, "Arıza trafonun giriş uçlarındadır: akım kaynaktan arıza yerine akar, sargılardan geçmez", "hesap"),
            C("OG donanımının kısa süreli dayanım akımı", f"Ik″ = {fnum(ik3_og / 1000, 1)} kA", "hücre ve kablo başlığı ≥ bu değer (ör. 16 kA / 1 s)", ik3_og / 1000 <= 16, "Hücre, ayırıcı, kablo başlığı ve buşingler bu akıma dayanmalıdır", "hesap"),
            C("Toprak arıza akımı", f"{fnum(num(p, 'in_og', 1000), 0)} A", "nötr direnciyle sınırlı", None, "34,5 kV dağıtım şebekesinde besleyen trafonun OG nötrü direnç üzerinden topraklıdır (20 Ω ≈ 1000 A); değer işletmeye göre değişir", "ikincil"),
        ]
        adimlar = [A("OG barasında üç fazlı kısa devre", "Ik″ = Sk″ / (√3 · Un)", f"{fnum(sk, 0)} MVA / (1,732 × {fnum(tr['un'], 1)} kV)", f"{fnum(ik3_og / 1000, 2)} kA", "kısa devre gücünün tanımı", "hesap", ["Şebeke kısa devre gücü"]),
                   A("Bu arıza tipinde", "2f: √3/2 · Ik″ · 1f: nötr direnci belirler", TIP_AD[tip], f"{fnum(i_f / 1000, 2)} kA", "simetrili bileşenler", "hesap")]
        return {"ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "sahne": c.sahne(),
                "ayarlar": [S("OG rölesi › I>> / I>", "arıza hattın başındaki hücrede temizlenir", "—", "Trafo fideri korumasının ani kademesi OG uç arızasını görür", "Röle laboratuvarı › Faz aşırı akım", "ikincil"),
                            S("OG rölesi › Io> (toprak)", "nötr direnci akımının altında, duyarlı", "—", "Toprak arıza akımı küçüktür; faz kademeleri görmeyebilir", "Röle laboratuvarı › Toprak aşırı akım", "ikincil")],
                "test": [T("Arıza göstergeleri", "Hücredeki arıza akımı göstergesi, röle olay kaydı", "arızalı faz(lar) ve akım", "trafo deneyden geçirilmeden enerjilenmez: buşing ve kablo başlığı gözle incelenir")],
                "anlatim": ["Arıza trafonun OG uçlarında (buşing, kablo başlığı, parafudr) ise akımı şebeke verir; trafonun sargılarından geçmez. Trafo için bu bir kısa devre zorlaması değildir.",
                            f"Akımı OG barasının kısa devre gücü belirler: üç fazda {fnum(ik3_og / 1000, 1)} kA. Trafonun gücü ve uk'sı bu akımı etkilemez.",
                            "Toprak arızasında durum farklıdır: OG şebekesinin nötrü direnç üzerinden topraklı olduğundan akım birkaç yüz – bin amperle sınırlıdır. Faz arızalarına göre çok küçüktür ve ayrı bir toprak koruması ister.",
                            "Arıza süresince AG tarafı gerilimsiz kalır; AG'deki motorlar ilk birkaç periyotta arızaya küçük bir katkı verir, sonra yavaşlar."],
                "dersler": ["OG uç arızasında trafo kurbandır, kaynak değil: akım şebekeden gelir.", "OG toprak arıza akımı faz arıza akımının yanında çok küçüktür; onu nötr direnci belirler.",
                            "AG'deki arıza trafodan geçerek OG'de görünür; OG'deki arıza AG'de yalnız gerilim kaybı olarak görünür."]}

    # ---- sarımlar arası kısa devre ----
    di = f * f / (tr["uk"] / 100)
    c.hat("M124,77 H190", "L1", hot=True, w=3); c.hat("M210,77 H296", "L1", hot=True, w=3); c.hat("M384,77 H470", "L1", w=3); c.hat("M490,77 H640", "L1", w=3)
    c.simsek(332, 64, 1.3); c.kutu(640, 50, 130, 54, "AG yükü", "çalışmaya devam")
    c.yazi(20, 170, f"Sargının %{fnum(f * 100, 0)}'i kendi içinde kısa devre.", "#b91c1c", 13, kalin=True)
    c.yazi(20, 194, f"Trafonun uçlarında akım yalnız ≈ %{fnum(di * 100, 1)} artar: aşırı akım rölesi görmez.", "#334155", 12.5, kalin=True)
    c.yazi(20, 216, "Kısa devre olan sarımların içinde ise anma akımının onlarca katı dolaşır.", "#b91c1c", 12)
    c.yazi(20, 238, "O bölge hızla ısınır; yağ ayrışır, gaz çıkar, arıza komşu sarımlara yayılır.", "#334155", 12)
    c.yazi(20, 270, "Bunu gören: gaz / basınç koruması (yağlı), diferansiyel röle (duyarlıysa), kuru tipte sıcaklık ve koku.", "#1a4d8f", 12)
    ozet = [K("Kısa devre olan sarım", f"%{fnum(f * 100, 0)}", "bad", "aynı sargının içinde"), K("Uç akımındaki artış", f"≈ %{fnum(di * 100, 1)} In", "warn" if di < 0.2 else "bad", "f² / uk — kaba kabul"),
            K("Aşırı akım rölesi", "görmez" if di < 0.3 else "görebilir", "bad" if di < 0.3 else "warn", "ayar ≈ 1,2–1,5 × In"), K("Gaz / basınç koruması", "görür", "ok", "yağlı trafoda"),
            K("Diferansiyel", "görür" if di > 0.15 else "sınırda", "ok" if di > 0.15 else "warn", "başlatma ≈ %15–30")]
    kontroller = [
        C("Aşırı akım koruması bu arızayı görür mü?", f"uç akımı artışı ≈ %{fnum(di * 100, 1)} In", "> %20–50 (I> ayarının yükün üstünde kalan payı)", di > 0.3, "Küçük bir sarım grubunun kısa devresi uç akımını çok az değiştirir; arıza büyüyene kadar akım korumasına görünmez", "tahmini"),
        C("Trafonun kendi koruması var mı?", "gaz birikmesi / basınç" if not kuru else "sargı sıcaklığı (yavaş)", "yağlı trafoda ≥ 630 kVA", None if kuru else tr["sn"] >= 630,
          "Çok fonksiyonlu koruma rölesi (gaz birikmesi, basınç) / Buchholz rölesi 630 kVA ve üstünde bulunur — " + TEDAS_H + " böl. 2.3.11", "resmi"),
    ]
    fs = [x / 100 for x in range(1, 31)]
    g1 = {"baslik": "Kısa devre olan sarım oranına göre uç akımındaki artış", "x_ad": "Kısa devre olan sarım (%)", "y_ad": "Uç akımı artışı (% In)",
          "seriler": [{"ad": "ΔI ≈ f² / uk", "renk": "#dc2626", "pts": pts([x * 100 for x in fs], [x * x / (tr["uk"] / 100) * 100 for x in fs], 2)}],
          "yatay": [{"y": 30, "etiket": "aşırı akım görmeye başlar", "renk": "#7c3aed"}, {"y": 15, "etiket": "diferansiyel başlatma", "renk": "#15803d"}], "isaretler": [{"x": f * 100, "etiket": "seçili"}]}
    return {"ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "sahne": c.sahne(), "grafikler": [g1],
            "adimlar": [A("Uç akımındaki değişim", "ΔI ≈ f² / uk", f"{fnum(f, 2)}² / {fnum(tr['uk'] / 100, 3)}", f"≈ %{fnum(di * 100, 1)} In", "kısa devre olan bölüm küçük bir oto-trafo gibi davranır — kaba kabul", "tahmini", ["Trafo etiketi"])],
            "ayarlar": [S("Gaz birikmesi / Buchholz 1. kademe", "ihbar ya da açma", "—", "Sarımlar arası arızanın ilk ve çoğu zaman tek belirtisi", TEDAS_H + " böl. 2.3.11"),
                        S("Basınç kontağı / Buchholz 2. kademe", "açma", "—", "Arıza büyüyüp ark başlayınca", TEDAS_H + " böl. 2.3.11"),
                        S("Diferansiyel (87T)", "başlatma %15–30", "—", "Büyük trafolarda sarımlar arası arızayı akımdan gören tek koruma", "Röle laboratuvarı › Diferansiyel", "ikincil")],
            "test": [T("Sargı direnci ve çevirme oranı", "Üç fazda karşılaştırmalı", "arızalı fazda oran sapar, direnç düşer", "oran toleransı ±%0,5"), T("Yağda çözünmüş gaz", "Yağ örneği laboratuvara", "asetilen ve hidrojen: ark / kısmi boşalma", "gaz varsa enerjilenmez"),
                     T("Boşta akım", "Düşük gerilimle üç fazda", "arızalı bacağın akımı ötekilerden yüksek", "sahada en kolay yapılan karşılaştırma")],
            "anlatim": ["Sarımlar arası kısa devre, yalıtımı yıpranmış birkaç sarımın birbirine değmesidir: yaşlanma, yıldırım darbesi ya da önceki kısa devrelerin gevşettiği sargı yüzünden.",
                        f"Kısa devre olan sarımlar çekirdeğin akısını hâlâ keser ve üzerlerinde gerilim endüklenir; bu gerilim neredeyse sıfır dirençli bir halkada anma akımının onlarca katı akım dolaştırır. Dışarıdan bakıldığında ise uç akımı yalnız ≈ %{fnum(di * 100, 1)} artmıştır.",
                        "Bu yüzden arıza akım korumalarına görünmez. Isınan bölge yağı ayrıştırır: gaz kabarcıkları yukarı çıkar ve gaz rölesinde birikir. İlk uyarı buradan gelir.",
                        "Arıza kendi kendine sönmez; komşu sarımları da yakarak büyür ve sonunda faz–toprak ya da fazlar arası arızaya döner. O zaman akım korumaları açar ama sargı çoktan kaybedilmiştir."],
            "dersler": ["Sarımlar arası kısa devrede uç akımı küçük, sarım içi akım çok büyüktür: akım koruması görmez, gaz koruması görür.", "Gaz ihbarı «yanlış alarm» sayılmaz; gazın yanıcılığı denetlenmeden trafo enerjilenmez.",
                        "Kuru tip trafoda gaz koruması yoktur: kısmi boşalma ölçüsü ve sıcaklık izleme erken uyarının yerini tutar."]}
