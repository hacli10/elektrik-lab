"""Akım sınırlama ve geçen enerji: sigorta ve sınırlayıcı kesici, kısa devre akımı ilk tepesine varmadan devreyi keser. Kesilen tepe akım, geçen I²t;
sınırlamanın kabloya, baraya ve arka arkaya korumaya etkisi.

NH gG sigortanın ön-ark I²t değerleri laboratuvarın kural verisindendir (IEC 60269 — dogrulanacak); toplam I²t ≈ 2 × ön-ark (400 V). Kesilen tepe akım için
ic ≈ 8,9·In^0,75·Ik^(1/3) bağıntısı üretici sınırlama eğrilerine uydurulmuş yaklaşık bir bağıntıdır (tahmini). Otomatın geçirdiği enerji için enerji sınırlama sınıfı 3 değerleri
(TS EN 60898-1 Ek ZC — dogrulanacak). Sınırlamasız kesicide akım en az yarım periyot (10 ms) akar."""
from __future__ import annotations

import math

from ..lab.core import ruleset
from . import fizik as F
from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, logsp, num, opt, pts

ID = "sinirlama"
BASLIK = "Akım sınırlama"
IKON = "✋"
GIRIS = ("50 kA'lik bir kısa devre akımı ilk tepesinde 100 kA'in üstüne çıkar. Sigorta buna izin vermez: teli birkaç milisaniyede erir, ark gerilimi akımı geri iter ve devre, akım "
         "tepesine varmadan kesilir. Geçen enerji yüzde birlere iner. Sigortayı ve kısa devre akımını değiştirin; kesilen tepeyi ve geçen enerjiyi izleyin.")
IN_A = (16, 25, 32, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 630)
KESIT = (1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240)

KONTROLLER = [
    ctl("cihaz", "Koruma cihazı", "sec", "gG", secenek=opt(("gG", "NH sigorta gG (akım sınırlayan)"), ("mcb", "Otomat (enerji sınırlama sınıfı 3)"), ("acb", "Sınırlamasız kesici (açık tip, gecikmeli)"))),
    ctl("in_a", "Anma akımı In", "sec", 100, secenek=opt(*[(k, f"{k} A") for k in IN_A])),
    ctl("ik", "Beklenen kısa devre akımı (etkin)", "sayi", 25.0, min=0.5, max=100, adim=0.5, birim="kA"),
    ctl("kappa", "Tepe katsayısı κ", "sayi", 1.8, min=1.02, max=2.0, adim=0.02),
    ctl("s", "Korunan kablonun kesiti", "sec", 16, secenek=opt(*[(k, f"{str(k).replace('.', ',')} mm²") for k in KESIT])),
    ctl("t_acb", "Sınırlamasız kesicinin açma süresi", "sayi", 0.3, min=0.03, max=1.0, adim=0.01, birim="s", goster={"cihaz": ["acb"]}),
]


def sigorta(in_a: float, ik: float, ip: float) -> dict:
    nh = ruleset().breakers["nh"]["i2t_on_ark_max_ka2s"]
    on_ark = nh.get(str(int(in_a)), 0.6e-3 * in_a ** 2.5) * 1000          # A²s
    ic = min(8.9 * in_a ** 0.75 * ik ** (1 / 3), ip)
    sinirliyor = ic < ip * 0.98
    i2t = 2 * on_ark if sinirliyor else max(2 * on_ark, ik * ik * 0.01)
    return {"ic": ic, "i2t": i2t, "sinirliyor": sinirliyor, "on_ark": on_ark, "t": 2 * on_ark / (ik * ik) if sinirliyor else 0.01}


def run(p: dict) -> dict:
    cihaz, in_a, ik, kappa, s = str(p.get("cihaz", "gG")), num(p, "in_a", 100), num(p, "ik", 25.0) * 1000, num(p, "kappa", 1.8), num(p, "s", 16)
    ip = kappa * math.sqrt(2) * ik
    i2t_yarim = ik * ik * 0.01
    if cihaz == "gG":
        q = sigorta(in_a, ik, ip); ic, i2t, sinirliyor = q["ic"], q["i2t"], q["sinirliyor"]; ad = f"NH gG {in_a:g} A"
        dayanak, durum = "ön-ark I²t: IEC 60269 kapı değerleri (doğrulanacak); kesilen tepe: üretici eğrilerine uydurulmuş bağıntı", "dogrulanacak"
    elif cihaz == "mcb":
        tab = ruleset().breakers["mcb"]["enerji_siniri_sinif3_a2s"]
        ika = "6" if ik <= 6000 else "10"
        i2t = tab[ika]["16" if in_a <= 16 else "32"]["C"] * (1.0 if in_a <= 32 else (in_a / 32) ** 1.5) * min((ik / (6000 if ika == "6" else 10000)) ** 1.0, 1.0)
        ic = min(math.sqrt(i2t / 0.004) * 1.2, ip); sinirliyor = ic < ip * 0.98; ad = f"otomat C{in_a:g}"
        dayanak, durum = "enerji sınırlama sınıfı 3, izin verilen en büyük I²t — TS EN 60898-1 Ek ZC (doğrulanacak); 32 A üstü ölçeklenmiştir", "dogrulanacak"
    else:
        t_a = num(p, "t_acb", 0.3)
        i2t, ic, sinirliyor, ad = ik * ik * t_a, ip, False, f"sınırlamasız kesici {in_a:g} A ({fnum(t_a, 2)} s)"
        dayanak, durum = "akım, kesici açana kadar tam değeriyle akar", "hesap"
    k = F.k_katsayi("cu", 70, 160)
    s_min = math.sqrt(i2t) / k
    kuvvet_oran = (ic / ip) ** 2
    c = Cizim(900, 290)
    c.kutu(30, 60, 110, 54, "Kaynak", f"{fnum(ik / 1000, 1)} kA")
    c.hat("M140,87 H230", "L1", hot=True, w=3); c.dikdortgen(230, 76, 40, 22, "ariza", "#fee2e2"); c.yazi(250, 64, ad, "#b91c1c", 11, kalin=True, anchor="middle")
    c.hat("M270,87 H470", "L1", hot=True, w=3); c.yazi(370, 76, f"kablo {str(s).replace('.', ',')} mm² Cu/PVC", "#334155", 10.5, anchor="middle"); c.simsek(462, 76, 1.2)
    c.yazi(540, 56, f"Beklenen tepe {fnum(ip / 1000, 1)} kA → kesilen tepe {fnum(ic / 1000, 1)} kA", "#b91c1c" if not sinirliyor else "#15803d", 13.5, kalin=True)
    c.yazi(540, 82, "Sınırlıyor: akım tepesine varmadan kesildi" if sinirliyor else "Sınırlamıyor: akım tam tepesine çıkıyor", "#15803d" if sinirliyor else "#b91c1c", 12.5, kalin=True)
    c.yazi(540, 108, f"Geçen I²t = {fnum(i2t / 1e6, 3)} × 10⁶ A²s", "#334155", 12.5)
    c.yazi(540, 130, f"(yarım periyotta sınırlamasız: {fnum(i2t_yarim / 1e6, 2)} × 10⁶ → %{fnum(i2t / i2t_yarim * 100, 1)})", "#64748b", 11)
    c.yazi(540, 156, f"Baralara binen kuvvet: sınırlamasız değerin %{fnum(kuvvet_oran * 100, 0)}'i", "#334155", 12.5)
    c.yazi(540, 180, f"Bu enerjiyle korunabilen en küçük kablo: {fnum(s_min, 1)} mm²", "#b91c1c" if s < s_min else "#1a4d8f", 12.5, kalin=True)
    c.yazi(30, 150, "Tel erir (ön-ark) → ark yanar → ark gerilimi kaynak", "#64748b", 11); c.yazi(30, 166, "gerilimini aşar → akım sıfıra itilir.", "#64748b", 11)
    c.yazi(30, 196, "Küçük akımda sigorta sınırlamaz: tel, akım tepesinden", "#64748b", 11); c.yazi(30, 212, "sonra erir. Sınırlama, anma akımının ≈ 20–30 katının", "#64748b", 11); c.yazi(30, 228, "üstünde başlar.", "#64748b", 11)
    ozet = [
        K("Kesilen tepe akım", f"{fnum(ic / 1000, 1)} kA", "ok" if sinirliyor else "bad", f"beklenen {fnum(ip / 1000, 1)} kA"),
        K("Geçen I²t", f"{fnum(i2t / 1000, 0)} kA²s", "ok" if i2t <= (k * s) ** 2 else "bad", f"kablo dayanımı k²S² = {fnum((k * s) ** 2 / 1000, 0)} kA²s"),
        K("Enerji oranı", f"%{fnum(i2t / i2t_yarim * 100, 1)}", "ok" if i2t < 0.2 * i2t_yarim else "warn", "sınırlamasız yarım periyoda göre"),
        K("Kuvvet oranı", f"%{fnum(kuvvet_oran * 100, 0)}", "ok" if kuvvet_oran < 0.5 else "warn", "(kesilen tepe / beklenen tepe)²"),
        K("Korunabilen en küçük kesit", f"{fnum(s_min, 1)} mm²", "bad" if s < s_min else "ok", "bakır / PVC, k = 115"),
    ]
    kontroller = [
        C("Kablo geçen enerjiye dayanıyor mu?", f"I²t = {fnum(i2t / 1000, 0)} kA²s", f"≤ k²S² = {fnum((k * s) ** 2 / 1000, 0)} kA²s", i2t <= (k * s) ** 2, "0,1 s'den kısa açmalarda kablonun ısıl dayanımı, cihazın geçirdiği I²t ile karşılaştırılır (TS HD 60364-4-43 — asıl metinle doğrulanacak); " + dayanak, durum),
        C("Cihaz akımı sınırlıyor mu?", f"kesilen tepe {fnum(ic / 1000, 1)} kA", f"< beklenen tepe {fnum(ip / 1000, 1)} kA", sinirliyor, "Sınırlama için tel (ya da kontak) ilk çeyrek periyotta açılmalıdır: akım yeterince büyük olmalı", "tahmini" if cihaz == "gG" else durum),
        C("Arkadaki donanımın tepe dayanımı", f"{fnum(ic / 1000, 1)} kA tepe görür", "donanımın tepe dayanım akımına göre", None, "Sınırlayan cihazın arkasındaki bara, kontaktör ve kesiciler kesilen tepeye göre seçilebilir (arka arkaya koruma); geçerliliği üretici çizelgesiyle doğrulanır", "ikincil"),
    ]
    girdiler = [
        G("Beklenen kısa devre akımı", f"{fnum(ik / 1000, 1)} kA · κ = {fnum(kappa, 2)}", "Kısa devre hesabı: cihazın bulunduğu noktada", "Sınırlama, akım cihazın anma akımına göre ne kadar büyükse o kadar etkilidir", "ip = κ·√2·Ik"),
        G("Cihazın sınırlama verisi", ad, "Üretici kataloğu: kesilen akım eğrisi ve I²t eğrisi", "Kesilen tepe ve geçen enerji katalogdan okunur", "ic(Ik), I²t(Ik)"),
        G("Korunan kablo", f"{str(s).replace('.', ',')} mm² Cu/PVC", "Proje", "Isıl dayanımı k²S²", f"{fnum((k * s) ** 2 / 1000, 0)} kA²s"),
    ]
    adimlar = [
        A("Beklenen tepe", "ip = κ · √2 · Ik", f"{fnum(kappa, 2)} × 1,414 × {fnum(ik / 1000, 1)}", f"{fnum(ip / 1000, 1)} kA", "cihaz olmasaydı akacak akımın ilk tepesi", "hesap", ["Beklenen kısa devre akımı"]),
        A("Kesilen tepe", "ic ≈ 8,9 · In^0,75 · Ik^(1/3)" if cihaz == "gG" else "ic: cihazın sınırlama eğrisinden", f"In = {in_a:g} A · Ik = {fnum(ik, 0)} A", f"{fnum(ic / 1000, 1)} kA", "üretici sınırlama eğrilerine uydurma" if cihaz == "gG" else dayanak, "tahmini" if cihaz != "acb" else "hesap", ["Cihazın sınırlama verisi"]),
        A("Geçen enerji", "I²t = ön-ark + ark" if cihaz == "gG" else "I²t", "toplam ≈ 2 × ön-ark" if cihaz == "gG" else ad, f"{fnum(i2t / 1000, 0)} kA²s", dayanak, durum),
        A("Kablonun dayanımı", "k² · S²", f"115² × {str(s).replace('.', ',')}²", f"{fnum((k * s) ** 2 / 1000, 0)} kA²s", "adyabatik ısınma: bakır / PVC, 70 → 160 °C", "hesap", ["Korunan kablo"]),
        A("Korunabilen en küçük kesit", "S = √(I²t) / k", f"√{fnum(i2t, 0)} / 115", f"{fnum(s_min, 1)} mm²", "geçen enerjiye göre", "hesap"),
    ]
    ayarlar = [
        S("Arka arkaya koruma (back-up)", "sınırlayan üst cihaz, kesme kapasitesi düşük alt cihazı korur", "—", "Alt cihazın kesme kapasitesi kısa devre akımının altında olabilir; geçerliliği yalnız üreticinin doğruladığı çiftler için", "üretici çizelgesi", "ikincil"),
        S("Sigorta seçimi", "motor devresinde aM, dağıtımda gG", "—", "Sınırlama kısa devrede; aşırı yük için ayrı koruma", "saha pratiği", "ikincil"),
        S("Kısa devre kesme kapasitesi", f"NH gG: 120 kA" if cihaz == "gG" else "cihaz etiketi (Icn / Icu)", "—", "Sigortanın kesme kapasitesi çok yüksektir: büyük kısa devre akımlı baralarda tercih nedeni", "kural verisi (TS EN 60269 — doğrulanacak)", "dogrulanacak"),
    ]
    test = [T("Sigorta değişimi", "Atan sigorta aynı tip ve anma akımıyla değiştirilir; üç faz birlikte", "tek fazı değiştirilen takımda öbür ikisi yorgundur", "köprüleme, tel sarma: sınırlama da kesme de kalmaz"),
            T("Arıza sonrası", "Kablo, bara ve kontaklarda hasar", "sınırlayan cihazın arkasında hasar çok azdır", "hasar büyükse cihaz sınırlamamıştır: akım küçük ya da cihaz yanlış")]
    iks = logsp(500, 100000, 50)
    g1 = {"baslik": "Sınırlama eğrisi: beklenen akıma göre kesilen tepe", "x_ad": "Beklenen kısa devre akımı (A, etkin)", "y_ad": "Tepe akım (A)", "logx": True, "logy": True,
          "seriler": [{"ad": "sınırlamasız tepe (κ·√2·Ik)", "renk": "#94a3b8", "kesik": True, "pts": pts(iks, [kappa * math.sqrt(2) * x for x in iks], 0)}] +
                     [{"ad": f"gG {n} A", "renk": rk, "pts": pts(iks, [sigorta(n, x, kappa * math.sqrt(2) * x)["ic"] for x in iks], 0)} for n, rk in ((32, "#15803d"), (100, "#1a4d8f"), (250, "#b45309"), (630, "#dc2626"))],
          "isaretler": [{"x": ik, "etiket": "Ik"}]}
    g2 = {"baslik": "Beklenen akıma göre geçen I²t", "x_ad": "Beklenen kısa devre akımı (A, etkin)", "y_ad": "I²t (A²s)", "logx": True, "logy": True,
          "seriler": [{"ad": "sınırlamasız, 10 ms", "renk": "#94a3b8", "kesik": True, "pts": pts(iks, [x * x * 0.01 for x in iks], 0)}] +
                     [{"ad": f"gG {n} A", "renk": rk, "pts": pts(iks, [sigorta(n, x, kappa * math.sqrt(2) * x)["i2t"] for x in iks], 0)} for n, rk in ((32, "#15803d"), (100, "#1a4d8f"), (250, "#b45309"), (630, "#dc2626"))],
          "yatay": [{"y": (k * s) ** 2, "etiket": f"kablo {str(s).replace('.', ',')} mm²", "renk": "#7c3aed"}], "isaretler": [{"x": ik, "etiket": "Ik"}]}
    ts = [j * 0.1 for j in range(0, 201)]
    t_kes = min(max(2 * (i2t / (ic * ic)) * 1000 if sinirliyor else 20.0, 1.0), 20.0)
    g3 = {"baslik": "İlk periyotta akım: sınırlamasız ve sınırlı", "x_ad": "Zaman (ms)", "y_ad": "Akım (kA)", "zaman": True,
          "seriler": [{"ad": "sınırlamasız", "renk": "#94a3b8", "kesik": True, "pts": pts(ts, [math.sqrt(2) * ik / 1000 * (math.sin(math.pi * t / 10 - math.pi / 2) + math.exp(-t / 45) * (kappa - 1.02) / 0.78 + (1 - (kappa - 1.02) / 0.78) * 0) for t in ts], 2)},
                      {"ad": "bu cihazla", "renk": "#dc2626", "pts": pts(ts, [(ic / 1000 * math.sin(math.pi * min(t, t_kes) / t_kes) if t <= t_kes else 0.0) if sinirliyor else math.sqrt(2) * ik / 1000 * (math.sin(math.pi * t / 10 - math.pi / 2) + math.exp(-t / 45) * (kappa - 1.02) / 0.78) for t in ts], 2)}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g3, g1, g2],
        "anlatim": [
            f"Bu noktada beklenen kısa devre akımı {fnum(ik / 1000, 1)} kA; ilk tepesi {fnum(ip / 1000, 1)} kA olurdu. Bu tepeye arızadan yaklaşık 10 ms sonra varılır.",
            ("Sigortanın içindeki gümüş ya da bakır şeridin dar boğazları bu akımda bir–iki milisaniyede erir. Erime noktalarında seri arklar yanar; kuvars kum arkı soğutur ve ark gerilimi hızla kaynak geriliminin üstüne çıkar. Devrede artık kaynağa karşı duran bir gerilim vardır: akım yükselmeyi bırakır ve sıfıra iner."
             if cihaz == "gG" else "Sınırlayıcı otomat ve kompakt şalterde kontaklar kısa devre akımının kendi kuvvetiyle itilerek açılır ve ark, söndürme hücresinde bölünür: ark gerilimi akımı sınırlar. Sigorta kadar etkili değildir ama yeniden kapatılabilir."
             if cihaz == "mcb" else "Açık tip kesici seçicilik için bilerek bekler. Bu süre boyunca akım tam değeriyle akar: bütün kuvvet ve bütün ısı donanıma biner. Donanım buna göre (kısa süreli dayanım akımı) seçilir."),
            f"Sonuç: tepe {fnum(ic / 1000, 1)} kA'de kesiliyor; geçen enerji {fnum(i2t / 1000, 0)} kA²s. Sınırlamasız bir yarım periyotta {fnum(i2t_yarim / 1000, 0)} kA²s geçerdi.",
            f"Kuvvet tepe akımın karesiyle, ısınma I²t ile orantılıdır: baralara binen kuvvet %{fnum(kuvvet_oran * 100, 0)}'e, kablonun ısınması %{fnum(i2t / i2t_yarim * 100, 1)}'e iner. {str(s).replace('.', ',')} mm² kablo bu enerjiye " + ("dayanır." if i2t <= (k * s) ** 2 else "dayanmaz."),
            "Sınırlamanın bir alt sınırı vardır: akım küçükse tel, tepe geçtikten sonra erir ve sigorta sıradan bir gecikmeli koruma gibi davranır. Bu yüzden uzun hattın sonundaki küçük kısa devrede sınırlama beklenmez.",
        ],
        "dersler": [
            "Akım sınırlayan cihaz hem tepeyi (kuvvet) hem I²t'yi (ısı) düşürür; gecikmeli kesici ikisini de düşürmez.",
            "0,1 s'den kısa açmalarda kablo, cihazın geçirdiği I²t ile karşılaştırılır: I²t ≤ k²S².",
            "Sigorta büyük akımda sınırlar, küçük akımda sınırlamaz: sınırlama eşiği anma akımının 20–30 katıdır.",
            "Arka arkaya koruma yalnız üreticinin doğruladığı cihaz çiftleri için geçerlidir.",
            "Atan sigortanın yerine tel sarmak, tesisin en hızlı korumasını iptal etmektir.",
        ],
        "tablolar": [{"baslik": f"NH gG sigortalar, {fnum(ik / 1000, 1)} kA'de", "cols": ["In", "Kesilen tepe", "Ön-ark I²t", "Toplam I²t", "Korunabilen en küçük Cu/PVC"],
                      "rows": [[f"{n} A" + (" ◀" if n == in_a and cihaz == "gG" else ""), f"{fnum(q['ic'] / 1000, 1)} kA" + ("" if q["sinirliyor"] else " (sınırlamıyor)"), f"{fnum(q['on_ark'] / 1000, 1)} kA²s", f"{fnum(q['i2t'] / 1000, 0)} kA²s", f"{fnum(math.sqrt(q['i2t']) / k, 1)} mm²"]
                               for n in IN_A for q in [sigorta(n, ik, ip)]],
                      "not": "Ön-ark I²t değerleri IEC 60269 kapı değerleridir (doğrulanacak); kesilen tepe yaklaşık bağıntıyla hesaplanmıştır. Gerçek değerler üreticinin sınırlama eğrilerinden okunur."}],
    }
