"""Pano içi ısınma: panodaki cihazların ve baraların kaybı ısıya dönüşür; kapalı mahfaza bu ısıyı yüzeyinden atar. İç sıcaklık, mahfazanın büyüklüğü, havalandırma ve fan;
sıcaklığın cihazların taşıyabildiği akıma etkisi.

Isı dengesi: P = k·A·ΔT (doğal taşınımla ısı atan kapalı sac mahfaza için k ≈ 5,5 W/m²·K; etkin yüzey duvara dayalı yüzler çıkarılarak) ve fanlı havalandırmada
V̇ ≈ 3,1·P/ΔT (m³/h) bağıntıları pano ısıl hesabında kullanılan yaklaşık bağıntılardır (IEC TR 60890 yöntemi daha ayrıntılıdır — dogrulanacak). Cihaz kayıpları ve sıcaklıkla akım
düşürme katsayıları tipiktir (tahmini). Pano doğrulaması TS EN 61439'a göre sıcaklık artışı deneyi ya da hesabıyla yapılır."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, num, opt, pts

ID = "pano_isi"
BASLIK = "Pano içi ısınma"
IKON = "🌡"
GIRIS = ("Pano kapalı bir kutudur ve içindeki her şalter, kontaktör, sürücü ve bara birer ısıtıcıdır. Isı yalnız sacın yüzeyinden çıkabilir: içerisi dışarıdan 20–30 °C sıcak olur. "
         "Cihazlar ise 40 °C'ye göre etiketlenir. Kaybı, pano boyutunu ve havalandırmayı değiştirin; iç sıcaklığı ve cihazların gerçekte taşıyabildiği akımı izleyin.")

KONTROLLER = [
    ctl("p", "Pano içindeki toplam kayıp", "sayi", 250, min=50, max=5000, adim=50, birim="W", yardim="Şalterler, kontaktörler, baralar, kablolar, sürücüler (sürücü: gücünün ≈ %3'ü)"),
    ctl("w", "Genişlik", "sayi", 800, min=300, max=2400, adim=100, birim="mm"),
    ctl("h", "Yükseklik", "sayi", 2000, min=400, max=2200, adim=100, birim="mm"),
    ctl("d", "Derinlik", "sayi", 500, min=150, max=1000, adim=50, birim="mm"),
    ctl("yer", "Yerleşim", "sec", "duvar", secenek=opt(("serbest", "Dört yanı açık"), ("duvar", "Arkası duvara dayalı"), ("sira", "Sırada, iki yanında pano, arkası duvar"))),
    ctl("ta", "Ortam sıcaklığı", "sayi", 30, min=10, max=55, adim=1, birim="°C"),
    ctl("sog", "Soğutma", "sec", "kapali", secenek=opt(("kapali", "Kapalı (yalnız yüzeyden)"), ("panjur", "Panjurlu (doğal havalandırma)"), ("fan", "Fanlı + filtreli"))),
    ctl("fan", "Fan debisi", "sayi", 150, min=20, max=1000, adim=10, birim="m³/h", goster={"sog": ["fan"]}),
]


def run(p: dict) -> dict:
    pw, w, h, d, yer, ta, sog = num(p, "p", 250), num(p, "w", 800) / 1000, num(p, "h", 2000) / 1000, num(p, "d", 500) / 1000, str(p.get("yer", "duvar")), num(p, "ta", 30), str(p.get("sog", "kapali"))
    a_ust, a_on, a_yan = w * d, w * h, d * h
    if yer == "serbest":
        a = 1.8 * h * (w + d) + 1.4 * a_ust                                  # dört yan yüz + üst
    elif yer == "duvar":
        a = 1.4 * w * (h + d) + 1.8 * d * h                                  # ön + üst + iki yan; arka duvara bakıyor
    else:
        a = 1.2 * a_on + 0.7 * a_ust + 0.2 * a_yan                            # yalnız ön ve üst; yanlar komşu panoyla paylaşılır
    k = 5.5
    dt_kapali = pw / (k * a)
    if sog == "panjur":
        dt = dt_kapali * 0.6
    elif sog == "fan":
        fan = num(p, "fan", 150)
        dt = pw / (k * a + fan / 3.1)
    else:
        dt = dt_kapali
    ti = ta + dt
    ti_ust = ta + dt * 1.3                                              # üst bölge ortalamadan sıcak
    carp = 1.0 if ti <= 40 else max(1 - 0.012 * (ti - 40), 0.4)         # şalterlerde 40 °C üstü her derece için ≈ %1–1,5
    fan_gerek = max(3.1 * pw / max(45 - ta, 1) - k * a * 3.1, 0) if ta < 45 else float("inf")
    p_max = k * a * max(45 - ta, 0)
    c = Cizim(900, 300)
    xw, xh = 60 + min(w * 110, 200), 250 - min(h * 100, 200)
    c.dikdortgen(60, xh, xw - 60, 250 - xh, "ariza" if ti > 55 else "cizgi", "#fee2e2" if ti > 55 else "#fef3c7" if ti > 45 else "#f1f5f9", kw=2.4, r=2)
    for j in range(3):
        c.dikdortgen(74, xh + 20 + j * 40, min(xw - 88, 90), 24, "cizgi", "#fff", kw=1.2)
    c.yazi(max((60 + xw) / 2, 150), xh - 10, f"iç sıcaklık {fnum(ti, 0)} °C (üstte ≈ {fnum(ti_ust, 0)} °C)", "#b91c1c" if ti > 45 else "#15803d", 13, kalin=True, anchor="middle")
    c.yazi((60 + xw) / 2, 272, f"{fnum(w * 1000, 0)} × {fnum(h * 1000, 0)} × {fnum(d * 1000, 0)} mm · {fnum(pw, 0)} W", "#475569", 10.5, anchor="middle")
    if sog == "fan":
        c.ok(xw + 40, 230, xw + 4, 230, "mavi", 2.4); c.ok(xw - 20, xh - 2, xw - 20, xh - 34, "uyari", 2.4); c.yazi(xw + 46, 234, "soğuk hava", "#1d4ed8", 10.5)
    c.yazi(400, 60, f"Etkin ısı atma yüzeyi {fnum(a, 2)} m²", "#334155", 12.5)
    c.yazi(400, 84, f"Sıcaklık artışı ΔT = {fnum(dt, 0)} K (kapalıyken {fnum(dt_kapali, 0)} K)", "#b91c1c" if dt > 25 else "#334155", 13, kalin=True)
    c.yazi(400, 108, f"Ortam {fnum(ta, 0)} °C → iç {fnum(ti, 0)} °C", "#334155", 12.5)
    c.yazi(400, 134, f"Cihazların taşıyabildiği akım: etiket değerinin %{fnum(carp * 100, 0)}'i", "#b91c1c" if carp < 0.95 else "#15803d", 13, kalin=True)
    c.yazi(400, 160, f"Bu panonun fansız atabildiği kayıp (iç ≤ 45 °C): {fnum(p_max, 0)} W", "#1a4d8f", 12.5)
    c.yazi(400, 184, "İç ≤ 45 °C için gereken fan: " + ("ortam çok sıcak: klima gerekir" if math.isinf(fan_gerek) else "gerekmez" if fan_gerek <= 0 else f"{fnum(fan_gerek, 0)} m³/h"), "#1a4d8f", 12.5)
    c.yazi(400, 214, "Isı sacın yüzeyinden doğal taşınım ve ışınımla atılır:", "#64748b", 11); c.yazi(400, 230, "metrekare ve derece başına yaklaşık 5,5 W.", "#64748b", 11)
    ozet = [
        K("İç sıcaklık", f"{fnum(ti, 0)} °C", "bad" if ti > 55 else "warn" if ti > 45 else "ok", f"üst bölgede ≈ {fnum(ti_ust, 0)} °C"),
        K("Sıcaklık artışı", f"{fnum(dt, 0)} K", "warn" if dt > 20 else "ok", f"{fnum(pw, 0)} W / {fnum(a, 2)} m²"),
        K("Akım düşürme", f"%{fnum(carp * 100, 0)}", "bad" if carp < 0.9 else "warn" if carp < 1 else "ok", "cihaz etiketi 40 °C içindir"),
        K("Fansız atılabilen kayıp", f"{fnum(p_max, 0)} W", "bad" if p_max < pw and sog == "kapali" else "info", "iç ≤ 45 °C için"),
        K("Gereken fan debisi", "klima" if math.isinf(fan_gerek) else "—" if fan_gerek <= 0 else f"{fnum(fan_gerek, 0)} m³/h", "info", "iç ≤ 45 °C için"),
    ]
    kontroller = [
        C("İç sıcaklık cihazların sınırının içinde mi?", f"{fnum(ti, 0)} °C", "≤ 45–55 °C (cihaza göre; elektronik için ≤ 45 °C)", ti <= 55, "Şalt cihazları 40 °C ortam (24 saat ortalaması 35 °C) için etiketlenir; üstünde akım düşürme uygulanır — değerler üretici kataloğundandır", "tahmini"),
        C("Akım düşürme gerekiyor mu?", f"etiketin %{fnum(carp * 100, 0)}'i", "%100 (iç ≤ 40 °C)", carp >= 0.999, "Tipik: 40 °C'nin üstünde her derece için ≈ %1–1,5; kesin değer cihazın akım düşürme çizelgesinden", "tahmini"),
        C("Isı dengesi", f"P = {fnum(pw, 0)} W · k·A = {fnum(k * a, 1)} W/K", "ΔT = P / (k·A)", None, "Kapalı sac mahfazada k ≈ 5,5 W/m²·K; ayrıntılı yöntem IEC TR 60890 (doğrulanacak)", "dogrulanacak"),
        C("Pano doğrulaması", "sıcaklık artışı: deney, karşılaştırma ya da hesap", "TS EN 61439 tasarım doğrulaması", None, "Pano üreticisi sıcaklık artışı sınırlarının aşılmadığını doğrular; sahada eklenen cihazlar bu doğrulamayı geçersiz kılabilir (madde asıl metinle doğrulanacak)", "dogrulanacak"),
    ]
    girdiler = [
        G("Toplam kayıp", f"{fnum(pw, 0)} W", "Cihaz katalogları (kutup başına W), bara ve kablo kayıpları, sürücü verimi", "Isınmayı belirleyen tek kaynak", "ΣP"),
        G("Mahfaza", f"{fnum(w * 1000, 0)} × {fnum(h * 1000, 0)} × {fnum(d * 1000, 0)} mm · {yer}", "Pano çizimi, yerleşim", "Isı atan yüzeyi belirler: duvara ve komşu panoya bakan yüzler az çalışır", f"A(etkin) = {fnum(a, 2)} m²"),
        G("Ortam", f"{fnum(ta, 0)} °C · {sog}", "Pano odasının yaz sıcaklığı; güneş alan dış pano", "İç sıcaklık ortamın üstüne eklenir", "Ti = Ta + ΔT"),
    ]
    adimlar = [
        A("Etkin yüzey", "A = Σ (yüz alanı × yüzey katsayısı)", f"{yer}: üst 1,4 · açık yan 0,9 · duvara bakan 0,5–0,7 çarpanlarıyla", f"{fnum(a, 2)} m²", "IEC TR 60890 yaklaşımı — katsayılar doğrulanacak", "dogrulanacak", ["Mahfaza"]),
        A("Sıcaklık artışı (kapalı)", "ΔT = P / (k · A)", f"{fnum(pw, 0)} / (5,5 × {fnum(a, 2)})", f"{fnum(dt_kapali, 0)} K", "doğal taşınım + ışınım", "dogrulanacak", ["Toplam kayıp"]),
        A("Havalandırmanın etkisi", "fan: ΔT = P / (k·A + V̇/3,1) · panjur: ≈ × 0,6", f"{sog}" + (f" · {fnum(num(p, 'fan', 150), 0)} m³/h" if sog == "fan" else ""), f"{fnum(dt, 0)} K", "hava debisi ısıyı taşır: 1 m³/h hava, derece başına ≈ 0,32 W", "hesap"),
        A("İç sıcaklık", "Ti = Ta + ΔT", f"{fnum(ta, 0)} + {fnum(dt, 0)}", f"{fnum(ti, 0)} °C", "ortalama; üst bölge daha sıcak", "hesap", ["Ortam"]),
        A("Akım düşürme", "≈ %1,2 / K (40 °C üstü)", f"{fnum(max(ti - 40, 0), 0)} K fazla", f"%{fnum(carp * 100, 0)}", "tipik; cihaza göre değişir", "tahmini"),
    ]
    ayarlar = [
        S("Termostatlı fan + filtre", f"≥ {fnum(fan_gerek, 0)} m³/h" if 0 < fan_gerek < 1e9 else "—", "alttan giriş, üstten çıkış", "Hava yolu cihazların üstünden geçmeli; filtre tıkanınca debi düşer", "saha pratiği", "ikincil"),
        S("Şalter ayarı", f"Ir ≤ %{fnum(carp * 100, 0)} × In", "—", "Sıcak panoda termik açtırıcı erken açar, elektronik açtırıcı açmaz ama cihaz ısınır", "üretici akım düşürme çizelgesi", "ikincil"),
        S("Yerleşim", "çok ısınan cihazlar (sürücü, trafo, reaktör) üstte ya da ayrı gözde", "—", "Sıcak hava yükselir: alttaki ısı kaynağı üsttekileri ısıtır", "saha pratiği", "ikincil"),
    ]
    test = [T("İç sıcaklık", "Pano kapalıyken üst bölgede termometre / veri kaydedici, tam yükte en az 2 saat", f"≈ {fnum(ti_ust, 0)} °C", "kapı açıkken yapılan ölçü yanıltır"),
            T("Termal kamera", "Kapı açılır açılmaz bağlantılar ve cihazlar", "bağlantılar gövdeden sıcak olmamalı", "sıcak nokta gevşek bağlantıdır; genel sıcaklık ise havalandırma sorunudur"),
            T("Filtre ve fan", "Filtre temizliği, fanın dönüşü, termostat ayarı", "temiz ve çalışır", "tozlu ortamda en sık arıza nedeni")]
    ps = [50 * k for k in range(1, 61)]
    g1 = {"baslik": "Kayba göre iç sıcaklık", "x_ad": "Pano içindeki kayıp (W)", "y_ad": "İç sıcaklık (°C)",
          "seriler": [{"ad": "kapalı", "renk": "#dc2626", "pts": pts(ps, [ta + x / (k * a) for x in ps], 1)}, {"ad": "panjurlu", "renk": "#b45309", "pts": pts(ps, [ta + 0.6 * x / (k * a) for x in ps], 1)},
                      {"ad": "fanlı 150 m³/h", "renk": "#1a4d8f", "pts": pts(ps, [ta + x / (k * a + 150 / 3.1) for x in ps], 1)}],
          "yatay": [{"y": 45, "etiket": "45 °C", "renk": "#d97706"}, {"y": 55, "etiket": "55 °C", "renk": "#dc2626"}], "isaretler": [{"x": pw, "etiket": "kayıp"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1],
        "anlatim": [
            f"Panonun içinde {fnum(pw, 0)} W ısı üretiliyor: her şalterin kontak direnci, her kontaktörün bobini, her baranın direnci, her sürücünün kaybı. Bu ısı kapalı kutudan yalnız sacın yüzeyi üzerinden çıkabilir.",
            f"Sac, iç hava ile dış hava arasındaki her derece fark için metrekare başına yaklaşık 5,5 W atar. Etkin yüzey {fnum(a, 2)} m²: {fnum(pw, 0)} W'ı atmak için içerinin dışarıdan {fnum(dt_kapali, 0)} K sıcak olması gerekir.",
            "Duvara dayalı arka yüz ve komşu panoya bakan yan yüzler az çalışır: aynı pano sıranın ortasında, tek başına durduğundan daha sıcak olur. Üst bölge ortalamadan belirgin sıcaktır.",
            f"Ortam {fnum(ta, 0)} °C iken iç sıcaklık {fnum(ti, 0)} °C. Cihazların etiketindeki akım 40 °C içindir: bu sıcaklıkta etiket değerinin yaklaşık %{fnum(carp * 100, 0)}'i taşınabilir. 100 A'lik şalter sıcak panoda 100 A'lik değildir.",
            ("Fan, ısıyı havayla dışarı taşır: saatte bir metreküp hava, her derece fark için yaklaşık 0,32 W götürür. Filtre tıkandıkça debi düşer ve pano, kimse fark etmeden kapalı pano gibi ısınmaya başlar."
             if sog == "fan" else "Panjur, sıcak havanın üstten çıkıp soğuk havanın alttan girmesine izin verir: artış kabaca %40 azalır; karşılığında toz ve nem içeri girer."
             if sog == "panjur" else "Kapalı pano tozdan ve nemden korur ama ısısını yalnız yüzeyinden atar: kayıp büyüdükçe ya pano büyütülür ya da havalandırılır."),
        ],
        "dersler": [
            "ΔT ≈ P / (5,5 · A): kayıp iki katına çıkarsa artış iki katına çıkar.",
            "Cihaz etiketi 40 °C içindir; iç sıcaklık 50 °C ise şalter %10–15 daha az taşır.",
            "Duvara dayalı ve sırada duran pano daha az yüzeyle soğur.",
            "Fan debisi: V̇ ≈ 3,1 · P / ΔT (m³/h). Filtre bakımı fanın kendisi kadar önemlidir.",
            "Sonradan eklenen sürücü ya da trafo, panonun ısıl doğrulamasını bozar.",
        ],
        "tablolar": [{"baslik": "Tipik kayıplar", "cols": ["Cihaz", "Kayıp"],
                      "rows": [["Otomat (kutup başına, anma akımında)", "1–4 W"], ["Kompakt şalter 250 A (üç kutup)", "40–60 W"], ["Kompakt şalter 630 A", "100–150 W"], ["Açık tip kesici 1600 A", "250–400 W"],
                               ["Kontaktör 100 A (üç kutup + bobin)", "20–30 W"], ["Frekans çevirici", "anma gücünün ≈ %3'ü"], ["Kumanda trafosu / güç kaynağı", "gücünün %10–15'i"], ["Bara ve kablolar", "akıma ve kesite göre; büyük panoda toplamın üçte biri"]],
                      "not": "Değerler katalog mertebesidir; hesapta cihazın kendi veri sayfası kullanılır."}],
    }
