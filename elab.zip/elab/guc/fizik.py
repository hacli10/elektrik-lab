"""Arıza fiziği — ortak sabitler ve bağıntılar: malzeme özellikleri, havanın delinmesi (Paschen ve düzgün alan bağıntısı), iletkenin adyabatik ısınması ve erimesi,
paralel iletkenler arası kuvvet, ark gerilimi ve enerjisi, kapalı hacimde ark basıncı, ark parlaması olay enerjisi.

Malzeme sabitleri fizik çizelgelerindeki bilinen değerlerdir (hesap). Yalıtkanların delinme dayanımı, ark gerilimi eğimi ve arkın gaza aktardığı ısı payı
tipik değerlerdir (tahmini). Standart bağıntıları (IEC 60865 kuvvet, IEEE 1584-2002 olay enerjisi, IEC 60815 kaçak yolu) bellekten yazılmıştır (dogrulanacak)."""
from __future__ import annotations

import math

MU0 = 4e-7 * math.pi

# iletkenler: özdirenç (Ω·mm²/m, 20 °C), sıcaklık katsayısı tabanı β (°C), yoğunluk (kg/m³), özgül ısı (J/kg·K), erime (°C), erime ısısı (kJ/kg), kaynama (°C), buharlaşma ısısı (kJ/kg)
METAL = {
    "cu": {"ad": "Bakır", "ro": 0.017241, "beta": 234.5, "yog": 8960, "c": 385, "erime": 1085, "le": 205, "kaynama": 2562, "lb": 4730},
    "al": {"ad": "Alüminyum", "ro": 0.028264, "beta": 228.0, "yog": 2700, "c": 897, "erime": 660, "le": 397, "kaynama": 2470, "lb": 10500},
    "fe": {"ad": "Çelik", "ro": 0.138, "beta": 202.0, "yog": 7850, "c": 480, "erime": 1500, "le": 250, "kaynama": 2860, "lb": 6100},
}
# yalıtkanlar: bağıl dielektrik sabiti, kısa süreli delinme dayanımı (kV/mm, ince örnek), işletme alan şiddeti (kV/mm, OG tasarımı), en yüksek sürekli sıcaklık (°C), iz dayanımı (CTI, V), ömür üssü n
YALITKAN = {
    "hava": {"ad": "Hava (1 bar)", "er": 1.0, "ed": 3.0, "ei": 0.5, "tmax": None, "cti": None, "n": None},
    "sf6": {"ad": "SF6 (1 bar)", "er": 1.0, "ed": 8.9, "ei": 1.5, "tmax": None, "cti": None, "n": None},
    "yag": {"ad": "Trafo yağı", "er": 2.2, "ed": 12.0, "ei": 2.5, "tmax": 105, "cti": None, "n": None},
    "kagit": {"ad": "Yağlı kâğıt", "er": 3.5, "ed": 50.0, "ei": 4.0, "tmax": 105, "cti": None, "n": 10},
    "xlpe": {"ad": "XLPE", "er": 2.3, "ed": 30.0, "ei": 3.0, "tmax": 90, "cti": 600, "n": 10},
    "pvc": {"ad": "PVC", "er": 5.0, "ed": 15.0, "ei": 1.5, "tmax": 70, "cti": 175, "n": 9},
    "epoksi": {"ad": "Epoksi reçine (dolgulu, döküm)", "er": 4.0, "ed": 20.0, "ei": 3.0, "tmax": 155, "cti": 400, "n": 11},
    "porselen": {"ad": "Porselen", "er": 6.0, "ed": 15.0, "ei": 1.5, "tmax": 1000, "cti": 600, "n": None},
    "silikon": {"ad": "Silikon kauçuk", "er": 3.0, "ed": 20.0, "ei": 2.0, "tmax": 180, "cti": 600, "n": None},
}


# ---------------- havanın delinmesi ----------------
def hava_yogunlugu(rakim_m: float = 0.0, t_c: float = 20.0) -> float:
    """Bağıl hava yoğunluğu δ (deniz düzeyi, 20 °C'de 1)."""
    p = 101.325 * (1 - 2.25577e-5 * rakim_m) ** 5.25588
    return p / 101.325 * 293.0 / (273.0 + t_c)


def paschen(d_mm: float, delta: float = 1.0) -> float:
    """Düzgün alanda hava aralığının delinme gerilimi (kV tepe). Küçük aralıklarda Paschen bağıntısı, ≥ 1 mm'de deneysel bağıntı
    Ud = 24,22·δ·d + 6,08·√(δ·d) (d cm). İki bağıntıdan büyük olanı (geçiş sürekli olsun diye)."""
    d_cm = max(d_mm, 1e-4) / 10
    pd = 760.0 * delta * d_cm                                   # Torr·cm
    a, b, gam = 15.0, 365.0, 0.01
    payda = math.log(a * pd) - math.log(math.log(1 + 1 / gam))
    up = b * pd / payda / 1000 if payda > 0.05 else 1e9          # kV; Paschen minimumunun solunda delinme zorlaşır
    ue = 24.22 * delta * d_cm + 6.08 * math.sqrt(delta * d_cm)
    if d_mm >= 1.0:
        return ue
    return max(min(up * 0.8632, 1e3), 0.305) if up < 1e8 else 1e3          # 0,8632: 1 mm'de iki bağıntı aynı değeri verir (4,34 kV)


def hava_atlama(d_mm: float, bicim: str = "cubuk", delta: float = 1.0, nem: float = 1.0) -> float:
    """Hava aralığının şebeke frekansında atlama gerilimi (kV etkin). bicim: duzgun (levha–levha), kure (küre–küre, yarı düzgün), cubuk (çubuk–levha / sivri uç: düzgün değil).
    Düzgün olmayan alanda uzun aralıkta atlama ≈ 5 kV(tepe)/cm; yüzey kirli / ıslaksa nem çarpanı < 1."""
    d_cm = d_mm / 10
    if bicim == "duzgun":
        tepe = paschen(d_mm, delta)
    elif bicim == "kure":
        tepe = 0.85 * paschen(d_mm, delta)
    else:
        tepe = min(paschen(d_mm, delta), delta * (14.0 + 3.16 * d_cm * 1.0 + 3.0 * math.sqrt(d_cm)))          # çubuk–levha: kısa aralıkta düzgün alana, uzun aralıkta ≈ 3–5 kV/cm'ye yaklaşır
    return tepe / math.sqrt(2) * nem


# ---------------- iletkenin ısınması ----------------
def isin(metal: str, j: float, t: float, th0: float = 20.0) -> dict:
    """Adyabatik ısınma: akım yoğunluğu j (A/mm²) sabit, süre t (s). Direncin sıcaklıkla artışı hesaba katılır; erime gizli ısısı eklenir.
    Dönen: th (son sıcaklık, °C), eridi (0…1 erime oranı), t_erime (erime başlangıcına kadar süre, s), t_tam (tam erime, s)."""
    m = METAL[metal]
    qc = m["yog"] * m["c"] * 1e-9                                # J/(K·mm³)
    k2 = qc * (m["beta"] + 20) / m["ro"] * 1e3                   # (A/mm²)²·s katsayısı: j²·t = k2·ln((β+θ1)/(β+θ0)); ro Ω·mm²/m → Ω·mm: /1000
    j2t = j * j * t
    son = (m["beta"] + th0) * math.exp(j2t / k2) - m["beta"] if j2t / k2 < 50 else 1e9
    t_erime = k2 * math.log((m["beta"] + m["erime"]) / (m["beta"] + th0)) / (j * j) if j > 0 else math.inf
    ro_e = m["ro"] * (m["beta"] + m["erime"]) / (m["beta"] + 20) * 1e-3          # erime sıcaklığında özdirenç (Ω·mm)
    t_gizli = m["yog"] * m["le"] * 1e3 * 1e-9 / (ro_e * j * j) if j > 0 else math.inf
    if son < m["erime"]:
        return {"th": son, "eridi": 0.0, "t_erime": t_erime, "t_tam": t_erime + t_gizli, "k": math.sqrt(k2)}
    oran = min((t - t_erime) / t_gizli, 1.0) if t_gizli > 0 else 1.0
    return {"th": m["erime"], "eridi": max(oran, 0.0), "t_erime": t_erime, "t_tam": t_erime + t_gizli, "k": math.sqrt(k2)}


def k_katsayi(metal: str, th0: float, th1: float) -> float:
    """Adyabatik k katsayısı (A·√s/mm²): S = I·√t / k."""
    m = METAL[metal]
    qc = m["yog"] * m["c"] * 1e-9
    return math.sqrt(qc * (m["beta"] + 20) / m["ro"] * 1e3 * math.log((m["beta"] + th1) / (m["beta"] + th0)))


# ---------------- kuvvet ----------------
def kuvvet(i1_ka: float, i2_ka: float, a_m: float) -> float:
    """Paralel iki iletken arasındaki kuvvet (N/m): F′ = μ0·i1·i2 / (2π·a)."""
    return MU0 * (i1_ka * 1e3) * (i2_ka * 1e3) / (2 * math.pi * max(a_m, 1e-4))


def kuvvet_3f(ip_ka: float, a_m: float) -> float:
    """Üç fazlı kısa devrede orta iletkene etkiyen en büyük kuvvet (N/m): F′ = (√3/2)·μ0·ip² / (2π·a)."""
    return math.sqrt(3) / 2 * kuvvet(ip_ka, ip_ka, a_m)


# ---------------- ark ----------------
def ark_gerilimi(l_cm: float, i_ka: float = 10.0) -> float:
    """Serbest yanan arkın gerilimi (V): elektrot düşümü ≈ 30 V + sütun ≈ 12 V/cm (yüksek akımda, havada; tipik)."""
    return 30.0 + 12.0 * max(l_cm, 0.0)


def metal_enerji(metal: str) -> float:
    """1 kg metali 20 °C'den buharlaştırmak için gereken enerji (MJ/kg)."""
    m = METAL[metal]
    return (m["c"] * (m["erime"] - 20) + m["le"] * 1e3 + m["c"] * (m["kaynama"] - m["erime"]) + m["lb"] * 1e3) / 1e6


def basinc(p_ark_mw: float, hacim_m3: float, sure_ms: float, kapak_bar: float, kapak_m2: float, kp: float = 0.5, dt_ms: float = 0.1) -> dict:
    """Kapalı bölmede ark basıncı (tek hacimli kütle ve enerji dengesi; ideal gaz). Arkın gücü p_ark (MW) sabit; kp: gücün gazı ısıtan payı.
    Durum: gaz kütlesi m ve sıcaklığı T. dU/dt = kp·P − ṁ·cp·T ; dm/dt = −ṁ ; p = m·R·T / V. Kapak, eşik basıncında açılır; çıkış debisi
    sıkıştırılabilir delik akışıdır (kritik basınç oranının üstünde boğulmuş akış), akış katsayısı 0,7.
    Dönen: t (ms), p (bar, atmosfere göre), sicaklik (K), tepe, t_tepe, t_kapak."""
    kap, rg, cv, cp = 1.4, 287.0, 718.0, 1005.0
    p0, t0 = 101325.0, 293.0
    m = p0 * hacim_m3 / (rg * t0); tg = t0
    acik = False; t_kapak = None
    ts, ps, tgs = [], [], []
    n = int(sure_ms / dt_ms); dt = dt_ms / 1000
    for k in range(n + 1):
        t = k * dt_ms
        p = m * rg * tg / hacim_m3
        ts.append(t); ps.append((p - p0) / 1e5); tgs.append(tg)
        if not acik and (p - p0) / 1e5 >= kapak_bar:
            acik = True; t_kapak = t
        md = 0.0
        if acik and p > p0 * 1.0001:
            oran = p0 / p
            if oran < 0.5283:                                    # boğulmuş akış
                md = 0.7 * kapak_m2 * p * math.sqrt(kap / (rg * tg)) * (2 / (kap + 1)) ** ((kap + 1) / (2 * (kap - 1)))
            else:
                md = 0.7 * kapak_m2 * p * math.sqrt(2 * kap / ((kap - 1) * rg * tg) * (oran ** (2 / kap) - oran ** ((kap + 1) / kap)))
            md = min(md, 0.5 * m / dt, max(m - p0 * hacim_m3 / (rg * tg), 0.0) / dt)          # basınç dış basıncın altına inemez (dengeye yakın salınımı önler)
        u = m * cv * tg + (kp * p_ark_mw * 1e6 - md * cp * tg) * dt
        m = max(m - md * dt, 1e-6)
        tg = min(max(u / (m * cv), t0), 20000.0)
    tepe = max(ps)
    return {"t": ts, "p": ps, "sicaklik": tgs, "tepe": tepe, "t_tepe": ts[ps.index(tepe)], "t_kapak": t_kapak}


def ieee1584(u_kv: float, ibf_ka: float, t_s: float, d_mm: float, g_mm: float, kutu: bool, toprakli: bool, x: float) -> dict:
    """IEEE 1584-2002 deneysel bağıntısı (0,208–15 kV). 15 kV'un üstünde aynı bağıntı uzatılarak kullanılır (standardın önerdiği Lee bağıntısı
    E = 2,142·10⁶·U·Ibf·t/D² kapalı hücrede gerçekçi olmayacak kadar büyük sonuç verir). Dönen: ia (ark akımı, kA), e (olay enerjisi, cal/cm²), lee (karşılaştırma)."""
    lg = math.log10
    if u_kv < 1.0:
        k = -0.097 if kutu else -0.153
        ia = 10 ** (k + 0.662 * lg(ibf_ka) + 0.0966 * u_kv + 0.000526 * g_mm + 0.5588 * u_kv * lg(ibf_ka) - 0.00304 * g_mm * lg(ibf_ka))
    else:
        ia = 10 ** (0.00402 + 0.983 * lg(ibf_ka))
    k1 = -0.555 if kutu else -0.792
    k2 = -0.113 if toprakli else 0.0
    en = 10 ** (k1 + k2 + 1.081 * lg(ia) + 0.0011 * g_mm)
    cf = 1.5 if u_kv <= 1.0 else 1.0
    e = 4.184 * cf * en * (t_s / 0.2) * (610.0 ** x / d_mm ** x)     # J/cm²
    lee = 2.142e6 * u_kv * ibf_ka * t_s / (d_mm * d_mm) / 4.184
    return {"ia": ia, "e": e / 4.184, "lee": lee, "yontem": "IEEE 1584-2002" + (" (15 kV'un üstüne uzatılarak)" if u_kv > 15 else "")}
