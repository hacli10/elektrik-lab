"""Trafoların paralel çalışması: yükün paylaşımı (güç ve uk'ya göre), çevirme oranı farkından doğan dolaşım akımı, bağlantı grubu uyumsuzluğu.

Model: iki trafo, ortak OG ve AG barası arasında iki seri empedans; iç gerilimleri arasındaki fark (oran farkı, saat grubu farkı) dolaşım akımını sürer:
Ic = ΔE / (Z1 + Z2); yük akımı empedanslarla ters orantılı bölünür. Empedans açıları trafoların yük kayıplarından alınır (TEDAŞ-MLZ/99-032.E değerleri).
Paralel çalışma koşulları (aynı saat grubu, oran farkı ≤ %0,5, uk farkı ≤ %10, güç oranı ≤ 3:1) uygulama kurallarıdır (ikincil); oran ve uk toleransları
şartnamenin kabul toleranslarıdır (böl. 2.2.17)."""
from __future__ import annotations

import cmath
import math

from .ortak import A, C, G, K, S, T, TEDAS_H, TEMEL, Cizim, ctl, fa, fnum, guc_sec, num, opt, pts, trafo

ID = "trafo_paralel"
BASLIK = "Paralel çalışma"
IKON = "⏸"
GIRIS = ("İki trafo aynı barayı beslerken yükü güçleriyle orantılı paylaşmaz: paylaşımı kısa devre empedansları belirler. Kademeleri farklıysa yük olmasa bile aralarında akım dolaşır; "
         "bağlantı grupları farklıysa bu akım kısa devre mertebesindedir. Güçleri, uk'ları ve kademe farkını değiştirip izleyin.")

KONTROLLER = [
    ctl("sn1", "1. trafo — güç", "sec", 1000, secenek=guc_sec()),
    ctl("uk1", "1. trafo — uk", "sayi", 6.0, min=3.5, max=8, adim=0.1, birim="%"),
    ctl("sn2", "2. trafo — güç", "sec", 630, secenek=guc_sec()),
    ctl("uk2", "2. trafo — uk", "sayi", 4.5, min=3.5, max=8, adim=0.1, birim="%"),
    ctl("oran", "Çevirme oranı farkı (2. trafonun boştaki gerilimi daha düşük)", "sayi", 0.0, min=0, max=5, adim=0.1, birim="%", yardim="Bir kademe farkı %2,5'tir; kabul toleransı ±%0,5"),
    ctl("saat", "Bağlantı grubu farkı", "sec", 0, secenek=opt((0, "Aynı grup (ör. ikisi de Dyn11)"), (30, "30° (ör. Dyn11 ile Yyn0)"), (60, "60° (ör. Dyn11 ile Dyn1)"), (180, "180° (ör. Dyn11 ile Dyn5)"))),
    ctl("yuk", "Toplam yük", "sayi", 80, min=0, max=130, adim=5, birim="%", yardim="İki trafonun toplam anma gücünün yüzdesi"),
    ctl("cos", "Güç katsayısı", "sayi", 0.9, min=0.5, max=1.0, adim=0.01),
]


def emp(sn: float, uk: float) -> complex:
    """Trafonun kendi tabanında kısa devre empedansı (pu); açısı şartnamedeki yük kaybından."""
    ur = trafo("hermetik", sn, 33.0)["ur"]
    ur = min(ur, uk * 0.95)
    return complex(ur, math.sqrt(uk * uk - ur * ur)) / 100


def paylas(sn1: float, z1: complex, sn2: float, z2: complex, s_top: float, cosf: float, oran: float, saat: float) -> dict:
    """Ortak taban Sn1. Dönen: k1, k2 (kendi anma akımlarına göre yüklenme), ic (dolaşım akımı, 1. trafo tabanında pu)."""
    z2b = z2 * (sn1 / sn2)
    il = s_top / sn1 * cmath.rect(1, -math.acos(cosf))
    de = 1 - (1 - oran) * cmath.rect(1, -math.radians(saat))
    ic = de / (z1 + z2b)
    i1 = il * z2b / (z1 + z2b) + ic
    i2 = il * z1 / (z1 + z2b) - ic
    return {"k1": abs(i1), "k2": abs(i2) * sn1 / sn2, "ic": abs(ic), "i1": i1, "i2": i2}


def run(p: dict) -> dict:
    sn1, sn2, uk1, uk2 = num(p, "sn1", 1000), num(p, "sn2", 630), num(p, "uk1", 6.0), num(p, "uk2", 4.5)
    oran, saat, cosf = num(p, "oran", 0) / 100, num(p, "saat", 0), num(p, "cos", 0.9)
    s_top = (sn1 + sn2) * num(p, "yuk", 80) / 100
    z1, z2 = emp(sn1, uk1), emp(sn2, uk2)
    r = paylas(sn1, z1, sn2, z2, s_top, cosf, oran, saat)
    r0 = paylas(sn1, z1, sn2, z2, 0.0, cosf, oran, saat)
    i1n, i2n = sn1 / (math.sqrt(3) * 0.4), sn2 / (math.sqrt(3) * 0.4)
    ic_a = r["ic"] * i1n
    s_max = next((x for x in range(int(sn1 + sn2) * 2, 0, -5) if max(paylas(sn1, z1, sn2, z2, x, cosf, oran, saat)["k1"], paylas(sn1, z1, sn2, z2, x, cosf, oran, saat)["k2"]) <= 1.0), 0)
    uk_min = min(uk1, uk2); s_ideal = sn1 * uk_min / uk1 + sn2 * uk_min / uk2
    fark_uk = abs(uk1 - uk2) / ((uk1 + uk2) / 2) * 100
    g_oran = max(sn1, sn2) / min(sn1, sn2)

    c = Cizim(900, 320)
    c.hat("M120,50 H780", "cizgi", w=5); c.yazi(450, 40, "OG bara", "#475569", 10.5, anchor="middle")
    c.hat("M120,250 H780", "cizgi", w=5); c.yazi(450, 272, "AG bara", "#475569", 10.5, anchor="middle")
    for j, (x, sn, uk, k_, ia) in enumerate(((270, sn1, uk1, r["k1"], r["k1"] * i1n), (630, sn2, uk2, r["k2"], r["k2"] * i2n))):
        c.hat(f"M{x},50 V110", "L1", hot=k_ > 0.01, w=3); c.daire(x, 132, 22, "cizgi"); c.daire(x, 164, 22, "cizgi"); c.hat(f"M{x},186 V250", "L1", hot=k_ > 0.01, w=3, hot_renk="ariza" if k_ > 1 else None)
        c.yazi(x + 34, 136, f"{j + 1}. trafo — {fnum(sn, 0)} kVA · uk %{fnum(uk, 1)}", "#334155", 11.5, kalin=True)
        c.yazi(x + 34, 156, f"yüklenme %{fnum(k_ * 100, 0)} · {fnum(ia, 0)} A", "#b91c1c" if k_ > 1 else "#15803d", 12.5, kalin=True)
        c.yazi(x + 34, 176, f"taşıdığı güç ≈ {fnum(k_ * sn, 0)} kVA", "#64748b", 10.5)
    if r["ic"] > 0.005:
        c.ok(300, 100, 600, 100, "mor", 2); c.ok(600, 210, 300, 210, "mor", 2)
        c.yazi(450, 92, f"dolaşım akımı {fnum(ic_a, 0)} A", "#7c3aed", 12, kalin=True, anchor="middle")
    c.kutu(20, 285, 130, 30, f"Yük {fnum(s_top, 0)} kVA", "")
    c.yazi(170, 304, f"İki trafo birlikte aşırı yüklenmeden en çok {fnum(s_max, 0)} kVA taşır (toplam anma {fnum(sn1 + sn2, 0)} kVA).", "#1a4d8f", 12, kalin=True)

    ozet = [
        K("1. trafonun yüklenmesi", f"%{fnum(r['k1'] * 100, 0)}", "bad" if r["k1"] > 1 else "ok", f"{fnum(r['k1'] * sn1, 0)} kVA"),
        K("2. trafonun yüklenmesi", f"%{fnum(r['k2'] * 100, 0)}", "bad" if r["k2"] > 1 else "ok", f"{fnum(r['k2'] * sn2, 0)} kVA"),
        K("Dolaşım akımı", f"{fnum(ic_a, 0)} A", "bad" if r["ic"] * sn1 / min(sn1, sn2) > 0.1 else "ok", f"küçük trafonun anma akımının %{fnum(r['ic'] * sn1 / min(sn1, sn2) * 100, 0)}'i — yük olmasa da akar"),
        K("Birlikte taşınabilen güç", f"{fnum(s_max, 0)} kVA", "warn" if s_max < 0.95 * (sn1 + sn2) else "ok", f"toplam anma gücünün %{fnum(s_max / (sn1 + sn2) * 100, 0)}'i"),
        K("uk farkı", f"%{fnum(fark_uk, 0)}", "warn" if fark_uk > 10 else "ok", "ortalamaya göre"),
    ]
    kontroller = [
        C("Bağlantı grupları (saat sayıları) aynı mı?", "aynı" if saat == 0 else f"{fnum(saat, 0)}° fark", "aynı", saat == 0, "Saat farkı iç gerilimler arasında kalıcı bir fazör farkı bırakır: 30°'de 0,52 pu, 180°'de 2 pu. Paralel bağlanamaz", "ikincil"),
        C("Çevirme oranları eşit mi?", f"fark %{fnum(oran * 100, 1)}", "≤ %0,5", oran <= 0.005 + 1e-9, "Oranın kabul toleransı ±%0,5'tir — " + TEDAS_H + " böl. 2.2.17; bir kademe farkı (%2,5) bunun beş katıdır", "resmi"),
        C("Kısa devre empedansları yakın mı?", f"%{fnum(uk1, 1)} / %{fnum(uk2, 1)} — fark %{fnum(fark_uk, 0)}", "≤ %10", fark_uk <= 10.0 + 1e-9, "uk'nın kabul toleransı ±%10'dur — " + TEDAS_H + " böl. 2.2.17; daha büyük farkta küçük uk'lı trafo aşırı yüklenir", "resmi"),
        C("Güç oranı", f"{fnum(g_oran, 1)} : 1", "≤ 3 : 1", g_oran <= 3.0 + 1e-9, "Çok farklı güçlerde empedans açıları da farklıdır; paylaşım daha da bozulur", "ikincil"),
        C("Hiçbir trafo aşırı yüklenmiyor mu?", f"%{fnum(r['k1'] * 100, 0)} / %{fnum(r['k2'] * 100, 0)}", "≤ %100", max(r["k1"], r["k2"]) <= 1.0 + 1e-9, "Toplam yük toplam anma gücünün altında olsa da paylaşım eşit değilse biri aşırı yüklenir", "hesap"),
    ]
    girdiler = [
        G("İki trafonun etiketi", f"{fnum(sn1, 0)} kVA uk %{fnum(uk1, 1)} · {fnum(sn2, 0)} kVA uk %{fnum(uk2, 1)}", "Etiketler; deney raporlarındaki ölçülmüş uk", "Paylaşımı anma değeri değil ölçülmüş uk belirler", "S1 : S2 = (Sn1/uk1) : (Sn2/uk2)"),
        G("Kademe konumları", f"oran farkı %{fnum(oran * 100, 1)}", "Kademe göstergeleri; boşta AG gerilimlerinin ölçüsü", "Farklı kademe = farklı boşta gerilim = dolaşım akımı", "Ic = ΔU / (Z1 + Z2)"),
        G("Bağlantı grupları", "aynı" if saat == 0 else f"{fnum(saat, 0)}° fark", "Etiketler; faz sırası ve fazlama ölçüsü", "Saat sayısı farklıysa AG gerilimleri arasında kalıcı açı vardır", "ΔU = 2 · sin(θ/2)"),
    ]
    adimlar = [
        A("Yükün paylaşımı (oran ve grup aynıyken)", "S1 / S2 = (Sn1 / uk1) / (Sn2 / uk2)", f"({fnum(sn1, 0)} / {fnum(uk1, 1)}) / ({fnum(sn2, 0)} / {fnum(uk2, 1)})", f"{fnum((sn1 / uk1) / (sn2 / uk2), 2)} : 1", "paralel empedanslarda akım empedansla ters orantılı bölünür", "hesap", ["İki trafonun etiketi"]),
        A("Aşırı yüklenmeden taşınabilen güç", "S = Σ Sn·(uk(min) / uk)", f"{fnum(sn1, 0)} × {fnum(uk_min / uk1, 2)} + {fnum(sn2, 0)} × {fnum(uk_min / uk2, 2)}", f"{fnum(s_ideal, 0)} kVA", "küçük uk'lı trafo önce dolar", "hesap"),
        A("İç gerilim farkı", "ΔE = 1 − (1 − oran farkı) ∠ −θ", f"oran %{fnum(oran * 100, 1)}, θ = {fnum(saat, 0)}°", f"{fnum(abs(1 - (1 - oran) * cmath.rect(1, -math.radians(saat))) * 100, 1)} %", TEMEL, "hesap", ["Kademe konumları", "Bağlantı grupları"]),
        A("Dolaşım akımı", "Ic = ΔE / (Z1 + Z2)", f"{fnum(abs(1 - (1 - oran) * cmath.rect(1, -math.radians(saat))) * 100, 1)} % / ({fnum(abs(z1) * 100, 1)} % + {fnum(abs(z2 * sn1 / sn2) * 100, 1)} %)", f"{fnum(ic_a, 0)} A (yüksüzken de)", "iki trafonun empedansı seri bir çevrim oluşturur", "hesap"),
        A("Yük altında yüklenmeler", "I1 = IL·Z2/(Z1+Z2) + Ic · I2 = IL·Z1/(Z1+Z2) − Ic", f"yük {fnum(s_top, 0)} kVA", f"%{fnum(r['k1'] * 100, 0)} / %{fnum(r['k2'] * 100, 0)}", "yük akımı ile dolaşım akımının fazör toplamı", "hesap"),
    ]
    ayarlar = [
        S("Kuplaj / AG giriş kesicileri kilitlemesi", "paralele girmeden önce: grup, oran, fazlama", "—", "Yanlış fazlanmış iki kaynağın paralele alınması kısa devredir", "saha pratiği", "ikincil"),
        S("Her trafonun AG giriş kesicisi › aşırı yük (L)", "kendi trafosunun In'i", "—", "Paylaşım bozuksa aşırı yüklenen trafoyu kendi kesicisi korur", "saha pratiği", "ikincil"),
        S("Ters güç / yönlü koruma (32, 67)", "dolaşım akımına duyarlı", "—", "Bir trafo ötekini AG tarafından besliyorsa akım yönü terstir", "Röle laboratuvarı › Yönlü güç", "ikincil"),
    ]
    test = [
        T("Fazlama", "Paralele girecek kesicinin iki yanında aynı fazlar arasında gerilim", "0 V (aynı faz) · 400 V (farklı faz)", "aynı fazlar arasında gerilim varsa grup ya da bağlantı yanlış"),
        T("Boşta AG gerilimleri", "Her trafo ayrı ayrı enerjiliyken", "fark ≤ %0,5 (2 V)", f"bu ayarda fark {fnum(oran * 400, 1)} V"),
        T("Yük paylaşımı", "Paralelde iki trafonun AG akımları", f"{fnum(r['k1'] * i1n, 0)} A / {fnum(r['k2'] * i2n, 0)} A", "yüksüzken akım okunuyorsa dolaşım akımıdır"),
    ]
    xs = [j * 5 for j in range(0, 27)]
    g1 = {"baslik": "Toplam yüke göre iki trafonun yüklenmesi", "x_ad": "Toplam yük (% toplam anma gücü)", "y_ad": "Yüklenme (%)", "ymin": 0,
          "seriler": [{"ad": "1. trafo", "renk": "#1a4d8f", "pts": pts(xs, [paylas(sn1, z1, sn2, z2, (sn1 + sn2) * x / 100, cosf, oran, saat)["k1"] * 100 for x in xs], 1)},
                      {"ad": "2. trafo", "renk": "#dc2626", "pts": pts(xs, [paylas(sn1, z1, sn2, z2, (sn1 + sn2) * x / 100, cosf, oran, saat)["k2"] * 100 for x in xs], 1)}],
          "yatay": [{"y": 100, "etiket": "anma", "renk": "#94a3b8"}], "isaretler": [{"x": num(p, "yuk", 80), "etiket": "yük"}]}
    os_ = [j * 0.25 for j in range(0, 21)]
    g2 = {"baslik": "Oran farkına göre dolaşım akımı (yüksüz)", "x_ad": "Çevirme oranı farkı (%)", "y_ad": "Dolaşım akımı (A)", "ymin": 0,
          "seriler": [{"ad": "aynı grup", "renk": "#7c3aed", "pts": pts(os_, [paylas(sn1, z1, sn2, z2, 0, cosf, x / 100, 0)["ic"] * i1n for x in os_], 1)}],
          "yatay": [{"y": min(i1n, i2n), "etiket": "küçük trafonun anma akımı", "renk": "#dc2626"}], "isaretler": [{"x": 2.5, "etiket": "bir kademe"}, {"x": 0.5, "etiket": "tolerans"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Paralel çalışan iki trafo, aynı iki bara arasına bağlı iki empedanstır. Yük akımı bu iki yoldan empedanslarıyla ters orantılı geçer: uk'sı küçük olan daha çok akım alır.",
            f"1. trafo {fnum(sn1, 0)} kVA uk %{fnum(uk1, 1)}, 2. trafo {fnum(sn2, 0)} kVA uk %{fnum(uk2, 1)}. Paylaşım güçle değil Sn/uk ile orantılıdır: {fnum((sn1 / uk1) / (sn2 / uk2), 2)} : 1.",
            f"Sonuç: 1. trafo %{fnum(r['k1'] * 100, 0)}, 2. trafo %{fnum(r['k2'] * 100, 0)} yükleniyor. uk'lar eşit olsaydı ikisi de aynı yüzdeyle yüklenirdi.",
            ("Kademeler aynı: yük yokken aralarında akım dolaşmaz." if oran == 0 and saat == 0 else
             f"İç gerilimler eşit değil: fark, iki trafonun empedanslarının toplamı üzerinden {fnum(r0['ic'] * i1n, 0)} A dolaştırır. Bu akım yüke gitmez; yalnız sargıları ısıtır ve bir trafonun yükünü artırırken ötekinin yükünü azaltır."),
            ("Bağlantı grubu farkı kademeyle düzeltilemez: açısal fark kalıcıdır ve dolaşım akımı kısa devre akımı mertebesindedir. Bu iki trafo paralel bağlanamaz." if saat else
             "Bağlantı grupları aynı: AG gerilimleri aynı fazda. Paralel çalışmanın ilk koşulu budur ve fazlama ölçüsüyle doğrulanır."),
        ],
        "dersler": [
            "Yük paylaşımını güç değil Sn/uk belirler: küçük uk'lı trafo önce dolar.",
            "Bir kademe farkı (%2,5) yüksüzken bile anma akımının önemli bir bölümü kadar dolaşım akımı demektir.",
            "Saat sayıları farklı trafolar paralel bağlanmaz; 30° fark bile yarım gerilimlik bir kısa devredir.",
            "Paralele almadan önce fazlama yapılır: aynı adlı fazlar arasında gerilim sıfır okunmalıdır.",
            "İki trafonun paralel çalışması AG kısa devre akımını da toplar: pano ve kesiciler buna göre seçilir.",
        ],
    }
