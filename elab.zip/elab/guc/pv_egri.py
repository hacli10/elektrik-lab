"""PV modülün akım–gerilim eğrisi: ışınım akımı, sıcaklık gerilimi belirler. Modül bir akım kaynağı gibi davranır: kısa devre akımı çalışma akımının yalnız birkaç yüzde üstündedir.

Model: elab/guc/pv_model.py (veri sayfasındaki dört noktadan kurulan açık bağıntı; tahmini modül değerleri).
Dayanak (metinden): TEDAŞ LÜY 50 kWe GES Tip Şartnamesi böl. 2.1.2 (kristal silisyum modüllerde DC bileşenlerin en küçük değerleri: gerilim Voc(STC) × 1,15, akım Isc(STC) × 1,25;
STC = 1000 W/m², hava kütlesi 1,5, 25 °C hücre sıcaklığı) ve böl. 2.1.10 («bir modülün kısa devre akımı çalışma akımının çok az üzerindedir; tek dizili sistemde sigorta
kısa devre akımını algılamaz»). Modülün çalışma sıcaklığı aralığı (−40 … +85 °C) veri sayfası değeridir (ikincil)."""
from __future__ import annotations

from . import pv_model as PV
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, lin, num, opt, pts

ID = "pv_egri"
BASLIK = "PV modülün I–V eğrisi"
IKON = "🔆"
GIRIS = ("Güneş modülü pile benzemez: gerilimi hemen hemen sabit, akımı ışıkla orantılı bir kaynaktır ve kısa devre edildiğinde akımı pek artmaz. Işınımı ve sıcaklığı değiştirin; "
         "eğrinin nasıl kaydığını, en büyük güç noktasının nereye gittiğini ve evirici bu noktadan uzaklaştığında gücün ne olduğunu izleyin.")

GES = "TEDAŞ LÜY 50 kWe GES Tip Şartnamesi"

KONTROLLER = [
    ctl("modul", "Modül", "sec", "m550", secenek=PV.secenek()),
    ctl("g", "Işınım (modül düzleminde)", "sayi", 1000, min=50, max=1300, adim=50, birim="W/m²"),
    ctl("ta", "Ortam sıcaklığı", "sayi", 25, min=-25, max=50, adim=1, birim="°C"),
    ctl("montaj", "Montaj", "sec", "arazi", secenek=opt(("arazi", "Açık arazi / eğimli konstrüksiyon (arkası havalanır)"), ("cati", "Çatıya paralel (arkası az havalanır, ≈ +10 K)"))),
    ctl("vo", "Çalışma gerilimi (en büyük güç noktası geriliminin yüzdesi)", "sayi", 100, min=0, max=125, adim=1, birim="%", yardim="100: evirici en büyük güç noktasını izliyor · 0: kısa devre"),
]


def run(p: dict) -> dict:
    mk = str(p.get("modul", "m550")); m = PV.MODUL.get(mk, PV.MODUL["m550"])
    g, ta, montaj, vo = num(p, "g", 1000), num(p, "ta", 25), str(p.get("montaj", "arazi")), num(p, "vo", 100)
    tc = PV.hucre_sicakligi(ta, g, m["noct"], 10.0 if montaj == "cati" else 0.0)
    n = PV.nokta(m, g, tc)
    stc = PV.nokta(m, 1000, 25)
    v = min(vo / 100 * n["vmp"], n["voc"])
    i = PV.akim(v, n)
    pw = v * i
    verim = n["pmp"] / (g * m["alan"]) * 100
    ff = n["pmp"] / (n["voc"] * n["isc"])
    soguk = PV.nokta(m, 1000, -10)
    parlak = PV.nokta(m, 1200, 45)
    kd_oran = (n["isc"] / n["imp"] - 1) * 100
    cz = Cizim(900, 320)
    cz.daire(80, 70, 26, "uyari", "#fde68a")
    for k in range(4):
        cz.ok(110 + k * 14, 86 + k * 10, 190 + k * 14, 132 + k * 10, "uyari", 1.6)
    cz.yazi(40, 120, f"{fnum(g, 0)} W/m²", "#b45309", 12, kalin=True)
    cz.dikdortgen(230, 60, 150, 190, "cizgi", "#1e3a8a", r=3)
    for a in range(1, 6):
        cz.hat(f"M{230 + a * 25},60 V250", "#93c5fd", w=0.8)
    for b in range(1, 12):
        cz.hat(f"M230,{60 + b * 16:.0f} H380", "#93c5fd", w=0.8)
    cz.yazi(305, 268, f"hücre {fnum(tc, 0)} °C", "#b91c1c" if tc > 70 else "#334155", 12, kalin=True, anchor="middle")
    cz.hat("M380,90 H470", "L1", hot=i > 0.05, w=2.5); cz.hat("M380,220 H470", "N", hot=i > 0.05, w=2.5)
    cz.kutu(470, 120, 110, 70, "Evirici (MPPT)" if 95 <= vo <= 105 else "Kısa devre" if vo < 3 else "Açık devre" if v >= n["voc"] * 0.999 else "Yük", f"{fnum(v, 1)} V · {fnum(i, 1)} A")
    cz.hat("M470,90 V120", "L1", hot=i > 0.05, w=2.5); cz.hat("M470,220 V190", "N", hot=i > 0.05, w=2.5)
    cz.yazi(610, 86, f"Kısa devre akımı {fa(n['isc'], 2)}", "#334155", 12)
    cz.yazi(610, 108, f"Açık devre gerilimi {fnum(n['voc'], 1)} V", "#334155", 12)
    cz.yazi(610, 130, f"En büyük güç {fnum(n['pmp'], 0)} W", "#15803d", 13, kalin=True)
    cz.yazi(610, 150, f"({fnum(n['vmp'], 1)} V · {fnum(n['imp'], 2)} A)", "#15803d", 11.5)
    cz.yazi(610, 176, f"Şimdi alınan güç {fnum(pw, 0)} W", "#b91c1c" if pw < 0.97 * n["pmp"] else "#15803d", 12.5, kalin=True)
    cz.yazi(610, 198, f"Verim %{fnum(verim, 1)} · dolgu çarpanı {fnum(ff, 2)}", "#64748b", 11.5)
    cz.yazi(610, 226, f"Kısa devre akımı çalışma akımının", "#64748b", 11.5)
    cz.yazi(610, 242, f"yalnız %{fnum(kd_oran, 1)} üstünde", "#b45309", 12, kalin=True)
    cz.yazi(40, 300, f"Etiket (STC, 1000 W/m², 25 °C): {fnum(stc['pmp'], 0)} W — bu koşulda etiketin %{fnum(n['pmp'] / stc['pmp'] * 100, 0)} kadarı", "#334155", 12)
    ozet = [
        K("En büyük güç", f"{fnum(n['pmp'], 0)} W", "info", f"etiketin %{fnum(n['pmp'] / stc['pmp'] * 100, 0)} kadarı"),
        K("Hücre sıcaklığı", f"{fnum(tc, 0)} °C", "warn" if tc > 70 else "info", f"ortamın {fnum(tc - ta, 0)} K üstünde"),
        K("Açık devre gerilimi", f"{fnum(n['voc'], 1)} V", "info", f"STC'de {fnum(stc['voc'], 1)} V · −10 °C'ta {fnum(soguk['voc'], 1)} V"),
        K("Kısa devre akımı", fa(n["isc"], 2), "info", f"çalışma akımının %{fnum(kd_oran, 1)} üstünde"),
        K("Şimdi alınan güç", f"{fnum(pw, 0)} W", "ok" if pw >= 0.99 * n["pmp"] else "warn", f"{fnum(v, 1)} V · {fnum(i, 2)} A"),
    ]
    kontroller = [
        C("Çalışma noktası en büyük güç noktasında mı?", f"{fnum(pw, 0)} W", f"≥ %99 × {fnum(n['pmp'], 0)} W", pw >= 0.99 * n["pmp"],
          "Evirici, dizinin gerilimini sürekli oynatarak gücün en büyük olduğu noktayı arar (MPPT). Bu noktanın solunda akım, sağında gerilim boşa gider", "hesap"),
        C("Hücre sıcaklığı modülün çalışma aralığında mı?", f"{fnum(tc, 0)} °C", "−40 … +85 °C", -40 <= tc <= 85, "Modül veri sayfalarındaki çalışma sıcaklığı aralığı; çatıya yapışık montajda yazın sınıra yaklaşılır", "ikincil"),
        C("Soğuk ve açık havada açık devre gerilimi «× 1,15» payının içinde mi?", f"−10 °C'ta {fnum(soguk['voc'], 1)} V = Voc(STC) × {fnum(soguk['voc'] / stc['voc'], 3)}", f"≤ Voc(STC) × 1,15 = {fnum(stc['voc'] * 1.15, 1)} V",
          soguk["voc"] <= stc["voc"] * 1.15, f"{GES} böl. 2.1.2: kristal silisyum modüllerde bütün DC bileşenlerin gerilimi en az Voc(STC) × 1,15 alınır", "resmi"),
        C("Parlak günde kısa devre akımı «× 1,25» payının içinde mi?", f"1200 W/m²'de {fa(parlak['isc'], 2)} = Isc(STC) × {fnum(parlak['isc'] / stc['isc'], 3)}", f"≤ Isc(STC) × 1,25 = {fa(stc['isc'] * 1.25, 2)}",
          parlak["isc"] <= stc["isc"] * 1.25, f"{GES} böl. 2.1.2: akım en az Isc(STC) × 1,25 alınır (bulut kenarı yansımasında ışınım kısa süre 1000 W/m²'yi aşar)", "resmi"),
        C("Kısa devrede akım sigortayı attıracak kadar büyüyor mu?", f"Isc / Imp = {fnum(n['isc'] / n['imp'], 3)}", "sigorta için ≥ 1,5–2 kat gerekir", None,
          f"{GES} böl. 2.1.10: bir modülün kısa devre akımı çalışma akımının çok az üzerindedir; tek dizili sistemde sigorta kısa devre akımını algılamaz ve temizlemez", "resmi"),
    ]
    girdiler = [
        G("Modül veri sayfası (STC)", f"Voc {fnum(m['voc'], 1)} V · Isc {fnum(m['isc'], 2)} A · Vmp {fnum(m['vmp'], 1)} V · Imp {fnum(m['imp'], 2)} A", "Modül etiketi ve veri sayfası",
          "Eğrinin dört köşe noktası", f"Pmax = Vmp × Imp = {fnum(m['vmp'] * m['imp'], 0)} W"),
        G("Sıcaklık katsayıları", f"Isc +%{fnum(m['a'], 3)}/°C · Voc %{fnum(m['b'], 2)}/°C · Pmax %{fnum(m['g'], 2)}/°C · NOCT {fnum(m['noct'], 0)} °C", "Veri sayfası",
          "Sıcakta gerilim ve güç düşer; soğukta gerilim yükselir", "her 10 °C için güç ≈ %" + fnum(abs(m["g"]) * 10, 1)),
        G("Işınım ve ortam sıcaklığı", f"{fnum(g, 0)} W/m² · {fnum(ta, 0)} °C", "Işınımölçer (piranometre / referans hücre) ve sıcaklık duyargası", "Akımı ışınım, hücre sıcaklığını ikisi birlikte belirler",
          f"Tc = Ta + (NOCT − 20) · G / 800 = {fnum(tc, 0)} °C"),
    ]
    adimlar = [
        A("Hücre sıcaklığı", "Tc = Ta + (NOCT − 20) · G / 800", f"{fnum(ta, 0)} + ({fnum(m['noct'], 0)} − 20) × {fnum(g, 0)} / 800" + (" + 10 K (çatı)" if montaj == "cati" and g > 0 else ""), f"{fnum(tc, 0)} °C", "güneşte hücre ortamdan 25–35 K sıcaktır", "hesap",
          ["Işınım ve ortam sıcaklığı"]),
        A("Kısa devre akımı", "Isc = Isc(STC) · G/1000 · (1 + α·ΔT)", f"{fnum(m['isc'], 2)} × {fnum(g / 1000, 2)} × (1 + {fnum(m['a'] / 100, 5)} × {fnum(tc - 25, 0)})", fa(n["isc"], 2), "ışınımla doğru orantılı", "hesap", ["Modül veri sayfası (STC)"]),
        A("Açık devre gerilimi", "Voc = Voc(STC) · (1 + β·ΔT) + n·Ns·Vt · ln(G/1000)", f"{fnum(m['voc'], 1)} × (1 − {fnum(abs(m['b']) / 100, 4)} × {fnum(tc - 25, 0)}) + …", f"{fnum(n['voc'], 1)} V", "sıcaklıkla düşer; ışınıma az bağlıdır", "hesap", ["Sıcaklık katsayıları"]),
        A("En büyük güç", "Pmp = Vmp · Imp", f"{fnum(n['vmp'], 1)} × {fnum(n['imp'], 2)}", f"{fnum(n['pmp'], 0)} W", "eğrinin dirseği", "hesap"),
        A("Verim ve dolgu çarpanı", "η = Pmp / (G · A) · FF = Pmp / (Voc · Isc)", f"{fnum(n['pmp'], 0)} / ({fnum(g, 0)} × {fnum(m['alan'], 2)} m²)", f"%{fnum(verim, 1)} · {fnum(ff, 2)}", "kalan ışınım ısıya döner", "hesap"),
        A("Çalışma noktası", "I = Isc · [1 − C1 · (exp(V / (C2·Voc)) − 1)]", f"V = {fnum(v, 1)} V", f"{fa(i, 2)} · {fnum(pw, 0)} W", "eğri üzerinde", "hesap"),
        A("DC malzeme için en küçük değerler", "U ≥ Voc(STC) × 1,15 · I ≥ Isc(STC) × 1,25", f"{fnum(stc['voc'], 1)} × 1,15 · {fnum(stc['isc'], 2)} × 1,25", f"{fnum(stc['voc'] * 1.15, 1)} V · {fa(stc['isc'] * 1.25, 1)} (modül başına)", f"{GES} böl. 2.1.2", "resmi"),
    ]
    ayarlar = [
        S("Evirici › MPPT", "dizinin gerilimini en büyük güç noktasında tutar", f"modül başına {fnum(n['vmp'], 1)} V", "Işınım ve sıcaklık değiştikçe nokta kayar", "evirici kılavuzu", "ikincil"),
        S("Dizi sigortası (gPV)", "kısa devreyi değil, öbür dizilerden gelen ters akımı keser", f"1,5 × Isc < In ≤ 2,4 × Isc", "Tek dizide sigorta işe yaramaz", f"{GES} böl. 2.1.10.1", "resmi"),
        S("DC ayırıcı", "yük altında DC akımı kesebilen tip", f"≥ {fnum(stc['voc'] * 1.15, 0)} V × modül sayısı", "DC ark kendiliğinden sönmez", f"{GES} böl. 2.1.2", "resmi"),
        S("Yalıtım izleme (evirici)", "DC tarafın toprağa yalıtım direncini ölçer", "—", "Modül akım kaynağıdır: toprak arızası akımı da küçüktür, aşırı akımla bulunamaz", "evirici kılavuzu", "ikincil"),
    ]
    test = [
        T("Açık devre gerilimi", "Dizi ayrıkken DC voltmetre (uygun gerilim sınıfında)", f"modül başına ≈ {fnum(n['voc'], 1)} V (bu sıcaklıkta)", "diziler arasında fark: eksik modül, ters bağlantı, kısa devre diyot"),
        T("Kısa devre akımı", "DC pens ampermetre / I–V eğri çizici", f"≈ {fa(n['isc'], 1)} (bu ışınımda)", "ışınımla birlikte ölçülmezse yorumlanamaz"),
        T("I–V eğrisi", "Eğri çizici + ışınım ve sıcaklık duyargası", "eğri STC'ye çevrilip etiketle karşılaştırılır", "basamak: gölge ya da diyot; düşük dirsek: seri direnç (kötü bağlantı)"),
        T("Termal kamera", "Yük altında, en az 600 W/m²", "hücreler arası fark birkaç K", "tek sıcak hücre: çatlak ya da gölge — GES › Gölge"),
    ]
    vs = lin(0, max(stc["voc"], n["voc"], soguk["voc"]) * 1.02, 90)
    g1 = {"baslik": "Akım–gerilim eğrisi", "x_ad": "Gerilim (V)", "y_ad": "Akım (A)", "ymin": 0,
          "seriler": [{"ad": "bu koşul", "renk": "#dc2626", "pts": pts(vs, [PV.akim(q, n) for q in vs], 3)}, {"ad": "STC (1000 W/m², 25 °C)", "renk": "#94a3b8", "pts": pts(vs, [PV.akim(q, stc) for q in vs], 3)},
                      {"ad": "1000 W/m², −10 °C", "renk": "#0ea5e9", "pts": pts(vs, [PV.akim(q, soguk) for q in vs], 3)}], "isaretler": [{"x": v, "etiket": "çalışma"}]}
    g2 = {"baslik": "Güç–gerilim eğrisi", "x_ad": "Gerilim (V)", "y_ad": "Güç (W)", "ymin": 0,
          "seriler": [{"ad": "bu koşul", "renk": "#dc2626", "pts": pts(vs, [q * PV.akim(q, n) for q in vs], 1)}, {"ad": "STC", "renk": "#94a3b8", "pts": pts(vs, [q * PV.akim(q, stc) for q in vs], 1)},
                      {"ad": "1000 W/m², −10 °C", "renk": "#0ea5e9", "pts": pts(vs, [q * PV.akim(q, soguk) for q in vs], 1)}], "isaretler": [{"x": v, "etiket": "çalışma"}]}
    rows_g = []
    for gg in (200, 400, 600, 800, 1000, 1200):
        t2 = PV.hucre_sicakligi(ta, gg, m["noct"], 10.0 if montaj == "cati" else 0.0); q = PV.nokta(m, gg, t2)
        rows_g.append([f"{gg} W/m²", fnum(t2, 0), fnum(q["isc"], 2), fnum(q["voc"], 1), fnum(q["vmp"], 1), fnum(q["pmp"], 0), fnum(q["pmp"] / (gg * m["alan"]) * 100, 1)])
    rows_t = []
    for t2 in (-10, 0, 25, 45, 65, 85):
        q = PV.nokta(m, 1000, t2)
        rows_t.append([f"{t2} °C", fnum(q["voc"], 1), fnum(q["vmp"], 1), fnum(q["isc"], 2), fnum(q["pmp"], 0), f"%{fnum(q['pmp'] / stc['pmp'] * 100, 0)}"])
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Güneş hücresi, ışık düşünce akım üreten geniş bir diyottur. Işık ne kadar çoksa o kadar elektron kopar: akım ışınımla doğru orantılıdır. Gerilim ise diyodun iletime geçtiği eşikle sınırlıdır ve ışınıma pek bağlı değildir.",
            f"Bu yüzden eğri iki bölgelidir. Solda modül sabit akım kaynağı gibidir: gerilim ne olursa olsun {fa(n['isc'], 1)} dolayında akım verir. Sağda sabit gerilim kaynağına benzer ve {fnum(n['voc'], 1)} V'ta akım sıfıra iner. İkisinin arasındaki dirsekte güç en büyüktür: {fnum(n['pmp'], 0)} W.",
            f"Sıcaklık gerilimi düşürür. Güneşte hücre ortamdan {fnum(tc - ta, 0)} K sıcaktır ({fnum(tc, 0)} °C); her derece gücün binde {fnum(abs(m['g']) * 10, 1)}'ini götürür. Etiketteki güç 25 °C hücre sıcaklığı içindir: yazın öğle vakti modül etiketinin altında, soğuk ve parlak bir kış günü üstünde üretir.",
            f"Soğuk, gerilimi yükseltir: −10 °C'ta açık devre gerilimi {fnum(soguk['voc'], 1)} V. Dizideki modül sayısı bu değere göre belirlenir — eviricinin dayanabileceği en yüksek gerilim yazın değil, kışın sabahı aşılır.",
            f"Modülün kısa devre akımı çalışma akımının yalnız %{fnum(kd_oran, 1)} üstündedir. AC tesisattaki «kısa devre olursa büyük akım akar, sigorta atar» mantığı burada çalışmaz: kısa devre edilmiş bir dizi saatlerce, hiçbir koruma çalışmadan akım akıtır. DC taraftaki korumanın ayrı kuralları olmasının nedeni budur.",
            (f"Evirici şu an en büyük güç noktasını izliyor: {fnum(v, 1)} V, {fnum(i, 2)} A." if pw >= 0.99 * n["pmp"]
             else f"Çalışma noktası en büyük güç noktasından uzak: {fnum(v, 1)} V'ta {fnum(pw, 0)} W alınıyor, {fnum(n['pmp'] - pw, 0)} W modülde ısı olarak kalıyor. Kısa devrede ve açık devrede güç sıfırdır: ışınımın tamamı ısıya döner."),
        ],
        "dersler": [
            "Akımı ışınım, gerilimi sıcaklık belirler.",
            "Sıcakta güç düşer (≈ %0,3–0,4 / °C); soğukta gerilim yükselir.",
            "Kısa devre akımı çalışma akımının birkaç yüzde üstündedir: sigorta kısa devreyi göremez.",
            "DC malzeme en az Voc × 1,15 gerilime ve Isc × 1,25 akıma göre seçilir (TEDAŞ GES tip şartnamesi).",
            "Evirici gücün en büyük olduğu noktayı sürekli arar; başka her noktada fark modülde ısı olur.",
        ],
        "tablolar": [
            {"baslik": f"Işınıma göre ({fnum(ta, 0)} °C ortam)", "cols": ["Işınım", "Hücre (°C)", "Isc (A)", "Voc (V)", "Vmp (V)", "Pmp (W)", "Verim (%)"], "rows": rows_g},
            {"baslik": "Hücre sıcaklığına göre (1000 W/m²)", "cols": ["Hücre sıcaklığı", "Voc (V)", "Vmp (V)", "Isc (A)", "Pmp (W)", "Etikete göre"], "rows": rows_t,
             "not": "Modül değerleri tipik veri sayfası mertebesindedir; belirli bir üreticinin ürünü değildir."},
        ],
    }
