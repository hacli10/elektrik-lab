"""Üç fazlı motoru tek fazda çalıştırma (Steinmetz bağlantısı): üçgen bağlı motorun iki ucu şebekeye, üçüncü ucu kondansatör üzerinden bir faza bağlanır.
Kondansatör değerine ve yüke göre sargı akımları, gerilim dengesizliği, alınabilen güç, kalkış momenti.

Model: motorun pozitif ve negatif bileşen admitansları (motor_model) faz koordinatlarına çevrilir; üçüncü uç yalnız kondansatöre bağlı serbest düğümdür.
Kondansatör için «230 V'ta kW başına ≈ 70 µF» ve «gücün ≈ %70'i alınır» kuralları saha pratiğidir (ikincil); buradaki sonuçlar tipik motor parametreleriyle
hesaplanır (tahmini)."""
from __future__ import annotations

import cmath
import math

from . import motor_model as M
from .asenkron import anma_akim
from .ortak import A, A120, C, G, K, RENK3, S, S3, T, TEMEL, Cizim, ctl, fa, fazor, fnum, num, opt, pts
from .trafo_model import dizi, dizi_blok

ID = "steinmetz"
BASLIK = "Üç fazlı motor tek fazda"
IKON = "🔌"
GIRIS = ("Elde üç fazlı küçük bir motor var ama şebeke tek faz. Motor üçgen bağlanır, iki ucu şebekeye, üçüncü ucu bir kondansatör üzerinden fazlardan birine verilir: kondansatör eksik fazı "
         "yaklaşık olarak üretir. Kondansatör değerini ve yükü değiştirin; sargı akımlarının neden eşit olmadığını ve motordan neden tam güç alınamadığını izleyin.")
GUCLER = (0.18, 0.37, 0.55, 0.75, 1.1, 1.5, 2.2)
AKIM = {0.18: 1.2, 0.37: 2.0, 0.55: 2.8, 0.75: 3.5, 1.1: 4.9, 1.5: 6.3, 2.2: 8.9}          # 4 kutuplu küçük motorların 230 V üçgendeki anma akımı (A, tipik katalog değerleri)

KONTROLLER = [
    ctl("pn", "Motor gücü (etiket, üç fazlı)", "sec", 0.75, secenek=opt(*[(g, f"{str(g).replace('.', ',')} kW") for g in GUCLER])),
    ctl("c", "Kondansatör", "sayi", 50, min=10, max=200, adim=5, birim="µF/kW", yardim="230 V, 50 Hz için kural: kW başına ≈ 70 µF"),
    ctl("yuk", "Yük momenti", "sayi", 55, min=0, max=110, adim=5, birim="%"),
    ctl("yon", "Kondansatörün bağlandığı faz ucu", "sec", "l", secenek=opt(("l", "L ucuna (bir yöne döner)"), ("n", "N ucuna (ters yöne döner)"))),
    ctl("kalkis", "Kalkışta ek kondansatör (çalışma kondansatörünün 2 katı, geçici)", "onay", True),
]


def coz(par: dict, s: float, yc: complex) -> dict:
    """Üçgen motor, uçlar a (L), b (N), c (kondansatörle a'ya). Faz–nötr tabanında: Va = +√3/2, Vb = −√3/2 (hat arası √3 = anma)."""
    y1, y2 = 1 / M.zs(par, s), 1 / M.zs(par, 2 - s)
    yb = dizi_blok(0j, y1, y2)
    va, vb = complex(S3 / 2), complex(-S3 / 2)
    vc = (yc * va - yb[2][0] * va - yb[2][1] * vb) / (yb[2][2] + yc)
    v = [va, vb, vc]
    ort = sum(v) / 3; v = [x - ort for x in v]                    # yıldız noktasına göre
    v0, v1, v2 = dizi(v)
    m = M.moment(par, s, v1, v2)
    ihat = [sum(yb[i][j] * v[j] for j in range(3)) for i in range(3)]
    # üçgen sargı akımları (anma sargı akımına göre): bileşenlerden
    d1, d2 = m["i1"] * cmath.rect(1, math.radians(30)), m["i2"] * cmath.rect(1, math.radians(-30))
    a = A120
    sargi = [d1 + d2, a * a * d1 + a * d2, a * d1 + a * a * d2]
    return {"v": v, "v1": v1, "v2": v2, "m": m["m"], "ihat": ihat, "sargi": sargi, "uc": abs(v[2] - v[0]), "p_rotor": m["p_rotor"]}


def calis(par: dict, yuk: float, yc: complex) -> dict:
    mn = M.anma(M.UC)["m"]
    ss = [0.003 * 1.08 ** k for k in range(80) if 0.003 * 1.08 ** k < 1.0]
    f = lambda s: coz(par, s, yc)["m"] / mn - yuk                                   # noqa: E731
    tepe = max(ss, key=lambda s: coz(par, s, yc)["m"])
    if f(tepe) < 0:
        return {"s": 1.0, "devrildi": True, **coz(par, 1.0, yc)}
    lo, hi = 1e-5, tepe
    for _ in range(45):
        mid = (lo + hi) / 2
        lo, hi = (lo, mid) if f(mid) > 0 else (mid, hi)
    return {"s": (lo + hi) / 2, "devrildi": False, **coz(par, (lo + hi) / 2, yc)}


def run(p: dict) -> dict:
    pn, c_kw, yuk = num(p, "pn", 0.75), num(p, "c", 50), num(p, "yuk", 55) / 100
    par = M.UC; a0 = M.anma(par)
    an = {"i": AKIM.get(pn, anma_akim(pn, 230.0)["i"])}        # üçgende 230 V hat gerilimi
    amper = an["i"] / a0["i"]
    zb = (230 / S3) / amper                                      # faz–nötr taban empedansı (Ω)
    c_uf = c_kw * pn
    yc = 1j * (100 * math.pi * c_uf * 1e-6) * zb                 # pu admitans
    r = calis(par, yuk, yc)
    kal = coz(par, 1.0, yc * (3 if p.get("kalkis") else 1))
    m0 = kal["m"] / a0["m"]
    sargi = [abs(x) / a0["i"] for x in r["sargi"]]; en = max(sargi)
    vuf = abs(r["v2"]) / abs(r["v1"]) * 100
    uc_v = r["uc"] / S3 * 230
    # alınabilen güç: en yüklü sargı anma akımını aşmadan
    y_max = 0.0
    for k in range(1, 23):
        q = calis(par, k * 0.05, yc)
        if q["devrildi"] or max(abs(x) for x in q["sargi"]) / a0["i"] > 1.0:
            break
        y_max = k * 0.05
    c_iyi = min(range(20, 201, 5), key=lambda cu: abs(calis(par, yuk, 1j * (100 * math.pi * cu * pn * 1e-6) * zb)["v2"]))

    c = Cizim(900, 320)
    c.hat("M40,60 H250", "L1", hot=True, w=3); c.yazi(32, 64, "L", "#8a4b12", 12, kalin=True, anchor="end")
    c.hat("M40,260 H250", "N", hot=True, w=3, hot_renk="mavi"); c.yazi(32, 264, "N", "#1d4ed8", 12, kalin=True, anchor="end")
    ust, alt, sag = (250, 60), (250, 260), (420, 160)
    for (a_, b_, k) in ((ust, alt, 0), (alt, sag, 1), (sag, ust, 2)):
        c.hat(f"M{a_[0]},{a_[1]} L{b_[0]},{b_[1]}", "ariza" if sargi[k] > 1.05 else "cizgi", hot=True, w=5, hot_renk="ariza" if sargi[k] > 1.05 else "uyari")
    c.yazi(238, 164, f"{fnum(sargi[0], 2)}", "#b91c1c" if sargi[0] > 1.05 else "#334155", 12.5, kalin=True, anchor="end")
    c.yazi(345, 228, f"{fnum(sargi[1], 2)}", "#b91c1c" if sargi[1] > 1.05 else "#334155", 12.5, kalin=True)
    c.yazi(345, 100, f"{fnum(sargi[2], 2)}", "#b91c1c" if sargi[2] > 1.05 else "#334155", 12.5, kalin=True)
    yk = 60 if p.get("yon", "l") == "l" else 260
    c.hat(f"M{sag[0]},{sag[1]} H500 V{yk + (40 if yk == 60 else -40)}", "cizgi", hot=True, w=2.4)
    c.kap(500, yk + (10 if yk == 60 else -40), yk + (40 if yk == 60 else -10), "cizgi", ad=f"{fnum(c_uf, 0)} µF")
    c.hat(f"M500,{yk + (10 if yk == 60 else -10)} V{yk} H250", "cizgi", hot=True, w=2.4)
    c.yazi(250, 290, "sargı akımları (anma sargı akımının katı)", "#64748b", 10.5, anchor="middle")
    c.yazi(580, 60, "DEVRİLDİ" if r["devrildi"] else f"Motor dönüyor — kayma %{fnum(r['s'] * 100, 1)}", "#b91c1c" if r["devrildi"] else "#15803d", 14, kalin=True)
    c.yazi(580, 86, f"Gerilim dengesizliği V2/V1 = %{fnum(vuf, 0)}", "#b91c1c" if vuf > 10 else "#334155", 12.5, kalin=True)
    c.yazi(580, 110, f"En yüklü sargı × {fnum(en, 2)}", "#b91c1c" if en > 1.05 else "#334155", 12.5, kalin=True)
    c.yazi(580, 134, f"Kalkış momenti %{fnum(m0 * 100, 0)}" + (" (ek kondansatörle)" if p.get("kalkis") else ""), "#b91c1c" if m0 < 0.3 else "#334155", 12.5)
    c.yazi(580, 158, f"Kondansatör gerilimi {fnum(uc_v, 0)} V", "#b91c1c" if uc_v > 400 else "#334155", 12.5)
    c.yazi(580, 188, f"Bu kondansatörle alınabilen yük: %{fnum(y_max * 100, 0)}", "#1a4d8f", 12.5, kalin=True)
    c.yazi(580, 212, f"Bu yük için en uygun değer ≈ {fnum(c_iyi, 0)} µF/kW", "#1a4d8f", 12)
    c.yazi(580, 246, "Kondansatör tek bir yük için ayarlanabilir:", "#64748b", 11); c.yazi(580, 262, "yük değişince denge bozulur.", "#64748b", 11)
    fz = {"baslik": "Motor uç gerilimleri (yıldız noktasına göre)", "vektorler": [fazor(ad, x, RENK3[k]) for k, (ad, x) in enumerate(zip(("L", "N", "C"), r["v"]))], "not": "dengeli üç fazda üç vektör eşit ve 120° aralıklı olurdu"}
    ozet = [
        K("Motor", "devrildi" if r["devrildi"] else f"kayma %{fnum(r['s'] * 100, 1)}", "bad" if r["devrildi"] else "ok", f"yük %{fnum(yuk * 100, 0)}"),
        K("Gerilim dengesizliği", f"%{fnum(vuf, 0)}", "bad" if vuf > 10 else "warn" if vuf > 3 else "ok", "V2/V1 — sıfır olması için kondansatör yüke uymalı"),
        K("En yüklü sargı", f"× {fnum(en, 2)}", "bad" if en > 1.05 else "ok", " / ".join(fnum(x, 2) for x in sargi)),
        K("Kalkış momenti", f"%{fnum(m0 * 100, 0)}", "bad" if m0 < 0.3 else "ok", "üç fazda ≈ %240"),
        K("Alınabilen yük", f"%{fnum(y_max * 100, 0)}", "warn" if y_max < 0.8 else "ok", "hiçbir sargı anma akımını aşmadan"),
    ]
    kontroller = [
        C("Hiçbir sargı anma akımını aşmıyor mu?", f"en yüklü × {fnum(en, 2)}", "≤ 1,05", en <= 1.05, "Kondansatör üçüncü fazı tam üretemez: akımlar eşit dağılmaz, bir sargı ötekilerden çok yüklenir", "hesap"),
        C("Kalkış momenti yeterli mi?", f"%{fnum(m0 * 100, 0)}", "≥ %30 (hafif kalkan yük)", m0 >= 0.3, "Çalışma için seçilen kondansatör kalkışta küçük kalır: kalkış momenti üç fazdakinin dörtte biri dolayındadır. Ağır kalkışta geçici ek kondansatör kullanılır", "ikincil"),
        C("Kondansatör değeri kural aralığında mı?", f"{fnum(c_kw, 0)} µF/kW", "tam yük için ≈ 70 µF/kW; kısmi yükte 40–60", 35 <= c_kw <= 90, "Saha kuralı; uygun değer yüke bağlıdır", "ikincil"),
        C("Kondansatör gerilimi", f"{fnum(uc_v, 0)} V", "≤ 400 V (motor çalışma kondansatörü)", uc_v <= 400, "Kondansatörün üstündeki gerilim şebeke geriliminden yüksektir; elektrolitik kalkış kondansatörü sürekli devrede bırakılmaz", "tahmini"),
        C("Motor 230 V üçgene uygun mu?", "etiket: 230/400 V Δ/Y", "üçgen 230 V", None, "Yalnız sargı gerilimi 230 V olan (etiketinde 230/400 V yazan) motorlar tek fazlı 230 V'ta üçgen bağlanabilir; 400/690 V motor bağlanamaz", "hesap"),
    ]
    girdiler = [
        G("Motor etiketi", f"{str(pn).replace('.', ',')} kW · 230/400 V Δ/Y · üçgende ≈ {fa(an['i'], 1)}", "Etiket", "Sargı gerilimi 230 V olmalı; anma akımı üçgen bağlantıdaki değerdir", "I(sargı) = I(hat) / √3"),
        G("Kondansatör", f"{fnum(c_uf, 0)} µF ({fnum(c_kw, 0)} µF/kW)", "Kondansatörün üstü; motor çalışma tipi (MKP), ≥ 400 V", "Üçüncü ucun gerilimini ve açısını belirler", "Xc = 1 / (2π·f·C)"),
        G("Yük", f"%{fnum(yuk * 100, 0)}", "Çalışma akımı", "Kondansatör yalnız bir yük değerinde dengeyi sağlar", "V2 = 0 koşulu"),
    ]
    adimlar = [
        A("Motorun bileşen admitansları", "Y1 = 1 / Z(s) · Y2 = 1 / Z(2 − s)", f"s = {fnum(r['s'], 3)}", f"|Y1| = {fnum(abs(1 / M.zs(par, r['s'])), 2)} · |Y2| = {fnum(abs(1 / M.zs(par, 2 - r['s'])), 2)} pu", "motor geri alana kilitli rotor gibi görünür: Y2 büyüktür", "hesap", ["Motor etiketi"]),
        A("Üçüncü ucun gerilimi", "Σ I(c) = 0: motor akımı = kondansatör akımı", f"C = {fnum(c_uf, 0)} µF", f"|Vc| = {fnum(abs(r['v'][2]), 2)} pu", "serbest düğümde akımlar toplamı sıfır", "hesap", ["Kondansatör"]),
        A("Gerilim dengesizliği", "V2 / V1", "uç gerilimlerinin simetrili bileşenleri", f"%{fnum(vuf, 0)}", TEMEL, "hesap"),
        A("Sargı akımları", "üçgen: bileşen akımları ∠ ±30°", "anma sargı akımına göre", " / ".join(fnum(x, 2) for x in sargi), "üç sargı eşit yüklenmez", "hesap"),
        A("Alınabilen yük", "en yüklü sargı = anma akımı olana kadar", f"C = {fnum(c_kw, 0)} µF/kW", f"%{fnum(y_max * 100, 0)}", "kural: etiket gücünün ≈ %70'i", "ikincil"),
    ]
    ayarlar = [
        S("Termik koruma", f"{fa(an['i'], 1)} altında; en yüklü sargıya göre", "—", "Hat akımı sargıların en yüklüsünü göstermez: ayar anma akımının altında tutulur", "saha pratiği", "ikincil"),
        S("Kalkış kondansatörü rölesi", "kalkıştan sonra ayırır", "≈ 2 × çalışma kondansatörü", "Ağır kalkışta geçici olarak paralel bağlanır", "saha pratiği", "ikincil"),
        S("Dönüş yönü", "kondansatör öbür faz ucuna alınır", "—", "Kondansatör L ucundan N ucuna taşınınca motor ters döner", "hesap", "hesap"),
    ]
    test = [
        T("Üç sargı akımı", "Pens ampermetre, motorun üç ucunda", "birbirine yakın (yük kondansatöre uygunsa)", "biri belirgin yüksekse kondansatör yüke uymuyor"),
        T("Kondansatör gerilimi", "Çalışırken, yalıtılmış proplarla", f"≈ {fnum(uc_v, 0)} V", "anma geriliminin üstündeyse kondansatör kısa ömürlü olur"),
        T("Isınma", "Yarım saat çalışmadan sonra gövde sıcaklığı", "üç fazlı çalışmadakinden yüksek, ama sınıf sınırının altında", "ısınıyorsa yük azaltılır ya da kondansatör değiştirilir"),
    ]
    cs = list(range(20, 201, 5))
    egri = [calis(par, yuk, 1j * (100 * math.pi * cu * pn * 1e-6) * zb) for cu in cs]
    g1 = {"baslik": f"Kondansatör değerine göre (yük %{fnum(yuk * 100, 0)})", "x_ad": "Kondansatör (µF/kW)", "y_ad": "sargı akımı (× anma) · V2/V1", "ymin": 0,
          "seriler": [{"ad": "en yüklü sargı", "renk": "#dc2626", "pts": pts(cs, [max(abs(x) for x in q["sargi"]) / a0["i"] for q in egri], 3)},
                      {"ad": "en az yüklü sargı", "renk": "#1a4d8f", "pts": pts(cs, [min(abs(x) for x in q["sargi"]) / a0["i"] for q in egri], 3)},
                      {"ad": "V2/V1", "renk": "#7c3aed", "kesik": True, "pts": pts(cs, [abs(q["v2"]) / abs(q["v1"]) for q in egri], 3)}],
          "yatay": [{"y": 1.0, "etiket": "anma", "renk": "#94a3b8"}], "isaretler": [{"x": c_kw, "etiket": "seçili"}]}
    ys = [k * 0.05 for k in range(0, 23)]
    eg2 = [calis(par, x, yc) for x in ys]
    g2 = {"baslik": f"Yüke göre sargı akımları ({fnum(c_kw, 0)} µF/kW)", "x_ad": "Yük (% anma)", "y_ad": "Sargı akımı (× anma)", "ymin": 0,
          "seriler": [{"ad": f"sargı {k + 1}", "renk": RENK3[k], "pts": pts([x * 100 for x in ys], [abs(q["sargi"][k]) / a0["i"] for q in eg2], 3)} for k in range(3)],
          "yatay": [{"y": 1.0, "etiket": "anma", "renk": "#94a3b8"}], "isaretler": [{"x": yuk * 100, "etiket": "yük"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(fazor=fz), "grafikler": [g1, g2],
        "anlatim": [
            "Üç fazlı motorun dönen alan üretebilmesi için üç ucuna 120° kaymış üç gerilim gerekir. Tek fazlı şebeke bunlardan yalnız birini (iki uç arasındaki gerilimi) verir.",
            "Steinmetz bağlantısında üçüncü uç, bir kondansatör üzerinden faz uçlarından birine bağlanır. Kondansatörün akımı gerilimden 90° ileridedir; motorun sargılarıyla birlikte üçüncü uçta kaymış bir gerilim oluşturur. Motor bunu eksik faz gibi kullanır.",
            f"Bu kaymanın ne kadar doğru olacağı motorun o andaki empedansına, yani yüke bağlıdır. {fnum(c_kw, 0)} µF/kW ile %{fnum(yuk * 100, 0)} yükte gerilim dengesizliği %{fnum(vuf, 0)}: sargı akımları {fnum(sargi[0], 2)} / {fnum(sargi[1], 2)} / {fnum(sargi[2], 2)}.",
            "Dengesizlik demek geri dönen alan demektir: moment azalır, rotor ısınır, motor titrer. Bu yüzden motordan etiket gücünün tamamı alınamaz; hiçbir sargı anma akımını aşmasın diye güç düşürülür.",
            f"Kalkışta motorun empedansı çok düşüktür; çalışma için seçilen kondansatör küçük kalır ve kalkış momenti %{fnum(coz(par, 1.0, yc)['m'] / a0['m'] * 100, 0)}'e iner. Fan gibi hafif kalkan yüklerde yeter; kompresörde kalkış için geçici ek kondansatör gerekir.",
            "Bu bağlantı küçük güçlerde (2 kW'a kadar) pratik bir çaredir. Daha büyük güçte ya da değişken yükte doğru çözüm tek faz girişli frekans çeviricidir: üç fazı gerçekten üretir.",
        ],
        "dersler": [
            "Kondansatör üçüncü fazı yaklaşık üretir ve yalnız bir yükte tam tutar.",
            "Kural: 230 V'ta kW başına ≈ 70 µF, alınabilen güç etiketin ≈ %70'i, kalkış momenti üç fazdakinin dörtte biri.",
            "Yalnız 230/400 V etiketli motor 230 V tek fazda üçgen bağlanır.",
            "Kondansatör öbür faz ucuna alınırsa motor ters döner.",
            "Sargı akımları eşit değilse kondansatör yüke uymuyordur: en yüklü sargı motoru sınırlar.",
        ],
    }
