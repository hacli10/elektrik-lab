"""Kademe değiştirme: enerjisiz kademe değiştiricinin konumu, şebeke gerilimi ve yüke göre AG gerilimi; yanlış kademede çekirdeğin aşırı uyarılması
(akı, boşta kayıp, boşta akım, ses); kademenin neden enerji altında çevrilmediği.

Kademe gerilimleri ve ayar sınıfı (sabit akı, CFVV), 1 no.lu kademenin en küçük sarım sayısı olduğu, kademenin enerjisizken değiştirildiği ve aşırı gerilimde
çalışma sınırları (%105 Un'de anma akımı, %110 Un'de boşta) TEDAŞ-MLZ/99-032.E'dendir. Aşırı uyarmada boşta kaybın akının karesiyle, boşta akımın akının
yaklaşık 8. kuvvetiyle, sesin 130·log10(B) ile değiştiği (%10 fazla akı ≈ +5 dB) kabulleri tipiktir (tahmini): gerçek eğri çekirdek sacına bağlıdır."""
from __future__ import annotations

import math

from .ortak import A, C, G, K, S, SGB, SIEMENS_K, T, Cizim, ctl, fa, fnum, kademeler, num, pts, tr_al, tr_ctl, tr_girdi
from .trafo_yuk import u2

ID = "trafo_kademe"
BASLIK = "Kademe değiştirme"
IKON = "🎚"
GIRIS = ("Kademe değiştirici YG sargısının sarım sayısını değiştirir: şebeke gerilimi kademe geriliminden yüksekse çekirdek fazla uyarılır, AG gerilimi yükselir, boşta kayıp ve ses artar; "
         "düşükse AG gerilimi düşük kalır. Şebeke gerilimini ve kademeyi değiştirip doğru kademeyi bulun.")

KONTROLLER = tr_ctl() + [
    ctl("kademe", "Kademe konumu", "sayi", 5, min=1, max=6, adim=1, yardim="1 no.lu kademe en küçük sarım sayısıdır (en düşük gerilim). 33 kV trafoda 6, öbürlerinde 5 kademe vardır"),
    ctl("u_net", "Şebeke gerilimi (ana kademe geriliminin yüzdesi)", "sayi", 104.5, min=85, max=112, adim=0.5, birim="%", yardim="33 kV anma gerilimli trafo 34,5 kV şebekede: %104,5"),
    ctl("yuk", "Yük", "sayi", 70, min=0, max=120, adim=5, birim="%"),
    ctl("cos", "Güç katsayısı (endüktif)", "sayi", 0.9, min=0.5, max=1.0, adim=0.01),
    ctl("enerjili", "Kademe enerji altında çevrilmeye çalışılıyor", "onay", False),
]


def hal(tr: dict, u_tap: float, u_net: float, k: float, cosf: float) -> dict:
    b = u_net / u_tap
    v = abs(u2(tr, k, cosf, False, b))
    return {"b": b, "u0": 400 * b, "uy": 400 * v, "p0": tr["p0"] * b * b, "i0": b ** 8, "ses": 130 * math.log10(b), "ik": tr["ik2"] * b}


def run(p: dict) -> dict:
    tr = tr_al(p)
    taps = kademeler(tr["un"])
    no = int(min(max(num(p, "kademe", 5), 1), len(taps)))
    u_net = tr["un"] * num(p, "u_net", 104.5) / 100
    k, cosf, enerjili = num(p, "yuk", 70) / 100, num(p, "cos", 0.9), bool(p.get("enerjili"))
    u_tap = taps[no - 1]
    h = hal(tr, u_tap, u_net, k, cosf)
    hepsi = [hal(tr, t, u_net, k, cosf) for t in taps]
    uygun = [j for j in range(len(taps)) if hepsi[j]["b"] <= 1.05 and hepsi[j]["uy"] >= 380 and hepsi[j]["u0"] <= 420]          # önce akı anma değerine en yakın olan
    iyi = min(uygun, key=lambda j: abs(hepsi[j]["b"] - 1)) if uygun else min(range(len(taps)), key=lambda j: abs(hepsi[j]["uy"] - 400) + (1000 if hepsi[j]["b"] > 1.05 else 0))
    b = h["b"]
    kuru = tr["tip"] == "kuru"

    c = Cizim(900, 330)
    c.kutu(20, 30, 140, 54, "OG şebeke", f"{fnum(u_net, 2)} kV")
    c.hat("M160,57 H250 V80", "L1", hot=True, w=3)
    n = len(taps); y0, y1 = 80, 280
    c.dikdortgen(236, y0, 28, y1 - y0, "cizgi", "#fde68a", kw=2); c.yazi(250, y1 + 16, "YG sargısı", "#475569", 10.5, anchor="middle")
    for j, t in enumerate(taps):                                   # kademe uçları: sargının alt ucunda, 1 no.lu kademe en az sarım
        y = y1 - 16 - j * 22
        c.hat(f"M264,{y} H330", "cizgi", w=1.6)
        c.daire(334, y, 4, "ariza" if j == no - 1 else "cizgi", "#dc2626" if j == no - 1 else "#fff", w=1.4)
        c.yazi(346, y + 4, f"{j + 1} — {fnum(t, 2)} kV", "#b91c1c" if j == no - 1 else "#15803d" if j == iyi else "#475569", 11, kalin=j in (no - 1, iyi))
    ysec = y1 - 16 - (no - 1) * 22
    c.hat(f"M470,{ysec} H436", "ariza", w=3); c.yazi(476, ysec + 4, "seçici" + (" — ARK" if enerjili else ""), "#b91c1c", 11.5, kalin=True)
    if enerjili:
        c.simsek(440, ysec - 14, 1.2)
    c.yazi(250, 70, "bütün sarımlar", "#64748b", 9.5, anchor="middle")
    c.cihaz(600, 30, f"{fnum(h['uy'], 0)} V", "AG faz arası (yükte)", ok=380 <= h["uy"] <= 420)
    c.cihaz(750, 30, f"{fnum(h['u0'], 0)} V", "AG faz arası (boşta)", ok=380 <= h["u0"] <= 420)
    c.yazi(600, 116, f"Çekirdek akısı: anma değerinin %{fnum(b * 100, 1)}'i", "#b91c1c" if b > 1.05 else "#b45309" if b > 1.02 or b < 0.95 else "#15803d", 13, kalin=True)
    c.yazi(600, 140, f"Boşta kayıp ≈ {fnum(h['p0'], 0)} W (anma {fnum(tr['p0'], 0)} W)", "#334155", 11.5)
    c.yazi(600, 160, f"Boşta akım ≈ {fnum(h['i0'], 2)} × anma boşta akımı", "#b91c1c" if h["i0"] > 2 else "#334155", 11.5)
    c.yazi(600, 180, f"Ses: {'+' if h['ses'] >= 0 else '−'}{fnum(abs(h['ses']), 1)} dB", "#334155", 11.5)
    c.yazi(600, 200, f"AG'de kısa devre akımı ≈ {fnum(h['ik'] / 1000, 1)} kA", "#334155", 11.5)
    c.yazi(600, 236, f"Uygun kademe: {iyi + 1} ({fnum(taps[iyi], 2)} kV) → yükte {fnum(hepsi[iyi]['uy'], 0)} V", "#15803d", 12.5, kalin=True)
    c.yazi(600, 260, "Sarım artarsa (üst kademe) AG gerilimi düşer.", "#64748b", 11)
    if enerjili:
        c.yazi(20, 318, "Enerji altında çevirme: kontak açılırken ark oluşur, iki kademe arası sarımlar ark üzerinden kısa devre olur.", "#b91c1c", 12, kalin=True)

    ozet = [
        K("Kademe gerilimi", f"{fnum(u_tap, 2)} kV", "info", f"{no}. kademe · çevirme oranı {fnum(u_tap, 2)} / 0,4 kV"),
        K("AG gerilimi (yükte)", f"{fnum(h['uy'], 0)} V", "ok" if 380 <= h["uy"] <= 420 else "bad", f"boşta {fnum(h['u0'], 0)} V"),
        K("Çekirdek akısı", f"%{fnum(b * 100, 1)}", "bad" if b > 1.05 else "warn" if b > 1.02 or b < 0.95 else "ok", "şebeke gerilimi / kademe gerilimi"),
        K("Boşta kayıp", f"{fnum(h['p0'], 0)} W", "warn" if b > 1.02 else "ok", f"anma {fnum(tr['p0'], 0)} W · boşta akım × {fnum(h['i0'], 2)}"),
        K("Uygun kademe", f"{iyi + 1}", "ok" if iyi == no - 1 else "warn", f"{fnum(taps[iyi], 2)} kV → {fnum(hepsi[iyi]['uy'], 0)} V"),
    ]
    kontroller = [
        C("Aşırı uyarma — yük altında", f"gerilim kademe geriliminin %{fnum(b * 100, 1)}'i", "≤ %105 (anma akımında)" if k > 0.05 else "≤ %110 (boşta)", b <= (1.05 if k > 0.05 else 1.10) + 1e-9,
          "Trafo anma geriliminin %105'inde anma akımını verecek, %110'unda boşta çalışacak biçimde yapılır — " + tr["kaynak"] + (" böl. 2.2.13" if kuru else " böl. 2.2.15"), "resmi"),
        C("AG gerilimi (yükte)", f"{fnum(h['uy'], 0)} V", "400 V ± %5 (trafo uçlarında)", abs(h["uy"] - 400) <= 20, "Tüketicideki ±%10 sınırının bir kısmı AG hattındaki düşüme ayrılır", "ikincil"),
        C("AG gerilimi (boşta, gece)", f"{fnum(h['u0'], 0)} V", "≤ 420 V", h["u0"] <= 420, "Yük kalkınca düşüm de kalkar: gece gerilimi yükte ölçülenden yüksektir", "hesap"),
        C("Seçilen kademe uygun mu?", f"{no}. kademe", f"uygun olan {iyi + 1}. kademe", iyi == no - 1, "Çekirdeği anma akısına en yakın çalıştıran ve AG gerilimini sınırlar içinde tutan kademe", "hesap"),
        C("Kademe enerjisizken mi değiştiriliyor?", "enerji altında" if enerjili else "enerjisiz", "trafo enerjisiz ve topraklanmış", not enerjili,
          "Kademe değiştirici enerjisiz halde çalıştırılır — " + tr["kaynak"] + (" böl. 2.3.3 (bağlantı köprüleri)" if kuru else " böl. 2.3.5") + "; " + (SIEMENS_K if kuru else SGB + " böl. 3.11"), "resmi"),
    ]
    girdiler = tr_girdi(tr) + [
        G("Şebekenin gerçek gerilimi", f"{fnum(u_net, 2)} kV", "OG hücresindeki gerilim ölçüsü, röle ölçüleri; dağıtım şirketi verisi", "Kademe, anma gerilimine değil şebekenin o noktadaki gerçek gerilimine göre seçilir", "akı ∝ U(şebeke) / U(kademe)"),
        G("Kademe gerilimleri", " · ".join(fnum(t, 2) for t in taps) + " kV", "Trafo etiketi; kademe göstergesi", "Her kademenin gerilimi etikette yazar; 1 no.lu kademe en düşük gerilimdir", "U2(boşta) = 400 V × U(şebeke) / U(kademe)"),
        G("Yük ve güç katsayısı", f"%{fnum(k * 100, 0)} · cosφ {fnum(cosf, 2)}", "AG ana pano analizörü", "Yük düşümü boştaki gerilimin üstüne biner", "«Yük altında gerilim» sayfası"),
    ]
    adimlar = [
        A("Çekirdek akısı", "B / Bn = U(şebeke) / U(kademe)", f"{fnum(u_net, 2)} / {fnum(u_tap, 2)}", f"%{fnum(b * 100, 1)}", "sargı gerilimi sarım başına akının değişim hızıdır: sarım azalırsa aynı gerilim daha çok akı ister", "hesap", ["Şebekenin gerçek gerilimi", "Kademe gerilimleri"]),
        A("Boştaki AG gerilimi", "U2 = 400 V × U(şebeke) / U(kademe)", f"400 × {fnum(b, 4)}", f"{fnum(h['u0'], 1)} V", "AG sargısının sarım sayısı değişmez; sarım başına gerilim akıyla orantılıdır", "hesap"),
        A("Yükteki AG gerilimi", "U2 = U2(boşta) − düşüm", f"yük %{fnum(k * 100, 0)}, cosφ {fnum(cosf, 2)}", f"{fnum(h['uy'], 1)} V", "«Yük altında gerilim» sayfasındaki fazör çözümü", "hesap", ["Yük ve güç katsayısı"]),
        A("Boşta kayıp", "P0 ≈ P0n · (B / Bn)²", f"{fnum(tr['p0'], 0)} × {fnum(b, 3)}²", f"{fnum(h['p0'], 0)} W", "çekirdek kaybı akının yaklaşık karesiyle artar — üs çekirdek sacına bağlı", "tahmini", ["Kayıplar"]),
        A("Boşta akım", "I0 ≈ I0n · (B / Bn)^8", f"{fnum(b, 3)}^8", f"{fnum(h['i0'], 2)} × anma", "çekirdek doymaya yaklaştıkça mıknatıslanma akımı hızla büyür — üs tipik", "tahmini"),
    ]
    ayarlar = [
        S("Kademe değiştirici", f"{iyi + 1}. kademe ({fnum(taps[iyi], 2)} kV)", ("28,5 – 30 – 31,5 – 33 – 34,5 – 36 kV" if tr["un"] > 20 else "±2 × %2,5"), "Şebekenin gerçek gerilimine en yakın kademe", tr["kaynak"] + " böl. 2.2.5"),
        S("Ayar sınıfı", "sabit akı (CFVV)", "—", "Kademe ne olursa olsun doğru seçildiğinde çekirdek anma akısında çalışır", tr["kaynak"] + " böl. 2.2.5"),
        S("Kademe değiştirme sırası", "aç → topraklama → çevir → kilitle → ölç", "—", "Kol tam yuvasına oturmalı; ara konumda bırakılan kademe sargıyı açık devre eder", SGB + " böl. 3.11"),
        S("Aşırı uyarma koruması (24, V/Hz)", "≈ 1,05–1,10 pu", "röleye göre", "Dağıtım trafolarında seyrek kullanılır; aşırı gerilim rölesi (59) aynı işi görür", "Röle laboratuvarı › Aşırı uyarma sayfası", "ikincil"),
    ]
    test = [
        T("Çevirme oranı", "Her kademede oran ölçer ile (TTR)", " · ".join(fnum(t / 0.4, 2) for t in taps), "tolerans ±%0,5 (ana kademede)"),
        T("Sargı direnci", "Kademe değiştirildikten sonra üç fazda", "üç faz birbirine yakın; önceki ölçüyle uyumlu", "kontak tam oturmadıysa bir fazın direnci yüksek çıkar"),
        T("AG gerilimi", "Enerjilendikten sonra, yüksüz ve yükte", f"boşta ≈ {fnum(hepsi[iyi]['u0'], 0)} V, yükte ≈ {fnum(hepsi[iyi]['uy'], 0)} V ({iyi + 1}. kademede)", "gece ve gündüz ayrı ölçülür"),
    ]
    xs = list(range(1, len(taps) + 1))
    g1 = {"baslik": "Kademeye göre AG gerilimi", "x_ad": "Kademe", "y_ad": "AG faz arası gerilim (V)",
          "seriler": [{"ad": "boşta", "renk": "#1a4d8f", "pts": pts(xs, [x["u0"] for x in hepsi], 1)}, {"ad": "yükte", "renk": "#dc2626", "pts": pts(xs, [x["uy"] for x in hepsi], 1)}],
          "yatay": [{"y": 420, "etiket": "+%5", "renk": "#d97706"}, {"y": 400, "etiket": "400 V", "renk": "#94a3b8"}, {"y": 380, "etiket": "−%5", "renk": "#d97706"}], "isaretler": [{"x": no, "etiket": "seçili"}]}
    bs = [0.9 + j * 0.01 for j in range(0, 26)]
    g2 = {"baslik": "Aşırı uyarmanın bedeli (akıya göre)", "x_ad": "Akı (% anma)", "y_ad": "anma değerinin katı",
          "seriler": [{"ad": "boşta kayıp", "renk": "#b45309", "pts": pts([x * 100 for x in bs], [x * x for x in bs], 3)}, {"ad": "boşta akım", "renk": "#dc2626", "pts": pts([x * 100 for x in bs], [x ** 8 for x in bs], 3)}],
          "isaretler": [{"x": b * 100, "etiket": "şimdi"}, {"x": 105, "etiket": "%105"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Kademe değiştirici YG sargısının kaç sarımının devrede olacağını seçer. AG sargısının sarım sayısı sabittir; çevirme oranı YG sarımıyla değişir.",
            f"Şebeke {fnum(u_net, 2)} kV, seçili kademe {fnum(u_tap, 2)} kV. Sarım başına düşen gerilim, yani çekirdeğin akısı, anma değerinin %{fnum(b * 100, 1)}'i.",
            ("Kademe gerilimi şebekeden düşük: az sarım aynı gerilimi taşımak için daha çok akı ister. Çekirdek doymaya yaklaşır; boşta kayıp, boşta akım ve ses artar, AG gerilimi yükselir."
             if b > 1.02 else "Kademe gerilimi şebekeden yüksek: akı azalır, çekirdek rahattır ama AG gerilimi düşük kalır." if b < 0.98 else "Kademe gerilimi şebekeye uygun: çekirdek anma akısında çalışıyor."),
            f"Boşta AG gerilimi {fnum(h['u0'], 0)} V; %{fnum(k * 100, 0)} yükte trafonun iç düşümüyle {fnum(h['uy'], 0)} V'a iniyor. Gece yük kalkınca gerilim boştaki değere çıkar.",
            "Üst kademeye geçmek (daha çok sarım) AG gerilimini düşürür; alt kademeye geçmek yükseltir. Ezberi: «AG gerilimi yüksekse kademeyi yükselt».",
            ("Enerji altında çevirme: seçici kontak yük akımını keserken ark oluşur. Kontak iki kademe ucuna aynı anda değdiği anda aradaki sarımlar kısa devre olur ve içlerinden anma akımının onlarca katı dolaşır. "
             "Yağlı trafoda ark yağı ayrıştırır, gaz ve basınç oluşur; kuru tipte bağlantı köprüsü elde kalır. Bu kademe değiştirici akım kesmek için yapılmamıştır."
             if enerjili else "Bu kademe değiştirici akım kesemez: yalnız trafo enerjisiz ve topraklanmışken çevrilir. Yük altında kademe değiştirici (OLTC) ayrı bir cihazdır ve dağıtım trafolarında bulunmaz."),
        ],
        "dersler": [
            "Kademe, etiketteki anma gerilimine göre değil şebekenin o noktadaki gerçek gerilimine göre seçilir. 34,5 kV şebekede 33 kV kademesi %4,5 aşırı uyarmadır.",
            "AG gerilimi yüksekse kademe yükseltilir (sarım artar), düşükse düşürülür.",
            "Aşırı uyarılan trafo boştayken bile fazla kayıp harcar, daha çok uğuldar ve demerajı büyür.",
            "Kademe enerji altında çevrilmez. Çevrildikten sonra oran ve sargı direnci ölçülür: tam oturmayan kontak ısınır.",
            "Kademe değiştirici yükle değişen düşümü izlemez; şebeke geriliminin kalıcı sapmasını bir kez düzeltir.",
        ],
        "tablolar": [{"baslik": f"Bütün kademeler (şebeke {fnum(u_net, 2)} kV, yük %{fnum(k * 100, 0)})", "cols": ["Kademe", "Kademe gerilimi", "Akı", "AG boşta", "AG yükte", "Boşta kayıp", "Değerlendirme"],
                      "rows": [[f"{j + 1}" + (" ◀" if j == no - 1 else ""), f"{fnum(t, 2)} kV", f"%{fnum(x['b'] * 100, 1)}", f"{fnum(x['u0'], 0)} V", f"{fnum(x['uy'], 0)} V", f"{fnum(x['p0'], 0)} W",
                                "aşırı uyarma" if x["b"] > 1.05 else "uygun" if j == iyi else "AG yüksek" if x["uy"] > 420 else "AG düşük" if x["uy"] < 380 else "kullanılabilir"] for j, (t, x) in enumerate(zip(taps, hepsi))],
                      "not": "1 no.lu kademe en küçük sarım sayısıdır (TEDAŞ-MLZ/99-032.E böl. 2.3.5): aynı şebeke geriliminde en yüksek AG gerilimini verir."}],
    }
