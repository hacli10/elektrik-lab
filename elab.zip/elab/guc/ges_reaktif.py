"""GES'te reaktif güç: eviricinin P–Q yeteneği (görünür güç çemberi), gündüz reaktif çekerek gerilimi tutma, gece — eviriciler dururken — OG kablosunun kapasitif ve trafonun
endüktif reaktif gücünün sayaca yazılması; şönt reaktör ve eviricinin gece reaktif desteği.

Hesap: S² = P² + Q²; trafo boşta reaktifi Q0 ≈ i0·Sn (boşta akım %0,8 alındı — tahmini), yükte Qk = uk·(S/Sn)²·Sn; kablo Qc = ω·C·U²·L (kapasite katalog mertebesi — tahmini).
Trafo kayıpları ve uk: TEDAŞ-MLZ/99-032.E (metinden). Aylık reaktif / aktif enerji oranı sınırları (endüktif %20, kapasitif %15) tarife uygulamasından bellekle yazıldı; asıl
metinle doğrulanmadı (dogrulanacak). Eviricinin reaktif güç aralığı (cosφ 0,8 endüktif – 0,8 kapasitif) tipik veri sayfası değeridir (tahmini)."""
from __future__ import annotations

import math

from . import kablo as KB
from .ortak import A, C, G, K, S, T, TEDAS_H, Cizim, ctl, fnum, guc_sec, lin, num, opt, pts, trafo

ID = "ges_reaktif"
BASLIK = "GES'te reaktif güç ve gece cezası"
IKON = "🌙"
GIRIS = ("Santral gündüz aktif güç satar; gece hiçbir şey üretmez ama şebekeye bağlı kalır. OG kablosu bir kondansatör, trafo bir bobindir: ikisi de gece boyunca reaktif güç alışverişi yapar "
         "ve sayaç bunu, neredeyse sıfır olan aktif tüketime oranlar. Kablo boyunu, reaktörü ve eviricinin çalışma biçimini değiştirin; oranın nasıl fırladığını ve nasıl düzeldiğini izleyin.")

I0 = 0.8                 # % — trafonun boşta akımı (mertebe)
SINIR_END, SINIR_KAP = 20.0, 15.0
T_GECE, T_GUN = 11.0, 13.0          # saat / gün

KONTROLLER = [
    ctl("s_ev", "Eviricilerin toplam görünür gücü", "sayi", 1000, min=50, max=2500, adim=50, birim="kVA"),
    ctl("p_gun", "Gündüz üretim", "sayi", 80, min=0, max=100, adim=5, birim="% S"),
    ctl("mod", "Eviricinin reaktif güç çalışması", "sec", "cos1", secenek=opt(("cos1", "cosφ = 1 (reaktif yok)"), ("cos", "Sabit cosφ, endüktif (gerilimi düşürmek için reaktif çeker)"),
                                                                              ("gece", "cosφ = 1 + gece reaktif desteği (evirici gece de devrede)"))),
    ctl("cos", "Ayarlanan cosφ", "sayi", 0.95, min=0.8, max=1.0, adim=0.01, goster={"mod": ["cos"]}),
    ctl("sn", "Trafo gücü", "sec", 1250, secenek=guc_sec()),
    ctl("l", "OG kablo boyu (santral – bağlantı noktası)", "sayi", 1.5, min=0, max=15, adim=0.1, birim="km"),
    ctl("s", "OG kablo kesiti", "sec", 95, secenek=opt(*[(k, f"{k} mm²") for k in KB.OG_KESIT])),
    ctl("ic", "Gece iç ihtiyaç (aydınlatma, kamera, izleme)", "sayi", 3.0, min=0.2, max=30, adim=0.2, birim="kW"),
    ctl("reaktor", "Şönt reaktör", "sayi", 0, min=0, max=600, adim=5, birim="kvar"),
    ctl("sayac", "Sayacın yeri", "sec", "og", secenek=opt(("og", "Bağlantı noktasında (kablo sayacın santral tarafında)"), ("tm", "Santral trafo merkezinde (kablo sayacın şebeke tarafında)"))),
]


def run(p: dict) -> dict:
    s_ev, p_y, mod, cosf, sn, l, kes = num(p, "s_ev", 1000), num(p, "p_gun", 80), str(p.get("mod", "cos1")), num(p, "cos", 0.95), num(p, "sn", 1250), num(p, "l", 1.5), int(num(p, "s", 95))
    ic, rea, sayac = num(p, "ic", 3.0), num(p, "reaktor", 0), str(p.get("sayac", "og"))
    kes = kes if kes in KB.OG_KESIT else 95
    tr = trafo("hermetik", sn, 33.0)
    un = 34.5
    q0 = I0 / 100 * sn                                              # kvar, endüktif
    qc_km = 100 * math.pi * KB.OG_C[kes] * 1e-6 * (un * 1000) ** 2 / 1000          # kvar / km
    qc = qc_km * l if sayac == "og" else 0.0
    # ---- gündüz ----
    p_ist = p_y / 100 * s_ev
    q_ist = p_ist * math.tan(math.acos(cosf)) if mod == "cos" else 0.0           # evirici çeker (endüktif)
    s_ist = math.hypot(p_ist, q_ist)
    p_ev = p_ist if s_ist <= s_ev else math.sqrt(max(s_ev ** 2 - q_ist ** 2, 0.0))
    kisinti = p_ist - p_ev
    s_gun = math.hypot(p_ev, q_ist)
    qk = tr["ux"] / 100 * (s_gun / sn) ** 2 * sn
    pk = tr["pk"] / 1000 * (s_gun / sn) ** 2
    p_gunduz = p_ev - pk - tr["p0"] / 1000                                         # kW — şebekeye verilen
    q_gunduz = q0 + qk + q_ist + rea - qc                                           # kvar — artı: şebekeden çekilen (endüktif)
    cos_pcc = abs(p_gunduz) / math.hypot(p_gunduz, q_gunduz) if p_gunduz > 0 else 0.0
    # ---- gece ----
    p_gece = tr["p0"] / 1000 + ic                                                   # kW çekiş
    q_ic = ic * math.tan(math.acos(0.9))
    q_ham = q0 + q_ic + rea - qc                                                    # evirici desteği olmadan
    q_evg = 0.0
    if mod == "gece":
        q_evg = max(min(-q_ham, s_ev), -s_ev)                                       # evirici farkı kapatır (görünür gücü içinde)
        p_gece += 0.004 * s_ev                                                      # eviricinin gece çalışma kaybı (≈ %0,4)
    q_gece = q_ham + q_evg
    oran_end = max(q_gece, 0) / p_gece * 100
    oran_kap = max(-q_gece, 0) / p_gece * 100
    e_p = p_gece * T_GECE * 30; e_q = abs(q_gece) * T_GECE * 30
    rea_oneri = max(-(q0 + q_ic - qc), 0.0)
    ceza = oran_end > SINIR_END or oran_kap > SINIR_KAP
    cz = Cizim(900, 320)
    cz.kutu(20, 60, 100, 54, "Şebeke", "34,5 kV")
    cz.dikdortgen(138, 74, 26, 26, "mor", "#f5f3ff"); cz.yazi(151, 66, "sayaç" if sayac == "og" else "", "#6d28d9", 10, kalin=True, anchor="middle")
    cz.hat("M120,87 H138", "L1", hot=True, w=3); cz.hat("M164,87 H400", "L1", hot=True, w=3 if l > 0 else 2)
    for k in range(4):
        cz.kap(210 + k * 50, 90, 112, "mavi")
    cz.hat("M190,112 H380", "toprak", w=1.5, kesik=True)
    cz.yazi(285, 76, f"OG kablosu {fnum(l, 1)} km · {fnum(qc_km * l, 0)} kvar kapasitif", "#1d4ed8", 11, kalin=True, anchor="middle")
    if sayac == "tm":
        cz.dikdortgen(402, 74, 26, 26, "mor", "#f5f3ff"); cz.yazi(415, 66, "sayaç", "#6d28d9", 10, kalin=True, anchor="middle")
    cz.hat("M400,87 H470", "L1", hot=True, w=3)
    if rea > 0:
        cz.hat("M445,87 V118", "cizgi", w=2); cz.bobin(445, 120, ad=f"{fnum(rea, 0)} kvar"); cz.toprak(445, 156)
    cz.sarim(500, 87, "ucgen"); cz.sarim(548, 87, "yildiz")
    cz.yazi(524, 46, f"{fnum(sn, 0)} kVA · boşta {fnum(q0, 0)} kvar", "#334155", 11, kalin=True, anchor="middle")
    cz.hat("M578,87 H660", "L1", hot=True, w=3)
    cz.kutu(660, 60, 150, 54, "Eviriciler", f"{fnum(s_ev, 0)} kVA", "vurgu" if mod == "gece" else "normal")
    cz.yazi(40, 190, f"Gündüz: şebekeye {fnum(p_gunduz, 0)} kW · reaktif {fnum(abs(q_gunduz), 0)} kvar {'çekiyor (endüktif)' if q_gunduz >= 0 else 'veriyor (kapasitif)'} · cosφ {fnum(cos_pcc, 3)}", "#334155", 12.5, kalin=True)
    cz.yazi(40, 214, (f"Evirici görünür gücü doldu: aktif güç {fnum(kisinti, 0)} kW kısıldı" if kisinti > 0.5 else f"Evirici: {fnum(p_ev, 0)} kW + {fnum(q_ist, 0)} kvar = {fnum(s_gun, 0)} kVA (%{fnum(s_gun / s_ev * 100, 0)})"),
            "#b91c1c" if kisinti > 0.5 else "#64748b", 12)
    cz.yazi(40, 244, f"Gece: {fnum(p_gece, 1)} kW çekiyor · reaktif {fnum(abs(q_gece), 0)} kvar {'endüktif' if q_gece >= 0 else 'kapasitif'}", "#1d4ed8", 12.5, kalin=True)
    cz.yazi(40, 268, f"Gece oranı: endüktif %{fnum(oran_end, 0)} (sınır %{fnum(SINIR_END, 0)}) · kapasitif %{fnum(oran_kap, 0)} (sınır %{fnum(SINIR_KAP, 0)})", "#b91c1c" if ceza else "#15803d", 13, kalin=True)
    cz.yazi(40, 292, (f"Gece dengesi için ≈ {fnum(rea_oneri, 0)} kvar reaktör ya da eviricinin gece desteği gerekir" if ceza and q_gece < 0 else "Reaktör fazla: endüktife geçildi" if ceza else "Gece reaktif alışverişi sınırların içinde"),
            "#b45309" if ceza else "#64748b", 12)
    ozet = [
        K("Gece reaktif gücü", f"{fnum(abs(q_gece), 0)} kvar {'endüktif' if q_gece >= 0 else 'kapasitif'}", "bad" if ceza else "ok", f"aktif çekiş {fnum(p_gece, 1)} kW"),
        K("Gece reaktif oranı", f"%{fnum(max(oran_end, oran_kap), 0)}", "bad" if ceza else "ok", f"sınır: endüktif %{fnum(SINIR_END, 0)} · kapasitif %{fnum(SINIR_KAP, 0)}"),
        K("Kablonun kapasitif gücü", f"{fnum(qc_km * l, 0)} kvar", "info", f"{fnum(qc_km, 0)} kvar/km" + ("" if sayac == "og" else " · sayacın şebeke tarafında")),
        K("Gündüz bağlantı noktası", f"cosφ {fnum(cos_pcc, 3)}", "info", f"{fnum(p_gunduz, 0)} kW · {fnum(q_gunduz, 0)} kvar"),
        K("Evirici yüklenmesi", f"%{fnum(s_gun / s_ev * 100, 0)}", "bad" if kisinti > 0.5 else "ok", f"{fnum(p_ev, 0)} kW + {fnum(q_ist, 0)} kvar"),
    ]
    kontroller = [
        C("Gece kapasitif reaktif oranı", f"%{fnum(oran_kap, 0)}", f"≤ %{fnum(SINIR_KAP, 0)} (aylık kapasitif reaktif / aktif enerji)", oran_kap <= SINIR_KAP,
          "Gece aktif çekiş yalnız trafo boşta kaybı ve iç ihtiyaçtır; kablonun kapasitif gücü buna oranlanınca oran yüzlerce yüzdeye çıkar. Sınır değeri asıl metinle doğrulanacak", "dogrulanacak"),
        C("Gece endüktif reaktif oranı", f"%{fnum(oran_end, 0)}", f"≤ %{fnum(SINIR_END, 0)} (aylık endüktif reaktif / aktif enerji)", oran_end <= SINIR_END,
          "Kablo kısaysa ya da reaktör fazlaysa trafonun boşta reaktifi baskın kalır ve oran endüktif yönde aşılır. Sınır değeri asıl metinle doğrulanacak", "dogrulanacak"),
        C("Eviricinin görünür gücü istenen aktif ve reaktif güce yetiyor mu?", f"√({fnum(p_ist, 0)}² + {fnum(q_ist, 0)}²) = {fnum(s_ist, 0)} kVA", f"≤ {fnum(s_ev, 0)} kVA", s_ist <= s_ev + 0.01,
          "Evirici akımla sınırlıdır: reaktif güç verirken aktif güce kalan pay küçülür. Tam üretimde cosφ 0,95 istenirse aktif güç kısılır ya da evirici %5 büyük seçilir", "hesap"),
        C("Gündüz trafonun çektiği reaktif güç", f"{fnum(q0 + qk, 0)} kvar (boşta {fnum(q0, 0)} + yükte {fnum(qk, 0)})", f"≈ %{fnum((q0 + qk) / max(s_gun, 1) * 100, 1)} × S", None,
          f"Yükte reaktif tüketim uk ile orantılıdır: uk %{fnum(tr['uk'], 1)} — {TEDAS_H} böl. 2.2.9", "resmi"),
        C("Şönt reaktör gece dengesine uygun mu?", f"{fnum(rea, 0)} kvar" if rea > 0 else "yok", f"≈ {fnum(rea_oneri, 0)} kvar (kablo − trafo boşta − iç ihtiyaç)", (not ceza) if (rea > 0 or ceza) and mod != "gece" else None,
          f"Denge penceresi dardır: gece aktif çekiş {fnum(p_gece, 1)} kW olduğu için net reaktif −{fnum(SINIR_KAP / 100 * p_gece, 1)} … +{fnum(SINIR_END / 100 * p_gece, 1)} kvar arasında kalmalıdır. Sabit reaktörle tutturmak zordur; ayarlı reaktör (SVG) ya da evirici desteği bunu çözer", "ikincil"),
    ]
    girdiler = [
        G("Trafo", f"{fnum(sn, 0)} kVA · uk %{fnum(tr['uk'], 1)} · P0 {fnum(tr['p0'], 0)} W", "Trafo etiketi ve deney raporu (boşta akım)", "Boşta ve yükte çektiği reaktif güç", f"Q0 ≈ i0 · Sn = %{fnum(I0, 1)} × {fnum(sn, 0)} = {fnum(q0, 0)} kvar"),
        G("OG kablosu", f"{fnum(l, 1)} km · 3 × 1 × {kes} mm² XLPE", "Proje; kablo veri sayfası (kapasite)", "Sürekli kapasitif reaktif güç üretir", f"Qc = ω·C·U² = {fnum(qc_km, 0)} kvar/km"),
        G("Gece aktif çekiş", f"{fnum(p_gece, 1)} kW", "Sayaç gece endeksleri", "Oranın paydası: küçüldükçe oran büyür", f"trafo boşta kaybı {fnum(tr['p0'] / 1000, 2)} kW + iç ihtiyaç {fnum(ic, 1)} kW"),
        G("Sayacın yeri", "bağlantı noktası" if sayac == "og" else "santral trafo merkezi", "Bağlantı anlaşması; tek hat şeması", "Kablonun reaktifinin kimin sayacına yazıldığını belirler", "kablo sayacın santral tarafındaysa santralin hanesine yazılır"),
    ]
    adimlar = [
        A("Kablonun kapasitif gücü", "Qc = ω · C · U² · L", f"314 × {fnum(KB.OG_C[kes], 2)} µF/km × 34,5² kV × {fnum(l, 1)} km", f"{fnum(qc_km * l, 0)} kvar", "yükten bağımsız, gece gündüz", "hesap", ["OG kablosu"]),
        A("Trafonun boşta reaktifi", "Q0 ≈ i0 · Sn", f"%{fnum(I0, 1)} × {fnum(sn, 0)} kVA", f"{fnum(q0, 0)} kvar endüktif", "çekirdeği mıknatıslamak için", "tahmini", ["Trafo"]),
        A("Gece reaktif dengesi", "Q = Q0 + Q(iç ihtiyaç) + Q(reaktör) − Qc + Q(evirici)", f"{fnum(q0, 0)} + {fnum(q_ic, 1)} + {fnum(rea, 0)} − {fnum(qc, 0)} + ({fnum(q_evg, 0)})", f"{fnum(abs(q_gece), 0)} kvar {'endüktif' if q_gece >= 0 else 'kapasitif'}", "artı: endüktif", "hesap"),
        A("Gece oranı", "oran = Q / P", f"{fnum(abs(q_gece), 0)} kvar / {fnum(p_gece, 1)} kW", f"%{fnum(max(oran_end, oran_kap), 0)}", "aylık enerjilerle aynı oran", "hesap", ["Gece aktif çekiş"]),
        A("Aylık gece enerjileri", "E = P · t · 30", f"{fnum(T_GECE, 0)} saat / gün", f"{fnum(e_p, 0)} kWh · {fnum(e_q, 0)} kvarh", "gündüz veriş yönündeki enerji ayrı hanede tutulur", "hesap"),
        A("Eviricinin yeteneği", "S² = P² + Q²", f"P = {fnum(p_ev, 0)} kW · Q = {fnum(q_ist, 0)} kvar", f"{fnum(s_gun, 0)} kVA / {fnum(s_ev, 0)} kVA", "tam üretimde kalan reaktif pay √(S² − P²)", "hesap"),
        A("Trafonun yükte reaktifi", "Qk = ux · (S / Sn)² · Sn", f"%{fnum(tr['ux'], 2)} × ({fnum(s_gun, 0)} / {fnum(sn, 0)})² × {fnum(sn, 0)}", f"{fnum(qk, 0)} kvar", "akımın karesiyle", "hesap"),
    ]
    ayarlar = [
        S("Şönt reaktör", f"≈ {fnum(rea_oneri, 0)} kvar" if rea_oneri > 1 else "gerekmez", "sabit / kademeli / ayarlı", "Kablonun kapasitif gücünü yerinde tüketir", "saha pratiği", "ikincil"),
        S("Evirici › gece reaktif desteği", "açık" if mod == "gece" else "kapalı", f"±{fnum(s_ev, 0)} kvar'a kadar", "Evirici gece DC barasını şebekeden besleyerek reaktif üretir / tüketir; küçük bir aktif kayıp getirir", "evirici kılavuzu", "ikincil"),
        S("Evirici › cosφ / Q(U)", f"cosφ {fnum(cosf, 2)} endüktif" if mod == "cos" else "cosφ = 1", "tipik 0,8 end. – 0,8 kap.", "Gündüz gerilim yükselmesini azaltır — Kablo boyu › GES'te kablo boyu", "evirici veri sayfası", "tahmini"),
        S("Santral denetleyicisi (PPC)", "bağlantı noktasındaki ölçüye göre eviricilere Q hedefi", "—", "Kablo ve trafonun reaktifini bağlantı noktasında sıfırlar", "saha pratiği", "ikincil"),
        S("Reaktif güç rölesi / sayaç izleme", "gece endekslerinin aylık oranı", "—", "Ceza ay sonunda değil, ilk hafta görülür", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Gece sayaç endeksleri", "Eviriciler dururken aktif, endüktif ve kapasitif endeks farkları", f"aktif ≈ {fnum(p_gece, 1)} kW · reaktif ≈ {fnum(abs(q_gece), 0)} kvar {'endüktif' if q_gece >= 0 else 'kapasitif'}", "bir gecelik fark aylık oranı verir"),
        T("Kablo şarj akımı", "Santral trafosu açıkken OG fider akımı", f"≈ {fnum(qc_km * l / (math.sqrt(3) * un), 1)} A", "Kablo boyu › OG kablo boyu"),
        T("Reaktör devredeyken", "Bağlantı noktasında analizör", "reaktif güç sıfıra yakın, cosφ ≈ 1", "reaktör akımı ≈ " + fnum(rea / (math.sqrt(3) * un), 1) + " A"),
    ]
    aci = lin(-90, 90, 37)
    g1 = {"baslik": "Eviricinin P–Q yeteneği", "x_ad": "Reaktif güç (kvar) — artı: endüktif (çeker)", "y_ad": "Aktif güç (kW)", "ymin": 0,
          "seriler": [{"ad": "görünür güç sınırı", "renk": "#94a3b8", "pts": [[round(s_ev * math.sin(math.radians(q)), 1), round(s_ev * math.cos(math.radians(q)), 1)] for q in aci]},
                      {"ad": "gündüz çalışma noktası", "renk": "#dc2626", "nokta": True, "pts": [[round(q_ist, 1), round(p_ev, 1)]]},
                      {"ad": "gece çalışma noktası", "renk": "#1d4ed8", "nokta": True, "pts": [[round(q_evg, 1), 0.0]]}]}
    ls = lin(0, 15, 31)
    g2 = {"baslik": "Kablo boyuna göre gece reaktif gücü (evirici desteği olmadan)", "x_ad": "OG kablo boyu (km)", "y_ad": "Reaktif güç (kvar) — eksi: kapasitif",
          "seriler": [{"ad": "gece net reaktif", "renk": "#1d4ed8", "pts": pts(ls, [q0 + q_ic + rea - qc_km * q * (1 if sayac == "og" else 0) for q in ls], 1)}],
          "yatay": [{"y": SINIR_END / 100 * (tr["p0"] / 1000 + ic), "etiket": "endüktif sınır", "renk": "#b45309"}, {"y": -SINIR_KAP / 100 * (tr["p0"] / 1000 + ic), "etiket": "kapasitif sınır", "renk": "#b45309"}],
          "isaretler": [{"x": l, "etiket": "boy"}]}
    rows = [["Trafo — boşta", f"+{fnum(q0, 0)}", f"+{fnum(q0, 0)}"], ["Trafo — yükte", f"+{fnum(qk, 0)}", "0"], ["OG kablosu", f"−{fnum(qc, 0)}", f"−{fnum(qc, 0)}"],
            ["İç ihtiyaç", "≈ 0", f"+{fnum(q_ic, 1)}"], ["Şönt reaktör", f"+{fnum(rea, 0)}", f"+{fnum(rea, 0)}"], ["Evirici", f"+{fnum(q_ist, 0)}", fnum(q_evg, 0)],
            ["Net (sayaçta)", fnum(q_gunduz, 0), fnum(q_gece, 0)], ["Aktif güç (kW)", f"{fnum(p_gunduz, 0)} veriş", f"{fnum(p_gece, 1)} çekiş"]]
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Reaktif güç iş yapmaz ama akım olarak hatlardan geçer; bu yüzden dağıtım şirketi onu sayar ve aktif enerjiye oranlar. Tüketim tesislerinde bu oran kompanzasyon panosuyla tutulur. Güneş santralinde sorun başka bir yerden çıkar: geceden.",
            f"Güneş battığında eviriciler durur ama santral şebekeye bağlı kalır. Trafo enerjilidir ve çekirdeğini mıknatıslamak için {fnum(q0, 0)} kvar endüktif güç çeker. OG kablosu enerjilidir ve — iletkeni ile ekranı arasındaki kapasite yüzünden — {fnum(qc_km * l, 0)} kvar kapasitif güç üretir ({fnum(qc_km, 0)} kvar/km).",
            f"Aktif tüketim ise neredeyse yoktur: trafonun boşta kaybı ve birkaç kilovatlık iç ihtiyaç, toplam {fnum(p_gece, 1)} kW. Sayaç {fnum(abs(q_gece), 0)} kvar'ı bu küçük sayıya böler: %{fnum(max(oran_end, oran_kap), 0)}. "
            + ("Sınırın çok üstünde: her ay reaktif bedel faturalanır. Santralin hiçbir kusuru yoktur; yalnızca paydası küçüktür." if ceza else "Sınırların içinde."),
            (f"Çarelerden biri şönt reaktördür: kablonun ürettiği kapasitif gücü yerinde tüketen bir bobin. Burada ≈ {fnum(rea_oneri, 0)} kvar gerekir. Sabit reaktör gündüz de devrededir ve üretim sırasında trafonun reaktifine eklenir; bu yüzden büyük santrallerde kademeli ya da sürekli ayarlı çözümler seçilir."
             if rea_oneri > 1 else "Bu santralde kablo kısa: trafonun endüktif gücü kablonun kapasitif gücünü zaten karşılıyor; reaktöre gerek yok."),
            (f"Öbür çare eviricinin kendisidir. Evirici gece de şebekeye bağlı kalır, DC barasını şebekeden besler ve bir reaktör ya da kondansatör gibi çalışır: burada {fnum(abs(q_evg), 0)} kvar {'tüketerek' if q_evg > 0 else 'üreterek'} dengeyi sıfırlıyor. Bedeli küçük bir aktif kayıp ve eviricinin gece de çalışmasıdır."
             if mod == "gece" else "Öbür çare eviricinin gece reaktif desteğidir: evirici gece de şebekeye bağlı kalır ve bir reaktör ya da kondansatör gibi çalışır. Ek donanım gerektirmez; «Eviricinin reaktif güç çalışması» ayarından deneyin."),
            (f"Gündüz evirici reaktif güç de taşıyabilir, ama sınırsız değil. Evirici akımla sınırlıdır: aktif ve reaktif gücün kareleri toplamı görünür gücün karesini aşamaz. cosφ {fnum(cosf, 2)} ile {fnum(p_ist, 0)} kW istenince "
             + (f"görünür güç {fnum(s_ist, 0)} kVA'ya çıkar ve evirici aktif gücü {fnum(kisinti, 0)} kW kısar." if kisinti > 0.5 else f"evirici {fnum(s_gun, 0)} kVA ile çalışır (%{fnum(s_gun / s_ev * 100, 0)}).")
             if mod == "cos" else f"Gündüz evirici cosφ = 1 ile çalışıyor; bağlantı noktasında yine de {fnum(abs(q_gunduz), 0)} kvar reaktif görülür — trafo ve kablo yüzünden."),
            ("Sayacın yeri sonucu değiştirir. Sayaç santral trafo merkezindeyse kablo sayacın şebeke tarafında kalır ve kapasitif gücü santralin hanesine yazılmaz; bağlantı noktasındaysa yazılır." if sayac == "tm"
             else "Sayaç bağlantı noktasında olduğu için kablonun kapasitif gücü santralin hanesine yazılıyor. Kablo ne kadar uzunsa sorun o kadar büyür."),
        ],
        "dersler": [
            "Gece sorunu oranın paydasıdır: aktif tüketim küçük, kablo ve trafonun reaktifi sabittir.",
            "34,5 kV XLPE kablo kilometre başına 60–90 kvar kapasitif güç üretir; trafo boşta anma gücünün ≈ %1'i kadar endüktif çeker.",
            "Çare: şönt reaktör ya da eviricinin gece reaktif desteği.",
            "Evirici S² = P² + Q² ile sınırlıdır: tam üretimde reaktif güç aktif güçten yer.",
            "Sayacın yeri, kablonun reaktifinin kimin hanesine yazıldığını belirler.",
        ],
        "tablolar": [{"baslik": "Reaktif güç bileşenleri (kvar; artı: endüktif — şebekeden çekilen)", "cols": ["Bileşen", "Gündüz", "Gece"], "rows": rows,
                      "not": "Trafonun boşta akımı %0,8 ve kablo kapasitesi katalog mertebesidir; gerçek değerler deney raporundan ve kablo veri sayfasından alınır. Reaktif oran sınırları asıl metinle doğrulanacaktır."}],
    }
