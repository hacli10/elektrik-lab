"""Yürüyen dalga, parafudr ve yalıtım koordinasyonu: havai hattan gelen yıldırım dalgası parafudrda kırpılır, ama parafudr ile trafo arasındaki yolda yansıyarak
yeniden büyür. Parafudrun yeri, bağlantı iletkeninin boyu ve kablo girişi trafonun gördüğü gerilimi belirler.

Model: tek fazlı yürüyen dalga benzetimi (karakteristikler yöntemi). Gelen dalga dik cepheli rampa; hat dalga empedansı 450 Ω, 300 m/µs; kablo 35 Ω, 160 m/µs; parafudr
parçalı doğrusal V–I eğrisi (10 kA'da artık gerilim = seçilen oran × Ur) ve seri bağlantı endüktansı (1 µH/m); trafo ucu 1 nF kapasiteyle sonlanır (tahmini mertebeler).

Dayanak (metinden): TEDAŞ-MLZ/96-019.B YG parafudr şartnamesi — Tablo-4 (korunacak teçhizatın yıldırım darbe dayanımı 60/75/95/170 kV-tepe; kısa devre 16 kA 1 s),
Tablo-5/6 (anma boşalma akımı: dağıtım sınıfı DH 10 kA, DM 5 kA; trafo merkezi sınıfı SL 10 kA), Tablo-7 (Ur ve Uc: doğrudan topraklı 6/10/15/30 ve 5/8/12/24 kV; direnç
üzerinden topraklı 7/12/18/36 ve 6/10/15/28,8 kV), Tablo-8 (yıldırım darbesi artık gerilimi 2,3–3,6 × Ur). En küçük hava açıklıkları: Siemens GEAFOL kılavuzu böl. 6.6-6.7.
Koruma payı (≥ 1,2) yaygın uygulamadır; IEC 60071-2 emniyet katsayıları görülmedi (ikincil)."""
from __future__ import annotations

import math
from collections import deque

from .ortak import A, C, G, K, S, T, Cizim, ctl, fnum, num, opt, pts

ID = "yuruyen"
BASLIK = "Yürüyen dalga ve parafudr"
IKON = "🌩️"
GIRIS = ("Yıldırım dalgası hat boyunca ışık hızına yakın bir hızla yürür ve açık uca (trafoya) çarptığında iki katına çıkar. Parafudr dalgayı kendi bulunduğu yerde kırpar; "
         "trafoya kadar kalan her metre, kırpılmış dalganın yeniden büyümesi için zamandır. Parafudru uzaklaştırın, bağlantı iletkenini uzatın, kablo girişi yapın: trafonun gördüğü gerilimi izleyin.")

PF = "TEDAŞ-MLZ/96-019.B (YG parafudr şartnamesi)"
UM = (7.2, 12.0, 17.5, 36.0)
UN = dict(zip(UM, (6.3, 10.5, 15.8, 34.5)))
BIL = dict(zip(UM, (60.0, 75.0, 95.0, 170.0)))
AC = dict(zip(UM, (20.0, 28.0, 38.0, 70.0)))
UR = {"direkt": dict(zip(UM, (6.0, 10.0, 15.0, 30.0))), "direnc": dict(zip(UM, (7.0, 12.0, 18.0, 36.0)))}
UC = {"direkt": dict(zip(UM, (5.0, 8.0, 12.0, 24.0))), "direnc": dict(zip(UM, (6.0, 10.0, 15.0, 28.8)))}
ACIKLIK = {12.0: "120 mm (LI 75 kV)", 36.0: "320 mm (LI 170 kV)"}
Z_HAT, V_HAT, Z_KABLO, V_KABLO = 450.0, 300.0, 35.0, 160.0
C_TRAFO = 0.001                    # µF
L_BAG = 1.0                         # µH/m
# parafudr V–I eğrisi: (akım kA, gerilim / artık gerilim)
VI = [(0.0, 0.0), (1e-6, 0.60), (1e-3, 0.70), (0.1, 0.78), (1.0, 0.86), (5.0, 0.94), (10.0, 1.0), (20.0, 1.08), (40.0, 1.18), (100.0, 1.35)]

KONTROLLER = [
    ctl("um", "En yüksek sistem gerilimi", "sec", 36.0, secenek=opt((7.2, "7,2 kV (6,3 kV şebeke)"), (12.0, "12 kV (10,5 kV)"), (17.5, "17,5 kV (15,8 kV)"), (36.0, "36 kV (34,5 kV)"))),
    ctl("sebeke", "Şebekenin OG nötrü", "sec", "direnc", secenek=opt(("direnc", "Direnç üzerinden topraklı"), ("direkt", "Doğrudan topraklı"))),
    ctl("pf", "Parafudr", "sec", "direnc", secenek=opt(("direnc", "Var — direnç üzerinden topraklı sistem için seçilmiş"), ("direkt", "Var — doğrudan topraklı sistem için seçilmiş"), ("yok", "Yok"))),
    ctl("kres", "Artık gerilim / beyan gerilimi (10 kA'da)", "sayi", 2.9, min=2.3, max=3.6, adim=0.05, yardim="Şartname aralığı 2,3–3,6; küçük oran daha iyi korur"),
    ctl("giris", "Parafudr ile trafo arası", "sec", "hava", secenek=opt(("hava", "Çıplak iletken / bara"), ("kablo", "OG kablosu (parafudr direkte, trafo kabloyla besleniyor)"))),
    ctl("d", "Parafudr – trafo uzaklığı", "sayi", 3.0, min=0.5, max=200, adim=0.5, birim="m"),
    ctl("bag", "Parafudr bağlantı iletkenlerinin toplam boyu", "sayi", 1.0, min=0, max=10, adim=0.5, birim="m", yardim="Faz bağlantısı + toprak bağlantısı (trafo tankına kadar)"),
    ctl("s", "Gelen dalganın dikliği", "sayi", 800, min=100, max=2000, adim=50, birim="kV/µs"),
    ctl("tepe", "Gelen dalganın tepe değeri", "sayi", 300, min=50, max=600, adim=10, birim="kV"),
]


def benzet(upk: float, s: float, z2: float, v2: float, d: float, ures: float, pf: bool, l_bag: float, ct: float = C_TRAFO, z1: float = Z_HAT) -> dict:
    """Parafudr düğümü (A) ile trafo ucu (T) arasında yürüyen dalga. Birimler: kV, kA, Ω, µs, µH, µF."""
    tau = d / v2
    t_on = upk / s
    sure = t_on + 8 * tau + 1.0
    hedef = max(0.004, sure / 4000)
    n = max(1, min(80, round(tau / hedef)))
    dt = tau / n
    adim = min(int(sure / dt) + 1, 6000)
    fq, bq = deque([0.0] * n), deque([0.0] * n)
    y = 1 / z1 + 1 / z2
    ld = l_bag / dt
    i_once, vt = 0.0, 0.0
    ts, va_s, vt_s, e_s = [], [], [], []
    va_max = vt_max = i_max = 0.0
    seg = [(VI[k][0], VI[k][1] * ures, (VI[k + 1][1] - VI[k][1]) * ures / (VI[k + 1][0] - VI[k][0]), VI[k + 1][0]) for k in range(len(VI) - 1)]
    for k in range(adim):
        t = k * dt
        e = min(s * t, upk)
        ba = bq.popleft()
        a0 = 2 * e / z1 + 2 * ba / z2
        i = 0.0
        if pf:
            for ik, vk, mk, iu in seg:
                i = (a0 - y * (vk - mk * ik - ld * i_once)) / (1 + y * (mk + ld))
                if i <= iu:
                    break
            if i < 0:
                i = 0.0
        va = (a0 - i) / y
        i_once = i
        fa_ = va - ba
        fq.append(fa_)
        ft = fq.popleft()
        if ct > 0:
            a = dt / (ct * z2)
            vt = (vt + a * 2 * ft) / (1 + a)
        else:
            vt = 2 * ft
        bq.append(vt - ft)
        va_max, vt_max, i_max = max(va_max, va), max(vt_max, vt), max(i_max, i)
        ts.append(t); va_s.append(va); vt_s.append(vt); e_s.append(e)
    adim_g = max(1, len(ts) // 220)
    return {"vt": vt_max, "va": va_max, "i": i_max, "tau": tau, "t": ts[::adim_g], "va_s": va_s[::adim_g], "vt_s": vt_s[::adim_g], "e_s": e_s[::adim_g]}


def run(p: dict) -> dict:
    um = num(p, "um", 36.0)
    um = um if um in BIL else 36.0
    sebeke, pfs, kres, giris = str(p.get("sebeke", "direnc")), str(p.get("pf", "direnc")), num(p, "kres", 2.9), str(p.get("giris", "hava"))
    d, bag, s, tepe = max(num(p, "d", 3.0), 0.5), num(p, "bag", 1.0), num(p, "s", 800), num(p, "tepe", 300)
    var = pfs in UR
    bil, un = BIL[um], UN[um]
    ur = UR[pfs][um] if var else 0.0
    uc = UC[pfs][um] if var else 0.0
    ures = kres * ur
    z2, v2 = (Z_KABLO, V_KABLO) if giris == "kablo" else (Z_HAT, V_HAT)
    r = benzet(tepe, s, z2, v2, d, ures, var, bag * L_BAG)
    ut, ua, ipf, tau = r["vt"], r["va"], r["i"], r["tau"]
    pay = bil / ut if ut > 0 else 99.0
    tov = (1.73 if sebeke == "direnc" else 1.4) * um / math.sqrt(3)
    basit = min(ures + 2 * s * tau, 2 * tepe) if var else 2 * tepe
    # uzaklığa göre trafo gerilimi ve koruma uzaklığı
    ds = [0.5, 1, 2, 3, 5, 7.5, 10, 15, 20, 30, 50, 80, 120, 200]
    uts = [benzet(tepe, s, z2, v2, q, ures, var, bag * L_BAG)["vt"] for q in ds]
    sinir = bil / 1.2
    d_kor = None
    if var:
        if uts[0] > sinir:
            d_kor = 0.0
        else:
            d_kor = ds[-1]
            for k in range(1, len(ds)):
                if uts[k] > sinir:
                    d_kor = ds[k - 1] + (ds[k] - ds[k - 1]) * (sinir - uts[k - 1]) / (uts[k] - uts[k - 1])
                    break
    # ---------------- şema ----------------
    cz = Cizim(900, 320)
    cz.hat("M30,90 H330", "L1", hot=True, w=3)
    cz.simsek(90, 58, 1.2)
    cz.yazi(40, 112, f"gelen dalga: {fnum(tepe, 0)} kV · {fnum(s, 0)} kV/µs", "#b91c1c", 11.5, kalin=True)
    for xx in (60, 200):
        cz.hat(f"M{xx},80 V178", "cizgi", w=3); cz.hat(f"M{xx - 14},86 H{xx + 14}", "cizgi", w=2)
    if var:
        cz.hat("M330,90 V118", "cizgi", hot=ipf > 0.05, w=2)
        cz.dikdortgen(316, 118, 28, 44, "mor", "#f5f3ff")
        cz.hat("M330,162 V182", "cizgi", hot=ipf > 0.05, w=2); cz.toprak(330, 182)
        cz.yazi(352, 136, f"parafudr Ur {fnum(ur, 0)} kV", "#6d28d9", 11, kalin=True)
        cz.yazi(352, 152, f"artık gerilim {fnum(ures, 0)} kV · {fnum(ipf, 1)} kA", "#6d28d9", 10.5)
    else:
        cz.yazi(340, 136, "parafudr yok", "#b91c1c", 11.5, kalin=True)
    if giris == "kablo":
        cz.hat("M330,90 H640", "mavi", hot=True, w=6)
        cz.yazi(485, 80, f"OG kablosu {fnum(d, 1)} m", "#1d4ed8", 11.5, kalin=True, anchor="middle")
    else:
        cz.hat("M330,90 H640", "L1", hot=True, w=3)
        cz.yazi(485, 80, f"{fnum(d, 1)} m", "#334155", 11.5, kalin=True, anchor="middle")
    cz.kutu(640, 62, 130, 56, "Trafo", f"LI {fnum(bil, 0)} kV", "gecersiz" if ut > bil else "normal")
    cz.yazi(330, 60, f"{fnum(ua, 0)} kV", "#6d28d9", 13, kalin=True, anchor="middle")
    cz.yazi(705, 50, f"{fnum(ut, 0)} kV", "#b91c1c" if ut > sinir else "#15803d", 14, kalin=True, anchor="middle")
    cz.hat("M150,178 H800", "toprak", w=1.5, kesik=True)
    cz.yazi(40, 214, f"Trafo ucunda tepe gerilim {fnum(ut, 0)} kV — yıldırım darbe dayanımı {fnum(bil, 0)} kV, koruma payı {fnum(pay, 2)}", "#b91c1c" if pay < 1.2 else "#15803d", 13, kalin=True)
    cz.yazi(40, 238, f"Dalga parafudrdan trafoya {fnum(tau * 1000, 0)} ns'de varır; her gidiş-gelişte gerilim {fnum(2 * s * tau, 0)} kV daha büyür", "#334155", 12)
    cz.yazi(40, 262, (f"Bağlantı iletkeni ({fnum(bag, 1)} m) artık gerilime kendi endüktif gerilimini ekler" if var and bag > 0 else "Parafudr trafonun tam ucunda ve kısa bağlantılı olmalıdır"), "#64748b", 12)
    cz.yazi(40, 286, ((f"Bu diklikte koruma uzaklığı ≈ {fnum(d_kor, 1)} m" if d_kor and d_kor < 199 else "Bu diklikte parafudr 200 m'ye kadar koruyor" if d_kor else "Parafudr bu diklikte trafonun ucunda bile yetmiyor")
                       if var else "Parafudrsuz: dalga trafo ucunda iki katına çıkar"), "#b91c1c" if (not var or (d_kor is not None and d_kor < d)) else "#64748b", 12, kalin=True)
    ozet = [
        K("Trafo ucunda tepe gerilim", f"{fnum(ut, 0)} kV", "bad" if ut > bil else "warn" if pay < 1.2 else "ok", f"dayanım (LI) {fnum(bil, 0)} kV"),
        K("Koruma payı", fnum(pay, 2), "bad" if pay < 1.0 else "warn" if pay < 1.2 else "ok", "LI / trafo gerilimi; ≥ 1,2 istenir"),
        K("Parafudr ucunda", f"{fnum(ua, 0)} kV" if var else "—", "info", f"artık gerilim {fnum(ures, 0)} kV · akım {fnum(ipf, 1)} kA" if var else "parafudr yok"),
        K("Koruma uzaklığı", (f"≈ {fnum(d_kor, 1)} m" if d_kor is not None and d_kor < 199 else "> 200 m" if d_kor else "—"), "bad" if (d_kor is not None and d_kor < d) else "info", f"şimdiki uzaklık {fnum(d, 1)} m"),
        K("Yürüme süresi", f"{fnum(tau * 1000, 0)} ns", "info", f"{fnum(v2, 0)} m/µs · dalga empedansı {fnum(z2, 0)} Ω"),
    ]
    kontroller = [
        C("Trafo ucundaki tepe gerilim yıldırım darbe dayanımının altında mı?", f"{fnum(ut, 0)} kV", f"≤ {fnum(bil, 0)} kV-tepe", ut <= bil,
          f"{PF} Tablo-4: Um {fnum(um, 1)} kV'ta korunacak teçhizatın yıldırım darbe dayanım gerilimi {fnum(bil, 0)} kV-tepe", "resmi"),
        C("Koruma payı yeterli mi?", fnum(pay, 2), "≥ 1,2", pay >= 1.2,
          "Dalganın dikliği, parafudrun yaşlanması ve yalıtımın yıllar içinde zayıflaması için pay bırakılır; 1,2 yaygın uygulamadır (IEC 60071-2 iç yalıtım için 1,15 emniyet katsayısı kullanır)", "ikincil"),
        C("Parafudrun beyan gerilimi şebekenin topraklama biçimine uygun mu?", f"Ur {fnum(ur, 0)} kV · Uc {fnum(uc, 1)} kV" if var else "parafudr yok",
          f"Ur ≥ {fnum(UR[sebeke][um], 0)} kV · Uc ≥ {fnum(UC[sebeke][um], 1)} kV", (ur >= UR[sebeke][um]) if var else False,
          f"{PF} Tablo-7. Toprak arızasında sağlam fazların gerilimi yükselir (bu şebekede ≈ {fnum(tov, 1)} kV); beyan gerilimi küçük seçilen parafudr bu sırada ısınır ve bozulur", "resmi"),
        C("Parafudrdan geçen akım anma boşalma akımının içinde mi?", f"{fnum(ipf, 1)} kA" if var else "—", "≤ 10 kA (DH ve SL sınıfı; DM'de 5 kA)", (ipf <= 10.0) if var else None,
          f"{PF} Tablo-5 ve Tablo-6: anma boşalma akımı. Hatta doğrudan yıldırım düşmesinde akım bunun üstüne çıkabilir; parafudr yüksek akım darbesiyle ayrıca denenir", "resmi"),
        C("Kablo girişinde trafo ucuna ikinci parafudr takımı gerekir mi?", f"kablo {fnum(d, 1)} m · trafo ucunda {fnum(ut, 0)} kV" if giris == "kablo" else "kablo girişi yok", "koruma payı < 1,2 ise gerekir",
          (pay >= 1.2) if giris == "kablo" else None, "Kablo içinde dalga iki uç arasında gidip gelir ve açık uçta parafudrun kırptığı gerilimin üstüne çıkar; pay yetmiyorsa trafo ucuna ikinci takım konur", "ikincil"),
    ]
    girdiler = [
        G("Şebeke ve yalıtım düzeyi", f"Um {fnum(um, 1)} kV ({fnum(un, 1)} kV şebeke) · LI {fnum(bil, 0)} kV · AC {fnum(AC[um], 0)} kV", "Trafo ve hücre etiketi; şartname", "Yalıtımın dayanacağı en yüksek darbe gerilimi",
          f"izin verilen = LI / 1,2 = {fnum(sinir, 0)} kV"),
        G("Parafudr", (f"Ur {fnum(ur, 0)} kV · Uc {fnum(uc, 1)} kV · artık gerilim {fnum(ures, 0)} kV (10 kA)" if var else "yok"), "Parafudr etiketi ve deney raporu", "Dalganın kırpıldığı gerilim",
          f"Ures = {fnum(kres, 2)} × Ur" if var else "—"),
        G("Parafudr – trafo yolu", f"{fnum(d, 1)} m · {'kablo' if giris == 'kablo' else 'çıplak iletken'} · bağlantı {fnum(bag, 1)} m", "Yerleşim resmi; sahada ölçü", "Dalganın yeniden büyüdüğü yol",
          f"τ = d / v = {fnum(d, 1)} / {fnum(v2, 0)} = {fnum(tau * 1000, 0)} ns"),
        G("Gelen dalga", f"{fnum(tepe, 0)} kV · {fnum(s, 0)} kV/µs", "Ölçülmez: hat yalıtımının atlama gerilimi ve yıldırımın uzaklığıyla kestirilir", "Tepe değerini hat izolatörleri, dikliği yıldırımın uzaklığı belirler",
          "yakın yıldırım: dik cephe; uzak yıldırım: korona cepheyi yatırır"),
    ]
    adimlar = [
        A("Açık uçta yansıma", "U(uç) = 2 · U(gelen)", f"2 × {fnum(tepe, 0)}", f"{fnum(2 * tepe, 0)} kV", "trafo dalgaya açık uç gibi görünür: dalga geri döner ve üst üste biner", "hesap", ["Gelen dalga"]),
        A("Parafudrun kırptığı gerilim", "Ures = oran × Ur", f"{fnum(kres, 2)} × {fnum(ur, 0)}", f"{fnum(ures, 0)} kV" if var else "—", f"{PF} Tablo-8: yıldırım darbesi artık gerilimi 2,3–3,6 × Ur", "resmi", ["Parafudr"]),
        A("Yoldaki büyüme (yalın bağıntı)", "U(trafo) ≈ Ures + 2 · S · τ", f"{fnum(ures, 0)} + 2 × {fnum(s, 0)} × {fnum(tau, 4)} µs", f"{fnum(basit, 0)} kV", "üst sınır: 2 × gelen tepe", "hesap", ["Parafudr – trafo yolu"]),
        A("Bağlantı iletkeninin gerilimi", "U = L · di/dt", f"{fnum(bag * L_BAG, 1)} µH × parafudr akımının yükselme hızı", f"parafudr ucunda {fnum(ua, 0)} kV" if var else "—", "her metre bağlantı ≈ 1 µH; dik akımda metre başına birkaç kV", "hesap"),
        A("Benzetim sonucu", "yürüyen dalga + parafudr eğrisi + trafo kapasitesi", f"Z = {fnum(z2, 0)} Ω · v = {fnum(v2, 0)} m/µs · C(trafo) = 1 nF", f"trafo ucunda {fnum(ut, 0)} kV", "yalın bağıntıdan farkı: trafo kapasitesi ve çoklu yansımalar", "hesap"),
        A("Koruma payı", "pay = LI / U(trafo)", f"{fnum(bil, 0)} / {fnum(ut, 0)}", fnum(pay, 2), "≥ 1,2 istenir", "hesap", ["Şebeke ve yalıtım düzeyi"]),
        A("Toprak arızasında geçici aşırı gerilim", "U = k · Um / √3", f"{'1,73' if sebeke == 'direnc' else '1,4'} × {fnum(um, 1)} / 1,732", f"{fnum(tov, 1)} kV", "parafudrun beyan gerilimi bunun altında kalmamalı", "ikincil"),
    ]
    ayarlar = [
        S("Parafudrun yeri", "trafo OG buşinglerinin hemen yanında; toprak ucu trafo tankına", f"koruma uzaklığı ≈ {fnum(d_kor, 1)} m" if d_kor is not None else "—", "Tank ile parafudr aynı toprağa bağlanınca yalıtım yalnız artık gerilimi görür", "saha pratiği", "ikincil"),
        S("Beyan gerilimi (Ur) / sürekli işletme gerilimi (Uc)", f"{fnum(UR[sebeke][um], 0)} / {fnum(UC[sebeke][um], 1)} kV", "Tablo-7", "Şebekenin topraklama biçimine göre", f"{PF} Tablo-7", "resmi"),
        S("Anma boşalma akımı", "10 kA (DH, SL) · 5 kA (DM)", "Tablo-5, Tablo-6", "Dağıtım ve trafo merkezi sınıfı", f"{PF} Tablo-5 ve Tablo-6", "resmi"),
        S("Parafudr ayırıcısı", "arızalanan parafudru şebekeden ayırır", "—", "Kısa devre olmuş parafudr kalıcı toprak arızasına dönüşmesin; yerden gözle görülür", f"{PF} böl. 2.4.2", "resmi"),
        S("En küçük hava açıklığı", ACIKLIK.get(um, "Um'a göre çizelgeden"), "—", "Darbe geriliminde havanın atlamaması için", "Siemens GEAFOL kılavuzu böl. 6.6-6.7 çizelgesi", "resmi"),
    ]
    test = [
        T("Parafudrun kaçak akımı", "Pens ampermetreyle toprak iletkeninde (özel kaçak akım ölçeri)", "miliamperin altında, üç fazda benzer", "birinde artış: yaşlanma ya da nem — değiştirilir"),
        T("Ayırıcının durumu", "Gözle, yerden", "ayırıcı düşmemiş, toprak iletkeni bağlı", "düşmüş ayırıcı: parafudr arızalı, trafo korumasız"),
        T("Toprak bağlantısı", "Parafudr toprağı ile trafo tankı arasında süreklilik", "aynı topraklama barasında, kısa ve düz", "kıvrım ve fazla boy endüktif gerilimi artırır"),
        T("Sayıcı (varsa)", "Darbe sayıcısının göstergesi", "boşalma sayısı", "çok çalışan parafudr gözden geçirilir"),
    ]
    g1 = {"baslik": "Zamana göre gerilim", "x_ad": "Zaman (µs)", "y_ad": "Gerilim (kV)", "ymin": 0,
          "seriler": [{"ad": "gelen dalga", "renk": "#94a3b8", "pts": pts(r["t"], r["e_s"], 1)}, {"ad": "parafudr ucunda", "renk": "#7c3aed", "pts": pts(r["t"], r["va_s"], 1)},
                      {"ad": "trafo ucunda", "renk": "#dc2626", "pts": pts(r["t"], r["vt_s"], 1)}],
          "yatay": [{"y": bil, "etiket": f"LI {fnum(bil, 0)} kV", "renk": "#dc2626"}, {"y": sinir, "etiket": "LI / 1,2", "renk": "#b45309"}]}
    g2 = {"baslik": "Parafudr uzaklaştıkça trafonun gördüğü gerilim", "x_ad": "Parafudr – trafo uzaklığı (m)", "y_ad": "Tepe gerilim (kV)", "logx": True, "ymin": 0,
          "seriler": [{"ad": "trafo ucunda (benzetim)", "renk": "#dc2626", "pts": pts(ds, uts, 1)}],
          "yatay": [{"y": bil, "etiket": f"LI {fnum(bil, 0)} kV", "renk": "#dc2626"}, {"y": sinir, "etiket": "LI / 1,2", "renk": "#b45309"}], "isaretler": [{"x": d, "etiket": "uzaklık"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Yıldırım hatta ya da hattın yakınına düştüğünde iletkende bir gerilim dalgası doğar ve iki yöne yürür: havai hatta saniyede 300 000 km, kabloda bunun yarısı kadar hızla. Dalganın tepe değerini hattın izolatörleri sınırlar; fazlası direkte atlar.",
            f"Dalga trafoya vardığında gidecek yeri kalmaz: trafo sargısı bu kadar hızlı bir olaya açık uç gibi davranır. Dalga geri yansır ve gelenle üst üste biner; parafudr olmasaydı trafo ucunda {fnum(2 * tepe, 0)} kV görülürdü. Trafonun darbe dayanımı ise {fnum(bil, 0)} kV'tur.",
            (f"Parafudr, gerilim {fnum(0.7 * ures, 0)} kV'u geçince iletmeye başlayan bir dirençtir: akım büyüdükçe gerilimi {fnum(ures, 0)} kV dolayında tutar ve dalganın fazlasını toprağa akıtır ({fnum(ipf, 1)} kA). Ama bunu yalnız bulunduğu noktada yapar."
             if var else "Parafudr yokken dalgayı sınırlayan tek şey hattın ve trafonun kendi yalıtımıdır: dalga trafo ucunda iki katına çıkar ve en zayıf yerden — çoğu zaman sargının ilk sarımlarından — atlar."),
            f"Parafudrdan trafoya {fnum(d, 1)} m yol var; dalga bu yolu {fnum(tau * 1000, 0)} ns'de alır. Kırpılmış dalga trafoya varıp yansıyana ve parafudr bunu «görene» kadar trafo ucundaki gerilim yükselmeye devam eder: her gidiş-gelişte 2·S·τ = {fnum(2 * s * tau, 0)} kV. Bu yüzden uzaklık ve diklik çarpımı önemlidir.",
            (f"Bağlantı iletkenleri de sayılır: {fnum(bag, 1)} m iletken ≈ {fnum(bag * L_BAG, 1)} µH'dir ve akım mikrosaniyede kiloamperler hızıyla yükselirken üzerinde kilovoltlar düşer. Bu gerilim artık gerilime eklenir; parafudr ucunda {fnum(ua, 0)} kV görülmesinin nedeni budur."
             if var and bag > 0 else "Bağlantı iletkeni ne kadar kısa ve düzse parafudrun koruma düzeyi etiket değerine o kadar yakın olur."),
            (f"Kablo girişinde durum farklıdır. Kablonun dalga empedansı hattınkinin on ikide biridir: dalganın yalnız yedide biri kabloya girer, kablo dalgayı yumuşatır. Ama giren dalga iki uç arasında gidip gelir ve açık uçta parafudrun tuttuğu gerilimin üstüne çıkar: burada {fnum(ut, 0)} kV. Gelen dalga büyüdükçe (tepe değerini artırın) bu taşma büyür; pay yetmediğinde trafo ucuna ikinci bir parafudr takımı konur."
             if giris == "kablo" else "Trafo kabloyla besleniyorsa parafudr kablo başlığının bulunduğu direğe konur; kablo uzunsa trafo ucuna ikinci bir takım gerekir («kablo» seçeneğiyle deneyin)."),
            f"Parafudr seçiminde ikinci koşul şebekenin kendisidir. Toprak arızasında sağlam fazların gerilimi yükselir: bu şebekede ≈ {fnum(tov, 1)} kV. Beyan gerilimi bunun altında kalan parafudr arıza süresince iletir, ısınır ve bozulur; bu yüzden direnç üzerinden topraklı şebekede daha yüksek beyan gerilimli parafudr kullanılır.",
        ],
        "dersler": [
            "Dalga açık uçta iki katına çıkar; trafo dalgaya açık uç gibi görünür.",
            "Parafudr yalnız bulunduğu noktayı korur: trafoya uzaklık arttıkça koruma zayıflar (U ≈ Ures + 2·S·τ).",
            "Bağlantı iletkeni kısa ve düz olmalı; parafudr toprağı trafo tankına bağlanmalı.",
            "Beyan gerilimi şebekenin topraklama biçimine göre seçilir: 34,5 kV'ta direnç üzerinden topraklıda 36 kV, doğrudan topraklıda 30 kV.",
            "Kablo dalgayı yumuşatır, ama açık ucunda gerilim parafudr geriliminin üstüne çıkar: pay yetmezse trafo ucuna da parafudr konur.",
        ],
        "tablolar": [{"baslik": "Yalıtım düzeyleri ve parafudr değerleri", "cols": ["Um (kV)", "Şebeke (kV)", "LI dayanım (kV-tepe)", "AC dayanım (kV)", "Ur / Uc — doğrudan topraklı", "Ur / Uc — direnç üzerinden", "Artık gerilim aralığı (kV)"],
                      "rows": [[fnum(u, 1) + (" ◀" if u == um else ""), fnum(UN[u], 1), fnum(BIL[u], 0), fnum(AC[u], 0), f"{fnum(UR['direkt'][u], 0)} / {fnum(UC['direkt'][u], 0)}",
                                f"{fnum(UR['direnc'][u], 0)} / {fnum(UC['direnc'][u], 1)}", f"{fnum(2.3 * UR[sebeke][u], 0)} – {fnum((3.3 if UR[sebeke][u] >= 30 else 3.6) * UR[sebeke][u], 0)}"] for u in UM],
                      "not": f"{PF} Tablo-4, Tablo-7 ve Tablo-8.b (10 kA). AC dayanım: TEDAŞ-MLZ/99-032.E böl. 2.2.11. Artık gerilim aralığı şebekenin seçili topraklama biçimi içindir."}],
    }
