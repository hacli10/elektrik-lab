"""Üç fazlı motorda faz kopması (iki faza kalma): dururken ve çalışırken; yıldız ve üçgen bağlı sargılarda hangi sargıdan ne akım geçer, hangisi önce yanar,
termik röle görür mü.

Model: motor_model'in pozitif ve negatif bileşen devreleri. L1 hattı açıkken I(L1) = 0 → I1 = −I2 ve V1 − V2 = 1 pu (kalan hat arası gerilimden):
I1 = 1 / (Z1(s) + Z2(2 − s)); hat akımı = √3·|I1|. Üçgen sargıda sargı akımları: açık olmayan iki hattın arasındaki sargı 2·|I1|, öbür ikisi |I1| (anma sargı
akımına göre). Yıldızda iki sargı √3·|I1|, üçüncüsü sıfır. Dururken ileri ve geri alan eşittir: moment yok. Termik süresi sınıf 10 için yaklaşık bağıntıdır (tahmini)."""
from __future__ import annotations

import math

from . import motor_model as M
from .asenkron import GUCLER, anma_akim
from .ortak import A, C, G, K, S, T, TEMEL, Cizim, ctl, fa, fnum, num, opt, pts
from .trafo_faz import termik

ID = "motor_faz"
BASLIK = "Motorda faz kopması"
IKON = "⚠"
GIRIS = ("Üç fazlı motorun bir fazı kesildi: sigorta attı, kontaktörün bir kutbu yandı, klemens gevşedi. Motor duruyorsa kalkamaz; dönüyorsa dönmeye devam eder ama iki fazla. "
         "Akım nereye çıkar, yıldız ve üçgen sargıda hangi sargı yanar, termik röle bunu görür mü? Bağlantıyı ve yükü değiştirip izleyin.")

KONTROLLER = [
    ctl("pn", "Motor gücü", "sec", 15, secenek=opt(*[(g, f"{str(g).replace('.', ',')} kW") for g in GUCLER])),
    ctl("bag", "Sargı bağlantısı", "sec", "ucgen", secenek=opt(("ucgen", "Üçgen (Δ) — 400 V'ta ≥ 5,5 kW motorlar"), ("yildiz", "Yıldız (Y)"))),
    ctl("an", "Faz ne zaman koptu?", "sec", "calisirken", secenek=opt(("calisirken", "Motor çalışırken"), ("dururken", "Motor dururken (kalkış denemesi)"), ("yok", "Kopma yok — olağan çalışma"))),
    ctl("yuk", "Yük momenti", "sayi", 75, min=0, max=120, adim=5, birim="%"),
    ctl("yuk_tip", "Yükün türü", "sec", "sabit", secenek=opt(("sabit", "Sabit moment"), ("fan", "Hızın karesiyle artan (fan, pompa)"))),
    ctl("ayar", "Termik rölenin ayarı", "sayi", 1.0, min=0.8, max=1.3, adim=0.05, birim="× In"),
    ctl("duyarli", "Termik röle faz kaybına duyarlı (diferansiyel sürgülü)", "onay", True),
]


def tek_faz(par: dict, s: float) -> dict:
    """Bir hattı açık motor: akımlar, moment."""
    z1, z2 = M.zs(par, s), M.zs(par, 2 - s)
    i1 = 1 / (z1 + z2)
    v1, v2 = i1 * z1, -i1 * z2
    m = M.moment(par, s, v1, v2)
    return {"i1": i1, "v1": v1, "v2": v2, "m": m["m"], "p_rotor": m["p_rotor"], "hat": math.sqrt(3) * abs(i1)}


def calis_tek(par: dict, yuk: float, fan: bool) -> dict:
    mn = M.anma(par)["m"]
    ss = [0.002 * 1.08 ** k for k in range(90) if 0.002 * 1.08 ** k < 1.0]
    f = lambda s: tek_faz(par, s)["m"] / mn - yuk * ((1 - s) ** 2 if fan else 1.0)          # noqa: E731
    tepe = max(ss, key=lambda s: tek_faz(par, s)["m"])
    if f(tepe) < 0:
        return {"s": 1.0, "devrildi": True, **tek_faz(par, 1.0)}
    lo, hi = 1e-5, tepe
    for _ in range(50):
        mid = (lo + hi) / 2
        lo, hi = (lo, mid) if f(mid) > 0 else (mid, hi)
    s = (lo + hi) / 2
    return {"s": s, "devrildi": False, **tek_faz(par, s)}


def run(p: dict) -> dict:
    pn, ucgen, an_ = num(p, "pn", 15), p.get("bag", "ucgen") == "ucgen", str(p.get("an", "calisirken"))
    yuk, fan, ayar, duyarli = num(p, "yuk", 75) / 100, p.get("yuk_tip") == "fan", num(p, "ayar", 1.0), bool(p.get("duyarli", True))
    par = M.UC; a0 = M.anma(par); an = anma_akim(pn); amper = an["i"] / a0["i"]
    n3 = M.calisma(par, yuk, 1.0, 0j, 1.0, fan)                               # kopmadan önce
    i3 = abs(n3["i1"]) / a0["i"]
    if an_ == "yok":
        hat = [i3, i3, i3]; sargi = [i3, i3, i3]; s = n3["s"]; dev = n3["devrildi"]; m = n3["m"] / a0["m"]; rotor = n3["p_rotor"]; vuf = 0.0
    else:
        q = tek_faz(par, 1.0) if an_ == "dururken" else calis_tek(par, yuk, fan)
        s = 1.0 if an_ == "dururken" else q["s"]; dev = an_ == "dururken" or q["devrildi"]
        i1 = abs(q["i1"]) / a0["i"]
        hat = [0.0, math.sqrt(3) * i1, math.sqrt(3) * i1]
        sargi = [i1, 2 * i1, i1] if ucgen else [0.0, math.sqrt(3) * i1, math.sqrt(3) * i1]          # üçgen: L1–L2, L2–L3, L3–L1 · yıldız: U, V, W
        m = q["m"] / a0["m"]; rotor = q["p_rotor"]; vuf = abs(q["v2"]) / abs(q["v1"]) * 100
    rotor0 = M.moment(par, M.SN)["p_rotor"]
    isi = [x * x for x in sargi]
    m_hat = max(hat) / ayar
    t_ter = termik(m_hat if not (duyarli and an_ != "yok") else max(m_hat, 1.16) * 1.25)          # faz kaybına duyarlı röle: eşik düşer, süre kısalır
    sargi_ad = ["L1–L2 sargısı", "L2–L3 sargısı", "L3–L1 sargısı"] if ucgen else ["U sargısı (L1)", "V sargısı (L2)", "W sargısı (L3)"]
    en = max(range(3), key=lambda k: sargi[k])

    c = Cizim(900, 330)
    for j, y in enumerate((60, 100, 140)):
        acik = an_ != "yok" and j == 0
        c.hat(f"M30,{y} H150", f"L{j + 1}", hot=hat[j] > 0.02, w=3)
        if acik:
            c.hat(f"M150,{y} l24,-14", f"L{j + 1}", w=3); c.yazi(162, y - 18, "KOPUK", "#b91c1c", 10, kalin=True, anchor="middle"); c.hat(f"M180,{y} H300", f"L{j + 1}", kesik=True, w=2)
        else:
            c.hat(f"M150,{y} H300", f"L{j + 1}", hot=hat[j] > 0.02, w=3)
        c.yazi(230, y - 7, fa(hat[j] * amper, 1), "#b91c1c" if hat[j] > 1.05 else "#334155", 11.5, kalin=hat[j] > 1.05, anchor="middle")
        c.yazi(30, y - 7, f"L{j + 1}", "#475569", 10)
    cx, cy = 400, 100
    if ucgen:
        ust, sol, sag = (cx, cy - 56), (cx - 62, cy + 50), (cx + 62, cy + 50)
        kenar = [(ust, sag, 0), (sag, sol, 1), (sol, ust, 2)]                # L1(üst)–L2(sağ), L2–L3(sol), L3–L1
        for (a_, b_, k) in kenar:
            c.hat(f"M{a_[0]},{a_[1]} L{b_[0]},{b_[1]}", "ariza" if isi[k] > 1.3 else "cizgi", hot=sargi[k] > 0.02, w=6 if isi[k] > 1.3 else 4, hot_renk="ariza" if isi[k] > 1.3 else "uyari")
        c.hat(f"M300,60 H{cx} V{ust[1]}", "L1", w=2, kesik=an_ != "yok"); c.hat(f"M300,100 H330 V20 H{sag[0] + 20} V{sag[1]} H{sag[0]}", "L2", w=2); c.hat(f"M300,140 H{sol[0]} V{sol[1]}", "L3", w=2)
        c.yazi(cx + 50, cy - 14, f"{fnum(sargi[0], 2)}", "#b91c1c" if isi[0] > 1.3 else "#334155", 12, kalin=True); c.yazi(cx, cy + 70, f"{fnum(sargi[1], 2)}", "#b91c1c" if isi[1] > 1.3 else "#334155", 12, kalin=True, anchor="middle")
        c.yazi(cx - 50, cy - 14, f"{fnum(sargi[2], 2)}", "#b91c1c" if isi[2] > 1.3 else "#334155", 12, kalin=True, anchor="end")
    else:
        uc = [(cx, cy - 56), (cx + 62, cy + 50), (cx - 62, cy + 50)]
        for k, (x, y) in enumerate(uc):
            c.hat(f"M{cx},{cy + 10} L{x},{y}", "ariza" if isi[k] > 1.3 else "cizgi", hot=sargi[k] > 0.02, w=6 if isi[k] > 1.3 else 4, hot_renk="ariza" if isi[k] > 1.3 else "uyari")
            c.yazi(x + (14 if k < 2 else -14), y + (0 if k else -8), fnum(sargi[k], 2), "#b91c1c" if isi[k] > 1.3 else "#334155", 12, kalin=True, anchor="start" if k < 2 else "end")
        c.hat(f"M300,60 H{cx} V{uc[0][1]}", "L1", w=2, kesik=an_ != "yok"); c.hat(f"M300,100 H330 V20 H{uc[1][0] + 30} V{uc[1][1]} H{uc[1][0]}", "L2", w=2); c.hat(f"M300,140 H{uc[2][0]} V{uc[2][1]}", "L3", w=2)
    c.yazi(cx, cy + 96, "sargı akımları (anma sargı akımının katı)", "#64748b", 10, anchor="middle")
    c.yazi(540, 50, {"yok": "Olağan çalışma", "calisirken": "Çalışırken faz koptu", "dururken": "Dururken faz yok: kalkış denemesi"}[an_], "#15803d" if an_ == "yok" else "#b91c1c", 14, kalin=True)
    c.yazi(540, 76, ("Motor KALKAMIYOR: moment yok" if an_ == "dururken" else "Motor DEVRİLDİ: yük iki fazla taşınamıyor" if dev else f"Motor dönüyor: kayma %{fnum(s * 100, 1)} (önce %{fnum(n3['s'] * 100, 1)})"), "#b91c1c" if dev else "#334155", 12.5, kalin=True)
    c.yazi(540, 100, f"Hat akımı {fnum(max(hat), 2)} × In (önce {fnum(i3, 2)} × In)", "#b91c1c" if max(hat) > 1.05 else "#334155", 12.5, kalin=True)
    c.yazi(540, 124, f"En çok ısınan: {sargi_ad[en]} — ısınma × {fnum(isi[en], 1)}", "#b91c1c" if isi[en] > 1.3 else "#334155", 12.5, kalin=isi[en] > 1.3)
    c.yazi(540, 148, f"Rotor kaybı × {fnum(rotor / rotor0, 1)} (anma yüküne göre)", "#b91c1c" if rotor / rotor0 > 1.5 else "#334155", 12)
    c.yazi(540, 176, "Termik röle: " + ("açmaz — hat akımı ayarın altında" if t_ter is None else f"{fnum(t_ter, 0)} s içinde açar" if t_ter < 120 else f"{fnum(t_ter / 60, 0)} dk içinde açar"), "#b91c1c" if t_ter is None and isi[en] > 1.3 else "#334155", 12.5, kalin=True)
    if an_ != "yok" and ucgen and not dev:
        c.yazi(540, 204, "Üçgende bir sargı hat akımının 2/3'ünü taşır:", "#1a4d8f", 11.5); c.yazi(540, 220, "hat akımı ayarın altındayken bile o sargı yanabilir.", "#1a4d8f", 11.5)
    c.yazi(30, 250, "Kopmadan önce: " + f"hat {fnum(i3, 2)} × In, sargılar {fnum(i3, 2)} × anma, kayma %{fnum(n3['s'] * 100, 1)}", "#64748b", 11.5)
    c.yazi(30, 274, "İki fazla çalışan motorda alan eliptiktir: geri dönen bileşen rotoru yaklaşık iki katı frekansta keser ve ısıtır.", "#64748b", 11)
    c.yazi(30, 296, "Motor uğuldar, titreşir, yavaşlar; yük hafifse fark edilmeden dakikalarca çalışabilir.", "#64748b", 11)

    korunuyor = t_ter is not None or isi[en] <= 1.3
    ozet = [
        K("Motor", "kalkamıyor" if an_ == "dururken" else "devrildi" if dev else "dönüyor", "bad" if dev else "ok" if an_ == "yok" else "warn", f"kayma %{fnum(s * 100, 1)} · moment %{fnum(m * 100, 0)}"),
        K("Hat akımı", f"{fa(max(hat) * amper, 1)}", "bad" if max(hat) > 1.05 else "ok", f"{fnum(max(hat), 2)} × In · önce {fnum(i3, 2)} × In"),
        K("En yüklü sargı", f"× {fnum(sargi[en], 2)}", "bad" if isi[en] > 1.3 else "ok", f"{sargi_ad[en]} · ısınma × {fnum(isi[en], 1)}"),
        K("Rotor kaybı", f"× {fnum(rotor / rotor0, 1)}", "bad" if rotor / rotor0 > 1.5 else "ok", "anma yükündeki kayba göre"),
        K("Termik röle", "açmaz" if t_ter is None else f"{fnum(t_ter, 0)} s" if t_ter < 120 else f"{fnum(t_ter / 60, 0)} dk", "bad" if not korunuyor else "ok", f"hat akımı / ayar = {fnum(m_hat, 2)}" + (" · faz kaybına duyarlı" if duyarli and an_ != "yok" else "")),
    ]
    kontroller = [
        C("Motor dönebiliyor mu?", "kalkamıyor" if an_ == "dururken" else "devrildi" if dev else f"kayma %{fnum(s * 100, 1)}", "kalkış ve kararlı çalışma", not dev, "Dururken iki fazla beslenen motorun alanı dönmez: kalkış momenti sıfırdır. Dönerken devam eder ama devrilme momenti yaklaşık yarıya iner", "hesap"),
        C("Hat akımı", f"{fnum(max(hat), 2)} × In", "≤ 1,05 × In", max(hat) <= 1.05, "Aynı gücü iki hat taşır: akım kabaca √3 katına, yük ağırsa daha da yukarı çıkar", "hesap"),
        C("Hiçbir sargı aşırı ısınmıyor mu?", f"{sargi_ad[en]}: akım × {fnum(sargi[en], 2)}, ısınma × {fnum(isi[en], 1)}", "ısınma ≤ × 1,3", isi[en] <= 1.3, "Üçgen sargıda açık olmayan iki hattın arasındaki sargı öbür ikisinin iki katı akım taşır; yıldızda iki sargı eşit yüklenir", "hesap"),
        C("Koruma bu durumu yakalıyor mu?", "açmıyor" if t_ter is None else f"{fnum(t_ter, 0)} s", "sargı hasar görmeden açmalı", korunuyor, "Termik röle hat akımını ölçer. Üçgen motorda hafif yükte hat akımı ayarın altında kalırken bir sargı aşırı ısınabilir: faz kaybına duyarlı röle ya da ayrı faz koruma rölesi gerekir", "ikincil"),
        C("Gerilim dengesizliği (motor klemensinde)", f"V2/V1 = %{fnum(vuf, 0)}", "bilgi", None, "Dönen motor eksik fazın gerilimini kendi üretir: klemensteki gerilim ölçüsü «üç faz da var» gösterebilir. Faz kaybı gerilimden değil akımdan anlaşılır", "hesap"),
    ]
    girdiler = [
        G("Motor etiketi ve bağlantı", f"{str(pn).replace('.', ',')} kW · {'Δ' if ucgen else 'Y'} · {fa(an['i'], 1)}", "Etiket; klemens kutusundaki köprüler", "Sargı akımı bağlantıya göre değişir: üçgende hat akımının 1/√3'ü", "I(sargı) = I(hat) / √3 (Δ, dengeli)"),
        G("Yük", f"%{fnum(yuk * 100, 0)} · {'hızla artan' if fan else 'sabit'}", "Çalışma akımı / anma akımı", "İki fazla taşınabilecek yük sınırlıdır; hafif yükte arıza gizli kalır", "M(dev, iki faz) ≈ M(dev) / 2"),
        G("Termik rölenin ayarı ve tipi", f"{fnum(ayar, 2)} × In · {'faz kaybına duyarlı' if duyarli else 'duyarsız'}", "Rölenin üstü: ayar kadranı, «faz kaybı duyarlı» işareti", "Duyarlı röle akımlar dengesizken daha düşük akımda ve daha çabuk açar", "duyarlı rölede iki fazlı çalışmada eşik düşer"),
    ]
    adimlar = [
        A("Sınır koşulu", "I(L1) = 0 → I1 = −I2", "nötr bağlı değil: I0 = 0", "pozitif ve negatif bileşen akımları eşit ve ters", "simetrili bileşenler", "hesap"),
        A("Bileşen akımı", "I1 = (V1 − V2) / (Z1(s) + Z2(2 − s)) · V1 − V2 = 1 pu", f"s = {fnum(s, 3)}", f"|I1| = {fnum(sargi[0] if ucgen else hat[1] / math.sqrt(3), 2)} × In" if an_ != "yok" else "kopma yok", "iki bileşen devresi seri bağlanır", "hesap", ["Motor etiketi ve bağlantı"]),
        A("Hat akımı", "I(hat) = √3 · |I1|", "kalan iki hatta, eşit ve ters", f"{fnum(max(hat), 2)} × In", TEMEL, "hesap"),
        A("Sargı akımları", "Δ: |I1|, 2·|I1|, |I1| · Y: 0, √3·|I1|, √3·|I1|" , "anma sargı akımına göre", " / ".join(fnum(x, 2) for x in sargi), "üçgende iki sargı seri, biri onlara paralel kalır", "hesap"),
        A("Moment", "M = M1(s) − M2(2 − s)", f"V1 = {fnum(abs(tek_faz(par, s)['v1']) if an_ != 'yok' else 1, 2)} · V2 = {fnum(abs(tek_faz(par, s)['v2']) if an_ != 'yok' else 0, 2)}", f"%{fnum(m * 100, 0)}", "geri alan fren momenti üretir", "hesap", ["Yük"]),
        A("Termik süre", "t ≈ 300 · ln(m² / (m² − 1,15²))", f"m = {fnum(m_hat, 2)}" + (" (duyarlı: × 1,25)" if duyarli and an_ != "yok" else ""), "açmaz" if t_ter is None else f"{fnum(t_ter, 0)} s", "sınıf 10 röle için yaklaşık eğri", "tahmini", ["Termik rölenin ayarı ve tipi"]),
    ]
    ayarlar = [
        S("Termik röle › ayar", f"{fa(an['i'], 1)} (etiket akımı)", "—", "Yıldız–üçgen yol vermede röle sargı devresindeyse ayar In/√3'tür", "saha pratiği", "ikincil"),
        S("Faz kaybı / faz sırası rölesi", "motor panosunun girişinde", "gecikme 1–3 s", "Gerilimden çalışır: besleme tarafındaki kopmayı görür, motorla röle arasındaki kopmayı görmez", "saha pratiği", "ikincil"),
        S("Motor koruma rölesi › akım dengesizliği (46)", "I2 > %15–20 In · 1–3 s", "—", "Kopmanın yerinden bağımsız olarak akımdan yakalar; en güvenilir koruma", "Röle laboratuvarı › Negatif bileşen", "ikincil"),
        S("Sigorta", "bir sigortanın atması motoru iki faza bırakır", "—", "Motor devrelerinde sigorta yerine üç kutbu birlikte açan motor koruma şalteri tercih edilir", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Üç faz akımı", "Pens ampermetre, motor çalışırken üç hatta", " / ".join(fa(x * amper, 1) for x in hat), "bir hatta 0 A, öbür ikisi eşit ve yüksek: faz yok"),
        T("Klemens gerilimleri", "Motor çalışırken ve dururken", "çalışırken üç faz arası da gerilim okunabilir; dururken açık fazda gerilim yok", "çalışan motor eksik fazı kendi üretir: ölçü motor durdurulup yapılır"),
        T("Sargı dirençleri", "Enerjisizken, üç uç arasında", "üçü eşit", "yanmış sargının direnci farklıdır; megerle gövdeye kaçak aranır"),
    ]
    ys = [k * 0.05 for k in range(0, 25)]
    uc3 = [M.calisma(par, x, 1.0, 0j, 1.0, fan) for x in ys]; tk = [calis_tek(par, x, fan) for x in ys]
    g1 = {"baslik": "Yüke göre hat akımı: üç faz ve iki faz", "x_ad": "Yük momenti (% anma)", "y_ad": "Hat akımı (× In)", "ymin": 0,
          "seriler": [{"ad": "üç fazla", "renk": "#15803d", "pts": pts([x * 100 for x in ys], [abs(q["i1"]) / a0["i"] for q in uc3], 2)}, {"ad": "iki fazla", "renk": "#dc2626", "pts": pts([x * 100 for x in ys], [q["hat"] / a0["i"] for q in tk], 2)},
                      {"ad": "en yüklü sargı (Δ)", "renk": "#7c3aed", "kesik": True, "pts": pts([x * 100 for x in ys], [2 * abs(q["i1"]) / a0["i"] for q in tk], 2)}],
          "yatay": [{"y": ayar, "etiket": "termik ayarı", "renk": "#94a3b8"}], "isaretler": [{"x": yuk * 100, "etiket": "yük"}]}
    ss = [0.002 * 1.07 ** k for k in range(95) if 0.002 * 1.07 ** k < 1.0] + [1.0]
    g2 = {"baslik": "Moment – hız: üç faz ve iki faz", "x_ad": "Hız (% senkron hız)", "y_ad": "Moment (% anma)",
          "seriler": [{"ad": "üç fazla", "renk": "#15803d", "pts": pts([(1 - x) * 100 for x in ss], [M.moment(par, x)["m"] / a0["m"] * 100 for x in ss], 1)},
                      {"ad": "iki fazla", "renk": "#dc2626", "pts": pts([(1 - x) * 100 for x in ss], [tek_faz(par, x)["m"] / a0["m"] * 100 for x in ss], 1)},
                      {"ad": "yük", "renk": "#64748b", "kesik": True, "pts": pts([(1 - x) * 100 for x in ss], [yuk * ((1 - x) ** 2 if fan else 1) * 100 for x in ss], 1)}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "Bir hat kesilince motor iki uçtan, yani tek fazdan beslenir. Statorun alanı artık dönmez; bir eksen boyunca titreşir. Titreşen alan, zıt yönde dönen iki alanın toplamıdır.",
            ("Motor duruyorsa bu iki alan rotoru eşit kuvvetle zıt yönlere çeker: moment yoktur. Motor uğuldar, kalkış akımının yaklaşık 0,87 katını çeker ve saniyeler içinde ısınır." if an_ == "dururken" else
             "Motor dönüyorsa ileri alana göre kayma küçük, geri alana göre büyüktür (≈ 2): ileri alanın momenti baskındır ve motor dönmeye devam eder. Ama devrilme momenti yarıya inmiştir; yük ağırsa motor devrilir." if an_ == "calisirken" else
             "Kopma yokken üç hat eşit akım taşır, alan daireseldir."),
            (f"Aynı mekanik gücü iki hat taşır: hat akımı {fnum(i3, 2)} × In'den {fnum(max(hat), 2)} × In'e çıktı. Kayma da büyüdü: rotor hem ileri alanın artan akımıyla hem geri alanın yüksek frekanslı akımıyla ısınıyor." if an_ == "calisirken" and not dev else
             "Kalkamayan ya da devrilen motor kilitli rotor durumundadır: bütün giriş gücü ısıya dönüşür." if dev else "Yükü artırıp kopmayı seçin: akımın ve kaymanın nasıl sıçradığını görün."),
            ("Üçgen bağlı sargıda iş daha sinsidir. Açık olmayan iki hattın arasındaki sargı tek başına gerilimin tamamını görür; öbür iki sargı seri kalır ve gerilimi paylaşır. Akımın üçte ikisi tek sargıdan geçer: o sargı öbürlerinin dört katı ısınır." if ucgen else
             "Yıldız bağlı sargıda kalan iki sargı seri kalır ve aynı akımı taşır: ikisi birlikte ısınır, üçüncüsü soğuk kalır. Sargı akımı hat akımına eşittir; termik röle sargının gördüğünü görür."),
            ("Termik röle hat akımını ölçer. Üçgen motor yarı yükte iki faza kaldığında hat akımı ayarın altında kalabilir, ama içerideki bir sargı anma akımının üstündedir: röle açmaz, sargı yanar. Faz kaybına duyarlı röle akımların eşit olmadığını algılayıp eşiğini düşürür."
             if ucgen else "Yıldızda hat akımı ayarı aştığında röle açar; hafif yükte akım ayarın altındaysa sargı da anma akımının altındadır. Tehlike, yük ağırken rölenin geç kalmasıdır."),
            "Çalışan motor eksik fazın gerilimini kendisi üretir: klemensinde üç faz arası da gerilim ölçülebilir. Bu yüzden gerilim rölesi motorla kendisi arasındaki bir kopmayı görmez; kesin belirti akımdır.",
        ],
        "dersler": [
            "İki faza kalan motor dururken kalkamaz, dönerken dönmeye devam eder: arıza bu yüzden geç fark edilir.",
            "Hat akımı ≈ √3 katına çıkar; üçgende bir sargı bunun da üstünde yüklenir ve ilk o yanar.",
            "Yanmış bir motorda tek sargı (Δ) ya da iki sargı (Y) kavrulmuşsa neden faz kaybıdır; üçü birden kavrulmuşsa aşırı yüktür.",
            "Faz kaybını en iyi akım dengesizliği koruması yakalar; gerilim rölesi kopmanın yerine göre görmeyebilir.",
            "Sigortalı motor devresinde tek sigortanın atması faz kaybıdır: üç kutbu birlikte açan koruma kullanılır.",
        ],
        "tablolar": [{"baslik": "Bağlantıya göre iki fazda sargı akımları (anma sargı akımının katı)", "cols": ["Yük", "Hat akımı", "Δ: en yüklü sargı", "Δ: öbür iki sargı", "Y: iki sargı", "Termik (duyarsız)"],
                      "rows": [[f"%{int(x * 100)}", ("devrilir" if q["devrildi"] else f"{fnum(q['hat'] / a0['i'], 2)} × In"), f"× {fnum(2 * abs(q['i1']) / a0['i'], 2)}", f"× {fnum(abs(q['i1']) / a0['i'], 2)}", f"× {fnum(q['hat'] / a0['i'], 2)}",
                                ("açmaz" if termik(q["hat"] / a0["i"] / ayar) is None else f"{fnum(termik(q['hat'] / a0['i'] / ayar), 0)} s")] for x in (0.25, 0.5, 0.75, 1.0) for q in [calis_tek(par, x, fan)]],
                      "not": "Üçgen motorda %50 yük dolayında hat akımı termik ayarının altındayken en yüklü sargı anma akımını aşar: klasik «hafif yükte yanan motor» durumu."}],
    }
