"""OG kablo boyu: kablo bir iletken olduğu kadar bir kondansatördür. Boy arttıkça şarj akımı, ürettiği kapasitif reaktif güç, toprak arızasındaki kapasitif akım ve
boştaki uç geriliminin yükselmesi büyür; gerilim düşümü ve hat sonu kısa devre akımı değişir.

Model: nominal π devresi (R, X seri; C/2 iki uçta). Kablo kapasiteleri ve reaktansları katalog mertebesindedir (tahmini); iletken dirençleri çizelge değerleridir (dogrulanacak).
XLPE iletken sıcaklığı 90 °C: TEDAŞ-MLZ/96-018.B. Reaktif enerji sınırları (endüktif %20, kapasitif %15) tarife uygulamasından bellekle (dogrulanacak). Besleyen trafo merkezinin
OG nötr direnci toprak arıza akımını ≈ 1000 A ile sınırlar (ikincil)."""
from __future__ import annotations

import cmath
import math

from . import kablo as KB
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, logsp, num, opt, pts

ID = "boy_og"
BASLIK = "OG kablo boyu"
IKON = "🧶"
GIRIS = ("Orta gerilim kablosunun iletkeni ile ekranı arasında birkaç milimetre yalıtkan vardır: kablo, boyu kadar uzun bir kondansatördür. Yük olmasa da akım çeker, şebekeye "
         "kapasitif reaktif güç verir, toprak arızasında yere akım akıtır. Boyu ve kesiti değiştirin; uzun kablonun getirdiklerini izleyin.")

KONTROLLER = [
    ctl("un", "Şebeke gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("s", "Kesit (tek damarlı XLPE)", "sec", 95, secenek=opt(*[(k, f"{k} mm²") for k in KB.OG_KESIT])),
    ctl("metal", "İletken", "sec", "cu", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum"))),
    ctl("l", "Kablo boyu", "sayi", 3.0, min=0.05, max=40, adim=0.05, birim="km"),
    ctl("i", "Yük akımı (hat sonunda)", "sayi", 60, min=0, max=600, adim=5, birim="A"),
    ctl("cos", "Yükün güç katsayısı", "sayi", 0.95, min=0.7, max=1.0, adim=0.01),
    ctl("sk", "Kaynakta kısa devre gücü", "sayi", 350, min=50, max=1500, adim=10, birim="MVA"),
    ctl("notr", "Şebekenin OG nötrü", "sec", "direnc", secenek=opt(("direnc", "Direnç üzerinden topraklı (≈ 1000 A)"), ("yalitilmis", "Yalıtılmış"), ("petersen", "Söndürme bobinli (Petersen)"))),
    ctl("devre", "Aynı baradan çıkan öbür kabloların toplam boyu", "sayi", 10, min=0, max=200, adim=1, birim="km", yardim="Toprak arızasında bütün sağlam fiderlerin kapasitif akımı arıza yerine akar"),
]


def run(p: dict) -> dict:
    un, s, metal, l, i, cosf = num(p, "un", 34.5), num(p, "s", 95), str(p.get("metal", "cu")), num(p, "l", 3.0), num(p, "i", 60), num(p, "cos", 0.95)
    sk, notr, diger = num(p, "sk", 350), str(p.get("notr", "direnc")), num(p, "devre", 10)
    u0 = un * 1000 / math.sqrt(3)
    r, x, c_km = KB.r_km(s, metal, 90.0), KB.OG_X[s], KB.OG_C[s] * (1.0 if un > 20 else 1.5)          # düşük gerilimde yalıtkan ince: kapasite büyür
    w = 100 * math.pi
    ic = w * c_km * 1e-6 * u0 * l                                   # şarj akımı (A)
    qc = math.sqrt(3) * un * ic                                      # kvar
    z = complex(r, x) * l
    sinf = math.sqrt(1 - cosf * cosf)
    du = math.sqrt(3) * i * (r * cosf + x * sinf) * l / (un * 1000) * 100
    zs = (un ** 2 / sk) * complex(0.1, 0.995)
    ik3 = un / (math.sqrt(3) * abs(zs + z))                           # kA
    ik3_0 = un / (math.sqrt(3) * abs(zs))
    ferranti = (1 / (1 - (w * w * (x / w) * c_km * 1e-6 * l * l) / 2) - 1) * 100
    ice = 3 * w * c_km * 1e-6 * u0 * l                                # bu kablonun toprak arıza kapasitif akımı (A)
    ice_top = 3 * w * c_km * 1e-6 * u0 * (l + diger)
    iz = KB.OG_IZ_CU[s] * (0.78 if metal == "al" else 1.0)
    p_yuk = math.sqrt(3) * un * i * cosf                              # kW
    q_yuk = math.sqrt(3) * un * i * sinf
    q_net = q_yuk - qc
    kap_oran = max(-q_net, 0) / p_yuk * 100 if p_yuk > 0 else (100.0 if qc > 0 else 0.0)
    zc = math.sqrt((x / w) / (c_km * 1e-6))                            # dalga empedansı (Ω)
    i_kapama = un * 1000 * math.sqrt(2 / 3) / math.sqrt((abs(zs) / w) / (c_km * 1e-6 * l)) if l > 0 else 0          # kapama akımı tepesi (A): kaynak endüktansı – kablo kapasitesi salınımı
    f_kapama = 1 / (2 * math.pi * math.sqrt((abs(zs) / w) * c_km * 1e-6 * l)) if l > 0 else 0
    i_toprak = 1000.0 if notr == "direnc" else ice_top if notr == "yalitilmis" else 0.1 * ice_top
    c = Cizim(900, 300)
    c.kutu(20, 60, 120, 54, "OG bara", f"{fnum(sk, 0)} MVA")
    c.dikdortgen(160, 77, 22, 20, "cizgi", "#fff")
    xe = 182 + min(max(l * 40, 120), 500)
    c.hat(f"M140,87 H160", "L1", hot=True, w=3); c.hat(f"M182,87 H{xe}", "L1", hot=i > 0 or ic > 0, w=3)
    c.hat(f"M182,117 H{xe}", "toprak", w=2, kesik=True); c.yazi(190, 132, "ekran (topraklı)", "#7c5a36", 9.5)
    for k in range(5):
        xx = 182 + (xe - 182) * (k + 0.5) / 5
        c.kap(xx, 90, 114, "mavi")
    c.yazi((182 + xe) / 2, 74, f"{fnum(l, 2)} km · 3 × 1 × {fnum(s, 0)} mm² {'Al' if metal == 'al' else 'Cu'} XLPE", "#334155", 11.5, kalin=True, anchor="middle")
    c.kutu(xe, 60, 120, 54, "Yük", f"{fnum(i, 0)} A" if i > 0 else "boşta")
    c.yazi(40, 172, f"Şarj akımı {fa(ic, 1)} — yük olmasa da akar · kapasitif reaktif güç {fnum(qc, 0)} kvar", "#1d4ed8", 12.5, kalin=True)
    c.yazi(40, 196, f"Toprak arızasında bu kablonun kapasitif akımı {fa(ice, 1)}; bütün şebeke {fa(ice_top, 0)}", "#b91c1c" if ice_top > 50 else "#334155", 12.5)
    c.yazi(40, 220, f"Gerilim düşümü %{fnum(du, 2)} · hat sonu kısa devre {fnum(ik3, 1)} kA (başta {fnum(ik3_0, 1)} kA)", "#334155", 12)
    c.yazi(40, 244, f"Boşta uç gerilimi yükselmesi %{fnum(ferranti, 2)} · kapama akımı tepesi ≈ {fnum(i_kapama, 0)} A, {fnum(f_kapama, 0)} Hz", "#334155", 12)
    c.yazi(40, 272, ("Yük az: tesis şebekeye kapasitif reaktif veriyor (%" + fnum(kap_oran, 0) + ")" if q_net < 0 else "Yükün endüktif reaktifi kablonun kapasitifini aşıyor"), "#b91c1c" if kap_oran > 15 else "#64748b", 11.5, kalin=kap_oran > 15)
    ozet = [
        K("Şarj akımı", fa(ic, 1), "warn" if ic > 0.2 * max(i, 1) else "info", f"{fnum(ic / l, 2)} A/km · C = {fnum(c_km, 2)} µF/km"),
        K("Kapasitif reaktif güç", f"{fnum(qc, 0)} kvar", "warn" if kap_oran > 15 else "info", f"{fnum(qc / l, 0)} kvar/km · kapasitif oran %{fnum(kap_oran, 0)}"),
        K("Toprak arıza kapasitif akımı", fa(ice_top, 0), "warn" if ice_top > 50 else "info", f"bu kablo {fa(ice, 1)}" + (" · nötr direnci ≈ 1000 A ekler" if notr == "direnc" else "")),
        K("Gerilim düşümü", f"%{fnum(du, 2)}", "bad" if du > 5 else "ok", f"{fnum(i, 0)} A, cosφ {fnum(cosf, 2)}"),
        K("Hat sonu kısa devre", f"{fnum(ik3, 1)} kA", "info", f"başta {fnum(ik3_0, 1)} kA"),
    ]
    kontroller = [
        C("Yük akımı kablonun akım taşıma kapasitesinin içinde mi?", f"{fnum(math.hypot(i, ic), 0)} A (yük + şarj)", f"≤ {fnum(iz, 0)} A", math.hypot(i, ic) <= iz, "Toprakta yonca demet için tipik değer; iletken sıcaklığı 90 °C — TEDAŞ-MLZ/96-018.B böl. 2.2.2.2 (sıcaklık); kapasite değeri katalog mertebesi", "tahmini"),
        C("Gerilim düşümü", f"%{fnum(du, 2)}", "≤ %5 (OG dağıtımda kabul edilen sınır)", du <= 5.0, "OG fiderlerinde gerilim düşümü dağıtım şirketinin ölçütüyle sınırlanır; tipik %5", "ikincil"),
        C("Kapasitif reaktif oran", f"%{fnum(kap_oran, 0)}", "≤ %15 (aylık kapasitif reaktif / aktif)", kap_oran <= 15.0, "Uzun kablolu ve az yüklü tesiste (gece, GES) kablonun ürettiği reaktif cezaya yol açar; çare şönt reaktör — sınır değeri asıl metinle doğrulanacak", "dogrulanacak"),
        C("Toprak arızasında kapasitif akım", fa(ice_top, 0), "yalıtılmış şebekede kendiliğinden sönme için ≲ 30–50 A" if notr != "direnc" else "nötr direnci akımına eklenir", (ice_top <= 50) if notr == "yalitilmis" else None,
          "Yalıtılmış şebekede arıza akımı, bütün fiderlerin kapasitif akımlarının toplamıdır; kablo şebekesi büyüdükçe ark kendiliğinden sönmez ve söndürme bobini ya da nötr direnci gerekir", "ikincil"),
        C("Sağlam fiderin toprak koruması", f"bu fider arıza yokken {fa(ice, 1)} kapasitif akım verir", "duyarlı toprak ayarı bunun üstünde ya da yönlü", None, "Başka bir fiderdeki toprak arızasında bu kablonun kapasitif akımı kendi rölesinden geçer: yönsüz duyarlı ayar yanlış açtırır — Röle laboratuvarı › Toprak arızasında fiderler", "ikincil"),
    ]
    girdiler = [
        G("Kablo", f"3 × 1 × {fnum(s, 0)} mm² {'Al' if metal == 'al' else 'Cu'} XLPE · {fnum(l, 2)} km", "Proje, kablo etiketi", "Direnç, reaktans ve kapasite boyla doğru orantılıdır", f"r = {fnum(r, 3)} · x = {fnum(x, 3)} Ω/km · C = {fnum(c_km, 2)} µF/km"),
        G("Şebeke", f"{fnum(un, 1)} kV · {fnum(sk, 0)} MVA · nötr: {notr}", "Bağlantı görüşü; trafo merkezi tek hat şeması", "Kısa devre ve toprak arıza akımını belirler", "Zs = U² / Sk″"),
        G("Yük", f"{fnum(i, 0)} A · cosφ {fnum(cosf, 2)}", "Yük eğrisi (gündüz ve gece)", "Gerilim düşümü yükle, kapasitif oran yüksüzlükle büyür", "Q(net) = Q(yük) − Q(kablo)"),
    ]
    adimlar = [
        A("Şarj akımı", "Ic = ω · C · Uo · L", f"314 × {fnum(c_km, 2)} µF/km × {fnum(u0 / 1000, 1)} kV × {fnum(l, 2)} km", fa(ic, 1), "kondansatör akımı", "hesap", ["Kablo"]),
        A("Kapasitif reaktif güç", "Qc = √3 · U · Ic", f"1,732 × {fnum(un, 1)} × {fnum(ic, 1)}", f"{fnum(qc, 0)} kvar", "yükten bağımsız, hep vardır", "hesap"),
        A("Gerilim düşümü", "ΔU% = √3·I·L·(r·cosφ + x·sinφ) / U", f"{fnum(i, 0)} A × {fnum(l, 2)} km", f"%{fnum(du, 2)}", "kısa hat yaklaşımı", "hesap", ["Yük"]),
        A("Hat sonu kısa devre akımı", "Ik″ = U / (√3 · |Zs + Z(kablo)|)", f"Zs = {fnum(abs(zs), 2)} Ω · Z(kablo) = {fnum(abs(z), 2)} Ω", f"{fnum(ik3, 1)} kA", "empedanslar seri", "hesap", ["Şebeke"]),
        A("Toprak arıza kapasitif akımı", "Ice = 3 · ω · C · Uo · L", f"3 × {fnum(ic, 1)} A (bu kablo); şebeke toplamı L = {fnum(l + diger, 1)} km", f"{fa(ice, 1)} · toplam {fa(ice_top, 0)}", "arızalı fazın gerilimi sıfır, sağlam fazlarınki √3 kat olur", "hesap"),
        A("Boşta uç gerilimi (Ferranti)", "U2 / U1 = 1 / (1 − ω²·L′·C′·l² / 2)", f"L′ = {fnum(x / w * 1000, 2)} mH/km", f"+%{fnum(ferranti, 2)}", "şarj akımı seri reaktansta gerilimi yükseltir; kabloda küçük, uzun havai hatta büyük", "hesap"),
        A("Kapama akımı", "î ≈ Û / √(Ls / C) · f = 1 / (2π·√(Ls·C))", f"Ls = {fnum(abs(zs) / w * 1000, 1)} mH · C = {fnum(c_km * l, 2)} µF", f"≈ {fnum(i_kapama, 0)} A tepe, {fnum(f_kapama, 0)} Hz", "kaynak endüktansı ile kablo kapasitesinin salınımı", "hesap"),
    ]
    ayarlar = [
        S("Toprak koruması", "yönlü (67N) ya da ayar > fiderin kendi kapasitif akımı" if notr != "direnc" else "Io> nötr direnci akımının altında, fiderin kapasitif akımının üstünde", f"bu fider: {fa(ice, 1)}", "Sağlam fiderin yanlış açmaması için", "Röle laboratuvarı › Toprak arızasında fiderler", "ikincil"),
        S("Şönt reaktör / kompanzasyon", f"≈ {fnum(qc, 0)} kvar endüktif" if kap_oran > 15 else "gerekmiyor", "—", "Kablonun ürettiği reaktifi yerinde tüketir", "saha pratiği", "ikincil"),
        S("Kesicinin kablo şarj akımı kesme yeteneği", f"≥ {fa(ic, 1)}", "—", "Boştaki kabloyu açarken yeniden tutuşma olmamalı", "Röle laboratuvarı › Kesici ve ark", "ikincil"),
        S("Ekran topraklaması", "kısa hatta iki uçtan; uzun ve yüklü hatta çapraz bağlama", "—", "Ekranda endüklenen gerilim ve dolaşım akımı boyla artar", "Topraklama laboratuvarı › OG kablo ekranı", "ikincil"),
    ]
    test = [
        T("Boşta akım", "Hat sonu açıkken fider ampermetresi / röle ölçüsü", f"≈ {fa(ic, 1)} (üç fazda eşit, gerilimden 90° ileride)", "ölçü akım trafosunun alt sınırına yakınsa röle göstermez"),
        T("Kablo kapasitesi", "Tan δ / VLF cihazı ile", f"≈ {fnum(c_km * l, 2)} µF (faz başına)", "VLF cihazının gücü bu kapasiteye yetmeli — Topraklama laboratuvarı › Kablo deneyleri"),
        T("Reaktif sayaç", "Gece ve hafta sonu kapasitif endeks", f"yük yokken ≈ {fnum(qc, 0)} kvar kapasitif", "ceza sınırı aylık orana göredir"),
    ]
    ls = logsp(0.1, 40, 45)
    g1 = {"baslik": "Boya göre şarj akımı ve toprak arıza kapasitif akımı", "x_ad": "Kablo boyu (km)", "y_ad": "Akım (A)", "logx": True, "logy": True,
          "seriler": [{"ad": "şarj akımı (faz başına)", "renk": "#1a4d8f", "pts": pts(ls, [w * c_km * 1e-6 * u0 * q for q in ls], 2)}, {"ad": "toprak arıza kapasitif akımı (bu kablo)", "renk": "#dc2626", "pts": pts(ls, [3 * w * c_km * 1e-6 * u0 * q for q in ls], 2)}],
          "isaretler": [{"x": l, "etiket": "boy"}]}
    g2 = {"baslik": "Boya göre gerilim düşümü ve hat sonu kısa devre akımı", "x_ad": "Kablo boyu (km)", "y_ad": "ΔU (%) · Ik″ (kA)", "logx": True, "ymin": 0,
          "seriler": [{"ad": "gerilim düşümü (%)", "renk": "#b45309", "pts": pts(ls, [math.sqrt(3) * i * (r * cosf + x * sinf) * q / (un * 1000) * 100 for q in ls], 3)},
                      {"ad": "hat sonu Ik″ (kA)", "renk": "#7c3aed", "pts": pts(ls, [un / (math.sqrt(3) * abs(zs + complex(r, x) * q)) for q in ls], 3)}], "isaretler": [{"x": l, "etiket": "boy"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "OG kablosunda iletkenin çevresinde birkaç milimetre XLPE, onun da çevresinde topraklı bir ekran vardır: iki iletken yüzey arasında yalıtkan, yani bir kondansatör. Kapasitesi kilometre başına 0,1–0,3 µF'tır.",
            f"Bu kondansatör şebeke gerilimine bağlı olduğu sürece akım çeker: {fnum(l, 2)} km'de faz başına {fa(ic, 1)}. Bu akım yüke gitmez, gerilimden 90° ileridedir ve kabloyu şebekeye kapasitif reaktif güç veren bir kaynağa çevirir: {fnum(qc, 0)} kvar.",
            ("Gündüz yükün endüktif reaktifi bunu örter. Gece, hafta sonu ya da tesis az yüklüyken örtmez: sayaç kapasitif yazar. Uzun kablolu GES'lerde ve az yüklü OG abonelerinde kapasitif reaktif cezanın kaynağı budur."
             if kap_oran > 5 else "Bu yükte kablonun kapasitif reaktifi yükün endüktif reaktifinin altında kalıyor."),
            f"Toprak arızasında kapasite başka bir rol oynar. Arızalı fazın gerilimi sıfıra iner, sağlam iki fazınki faz arası gerilime çıkar; bu iki fazın kapasiteleri üzerinden yere akım akar. Bu kablonun katkısı {fa(ice, 1)}, baradaki bütün kabloların {fa(ice_top, 0)}.",
            ("Nötr yalıtılmışsa arıza akımı yalnız bu kapasitif akımdır: küçükse ark kendiliğinden söner, şebeke çalışmaya devam eder. Kablo şebekesi büyüdükçe akım büyür, ark sönmez; söndürme bobini bu akımı endüktif akımla götürür."
             if notr != "direnc" else "Nötr direnç üzerinden topraklıysa arıza akımını direnç belirler (≈ 1000 A) ve kapasitif akım buna eklenir. Sağlam fiderlerin röleleri yine kendi kapasitif akımlarını görür: ayar bunun üstünde olmalıdır."),
            f"Boy uzadıkça gerilim düşümü artar (%{fnum(du, 2)}) ve hat sonundaki kısa devre akımı düşer ({fnum(ik3_0, 1)} → {fnum(ik3, 1)} kA). OG'de AG'deki kadar sert değildir, ama uzun fiderin sonunda koruma ayarı bu küçük akımı görmelidir.",
            "Boştaki kablo enerjilendiğinde kapasitesi kaynağın endüktansı üzerinden dolar: kısa süreli, yüksek frekanslı bir akım darbesi akar. Açarken ise kesici küçük bir kapasitif akımı keser; kontaklar arasında gerilim iki katına çıkar, yeniden tutuşma olursa aşırı gerilim doğar.",
        ],
        "dersler": [
            "OG kablosu kilometre başına 1–1,5 A şarj akımı çeker (34,5 kV) ve 60–90 kvar kapasitif reaktif üretir.",
            "Az yüklü, uzun kablolu tesiste sayaç kapasitif yazar: çare şönt reaktördür.",
            "Toprak arızasında kapasitif akım = 3 × şarj akımı; bütün sağlam fiderlerinki arıza yerinde toplanır.",
            "Sağlam fiderin toprak rölesi kendi kapasitif akımını görür: duyarlı ayar yönlü olmalıdır.",
            "Kabloda Ferranti yükselmesi küçüktür; asıl etki şarj akımı ve reaktif güçtür.",
        ],
        "tablolar": [{"baslik": f"Kesite göre kilometre başına değerler ({fnum(un, 1)} kV, XLPE)", "cols": ["Kesit", "r (Ω/km, 90 °C)", "x (Ω/km)", "C (µF/km)", "Şarj akımı (A/km)", "Qc (kvar/km)", "Akım taşıma (A)"],
                      "rows": [[f"{k} mm²" + (" ◀" if k == s else ""), fnum(KB.r_km(k, metal, 90.0), 3), fnum(KB.OG_X[k], 3), fnum(KB.OG_C[k] * (1.0 if un > 20 else 1.5), 2),
                                fnum(w * KB.OG_C[k] * (1.0 if un > 20 else 1.5) * 1e-6 * u0, 2), fnum(math.sqrt(3) * un * w * KB.OG_C[k] * (1.0 if un > 20 else 1.5) * 1e-6 * u0, 0), fnum(KB.OG_IZ_CU[k] * (0.78 if metal == "al" else 1.0), 0)] for k in KB.OG_KESIT],
                      "not": "Kapasite, reaktans ve akım taşıma değerleri katalog mertebesindedir; gerçek değer kablo üreticisinin veri sayfasından alınır."}],
    }
