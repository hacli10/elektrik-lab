"""Gölge ve köprüleme (bypass) diyotları: seri bağlı hücrelerde akımı en az ışık alan hücre belirler. Köprüleme diyodu gölgeli alt diziyi devre dışı bırakarak dizinin geri
kalanını kurtarır; bedeli güç–gerilim eğrisinde birden çok tepe ve gölgeli hücrede ısınmadır (sıcak nokta).

Model: elab/guc/pv_model.py — her modül üç alt dizi (her birinde bir köprüleme diyodu); dizinin eğrisi alt dizilerin gerilimleri toplanarak bulunur. Diyotsuz (ya da diyodu
açık devre arızalı) durumda gölgeli hücreler ters kutuplanır; ters yön eğimi ve sıcak nokta gücü mertebedir (tahmini). Modül değerleri tipik veri sayfası mertebesidir (tahmini).
Dayanak (metinden): TEDAŞ LÜY 50 kWe GES Tip Şartnamesi böl. 2.3.4.1 (farklı yön ve eğimdeki diziler ayrı MPPT girişlerine bağlanır; aynı MPPT'ye bağlamak sistem performansını
önemli ölçüde düşürür; eviricinin MPP gerilim aralığı)."""
from __future__ import annotations

from . import pv_model as PV
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, num, opt, pts

ID = "golge"
BASLIK = "Gölge ve köprüleme diyotları"
IKON = "🌥️"
GIRIS = ("Seri bağlı hücreler bir zincirin halkalarıdır: en az ışık alan hücre bütün dizinin akımını kısar. Modülün içindeki üç köprüleme diyodu gölgeli bölümü atlatır. "
         "Gölgeli modül sayısını, gölgenin koyuluğunu ve diyotların durumunu değiştirin; güç eğrisindeki tepeleri ve eviricinin hangisine oturduğunu izleyin.")

GES = "TEDAŞ LÜY 50 kWe GES Tip Şartnamesi"

KONTROLLER = [
    ctl("modul", "Modül", "sec", "m550", secenek=PV.secenek()),
    ctl("n", "Dizideki modül sayısı", "sayi", 18, min=6, max=28, adim=1),
    ctl("ng", "Gölgeli modül sayısı", "sayi", 3, min=0, max=28, adim=1),
    ctl("alt", "Gölgeli modülde gölgelenen alt dizi", "sec", 3, secenek=opt((1, "1 / 3 (ör. yatay modülde alt kenar, yaprak, kuş pisliği)"), (2, "2 / 3"), (3, "3 / 3 (modülün tamamı)"))),
    ctl("oran", "Gölgedeki ışınım (açıktakinin yüzdesi)", "sayi", 20, min=5, max=90, adim=5, birim="%", yardim="Koyu gölgede yalnız yayılı ışık kalır: ≈ %10–25"),
    ctl("g", "Açıktaki ışınım", "sayi", 1000, min=200, max=1200, adim=50, birim="W/m²"),
    ctl("bypass", "Köprüleme diyotları", "sec", "saglam", secenek=opt(("saglam", "Sağlam"), ("acik", "Yok / açık devre arızalı"), ("kisa", "Gölgeli modüllerde kısa devre arızalı"))),
    ctl("izleme", "Eviricinin en büyük güç izlemesi", "sec", "genel", secenek=opt(("genel", "Gölge taramalı: en yüksek tepeyi bulur"), ("yerel", "Yalın: gerilimi yüksek olan ilk tepede kalır"))),
    ctl("vmin", "Eviricinin MPPT alt gerilimi", "sayi", 200, min=100, max=600, adim=10, birim="V"),
]


def run(p: dict) -> dict:
    mk = str(p.get("modul", "m550")); m = PV.MODUL.get(mk, PV.MODUL["m550"])
    n = int(num(p, "n", 18)); ng = int(min(num(p, "ng", 3), n)); alt = int(num(p, "alt", 3)); oran, g = num(p, "oran", 20), num(p, "g", 1000)
    byp, izl, vmin = str(p.get("bypass", "saglam")), str(p.get("izleme", "genel")), num(p, "vmin", 200)
    alt = min(max(alt, 1), 3)
    tc = PV.hucre_sicakligi(25, g, m["noct"])
    acik_n = PV.nokta(m, g, tc, PV.N_ALT)
    golge_n = PV.nokta(m, g * oran / 100, tc, PV.N_ALT)
    n_g = ng * alt                                   # gölgeli alt dizi
    n_a = n * PV.N_ALT - n_g
    tam = PV.dizi_egri([(n * PV.N_ALT, acik_n)])
    p_tam = max(tam["p"])
    if byp == "kisa":
        e = PV.dizi_egri([(n_a, acik_n)]) if n_a > 0 else {"v": [0.0], "i": [0.0], "p": [0.0]}          # kısa devre diyot: alt dizi hiç gerilim vermez
    else:
        gr = ([(n_a, acik_n)] if n_a > 0 else []) + ([(n_g, golge_n)] if n_g > 0 else [])
        e = PV.dizi_egri(gr, bypass=byp)
    tp = PV.tepeler(e) or [(0.0, 0.0, 0.0)]
    genel = max(tp, key=lambda q: q[2])
    yerel = max(tp, key=lambda q: q[0])                 # gerilimi en yüksek tepe
    pencere = [q for q in tp if q[0] >= vmin]
    if izl == "genel":
        cal = max(pencere, key=lambda q: q[2]) if pencere else yerel
    else:
        cal = yerel
    v_c, i_c, p_c = cal
    kayip = (1 - p_c / p_tam) * 100 if p_tam > 0 else 0.0
    alan_g = n_g / (n * PV.N_ALT) * (1 - oran / 100) * 100          # yitirilen ışınımın payı
    iletiyor = byp == "saglam" and n_g > 0 and i_c > golge_n["isc"]
    p_diyot = i_c * PV.V_DIYOT if iletiyor else 0.0
    hucre_alt = m["ns"] // PV.N_ALT
    # sıcak nokta: gölgeli hücre, alt dizideki öbür hücrelerin gerilimiyle ters kutuplanır ve kendi (azalmış) akımını taşır
    if n_g > 0 and i_c > golge_n["isc"] and byp != "kisa":
        v_ters = (hucre_alt - 1) * acik_n["vmp"] / hucre_alt if byp == "saglam" else min((i_c - golge_n["isc"]) * PV.R_TERS, 25.0 * acik_n["voc"])
        p_sicak = v_ters * (golge_n["isc"] if byp == "saglam" else i_c)
    else:
        v_ters, p_sicak = 0.0, 0.0
    cz = Cizim(900, 320)
    w = min(40.0, 800.0 / n); x0 = 50
    for k in range(n):
        xx = x0 + k * w
        gol = k < ng
        for a in range(3):
            koyu = gol and a < alt
            cz.dikdortgen(xx + 1, 60 + a * 30, w - 3, 28, "cizgi", ("#475569" if koyu else "#1e3a8a"), kw=0.8, r=2)
        if gol and iletiyor:
            cz.hat(f"M{xx + w / 2:.0f},54 q0,-12 {w / 2:.0f},-12", "ariza", w=1.5)
    cz.hat(f"M{x0},105 H40 V190 H120", "L1", hot=i_c > 0.05, w=2.5)
    cz.hat(f"M{x0 + n * w:.0f},105 H{min(x0 + n * w + 14, 880):.0f} V210 H240", "N", hot=i_c > 0.05, w=2.5)
    cz.kutu(120, 172, 120, 50, "Evirici", f"{fnum(v_c, 0)} V · {fnum(i_c, 1)} A")
    cz.yazi(50, 46, f"{n} modül seri" + (f" · {ng} modülün {alt}/3'ü gölgede (ışınım %{fnum(oran, 0)})" if ng else " · gölge yok"), "#334155", 11.5, kalin=True)
    cz.yazi(280, 186, f"Dizi gücü {fnum(p_c / 1000, 2)} kW — gölgesiz {fnum(p_tam / 1000, 2)} kW (kayıp %{fnum(kayip, 0)})", "#b91c1c" if kayip > 2 * alan_g + 5 else "#15803d", 13, kalin=True)
    cz.yazi(280, 210, f"Gölge ışınımın %{fnum(alan_g, 0)} kadarını kesiyor; güç kaybı %{fnum(kayip, 0)}", "#334155", 12)
    cz.yazi(280, 234, (f"{n_g} köprüleme diyodu iletimde: her biri {fnum(p_diyot, 1)} W ısınıyor" if iletiyor else "Köprüleme diyotları iletimde değil" if byp == "saglam"
                       else "Diyot yok: gölgeli hücreler bütün dizinin akımını kısıyor" if byp == "acik" else "Kısa devre diyot: o alt diziler hiç üretmiyor"), "#64748b", 12)
    cz.yazi(280, 258, f"Güç eğrisinde {len(tp)} tepe · evirici {fnum(v_c, 0)} V'taki tepede" + (" (en yüksek tepe değil)" if p_c < 0.98 * genel[2] else ""), "#b45309" if p_c < 0.98 * genel[2] else "#64748b", 12)
    cz.yazi(280, 282, (f"Gölgeli hücrede sıcak nokta gücü ≈ {fnum(p_sicak, 0)} W (ters gerilim {fnum(v_ters, 0)} V)" if p_sicak > 1 else "Gölgeli hücrelerde ters kutuplanma yok"), "#b91c1c" if p_sicak > 60 else "#64748b", 12)
    ozet = [
        K("Dizi gücü", f"{fnum(p_c / 1000, 2)} kW", "bad" if kayip > 30 else "warn" if kayip > 8 else "ok", f"gölgesiz {fnum(p_tam / 1000, 2)} kW"),
        K("Güç kaybı", f"%{fnum(kayip, 0)}", "bad" if kayip > 2 * alan_g + 5 else "info", f"gölgenin kestiği ışınım %{fnum(alan_g, 0)}"),
        K("Güç eğrisindeki tepe sayısı", f"{len(tp)}", "warn" if len(tp) > 1 else "ok", f"en yüksek tepe {fnum(genel[0], 0)} V · {fnum(genel[2] / 1000, 2)} kW"),
        K("Çalışma noktası", f"{fnum(v_c, 0)} V · {fnum(i_c, 1)} A", "warn" if p_c < 0.98 * genel[2] else "info", "en yüksek tepe" if p_c >= 0.98 * genel[2] else "yerel tepe"),
        K("Sıcak nokta", f"≈ {fnum(p_sicak, 0)} W" if p_sicak > 1 else "yok", "bad" if p_sicak > 60 else "warn" if p_sicak > 20 else "ok", "gölgeli hücrede ısıya dönen güç"),
    ]
    kontroller = [
        C("Güç kaybı gölgenin kestiği ışınımla orantılı mı?", f"kayıp %{fnum(kayip, 0)}", f"≈ %{fnum(alan_g, 0)} (gölgelenen ışınım) + diyot kayıpları", kayip <= 2 * alan_g + 5,
          "Köprüleme diyotları sağlam ve evirici doğru tepedeyken kayıp gölgeyle orantılı kalır; diyot yoksa ya da evirici yanlış tepedeyse küçük bir gölge büyük kayıp yapar", "hesap"),
        C("Evirici en yüksek tepede mi çalışıyor?", f"{fnum(p_c / 1000, 2)} kW", f"en yüksek tepe {fnum(genel[2] / 1000, 2)} kW ({fnum(genel[0], 0)} V)", p_c >= 0.98 * genel[2],
          "Yalın izleme algoritması bulunduğu tepenin çevresinde dolaşır; gölgede eğri çok tepeli olur ve en yüksek tepe başka gerilimdedir. Gölge taraması bütün gerilim aralığını arada bir tarar", "ikincil"),
        C("En yüksek tepe eviricinin MPPT gerilim aralığında mı?", f"{fnum(genel[0], 0)} V", f"≥ {fnum(vmin, 0)} V", genel[0] >= vmin,
          f"{GES} böl. 2.3.4.1: evirici seçiminde MPP gerilim aralığı. Çok modül gölgelenince en yüksek tepe düşük gerilime kayar ve aralığın dışına çıkabilir", "resmi"),
        C("Köprüleme diyotları görevini yapıyor mu?", {"saglam": "sağlam", "acik": "yok / açık devre", "kisa": "kısa devre arızalı"}[byp], "sağlam", byp == "saglam",
          "Açık devre diyot: gölgede hücre ters kutuplanır ve yanar. Kısa devre diyot: o alt dizi güneşte de üretmez; dizi gerilimi kalıcı olarak düşer", "ikincil"),
        C("Gölgeli hücredeki ısınma kabul edilebilir mi?", f"≈ {fnum(p_sicak, 0)} W", "≲ 60 W (bir hücrenin soğutabileceği mertebe)", p_sicak <= 60,
          "Hücre ters kutuplandığında üretici değil tüketici olur: gücü küçük bir alanda ısıya çevirir. Kalıcı gölge (baca, direk, komşu sıra) hücreyi ve arka yüzeyi yakar", "tahmini"),
    ]
    girdiler = [
        G("Dizi", f"{n} × {m['ad']}", "Dizi şeması; modül etiketi", "Her modülde 3 alt dizi ve 3 köprüleme diyodu vardır", f"{n * PV.N_ALT} alt dizi seri · alt dizi başına {hucre_alt} hücre"),
        G("Gölge", f"{ng} modül · modülün {alt}/3'ü · ışınım %{fnum(oran, 0)}", "Gölge çözümlemesi (ufuk çizgisi, komşu sıra, baca); termal kamera", "Gölgeli alt dizinin akımı ışınımıyla orantılı düşer",
          f"açıkta Isc {fa(acik_n['isc'], 1)} · gölgede {fa(golge_n['isc'], 1)}"),
        G("Evirici", f"MPPT alt gerilimi {fnum(vmin, 0)} V · " + ("gölge taramalı" if izl == "genel" else "yalın izleme"), "Evirici veri sayfası ve ayarları", "Hangi tepede çalışılacağını belirler", "gölge taraması çoğu eviricide ayarla açılır"),
    ]
    adimlar = [
        A("Gölgesiz dizi", "P = n · Pmp(modül)", f"{n} × {fnum(acik_n['pmp'] * 3, 0)} W", f"{fnum(p_tam / 1000, 2)} kW", f"hücre {fnum(tc, 0)} °C", "hesap", ["Dizi"]),
        A("Seri bağlantı kuralı", "I(dizi) ≤ en küçük Isc — diyot yoksa", f"gölgede Isc = {fa(golge_n['isc'], 1)}", f"akım {fa(golge_n['isc'], 1)} ile sınırlanır", "zincirin en zayıf halkası", "hesap", ["Gölge"]),
        A("Köprüleme", "I > Isc(gölge) ise diyot iletir: alt dizi −0,5 V", f"{n_g} alt dizi devre dışı", f"dizi gerilimi {fnum(n_g * acik_n['vmp'], 0)} V düşer" if n_g else "—", "akım tam değerinde kalır, gerilim eksilir", "hesap"),
        A("Güç eğrisinin tepeleri", "V(I) = Σ alt dizi gerilimleri", " · ".join(f"{fnum(q[0], 0)} V → {fnum(q[2] / 1000, 2)} kW" for q in tp[:4]), f"{len(tp)} tepe", "her gölge düzeyi bir tepe ekler", "hesap"),
        A("Çalışma noktası", "evirici: " + ("pencere içindeki en yüksek tepe" if izl == "genel" else "gerilimi yüksek olan tepe"), f"MPPT ≥ {fnum(vmin, 0)} V", f"{fnum(v_c, 0)} V · {fa(i_c, 1)} · {fnum(p_c / 1000, 2)} kW", "eviricinin izleme biçimine ve gerilim aralığına göre", "hesap", ["Evirici"]),
        A("Sıcak nokta gücü", "P ≈ U(ters) · I(hücre)", f"{fnum(v_ters, 1)} V × {fnum((golge_n['isc'] if byp == 'saglam' else i_c), 1)} A" if p_sicak > 0 else "ters kutuplanma yok", f"≈ {fnum(p_sicak, 0)} W",
          "diyot sağlamken ters gerilim bir alt dizinin gerilimiyle sınırlıdır", "tahmini"),
    ]
    ayarlar = [
        S("Evirici › gölge taraması", "açık (gölge alan dizilerde)", "tarama aralığı dakikalar", "Çok tepeli eğride en yüksek tepeyi bulur; tarama sırasında kısa süre üretim düşer", "evirici kılavuzu", "ikincil"),
        S("Dizilerin MPPT girişlerine dağıtımı", "gölge alan ve almayan diziler ayrı girişlere", "—", "Aynı MPPT'ye bağlı paralel dizilerde gölgeli dizi ötekini de aşağı çeker", f"{GES} böl. 2.3.4.1", "resmi"),
        S("Sıralar arası açıklık", "kış gündönümü öğlesinde gölge düşmeyecek kadar", "—", "Alt sıranın gölgesi her gün aynı hücreleri vurur", "saha pratiği", "ikincil"),
        S("Modül yönü", "alt kenar gölgesinde yatay montaj", "—", "Yatay modülde alt kenar gölgesi tek alt diziyi, dikey modülde üçünü birden keser", "saha pratiği", "ikincil"),
    ]
    test = [
        T("I–V eğrisi", "Eğri çizici ile dizi başından", f"{len(tp)} basamak / tepe" if len(tp) > 1 else "tek dirsekli düzgün eğri", "basamak sayısı gölgeli ya da diyodu kısa devre alt dizi sayısını verir"),
        T("Termal kamera", "Öğle saatinde, yük altında", "iletimdeki diyotun bağlantı kutusu ılık; gölgeli hücre sıcak", f"sıcak nokta ≈ {fnum(p_sicak, 0)} W" if p_sicak > 1 else "sıcak nokta yok"),
        T("Dizi açık devre gerilimi", "Diziler arası karşılaştırma", f"kısa devre diyot başına ≈ {fnum(acik_n['voc'], 1)} V eksik", "gölge açık devre gerilimini pek değiştirmez: eksik gerilim diyot arızasıdır"),
        T("Evirici günlük eğrisi", "İzleme yazılımında dizi akımı / gücü", "gölge saatlerinde çentik", "her gün aynı saatte çentik: sabit bir cisim gölgesi"),
    ]
    g1 = {"baslik": "Güç–gerilim eğrisi", "x_ad": "Dizi gerilimi (V)", "y_ad": "Güç (kW)", "ymin": 0,
          "seriler": [{"ad": "gölgeli", "renk": "#dc2626", "pts": pts(e["v"], [q / 1000 for q in e["p"]], 3)}, {"ad": "gölgesiz", "renk": "#94a3b8", "pts": pts(tam["v"], [q / 1000 for q in tam["p"]], 3)}],
          "isaretler": [{"x": v_c, "etiket": "evirici"}, {"x": vmin, "etiket": "MPPT alt"}]}
    g2 = {"baslik": "Akım–gerilim eğrisi", "x_ad": "Dizi gerilimi (V)", "y_ad": "Akım (A)", "ymin": 0,
          "seriler": [{"ad": "gölgeli", "renk": "#dc2626", "pts": pts(e["v"], e["i"], 3)}, {"ad": "gölgesiz", "renk": "#94a3b8", "pts": pts(tam["v"], tam["i"], 3)}], "isaretler": [{"x": v_c, "etiket": "evirici"}]}
    rows = []
    for k in sorted({0, 1, 2, 3, n // 4, n // 2, n}):
        if k > n:
            continue
        na = n * 3 - k * alt
        for b in ("saglam", "acik"):
            gr = ([(na, acik_n)] if na > 0 else []) + ([(k * alt, golge_n)] if k else [])
            ee = PV.dizi_egri(gr, bypass=b, adim=160)
            pm = max(ee["p"]) if ee["p"] else 0.0
            if b == "saglam":
                satir = [f"{k}" + (" ◀" if k == ng else ""), f"%{fnum(k * alt / (n * 3) * (1 - oran / 100) * 100, 0)}", f"{fnum(pm / 1000, 2)} kW (−%{fnum((1 - pm / p_tam) * 100, 0)})"]
            else:
                satir.append(f"{fnum(pm / 1000, 2)} kW (−%{fnum((1 - pm / p_tam) * 100, 0)})")
        rows.append(satir)
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": cz.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"Dizideki {n} modülün her birinde {m['ns']} hücre seri bağlıdır: aynı akım hepsinden geçmek zorundadır. Bir hücre gölgede kaldığında üretebildiği akım düşer (burada {fa(golge_n['isc'], 1)}; açıktakiler {fa(acik_n['isc'], 1)}) ve zincirin en zayıf halkası olur.",
            ("Diyot olmasaydı iki şey olurdu: bütün dizinin akımı gölgeli hücrenin akımına inerdi ve dizinin geri kalanı fazla akımı o hücreden zorla geçirmeye çalışırdı. Hücre ters kutuplanır, üretici olmaktan çıkar ve gücü ısıya çevirir."
             if byp != "acik" else f"Burada diyot yok: bütün dizinin akımı gölgeli hücrelerin akımına ({fa(golge_n['isc'], 1)}) iniyor; açıktaki {n_a} alt dizi üretebileceğinin küçük bir bölümünü veriyor. Akım bunun üstüne zorlanırsa (paralel dizi, kısa devre) gölgeli hücreler ters kutuplanır, üretici olmaktan çıkar ve gücü ısıya çevirir."),
            (f"Modülün bağlantı kutusundaki üç köprüleme diyodu bunu önler. Her diyot {hucre_alt} hücrelik bir alt diziye paralel bağlıdır. Alt dizi akımı taşıyamadığında diyot iletime geçer, akım gölgeli bölümün çevresinden dolaşır. Dizi o alt dizinin gerilimini ({fnum(acik_n['vmp'], 1)} V) yitirir ama akımını korur."
             if byp == "saglam" else "Kısa devre olmuş bir diyot ise alt diziyi kalıcı olarak devreden çıkarır: gölge olmasa da o bölüm üretmez. Dizi açık devre gerilimi öbür dizilerden bir alt dizi kadar düşüktür — sahada böyle bulunur."
             if byp == "kisa" else "Diyodun açık devre arızası sessizdir: güneşli günde hiçbir belirti vermez, ilk gölgede hücre yanar."),
            f"Bunun eğrideki karşılığı basamaktır. Yüksek akımda yalnız açıktaki alt diziler üretir (düşük gerilim, tam akım); düşük akımda gölgeliler de katılır (yüksek gerilim, kısık akım). Güç eğrisinde {len(tp)} tepe oluşur: "
            + " · ".join(f"{fnum(q[0], 0)} V'ta {fnum(q[2] / 1000, 2)} kW" for q in tp[:3]) + ".",
            (f"Evirici en yüksek tepede çalışıyor: {fnum(p_c / 1000, 2)} kW. Gölge ışınımın %{fnum(alan_g, 0)} kadarını kesiyor, kayıp %{fnum(kayip, 0)}."
             if p_c >= 0.98 * genel[2] else f"Evirici yanlış tepede: {fnum(v_c, 0)} V'ta {fnum(p_c / 1000, 2)} kW alıyor, oysa {fnum(genel[0], 0)} V'ta {fnum(genel[2] / 1000, 2)} kW var. "
             + ("Yalın izleme bulunduğu tepenin çevresinde dolaşır ve ötekini görmez; gölge taraması bunu çözer." if genel[0] >= vmin else "En yüksek tepe eviricinin MPPT aralığının altında kaldı: evirici oraya inemez.")),
            (f"Diyot kurtarır ama bedelsiz değildir. İletimdeki her diyot {fnum(p_diyot, 1)} W ısınır. Gölgeli hücrenin kendisi ise alt dizideki öbür hücrelerin gerilimiyle ({fnum(v_ters, 0)} V) ters kutuplanır ve ≈ {fnum(p_sicak, 0)} W'ı küçük bir alanda ısıya çevirir. Geçici gölgede sorun olmaz; her gün aynı yere düşen gölge hücreyi yıllar içinde yakar."
             if iletiyor else "Gölgenin biçimi önemlidir. Dikey monte edilmiş modülde alt kenara düşen ince bir gölge üç alt diziyi birden keser; aynı gölge yatay modülde yalnız birini keser. Sıra arası gölgenin beklendiği sahalarda modüller bu yüzden yatay dizilir."),
        ],
        "dersler": [
            "Seri bağlı hücrelerde akımı en az ışık alan hücre belirler.",
            "Köprüleme diyodu gölgeli alt diziyi atlatır: gerilim eksilir, akım korunur.",
            "Gölgede güç eğrisi çok tepelidir; evirici en yüksek tepeyi ancak gölge taramasıyla bulur.",
            "Diyotsuz dizide küçük gölge büyük kayıp ve sıcak nokta demektir.",
            "Eksik dizi gerilimi kısa devre diyodu, gölgede yanmış hücre açık devre diyodu gösterir.",
        ],
        "tablolar": [{"baslik": f"Gölgeli modül sayısına göre dizinin en büyük gücü (modülün {alt}/3'ü gölgede, ışınım %{fnum(oran, 0)})", "cols": ["Gölgeli modül", "Kesilen ışınım", "Diyotlar sağlam", "Diyot yok"], "rows": rows,
                      "not": "Eviricinin en yüksek tepeyi bulduğu varsayılmıştır. Modül değerleri tipik veri sayfası mertebesindedir."}],
    }
