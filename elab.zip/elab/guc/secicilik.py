"""Seçicilik: arka arkaya bağlı iki koruma cihazından yalnız arızaya yakın olanın açması. Zaman–akım eğrilerinin kesişmesi; akım, zaman ve enerji seçiciliği;
seçicilik sınır akımı.

Eğriler laboratuvarın ortak modellerinden: otomat (TS EN 60898-1 bandının üst sınırı), NH gG sigorta (kapı değerleri arasında ara değer), elektronik açtırıcılı kompakt şalter
(L: 6 × Ir'de 12 s, S: Isd ve tsd, I: ani). Sigorta–sigorta için 1,6 : 1 kuralı ve sigortanın ön-ark I²t değerleri IEC 60269'dan (dogrulanacak); otomatın geçirdiği enerji için
enerji sınırlama sınıfı 3 değerleri (TS EN 60898-1 Ek ZC — dogrulanacak). Gerçek seçicilik üreticinin seçicilik çizelgesinden okunur: bu sayfa eğrilerin mantığını gösterir."""
from __future__ import annotations

import math

from ..lab.core import gg_sure, mcb_sure, ruleset
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, fsure, logsp, num, opt, pts

ID = "secicilik"
BASLIK = "Seçicilik"
IKON = "🪜"
GIRIS = ("Bir prizdeki kısa devre yalnız o prizin otomatını açtırmalı; katın, binanın elektriğini kesmemeli. Bunun için üstteki cihaz alttakine zaman tanımalıdır. "
         "Eğriler bir yerde kesişiyorsa o akımın üstünde ikisi birden açar. Cihazları ve arıza akımını değiştirin; kimin önce açtığını izleyin.")
IN_ALT = (6, 10, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125)
IN_UST = (25, 32, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400, 630)

KONTROLLER = [
    ctl("alt", "Alt cihaz (yüke yakın)", "sec", "C", secenek=opt(("B", "Otomat B"), ("C", "Otomat C"), ("D", "Otomat D"), ("gG", "NH sigorta gG"))),
    ctl("in_alt", "Alt cihaz In", "sec", 16, secenek=opt(*[(k, f"{k} A") for k in IN_ALT])),
    ctl("ust", "Üst cihaz (kaynağa yakın)", "sec", "gG", secenek=opt(("gG", "NH sigorta gG"), ("C", "Otomat C"), ("TM", "Kompakt şalter, termik-manyetik (10 × In, gecikmesiz)"), ("LSI", "Kompakt şalter, elektronik (LSI)"))),
    ctl("in_ust", "Üst cihaz In", "sec", 63, secenek=opt(*[(k, f"{k} A") for k in IN_UST])),
    ctl("isd", "Üst › kısa gecikmeli eşik Isd", "sayi", 6, min=1.5, max=10, adim=0.5, birim="× In", goster={"ust": ["LSI"]}),
    ctl("tsd", "Üst › kısa gecikme tsd", "sec", 0.2, secenek=opt((0.0, "0 s"), (0.1, "0,1 s"), (0.2, "0,2 s"), (0.3, "0,3 s"), (0.4, "0,4 s")), goster={"ust": ["LSI"]}),
    ctl("ii", "Üst › ani eşik Ii", "sayi", 15, min=2, max=15, adim=1, birim="× In", goster={"ust": ["LSI"]}, yardim="15: en yüksek (ani kademe fiilen devre dışı)"),
    ctl("ik", "Alt cihazın çıkışında kısa devre akımı", "sayi", 3.0, min=0.1, max=25, adim=0.1, birim="kA"),
]


def t_cihaz(tip: str, in_a: float, i: float, isd: float = 6, tsd: float = 0.2, ii: float = 15) -> float:
    if tip == "gG":
        return gg_sure(in_a, i)
    if tip in ("B", "C", "D"):
        return mcb_sure(in_a, tip, i)
    m = i / in_a
    if tip == "TM":
        return 0.02 if m >= 10 else (math.inf if m <= 1.05 else min(7200.0, 12 * 36 / (m * m)))
    if m >= ii and ii < 15:
        return 0.02
    if m >= isd:
        return tsd + 0.04
    return math.inf if m <= 1.05 else min(7200.0, 12 * 36 / (m * m))


def run(p: dict) -> dict:
    alt, ust, in_alt, in_ust = str(p.get("alt", "C")), str(p.get("ust", "gG")), num(p, "in_alt", 16), num(p, "in_ust", 63)
    isd, tsd, ii, ik = num(p, "isd", 6), num(p, "tsd", 0.2), num(p, "ii", 15), num(p, "ik", 3.0) * 1000
    ta = lambda i: t_cihaz(alt, in_alt, i)                                  # noqa: E731
    tu = lambda i: t_cihaz(ust, in_ust, i, isd, tsd, ii)                    # noqa: E731
    akimlar = logsp(max(in_alt * 1.2, 5), max(ik * 1.5, in_ust * 30), 140)
    def secici(i: float) -> bool:
        a, u = ta(i), tu(i)
        if not math.isfinite(a):
            return True
        return u >= max(1.3 * a, a + 0.03)
    i_s = None
    for i in akimlar:
        if not secici(i):
            i_s = i
            break
    t_a, t_u = ta(ik), tu(ik)
    nh = ruleset().breakers["nh"]
    oran = in_ust / in_alt
    enerji_not, enerji_ok = "", None
    if ust == "gG" and alt in ("B", "C", "D"):
        on_ark = nh["i2t_on_ark_max_ka2s"].get(str(int(in_ust)))
        tab = ruleset().breakers["mcb"]["enerji_siniri_sinif3_a2s"]
        if on_ark and in_alt <= 32:
            lim = tab["6"]["16" if in_alt <= 16 else "32"][alt]
            enerji_ok = on_ark * 1000 >= lim
            enerji_not = f"sigortanın ön-ark I²t'si {fnum(on_ark, 0)} kA²s · otomatın geçirdiği (sınıf 3, 6 kA) ≤ {fnum(lim / 1000, 0)} kA²s"
    tam = i_s is None or i_s >= ik
    if enerji_ok is True:
        tam = True; i_s = None
    durum = "tam" if tam else "kısmi" if i_s > 2 * in_alt else "yok"
    ad_alt = f"NH gG {in_alt:g} A" if alt == "gG" else f"otomat {alt}{in_alt:g}"
    ad_ust = f"NH gG {in_ust:g} A" if ust == "gG" else f"otomat C{in_ust:g}" if ust == "C" else f"kompakt şalter {in_ust:g} A ({ust})"
    ikisi = math.isfinite(t_u) and t_u < max(1.3 * t_a, t_a + 0.03) and not tam
    ust_yaz = "erimez (enerji seçiciliği)" if enerji_ok is True else fsure(t_u)          # ani bölgede eğri değil geçen enerji belirler
    c = Cizim(900, 290)
    c.kutu(30, 60, 110, 54, "Kaynak", "pano barası")
    c.hat("M140,87 H220", "L1", hot=True, w=3)
    c.dikdortgen(220, 76, 26, 22, "ariza" if ikisi else "cizgi", "#fee2e2" if ikisi else "#fff"); c.yazi(233, 64, ad_ust, "#b91c1c" if ikisi else "#334155", 11, kalin=True, anchor="middle")
    c.hat("M246,87 H420", "L1", hot=True, w=3)
    for j, y in enumerate((140, 180)):
        c.hat(f"M330,87 V{y} H420", "cizgi", w=2); c.dikdortgen(420, y - 10, 22, 20, "cizgi", "#fff"); c.hat(f"M442,{y} H520", "cizgi", w=2)
        c.yazi(530, y + 4, "öbür çıkış" + (" — elektriği kesildi" if ikisi else " — çalışıyor"), "#b91c1c" if ikisi else "#15803d", 10.5)
    c.dikdortgen(420, 76, 26, 22, "ariza", "#fee2e2"); c.yazi(433, 64, ad_alt, "#b91c1c", 11, kalin=True, anchor="middle")
    c.hat("M446,87 H640", "L1", hot=True, w=3); c.simsek(634, 76, 1.2); c.yazi(660, 82, f"arıza {fnum(ik / 1000, 1)} kA", "#b91c1c", 12.5, kalin=True)
    c.yazi(30, 222, ({"tam": "TAM SEÇİCİ: bu arıza akımına kadar yalnız alt cihaz açar", "kısmi": f"KISMİ SEÇİCİ: {fnum(i_s, 0)} A'e kadar yalnız alt cihaz; üstünde ikisi birden", "yok": "SEÇİCİ DEĞİL: küçük arızada bile üst cihaz da açar"}[durum]),
           "#15803d" if durum == "tam" else "#b45309" if durum == "kısmi" else "#b91c1c", 13.5, kalin=True)
    c.yazi(30, 246, f"Bu arızada: alt {fsure(t_a)} · üst {ust_yaz}" + (" — ikisi birden açıyor" if ikisi else ""), "#b91c1c" if ikisi else "#334155", 12.5)
    c.yazi(30, 270, f"Anma akımı oranı {fnum(oran, 1)} : 1" + (f" · {enerji_not}" if enerji_not else ""), "#64748b", 11)
    ozet = [
        K("Seçicilik", {"tam": "tam", "kısmi": "kısmi", "yok": "yok"}[durum], "ok" if durum == "tam" else "warn" if durum == "kısmi" else "bad", f"{fnum(ik / 1000, 1)} kA'e kadar denetlendi"),
        K("Seçicilik sınır akımı", "—" if i_s is None else fa(i_s, 0), "ok" if i_s is None else "warn", "bu akımın üstünde ikisi birden açar" if i_s is not None else "eğriler kesişmiyor"),
        K("Alt cihaz açma süresi", fsure(t_a), "info", ad_alt),
        K("Üst cihaz açma süresi", ust_yaz, "bad" if ikisi else "info", ad_ust),
        K("Anma akımı oranı", f"{fnum(oran, 1)} : 1", "warn" if oran < 1.6 else "ok", "sigorta–sigorta için ≥ 1,6 : 1"),
    ]
    kontroller = [
        C("Bu arızada yalnız alt cihaz mı açıyor?", f"alt {fsure(t_a)} · üst {ust_yaz}", "üst, alttan belirgin geç açmalı", not ikisi, "Üst cihazın açmama süresi, alt cihazın toplam açma süresinden uzun olmalıdır (burada %30 ya da 30 ms pay)", "hesap"),
        C("Bütün akım aralığında seçici mi?", "evet" if i_s is None else f"{fnum(i_s, 0)} A'e kadar", f"≥ {fnum(ik, 0)} A (hattaki en büyük arıza akımı)", tam, "Seçicilik sınır akımının altındaki arızalarda yalnız alt cihaz açar; kısa devre akımı sınırın altındaysa uygulamada tam seçiciliktir", "hesap"),
    ] + ([C("Sigorta – sigorta oranı", f"{fnum(oran, 1)} : 1", "≥ 1,6 : 1", oran >= 1.6, "Aynı tür (gG) sigortalar arasında anma akımları oranı 1,6 ve üstündeyse tam seçicilik sağlanır (IEC 60269 — asıl metinle doğrulanacak)", "dogrulanacak")] if alt == "gG" and ust == "gG" else []) + (
         [C("Enerji seçiciliği (sigorta üstte, otomat altta)", enerji_not, "ön-ark I²t ≥ otomatın geçirdiği I²t", enerji_ok, "Otomat arızayı, sigortanın telini eritecek enerjiye varmadan kesmelidir — değerler TS EN 60898-1 Ek ZC ve IEC 60269'dan (doğrulanacak)", "dogrulanacak")] if enerji_ok is not None else []) + (
         [C("Zaman seçiciliği", f"tsd = {fnum(tsd, 1)} s · Ii = {fnum(ii, 0)} × In", "tsd ≥ 0,1 s ve ani kademe alt cihazın arıza akımının üstünde", tsd >= 0.1 and (ii >= 15 or ii * in_ust > ik), "Kısa gecikmeli (S) kademe üst cihaza bekleme yeteneği verir; ani (I) kademe bu beklemeyi iptal eder — TS EN 60947-2 açtırıcı işlevleri (ayar aralıkları üretici kataloglarından)", "ikincil")] if ust == "LSI" else []) + (
         [C("Gecikmesiz iki manyetik açtırıcı", "ikisi de anında açar", "akım seçiciliği yalnız eşikler arasında", None, "Termik-manyetik şalter ve otomat gecikmesizdir: üst cihazın manyetik eşiğinin üstündeki arızada ikisi birden açar. Çare: sınırlayan alt cihaz + üretici seçicilik çizelgesi ya da elektronik açtırıcı", "ikincil")] if ust in ("C", "TM") else [])
    girdiler = [
        G("İki cihazın tipi ve ayarı", f"{ad_alt} · {ad_ust}", "Pano şeması; açtırıcı ayarları", "Eğrilerin yerini belirler", "t(I) eğrileri"),
        G("Alt cihazın çıkışındaki kısa devre akımı", f"{fnum(ik / 1000, 1)} kA", "Kısa devre hesabı", "Seçicilik bu akıma kadar aranır; üstü oluşamaz", "Is ≥ Ik ise tam seçici"),
        G("Üretici seçicilik çizelgesi", "cihaz çiftine göre sınır akımı", "Üretici kataloğu", "Ani bölgede seçiciliği eğriler değil geçirilen enerji belirler: çizelge deneyle bulunur", "eğri + çizelge birlikte"),
    ]
    adimlar = [
        A("Alt cihazın açma süresi", "t = eğri(I / In)", f"{fnum(ik, 0)} A / {in_alt:g} A = {fnum(ik / in_alt, 0)} × In", fsure(t_a), "bandın üst sınırı (en geç açma)", "dogrulanacak", ["İki cihazın tipi ve ayarı"]),
        A("Üst cihazın açma süresi", "t = eğri(I / In)", f"{fnum(ik, 0)} A / {in_ust:g} A = {fnum(ik / in_ust, 1)} × In", fsure(t_u), "aynı akım üst cihazdan da geçer", "dogrulanacak"),
        A("Seçicilik sınır akımı", "t(üst) < 1,3 · t(alt) olan ilk akım", "akım küçükten büyüğe taranır", "kesişme yok" if i_s is None else fa(i_s, 0), "eğrilerin kesiştiği yer", "hesap", ["Alt cihazın çıkışındaki kısa devre akımı"]),
    ]
    ayarlar = [
        S("Üst cihaz › kısa gecikme tsd", "0,1 – 0,2 – 0,3 – 0,4 s", "kademe başına 0,1 s", "Alt cihaza açması için süre tanır", "TS EN 60947-2; üretici kataloğu", "ikincil"),
        S("Üst cihaz › ani kademe Ii", "alt cihazın çıkışındaki Ik'nın üstünde ya da kapalı", "—", "Aksi halde gecikme işe yaramaz", "üretici kataloğu", "ikincil"),
        S("Sigortalar", "anma akımları oranı ≥ 1,6", "—", "Eğri bandları kesişmez", "IEC 60269 (doğrulanacak)", "dogrulanacak"),
        S("Bölge seçiciliği (ZSI)", "alt cihaz «gördüm» derse üst bekler, demezse hemen açar", "—", "Gecikmeyi yalnız gerektiğinde uygular: hem seçici hem hızlı", "Röle laboratuvarı › Ters kilitleme", "ikincil"),
    ]
    test = [
        T("Ayar denetimi", "Açtırıcıların üstündeki Ir, Isd, tsd, Ii konumları", "projedeki koordinasyon çalışmasıyla aynı", "fabrika çıkışı ayarlar çoğu zaman en düşüktedir: seçicilik yoktur"),
        T("Sekonder enjeksiyon", "Elektronik açtırıcıya deney cihazıyla", f"Isd'de {fnum(tsd, 1)} s gecikme", "üretici deney cihazı gerekir"),
    ]
    g1 = {"baslik": "Zaman – akım eğrileri", "x_ad": "Akım (A)", "y_ad": "Açma süresi (s)", "logx": True, "logy": True,
          "seriler": [{"ad": ad_alt, "renk": "#1a4d8f", "pts": pts([i for i in akimlar if math.isfinite(ta(i))], [max(ta(i), 0.004) for i in akimlar if math.isfinite(ta(i))], 4)},
                      {"ad": ad_ust, "renk": "#dc2626", "pts": pts([i for i in akimlar if math.isfinite(tu(i))], [max(tu(i), 0.004) for i in akimlar if math.isfinite(tu(i))], 4)}],
          "isaretler": [{"x": ik, "etiket": "Ik"}] + ([{"x": i_s, "etiket": "seçicilik sınırı"}] if i_s else [])}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1],
        "anlatim": [
            "Arıza akımı kaynaktan arıza yerine kadar yolundaki bütün koruma cihazlarından geçer. Hepsi onu görür; istenen, yalnız arızaya en yakın olanın açmasıdır.",
            f"Her cihazın bir zaman–akım eğrisi vardır: akım büyüdükçe daha çabuk açar. {ad_alt} bu arızayı {fsure(t_a)} içinde, {ad_ust} {fsure(t_u)} içinde açar.",
            ("Üst cihazın eğrisi alt cihazınkinin tümüyle üstünde ve sağında: hangi akım olursa olsun alt cihaz önce açar. Tam seçicilik." if durum == "tam" else
             f"Eğriler {fnum(i_s, 0)} A'de buluşuyor. Bunun altındaki arızalarda (aşırı yük, uzak kısa devre) yalnız alt cihaz açar; üstündeki arızalarda ikisi birden açar ve üst cihazın beslediği bütün çıkışlar kararır."),
            "Seçiciliğin üç yolu vardır. Akım seçiciliği: üst cihazın eşiği, alt cihazın çıkışındaki en büyük arıza akımının üstündedir (araya empedans, yani kablo girer). Zaman seçiciliği: üst cihaz bilerek bekler. Enerji seçiciliği: alt cihaz arızayı o kadar çabuk ve sınırlayarak keser ki üst cihaza açacak enerji ulaşmaz.",
            "Gecikmesiz iki cihaz (iki otomat, otomat + termik-manyetik şalter) arasında yüksek akımda seçicilik eğrilerden okunamaz: ikisi de «anında» açar. Gerçek sonuç, üreticinin deneyle bulduğu seçicilik çizelgesindedir.",
            "Zaman seçiciliğinin bedeli vardır: üst cihaz beklerken arıza akımı akmaya devam eder. Bu yüzden kademe sayısı sınırlıdır ve bara arızası için ayrı önlemler (ark rölesi, bölge seçiciliği) alınır.",
        ],
        "dersler": [
            "Seçicilik = eğriler kesişmiyor. Kesişiyorsa kesişme akımına kadar kısmi seçicilik vardır.",
            "Sigorta–sigorta: anma akımları oranı ≥ 1,6.",
            "Zaman seçiciliği için üst cihazda kısa gecikme (S) gerekir ve ani kademe yolundan çekilir.",
            "İki gecikmesiz cihaz arasında seçiciliği üretici çizelgesi söyler, eğri söylemez.",
            "Fabrika ayarında bırakılan açtırıcı seçici değildir.",
        ],
        "tablolar": [{"baslik": "Akıma göre açma süreleri", "cols": ["Akım", ad_alt, ad_ust, "Sonuç"],
                      "rows": [[fa(i, 0), fsure(ta(i)), fsure(tu(i)), "yalnız alt cihaz" if secici(i) else "ikisi birden"] for i in (in_alt * 2, in_alt * 5, in_alt * 10, in_alt * 20, in_ust * 5, in_ust * 10, ik) if i <= ik * 1.01]}],
    }
