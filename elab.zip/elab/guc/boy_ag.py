"""AG kablo boyu: kablo uzadıkça gerilim düşümü artar, hat sonu kısa devre akımı düşer, korumanın açma süresi uzar; bir boydan sonra koruma artık zamanında açamaz.
Aynı devrede dört sınır birlikte: akım taşıma, gerilim düşümü, açma koşulu, kısa devrede ısıl dayanım.

Sınırlar: gerilim düşümü %1,5 (aydınlatma, priz) ve %3 (motor) — Elektrik İç Tesisleri Yön. m.57; TN sistemde açma süresi 230 V'ta 0,4 s, dağıtım devresinde 5 s — Topraklamalar Yön.
m.8 Çizelge-2; koşul Zs·Ia ≤ Uo. Koruma cihazlarının açma akımları laboratuvarın ortak eğrilerinden (otomat: bandın üst sınırı; gG: kapı değerleri). İletken dirençleri ve akım
taşıma kapasiteleri çizelge değerleridir (dogrulanacak). Arıza sırasında iletken sıcaklığı 80 °C alınır."""
from __future__ import annotations

import math

from ..lab.core import gg_ia, gg_sure, mcb_ia, mcb_sure, ruleset
from . import fizik as F
from . import kablo as KB
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, fsure, logsp, num, opt, pts

ID = "boy_ag"
BASLIK = "AG kablo boyu"
IKON = "📏"
GIRIS = ("Aynı kablo 20 metrede sorunsuz, 200 metrede sorunlu olabilir: gerilim düşer, hat sonundaki kısa devre akımı küçülür ve koruma onu bir aşırı yük sanıp bekler. "
         "Boyu uzatın; hangi sınırın önce aşıldığını ve çaresinin kesit mi koruma mı olduğunu izleyin.")
YON = "Elektrik İç Tesisleri Yön. m.57"
TOP = "Topraklamalar Yön. m.8 Çizelge-2"
IN_A = (6, 10, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 160, 200, 250, 315, 400)

KONTROLLER = [
    ctl("faz", "Devre", "sec", 3, secenek=opt((3, "Üç fazlı 400 V"), (1, "Tek fazlı 230 V"))),
    ctl("tur", "Yük türü", "sec", "motor", secenek=opt(("priz", "Aydınlatma / priz (ΔU ≤ %1,5)"), ("motor", "Motor / güç devresi (ΔU ≤ %3)"))),
    ctl("i", "Yük akımı", "sayi", 50, min=1, max=400, adim=1, birim="A"),
    ctl("cos", "Güç katsayısı", "sayi", 0.85, min=0.5, max=1.0, adim=0.01),
    ctl("l", "Kablo boyu", "sayi", 80, min=1, max=600, adim=1, birim="m"),
    ctl("s", "Faz iletkeni kesiti", "sec", 16, secenek=opt(*[(k, f"{str(k).replace('.', ',')} mm²") for k in KB.KESIT])),
    ctl("pe", "Koruma iletkeni", "sec", "es", secenek=opt(("es", "Faz kesitine eşit"), ("yarim", "Faz kesitinin yarısı (≥ 16 mm²'nin üstünde)"))),
    ctl("metal", "İletken", "sec", "cu", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum"))),
    ctl("yal", "Yalıtkan", "sec", "pvc", secenek=opt(("pvc", "PVC (70 °C)"), ("xlpe", "XLPE (90 °C)"))),
    ctl("cihaz", "Koruma cihazı", "sec", "C", secenek=opt(("B", "Otomat B"), ("C", "Otomat C / kompakt şalter (10 × In)"), ("D", "Otomat D"), ("gG", "NH sigorta gG"))),
    ctl("in_a", "Anma akımı In", "sec", 63, secenek=opt(*[(k, f"{k} A") for k in IN_A])),
    ctl("devre", "Devrenin yeri", "sec", "son", secenek=opt(("son", "Son devre (açma ≤ 0,4 s)"), ("dagitim", "Dağıtım devresi / besleme (açma ≤ 5 s)"))),
    ctl("ik", "Panonun barasında kısa devre akımı", "sayi", 10.0, min=0.5, max=50, adim=0.5, birim="kA"),
]


def hal(p: dict, l: float) -> dict:
    faz, i, cosf = int(num(p, "faz", 3)), num(p, "i", 50), num(p, "cos", 0.85)
    s, metal, yal = num(p, "s", 16), str(p.get("metal", "cu")), str(p.get("yal", "pvc"))
    s_pe = s if p.get("pe", "es") == "es" or s <= 16 else max([k for k in KB.KESIT if k <= s / 2] or [s])
    t_is = 90.0 if yal == "xlpe" else 70.0
    du = KB.du_3f(i, l, s, cosf, metal, t_is) if faz == 3 else KB.du_1f(i, l, s, cosf, metal, t_is)
    zk = 230.0 / (num(p, "ik", 10.0) * 1000)
    zsrc = complex(0.3 * zk, 0.954 * zk)
    zc = KB.z_cevrim(l, s, s_pe, metal)
    zs = abs(zsrc + zc)
    ik1 = 230.0 / zs
    zpe = KB.r_km(s_pe, metal, 80.0) * l / 1000
    cihaz, in_a = str(p.get("cihaz", "C")), num(p, "in_a", 63)
    t_ac = gg_sure(in_a, ik1) if cihaz == "gG" else mcb_sure(in_a, cihaz, ik1)
    kayip = (3 if faz == 3 else 2) * i * i * KB.r_km(s, metal, t_is) * l / 1000
    p_yuk = (math.sqrt(3) * 400 if faz == 3 else 230) * i * cosf
    ik3 = 230.0 / abs(zsrc + complex(KB.r_km(s, metal, 20.0) * l / 1000, KB.X_AG * l / 1000))
    return {"du": du, "ik1": ik1, "zs": zs, "t_ac": t_ac, "ut": ik1 * zpe, "kayip": kayip, "kayip_pct": kayip / p_yuk * 100 if p_yuk else 0, "s_pe": s_pe, "ik3": ik3}


def run(p: dict) -> dict:
    faz, i, l, s = int(num(p, "faz", 3)), num(p, "i", 50), num(p, "l", 80), num(p, "s", 16)
    metal, yal, cihaz, in_a = str(p.get("metal", "cu")), str(p.get("yal", "pvc")), str(p.get("cihaz", "C")), num(p, "in_a", 63)
    son = p.get("devre", "son") == "son"
    gd = ruleset().ictesisler["gerilim_dusumu"]["profil_1995"]
    du_sinir = gd["baglanti_kutusu_tuketici_aydinlatma_priz_pct"] if p.get("tur") == "priz" else gd["baglanti_kutusu_motor_pct"]
    t_sinir = 0.4 if son else 5.0
    h = hal(p, l)
    ia = gg_ia(in_a, t_sinir) if cihaz == "gG" else mcb_ia(in_a, cihaz, t_sinir)
    iz = KB.iz(s, yal, metal)
    k = F.k_katsayi(metal, 90.0 if yal == "xlpe" else 70.0, 250.0 if yal == "xlpe" else 160.0)
    i2t_ok = (h["ik1"] ** 2 * min(h["t_ac"], 5.0)) <= (k * s) ** 2 if math.isfinite(h["t_ac"]) else False

    def lmax(olcut) -> float:
        lo, hi = 0.5, 3000.0
        if olcut(hi):
            return hi
        if not olcut(lo):
            return 0.0
        for _ in range(40):
            mid = (lo + hi) / 2
            lo, hi = (mid, hi) if olcut(mid) else (lo, mid)
        return lo
    l_du = lmax(lambda x: hal(p, x)["du"] <= du_sinir)
    l_ac = lmax(lambda x: hal(p, x)["ik1"] >= ia)
    l_en = min(l_du, l_ac)
    cihaz_ad = f"NH gG {in_a:g} A" if cihaz == "gG" else f"otomat {cihaz}{in_a:g}"
    c = Cizim(900, 300)
    c.kutu(20, 60, 110, 54, "Pano", f"Ik {fnum(num(p, 'ik', 10.0), 1)} kA")
    c.dikdortgen(150, 77, 22, 20, "ariza" if h["t_ac"] > t_sinir else "cizgi", "#fff"); c.yazi(161, 68, cihaz_ad, "#475569", 10, anchor="middle")
    xe = 172 + min(max(l * 1.0, 80), 520)
    c.hat(f"M130,87 H150", "L1", hot=True, w=3); c.hat(f"M172,87 H{xe}", "L1", hot=True, w=3)
    c.hat(f"M130,117 H{xe}", "PE", w=2.4); c.yazi(140, 132, "koruma iletkeni", "#15803d", 9.5)
    c.yazi((172 + xe) / 2, 76, f"{fnum(l, 0)} m · {str(s).replace('.', ',')} mm² {'Al' if metal == 'al' else 'Cu'}", "#334155", 11.5, kalin=True, anchor="middle")
    c.kutu(xe, 60, 110, 54, "Yük", f"{fnum(i, 0)} A")
    c.simsek(xe - 22, 92, 1.0); c.hat(f"M{xe - 14},87 V117", "ariza", hot=True, w=2)
    c.yazi(40, 170, f"Gerilim düşümü %{fnum(h['du'], 2)} (sınır %{fnum(du_sinir, 1)}) → en çok {fnum(l_du, 0)} m", "#b91c1c" if h["du"] > du_sinir else "#15803d", 12.5, kalin=True)
    c.yazi(40, 194, f"Hat sonunda faz–koruma kısa devresi {fnum(h['ik1'], 0)} A; {cihaz_ad} için gereken {fnum(ia, 0)} A → en çok {fnum(l_ac, 0)} m", "#b91c1c" if h["ik1"] < ia else "#15803d", 12.5, kalin=True)
    c.yazi(40, 218, f"Açma süresi: {fsure(h['t_ac'])} (sınır {fnum(t_sinir, 1)} s) · arıza sırasında gövde gerilimi ≈ {fnum(h['ut'], 0)} V", "#b91c1c" if h["t_ac"] > t_sinir else "#334155", 12)
    c.yazi(40, 242, f"Akım taşıma: {fnum(i, 0)} A ≤ In {in_a:g} A ≤ Iz {fnum(iz, 0)} A · kayıp {fnum(h['kayip'], 0)} W (%{fnum(h['kayip_pct'], 1)})", "#b91c1c" if not (i <= in_a <= iz) else "#334155", 12)
    c.yazi(40, 272, f"Bu devrede kabloyu sınırlayan: {'gerilim düşümü' if l_du < l_ac else 'açma koşulu'} — en büyük boy {fnum(l_en, 0)} m", "#1a4d8f", 12.5, kalin=True)
    ozet = [
        K("Gerilim düşümü", f"%{fnum(h['du'], 2)}", "bad" if h["du"] > du_sinir else "ok", f"sınır %{fnum(du_sinir, 1)}"),
        K("Hat sonu kısa devre akımı", f"{fnum(h['ik1'], 0)} A", "bad" if h["ik1"] < ia else "ok", f"faz–koruma · gereken {fnum(ia, 0)} A"),
        K("Açma süresi", fsure(h["t_ac"]), "bad" if h["t_ac"] > t_sinir else "ok", f"sınır {fnum(t_sinir, 1)} s · {cihaz_ad}"),
        K("En büyük boy", f"{fnum(l_en, 0)} m", "bad" if l > l_en else "ok", f"düşüm {fnum(l_du, 0)} m · açma {fnum(l_ac, 0)} m"),
        K("Kayıp", f"{fnum(h['kayip'], 0)} W", "warn" if h["kayip_pct"] > 3 else "info", f"yük gücünün %{fnum(h['kayip_pct'], 1)}'i"),
    ]
    kontroller = [
        C("Gerilim düşümü", f"%{fnum(h['du'], 2)}", f"≤ %{fnum(du_sinir, 1)}", h["du"] <= du_sinir, "Yapı bağlantı kutusu ile tüketim araçları arasında aydınlatma ve priz devrelerinde %1,5, motor devrelerinde %3 — " + YON + " a.3", "resmi"),
        C("Açma koşulu: hat sonu arıza akımı", f"{fnum(h['ik1'], 0)} A (Zs = {fnum(h['zs'] * 1000, 0)} mΩ)", f"≥ Ia = {fnum(ia, 0)} A ({fnum(t_sinir, 1)} s'de açtıran akım)", h["ik1"] >= ia,
          "TN sistemde Zs · Ia ≤ Uo; açma süresi 230 V'ta en çok 0,4 s, dağıtım devrelerinde 5 s — " + TOP, "resmi"),
        C("Açma süresi", fsure(h["t_ac"]), f"≤ {fnum(t_sinir, 1)} s", h["t_ac"] <= t_sinir, "Otomat için eğri bandının üst sınırı, sigorta için kapı değerleri arasında ara değer — " + TOP, "resmi"),
        C("Akım taşıma", f"Ib {fnum(i, 0)} A · In {in_a:g} A · Iz {fnum(iz, 0)} A", "Ib ≤ In ≤ Iz", i <= in_a <= iz, "Koruma cihazının anma akımı yük akımından büyük, kablonun akım taşıma kapasitesinden küçük olmalıdır (TS HD 60364-4-43 — asıl metinle doğrulanacak; Iz çizelge değeri)", "dogrulanacak"),
        C("Kısa devrede ısıl dayanım (hat sonu arızası)", f"I²t = {fnum(h['ik1'] ** 2 * min(h['t_ac'], 5.0) / 1e6, 2)} × 10⁶ A²s" if math.isfinite(h["t_ac"]) else "koruma açmıyor", f"≤ k²S² = {fnum((k * s) ** 2 / 1e6, 2)} × 10⁶ A²s", i2t_ok,
          "Küçük arıza akımı uzun sürerse kablo, büyük akımın kısa süresinden daha çok ısınabilir — «Kısa devrede ısı» sayfası", "hesap"),
        C("Arıza sırasında gövde gerilimi", f"≈ {fnum(h['ut'], 0)} V", "50 V'un üstünde: süre sınırı bunun içindir", None, "Arıza akımı koruma iletkeninde gerilim düşürür; gövdeye dokunan kişi bu gerilimi görür. Tehlikeli gerilim sınırı 50 V — Topraklamalar Yön. m.4, m.8", "resmi"),
    ]
    girdiler = [
        G("Yük", f"{fnum(i, 0)} A · cosφ {fnum(num(p, 'cos', 0.85), 2)} · {'üç' if faz == 3 else 'tek'} fazlı", "Yük listesi / etiket", "Gerilim düşümünü ve kaybı belirler", "ΔU = √3·I·L·(r·cosφ + x·sinφ)"),
        G("Kablo", f"{str(s).replace('.', ',')} mm² {'Al' if metal == 'al' else 'Cu'} · koruma iletkeni {str(h['s_pe']).replace('.', ',')} mm² · {fnum(l, 0)} m", "Proje, kablo etiketi, güzergâh ölçüsü", "Direnç boyla doğru, kesitle ters orantılıdır", f"r = {fnum(KB.r_km(s, metal, 70.0), 3)} Ω/km (70 °C)"),
        G("Koruma cihazı", cihaz_ad, "Pano şeması", "Hat sonundaki küçük arıza akımını süresinde açması gerekir", f"Ia({fnum(t_sinir, 1)} s) = {fnum(ia, 0)} A"),
        G("Kaynak", f"pano barasında Ik = {fnum(num(p, 'ik', 10.0), 1)} kA", "Kısa devre hesabı", "Çevrim empedansının kablo dışındaki kısmı", "Zs = Z(kaynak) + Z(faz) + Z(koruma)"),
    ]
    adimlar = [
        A("Gerilim düşümü", "ΔU% = √3·I·L·(r·cosφ + x·sinφ) / U" if faz == 3 else "ΔU% = 2·I·L·(r·cosφ + x·sinφ) / U", f"I = {fnum(i, 0)} A · L = {fnum(l, 0)} m · r = {fnum(KB.r_km(s, metal, 90.0 if yal == 'xlpe' else 70.0), 3)} Ω/km", f"%{fnum(h['du'], 2)}", YON + " (bağıntı ve sınırlar)", "resmi", ["Yük", "Kablo"]),
        A("Çevrim empedansı", "Zs = Z(kaynak) + (r(faz) + r(koruma))·L + j·2x·L", f"arıza sıcaklığında (80 °C)", f"{fnum(h['zs'] * 1000, 0)} mΩ", "faz iletkeni gidiş, koruma iletkeni dönüş", "hesap", ["Kablo", "Kaynak"]),
        A("Hat sonu arıza akımı", "Ik = Uo / Zs", f"230 / {fnum(h['zs'], 3)}", fa(h["ik1"], 0), "TN sistem, faz–koruma iletkeni kısa devresi", "hesap"),
        A("Açtıran akım", f"Ia: cihazın {fnum(t_sinir, 1)} s'de açtığı akım", cihaz_ad, fa(ia, 0), "otomat: manyetik eşik (bandın üst sınırı) · sigorta: zaman–akım eğrisi", "dogrulanacak", ["Koruma cihazı"]),
        A("En büyük boy", "Zs(L) · Ia = Uo ve ΔU(L) = sınır", "iki koşulun küçüğü", f"{fnum(l_en, 0)} m", "boy arttıkça ikisi de kötüleşir", "hesap"),
    ]
    ayarlar = [
        S("Çare 1: kesiti büyütmek", "her iki sınırı da uzatır", "—", "Direnç kesitle ters orantılıdır", "hesap", "hesap"),
        S("Çare 2: korumayı değiştirmek", "C → B eğrisi, ayarlanabilir manyetik eşik, ya da artık akım koruması", "—", "Yalnız açma koşulunu düzeltir; gerilim düşümünü değiştirmez", "Topraklama laboratuvarı › Kaçak akım rölesi", "ikincil"),
        S("Artık akım koruma düzeni (RCD)", "30 / 300 mA", "—", "Uzun hatlarda açma koşulunu aşırı akım koruması sağlayamıyorsa RCD sağlar", TOP),
    ]
    test = [
        T("Çevrim empedansı ölçüsü", "Hat sonundaki prizde / klemenste çevrim empedansı ölçeri (L–PE)", f"Zs ≈ {fnum(h['zs'], 2)} Ω → Ik ≈ {fnum(h['ik1'], 0)} A", "ölçülen Ik, cihazın Ia değerinin üstünde olmalı — Topraklama laboratuvarı › Ölçümler"),
        T("Gerilim düşümü", "Yük altında pano ve hat sonu gerilimi", f"fark ≈ %{fnum(h['du'], 1)}", "motor kalkışında ayrıca ölçülür"),
    ]
    ls = logsp(2, 600, 45)
    eg = [hal(p, x) for x in ls]
    g1 = {"baslik": "Boya göre gerilim düşümü", "x_ad": "Kablo boyu (m)", "y_ad": "ΔU (%)", "ymin": 0,
          "seriler": [{"ad": "gerilim düşümü", "renk": "#1a4d8f", "pts": pts(ls, [e["du"] for e in eg], 3)}], "yatay": [{"y": du_sinir, "etiket": f"sınır %{fnum(du_sinir, 1)}", "renk": "#dc2626"}], "isaretler": [{"x": l, "etiket": "boy"}]}
    g2 = {"baslik": "Boya göre hat sonu kısa devre akımı", "x_ad": "Kablo boyu (m)", "y_ad": "Akım (A)", "logx": True, "logy": True,
          "seriler": [{"ad": "faz–koruma (en küçük)", "renk": "#dc2626", "pts": pts(ls, [e["ik1"] for e in eg], 1)}, {"ad": "üç faz (en büyük)", "renk": "#94a3b8", "kesik": True, "pts": pts(ls, [e["ik3"] for e in eg], 1)}],
          "yatay": [{"y": ia, "etiket": f"Ia ({cihaz_ad})", "renk": "#7c3aed"}, {"y": in_a, "etiket": "In", "renk": "#15803d"}], "isaretler": [{"x": l, "etiket": "boy"}]}
    g3 = {"baslik": "Boya göre açma süresi", "x_ad": "Kablo boyu (m)", "y_ad": "Süre (s)", "logx": True, "logy": True,
          "seriler": [{"ad": cihaz_ad, "renk": "#b45309", "pts": pts(ls, [min(e["t_ac"], 7200.0) if math.isfinite(e["t_ac"]) else 7200.0 for e in eg], 3)}],
          "yatay": [{"y": t_sinir, "etiket": f"sınır {fnum(t_sinir, 1)} s", "renk": "#dc2626"}], "isaretler": [{"x": l, "etiket": "boy"}]}
    satir = []
    for kes in KB.KESIT:
        if (metal == "al" and kes < 16) or kes > 240:
            continue
        q = dict(p, s=kes)
        satir.append([f"{str(kes).replace('.', ',')} mm²" + (" ◀" if kes == s else ""), f"{fnum(KB.iz(kes, yal, metal), 0)} A", f"{fnum(lmax(lambda x: hal(q, x)['du'] <= du_sinir), 0)} m", f"{fnum(lmax(lambda x: hal(q, x)['ik1'] >= ia), 0)} m",
                      "akım taşıma" if KB.iz(kes, yal, metal) < in_a else "uygun" if l <= min(lmax(lambda x: hal(q, x)["du"] <= du_sinir), lmax(lambda x: hal(q, x)["ik1"] >= ia)) else "boy fazla"])
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2, g3],
        "anlatim": [
            f"Kablo bir dirençtir: boyu uzadıkça direnci büyür. {str(s).replace('.', ',')} mm² {'alüminyum' if metal == 'al' else 'bakır'} kablonun kilometresi {fnum(KB.r_km(s, metal, 70.0), 2)} Ω'dur; {fnum(l, 0)} metrede bu, yük akımında %{fnum(h['du'], 2)} gerilim düşümü demektir.",
            "Gerilim düşümü görünen sorundur: motor zor kalkar, lamba soluk yanar. Görünmeyen sorun kısa devrededir. Hat sonundaki bir arızada akımı sınırlayan artık kablonun kendisidir: faz iletkeninden gider, koruma iletkeninden döner.",
            f"Bu devrede hat sonu arıza akımı {fnum(h['ik1'], 0)} A. Panonun başında aynı arıza {fnum(num(p, 'ik', 10.0), 1)} kA olurdu. Kısa hatta koruma arızayı anında açar; uzun hatta arıza akımı cihazın anma akımının birkaç katına düşer.",
            (f"{cihaz_ad} bu akımı {fsure(h['t_ac'])} içinde açıyor: sınırın içinde." if h["t_ac"] <= t_sinir else
             f"{cihaz_ad} {fnum(t_sinir, 1)} saniyede açmak için {fnum(ia, 0)} A ister; hat sonunda {fnum(h['ik1'], 0)} A var. Cihaz bu arızayı bir aşırı yük gibi görür ve " + ("hiç açmaz." if not math.isfinite(h["t_ac"]) else f"{fsure(h['t_ac'])} sonra açar.") + " Bu süre boyunca gövde gerilim altındadır ve kablo ısınır."),
            f"Arıza sürerken koruma iletkeninde düşen gerilim gövdede görünür: yaklaşık {fnum(h['ut'], 0)} V. Süre sınırı (0,4 s) bu gerilimin insan vücudunda öldürücü olmaması için konmuştur.",
            f"Bu devrede sınırlayan {'gerilim düşümü' if l_du < l_ac else 'açma koşulu'}: en büyük boy {fnum(l_en, 0)} m. Kesiti büyütmek ikisini de düzeltir; koruma cihazını değiştirmek (daha düşük manyetik eşik, artık akım koruması) yalnız açma koşulunu düzeltir.",
        ],
        "dersler": [
            "Uzun hatta tehlike, kısa devre akımının büyüklüğü değil küçüklüğüdür: koruma onu görmeyebilir.",
            "Açma koşulu: Zs · Ia ≤ Uo. C eğrili otomatta Ia = 10 × In'dir; uzun hatta B eğrisi ya da RCD gerekir.",
            "Gerilim düşümü sınırları: aydınlatma ve priz %1,5, motor %3 (bağlantı kutusundan sonra).",
            "Koruma iletkeni küçültülürse çevrim empedansı büyür: en büyük boy kısalır.",
            "Çevrim empedansı hesapla bulunur, ölçüyle doğrulanır.",
        ],
        "tablolar": [{"baslik": f"Kesite göre en büyük boy ({fnum(i, 0)} A, {cihaz_ad})", "cols": ["Kesit", "Akım taşıma Iz", "Gerilim düşümüne göre", "Açma koşuluna göre", "Bu boyda"], "rows": satir,
                      "not": "Akım taşıma kapasiteleri çok damarlı kablo, delikli tava, 30 °C içindir; gruplama ve sıcaklık düzeltmeleri ayrıca uygulanır («Kablonun ısınması» sayfası)."}],
    }
