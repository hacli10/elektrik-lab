"""Yağ seviyesi, basınç ve trafonun kendi koruma donanımı: yağ ısınınca genleşir — genleşme depolu trafoda kaptaki seviye yükselir, hermetik trafoda tank
basıncı artar; yağ kaçağı ve iç arızada oluşan gaz hangi cihazı çalıştırır. Kuru tipte yağ yoktur: sargı sıcaklığı PT100 ile izlenir.

Yapı ve donanım TEDAŞ şartnamelerinden (99-032.E, 95-012.F) ve SGB-SMIT işletme kılavuzundandır (resmi). Sayısal model tipiktir (tahmini): yağ hacmi ≈ 14·Sn^0,57 litre,
hacimsel genleşme katsayısı 0,00075 1/K, ortalama yağ artışı üst yağ artışının 0,8'i; genleşme kabı −25…+100 °C aralığını %25 payla karşılayacak büyüklükte;
hermetik tankın esnekliği ortalama yağ 85 °C'de +0,20 bar verecek biçimde; emniyet valfi 0,35 bar, basınç kontağı 0,25 bar, gaz kontağı 150 cm³ (hermetik) /
250 cm³ (Buchholz), termometre 90 / 100 °C. Gerçek değerler trafonun etiketinde ve koruma cihazının kılavuzunda yazar."""
from __future__ import annotations

from . import trafo_model as M
from .ortak import A, C, G, K, S, SGB, SIEMENS_K, T, TEDAS_G, TEDAS_H, Cizim, ctl, fnum, num, pts, tr_al, tr_ctl, tr_girdi

ID = "trafo_yag"
BASLIK = "Yağ seviyesi, basınç, koruma"
IKON = "🛢"
GIRIS = ("Yağ ısınınca genleşir: genleşme depolu trafoda kaptaki seviye yükselir, hermetik trafoda tankın basıncı artar. Soğuk havada, yağ kaçağında ve iç arızada ne olur; "
         "Buchholz, çok fonksiyonlu röle, termometre ve basınç valfi hangi sırayla çalışır? Yükü, ortam sıcaklığını ve kaçağı değiştirip izleyin.")
BETA = 0.00075

KONTROLLER = tr_ctl() + [
    ctl("ta", "Ortam sıcaklığı", "sayi", 25, min=-25, max=50, adim=1, birim="°C"),
    ctl("yuk", "Yük (sürekli)", "sayi", 80, min=0, max=160, adim=5, birim="%"),
    ctl("ref", "Hermetik › doldurma (referans) sıcaklığı", "sayi", 20, min=0, max=40, adim=1, birim="°C", goster={"tip": ["hermetik"]}, yardim="Tank bu yağ sıcaklığında basınçsızdır; etikette yazar"),
    ctl("kacak", "Yağ kaçağı (kaybedilen yağ)", "sayi", 0, min=0, max=150, adim=5, birim="litre", goster={"tip": ["hermetik", "genlesme"]}),
    ctl("gaz", "İç arızada biriken gaz", "sayi", 0, min=0, max=600, adim=10, birim="cm³", goster={"tip": ["hermetik", "genlesme"]}, yardim="Sarımlar arası kısa devre, kötü kontak ya da çekirdek ısınması yağı ayrıştırır: gaz üste toplanır"),
    ctl("fan", "Kuru tip › fan var", "onay", True, goster={"tip": ["kuru"]}),
]


def hacim(sn: float) -> float:
    return 14.0 * sn ** 0.57


def ort_yag(ta: float, ust: float) -> float:
    return ta + 0.8 * (ust - ta)


def durum(tip: str, sn: float, ort: float, ust: float, ref: float, kacak: float, gaz: float) -> dict:
    v = hacim(sn)
    if tip == "genlesme":
        vk = BETA * v * 125 * 1.25                       # genleşme kabı hacmi
        icinde = 0.10 * vk + BETA * v * (ort + 25) - kacak
        return {"v": v, "vk": vk, "seviye": max(icinde / vk * 100, 0.0), "bos": icinde <= 0, "p": 0.0,
                "gaz_ihbar": gaz >= 250 or icinde <= 0, "gaz_acma": gaz >= 500 or icinde <= -0.02 * v, "seviye_ihbar": icinde / vk < 0.08}
    ct = BETA * v * 65 / 0.20                            # tankın esnekliği (litre / bar)
    p = (BETA * v * (ort - ref) - kacak) / ct
    return {"v": v, "ct": ct, "p": p, "seviye": None, "valf": p >= 0.35, "basinc": p >= 0.25, "gaz_ihbar": gaz >= 150 or p < -0.30, "vakum": p < -0.15}


def run(p: dict) -> dict:
    tr = tr_al(p); tip = tr["tip"]
    ta, k, ref, kacak, gaz = num(p, "ta", 25), num(p, "yuk", 80) / 100, num(p, "ref", 20), num(p, "kacak", 0), num(p, "gaz", 0)
    fan = bool(p.get("fan", True))
    r = tr["pk"] / tr["p0"]
    kuru = tip == "kuru"
    s = M.surekli("kuru" if kuru else "yag", k, ta, r, fan=fan and kuru and (ta + M.KURU["d_pt"] * k ** M.KURU["q"]) >= M.KURU_FAN_AC)
    c = Cizim(900, 330)
    if kuru:
        pt, sn = s["pt"], s["sn"]
        fan_on = fan and (ta + M.KURU["d_pt"] * k ** M.KURU["q"]) >= M.KURU_FAN_AC
        for j in range(3):
            c.dikdortgen(60 + j * 90, 80, 64, 190, "#b45309", "#fde68a", kw=2)
        c.cihaz(380, 60, f"{fnum(pt, 0)} °C", "sıcaklık denetimi (PT100)", ok=pt < M.KURU_IHBAR)
        c.kutu(380, 140, 150, 44, "Fan", "çalışıyor" if fan_on else "duruyor" if fan else "yok", "acti" if fan_on else "pasif")
        c.kutu(550, 140, 150, 44, "İhbar 130 °C", "verildi" if pt >= M.KURU_IHBAR else "yok", "gecersiz" if pt >= M.KURU_IHBAR else "normal")
        c.kutu(720, 140, 150, 44, "Açma 150 °C", "AÇTI" if pt >= M.KURU_ACMA else "yok", "gecersiz" if pt >= M.KURU_ACMA else "normal")
        c.yazi(380, 220, "Kuru tip trafoda yağ, genleşme kabı, Buchholz ve basınç valfi yoktur.", "#334155", 12, kalin=True)
        c.yazi(380, 242, f"Sargının en sıcak yeri {fnum(sn, 0)} °C; algılayıcı {fnum(pt, 0)} °C gösteriyor.", "#334155", 11.5)
        c.yazi(380, 264, "İç arızayı sıcaklık denetimi geç görür: asıl koruma OG aşırı akım / diferansiyel rölesidir.", "#64748b", 11)
        ozet = [K("PT100 göstergesi", f"{fnum(pt, 0)} °C", "bad" if pt >= M.KURU_ACMA else "warn" if pt >= M.KURU_IHBAR else "ok", "ihbar 130 · açma 150 °C"),
                K("Sargı sıcak noktası", f"{fnum(sn, 0)} °C", "bad" if sn > 155 else "ok", "F sınıfı sınırı 155 °C"), K("Fan", "çalışıyor" if fan_on else "duruyor" if fan else "yok", "info", "100 °C'de girer, 80 °C'de çıkar"),
                K("Yağ", "yok", "info", "soğutma havayla"), K("İç arıza algılama", "akım korumaları", "info", "gaz / basınç algılaması yok")]
        kontroller = [C("Sıcaklık denetimi açma eşiği", f"PT100 {fnum(pt, 0)} °C", "< 150 °C", pt < M.KURU_ACMA, SIEMENS_K + " böl. 7.1", "resmi"),
                      C("Sıcaklık denetimi ihbar eşiği", f"PT100 {fnum(pt, 0)} °C", "< 130 °C", pt < M.KURU_IHBAR, SIEMENS_K + " böl. 7.1", "resmi"),
                      C("Sargı sıcak noktası", f"{fnum(sn, 0)} °C", "≤ 155 °C (F sınıfı)", sn <= 155, tr["kaynak"] + " böl. 2.2.9", "resmi")]
        ayarlar = [S("Sıcaklık denetim cihazı › ihbar / açma", "130 °C / 150 °C", "üretici ayarı", "Algılayıcılar üç fazın sargısına yerleştirilir", SIEMENS_K + " böl. 7.1"),
                   S("Fan › giriş / çıkış", "100 °C / 80 °C", "üretici ayarı", "Geçici aşırı yükte soğutmayı artırır", SIEMENS_K + " böl. 7.1")]
        ks = [j / 20 for j in range(0, 33)]
        g1 = {"baslik": "Yüke göre sargı sıcaklığı (sürekli rejim, fansız)", "x_ad": "Yük (% Sn)", "y_ad": "Sıcaklık (°C)",
              "seriler": [{"ad": "sıcak nokta", "renk": "#dc2626", "pts": pts([x * 100 for x in ks], [M.surekli("kuru", x, ta, r)["sn"] for x in ks], 1)},
                          {"ad": "PT100", "renk": "#b45309", "pts": pts([x * 100 for x in ks], [M.surekli("kuru", x, ta, r)["pt"] for x in ks], 1)}],
              "yatay": [{"y": 150, "etiket": "açma", "renk": "#7c3aed"}, {"y": 130, "etiket": "ihbar", "renk": "#d97706"}, {"y": 100, "etiket": "fan", "renk": "#1d4ed8"}], "isaretler": [{"x": k * 100, "etiket": "yük"}]}
        return {"ozet": ozet, "kontroller": kontroller, "girdiler": tr_girdi(tr), "ayarlar": ayarlar, "sahne": c.sahne(), "grafikler": [g1],
                "adimlar": [A("Sargı sıcaklığı", "θ = θ(ortam) + Δθr · K^1,6", f"{fnum(ta, 0)} + 115 × {fnum(k, 2)}^1,6" + (" × 0,6 (fan)" if fan_on else ""), f"sıcak nokta {fnum(sn, 0)} °C · PT100 {fnum(pt, 0)} °C", "«Isınma, aşırı yük ve ömür» sayfasındaki model", "tahmini")],
                "test": [T("Sıcaklık denetimi", "PT100 yerine direnç kutusu: 138,5 Ω (100 °C), 149,8 Ω (130 °C), 157,3 Ω (150 °C)", "fan girer · ihbar · açma", "PT100: 0 °C'de 100 Ω, derece başına ≈ 0,385 Ω")],
                "anlatim": ["Kuru tip trafoda yağ yoktur: genleşme, seviye, basınç ve gaz konuları bu tipte geçerli değildir.", "Isı sargının yüzeyinden doğrudan havaya geçer; soğutmayı odanın havalandırması ve varsa fanlar belirler.",
                            f"Bu yükte ve ortamda algılayıcı {fnum(pt, 0)} °C gösteriyor. Fan 100 °C'de devreye girer, ihbar 130 °C'de, açma 150 °C'de verilir.",
                            "Sıcaklık denetimi yavaş bir korumadır: aşırı yükü ve tıkalı havalandırmayı görür. Sargı içi kısa devreyi akım korumaları (aşırı akım, diferansiyel) görür."],
                "dersler": ["Kuru tip trafonun «yağ seviyesi» yoktur; izlenen tek büyüklük sargı sıcaklığıdır.", "PT100 en sıcak noktada değildir: gösterge sıcak noktadan soğuktur.", "Tozlanmış sargı ve tıkalı havalandırma, aynı yükte sıcaklığı yükseltir: yıllık temizlik korumanın parçasıdır."]}

    ust = s["yag"]; ort = ort_yag(ta, ust)
    d = durum(tip, tr["sn"], ort, ust, ref, kacak, gaz)
    t_ihbar, t_acma = ust >= M.YAG_IHBAR, ust >= M.YAG_ACMA
    c.dikdortgen(70, 110, 240, 190, "cizgi", "#fef9c3", kw=2.4)
    c.dikdortgen(150, 150, 80, 130, "cizgi", "#fff"); c.yazi(190, 220, "sargı", "#475569", 10.5, anchor="middle")
    c.yazi(190, 134, f"üst yağ {fnum(ust, 0)} °C", "#b45309", 11.5, kalin=True, anchor="middle"); c.yazi(190, 296, f"ortalama yağ {fnum(ort, 0)} °C", "#a16207", 10.5, anchor="middle")
    if gaz > 0:
        c.daire(260, 122, 7, "ariza", "#fff"); c.daire(274, 118, 5, "ariza", "#fff"); c.yazi(250, 104, f"gaz {fnum(gaz, 0)} cm³", "#b91c1c", 10.5, kalin=True)
    if tip == "genlesme":
        sev = max(min(d["seviye"], 100), 0)
        c.dikdortgen(190, 20, 200, 50, "cizgi", "#fff", kw=2)
        if sev > 0:
            c.dikdortgen(190, 20 + 50 * (1 - sev / 100), 200, 50 * sev / 100, "cizgi", "#fde68a", kw=0.5, r=0)
        c.yazi(290, 14, f"genleşme kabı — seviye %{fnum(d['seviye'], 0)}", "#a16207" if not d["seviye_ihbar"] else "#b91c1c", 11.5, kalin=True, anchor="middle")
        c.hat("M210,70 V110", "cizgi", w=4)
        c.dikdortgen(198, 80, 24, 18, "ariza" if d["gaz_ihbar"] else "mavi", "#fee2e2" if d["gaz_ihbar"] else "#dbeafe"); c.yazi(228, 94, "Buchholz", "#b91c1c" if d["gaz_ihbar"] else "#1d4ed8", 10.5)
        c.hat("M390,34 h28 v36", "cizgi", w=1.6); c.dikdortgen(408, 70, 20, 30, "uyari", "#ffedd5"); c.yazi(434, 90, "nem alıcı", "#b45309", 10.5)
        ks_ = [("Buchholz 1. kademe (gaz / seviye)", d["gaz_ihbar"], "ihbar"), ("Buchholz 2. kademe (yağ akışı / boşalma)", d["gaz_acma"], "AÇMA"), ("Yağ seviye göstergesi", d["seviye_ihbar"], "düşük seviye"),
               ("Termometre 1. kontak (90 °C)", t_ihbar, "ihbar"), ("Termometre 2. kontak (100 °C)", t_acma, "AÇMA")]
    else:
        for j in range(9):
            w_ = 14 + max(min(d["p"], 0.4), -0.3) * 30
            c.hat(f"M{70 - 2},{122 + j * 20} h-{fnum(w_, 0)}", "cizgi", w=2); c.hat(f"M{310 + 2},{122 + j * 20} h{fnum(w_, 0)}", "cizgi", w=2)
        c.cihaz(90, 30, f"{'+' if d['p'] >= 0 else '−'}{fnum(abs(d['p']), 2)} bar", "tank basıncı (atmosfere göre)", ok=-0.15 <= d["p"] < 0.25)
        c.dikdortgen(250, 94, 20, 16, "ariza" if d["valf"] else "cizgi", "#fee2e2" if d["valf"] else "#fff"); c.yazi(276, 100, "emniyet valfi" + (" AÇTI" if d["valf"] else ""), "#b91c1c" if d["valf"] else "#475569", 10.5, kalin=d["valf"])
        ks_ = [("Basınç kontağı (0,25 bar)", d["basinc"], "AÇMA"), ("Emniyet valfi (0,35 bar)", d["valf"], "yağ atar"), ("Gaz / yağ seviyesi şamandırası", d["gaz_ihbar"], "AÇMA"),
               ("Sıcaklık 1. kademe (90 °C)", t_ihbar, "ihbar"), ("Sıcaklık 2. kademe (100 °C)", t_acma, "AÇMA")]
    c.yazi(470, 30, "Koruma donanımının durumu", "#334155", 12, kalin=True)
    for j, (ad, calisti, ne) in enumerate(ks_):
        c.kutu(470, 44 + j * 50, 400, 40, ad, ne.upper() + " verdi" if calisti else "çalışmadı", "gecersiz" if calisti else "normal")
    c.yazi(70, 322, f"Yağ hacmi ≈ {fnum(d['v'], 0)} litre · genleşme " + f"{fnum(BETA * d['v'] * (ort - (ref if tip == 'hermetik' else 20)), 1)} litre" + (f" · kaçak {fnum(kacak, 0)} litre" if kacak else ""), "#334155", 11)

    calisan = [ad for ad, x, _ in ks_ if x]
    ozet = [
        K("Üst yağ sıcaklığı", f"{fnum(ust, 0)} °C", "bad" if t_acma else "warn" if t_ihbar else "ok", f"ortalama {fnum(ort, 0)} °C · sıcak nokta {fnum(s['sn'], 0)} °C"),
        K("Yağın genleşmesi", f"{fnum(BETA * d['v'] * (ort - (ref if tip == 'hermetik' else 20)), 1)} litre", "info", f"{fnum(d['v'], 0)} litre yağ · 0,00075 /K"),
        (K("Genleşme kabı seviyesi", f"%{fnum(d['seviye'], 0)}", "bad" if d["bos"] else "warn" if d["seviye_ihbar"] else "ok", "kap boşaldı" if d["bos"] else "göstergede izlenir") if tip == "genlesme" else
         K("Tank basıncı", f"{'+' if d['p'] >= 0 else '−'}{fnum(abs(d['p']), 2)} bar", "bad" if d["valf"] or d["basinc"] or d["vakum"] else "ok", "eksik basınç: içeri hava / nem çekme riski" if d["vakum"] else "atmosfere göre")),
        K("Biriken gaz", f"{fnum(gaz, 0)} cm³", "bad" if d["gaz_ihbar"] and gaz > 0 else "ok", "iç arıza belirtisi" if gaz > 0 else "yok"),
        K("Çalışan koruma", str(len(calisan)) if calisan else "yok", "bad" if calisan else "ok", calisan[0] if calisan else "hepsi sakin"),
    ]
    if tip == "genlesme":
        kontroller = [
            C("Genleşme kabında yağ var mı?", f"seviye %{fnum(d['seviye'], 0)}", "> %8 (göstergenin alt işareti)", not d["seviye_ihbar"], "Kap, en soğuk havada boşalmayacak ve en sıcak yağda taşmayacak büyüklüktedir; seviye manyetik göstergeden izlenir — " + TEDAS_G + " böl. 2.3.8", "resmi"),
            C("Kap taşıyor mu?", f"seviye %{fnum(d['seviye'], 0)}", "< %100", d["seviye"] < 100, "Aşırı yükte yağ beklenenden çok genleşirse nem alıcıdan dışarı atılır", "tahmini"),
            C("Buchholz rölesi sakin mi?", "gaz " + fnum(gaz, 0) + " cm³" + (" · kap boş" if d["bos"] else ""), "1. kademe ≈ 250 cm³ gaz ya da seviye düşmesi", not d["gaz_ihbar"], "İki kademeli: 1. kademe gaz birikmesinde ihbar, 2. kademe yağ akışında / boşalmada açma — " + TEDAS_G + " böl. 2.3.11; eşik tipik", "tahmini"),
            C("Üst yağ sıcaklığı", f"{fnum(ust, 0)} °C", "< 100 °C (termometre açma kontağı)", not t_acma, "Çift kontaklı termometre — " + TEDAS_G + " böl. 2.3.11; eşik tipik", "tahmini"),
        ]
        ayarlar = [
            S("Buchholz rölesi › 1. kademe", "ihbar", "gaz ≈ 100–300 cm³", "Yavaş gelişen iç arızayı (kötü kontak, çekirdek ısınması) ve yağ eksilmesini bildirir", TEDAS_G + " böl. 2.3.11"),
            S("Buchholz rölesi › 2. kademe", "açma", "yağ akışı ≈ 1 m/s", "Şiddetli iç arızada yağ kaba doğru hızla akar; kesici açtırılır", TEDAS_G + " böl. 2.3.11"),
            S("Termometre › 1. / 2. kontak", "90 °C ihbar / 100 °C açma", "ayarlanabilir", "Aşırı yükü ve soğutma bozukluğunu görür", "tipik ayar", "tahmini"),
            S("Nem alıcı", "tanelerin 2/3'ü renk değiştirince yenilenir", "—", "Kap her soğumada dışarıdan hava çeker; nem yağın delinme gerilimini düşürür", SGB + " böl. 3.3"),
            S("Yağ delinme gerilimi", "yeni ≥ 50 kV · işletmede ≥ 30 kV", "—", "30 kV'un altında yağ arıtılır", SGB + " böl. 5"),
        ]
    else:
        kontroller = [
            C("Tank basıncı işletme aralığında mı?", f"{fnum(d['p'], 2)} bar", "−0,15 … +0,25 bar", -0.15 <= d["p"] < 0.25, "Tank referans sıcaklıkta basınçsızdır; yağ ısınınca aşırı, soğuyunca eksik basınç oluşur ve dalga duvar esneyerek karşılar — " + SGB + " böl. 1; sınırlar tipik", "tahmini"),
            C("Emniyet valfi kapalı mı?", f"{fnum(d['p'], 2)} bar", "< 0,35 bar", not d["valf"], "Basınç emniyet valfi bütün trafolarda bulunur; azami işletme basıncı ile yırtılma basıncı arasında en az 0,3 bar fark istenir — " + TEDAS_H + " böl. 2.3.6", "resmi"),
            C("Gaz / seviye kontağı sakin mi?", "gaz " + fnum(gaz, 0) + " cm³" + (" · eksik basınç" if d["vakum"] else ""), "≈ 150 cm³ gaz ya da yağ seviyesinin düşmesi", not d["gaz_ihbar"], "Çok fonksiyonlu rölenin şamandırası gaz birikince ya da yağ eksilince düşer — " + TEDAS_H + " böl. 2.3.11; eşik tipik", "tahmini"),
            C("Üst yağ sıcaklığı", f"{fnum(ust, 0)} °C", "< 100 °C (2. kademe açma)", not t_acma, "Sıcaklık koruması iki kademeli: 1. kademe ihbar, 2. kademe açma — " + TEDAS_H + " böl. 2.3.11; eşik tipik", "tahmini"),
            C("Hermetiklik", "doldurma tapası kapalı ve mühürlü", "açılmaz", None, "Tapa açılırsa basınç ayarı bozulur ve içeri hava girer; yağ alınacaksa kılavuzdaki sıra izlenir — " + SGB + " böl. 1 ve 4.6", "resmi"),
        ]
        ayarlar = [
            S("Çok fonksiyonlu röle › sıcaklık", "1. kademe ihbar · 2. kademe açma", "ayarlanabilir (tipik 90 / 100 °C)", "Aşırı yük ve soğutma bozukluğu", TEDAS_H + " böl. 2.3.11"),
            S("Çok fonksiyonlu röle › basınç", "açma", "tipik 0,2–0,3 bar", "İç arızada ark yağı buharlaştırır: basınç milisaniyeler içinde yükselir", TEDAS_H + " böl. 2.3.11"),
            S("Çok fonksiyonlu röle › gaz birikmesi / yağ kaçağı", "açma", "şamandıra", "Yavaş gelişen arıza ve yağ eksilmesi", TEDAS_H + " böl. 2.3.11"),
            S("Basınç emniyet valfi", "yağ atarak basıncı düşürür", "tipik ≈ 0,35 bar", "Tankın yırtılmasını önler; elektriksel açma vermeyebilir", TEDAS_H + " böl. 2.3.6"),
            S("Etiket › hermetik basınç ayarı", f"doldurma sıcaklığı {fnum(ref, 0)} °C", "—", "Yağ alındıktan sonra basınç bu bilgiyle yeniden ayarlanır", SGB + " böl. 4.6"),
        ]
    girdiler = tr_girdi(tr) + [
        G("Yağ miktarı", f"≈ {fnum(d['v'], 0)} litre", "Trafo etiketi (yağ ağırlığı, kg)", "Genleşen hacim yağ miktarıyla orantılıdır", "ΔV = β · V · Δθ"),
        G("Yağ sıcaklığı", f"üst {fnum(ust, 0)} °C · ortalama {fnum(ort, 0)} °C", "Termometre (üst yağ); ortam ve yük", "Seviyeyi ve basıncı ortalama yağ sıcaklığı belirler", "θ(ort) ≈ ortam + 0,8 × üst yağ artışı"),
    ]
    adimlar = [
        A("Üst yağ sıcaklığı", "θo = θa + 60 · [(1 + R·K²) / (1 + R)]^0,8", f"ortam {fnum(ta, 0)} °C · yük %{fnum(k * 100, 0)} · R = {fnum(r, 1)}", f"{fnum(ust, 0)} °C", "«Isınma, aşırı yük ve ömür» sayfasındaki model", "dogrulanacak", ["Kayıplar"]),
        A("Ortalama yağ sıcaklığı", "θ(ort) ≈ θa + 0,8 · (θo − θa)", f"{fnum(ta, 0)} + 0,8 × {fnum(ust - ta, 0)}", f"{fnum(ort, 0)} °C", "tankın altı üstünden soğuktur", "tahmini", ["Yağ sıcaklığı"]),
        A("Genleşen hacim", "ΔV = β · V · (θ(ort) − θ(ref))", f"0,00075 × {fnum(d['v'], 0)} × ({fnum(ort, 0)} − {fnum(ref if tip == 'hermetik' else 20, 0)})", f"{fnum(BETA * d['v'] * (ort - (ref if tip == 'hermetik' else 20)), 1)} litre", "mineral yağın hacimsel genleşmesi — katsayı tipik", "tahmini", ["Yağ miktarı"]),
        (A("Kaptaki seviye", "seviye = (kaptaki yağ) / (kap hacmi)", f"kap ≈ {fnum(d['vk'], 0)} litre · kaçak {fnum(kacak, 0)} litre", f"%{fnum(d['seviye'], 0)}", "kap −25…+100 °C aralığını karşılayacak büyüklükte alınmıştır", "tahmini") if tip == "genlesme" else
         A("Tank basıncı", "p = (ΔV − kaçak) / C(tank)", f"tank esnekliği ≈ {fnum(d['ct'], 0)} litre/bar", f"{fnum(d['p'], 2)} bar", "dalga duvar yay gibi davranır: hacim arttıkça basınç doğrusal artar", "tahmini")),
    ]
    test = [
        T("Yağ seviyesi / basınç", "Gösterge okunur; yağ sıcaklığı ile birlikte not edilir", f"%{fnum(d['seviye'], 0)}" if tip == "genlesme" else f"{fnum(d['p'], 2)} bar (göstergeli tiplerde)", "aynı sıcaklıkta seviye yıldan yıla düşüyorsa kaçak vardır"),
        T("Koruma kontakları", "Buchholz deneme düğmesi / çok fonksiyonlu rölenin deneme kolu", "ihbar ve açma kontakları çalışır; kesici açar", "yılda bir, enerjisizken"),
        T("Gaz örneği", "Rölede biriken gaz alınır: renk, koku, yanıcılık", "renksiz ve yanmayan gaz: hava; yanıcı gaz: iç arıza", "yanıcı gaz varsa trafo yeniden enerjilenmez, yağda gaz analizi yapılır"),
        T("Yağ delinme gerilimi", "Alt vanadan örnek, 2,5 mm aralıklı deney kabı", "yeni yağ ≥ 50 kV · işletmede ≥ 30 kV", "hermetik trafoda örnek almadan önce kılavuzdaki sıra izlenir"),
    ]
    ts_ = list(range(-25, 111, 5))
    if tip == "genlesme":
        g1 = {"baslik": "Kaptaki seviye – ortalama yağ sıcaklığı", "x_ad": "Ortalama yağ sıcaklığı (°C)", "y_ad": "Seviye (%)",
              "seriler": [{"ad": "kaçak yok", "renk": "#1a4d8f", "pts": pts(ts_, [durum(tip, tr["sn"], t, t, ref, 0, 0)["seviye"] for t in ts_], 1)}] +
                         ([{"ad": f"{fnum(kacak, 0)} litre kaçak", "renk": "#dc2626", "pts": pts(ts_, [durum(tip, tr["sn"], t, t, ref, kacak, 0)["seviye"] for t in ts_], 1)}] if kacak else []),
              "yatay": [{"y": 8, "etiket": "düşük seviye", "renk": "#dc2626"}, {"y": 100, "etiket": "kap dolu", "renk": "#d97706"}], "isaretler": [{"x": ort, "etiket": "şimdi"}]}
    else:
        g1 = {"baslik": "Tank basıncı – ortalama yağ sıcaklığı", "x_ad": "Ortalama yağ sıcaklığı (°C)", "y_ad": "Basınç (bar, atmosfere göre)",
              "seriler": [{"ad": "kaçak yok", "renk": "#1a4d8f", "pts": pts(ts_, [durum(tip, tr["sn"], t, t, ref, 0, 0)["p"] for t in ts_], 3)}] +
                         ([{"ad": f"{fnum(kacak, 0)} litre kaçak", "renk": "#dc2626", "pts": pts(ts_, [durum(tip, tr["sn"], t, t, ref, kacak, 0)["p"] for t in ts_], 3)}] if kacak else []),
              "yatay": [{"y": 0.35, "etiket": "emniyet valfi", "renk": "#dc2626"}, {"y": 0.25, "etiket": "basınç kontağı", "renk": "#7c3aed"}, {"y": 0, "etiket": "basınçsız", "renk": "#94a3b8"}],
              "isaretler": [{"x": ort, "etiket": "şimdi"}, {"x": ref, "etiket": "doldurma"}]}
    ks = [j / 20 for j in range(0, 33)]
    g2 = {"baslik": "Yüke göre yağ sıcaklığı (sürekli rejim)", "x_ad": "Yük (% Sn)", "y_ad": "Sıcaklık (°C)",
          "seriler": [{"ad": "üst yağ", "renk": "#b45309", "pts": pts([x * 100 for x in ks], [M.surekli("yag", x, ta, r)["yag"] for x in ks], 1)},
                      {"ad": "sıcak nokta", "renk": "#dc2626", "pts": pts([x * 100 for x in ks], [M.surekli("yag", x, ta, r)["sn"] for x in ks], 1)}],
          "yatay": [{"y": 100, "etiket": "termometre açma", "renk": "#7c3aed"}, {"y": 90, "etiket": "ihbar", "renk": "#d97706"}], "isaretler": [{"x": k * 100, "etiket": "yük"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"Trafoda yaklaşık {fnum(d['v'], 0)} litre yağ var. Mineral yağ her derecede hacminin on binde yedi buçuğu kadar genleşir: soğuk kış gecesi ile tam yükteki yaz günü arasında hacim %7–9 değişir.",
            ("Genleşme depolu trafoda bu fazlalık üstteki kaba çıkar; kaptaki yağın üstü havadır ve kap nem alıcı üzerinden nefes alır. Seviye, yağın sıcaklığını izler: soğukta düşer, yükte yükselir."
             if tip == "genlesme" else "Hermetik trafoda tank tamamen yağla doludur ve atmosfere kapalıdır. Yağ genleşince dalga duvarlar dışarı esner; tankın basıncı artar. Doldurma sıcaklığında basınç sıfırdır, altında tank içe çeker."),
            (f"Şimdi ortalama yağ {fnum(ort, 0)} °C: " + (f"kaptaki seviye %{fnum(d['seviye'], 0)}." if tip == "genlesme" else f"tank basıncı {fnum(d['p'], 2)} bar.")),
            ("Yağ kaçağı seviyeyi düşürür; kap boşalınca Buchholz rölesinin üst şamandırası düşer ve ihbar verir, yağ daha da eksilirse alt şamandıra açtırır." if tip == "genlesme" else
             "Yağ kaçağı basıncı düşürür: tank eksik basınca geçer, conta ve buşinglerden içeri hava ve nem çekebilir. Yağ seviyesi kapağın altına inince rölenin şamandırası düşer ve açtırır."),
            "İç arızada (sarımlar arası kısa devre, kötü kontak, çekirdek ısınması) ark ve aşırı ısı yağı ayrıştırır: yanıcı gazlar oluşur ve tankın en üstüne toplanır. " +
            ("Buchholz rölesi kap ile tank arasındaki boruda bu gazı tutar." if tip == "genlesme" else "Çok fonksiyonlu röle kapağın üstünde bu gazı tutar; şiddetli arızada basınç kontağı daha önce çalışır."),
            "Bu korumalar elektriksel korumalardan bağımsızdır ve onlardan önce uyarır: sarımlar arası kısa devre uç akımını çok az değiştirir, aşırı akım rölesi görmez; gaz ve basınç görür.",
        ],
        "dersler": [
            "Seviye ya da basınç tek başına anlam taşımaz; yağ sıcaklığıyla birlikte okunur.",
            "Genleşme depolu trafo nefes alır: nem alıcı bakımı yağın ömrüdür. Hermetik trafo nefes almaz: tapası açılmaz.",
            "Buchholz ihbarında gazın yanıcı olup olmadığına bakılır. Yanıcı gaz varken trafo yeniden enerjilenmez.",
            "Emniyet valfi tankı korur, trafoyu devreden çıkarmaz; açmayı basınç kontağı ya da Buchholz'un 2. kademesi yapar.",
            "İç arızayı en erken gören koruma çoğu zaman en ucuz olanıdır: gaz ve basınç.",
        ],
        "tablolar": [{"baslik": "Olay — hangi koruma görür", "cols": ["Olay", "Genleşme depolu", "Hermetik", "Kuru tip"],
                      "rows": [["Aşırı yük, tıkalı soğutma", "termometre (üst yağ)", "çok fonksiyonlu röle › sıcaklık", "PT100 sıcaklık denetimi"], ["Yağ kaçağı", "seviye göstergesi → Buchholz 1. kademe", "şamandıra (seviye) › açma", "—"],
                               ["Yavaş gelişen iç arıza (gaz)", "Buchholz 1. kademe", "gaz birikmesi kontağı", "kısmi boşalma ölçüsü; akım korumaları"], ["Şiddetli iç arıza (ark)", "Buchholz 2. kademe (yağ akışı)", "basınç kontağı; emniyet valfi", "OG aşırı akım / diferansiyel"],
                               ["Soğuk hava, düşük yük", "seviye düşer", "tank eksik basınca geçer", "yoğuşma riski (E2 sınıfı)"]],
                      "not": "Donanım şartnamelerde tanımlıdır (TEDAŞ-MLZ/95-012.F, 99-032.E böl. 2.3.11); 630 kVA'nın altında röle yerine termometre cebi ve seviye göstergesi bulunur."}],
    }
