"""Katı yalıtkanın delinmesi: epoksi, XLPE, PVC, yağlı kâğıt, porselen. Kalınlık ve gerilime göre alan şiddeti; yalıtkanın içindeki hava boşluğunda alanın
yoğunlaşması, kısmi boşalmanın başlaması, ağaçlanma ve delinmeye kadar geçen süre; sıcaklığın etkisi.

Boşlukta alan: levha biçimli boşlukta E(boşluk) = εr·E, küresel boşlukta E = 3εr/(1 + 2εr)·E (temel alan bağıntıları). Boşluğun delinmesi Paschen bağıntısıyla.
Yalıtkanların delinme dayanımı, işletme alan şiddeti ve ömür üssü (t ∝ E^−n) tipik değerlerdir (tahmini). İletken sıcaklık sınırları (XLPE 90 / 250 °C, PVC 70 / 160 °C)
TEDAŞ kablo şartnamelerinden, kuru tip trafoda kısmi boşalma sınırı (10 pC) TEDAŞ-MLZ/99-031.B'den (resmi)."""
from __future__ import annotations

import math

from . import fizik as F
from .ortak import A, C, G, K, S, T, TEDAS_K, Cizim, ctl, fnum, logsp, num, opt, pts

ID = "delinme"
BASLIK = "Katı yalıtkanın delinmesi"
IKON = "🧱"
GIRIS = ("Katı yalıtkan havanın on katı gerilime dayanır ama kendini onarmaz: bir kez delinirse o nokta kalıcı olarak iletkendir. Delinme çoğu zaman yalıtkanın kendisinden değil, "
         "içindeki küçük bir hava boşluğundan başlar. Malzemeyi, kalınlığı ve boşluğun boyunu değiştirin; boşlukta alanın nasıl yoğunlaştığını ve ömrün nasıl kısaldığını izleyin.")
MALZ = ("epoksi", "xlpe", "pvc", "kagit", "porselen")
XLPE_KAYNAK = "TEDAŞ-MLZ/96-018.B (OG XLPE kablo şartnamesi) böl. 2.2.2.2"

KONTROLLER = [
    ctl("malz", "Yalıtkan", "sec", "epoksi", secenek=opt(*[(k, F.YALITKAN[k]["ad"]) for k in MALZ])),
    ctl("u", "Uygulanan gerilim (faz–toprak, etkin)", "sayi", 20.0, min=0.2, max=60, adim=0.2, birim="kV", yardim="36 kV sistemde faz–toprak 20,8 kV"),
    ctl("d", "Yalıtkan kalınlığı", "sayi", 8.0, min=0.5, max=40, adim=0.5, birim="mm"),
    ctl("bosluk", "İçindeki hava boşluğunun boyu", "sayi", 0.2, min=0.0, max=3.0, adim=0.05, birim="mm", yardim="0: boşluksuz (kusursuz döküm). Döküm kabarcığı, ayrılmış katman, çatlak"),
    ctl("sekil", "Boşluğun biçimi", "sec", "levha", secenek=opt(("levha", "Yassı (katman ayrılması, çatlak): alan en çok yoğunlaşır"), ("kure", "Küresel (kabarcık)"))),
    ctl("t", "Yalıtkanın sıcaklığı", "sayi", 60, min=0, max=200, adim=5, birim="°C"),
]


def bosluk_alani(e: float, er: float, sekil: str) -> float:
    return e * (er if sekil == "levha" else 3 * er / (1 + 2 * er))


def run(p: dict) -> dict:
    malz = str(p.get("malz", "epoksi")); m = F.YALITKAN[malz]
    u, d, g, sekil, t = num(p, "u", 20.0), num(p, "d", 8.0), min(num(p, "bosluk", 0.2), num(p, "d", 8.0) * 0.9), str(p.get("sekil", "levha")), num(p, "t", 60)
    e = u / d                                                          # kV/mm etkin (ortalama)
    sic = 1.0 if m["tmax"] is None or t <= m["tmax"] else max(0.3, 1 - 0.006 * (t - m["tmax"]))          # sıcaklık fazlası dayanımı düşürür
    ed = m["ed"] * sic
    pay = ed / e if e else 99
    eb = bosluk_alani(e, m["er"], sekil) if g > 0 else 0.0             # boşluktaki alan (kV/mm etkin)
    ub = eb * g * math.sqrt(2)                                          # boşluk üstündeki gerilim (kV tepe)
    ud = F.paschen(g) if g > 0 else 0.0                                 # boşluğun delinme gerilimi (kV tepe)
    pd = g > 0 and ub >= ud
    u_pd = ud / math.sqrt(2) / (bosluk_alani(1 / d, m["er"], sekil) * g) if g > 0 else None          # kısmi boşalma başlangıç gerilimi (kV etkin)
    n = m["n"] or 10
    # ömür: işletme alanında 30 yıl; alanla ters üs yasası; kısmi boşalma varsa erozyon ömrü belirler
    omur = 30.0 * (m["ei"] / e) ** n if e > 0 else 1e9
    if pd:
        omur = min(omur, 2.0 * (ud / ub) ** 4 * (d / 8.0))
    if t > (m["tmax"] or 1e9):
        omur *= 2 ** (-(t - m["tmax"]) / 10)
    delindi = pay < 1.0
    c = Cizim(900, 300)
    x0, w = 120, 260
    c.dikdortgen(x0, 60, w, 14, "cizgi", "#94a3b8"); c.yazi(x0 + w / 2, 50, f"iletken — {fnum(u, 1)} kV", "#8a4b12", 11.5, kalin=True, anchor="middle")
    c.dikdortgen(x0, 74, w, 150, "cizgi", "#fde68a" if malz in ("epoksi", "kagit") else "#e0f2fe", kw=1.2, r=0); c.yazi(x0 + 10, 96, m["ad"], "#78350f", 11)
    c.dikdortgen(x0, 224, w, 14, "cizgi", "#94a3b8"); c.yazi(x0 + w / 2, 256, "toprak (ekran, gövde)", "#475569", 10.5, anchor="middle"); c.toprak(x0 + w + 30, 232)
    c.hat(f"M{x0 + w},231 h30", "toprak", w=2)
    if g > 0:
        gy = max(150 * g / d, 6)
        if sekil == "levha":
            c.dikdortgen(x0 + 90, 149 - gy / 2, 80, gy, "ariza" if pd else "cizgi", "#fff", kw=1.4, r=2)
        else:
            c.daire(x0 + 130, 149, max(gy / 2, 5), "ariza" if pd else "cizgi", "#fff", w=1.4)
        c.yazi(x0 + 180, 153, f"boşluk {fnum(g, 2)} mm", "#b91c1c" if pd else "#475569", 10.5, kalin=pd)
        if pd:
            c.simsek(x0 + 118, 138, 0.8)
    if delindi:
        c.hat(f"M{x0 + 60},74 l8,40 l-10,36 l12,40 l-6,34", "ariza", hot=True, w=3)
    c.hat(f"M{x0 - 30},74 V224", "mavi", w=1.2); c.yazi(x0 - 36, 153, f"{fnum(d, 1)} mm", "#1d4ed8", 11.5, kalin=True, anchor="end")
    c.yazi(470, 56, "DELİNDİ" if delindi else "Kısmi boşalma var: yalıtkan içten aşınıyor" if pd else "Yalıtkan sağlam", "#b91c1c" if delindi or pd else "#15803d", 14, kalin=True)
    c.yazi(470, 82, f"Ortalama alan {fnum(e, 2)} kV/mm · delinme dayanımı ≈ {fnum(ed, 0)} kV/mm", "#334155", 12.5)
    c.yazi(470, 106, f"Kısa süreli pay × {fnum(pay, 1)} · işletme alanı ≈ {fnum(m['ei'], 1)} kV/mm", "#b91c1c" if e > m["ei"] else "#334155", 12.5)
    if g > 0:
        c.yazi(470, 134, f"Boşluktaki alan {fnum(eb, 1)} kV/mm ({fnum(eb / e, 1)} kat)", "#b91c1c" if pd else "#334155", 12.5, kalin=True)
        c.yazi(470, 158, f"Boşluk üstünde {fnum(ub, 2)} kV-tepe · delinmesi {fnum(ud, 2)} kV-tepe", "#334155", 12)
        c.yazi(470, 182, f"Kısmi boşalma başlangıç gerilimi ≈ {fnum(u_pd, 1)} kV", "#b91c1c" if pd else "#15803d", 12.5, kalin=True)
    c.yazi(470, 212, "Beklenen ömür: " + ("yok" if delindi else f"≈ {fnum(omur * 365, 0)} gün" if omur < 1 else f"≈ {fnum(min(omur, 99), 0)} yıl" + ("+" if omur > 99 else "")), "#b91c1c" if omur < 10 else "#15803d", 13, kalin=True)
    c.yazi(470, 240, "Boşluktaki havanın dielektrik sabiti 1'dir: alan, sabiti büyük olan", "#64748b", 11); c.yazi(470, 256, "katıdan sabiti küçük olan havaya itilir.", "#64748b", 11)
    ozet = [
        K("Ortalama alan", f"{fnum(e, 2)} kV/mm", "bad" if delindi else "warn" if e > m["ei"] else "ok", f"işletme için ≈ {fnum(m['ei'], 1)} kV/mm"),
        K("Delinme payı", f"× {fnum(pay, 1)}", "bad" if pay < 1 else "ok", f"kısa süreli dayanım ≈ {fnum(ed, 0)} kV/mm"),
        K("Boşluktaki alan", f"{fnum(eb, 1)} kV/mm" if g > 0 else "boşluk yok", "bad" if pd else "ok", f"{fnum(eb / e, 1)} kat yoğunlaşma" if g > 0 and e else ""),
        K("Kısmi boşalma", "VAR" if pd else "yok", "bad" if pd else "ok", f"başlangıç ≈ {fnum(u_pd, 1)} kV" if u_pd else "boşluksuz"),
        K("Beklenen ömür", "delindi" if delindi else f"{fnum(omur * 365, 0)} gün" if omur < 1 else f"{fnum(min(omur, 99), 0)}{'+' if omur > 99 else ''} yıl", "bad" if omur < 10 else "ok", "alan, boşluk ve sıcaklığa göre"),
    ]
    kontroller = [
        C("Alan, kısa süreli delinme dayanımının altında mı?", f"{fnum(e, 2)} kV/mm", f"< {fnum(ed, 0)} kV/mm", not delindi, "Delinme dayanımı ince örnekte, kısa süreli deneyle ölçülür; kalın yalıtkanda ve uzun sürede bunun küçük bir kesri kullanılır — tipik değerler", "tahmini"),
        C("Alan, işletme alan şiddetinin içinde mi?", f"{fnum(e, 2)} kV/mm", f"≤ {fnum(m['ei'], 1)} kV/mm", e <= m["ei"] + 1e-9, "OG yalıtımında ortalama alan birkaç kV/mm'de tutulur: 36 kV XLPE kabloda 8 mm yalıtkan, faz–toprak 20,8 kV → 2,6 kV/mm", "tahmini"),
        C("Boşlukta kısmi boşalma başlıyor mu?", f"boşluk üstünde {fnum(ub, 2)} kV-tepe" if g > 0 else "boşluk yok", f"< {fnum(ud, 2)} kV-tepe (boşluğun delinmesi)" if g > 0 else "—", (not pd) if g > 0 else None,
          "Boşluktaki alan εr kat büyür; boşluğun delinme gerilimi Paschen bağıntısından", "hesap"),
        C("Sıcaklık sınırın altında mı?", f"{fnum(t, 0)} °C", f"≤ {m['tmax']} °C" if m["tmax"] else "—", (t <= m["tmax"]) if m["tmax"] else None,
          ("İletken sıcaklığı normal çalışmada 90 °C, kısa devrede 250 °C — " + XLPE_KAYNAK) if malz == "xlpe" else "Normal çalışmada 70 °C, kısa devrede 160 °C — TEDAŞ-MLZ/96-015.A (AG kablo şartnamesi)" if malz == "pvc" else
          "F sınıfı yalıtım sistemi sıcak nokta sıcaklığı 155 °C — " + TEDAS_K + " böl. 2.2.9" if malz == "epoksi" else "A sınıfı yalıtım: 105 °C — TEDAŞ-MLZ/99-032.E böl. 2.3.3 dipnotu" if malz == "kagit" else "tipik", "resmi" if malz in ("xlpe", "pvc", "epoksi", "kagit") else "tahmini"),
        C("Kısmi boşalma düzeyi sınırı (kuru tip trafo)", "≤ 10 pC", "şartname sınırı", None, "Dökme reçineli sargıda kısmi boşalmanın en yüksek değeri 10 pC olmalıdır — " + TEDAS_K + " böl. 2.2.15", "resmi"),
    ]
    girdiler = [
        G("Yalıtkan ve kalınlığı", f"{m['ad']} · {fnum(d, 1)} mm · εr = {fnum(m['er'], 1)}", "Ürün kataloğu, kesit çizimi", "Ortalama alanı kalınlık, boşluktaki alanı dielektrik sabiti belirler", "E = U / d"),
        G("Gerilim", f"{fnum(u, 1)} kV faz–toprak", "Sistem gerilimi / √3; yalıtılmış şebekede toprak arızasında faz arası gerilime çıkar", "Yalıtkanın üstündeki gerilim", "U0 = U / √3"),
        G("Kusur", f"boşluk {fnum(g, 2)} mm, {'yassı' if sekil == 'levha' else 'küresel'}" if g > 0 else "yok", "Kısmi boşalma ölçüsü; üretimde vakum altında döküm", "Ömrü yalıtkanın kendisi değil en büyük kusuru belirler", "E(boşluk) = εr · E"),
    ]
    adimlar = [
        A("Ortalama alan", "E = U / d", f"{fnum(u, 1)} / {fnum(d, 1)}", f"{fnum(e, 2)} kV/mm", "düzlem elektrotlar arasında", "hesap", ["Yalıtkan ve kalınlığı", "Gerilim"]),
        A("Boşluktaki alan", "E(boşluk) = εr · E (yassı) · 3εr/(1 + 2εr) · E (küresel)", f"εr = {fnum(m['er'], 1)}", f"{fnum(eb, 1)} kV/mm" if g > 0 else "boşluk yok", "yer değiştirme akısı süreklidir: D = ε·E iki ortamda eşit", "hesap", ["Kusur"]),
        A("Boşluğun delinme gerilimi", "Paschen: Ud = f(p · d)", f"d = {fnum(g, 2)} mm, 1 bar", f"{fnum(ud, 2)} kV-tepe" if g > 0 else "—", "küçük boşluk yüksek alana dayanır ama üstündeki gerilim de küçüktür", "hesap"),
        A("Kısmi boşalma başlangıç gerilimi", "U(başlangıç) = Ud / (E(boşluk)/U · g · √2)", "boşluğun üstündeki gerilim delinme değerine ulaştığında", f"≈ {fnum(u_pd, 1)} kV etkin" if u_pd else "—", "her yarım periyotta boşluk delinir ve söner", "hesap"),
        A("Ömür", "t ∝ E^(−n) · her 10 K fazlalıkta yarı", f"n ≈ {n} · E / E(işletme) = {fnum(e / m['ei'], 2)}", f"≈ {fnum(min(omur, 99), 1)} yıl" if not delindi else "delindi", "ters üs yasası ve Arrhenius yaklaşımı — sabitler tipik", "tahmini"),
    ]
    ayarlar = [
        S("Kısmi boşalma izleme", "çevrimiçi algılayıcı ya da dönemsel ölçü", "—", "Delinmeden aylar–yıllar önce uyarır", "Topraklama laboratuvarı › Kısmi boşalma", "ikincil"),
        S("Toprak arıza koruması", "delinme faz–toprak arızasıdır", "—", "Katı yalıtkan delindiğinde akım toprağa akar; yalıtılmış şebekede kapasitif akım kadar", "Röle laboratuvarı › Toprak aşırı akım", "ikincil"),
        S("Sıcaklık izleme", "sınıf sıcaklığının altında açma", "—", "Sıcaklık hem dayanımı düşürür hem yaşlanmayı hızlandırır", "saha pratiği", "ikincil"),
    ]
    test = [
        T("Kısmi boşalma ölçüsü", "Deney gerilimi yavaşça artırılır; başlangıç ve sönme gerilimi, pC düzeyi", f"başlangıç gerilimi işletme geriliminin üstünde (burada ≈ {fnum(u_pd, 1)} kV)" if u_pd else "boşalma yok", "kuru tip trafoda ≤ 10 pC"),
        T("Tan δ", "Gerilimle tan δ'nın artışı", "gerilimle sabit", "gerilimle artıyorsa boşluklarda boşalma başlamıştır — Topraklama laboratuvarı › Tan δ"),
        T("Dayanım deneyi", "Şebeke frekanslı ya da VLF, belirli süre", "delinme olmaz", "delinme yıkıcıdır: deney gerilimi yaşlı yalıtkanda azaltılır"),
    ]
    gs = [0.02 * 1.12 ** k for k in range(0, 45) if 0.02 * 1.12 ** k <= 3.0]
    g1 = {"baslik": "Boşluğun boyuna göre kısmi boşalma başlangıç gerilimi", "x_ad": "Boşluğun boyu (mm)", "y_ad": "kV (etkin)", "logx": True,
          "seriler": [{"ad": "yassı boşluk", "renk": "#dc2626", "pts": pts(gs, [F.paschen(x) / math.sqrt(2) / (bosluk_alani(1 / d, m["er"], "levha") * x) for x in gs], 2)},
                      {"ad": "küresel boşluk", "renk": "#1a4d8f", "pts": pts(gs, [F.paschen(x) / math.sqrt(2) / (bosluk_alani(1 / d, m["er"], "kure") * x) for x in gs], 2)}],
          "yatay": [{"y": u, "etiket": "uygulanan", "renk": "#7c3aed"}], "isaretler": ([{"x": g, "etiket": "boşluk"}] if g >= 0.02 else [])}
    es = [m["ei"] * (0.6 + 0.05 * k) for k in range(0, 41)]
    g2 = {"baslik": "Alan şiddetine göre beklenen ömür (boşluksuz)", "x_ad": "Ortalama alan (kV/mm)", "y_ad": "Ömür (yıl)", "logy": True,
          "seriler": [{"ad": m["ad"], "renk": "#b45309", "pts": pts(es, [min(max(30.0 * (m["ei"] / x) ** n, 1e-3), 1e4) for x in es], 3)}],
          "yatay": [{"y": 30, "etiket": "30 yıl", "renk": "#15803d"}], "isaretler": [{"x": e, "etiket": "şimdi"}] if es[0] <= e <= es[-1] else []}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            f"{m['ad']} kısa süreli deneyde milimetre başına yaklaşık {fnum(m['ed'], 0)} kV'a dayanır: havanın {fnum(m['ed'] / 3, 0)} katı. Ama bu sayı işletmede kullanılmaz; otuz yıl dayanması istenen yalıtkan bunun onda biri kadar bir alanla çalıştırılır.",
            f"Burada {fnum(d, 1)} mm kalınlığa {fnum(u, 1)} kV uygulanıyor: ortalama alan {fnum(e, 2)} kV/mm. Kusursuz bir yalıtkan bu alanı " + ("taşıyamaz: delinir." if delindi else "rahatça taşır." if e <= m["ei"] else "kısa süre taşır ama hızla yaşlanır."),
            ("Yalıtkanın içinde hava boşluğu var. Havanın dielektrik sabiti 1, katınınki " + fnum(m["er"], 1) + f": alan çizgileri boşlukta sıkışır ve oradaki alan {fnum(eb / e, 1)} katına çıkar. Üstelik hava, katının onda biri kadar alana dayanır."
             if g > 0 else "Boşluk yok: alan yalıtkanın içinde düzgün dağılır. Vakum altında döküm ve üç katlı ekstrüzyon (kabloda) bunun için yapılır."),
            ("Boşluk her yarım periyotta delinir, üstündeki gerilim çöker ve boşalma söner: bu kısmi boşalmadır. Yalıtkanın tamamı delinmez, ama her boşalma boşluğun duvarını bombardıman eder; duvar aşınır, karbonlaşır, boşluk büyür. İnce kanallar (ağaç) elektroda doğru ilerler."
             if pd else "Boşluğun üstündeki gerilim delinme değerinin altında: kısmi boşalma yok. Gerilim yükselirse (toprak arızasında sağlam fazlar, anahtarlama) başlayabilir." if g > 0 else
             "Yaşlanma yine de sürer: alan ve sıcaklık kimyasal bağları yavaşça koparır. Alan iki katına çıkarsa ömür bin kat kısalır (üs ≈ 10)."),
            "Katı yalıtkan delindiğinde arıza kalıcıdır: delik karbonlaşmış bir kanaldır ve gerilim yeniden uygulandığında hemen iletir. Bu yüzden kablo ve dökme reçineli donanımda tekrar kapama yapılmaz.",
        ],
        "dersler": [
            "Katı yalıtkanı öldüren, içindeki hava boşluğudur: alan boşlukta εr kat büyür, hava ise katının onda birine dayanır.",
            "Kısmi boşalma delinme değildir; delinmenin geri sayımıdır.",
            "Alan iki katına çıkınca ömür yaklaşık bin kat kısalır; sıcaklık 10 K artınca yarıya iner.",
            "Hava kendini onarır, katı onarmaz: kabloda ve dökme reçinede arıza kalıcıdır.",
            "Kısa süreli delinme dayanımı tasarım değeri değildir; işletme alanı onun onda biri mertebesindedir.",
        ],
        "tablolar": [{"baslik": "Yalıtkanların karşılaştırması (tipik değerler)", "cols": ["Malzeme", "εr", "Kısa süreli dayanım", "İşletme alanı", "Sürekli sıcaklık", "Yassı boşlukta yoğunlaşma"],
                      "rows": [[v["ad"], fnum(v["er"], 1), f"{fnum(v['ed'], 0)} kV/mm", f"{fnum(v['ei'], 1)} kV/mm", f"{v['tmax']} °C" if v["tmax"] else "—", f"× {fnum(v['er'], 1)}"] for k, v in F.YALITKAN.items()],
                      "not": "Dayanım değerleri örnek kalınlığına, süreye ve saflığa çok bağlıdır; buradakiler mertebe gösterir. Sıcaklıklar: XLPE ve PVC TEDAŞ kablo şartnamelerinden, epoksi F sınıfı, yağlı kâğıt A sınıfı."}],
    }
