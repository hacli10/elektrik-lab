"""Kablonun ısınması: akım taşıma kapasitesi nereden gelir; ortam sıcaklığı ve yan yana döşenen kabloların (gruplama) etkisi; aşırı yükte iletken sıcaklığının zamanla
yükselmesi; sıcaklığın yalıtkan ömrüne etkisi.

İletken sıcaklığı sürekli rejimde θ = θa + (θmax − 30)·(I / Iz)² (kayıp akımın karesiyle, ısı atımı sıcaklık farkıyla orantılı). Ortam düzeltme çarpanı bu bağıntıdan çıkar:
√((θmax − θa)/(θmax − 30)) (hesap). Akım taşıma çizelgesi ve gruplama çarpanları TS HD 60364-5-52'den bellekle (dogrulanacak). Yalıtkan sıcaklık sınırları TEDAŞ kablo
şartnamelerinden (resmi). Isıl zaman sabiti (τ ≈ 4·S^0,55 dk) ve ömür kuralı (her 8–10 K'de yarı) tipiktir (tahmini)."""
from __future__ import annotations

import math

from . import kablo as KB
from .ortak import A, C, G, K, S, T, Cizim, ctl, fa, fnum, num, opt, pts

ID = "kablo_isi"
BASLIK = "Kablonun ısınması"
IKON = "♨"
GIRIS = ("Kablonun «taşıdığı akım» sabit bir sayı değildir: iletkenin, yalıtkanın dayanabildiği sıcaklığa çıktığı akımdır ve kablonun ısısını nasıl atabildiğine bağlıdır. "
         "Sıcak bir ortamda ya da yan yana altı kabloyla aynı tavada, aynı kablo yarı akımda aynı sıcaklığa çıkar. Koşulları değiştirin; iletken sıcaklığını izleyin.")
GRUP = {1: 1.00, 2: 0.80, 3: 0.70, 4: 0.65, 5: 0.60, 6: 0.57, 7: 0.54, 8: 0.52, 9: 0.50, 12: 0.45, 16: 0.41, 20: 0.38}
GRUP_TAVA = {1: 1.00, 2: 0.88, 3: 0.82, 4: 0.77, 5: 0.75, 6: 0.73, 7: 0.73, 8: 0.72, 9: 0.72, 12: 0.72, 16: 0.72, 20: 0.72}

KONTROLLER = [
    ctl("s", "Kesit", "sec", 35, secenek=opt(*[(k, f"{str(k).replace('.', ',')} mm²") for k in KB.KESIT])),
    ctl("metal", "İletken", "sec", "cu", secenek=opt(("cu", "Bakır"), ("al", "Alüminyum"))),
    ctl("yal", "Yalıtkan", "sec", "pvc", secenek=opt(("pvc", "PVC (sürekli 70 °C)"), ("xlpe", "XLPE (sürekli 90 °C)"))),
    ctl("i", "Yük akımı", "sayi", 100, min=1, max=700, adim=1, birim="A"),
    ctl("ta", "Ortam sıcaklığı", "sayi", 30, min=10, max=60, adim=1, birim="°C"),
    ctl("n", "Aynı yolda yan yana kablo (devre) sayısı", "sec", 1, secenek=opt(*[(k, f"{k}") for k in GRUP])),
    ctl("dosem", "Döşeme", "sec", "tava", secenek=opt(("tava", "Delikli tavada tek kat"), ("demet", "Demet halinde / kanal içinde üst üste"))),
    ctl("asiri", "Aşırı yük (benzetim)", "sayi", 130, min=100, max=200, adim=5, birim="%", yardim="Sürekli rejimden sonra bu akıma çıkılırsa sıcaklık nasıl yükselir"),
]


def run(p: dict) -> dict:
    s, metal, yal, i, ta, n = num(p, "s", 35), str(p.get("metal", "cu")), str(p.get("yal", "pvc")), num(p, "i", 100), num(p, "ta", 30), int(num(p, "n", 1))
    demet = p.get("dosem") == "demet"; asiri = num(p, "asiri", 130) / 100
    th_max = 90.0 if yal == "xlpe" else 70.0
    iz0 = KB.iz(s, yal, metal)
    k_ta = math.sqrt(max(th_max - ta, 0.01) / (th_max - 30))
    k_gr = (GRUP if demet else GRUP_TAVA)[n]
    iz = iz0 * k_ta * k_gr
    th = ta + (th_max - ta) * (i / iz) ** 2 if iz > 0 else 999
    tau = 4.0 * s ** 0.55                                             # dk
    th_asiri = ta + (th_max - ta) * (i * asiri / iz) ** 2
    ts = [k * tau / 10 for k in range(0, 51)]
    egri = [th + (th_asiri - th) * (1 - math.exp(-t / tau)) for t in ts]
    t_sinir = -tau * math.log(1 - (th_max - th) / (th_asiri - th)) if th_asiri > th_max > th else (0.0 if th >= th_max else None)
    omur = 2 ** (-(th - th_max) / (8.0 if yal == "pvc" else 10.0))
    kayip = 3 * i * i * KB.r_km(s, metal, min(th, 150)) / 1000        # W/m (üç iletken)
    c = Cizim(900, 290)
    for j in range(min(n, 9)):
        x = 80 + j * 44
        col = "#fecaca" if th > th_max else "#fde68a" if th > th_max - 15 else "#e2e8f0"
        c.daire(x, 130 - (18 if demet and j % 2 else 0), 20, "ariza" if th > th_max else "cizgi", col, w=1.6); c.daire(x, 130 - (18 if demet and j % 2 else 0), 9, "cizgi", "#fbbf24" if metal == "cu" else "#cbd5e1", w=1)
    c.hat("M50,156 H500", "cizgi", w=4); c.yazi(275, 176, ("demet / kanal" if demet else "delikli tava") + f" · {n} devre", "#475569", 10.5, anchor="middle")
    c.yazi(275, 60, f"iletken sıcaklığı {fnum(min(th, 999), 0)} °C", "#b91c1c" if th > th_max else "#15803d", 14, kalin=True, anchor="middle")
    c.yazi(275, 82, f"ortam {fnum(ta, 0)} °C · sınır {fnum(th_max, 0)} °C", "#64748b", 11, anchor="middle")
    c.yazi(540, 56, f"Çizelge değeri Iz = {fnum(iz0, 0)} A (30 °C, tek başına)", "#334155", 12.5)
    c.yazi(540, 80, f"× ortam {fnum(k_ta, 2)} × gruplama {fnum(k_gr, 2)}", "#334155", 12.5)
    c.yazi(540, 104, f"= bu koşulda {fnum(iz, 0)} A", "#b91c1c" if i > iz else "#15803d", 14, kalin=True)
    c.yazi(540, 130, f"Yük {fnum(i, 0)} A → kapasitenin %{fnum(i / iz * 100, 0)}'i", "#b91c1c" if i > iz else "#334155", 12.5)
    c.yazi(540, 154, f"Kayıp {fnum(kayip, 1)} W/m (üç iletken)", "#334155", 12)
    c.yazi(540, 178, f"Yalıtkan ömrü: anma ömrünün {fnum(min(omur, 99), 2)} katı", "#b91c1c" if omur < 1 else "#334155", 12)
    c.yazi(540, 206, "Isı üretimi akımın karesiyle artar; ısı atımı", "#64748b", 11); c.yazi(540, 222, "kablonun ortamla sıcaklık farkıyla orantılıdır.", "#64748b", 11)
    c.yazi(50, 222, f"%{fnum(asiri * 100, 0)} aşırı yükte sınıra varış: " + ("zaten sınırın üstünde" if t_sinir == 0 else "varmıyor" if t_sinir is None else f"{fnum(t_sinir, 0)} dk"), "#334155", 12)
    c.yazi(50, 246, f"Isıl zaman sabiti ≈ {fnum(tau, 0)} dk: sıcaklık yüke bu gecikmeyle yetişir.", "#64748b", 11.5)
    ozet = [
        K("İletken sıcaklığı", f"{fnum(min(th, 999), 0)} °C", "bad" if th > th_max else "warn" if th > th_max - 10 else "ok", f"sınır {fnum(th_max, 0)} °C"),
        K("Bu koşulda akım taşıma", f"{fnum(iz, 0)} A", "bad" if i > iz else "ok", f"çizelge {fnum(iz0, 0)} A × {fnum(k_ta * k_gr, 2)}"),
        K("Yüklenme", f"%{fnum(i / iz * 100, 0)}", "bad" if i > iz else "ok", f"{fnum(i, 0)} A"),
        K("Aşırı yükte sınıra kadar", "sınırın üstünde" if t_sinir == 0 else "varmıyor" if t_sinir is None else f"{fnum(t_sinir, 0)} dk", "bad" if t_sinir == 0 else "info", f"%{fnum(asiri * 100, 0)} · τ ≈ {fnum(tau, 0)} dk"),
        K("Ömür katsayısı", f"× {fnum(min(omur, 99), 2)}", "bad" if omur < 0.6 else "warn" if omur < 1 else "ok", "anma ömrüne göre"),
    ]
    kontroller = [
        C("İletken sıcaklığı sınırın altında mı?", f"{fnum(min(th, 999), 0)} °C", f"≤ {fnum(th_max, 0)} °C", th <= th_max, ("XLPE: normal çalışmada 90 °C — TEDAŞ-MLZ/96-018.B böl. 2.2.2.2" if yal == "xlpe" else "PVC: normal çalışmada 70 °C — TEDAŞ-MLZ/96-015.A"), "resmi"),
        C("Yük, düzeltilmiş akım taşıma kapasitesinin altında mı?", f"{fnum(i, 0)} A", f"≤ {fnum(iz, 0)} A", i <= iz, "Iz = çizelge değeri × ortam çarpanı × gruplama çarpanı (TS HD 60364-5-52 — çizelge ve çarpanlar asıl metinle doğrulanacak)", "dogrulanacak"),
        C("Ortam düzeltmesi", f"× {fnum(k_ta, 2)}", "√((θmax − θa)/(θmax − 30))", None, "Sıcak ortamda kablonun ısı atabileceği sıcaklık farkı küçülür: aynı sıcaklığa daha az akımda varılır", "hesap"),
        C("Gruplama düzeltmesi", f"× {fnum(k_gr, 2)} ({n} devre)", "çizelge değeri", None, "Yan yana kablolar birbirini ısıtır; demet halinde çarpan daha da düşer (TS HD 60364-5-52 — doğrulanacak)", "dogrulanacak"),
    ]
    girdiler = [
        G("Kablo", f"{str(s).replace('.', ',')} mm² {'Al' if metal == 'al' else 'Cu'} / {yal.upper()}", "Etiket", "Yalıtkan, izin verilen iletken sıcaklığını belirler", f"θmax = {fnum(th_max, 0)} °C"),
        G("Döşeme koşulu", f"{fnum(ta, 0)} °C · {n} devre · {'demet' if demet else 'tava'}", "Güzergâhın en kötü yeri: sıcak hacim, dolu tava, kanal", "Akım taşıma kapasitesini en kötü kesit belirler", "Iz = Iz0 · k(ortam) · k(grup)"),
        G("Yük akımı", f"{fnum(i, 0)} A", "Ölçü ya da yük hesabı; sürekli yük", "Isınma akımın karesiyle artar", "Δθ ∝ I²"),
    ]
    adimlar = [
        A("Ortam çarpanı", "k = √((θmax − θa) / (θmax − 30))", f"√(({fnum(th_max, 0)} − {fnum(ta, 0)}) / ({fnum(th_max, 0)} − 30))", fnum(k_ta, 2), "çizelge 30 °C içindir", "hesap", ["Döşeme koşulu"]),
        A("Düzeltilmiş kapasite", "Iz = Iz0 · k(ortam) · k(grup)", f"{fnum(iz0, 0)} × {fnum(k_ta, 2)} × {fnum(k_gr, 2)}", fa(iz, 0), "çarpanlar çarpılır", "dogrulanacak", ["Kablo"]),
        A("İletken sıcaklığı", "θ = θa + (θmax − θa) · (I / Iz)²", f"{fnum(ta, 0)} + {fnum(th_max - ta, 0)} × ({fnum(i, 0)} / {fnum(iz, 0)})²", f"{fnum(min(th, 999), 0)} °C", "kayıp ∝ I², ısı atımı ∝ sıcaklık farkı", "hesap", ["Yük akımı"]),
        A("Aşırı yükte yükselme", "θ(t) = θ0 + (θ∞ − θ0)·(1 − e^(−t/τ))", f"τ ≈ {fnum(tau, 0)} dk · θ∞ = {fnum(min(th_asiri, 999), 0)} °C", "sınıra " + ("varmıyor" if t_sinir is None else f"{fnum(t_sinir, 0)} dk'da varıyor"), "tek zaman sabitli ısınma — τ tipik", "tahmini"),
        A("Ömür", "L / Ln = 2^(−(θ − θmax) / " + ("8)" if yal == "pvc" else "10)"), f"θ − θmax = {fnum(th - th_max, 0)} K", f"× {fnum(min(omur, 99), 2)}", "Arrhenius yaklaşımı — sabit tipik", "tahmini"),
    ]
    ayarlar = [
        S("Koruma cihazı In", f"≤ {fnum(iz, 0)} A", "Ib ≤ In ≤ Iz", "Cihaz, düzeltilmiş kapasiteye göre seçilir; çizelge değerine göre değil", "TS HD 60364-4-43 (doğrulanacak)", "dogrulanacak"),
        S("Aşırı yük koruması", "I2 ≤ 1,45 · Iz", "—", "Cihazın kesin açma akımı, kablonun kısa süreli dayanabildiği 1,45 katın altında olmalı", "TS HD 60364-4-43 (doğrulanacak)", "dogrulanacak"),
    ]
    test = [T("Termal kamera", "Yük altında, tavanın en dolu yerinde kablo yüzeyi", f"iletken ≈ {fnum(min(th, 999), 0)} °C iken yüzey 10–20 K daha soğuk", "en sıcak kablo demetin ortasındakidir"),
            T("Akım ölçüsü", "Her devrede pens ampermetre, en yüklü saatte", f"≤ {fnum(iz, 0)} A", "harmonikli yükte nötr de ısıtır")]
    g1 = {"baslik": "Yüke göre iletken sıcaklığı", "x_ad": "Akım (A)", "y_ad": "Sıcaklık (°C)",
          "seriler": [{"ad": "bu koşul", "renk": "#dc2626", "pts": pts([iz0 * 1.4 * k / 40 for k in range(41)], [min(ta + (th_max - ta) * (iz0 * 1.4 * k / 40 / iz) ** 2, 250) for k in range(41)], 1)},
                      {"ad": "30 °C, tek başına", "renk": "#94a3b8", "kesik": True, "pts": pts([iz0 * 1.4 * k / 40 for k in range(41)], [min(30 + (th_max - 30) * (1.4 * k / 40) ** 2, 250) for k in range(41)], 1)}],
          "yatay": [{"y": th_max, "etiket": f"sınır {fnum(th_max, 0)} °C", "renk": "#dc2626"}], "isaretler": [{"x": i, "etiket": "yük"}]}
    g2 = {"baslik": f"%{fnum(asiri * 100, 0)} aşırı yükte sıcaklığın yükselmesi", "x_ad": "Zaman (dk)", "y_ad": "Sıcaklık (°C)", "zaman": True,
          "seriler": [{"ad": "iletken", "renk": "#dc2626", "pts": pts(ts, [min(x, 300) for x in egri], 1)}], "yatay": [{"y": th_max, "etiket": "sınır", "renk": "#dc2626"}]}
    return {
        "ozet": ozet, "kontroller": kontroller, "girdiler": girdiler, "adimlar": adimlar, "ayarlar": ayarlar, "test": test, "sahne": c.sahne(), "grafikler": [g1, g2],
        "anlatim": [
            "İletkende üretilen ısı akımın karesiyle orantılıdır. Bu ısı yalıtkandan ve kılıftan geçip çevreye atılır; atılan ısı, kablonun yüzeyi ile ortam arasındaki sıcaklık farkıyla orantılıdır. İletken, üretilen ısı atılan ısıya eşit olana kadar ısınır.",
            f"Akım taşıma kapasitesi, bu denge sıcaklığının yalıtkanın sınırına ({fnum(th_max, 0)} °C) eşit olduğu akımdır. Çizelgedeki {fnum(iz0, 0)} A, 30 °C havada tek başına döşenmiş kablo içindir.",
            f"Ortam {fnum(ta, 0)} °C: kablonun kullanabileceği sıcaklık farkı {fnum(th_max - 30, 0)} K'den {fnum(th_max - ta, 0)} K'ye indi. Isınma akımın karesiyle gittiği için kapasite bu oranın kareköküyle düşer: × {fnum(k_ta, 2)}.",
            (f"Aynı yolda {n} devre var: her kablo komşularının ısısını da görür. Kapasite × {fnum(k_gr, 2)}." + (" Demet halinde ortadaki kablonun ısı atacak yüzeyi neredeyse kalmaz." if demet else "") if n > 1 else "Kablo tek başına: komşu ısısı yok."),
            f"Sonuç: bu koşulda kablo {fnum(iz, 0)} A taşır; {fnum(i, 0)} A'de iletken {fnum(min(th, 999), 0)} °C. " + ("Sınır aşılıyor: yalıtkan sertleşir, çatlar; ömrü her 8–10 K fazlalıkta yarıya iner." if th > th_max else "Sınırın altında."),
            f"Sıcaklık yükü gecikmeyle izler: bu kesitte ısıl zaman sabiti yaklaşık {fnum(tau, 0)} dakikadır. Kısa süreli aşırı yük (motor kalkışı, kısa çevrim) kabloyu ısıtmaya yetmez; sürekli aşırı yük ısıtır.",
        ],
        "dersler": [
            "Akım taşıma kapasitesi bir kablo özelliği değil, kablo + döşeme özelliğidir.",
            "Ortam çarpanı = √((θmax − θa)/(θmax − 30)); 50 °C'de PVC için 0,71.",
            "Dolu tavada kapasite %30–50 düşer: sonradan eklenen her kablo, eskileri de etkiler.",
            "Koruma cihazı düzeltilmiş kapasiteye göre seçilir.",
            "10 K fazla sıcaklık, yalıtkanın ömrünü yarıya indirir.",
        ],
        "tablolar": [{"baslik": "Düzeltme çarpanları", "cols": ["Ortam (°C)", "PVC", "XLPE", "", "Devre sayısı", "Tavada tek kat", "Demet"],
                      "rows": [[f"{t}", fnum(math.sqrt(max(70 - t, 0) / 40), 2), fnum(math.sqrt(max(90 - t, 0) / 60), 2), "", f"{g}", fnum(GRUP_TAVA[g], 2), fnum(GRUP[g], 2)] for t, g in zip((25, 30, 35, 40, 45, 50, 55, 60), (1, 2, 3, 4, 6, 9, 12, 20))],
                      "not": "Ortam çarpanları bağıntıdan hesaplanmıştır; gruplama çarpanları TS HD 60364-5-52 çizelgelerinden bellekle (doğrulanacak)."}],
    }
