"""Laboratuvarın kullandığı kural ve katalog verisi (her kural kaynağıyla birlikte taşınır).

agcalc'ın kural kümesinden laboratuvarın gerçekten okuduğu üç dosya buraya alınmıştır — içerikleri değiştirilmeden:
  rules/ictesisler.json  — Elektrik İç Tesisleri Yön. (laboratuvar yalnız «rcd» bölümünü okur)
  rules/topraklama.json  — Elektrik Tesislerinde Topraklamalar Yön. (adyabatik k katsayıları, periyodik ölçüm süreleri …)
  rules/breakers.json    — koruma cihazı kataloğu (laboratuvar yalnız NH gG kapı değerlerini okur: IEC 60269-1)
Topraklama laboratuvarının kendi sınır değerleri rules/lab_topraklama.json dosyasındadır (bkz. lab/core.py)."""
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

RULES_DIR = Path(__file__).resolve().parent / "rules"


def _load(ad: str) -> dict:
    return json.loads((RULES_DIR / ad).read_text(encoding="utf-8"))


@dataclass(frozen=True)
class RuleSet:
    ictesisler: dict
    topraklama: dict
    breakers: dict


@lru_cache(maxsize=1)
def load_rules() -> RuleSet:
    return RuleSet(ictesisler=_load("ictesisler.json"), topraklama=_load("topraklama.json"), breakers=_load("breakers.json"))


def fuse_ia(rs: RuleSet, in_a: float, t_s: float) -> float:
    """NH gG: verilen sürede açmayı sağlayan akım (IEC 60269-1 kapı değerleri; 0,1 s–5 s arası log-log ara değer)."""
    nh = rs.breakers["nh"]; k = str(int(in_a))
    i5 = nh["ia_5s_a"].get(k, 5.2 * in_a); i01 = nh["ia_01s_a"].get(k, 14.5 * in_a)
    if t_s >= 5:
        return float(i5)
    if t_s <= 0.1:
        return float(i01)
    a = (math.log(t_s) - math.log(5)) / (math.log(0.1) - math.log(5))
    return float(math.exp(math.log(i5) + a * (math.log(i01) - math.log(i5))))
