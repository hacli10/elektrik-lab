"""Laboratuvar konusu — dokunma ve adım gerilimi: topraklayıcı çevresindeki potansiyel hunisi (3 boyutlu).

Model: topraklayıcı küçük parçalara bölünür; her parça toprağa eşit yoğunlukta akım verir (homojen toprak, yarı sonsuz ortam).
Yüzeydeki P noktasının potansiyeli φ(P) = ρ·I/(2π) · Σ wᵢ / |P − Sᵢ| (nokta kaynak toplamı). Topraklama direnci RE yönetmeliğin
formülleriyle (Ek-T) hesaplanır, UE = RE·IE. Sonlu eleman çözümü değildir; biçimi ve mertebeyi doğru verir."""
from __future__ import annotations

import math

from .core import C, K, ctl, fnum, num, opt, ustp, utp, vucut_akimi, etki, zb_ohm

ID = "dokunma"
BASLIK = "Dokunma ve adım gerilimi"
IKON = "🦶"
GIRIS = ("Toprağa akım akan bir topraklayıcının çevresinde zemin potansiyeli huni biçiminde yükselir. Topraklayıcıyı, toprağı ve akımı seçin; "
         "kişiyi gezdirin: elinin değdiği gövde ile ayağının bastığı yer arasındaki fark dokunma gerilimi, iki ayağı arasındaki fark adım gerilimidir.")
ELEKTROT = {"kazik": "Tek kazık (derin topraklayıcı)", "serit": "Şerit (yüzeysel topraklayıcı)", "halka": "Halka (ring) topraklayıcı", "ag": "Gözlü (ağ) topraklayıcı",
            "kazik_halka": "Kazık + potansiyel düzenleyici halka (direk tipi trafo)"}

KONTROLLER = [
    ctl("elektrot", "Topraklayıcı", "sec", "kazik", secenek=opt(*ELEKTROT.items())),
    ctl("l_m", "Kazık / şerit boyu", "sayi", 3, min=1, max=60, adim=0.5, birim="m", goster={"elektrot": ["kazik", "serit", "kazik_halka"]}),
    ctl("d_m", "Halka çapı / ağ kenarı", "sayi", 10, min=2, max=60, adim=1, birim="m", goster={"elektrot": ["halka", "ag"]}),
    ctl("n_goz", "Ağın bir kenarındaki göz sayısı", "sayi", 4, min=1, max=8, adim=1, goster={"elektrot": ["ag"]}),
    ctl("rho", "Toprak özdirenci ρ", "sayi", 100, min=10, max=3000, adim=10, birim="Ω·m", yardim="bataklık 30 · killi/nemli toprak 100 · kum 200–500 · çakıl/kaya 1000–3000"),
    ctl("ie_a", "Toprağa akan akım IE", "sayi", 10, min=1, max=5000, adim=10, birim="A"),
    ctl("tf_s", "Arıza süresi tF", "sayi", 0.5, min=0.05, max=10, adim=0.05, birim="s"),
    ctl("x_m", "Kişinin konumu (merkezden uzaklık)", "sayi", 1, min=0.5, max=30, adim=0.5, birim="m"),
    ctl("yuzey", "Zemin yüzeyi", "sec", "yok", secenek=opt(("yok", "çıplak toprak"), ("cakil", "10 cm çakıl tabakası (ρs ≈ 3000 Ω·m)"), ("asfalt", "asfalt (ρs ≈ 10 000 Ω·m)"))),
    ctl("ayakkabi", "Ayakkabı direnci hesaba katılsın (1000 Ω)", "onay", False),
]
D_ILETKEN = 0.015     # şerit / halka iletkeninin eşdeğer çapı (30×3,5 mm şerit için kalınlığın yarısı ≈)
D_KAZIK = 0.02
H_GOMME = 0.6


def _parcalar(el: str, p: dict) -> tuple[list[tuple[float, float, float, float]], float, list[list[list[float]]], str, float]:
    """→ (parçalar [(x, y, z, ağırlık)], RE/ρ katsayısı, çizim için çoklu çizgiler, formül metni, alan yarı genişliği)"""
    L = num(p, "l_m", 3); D = num(p, "d_m", 10)
    pts: list[tuple[float, float, float, float]] = []
    lines: list[list[list[float]]] = []
    if el in ("kazik", "kazik_halka"):
        n = 24
        rod = [(0.0, 0.0, (k + 0.5) * L / n, 1.0 / n) for k in range(n)]
        k_rod = math.log(4 * L / D_KAZIK) / (2 * math.pi * L)
        lines.append([[0, 0, 0], [0, 0, L]])
        if el == "kazik":
            return rod, k_rod, lines, f"RE = ρ / (2π·l) · ln(4·l / d) ; l = {fnum(L, 1)} m, d = 20 mm", max(8.0, 2.5 * L)
        r = 1.0; hh = 0.5; m = 40
        dr = 2 * r
        k_ring = math.log(2 * math.pi * dr / D_ILETKEN) / (math.pi ** 2 * dr)
        g_rod, g_ring = 1 / k_rod, 1 / k_ring
        k_tot = 1.15 / (g_rod + g_ring)                 # karşılıklı etki payı (yaklaşık %15)
        w_rod, w_ring = g_rod / (g_rod + g_ring), g_ring / (g_rod + g_ring)
        pts = [(x, y, z, w * w_rod) for x, y, z, w in rod] + [(r * math.cos(2 * math.pi * k / m), r * math.sin(2 * math.pi * k / m), hh, w_ring / m) for k in range(m)]
        lines.append([[r * math.cos(2 * math.pi * k / 40), r * math.sin(2 * math.pi * k / 40), hh] for k in range(41)])
        return pts, k_tot, lines, f"kazık ∥ halka (Ø 2 m, 0,5 m derinde), karşılıklı etki için × 1,15", 8.0
    if el == "serit":
        n = max(24, int(L * 2))
        pts = [(0.0, -L / 2 + (k + 0.5) * L / n, H_GOMME, 1.0 / n) for k in range(n)]
        lines.append([[0, -L / 2, H_GOMME], [0, L / 2, H_GOMME]])
        return pts, math.log(L * L / (D_ILETKEN * H_GOMME)) / (2 * math.pi * L), lines, f"RE = ρ / (2π·l) · ln(l² / (d·H)) ; l = {fnum(L, 1)} m, H = 0,6 m", max(8.0, L / 2 + 6)
    if el == "halka":
        m = 60; r = D / 2
        pts = [(r * math.cos(2 * math.pi * k / m), r * math.sin(2 * math.pi * k / m), H_GOMME, 1.0 / m) for k in range(m)]
        lines.append([[r * math.cos(2 * math.pi * k / 60), r * math.sin(2 * math.pi * k / 60), H_GOMME] for k in range(61)])
        return pts, math.log(2 * math.pi * D / D_ILETKEN) / (math.pi ** 2 * D), lines, f"RE = ρ / (π²·D) · ln(2π·D / d) ; D = {fnum(D, 0)} m", r + 8.0
    # gözlü (ağ) topraklayıcı
    ng = max(1, int(num(p, "n_goz", 4))); a = D
    per = max(8, int(a * 1.2))
    for i in range(ng + 1):
        c = -a / 2 + i * a / ng
        for k in range(per):
            t = -a / 2 + (k + 0.5) * a / per
            pts.append((c, t, H_GOMME, 1.0)); pts.append((t, c, H_GOMME, 1.0))
        lines.append([[c, -a / 2, H_GOMME], [c, a / 2, H_GOMME]]); lines.append([[-a / 2, c, H_GOMME], [a / 2, c, H_GOMME]])
    w = 1.0 / len(pts)
    pts = [(x, y, z, w) for x, y, z, _ in pts]
    ltop = 2 * (ng + 1) * a
    deq = math.sqrt(4 * a * a / math.pi)
    return pts, 1 / (2 * deq) + 1 / ltop, lines, f"RE = ρ / (2·D) + ρ / L ; D = {fnum(deq, 1)} m (eş alanlı daire), L = {fnum(ltop, 0)} m iletken", a / 2 + 10.0


def _phi(pts, rho: float, i: float, x: float, y: float) -> float:
    s = 0.0
    for sx, sy, sz, w in pts:
        s += w / max(0.05, math.sqrt((x - sx) ** 2 + (y - sy) ** 2 + sz * sz))
    return rho * i / (2 * math.pi) * s


def run(p: dict) -> dict:
    el = p.get("elektrot") if p.get("elektrot") in ELEKTROT else "kazik"
    rho = num(p, "rho", 100); ie = num(p, "ie_a", 10); tf = num(p, "tf_s", 0.5); x = num(p, "x_m", 1)
    pts, k_re, lines, formul, half = _parcalar(el, p)
    re_ = rho * k_re
    ue = re_ * ie
    phi = lambda xx, yy=0.0: min(ue, _phi(pts, rho, ie, xx, yy))          # noqa: E731
    half = max(half, x + 3)
    rhos = {"yok": rho, "cakil": 3000.0, "asfalt": 10000.0}[p.get("yuzey") if p.get("yuzey") in ("yok", "cakil", "asfalt") else "yok"]
    ra = (1000.0 if p.get("ayakkabi") else 0.0) + 1.5 * rhos
    u_tp = utp(tf); u_stp = ustp(tf, ra)
    f_x = phi(x); u_st = max(0.0, ue - f_x); u_ss = abs(f_x - phi(x + 1.0))
    i_b, u_t = vucut_akimi(u_st, ra)
    d_k, e_k = etki(i_b, tf)
    # adım: ayaktan ayağa, her ayak 3·ρs (iki ayak seri: 6·ρs)
    i_s = u_ss / (zb_ohm(max(u_ss, 25), False) + 6 * rhos + (2000.0 if p.get("ayakkabi") else 0.0))
    c1 = ue <= 2 * u_tp + 1e-9
    ok_t = c1 or u_st <= u_stp + 1e-9
    an = [f"Topraklayıcıdan toprağa {fnum(ie, 0)} A akıyor. Yayılma direnci {formul} → RE = {fnum(re_, 2)} Ω. Topraklayıcı ve ona bağlı bütün gövdeler referans toprağa göre UE = RE · IE = {fnum(ue, 0)} V'a çıkar.",
          "Akım topraklayıcıdan uzaklaştıkça yayılır; zeminin potansiyeli topraklayıcının üstünde en yüksektir ve uzaklaştıkça düşer. Düşüşün büyük kısmı ilk birkaç metrede olur.",
          f"Kişi merkezden {fnum(x, 1)} m uzakta duruyor: bastığı yerin potansiyeli {fnum(f_x, 0)} V. Eliyle topraklayıcıya bağlı bir gövdeye dokunursa eli {fnum(ue, 0)} V'ta, ayakları {fnum(f_x, 0)} V'tadır: "
          f"beklenen dokunma gerilimi UST = {fnum(u_st, 0)} V.",
          f"Vücut empedansı ve ek dirençle (Ra = {fnum(ra, 0)} Ω) vücuttan {fnum(i_b * 1000, 0)} mA geçer ({fnum(tf, 2)} s): {e_k}.",
          f"Aynı kişi dokunmadan yürürse iki ayağı arasında (1 m) adım gerilimi {fnum(u_ss, 0)} V oluşur; akım ayaktan ayağa geçer (≈ {fnum(i_s * 1000, 0)} mA), kalpten geçmediği için dokunmaya göre daha az tehlikelidir."]
    if p.get("yuzey") != "yok":
        an.append(f"Yüzey tabakası zeminin potansiyelini değiştirmez; ayak ile zemin arasına büyük bir direnç koyar (Ra2 = 1,5 · ρs = {fnum(1.5 * rhos, 0)} Ω). İzin verilen kaynak gerilimi {fnum(u_tp, 0)} V'tan {fnum(u_stp, 0)} V'a çıkar.")
    if el == "kazik_halka":
        an.append("Kazığın çevresine gömülen halka zeminin potansiyelini gövdenin potansiyeline yaklaştırır: kişinin bastığı yer de yükselir, el–ayak farkı küçülür. Potansiyel düzenlemenin mantığı budur.")
    kt = [C("Topraklama gerilimi", f"UE = {fnum(ue, 0)} V", f"≤ 2 · UTp = {fnum(2 * u_tp, 0)} V  (tF = {fnum(tf, 2)} s → UTp = {fnum(u_tp, 0)} V)", True if c1 else None,
            "Topraklamalar Yön. m.5-d, Şekil-6/7, Ek-C (Çizelge-C.3); m.11 Çizelge-13"),
          C("Dokunma gerilimi (bu konumda)", f"UST = UE − φ(x) = {fnum(ue, 0)} − {fnum(f_x, 0)} = {fnum(u_st, 0)} V" + (" — UE ≤ 2·UTp olduğundan sağlanmış sayılır" if c1 else ""),
            f"≤ USTp = {fnum(u_stp, 0)} V  (ek direnç Ra = {fnum(ra, 0)} Ω)", ok_t, "Topraklamalar Yön. Ek-C.2 (Çizelge-C.4)"),
          C("Ek önlem kademesi", f"UE / UTp = {fnum(ue / u_tp, 1)}", "≤ 2: önlem gerekmez · ≤ 4: tanınan M önlemleri (potansiyel düzenleme, yalıtkan zemin) · > 4: UT ≤ UTp ölçüm ya da hesapla kanıtlanır", None,
            "Topraklamalar Yön. Ek-D (Çizelge-D.1)"),
          C("Adım gerilimi", f"USS = {fnum(u_ss, 0)} V (1 m)", "yönetmelik ayrı sınır tanımlamaz: dokunma koşulu sağlanıyorsa adım gerilimi tehlikesiz sayılır", None, "Topraklamalar Yön. m.5-d1")]
    ds = ["Tehlikeli olan topraklama geriliminin kendisi değil, kişinin iki noktası arasındaki farktır. Kuş telde durur, çünkü iki ayağı aynı potansiyeldedir.",
          "Dokunma gerilimini küçültmenin üç yolu: RE'yi küçültmek (UE düşer), potansiyel düzenlemek (zemini de yükseltmek: halka, ağ) ve zemini yalıtmak (çakıl, asfalt).",
          "Kazıktan uzaklaştıkça dokunma gerilimi artar, adım gerilimi azalır. En büyük dokunma gerilimi, topraklayıcıya bağlı ama ondan uzakta duran gövdede (çit, uzak pano, bahçe musluğu) oluşur.",
          "Özdirenç iki katına çıkarsa RE, UE ve bütün gerilimler iki katına çıkar: kayalık zeminde aynı topraklayıcı çok daha tehlikelidir.",
          "Arıza ne kadar hızlı temizlenirse izin verilen gerilim o kadar yüksektir: 0,2 s için 500 V, 1 s için ≈ 100 V, kalıcı arıza için 80 V."]
    # profil
    xs = [0.25 * k for k in range(1, int(half * 4) + 1)]
    prof = [[round(v, 2), round(phi(v), 1)] for v in xs]
    dok = [[round(v, 2), round(max(0.0, ue - phi(v)), 1)] for v in xs]
    graf = [{"baslik": "Zemin potansiyeli ve dokunma gerilimi (merkezden dışarı doğru)", "x_ad": "merkezden uzaklık (m)", "y_ad": "gerilim (V)",
             "seriler": [{"ad": "zemin potansiyeli φ(x)", "renk": "#b45309", "pts": prof}, {"ad": "dokunma gerilimi UE − φ(x)", "renk": "#dc2626", "pts": dok}],
             "yatay": [{"y": round(ue, 1), "etiket": f"UE = {fnum(ue, 0)} V", "renk": "#334155"}, {"y": round(u_stp, 1), "etiket": f"izin verilen USTp = {fnum(u_stp, 0)} V", "renk": "#15803d"}],
             "isaretler": [{"x": x, "etiket": f"kişi {fnum(x, 1)} m"}], "ymin": 0}]
    # 3B yüzey
    n = 41
    grid = []
    for j in range(n):
        yy = -half + 2 * half * j / (n - 1)
        for i in range(n):
            xx = -half + 2 * half * i / (n - 1)
            grid.append(round(phi(xx, yy) / ue, 3) if ue > 0 else 0.0)
    oz = [K("Yayılma direnci RE", f"{fnum(re_, 2)} Ω", "info", f"ρ = {fnum(rho, 0)} Ω·m"), K("Topraklama gerilimi UE", f"{fnum(ue, 0)} V", "ok" if c1 else "warn", f"2·UTp = {fnum(2 * u_tp, 0)} V"),
          K("Dokunma gerilimi", f"{fnum(u_st, 0)} V", "ok" if ok_t else "bad", f"izin verilen {fnum(u_stp, 0)} V"), K("Adım gerilimi", f"{fnum(u_ss, 0)} V", "info", "1 m adım"),
          K("Dokunan kişi", f"{fnum(i_b * 1000, 0)} mA", d_k, e_k)]
    tablo = {"baslik": "İzin verilen dokunma gerilimi UTp", "cols": ["Arıza süresi tF (s)", "0,04", "0,08", "0,14", "0,20", "0,29", "0,39", "0,49", "0,64", "0,72", "1,1", "≥ 10"],
             "rows": [["UTp (V)", "800", "700", "600", "500", "400", "300", "220", "150", "125", "100", "80"]],
             "not": "Topraklamalar Yön. Ek-C, Çizelge-C.3 (Şekil-6) — durum: resmi. Ek dirençlerle: USTp = UTp · (1 + Ra / ZB), Ra = Ra1 + 1,5·ρs."}
    sahne = {"tip": "dokunma", "n": n, "half": round(half, 2), "grid": grid, "ue": round(ue, 1), "cizgiler": lines, "kisi_x": x, "phi_x": round(f_x, 1), "ust": round(u_st, 1), "uss": round(u_ss, 1),
             "durum": "ok" if ok_t else "bad", "elektrot": ELEKTROT[el]}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "grafikler": graf, "tablolar": [tablo]}
