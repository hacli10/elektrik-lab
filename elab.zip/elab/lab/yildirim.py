"""Laboratuvar konusu — yıldırım ve parafudr (SPD): topraklama direncinin etkisi, parafudr bağlantı uzunluğu, ayırma mesafesi.

Modeller (mertebe): toprak potansiyel yükselmesi U = I · R ; parafudr bağlantı iletkenlerindeki ek gerilim U = L′ · di/dt · l
(L′ ≈ 1 µH/m; 8/20 µs dalgada di/dt ≈ I / 8 µs) ; ayırma mesafesi s = ki · (kc / km) · l.
Dayanak: TS EN 62305-1/-3/-4, TS HD 60364-5-534, TS HD 60364-4-443 — madde ve değerler doğrulanacak."""
from __future__ import annotations

from .cizim import Cizim
from .core import C, K, ctl, fnum, num, opt

ID = "yildirim"
BASLIK = "Yıldırım ve parafudr"
IKON = "🌩"
GIRIS = ("Yıldırım akımı toprağa akarken topraklama tesisini binlerce volta çıkarır; korunmak için her şeyin aynı potansiyele bağlanması gerekir. "
         "Parafudrun cihazı koruyup korumadığını ise çoğu zaman parafudrun kendisi değil, bağlantı iletkeninin uzunluğu belirler.")
LPL = {"I": (200, 20, 5, 10, 0.08), "II": (150, 30, 10, 10, 0.06), "III": (100, 45, 15, 15, 0.04), "IV": (100, 60, 20, 20, 0.04)}      # tepe akım kA, küre yarıçapı m, ağ gözü m, iniş aralığı m, ki
UW = {"I": 1.5, "II": 2.5, "III": 4.0, "IV": 6.0}
D = "dogrulanacak"

KONTROLLER = [
    ctl("lpl", "Yıldırımdan korunma seviyesi (LPL)", "sec", "III", secenek=opt(("I", "I — 200 kA"), ("II", "II — 150 kA"), ("III", "III — 100 kA"), ("IV", "IV — 100 kA"))),
    ctl("r_ohm", "Topraklama direnci", "sayi", 10, min=0.5, max=100, adim=0.5, birim="Ω"),
    ctl("esp", "Bina girişinde yıldırım eşpotansiyel dengelemesi yapılmış (bütün hatlar parafudrla / doğrudan baraya)", "onay", True),
    ctl("sinif", "Ana panodaki parafudr", "sec", "T1T2", secenek=opt(("yok", "yok"), ("T2", "Tip 2 (8/20 µs)"), ("T1T2", "Tip 1+2 (10/350 µs yıldırım akımı)"))),
    ctl("dis_lps", "Binada dış yıldırımlık (yakalama ucu + iniş iletkeni) var", "onay", True),
    ctl("up_kv", "Parafudrun koruma seviyesi Up", "sayi", 1.3, min=0.8, max=4, adim=0.1, birim="kV"),
    ctl("bag_m", "Parafudr bağlantı iletkenlerinin toplam uzunluğu (faz + toprak tarafı)", "sayi", 0.5, min=0.1, max=5, adim=0.1, birim="m"),
    ctl("in_ka", "Parafudrdan geçen darbe akımı (8/20 µs)", "sayi", 10, min=1, max=40, adim=1, birim="kA"),
    ctl("kategori", "Korunan cihazın darbe dayanımı", "sec", "II", secenek=opt(("I", "Kategori I — 1,5 kV (hassas elektronik)"), ("II", "Kategori II — 2,5 kV (ev aletleri, cihazlar)"), ("III", "Kategori III — 4 kV (pano, sabit tesisat)"), ("IV", "Kategori IV — 6 kV (sayaç, giriş)"))),
    ctl("mesafe", "Parafudr ile korunan cihaz arasındaki hat", "sayi", 8, min=0.5, max=100, adim=0.5, birim="m"),
    ctl("l_inis", "İniş iletkeninin, yaklaşma noktasından en yakın dengeleme noktasına uzunluğu", "sayi", 10, min=1, max=60, adim=1, birim="m", goster={"dis_lps": [True]}),
    ctl("kc", "Akımın iniş iletkenleri arasında paylaşımı kc", "sec", 0.66, secenek=opt((1, "1 — tek iniş"), (0.66, "0,66 — iki iniş"), (0.44, "0,44 — üç ve daha çok iniş")), goster={"dis_lps": [True]}),
    ctl("s_mevcut", "İniş iletkeni ile iç tesisat arasındaki mevcut açıklık", "sayi", 0.5, min=0.05, max=3, adim=0.05, birim="m", goster={"dis_lps": [True]}),
    ctl("km", "Aradaki malzeme", "sec", 1, secenek=opt((1, "hava"), (0.5, "beton / tuğla")), goster={"dis_lps": [True]}),
]


def run(p: dict) -> dict:
    lpl = p.get("lpl") if p.get("lpl") in LPL else "III"
    i_ka, r_kure, goz, inis, ki = LPL[lpl]
    r = num(p, "r_ohm", 10); esp = bool(p.get("esp", True)); sinif = p.get("sinif") if p.get("sinif") in ("yok", "T2", "T1T2") else "T1T2"
    lps = bool(p.get("dis_lps", True)); up = num(p, "up_kv", 1.3); bag = num(p, "bag_m", 0.5); i_n = num(p, "in_ka", 10)
    kat = p.get("kategori") if p.get("kategori") in UW else "II"; uw = UW[kat]; mes = num(p, "mesafe", 8)
    u_top = i_ka * r                                   # kV
    u_bag = 1.0 * (i_n / 8.0) * bag                    # kV: L′ = 1 µH/m, di/dt = I / 8 µs
    u_cihaz = up + u_bag if sinif != "yok" else None
    an = [f"LPL {lpl}: tasarımda esas alınan yıldırım akımı tepe değeri {i_ka} kA. Bu akım {fnum(r, 1)} Ω'luk topraklamadan akarken topraklama tesisi uzak toprağa göre I · R = {fnum(u_top, 0)} kV'a çıkar.",
          "Bu gerilimi hiçbir yalıtım tutamaz; çözüm yalıtmak değil eşitlemektir. Binadaki bütün metal sistemler ve bütün hatlar (enerji, veri, boru) girişte aynı baraya bağlanırsa hepsi birlikte yükselir, aralarında fark kalmaz. "
          "Enerjili iletkenler doğrudan bağlanamayacağı için parafudr üzerinden bağlanır."]
    kt = []
    kt.append(C("Yıldırım eşpotansiyel dengelemesi", "yapılmış" if esp else "yapılmamış", "binaya giren bütün iletken hatlar ve sistemler girişte dengelemeye bağlanır", esp, "TS EN 62305-3 m.6.2; TS EN 62305-4", D))
    if not esp:
        an.append(f"Dengeleme yok: topraklama {fnum(u_top, 0)} kV'a çıkarken dışarıdan gelen hat (şebeke nötrü, veri hattı) uzak toprağın potansiyelinde kalır. Aradaki fark cihazların içinden atlar: yanan modem, televizyon, pano.")
    kt.append(C("Topraklama direnci (yıldırımlık)", f"{fnum(r, 1)} Ω", "≤ 10 Ω önerilir (düşük frekansta ölçülen); belirleyici olan biçim ve dengelemedir", r <= 10 + 1e-9, "TS EN 62305-3 m.5.4", D))
    need_t1 = lps
    kt.append(C("Girişteki parafudrun sınıfı", {"yok": "parafudr yok", "T2": "Tip 2", "T1T2": "Tip 1+2"}[sinif], "dış yıldırımlık varsa girişte Tip 1 (yıldırım akımı parafudru)" if need_t1 else "en az Tip 2",
                (sinif == "T1T2") if need_t1 else (sinif != "yok"), "TS HD 60364-5-534 m.534.4; TS EN 62305-4", D))
    if sinif != "yok":
        an += [f"Parafudr {fnum(i_n, 0)} kA'lik darbeyi geçirirken uçlarında Up = {fnum(up, 1)} kV kalır. Ama cihaz parafudrun uçlarına değil, bağlantı iletkenlerinin öbür ucuna bağlıdır: {fnum(bag, 1)} m iletkende L · di/dt ≈ {fnum(u_bag, 2)} kV daha düşer.",
               f"Cihazın gördüğü gerilim ≈ Up + bağlantı = {fnum(u_cihaz, 2)} kV; cihazın dayanımı {fnum(uw, 1)} kV (kategori {kat}). Metre başına yaklaşık 1 kV: yarım metrelik bir fazlalık parafudru işe yaramaz kılabilir."]
        kt.append(C("Parafudr bağlantı uzunluğu", f"{fnum(bag, 1)} m", "≤ 0,5 m (toplam); sağlanamıyorsa V bağlantı", bag <= 0.5 + 1e-9, "TS HD 60364-5-534 m.534.4.8", D))
        kt.append(C("Etkin koruma seviyesi", f"Up + ΔU = {fnum(u_cihaz, 2)} kV", f"≤ 0,8 · Uw = {fnum(0.8 * uw, 2)} kV (kategori {kat})", u_cihaz <= 0.8 * uw + 1e-9, "TS HD 60364-5-534 m.534.4.4.2; TS HD 60364-4-443 (darbe dayanım kategorileri)", D))
        kt.append(C("Parafudr – cihaz uzaklığı", f"{fnum(mes, 1)} m", "≤ 10 m; daha uzunsa cihaza yakın ek parafudr (salınım ile gerilim ikiye katlanabilir)", mes <= 10 + 1e-9, "TS HD 60364-5-534 m.534.4.4.2", D))
    else:
        an.append("Girişte parafudr yok: şebekeden ya da yakına düşen yıldırımdan gelen darbe doğrudan tesisata girer; cihazların darbe dayanımı (1,5–6 kV) tek savunmadır.")
    s_gerek = None
    if lps:
        s_gerek = ki * num(p, "kc", 0.66) / num(p, "km", 1) * num(p, "l_inis", 10)
        an.append(f"İniş iletkeni akım taşırken boyunca gerilim düşer; yakınından geçen tesisata atlamaması için ayırma mesafesi gerekir: s = ki · (kc / km) · l = {fnum(ki, 2)} × ({fnum(num(p, 'kc', 0.66), 2)} / {fnum(num(p, 'km', 1), 1)}) × {fnum(num(p, 'l_inis', 10), 0)} = {fnum(s_gerek, 2)} m. "
                  "Sağlanamıyorsa o noktada dengeleme bağlantısı yapılır.")
        kt.append(C("Ayırma mesafesi", f"mevcut {fnum(num(p, 's_mevcut', 0.5), 2)} m", f"≥ s = {fnum(s_gerek, 2)} m", num(p, "s_mevcut", 0.5) >= s_gerek - 1e-9, "TS EN 62305-3 m.6.3", D))
    ds = ["Yıldırımda topraklama direnci tek başına koruma sağlamaz: 1 Ω'da bile 100 kV oluşur. Koruyan, bütün sistemlerin aynı baraya bağlanmasıdır.",
          "Parafudrun bağlantısı kısa ve düz olmalıdır. Kıvrılıp toplanmış fazla iletken, ilmek ve uzun topraklama yolu koruma seviyesini bozar; “V bağlantı” (hattın parafudr klemensinden girip çıkması) bağlantı boyunu sıfırlar.",
          "Kademeli koruma: girişte Tip 1 (enerjiyi boşaltır), tali panoda Tip 2 (gerilimi sınırlar), hassas cihazın yanında Tip 3. Her kademe bir öncekinin bıraktığını azaltır.",
          "Parafudr koruma iletkenine en kısa yoldan bağlanır; kaçak akım rölesinin kaynak tarafına konması gereksiz açmaları önler.",
          "İşletme, koruma ve yıldırım topraklaması aynı tesiste birleştirilir (tek topraklama tesisi); ayrı “temiz toprak” yıldırımda en büyük potansiyel farkını yaratır."]
    tablo = {"baslik": "Yıldırımdan korunma seviyeleri", "cols": ["LPL", "Tepe akım", "Yuvarlanan küre yarıçapı", "Ağ gözü", "İniş iletkeni aralığı", "ki"], "rows": [[k, f"{v[0]} kA", f"{v[1]} m", f"{v[2]} × {v[2]} m", f"{v[3]} m", fnum(v[4], 2)] for k, v in LPL.items()],
             "not": "TS EN 62305-1 Çizelge 3, TS EN 62305-3 Çizelge 2, 4, 10 — durum: dogrulanacak. Darbe dayanım kategorileri (230/400 V): I 1,5 kV · II 2,5 kV · III 4 kV · IV 6 kV (TS HD 60364-4-443)."}
    c = Cizim(900, 330, zemin=270)
    c.hat("M560,270 V110 L690,60 L820,110 V270", "#475569", w=2.2).yazi(690, 290, "bina", "#475569", 10.5, False, "middle")
    if lps:
        c.hat("M690,60 V30", "cizgi", w=3).hat("M690,60 L820,110 V270", "PE", hot=True, w=2.6).yazi(828, 190, "iniş iletkeni", "PE", 10.5)
        if s_gerek:
            c.yazi(828, 206, f"s ≥ {fnum(s_gerek, 2)} m", "ok" if num(p, "s_mevcut", 0.5) >= s_gerek else "ariza", 11, True)
    c.simsek(676, 4, 1.3).yazi(706, 22, f"{i_ka} kA", "ariza", 13, True)
    c.direnc(820, 270, f"R = {fnum(r, 1)} Ω", True).toprak(820, 304).yazi(650, 318, f"topraklama tesisi ≈ {fnum(u_top, 0)} kV'a çıkar", "ariza", 12, True, "middle")
    c.hat("M40,150 H600", "L1", w=2.4).yazi(40, 140, "şebekeden gelen hat (uzak toprağın potansiyelinde)", "#475569", 10.5)
    c.kutu(600, 130, 70, 40, "PANO", "", "normal")
    if sinif != "yok":
        c.kutu(610, 178, 50, 30, "SPD", f"Up {fnum(up, 1)} kV", "acti").hat(f"M635,208 V{min(262, 215 + bag * 14):.0f} H700 V270", "PE", hot=True).yazi(540, 250, f"bağlantı {fnum(bag, 1)} m → +{fnum(u_bag, 2)} kV", "ok" if bag <= 0.5 else "ariza", 11, True, "end")
    c.hat("M670,150 H730", "L1").kutu(730, 132, 70, 36, "cihaz", f"{fnum(uw, 1)} kV", "normal" if (u_cihaz is not None and u_cihaz <= 0.8 * uw) else "gecersiz")
    c.yazi(40, 318, "eşpotansiyel dengeleme yapılmış" if esp else "eşpotansiyel dengeleme YOK: hat ile tesis arasında atlama", "ok" if esp else "ariza", 11.5, True)
    oz = [K("Yıldırım akımı", f"{i_ka} kA", "info", f"LPL {lpl}"), K("Topraklama potansiyeli", f"{fnum(u_top, 0)} kV", "warn", f"R = {fnum(r, 1)} Ω"),
          K("Cihazın gördüğü darbe", f"{fnum(u_cihaz, 2)} kV" if u_cihaz is not None else "sınırlanmıyor", "ok" if (u_cihaz is not None and u_cihaz <= 0.8 * uw) else "bad", f"dayanım {fnum(uw, 1)} kV (0,8·Uw = {fnum(0.8 * uw, 2)})"),
          K("Bağlantıda düşen gerilim", f"{fnum(u_bag, 2)} kV", "ok" if bag <= 0.5 else "bad", f"{fnum(bag, 1)} m, ≈ 1 kV/m"), K("Ayırma mesafesi", f"{fnum(s_gerek, 2)} m" if s_gerek else "—", "info", "s = ki·kc/km·l")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "tablolar": [tablo]}
