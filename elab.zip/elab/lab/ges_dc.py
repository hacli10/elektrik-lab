"""Laboratuvar konusu — GES ve depolamada DC taraf: yalıtım arızası, yalıtım direnci (Riso), kapasitif kaçak akım, dizi sigortası.

Modeller (mertebe): PV dizisinin toprağa kapasitesi C ≈ c·P (kuru 50, ıslak 150 nF/kWp — tahmini). Trafosuz eviricide dizinin toprağa
göre gerilimi şebeke frekansında salınır (tek fazlı ≈ U0/2 @ 50 Hz; üç fazlı ≈ 15 V @ 150 Hz): I = 2π·f·C·U. En küçük yalıtım
direnci Riso ≥ Umax / 30 mA. Ters akım: (n − 1)·Isc; modülün ters akım dayanımını aşıyorsa dizi sigortası.
Dayanak: TS HD 60364-7-712; TS EN 62109-2; TS EN 62446-1; TS EN 62548 — doğrulanacak."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, ctl, fnum, num, opt

ID = "ges_dc"
BASLIK = "GES — DC taraf"
IKON = "☀"
GIRIS = ("PV dizisi topraktan yalıtılmış bir doğru akım kaynağıdır ve gün ışığı olduğu sürece kapatılamaz. İlk yalıtım arızası çoğu zaman sessizdir; ikincisi "
         "sigortanın kesemeyeceği bir ark yaratır. Eviricinin tipini, dizileri ve arıza durumunu değiştirin.")
D = "dogrulanacak"

KONTROLLER = [
    ctl("evirici", "Evirici", "sec", "trafosuz", secenek=opt(("trafosuz", "Trafosuz (dizi şebekeye galvanik bağlı)"), ("trafolu", "Trafolu (dizi şebekeden yalıtılmış)"))),
    ctl("faz", "Evirici çıkışı", "sec", 3, secenek=opt((1, "tek fazlı"), (3, "üç fazlı")), goster={"evirici": ["trafosuz"]}),
    ctl("kwp", "Eviriciye bağlı PV gücü", "sayi", 100, min=1, max=1000, adim=1, birim="kWp"),
    ctl("voc", "Dizinin en yüksek açık devre gerilimi", "sayi", 950, min=100, max=1500, adim=10, birim="V"),
    ctl("islak", "Modüller ıslak (yağmur, çiy)", "onay", False),
    ctl("riso_kohm", "Ölçülen yalıtım direnci Riso (dizi – toprak)", "sayi", 800, min=1, max=20000, adim=10, birim="kΩ"),
    ctl("ariza", "DC tarafta toprak arızası", "sec", "yok", secenek=opt(("yok", "yok"), ("bir", "bir arıza (bir kutup toprağa)"), ("iki", "iki arıza (artı ve eksi kutuplar farklı yerlerde toprağa)"))),
    ctl("n_dizi", "Paralel bağlı dizi sayısı (bir MPPT girişinde)", "sayi", 4, min=1, max=20, adim=1),
    ctl("isc", "Modül kısa devre akımı Isc", "sayi", 14, min=5, max=20, adim=0.5, birim="A"),
    ctl("i_ters", "Modülün ters akım dayanımı (en büyük seri sigorta)", "sec", 25, secenek=opt((15, "15 A"), (20, "20 A"), (25, "25 A"), (30, "30 A"))),
    ctl("sigorta", "Dizi sigortası var", "onay", True),
    ctl("rcd", "AC tarafta kaçak akım rölesi", "sec", "B300", secenek=opt(("yok", "yok"), ("A30", "30 mA tip A"), ("A300", "300 mA tip A"), ("B300", "300 mA tip B"))),
    ctl("s_esp", "Konstrüksiyon eşpotansiyel iletkeni", "sec", 6, secenek=opt((2.5, "2,5 mm² Cu"), (4, "4 mm² Cu"), (6, "6 mm² Cu"), (16, "16 mm² Cu"))),
]


def run(p: dict) -> dict:
    trafosuz = p.get("evirici") != "trafolu"; faz = int(num(p, "faz", 3))
    kwp = num(p, "kwp", 100); voc = num(p, "voc", 950); islak = bool(p.get("islak"))
    cc = (150 if islak else 50) * 1e-9 * kwp
    if trafosuz:
        i_kacak = 2 * math.pi * (50 if faz == 1 else 150) * cc * (115.0 if faz == 1 else 15.0)
    else:
        i_kacak = 0.0
    riso = num(p, "riso_kohm", 800) * 1000; riso_min = voc / 0.030
    ariza = p.get("ariza") if p.get("ariza") in ("yok", "bir", "iki") else "yok"
    n = int(num(p, "n_dizi", 4)); isc = num(p, "isc", 14); iters = num(p, "i_ters", 25)
    i_geri = (n - 1) * isc
    rcd = p.get("rcd") if p.get("rcd") in ("yok", "A30", "A300", "B300") else "B300"
    idn = {"yok": 0, "A30": 30, "A300": 300, "B300": 300}[rcd]
    an = [f"Dizi {fnum(voc, 0)} V'a kadar doğru gerilim üretir ve iki kutbu da topraktan yalıtılmıştır. Yalıtım direnci {fnum(riso / 1000, 0)} kΩ; evirici, şebekeye bağlanmadan önce bunu ölçer ve en az Umax / 30 mA = {fnum(riso_min / 1000, 0)} kΩ ister."]
    if trafosuz:
        an.append(f"Trafosuz eviricide dizi, evirici üzerinden şebekenin topraklı nötrüne bağlıdır: dizinin toprağa göre gerilimi şebeke frekansıyla salınır. Modüllerin cam ve çerçeveyle oluşturduğu kapasite ({fnum(cc * 1e6, 1)} µF, {'ıslak' if islak else 'kuru'}) üzerinden "
                  f"sürekli ≈ {fnum(i_kacak * 1000, 0)} mA kaçak akım akar. Arıza değildir; ama kaçak akım rölesi bunu görür.")
    else:
        an.append("Trafolu eviricide dizi şebekeden yalıtılmıştır: toprağa göre gerilimi salınmaz, kapasitif kaçak akım akmaz. Dizi gerçek bir IT sistemdir ve yalıtımı sürekli izlenir.")
    if ariza == "bir":
        an.append("Bir kutup toprağa değdi. " + ("Trafosuz eviricide arıza akımı, eviricinin içinden şebekenin topraklı nötrüne kapanır: evirici artık akım izleme düzeni (RCMU) sıçramayı algılar ve durur; yeniden başlarken Riso ölçümü geçmediği için devreye girmez." if trafosuz else
                  "Yalıtılmış dizide akımın dönecek yolu yok: hiçbir şey olmaz, yalıtım izleme alarm verir. Sistem çalışmayı sürdürebilir; ama ikinci arızaya karşı artık korumasızdır."))
    if ariza == "iki":
        an += [f"İki kutup farklı yerlerde toprağa değdi: konstrüksiyon üzerinden dizinin bir bölümü kısa devre oldu. Akım, dizilerin kısa devre akımı kadardır ({fnum(n * isc, 0)} A): çalışma akımından ancak %10 büyük. Sigorta bunu kısa devre olarak görmez.",
               "Arıza noktasında doğru akım arkı oluşur ve sıfırdan geçmediği için kendiliğinden sönmez. Çatı yangınlarının tipik başlangıcı budur. İlk arızanın algılanıp giderilmesi bu yüzden tek gerçek korumadır."]
    kt = [C("Yalıtım direnci (devreye girmeden önce)", f"Riso = {fnum(riso / 1000, 0)} kΩ", f"≥ Umax / 30 mA = {fnum(riso_min / 1000, 0)} kΩ ; devreye alma ölçümünde ≥ 1 MΩ", riso >= riso_min - 1e-9, "TS EN 62109-2 (evirici); TS EN 62446-1 (devreye alma: 1 MΩ)", D),
          C("DC toprak arızası", {"yok": "arıza yok", "bir": "bir arıza: algılandı, sistem durdu / alarm", "iki": "iki arıza: dizi kısa devresi, ark"}[ariza], "ilk arıza algılanır ve giderilir; ikinci arızaya izin verilmez", ariza != "iki" and not (ariza == "bir" and trafosuz and False),
            "TS HD 60364-7-712 (yalıtım izleme, RCMU); TS EN 62548", D)]
    if ariza == "bir":
        kt[-1]["ok"] = None
    gerek_sig = i_geri > iters
    an.append(f"Ters akım: bir dizide arıza olursa diğer {n - 1} dizi onu besler: (n − 1) · Isc = {fnum(i_geri, 0)} A. Modülün ters akım dayanımı {fnum(iters, 0)} A. " + ("Aşıyor: her diziye sigorta gerekir." if gerek_sig else "Aşmıyor: dizi sigortası zorunlu değil (iki diziye kadar hiçbir zaman gerekmez)."))
    kt.append(C("Dizi sigortası", ("var" if p.get("sigorta", True) else "yok") + f" ; ters akım {fnum(i_geri, 0)} A", f"(n − 1)·Isc > {fnum(iters, 0)} A ise gerekli", (bool(p.get("sigorta", True)) or not gerek_sig), "TS EN 62548; TS HD 60364-7-712 m.712.431", D))
    if rcd != "yok":
        tip_ok = (not trafosuz) or rcd.startswith("B")
        kt.append(C("AC taraftaki kaçak akım rölesinin tipi", rcd.replace("A", "tip A, ").replace("B", "tip B, ") + " mA", "trafosuz eviricide tip B (üretici tip A'nın yeterli olduğunu beyan etmedikçe)", tip_ok, "TS HD 60364-7-712 m.712.531.3", D))
        kt.append(C("Kapasitif kaçak akım – röle eşiği", f"≈ {fnum(i_kacak * 1000, 0)} mA sürekli", f"≤ 0,3 · IΔn = {fnum(0.3 * idn, 0)} mA", i_kacak * 1000 <= 0.3 * idn + 1e-9, "TS HD 60364-5-53 m.531.3.2; evirici üreticisi", D))
        if i_kacak * 1000 > 0.3 * idn:
            an.append("Kapasitif kaçak akım rölenin eşiğine yakın: yağmurda, sabah çiyinde sebepsiz açmalar beklenir. Büyük sistemlerde AC tarafta 30 mA kullanılmaz; eviricinin kendi artık akım izlemesi (RCMU) can güvenliği işlevini görür, röle yangın koruması içindir.")
    s_esp = num(p, "s_esp", 6)
    kt.append(C("Konstrüksiyon eşpotansiyel iletkeni", f"{fnum(s_esp, 1)} mm² Cu", "≥ 6 mm² Cu (yıldırımlık varsa ≥ 16 mm² Cu); bütün raylar ve çerçeveler kesintisiz bağlı", s_esp >= 6 - 1e-9, "TS HD 60364-7-712 m.712.544; TS EN 62305-3 (yıldırım akımı taşıyan bağlantılar)", D))
    ds = ["DC taraf gün ışığında her zaman gerilimlidir: evirici kapatılsa, AC kesilse bile modüllerden kabloya kadar olan bölüm enerjilidir. Çalışma bu varsayımla yapılır.",
          "DC kablolar çift yalıtımlıdır ve artı–eksi iletkenler yan yana, küçük çevrimle döşenir: hem ilk arızanın olasılığını hem yıldırımın endüklediği gerilimi azaltır.",
          "Trafosuz eviriciyle ince film ya da geniş alanlı çatı sistemlerinde kapasitif kaçak akım yüksektir; kaçak akım rölesi seçimi eviricinin üretici verisine göre yapılır.",
          "Konstrüksiyonun topraklanması modüllerin çalışması için değil, yalıtım arızasında çerçevelerin gerilim altında kalmaması ve yıldırım için gereklidir.",
          "Akü sistemlerinde (BESS) aynı mantık geçerlidir, ama kaynak çok daha güçlüdür: akü kısa devre akımı kiloamperlerdir ve DC sigorta / kesici seçimi ark kesme yeteneğine göre yapılır."]
    c = Cizim(900, 300, zemin=258)
    for k in range(min(n, 4)):
        c.dikdortgen(50 + k * 62, 60, 50, 90, "mavi", "#dbeafe", 1.6).yazi(75 + k * 62, 110, "PV", "mavi", 11, True, "middle")
    c.hat("M50,60 H300 V100 H470", "ariza", hot=ariza != "iki", w=2.6, hot_renk="ok" if ariza == "yok" else None).hat("M50,150 H300 V140 H470", "L2", hot=ariza != "iki", w=2.6, hot_renk="ok" if ariza == "yok" else None).yazi(310, 92, "+", "ariza", 14, True).yazi(310, 158, "−", "#111827", 14, True)
    c.kutu(470, 80, 130, 80, "EVİRİCİ", "trafosuz" if trafosuz else "trafolu", "gecersiz" if (ariza == "bir" and trafosuz) or riso < riso_min else "acti")
    c.hat("M600,120 H700", "L1", hot=ariza == "yok" or not trafosuz, hot_renk="ok" if ariza == "yok" else None).kutu(700, 100, 80, 40, "RCD", rcd if rcd != "yok" else "yok", "normal").hat("M780,120 H860", "L1")
    c.hat("M150,150 V258", "PE", kesik=True).toprak(150, 258).yazi(158, 246, f"konstrüksiyon {fnum(s_esp, 1)} mm²", "PE", 10.5)
    if trafosuz:
        c.kap(380, 140, 258, "uyari", False, f"{fnum(cc * 1e6, 1)} µF · {fnum(i_kacak * 1000, 0)} mA")
    if ariza in ("bir", "iki"):
        c.simsek(96, 150, 0.9).hat("M100,170 V258", "ariza", hot=True).yazi(60, 200, "arıza 1", "ariza", 10.5, True)
    if ariza == "iki":
        c.simsek(260, 56, 0.9).hat("M270,74 V258", "ariza", hot=True).yazi(280, 200, "arıza 2", "ariza", 10.5, True).hat("M100,272 H270", "toprak", hot=True)
    c.yazi(450, 290, {"yok": "arıza yok", "bir": "ilk arıza: " + ("evirici durur" if trafosuz else "alarm, sistem çalışır"), "iki": "ikinci arıza: konstrüksiyon üzerinden kısa devre ve sönmeyen ark"}[ariza], "ok" if ariza == "yok" else "ariza", 12, True, "middle")
    oz = [K("Yalıtım direnci", f"{fnum(riso / 1000, 0)} kΩ", "ok" if riso >= riso_min else "bad", f"en az {fnum(riso_min / 1000, 0)} kΩ"), K("Kapasitif kaçak akım", f"{fnum(i_kacak * 1000, 0)} mA", "ok" if (idn == 0 or i_kacak * 1000 <= 0.3 * idn) else "bad", f"{fnum(cc * 1e6, 1)} µF"),
          K("Ters akım", f"{fnum(i_geri, 0)} A", "ok" if (not gerek_sig or p.get("sigorta", True)) else "bad", f"modül dayanımı {fnum(iters, 0)} A"), K("DC arıza", {"yok": "yok", "bir": "bir (algılandı)", "iki": "iki (ark)"}[ariza], "ok" if ariza == "yok" else "warn" if ariza == "bir" else "bad", ""),
          K("Dizi gerilimi", f"{fnum(voc, 0)} V d.a.", "info", "gün ışığında kapatılamaz")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne()}
