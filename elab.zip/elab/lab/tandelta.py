"""Laboratuvar konusu — kayıp faktörü (tan δ) ve kapasite ölçümü: UST, GST, GSTg ölçme modları (Omicron CPC 100 + CP TD, Doble vb.).

İki sargılı trafonun yalıtımı üç kapasiteyle gösterilir: CH (OG sargısı – tank/çekirdek), CL (AG sargısı – tank), CHL (OG – AG arası).
Ölçme cihazının üç ucu vardır: yüksek gerilim ucu, ölçme (alçak gerilim) ucu ve toprak. Mod, hangi akımın ölçüleceğini seçer:
  UST  (topraksız nesne): yalnız ölçme ucundan dönen akım ölçülür; toprağa akan akım ölçüme girmez.
  GST  (topraklı nesne): toprağa ve ölçme ucuna dönen bütün akım ölçülür.
  GSTg (korumalı): ölçme ucu korumaya (guard) alınır; yalnız toprağa akan akım ölçülür.
Ölçülen büyüklükler: kapasite, tan δ = Σ(Cᵢ·tanδᵢ)/ΣCᵢ, akım I = ω·C·U, kayıp P = U·I·tanδ."""
from __future__ import annotations

from .cizim import Cizim
from .core import C, K, OMEGA, ctl, fnum, num, opt

ID = "tandelta"
BASLIK = "Tan δ ve kapasite (UST / GST)"
IKON = "📉"
GIRIS = ("Tan δ ölçümü yalıtımın kayıplarını, yani nemini ve yaşlanmasını gösterir. Trafoda üç ayrı yalıtım bölgesi vardır ve cihazın UST / GST / GSTg modları "
         "bunları tek tek ayırmaya yarar. Modu ve enerjilenen sargıyı seçin; cihazın hangi kapasiteyi ölçtüğünü ve neden üç ölçümün birlikte gerektiğini görün.")
MOD = {"GST": "GST — topraklı nesne (hepsi)", "GSTg": "GSTg — ölçme ucu korumada (yalnız toprağa)", "UST": "UST — topraksız nesne (yalnız ölçme ucuna)"}

KONTROLLER = [
    ctl("enerji", "Yüksek gerilim ucunun bağlandığı sargı", "sec", "og", secenek=opt(("og", "OG sargısı (uçları köprülü)"), ("ag", "AG sargısı (uçları köprülü)"))),
    ctl("mod", "Ölçme modu", "sec", "GST", secenek=opt(*MOD.items())),
    ctl("u_kv", "Deney gerilimi", "sayi", 10, min=0.1, max=12, adim=0.1, birim="kV", yardim="Sargının anma faz–toprak gerilimini geçmez; AG sargısında en çok birkaç yüz volt"),
    ctl("tip", "Trafo", "sec", "yagli", secenek=opt(("yagli", "Yağlı (hermetik)"), ("kuru", "Kuru tip (dökme reçineli)"))),
    ctl("ch_pf", "CH: OG sargısı – tank", "sayi", 2500, min=100, max=20000, adim=50, birim="pF"),
    ctl("cl_pf", "CL: AG sargısı – tank", "sayi", 6000, min=100, max=40000, adim=50, birim="pF"),
    ctl("chl_pf", "CHL: OG – AG sargıları arası", "sayi", 4500, min=100, max=40000, adim=50, birim="pF"),
    ctl("td_h", "CH yalıtımının tan δ değeri", "sayi", 0.30, min=0.05, max=10, adim=0.05, birim="%"),
    ctl("td_l", "CL yalıtımının tan δ değeri", "sayi", 0.30, min=0.05, max=10, adim=0.05, birim="%"),
    ctl("td_hl", "CHL yalıtımının tan δ değeri", "sayi", 0.30, min=0.05, max=10, adim=0.05, birim="%"),
    ctl("durum", "Değerlendirme ölçütü", "sec", "yeni", secenek=opt(("yeni", "Yeni trafo"), ("isletme", "İşletmedeki trafo"))),
]
LIM = {("yagli", "yeni"): 0.5, ("yagli", "isletme"): 1.0, ("kuru", "yeni"): 2.0, ("kuru", "isletme"): 4.0}


def olcum(enerji: str, mod: str, ch: float, cl: float, chl: float, th: float, tl: float, thl: float) -> tuple[list[str], float, float]:
    """→ (ölçülen kapasitelerin adları, toplam kapasite pF, tan δ %)"""
    toprak = ("CH", ch, th) if enerji == "og" else ("CL", cl, tl)
    ara = ("CHL", chl, thl)
    sec = {"GST": [toprak, ara], "GSTg": [toprak], "UST": [ara]}[mod]
    ct = sum(x[1] for x in sec)
    return [x[0] for x in sec], ct, sum(x[1] * x[2] for x in sec) / ct


def run(p: dict) -> dict:
    enerji = "ag" if p.get("enerji") == "ag" else "og"
    mod = p.get("mod") if p.get("mod") in MOD else "GST"
    tip = "kuru" if p.get("tip") == "kuru" else "yagli"
    u = num(p, "u_kv", 10) * 1000
    ch, cl, chl = num(p, "ch_pf", 2500), num(p, "cl_pf", 6000), num(p, "chl_pf", 4500)
    th, tl, thl = num(p, "td_h", 0.3), num(p, "td_l", 0.3), num(p, "td_hl", 0.3)
    adlar, ct, td = olcum(enerji, mod, ch, cl, chl, th, tl, thl)
    i_ma = OMEGA * ct * 1e-12 * u * 1000
    kayip = u * i_ma / 1000 * td / 100
    lim = LIM[(tip, p.get("durum") if p.get("durum") in ("yeni", "isletme") else "yeni")]
    sargi = "OG" if enerji == "og" else "AG"; diger = "AG" if enerji == "og" else "OG"
    an = [f"Yüksek gerilim ucu {sargi} sargısına bağlı (üç faz ucu köprülenmiş); ölçme ucu {diger} sargısında; tank topraklı. {fnum(u / 1000, 1)} kV uygulanınca akım iki yoldan döner: doğrudan tanka ({'CH' if enerji == 'og' else 'CL'}) ve {diger} sargısı üzerinden ölçme ucuna (CHL).",
          {"GST": f"GST modunda cihaz iki akımı birlikte ölçer: {' + '.join(adlar)} = {fnum(ct, 0)} pF. Hızlı bir genel bakıştır; ama iki bölgeden hangisinin bozuk olduğunu söylemez.",
           "GSTg": f"GSTg modunda ölçme ucu korumaya (guard) alınır: {diger} sargısından dönen akım ölçü devresinin dışından dolaşır. Cihaz yalnız tanka akan akımı ölçer: {adlar[0]} = {fnum(ct, 0)} pF.",
           "UST": f"UST modunda cihaz yalnız ölçme ucundan dönen akımı ölçer; tanka akan akım ölçüme girmez. Ölçülen, iki sargı arasındaki yalıtımdır: CHL = {fnum(ct, 0)} pF."}[mod],
          f"Ölçülen: C = {fnum(ct, 0)} pF, tan δ = %{fnum(td, 2)}, akım {fnum(i_ma, 2)} mA, kayıp {fnum(kayip, 3)} W ({fnum(u / 1000, 1)} kV'ta).",
          "Tam ölçüm altı adımdır: OG enerjili GST, GSTg, UST; sonra AG enerjili GST, GSTg, UST. Sağlaması: GST = GSTg + UST (kapasiteler toplanır) ve CHL iki yönden aynı çıkar. Tutmuyorsa bağlantı, topraklama ya da parazit sorunu vardır."]
    kt = [C("Ölçülen bölgenin tan δ değeri", f"%{fnum(td, 2)} ({' + '.join(adlar)})", f"≤ %{fnum(lim, 1)} ({'yağlı' if tip == 'yagli' else 'kuru tip'}, {'yeni' if lim in (0.5, 2.0) else 'işletmede'}; 20 °C)", td <= lim + 1e-9,
            "IEEE C57.152 / üretici değerleri (yorum ölçütü). TEDAŞ-MLZ/99-032.E: ≥ 630 kVA trafolarda sargılar arası ve sargı–tank tan δ ölçülür, 20 °C'ye indirgenir (sınır verilmez)", "ikincil"),
          C("Deney gerilimi", f"{fnum(u / 1000, 1)} kV ({sargi} sargısına)", "sargının anma gerilimini aşmaz" + ("; AG sargısında ≤ 0,5 kV" if enerji == "ag" else "; genellikle 10 kV"), (u <= 500) if enerji == "ag" else (u <= 12000), "Ölçü cihazı üreticisi uygulama kuralları", "ikincil")]
    bozuk = [n for n, v in (("CH", th), ("CL", tl), ("CHL", thl)) if v > lim]
    if bozuk:
        gorulur = [b for b in bozuk if b in adlar]
        an.append(f"Yalıtımda bozuk bölge: {', '.join(bozuk)} (tan δ sınırın üstünde). Bu ölçümde " + (f"{', '.join(gorulur)} ölçülen değerin içinde; " + ("ama başka bir bölgeyle karışık olduğu için ortalama düşük görünüyor." if len(adlar) > 1 and td <= lim else "değer bunu gösteriyor.") if gorulur else
                  "bu bölge ölçülmüyor: mod ya da enerjilenen sargı değiştirilmeden görülemez."))
    ds = ["UST'nin değeri: yalnız iki elektrot arasındaki yalıtımı ölçer. Buşing yüzeyindeki kir, nemli hava, ölçü kablosunun kaçağı toprağa aktığı için sonuca girmez. Sargılar arası yalıtım ve buşing ana kapasitesi (C1) bu modla ölçülür.",
          "GST tek başına yanıltır: iyi bir bölgeyle kötü bir bölgenin ortalamasını verir. Bölgeleri ayırmak için GSTg ve UST gerekir.",
          "Tan δ nemin ve yaşlanmanın göstergesidir; kapasite ise geometrinin. Kapasitede %5–10'luk değişim sargının yer değiştirdiğini (kısa devre sonrası deformasyon) düşündürür.",
          "Sonuçlar sıcaklığa çok bağlıdır ve 20 °C'ye indirgenir; ölçüm farklı gerilimlerde tekrarlanır (2–10 kV): tan δ gerilimle artıyorsa (tip-up) kısmi boşalma ya da kirlenme vardır.",
          "Bütün sargı uçları köprülenir (sargı endüktansı ölçüme girmesin), tank sağlam topraklanır, buşingler temizlenir ve kuru havada ölçülür."]
    c = Cizim(900, 320, zemin=285)
    xh, xl, yt = 250, 650, 285
    c.dikdortgen(150, 40, 600, 180, "#334155", "rgba(148,163,184,.08)", 2.2).yazi(450, 32, "TRAFO (tank topraklı)", "#334155", 11.5, True, "middle")
    c.kutu(xh - 60, 70, 120, 44, "OG sargısı", "uçlar köprülü", "gecersiz" if enerji == "og" else "vurgu").kutu(xl - 60, 70, 120, 44, "AG sargısı", "uçlar köprülü", "gecersiz" if enerji == "ag" else "vurgu")
    for ad, x1, yy, hot_ in (("CHL", (xh + 60, xl - 60), 92, "CHL" in adlar),):
        c.kap(yy, x1[0], x1[1], "ariza" if hot_ else "soluk", True, f"CHL {fnum(chl, 0)} pF" + (" ◀ ölçülüyor" if hot_ else ""))
    c.kap(xh, 114, 220, "ariza" if "CH" in adlar else "soluk", False, f"CH {fnum(ch, 0)} pF" + (" ◀" if "CH" in adlar else "")).kap(xl, 114, 220, "ariza" if "CL" in adlar else "soluk", False, f"CL {fnum(cl, 0)} pF" + (" ◀" if "CL" in adlar else ""))
    c.hat("M150,220 H750", "PE", w=2.4).hat("M450,220 V285", "PE", kesik=True).toprak(450, 285)
    xe, xo = (xh, xl) if enerji == "og" else (xl, xh)
    c.cihaz(385, 232, f"{fnum(ct, 0)} pF · %{fnum(td, 2)}", f"ölçü cihazı — {mod}", td <= lim, 170)
    c.hat(f"M{'385' if enerji == 'og' else '555'},258 H{xe - (90 if enerji == 'og' else -90)} V60 H{xe} V70", "ariza", hot=True).yazi(xe, 54, "yüksek gerilim ucu", "ariza", 10.5, True, "middle")
    c.hat(f"M{'555' if enerji == 'og' else '385'},270 H{xo + (90 if enerji == 'og' else -90)} V60 H{xo} V70", "mavi", kesik=(mod == "GSTg")).yazi(xo, 54, "ölçme ucu" + (" (korumada)" if mod == "GSTg" else ""), "mavi", 10.5, True, "middle")
    c.yazi(450, 312, f"{mod}: " + {"GST": "toprağa ve ölçme ucuna dönen akımın tamamı", "GSTg": "yalnız toprağa (tanka) dönen akım", "UST": "yalnız ölçme ucuna dönen akım"}[mod], "#334155", 11.5, True, "middle")
    tablo = {"baslik": "İki sargılı trafoda ölçüm sırası", "cols": ["Adım", "Yüksek gerilim ucu", "Ölçme ucu", "Mod", "Ölçülen", "Bu ayarlarla"], "rows": [
        [str(j + 1), "OG sargısı" if e == "og" else "AG sargısı", "AG sargısı" if e == "og" else "OG sargısı", m, " + ".join(olcum(e, m, ch, cl, chl, th, tl, thl)[0]),
         f"{fnum(olcum(e, m, ch, cl, chl, th, tl, thl)[1], 0)} pF · %{fnum(olcum(e, m, ch, cl, chl, th, tl, thl)[2], 2)}"] for j, (e, m) in enumerate((("og", "GST"), ("og", "GSTg"), ("og", "UST"), ("ag", "GST"), ("ag", "GSTg"), ("ag", "UST")))],
        "not": "Sağlama: 1. adım = 2. + 3. adım; 4. adım = 5. + 6. adım; 3. ve 6. adımlar (CHL) eşit çıkar. Buşinglerde: C1 (ana yalıtım) ölçme ucu test tapına bağlanarak UST ile, C2 (tap yalıtımı) GSTg ile ölçülür."}
    mods = {"baslik": "Ölçme modları", "cols": ["Mod", "Ölçülen akım", "Ne zaman"], "rows": [
        ["UST (Ungrounded Specimen Test)", "Yalnız ölçme ucundan dönen akım; toprağa akan akım ölçülmez", "İki elektrodu da topraktan ayrılabilen yalıtım: sargılar arası (CHL), buşing C1, kesicide açık kontaklar arası"],
        ["GST (Grounded Specimen Test)", "Toprağa ve ölçme ucuna dönen akımın tamamı", "Bir ucu topraklı nesne: sargı–tank toplamı, kablo, bara; ilk genel ölçüm"],
        ["GSTg (GST with guard)", "Yalnız toprağa dönen akım; ölçme ucuna gelen akım korumadan dolaşır", "Sargı–tank yalıtımını (CH, CL) sargılar arası yalıtımdan ayırmak; buşing C2"]],
        "not": "Ölçü cihazı üreticilerinin (Omicron CPC 100 + CP TD1, Doble M4000 vb.) uygulama kılavuzları; IEEE C57.152 — durum: ikincil"}
    oz = [K("Ölçülen kapasite", f"{fnum(ct, 0)} pF", "info", " + ".join(adlar)), K("Tan δ", f"%{fnum(td, 2)}", "ok" if td <= lim else "bad", f"sınır %{fnum(lim, 1)}"), K("Akım", f"{fnum(i_ma, 2)} mA", "info", f"{fnum(u / 1000, 1)} kV'ta"),
          K("Kayıp", f"{fnum(kayip * 1000, 1)} mW", "info", "U · I · tan δ"), K("Mod", mod, "info", sargi + " enerjili")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "tablolar": [tablo, mods]}
