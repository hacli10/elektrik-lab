"""Laboratuvar ders notu: bir konunun sonucu (ayarlar, şema, anlatım, kontroller, tablolar) → yazdırılabilir HTML → PDF."""
from __future__ import annotations

import html
import shutil
import tempfile
from pathlib import Path

CSS = """
@page { size: A4; margin: 14mm 13mm; } body { font: 10pt/1.45 "Segoe UI", Arial, sans-serif; color: #1f2937; }
h1 { font-size: 17pt; margin: 0 0 2mm; color: #1a4d8f; } h2 { font-size: 12pt; margin: 6mm 0 2mm; border-bottom: 1px solid #cbd5e1; padding-bottom: 1mm; color: #1a4d8f; }
.alt { color: #64748b; font-size: 9pt; margin-bottom: 4mm; } .v { padding: 2mm 3mm; border-radius: 2mm; font-weight: 700; margin: 3mm 0; } .ok { background: #e6f4ea; color: #0a7a2a; } .bad { background: #fdecee; color: #b00020; }
table { border-collapse: collapse; width: 100%; margin: 2mm 0; font-size: 8.6pt; } th, td { border: 1px solid #cbd5e1; padding: 1.2mm 1.8mm; text-align: left; vertical-align: top; } th { background: #eef2f7; }
.kp { display: flex; flex-wrap: wrap; gap: 2mm; } .kp div { border: 1px solid #cbd5e1; border-radius: 2mm; padding: 1.5mm 2.5mm; min-width: 30mm; } .kp b { display: block; font-size: 12pt; } .kp span { font-size: 8pt; color: #64748b; }
.fig { margin: 3mm 0; page-break-inside: avoid; } .fig svg, .fig img { width: 100%; height: auto; } ol, ul { margin: 1mm 0; padding-left: 6mm; } li { margin-bottom: 1.2mm; }
.not { font-size: 8pt; color: #64748b; margin-top: 6mm; border-top: 1px solid #e2e8f0; padding-top: 2mm; }
"""


def _e(x) -> str:
    return html.escape(str(x))


def _tablo(cols, rows) -> str:
    return "<table><tr>" + "".join(f"<th>{_e(c)}</th>" for c in cols) + "</tr>" + "".join("<tr>" + "".join(f"<td>{_e(c)}</td>" for c in row) + "</tr>" for row in rows) + "</table>"


def _deger(c: dict, v) -> str:
    for o in c.get("secenek", []):
        if str(o["id"]) == str(v):
            return o["ad"]
    if v is True:
        return "evet"
    if v is False:
        return "hayır"
    return f"{str(v).replace('.', ',')} {c.get('birim', '')}".strip()


def ders_notu_html(r: dict, cizimler: list) -> str:
    from .. import __version__
    rolemi = r.get("bolum") == "role"
    if rolemi:
        from ..role import spec
    else:
        from . import spec
    sp = next(s for s in spec() if s["id"] == r["konu"])
    p = r["params"]
    ayar = [(c["label"], _deger(c, p.get(c["key"]))) for c in sp["kontroller"]
            if not c.get("goster") or all(any(str(v) == str(p.get(k)) for v in vals) for k, vals in c["goster"].items())]
    nbad = sum(1 for k in r["kontroller"] if k["ok"] is False)
    cizim = "".join(f'<div class="fig">{c}</div>' for c in cizimler[:8] if isinstance(c, str) and c.lstrip()[:4] in ("<svg", "<img"))
    kp = "".join(f"<div>{_e(o['ad'])}<b>{_e(o['deger'])}</b><span>{_e(o['alt'])}</span></div>" for o in r["ozet"])
    kont = ("<h2>Kontroller</h2>" + _tablo(["Kontrol", "Hesap", "Sınır", "Sonuç", "Dayanak", "Durum"],
                                          [[k["ad"], k["hesap"], k["sinir"], "✓" if k["ok"] else "✗" if k["ok"] is False else "bilgi", k["kaynak"], k["durum"]] for k in r["kontroller"]])) if r["kontroller"] else ""
    tabs = "".join("<h2>" + _e(t["baslik"]) + "</h2>" + _tablo(t["cols"], t["rows"]) + (f"<div class='alt'>{_e(t['not'])}</div>" if t.get("not") else "") for t in r["tablolar"])
    ek = ""
    if r.get("girdiler"):
        ek += "<h2>Röleye giderken elinizde olması gerekenler</h2>" + _tablo(["Veri", "Değer", "Nereden alınır", "Neden gerekir", "Nasıl kullanılır"], [[g["ad"], g["deger"], g["nereden"], g["neden"], g["nasil"]] for g in r["girdiler"]])
    if r.get("adimlar"):
        ek += "<h2>Hesap adımları: veriden ayara</h2>" + _tablo(["Adım", "Bağıntı", "Hesap", "Sonuç", "Röle alanı", "Dayanak", "Durum"], [[a["ad"], a["formul"], a["hesap"], a["sonuc"], a["ayar"], a["kaynak"], a["durum"]] for a in r["adimlar"]])
    if r.get("ayarlar"):
        ek += "<h2>Röle ekranına girilecekler</h2>" + _tablo(["Alan", "Değer", "Ayar aralığı", "Neden", "Dayanak", "Durum"], [[a["alan"], a["deger"], a["aralik"], a["neden"], a["kaynak"], a["durum"]] for a in r["ayarlar"]])
    test = ("<h2>Test planı (sekonder enjeksiyon)</h2>" + _tablo(["Test", "Uygulanacak", "Beklenen", "Tolerans / not"], [[t["ad"], t["uygula"], t["beklenen"], t["tolerans"]] for t in r["test"]])) if r.get("test") else ""
    return (f'<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{_e(sp["baslik"])} — ders notu</title><style>{CSS}</style></head><body>'
            f"<h1>{_e(sp['baslik'])}</h1><div class='alt'>{'Röle' if rolemi else 'Topraklama'} laboratuvarı — ders notu · Elektrik Lab v{__version__}</div><p>{_e(sp['giris'])}</p>"
            f"<h2>Ayarlar</h2>{_tablo(['Ayar', 'Değer'], ayar)}"
            f"<div class='v {'bad' if nbad else 'ok'}'>{'✗ ' + str(nbad) + ' koşul sağlanmıyor' if nbad else '✓ Bütün koşullar sağlanıyor'}</div><div class='kp'>{kp}</div>{cizim}"
            f"{ek}<h2>Ne oluyor?</h2><ol>{''.join(f'<li>{_e(a)}</li>' for a in r['anlatim'])}</ol><h2>Akılda kalsın</h2><ul>{''.join(f'<li>{_e(a)}</li>' for a in r['dersler'])}</ul>{kont}{test}{tabs}"
            "<div class='not'>Bu not öğretim amaçlıdır; modeller sadeleştirilmiştir. Bir tesisin uygunluğu proje hesabı ve ölçümle gösterilir. Durum sütunu: resmi (mevzuat ya da şartname metni) · "
            "dogrulanacak (standart maddesi, asıl metinle teyit edilecek) · ikincil · tahmini · hesap (temel bağıntı ya da bu nottaki türetme).</div></body></html>")


def html_pdf(h: str) -> bytes:
    from ..render import html_to_pdf
    td = Path(tempfile.mkdtemp(prefix="elab_not_"))
    try:
        (td / "not.html").write_text(h, encoding="utf-8")
        html_to_pdf(str(td / "not.html"), str(td / "not.pdf"))
        return (td / "not.pdf").read_bytes()
    finally:
        shutil.rmtree(td, ignore_errors=True)
