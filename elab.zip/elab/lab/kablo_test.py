"""Laboratuvar konusu — kablo deneyleri: OG XLPE kablolar (fabrika rutin deneyleri ve tesis sonrası deneyler) ve 0,6/1 kV AG kabloları.

Bağıntılar (tek damarlı, eş eksenli):
  kapasite          C′ = εr / (18·ln(ro/ri))   µF/km           (ri: iletken ekranı üstü yarıçap, ro: yalıtım üstü yarıçap)
  en büyük alan     Emax = U0 / (ri·ln(ro/ri)) kV/mm
  şarj akımı        IC = 2π·f·C′·L·U ;  deney gücü S = 2π·f·C′·L·U²   → 0,1 Hz'de 50 Hz'in 1/500'ü
  yalıtım direnci   R = Ki·log10(ro/ri) / L    MΩ               (Ki: yalıtım direnci sabiti, MΩ·km)
Resmi: TEDAŞ-MLZ/96-018.B (OG XLPE: anma gerilimleri, yalıtım kalınlıkları, 2·U0'da ≤ 5 pC, 20,3/35 kV'ta 190 kV darbe, rutin deney listesi),
TEDAŞ-MLZ/96-015.A (AG: rutin deney listesi), Elektrik Tesisleri Kabul Yön. m.28-D-5 (güç kablolarında saha deneyleri), Topraklamalar Yön. m.10 Çizelge-9.
Doğrulanacak: TS IEC 60502-1/-2 deney gerilimleri ve süreleri, TS EN 60228 iletken dirençleri, TS HD 620 / IEEE 400.2 (0,1 Hz deneyleri)."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, ctl, fnum, num, opt

ID = "kablo_test"
BASLIK = "Kablo deneyleri (OG ve AG)"
IKON = "🧵"
GIRIS = ("Bir kablo fabrikadan çıkarken, döşendikten sonra ve işletmede yaşlandıkça farklı deneylerden geçer. Hangi deney neyi arar, kabloya hangi gerilim ne kadar süre uygulanır, "
         "bağlantı nasıl yapılır ve ölçülen değer nasıl yorumlanır: OG XLPE ve AG kabloları için deneyin.")

D, IK = "dogrulanacak", "ikincil"
S96 = "TEDAŞ-MLZ/96-018.B"
# OG: U0/U (Um) → (U0, U, Um, yalıtım kalınlığı mm [resmi], yıldırım darbe kV tepe)
OG = {"3.6/6": (3.6, 6.0, 7.2, 2.5, 60), "6/10": (6.0, 10.0, 12.0, 3.4, 75), "8.7/15": (8.7, 15.0, 17.5, 4.5, 95), "20.3/35": (20.3, 35.0, 42.0, 9.0, 190)}
D_ILET = {16: 4.8, 25: 6.0, 35: 7.0, 50: 8.2, 70: 9.8, 95: 11.5, 120: 12.9, 150: 14.3, 185: 16.0, 240: 18.4}                     # sıkıştırılmış çok telli iletken çapı (mm) — yaklaşık
R20 = {"cu": {16: 1.15, 25: 0.727, 35: 0.524, 50: 0.387, 70: 0.268, 95: 0.193, 120: 0.153, 150: 0.124, 185: 0.0991, 240: 0.0754},
       "al": {16: 1.91, 25: 1.20, 35: 0.868, 50: 0.641, 70: 0.443, 95: 0.320, 120: 0.253, 150: 0.206, 185: 0.164, 240: 0.125}}       # Ω/km, 20 °C (TS EN 60228, sınıf 2)
T_AG = {"nyy": {16: 1.0, 25: 1.2, 35: 1.2, 50: 1.4, 70: 1.4, 95: 1.6, 120: 1.6, 150: 1.8, 185: 2.0, 240: 2.2},
        "n2xy": {16: 0.7, 25: 0.9, 35: 0.9, 50: 1.0, 70: 1.1, 95: 1.1, 120: 1.2, 150: 1.4, 185: 1.6, 240: 1.7}}                    # AG yalıtım kalınlığı (mm) — TS IEC 60502-1
KI = {"xlpe": 3670.0, "pvc": 36.7}        # yalıtım direnci sabiti, 20 °C (MΩ·km); çalışma sıcaklığında 3,67 / 0,037
ER = {"xlpe": 2.3, "pvc": 5.0}
DOG = {"megger": "Yalıtım direnci (megger)", "kilif": "Dış kılıf deneyi (d.a.)", "vlf": "Çok düşük frekanslı (0,1 Hz) dayanım deneyi", "ac": "Şebeke frekanslı deney (tesis sonrası)",
       "dc": "Doğru gerilim dayanım deneyi", "tand": "Kayıp açısı (tan δ) ölçümü — 0,1 Hz", "fabrika": "Fabrika rutin deneyleri (iletken direnci, kısmi boşalma, gerilim)"}
DAG = {"megger": "Yalıtım direnci (megger)", "direnc": "İletken direnci ve süreklilik", "fabrika": "Fabrika rutin deneyleri (iletken direnci, gerilim)"}
KES = (16, 25, 35, 50, 70, 95, 120, 150, 185, 240)

KONTROLLER = [
    ctl("kablo", "Kablo", "sec", "og", secenek=opt(("og", "OG — XLPE yalıtımlı, bakır ekranlı (tek damarlı)"), ("ag", "AG — 0,6/1 kV"))),
    ctl("u0u", "Anma gerilimi U0/U", "sec", "20.3/35", secenek=opt(*[(k, f"{k.replace('.', ',')} kV (Um {fnum(v[2], 1)} kV)") for k, v in OG.items()]), goster={"kablo": ["og"]}),
    ctl("ag_tip", "Yalıtım", "sec", "nyy", secenek=opt(("nyy", "PVC (NYY / YVV)"), ("n2xy", "XLPE (N2XY / YXV)")), goster={"kablo": ["ag"]}),
    ctl("iletken", "İletken", "sec", "cu", secenek=opt(("cu", "bakır"), ("al", "alüminyum"))),
    ctl("kesit", "İletken kesiti", "sec", 95, secenek=opt(*[(v, f"{v} mm²") for v in KES])),
    ctl("l_m", "Kablo uzunluğu", "sayi", 800, min=20, max=10000, adim=10, birim="m"),
    ctl("deney_og", "Deney", "sec", "megger", secenek=opt(*DOG.items()), goster={"kablo": ["og"]}),
    ctl("deney_ag", "Deney", "sec", "megger", secenek=opt(*DAG.items()), goster={"kablo": ["ag"]}),
    ctl("yas", "Kablonun durumu", "sec", "yeni", secenek=opt(("yeni", "Yeni döşenmiş (kabul)"), ("yasli", "İşletmede yaşlanmış (bakım)")), goster={"kablo": ["og"], "deney_og": ["vlf", "dc", "tand", "megger"]}),
    ctl("u_megger", "Megger gerilimi", "sec", 5000, secenek=opt((500, "500 V"), (1000, "1000 V"), (2500, "2500 V"), (5000, "5000 V")), goster={"kablo": ["og"], "deney_og": ["megger"]}),
    ctl("r_olc", "Ölçülen yalıtım direnci (60 s)", "sayi", 8000, min=0.5, max=200000, adim=1, birim="MΩ", goster={"kablo": ["og"], "deney_og": ["megger"]}),
    ctl("ekran_ayrik", "Ekran her iki uçta topraktan ayrıldı", "onay", True, goster={"kablo": ["og"], "deney_og": ["kilif"]}),
    ctl("kilif_mm", "Dış kılıf kalınlığı", "sayi", 2.5, min=1.4, max=4, adim=0.1, birim="mm", goster={"kablo": ["og"], "deney_og": ["kilif"]}),
    ctl("kilif_kv", "Uygulanan gerilim (ekran – toprak)", "sayi", 10, min=1, max=15, adim=0.5, birim="kV", goster={"kablo": ["og"], "deney_og": ["kilif"]}),
    ctl("kilif_ma", "Kararlı kaçak akım", "sayi", 0.1, min=0.01, max=20, adim=0.01, birim="mA", goster={"kablo": ["og"], "deney_og": ["kilif"]}),
    ctl("vlf_kv", "Uygulanan gerilim (0,1 Hz, etken)", "sayi", 61, min=5, max=75, adim=0.5, birim="kV", goster={"kablo": ["og"], "deney_og": ["vlf"]}),
    ctl("vlf_dk", "Süre", "sayi", 60, min=5, max=60, adim=5, birim="dk", goster={"kablo": ["og"], "deney_og": ["vlf"]}),
    ctl("delinme", "Deney sırasında delinme oldu", "onay", False, goster={"kablo": ["og"], "deney_og": ["vlf", "dc", "ac"]}),
    ctl("ac_yontem", "Yöntem", "sec", "u0_24", secenek=opt(("u0_24", "Şebeke geriliminde (U0) 24 saat yüksüz bekletme"), ("u_5", "İletken – ekran arasına faz arası gerilim (U), 5 dakika")), goster={"kablo": ["og"], "deney_og": ["ac"]}),
    ctl("dc_kv", "Uygulanan doğru gerilim", "sayi", 81, min=5, max=120, adim=1, birim="kV", goster={"kablo": ["og"], "deney_og": ["dc"]}),
    ctl("td05", "tan δ — 0,5·U0'da", "sayi", 0.6, min=0.05, max=150, adim=0.05, birim="×10⁻³", goster={"kablo": ["og"], "deney_og": ["tand"]}),
    ctl("td10", "tan δ — U0'da", "sayi", 0.7, min=0.05, max=150, adim=0.05, birim="×10⁻³", goster={"kablo": ["og"], "deney_og": ["tand"]}),
    ctl("td15", "tan δ — 1,5·U0'da", "sayi", 0.9, min=0.05, max=250, adim=0.05, birim="×10⁻³", goster={"kablo": ["og"], "deney_og": ["tand"]}),
    ctl("td_std", "U0'da ölçümlerin standart sapması", "sayi", 0.05, min=0.01, max=5, adim=0.01, birim="×10⁻³", goster={"kablo": ["og"], "deney_og": ["tand"]}),
    ctl("pd_pc", "Kısmi boşalma (2·U0'da)", "sayi", 3, min=0, max=50, adim=0.5, birim="pC", goster={"kablo": ["og"], "deney_og": ["fabrika"]}),
    ctl("u_rutin", "Rutin gerilim deneyi (5 dk)", "sayi", 71, min=5, max=90, adim=0.5, birim="kV", goster={"kablo": ["og"], "deney_og": ["fabrika"]}),
    ctl("r_ilet", "Ölçülen iletken direnci", "sayi", 0.190, min=0.05, max=2.5, adim=0.001, birim="Ω/km"),
    ctl("sicak", "Ölçüm sıcaklığı", "sayi", 20, min=0, max=40, adim=1, birim="°C"),
    ctl("r_ag", "Ölçülen yalıtım direnci", "sayi", 200, min=0.05, max=20000, adim=0.5, birim="MΩ", goster={"kablo": ["ag"], "deney_ag": ["megger"]}),
    ctl("u_megger_ag", "Megger gerilimi", "sec", 500, secenek=opt((250, "250 V"), (500, "500 V"), (1000, "1000 V")), goster={"kablo": ["ag"], "deney_ag": ["megger"]}),
    ctl("u_rutin_ag", "Rutin gerilim deneyi (5 dk, a.a.)", "sayi", 3.5, min=1, max=6, adim=0.1, birim="kV", goster={"kablo": ["ag"], "deney_ag": ["fabrika"]}),
]


def geometri(kesit: float, u0u: str) -> dict:
    """OG tek damarlı XLPE kablo: yarıçaplar (mm), kapasite (µF/km), U0'da en büyük alan (kV/mm)."""
    u0, u, um, t, bil = OG[u0u]
    ri = D_ILET[int(kesit)] / 2 + 0.5                       # iletken + iç yarı iletken siper (≥ 0,3 mm; 0,5 alındı)
    ro = ri + t
    ln = math.log(ro / ri)
    return {"ri": ri, "ro": ro, "c": ER["xlpe"] / (18 * ln), "emax": u0 / (ri * ln), "log10": math.log10(ro / ri), "t": t}


def sarj(c_uf_km: float, l_m: float, u_kv: float, f: float = 50.0) -> tuple[float, float]:
    """Şarj akımı (A) ve gereken deney gücü (kVA)."""
    i = 2 * math.pi * f * c_uf_km * 1e-6 * l_m / 1000 * u_kv * 1000
    return i, i * u_kv


def r_yalitim_min(tip: str, log10_oran: float, l_m: float) -> float:
    """Yalıtım direncinin 20 °C'de beklenen alt değeri (MΩ)."""
    return KI[tip] * log10_oran / (l_m / 1000)


def r20_duzelt(r_olc: float, sicaklik: float, iletken: str) -> float:
    a = 0.00393 if iletken == "cu" else 0.00403
    return r_olc / (1 + a * (sicaklik - 20))


def _sema(og: bool, deney: str, etiket: str, cihaz: str, ok: bool, ayrik: bool = True) -> Cizim:
    c = Cizim(900, 320, zemin=282)
    c.yazi(450, 24, "KABLO GÜZERGÂHI — yakın uç (deney ucu) solda, uzak uç sağda", "#334155", 11, True, "middle")
    ys = (70, 128, 186)
    for k, y in enumerate(ys):
        den = k == 0 or (deney == "direnc" and k == 1)
        # dış kılıf, ekran, yalıtım, iletken (boyuna kesit)
        c.dikdortgen(260, y - 20, 420, 40, "#111827", "#e5e7eb", 1.4, False, 4)
        if og:
            c.dikdortgen(264, y - 16, 412, 32, "uyari", "rgba(217,119,6,.20)", 1.6, False, 3)
        c.dikdortgen(268, y - 11, 404, 22, "#64748b", "#f8fafc", 1, False, 3)
        c.hat(f"M230,{y} H710", "ariza" if den and deney not in ("kilif",) else "cizgi", w=5)
        c.yazi(246, y - 26, f"L{k + 1}", "#334155", 11, True, "end")
        if og:
            if deney == "kilif":
                if k:
                    c.hat(f"M264,{y + 16} H244", "uyari", w=2).yazi(240, y + 20, "ayrık", "uyari", 9.5, False, "end")
            else:
                c.hat(f"M264,{y + 16} H214 V282", "PE", w=2).hat(f"M676,{y + 16} H740 V282", "PE", w=2, kesik=not ayrik)
        if not den and deney not in ("kilif", "direnc"):
            c.hat(f"M230,{y} H196 V282", "PE", kesik=True)           # denenmeyen fazlar topraklı
        if deney not in ("direnc",):
            c.yazi(752, y - 6, "açık, yalıtılmış", "#64748b", 9.5)
    c.yazi(470, ys[0] - 26, ("ekran" if og else "") + (" · " if og else "") + "yalıtım · iletken", "#475569", 9.5, False, "middle")
    c.kutu(24, 44, 130, 52, cihaz, etiket, "acti" if ok else "gecersiz")
    if deney == "kilif":
        c.hat("M154,70 H204 V86 H264", "uyari", hot=True).hat("M90,96 V282", "PE").yazi(470, 236, "ekranlar her iki uçta topraktan ayrık; gerilim L1 ekranı ile toprak arasına uygulanıyor", "uyari", 10.5, True, "middle")
        c.yazi(470, 254, "dış kılıfın çevresi iletken olmalı: toprak / dolgu ya da grafit kaplama", "#475569", 10, False, "middle")
    elif deney == "direnc":
        c.hat("M154,70 H230", "ariza", hot=True).hat("M710,70 H770 V128 H710", "mavi", w=3).yazi(780, 104, "uzak uçta köprü", "mavi", 10).hat("M230,128 H170 V96", "ariza", hot=True)
    else:
        c.hat("M154,70 H230", "ariza", hot=True).hat("M90,96 V282", "PE")
    c.toprak(90, 282)
    return c


def run(p: dict) -> dict:
    og = p.get("kablo") != "ag"
    kes = int(num(p, "kesit", 95)); kes = kes if kes in KES else 95
    L = num(p, "l_m", 800); ilet = "al" if p.get("iletken") == "al" else "cu"
    kt, an, ds, graf, tab = [], [], [], [], []
    r20_max = R20[ilet][kes]
    r20_olc = r20_duzelt(num(p, "r_ilet", 0.190), num(p, "sicak", 20), ilet)
    k_direnc = C("İletken direnci (20 °C'ye indirgenmiş)", f"{fnum(r20_olc, 4)} Ω/km ({fnum(num(p, 'r_ilet', 0.190), 4)} Ω/km, {fnum(num(p, 'sicak', 20), 0)} °C)", f"≤ {fnum(r20_max, 4)} Ω/km ({kes} mm² {'Cu' if ilet == 'cu' else 'Al'})",
                 r20_olc <= r20_max * 1.0005, "TS EN 60228 (sınıf 2 iletken, 20 °C'de en büyük direnç); TS IEC 60502 rutin deney", D)
    if og:
        u0u = p.get("u0u") if p.get("u0u") in OG else "20.3/35"
        u0, u, um, t, bil = OG[u0u]
        Gm = geometri(kes, u0u)
        deney = p.get("deney_og") if p.get("deney_og") in DOG else "megger"
        yasli = p.get("yas") == "yasli"
        c_top = Gm["c"] * L / 1000                               # µF
        i50, s50 = sarj(Gm["c"], L, u0)
        an.append(f"Kablo: {u0u.replace('.', ',')} kV, {kes} mm² {'bakır' if ilet == 'cu' else 'alüminyum'}, XLPE yalıtım {fnum(t, 1)} mm, {fnum(L, 0)} m. Kapasitesi C′ = εr / (18·ln(ro/ri)) = {fnum(Gm['c'], 3)} µF/km → toplam {fnum(c_top, 3)} µF. "
                  f"İşletme geriliminde (U0 = {fnum(u0, 1)} kV) şarj akımı {fnum(i50, 2)} A; iletken yüzeyindeki alan şiddeti {fnum(Gm['emax'], 2)} kV/mm.")
        if deney == "megger":
            um_ = num(p, "u_megger", 5000); r = num(p, "r_olc", 8000)
            rmin = r_yalitim_min("xlpe", Gm["log10"], L)
            an += [f"Megger iletken ile (ekran + toprak) arasına bağlanır; diğer iki faz topraklanır, uzak uç açık ve yalıtılmış bırakılır. Kablo büyük bir kondansatördür ({fnum(c_top, 3)} µF): gösterge kapasite dolana ve soğurma akımı azalana kadar yükselir; değer 1. dakikada okunur.",
                   f"Beklenen değer uzunlukla ters orantılıdır: R = Ki·log10(ro/ri) / L. XLPE için Ki ≈ {fnum(KI['xlpe'], 0)} MΩ·km (20 °C) → {fnum(L, 0)} m için alt değer ≈ {fnum(rmin, 0)} MΩ. Sağlam yeni kabloda ölçülen değer bunun çok üstündedir; anlamlı olan, üç fazın birbirine yakın olmasıdır.",
                   f"Megger başlıkların yüzeyini ve ekleri de ölçer: nemli bir kablo başlığı bütün kabloyu “kötü” gösterebilir. Ölçümden sonra kablo boşaltılır: {fnum(um_ / 1000, 1)} kV'ta depolanan enerji {fnum(0.5 * c_top * 1e-6 * um_ ** 2, 2)} J, soğurulan yük nedeniyle gerilim geri gelir."]
            kt += [C("Yalıtım direnci (iletken – ekran, 60 s)", f"{fnum(r, 0)} MΩ ({fnum(r * L / 1000, 0)} MΩ·km)", f"≥ Ki·log10(ro/ri)/L = {fnum(rmin, 0)} MΩ ; üç faz arasında birkaç kattan büyük fark olmamalı", r >= rmin - 1e-9, "TS IEC 60502-2 (yalıtım direnci sabiti Ki); uygulama ölçütü", IK),
                   C("Ölçüm gerilimi", f"{fnum(um_, 0)} V d.a.", "OG kablo yalıtımı için 2500 – 5000 V (dış kılıf için ayrı deney)", um_ >= 2500, "Elektrik Tesisleri Kabul Yön. m.28-D-5 (güç kabloları: yalıtım direnci deneyi megger ile); gerilim: uygulama", "resmi"),
                   C("Megger'in söyleyebildiği", "nem, kirli başlık, kaba hasar", "megger kabul deneyi değildir: su ağacı, boşluk ve ek hatalarını göstermez; dayanım ya da tan δ deneyi yerine geçmez", None, "TS HD 620; IEEE 400", IK)]
            graf.append({"baslik": "Beklenen alt değer — kablo uzunluğuna göre", "x_ad": "uzunluk (m)", "y_ad": "yalıtım direnci (MΩ)", "logx": True, "logy": True,
                         "seriler": [{"ad": "XLPE alt değer (Ki = 3670 MΩ·km)", "renk": "#1a4d8f", "pts": [[x, round(r_yalitim_min('xlpe', Gm['log10'], x), 1)] for x in (20, 50, 100, 200, 500, 1000, 2000, 5000, 10000)]}], "isaretler": [{"x": L, "etiket": f"bu kablo: ölçülen {fnum(r, 0)} MΩ"}]})
            sema = _sema(True, deney, f"{fnum(r, 0)} MΩ", f"megger {fnum(um_, 0)} V", r >= rmin)
        elif deney == "kilif":
            tk = num(p, "kilif_mm", 2.5); uk = num(p, "kilif_kv", 10); ik = num(p, "kilif_ma", 0.1); ayr = bool(p.get("ekran_ayrik"))
            ug = min(4 * tk, 10.0)
            an += ["Dış kılıf, ekranı ve yalıtımı sudan korur. Döşeme sırasında taş, kürek ya da çekme halatıyla delinirse su ekrana ulaşır; ekran korozyona uğrar, yalıtımda su ağacı başlar. Hasar yıllar sonra arıza olarak görünür.",
                   f"Deney: ekran her iki uçta topraktan ayrılır; ekran ile toprak arasına doğru gerilim uygulanır. Gerilim kılıf kalınlığının milimetresi başına 4 kV, en çok 10 kV: {fnum(tk, 1)} mm kılıf için {fnum(ug, 1)} kV, 1 dakika.",
                   "Kılıfın dış yüzü iletken bir ortamla çevrili olmalıdır (toprak, nemli dolgu ya da grafit kaplama); boruda ya da havada duran kabloda delik bulunamaz. Akım kararlı ve küçük kalırsa kılıf sağlamdır; yükselen ya da zıplayan akım deliği gösterir, yeri adım gerilimi yöntemiyle bulunur."]
            kt += [C("Ekranın topraktan ayrılması", "her iki uçta ayrık" if ayr else "bir uç toprağa bağlı", "ekran iki uçta da topraktan ayrılır; yoksa gerilim uygulanamaz (kaynak kısa devre)", ayr, "TS IEC 60502-2 m.20.3.1; TS EN 60229", D),
                   C("Deney gerilimi", f"{fnum(uk, 1)} kV d.a.", f"4 kV/mm × {fnum(tk, 1)} mm = {fnum(ug, 1)} kV (en çok 10 kV), 1 dakika", abs(uk - ug) <= 0.05 * ug and ayr, "TS EN 60229 (dış kılıf deneyleri); TS IEC 60502-2 m.20.3.1", D),
                   C("Kaçak akım", f"{fnum(ik, 2)} mA (kararlı)", "küçük ve kararlı (mA'nın altında); delinme yok", ik <= 1.0, "Uygulama ölçütü; kablo üreticisi kuralları", IK)]
            sema = _sema(True, deney, f"{fnum(uk, 1)} kV · {fnum(ik, 2)} mA", "d.a. deney cihazı", all(k["ok"] is not False for k in kt), ayr)
        elif deney == "vlf":
            uv = num(p, "vlf_kv", 61); dk = num(p, "vlf_dk", 60); dl = bool(p.get("delinme"))
            ug = (2.0 if yasli else 3.0) * u0
            i01, s01 = sarj(Gm["c"], L, uv, 0.1); i50v, s50v = sarj(Gm["c"], L, uv, 50)
            an += [f"Döşenmiş kabloya 50 Hz'de dayanım deneyi yapmak için kapasitif akımı karşılayan büyük bir kaynak gerekir: {fnum(uv, 0)} kV'ta {fnum(i50v, 1)} A, {fnum(s50v, 0)} kVA. Aynı gerilimde 0,1 Hz'de akım ve güç frekansla orantılı olarak 500 kat küçülür: {fnum(i01 * 1000, 0)} mA, {fnum(s01, 2)} kVA. Taşınabilir bir cihaz yeter.",
                   f"Deney: gerilim iletken ile ekran arasına uygulanır, diğer fazlar ve ekranlar topraklıdır. {'Yaşlanmış kabloda gerilim düşük tutulur (≈ 2·U0)' if yasli else 'Yeni döşenmiş kabloda 3·U0'} = {fnum(ug, 1)} kV (etken), 15 – 60 dakika. Kabul ölçütü delinme olmamasıdır.",
                   "Alternatif gerilim olduğu için yalıtımda yük birikmez; kusurlu bir ek ya da hasarlı yalıtım deney sırasında delinir (işletmede değil). Süre kısa tutulursa büyümekte olan bir kusur delinmeden kalabilir; bu yüzden yeni tesiste 60 dakika önerilir."]
            kt += [C("Deney gerilimi (0,1 Hz, etken)", f"{fnum(uv, 1)} kV = {fnum(uv / u0, 2)} × U0", f"{'≈ 2·U0 (1,7 – 2,2·U0): bakım deneyi' if yasli else '3·U0 = ' + fnum(ug, 1) + ' kV: kabul deneyi'}",
                     (1.7 * u0 <= uv <= 2.2 * u0) if yasli else abs(uv - ug) <= 0.05 * ug, "TS HD 620 (tesis sonrası deneyler); IEEE 400.2 (0,1 Hz saha deneyleri)", D),
                   C("Deney süresi", f"{fnum(dk, 0)} dk", "en az 15 dk; yeni tesiste 60 dk önerilir", True if dk >= (60 if not yasli else 30) else (None if dk >= 15 else False), "TS HD 620; IEEE 400.2", D),
                   C("Sonuç", "delinme oldu" if dl else "delinme yok", "delinme olmamalı; olursa arıza yeri bulunur, onarılır, deney yinelenir", not dl, "TS HD 620; IEEE 400.2", D)]
            xs = [50, 100, 200, 500, 1000, 2000, 5000, 10000]
            graf.append({"baslik": f"Deney kaynağından istenen güç ({fnum(uv, 0)} kV)", "x_ad": "kablo uzunluğu (m)", "y_ad": "güç (kVA)", "logx": True, "logy": True,
                         "seriler": [{"ad": "50 Hz", "renk": "#dc2626", "pts": [[x, round(sarj(Gm['c'], x, uv, 50)[1], 3)] for x in xs]}, {"ad": "0,1 Hz", "renk": "#15803d", "pts": [[x, round(sarj(Gm['c'], x, uv, 0.1)[1], 4)] for x in xs]}], "isaretler": [{"x": L, "etiket": "bu kablo"}]})
            sema = _sema(True, deney, f"{fnum(uv, 1)} kV · 0,1 Hz · {fnum(dk, 0)} dk", "0,1 Hz deney cihazı", all(k["ok"] is not False for k in kt))
        elif deney == "ac":
            yon = p.get("ac_yontem"); dl = bool(p.get("delinme"))
            iu, su = sarj(Gm["c"], L, u)
            an += ["Tesis sonrası şebeke frekanslı deney iki biçimde yapılabilir: kablo yüksüz olarak şebeke geriliminde 24 saat bekletilir, ya da iletken ile ekran arasına 5 dakika süreyle faz arası gerilim uygulanır.",
                   (f"24 saat yüksüz bekletme: kabloya yalnız işletme gerilimi ({fnum(u0, 1)} kV) uygulanır; ayrı bir deney kaynağı gerekmez. Dayanım payı yoktur: yalnız kaba montaj hatalarını (yanlış yapılmış ek, hasarlı başlık) ortaya çıkarır." if yon != "u_5" else
                    f"Faz arası gerilimle 5 dakika: iletken–ekran arasına {fnum(u, 1)} kV (= 1,73·U0) uygulanır. 50 Hz'de gereken kaynak {fnum(iu, 1)} A, {fnum(su, 0)} kVA: uzun kabloda bu güç ancak rezonans deney düzeniyle (ayarlı reaktör kablo kapasitesiyle rezonansa getirilir) sağlanır."),
                   "Her iki yöntem de fabrika rutin deneyinden (3,5·U0) çok daha hafiftir; döşeme ve ek hatalarını bulmak içindir, kablonun kendisini yeniden sınamak için değil."]
            kt += [C("Deney yöntemi", "U0, 24 saat" if yon != "u_5" else f"U = {fnum(u, 1)} kV, 5 dakika", "U0'da 24 saat ya da iletken – ekran arasına U (faz arası gerilim) 5 dakika", True, "TS IEC 60502-2 m.20.3.2 (tesis sonrası a.a. deneyi)", D),
                   C("Sonuç", "delinme oldu" if dl else "delinme yok", "delinme olmamalı", not dl, "TS IEC 60502-2 m.20.3.2", D)]
            sema = _sema(True, deney, "U0 · 24 saat" if yon != "u_5" else f"{fnum(u, 1)} kV · 5 dk", "şebeke / rezonans düzeni", not dl)
        elif deney == "dc":
            ud = num(p, "dc_kv", 81); dl = bool(p.get("delinme")); ug = 4 * u0
            an += [f"Doğru gerilim deneyi küçük bir kaynakla yapılır (kapasite bir kez dolar, sonra yalnız kaçak akım akar). Standartta tesis sonrası için 4·U0 = {fnum(ug, 0)} kV, 15 dakika verilir; Kabul Yönetmeliği de güç kabloları için doğru akım yüksek gerilim deneyini sayar.",
                   "XLPE yalıtımda doğru gerilim iki sakınca taşır. Birincisi: alan dağılımını kapasiteler değil dirençler belirler; ek ve başlıklardaki alan denetimi a.a. için tasarlanmıştır, d.a.'da zorlanan yer işletmedekinden farklıdır — kusur bulunmadan geçilebilir.",
                   "İkincisi: polietilen yükü tutar. Deneyden sonra yalıtımın içinde kalan uzay yükü, kablo yeniden a.a. gerilime alındığında alanı yerel olarak büyütür; yaşlanmış (su ağaçlı) kabloda bu, deneyden günler sonra delinmeye yol açabilir. Bu yüzden XLPE kabloda 0,1 Hz ya da rezonans deneyi tercih edilir."]
            kt += [C("Deney gerilimi", f"{fnum(ud, 0)} kV d.a. = {fnum(ud / u0, 1)} × U0", f"4·U0 = {fnum(ug, 0)} kV, 15 dakika", abs(ud - ug) <= 0.05 * ug, "TS IEC 60502-2 m.20.3.2 (d.a. seçeneği); Elektrik Tesisleri Kabul Yön. m.28-D-5 (DA yüksek gerilim deneyi)", D),
                   C("XLPE kabloda doğru gerilim", "yaşlanmış kabloya uygulanıyor" if yasli else "yeni kabloya uygulanıyor", "işletmede yaşlanmış XLPE kabloya d.a. dayanım deneyi uygulanmaz; yeni kabloda izinlidir ama 0,1 Hz ya da rezonans deneyi tercih edilir", False if yasli else None, "TS HD 620; IEEE 400 (uzay yükü ve su ağacı etkisi)", IK),
                   C("Sonuç", "delinme oldu" if dl else "delinme yok", "delinme olmamalı", not dl, "TS IEC 60502-2 m.20.3.2", D)]
            sema = _sema(True, deney, f"{fnum(ud, 0)} kV d.a. · 15 dk", "d.a. deney cihazı", all(k["ok"] is not False for k in kt))
        elif deney == "tand":
            t05, t10, t15, sd = num(p, "td05", 0.6), num(p, "td10", 0.7), num(p, "td15", 0.9), num(p, "td_std", 0.05)
            fark = t15 - t05
            der = lambda v, a, b: True if v < a else (None if v <= b else False)  # noqa: E731
            an += ["Kayıp açısı ölçümü kabloyu delmeden yaşını okur. 0,1 Hz gerilim 0,5·U0, U0 ve 1,5·U0 basamaklarında uygulanır; her basamakta birkaç ölçüm alınır. Sağlam XLPE'de tan δ çok küçüktür ve gerilimle değişmez.",
                   f"Bu ölçümde: U0'da {fnum(t10, 2)} × 10⁻³, gerilimle artış (1,5·U0 − 0,5·U0) {fnum(fark, 2)} × 10⁻³, kararlılık (standart sapma) {fnum(sd, 2)} × 10⁻³.",
                   "Su ağaçları yalıtımın içinde su dolu ince kanallardır: kaybı artırır ve gerilim yükseldikçe daha çok iletir. Bu yüzden asıl gösterge mutlak değer değil, tan δ'nın gerilimle artışı ve ölçümden ölçüme oynamasıdır. Üç fazın birbirinden farkı da aynı bilgiyi verir.",
                   "Yüksek tan δ her zaman yalıtım demek değildir: nemli ek ya da başlık, ekrandaki korozyon aynı sonucu verir. Bulgu, kısmi boşalma ölçümü ve eklerin incelenmesiyle ayrıştırılır."]
            kt += [C("tan δ — U0'da ortalama", f"{fnum(t10, 2)} × 10⁻³", "< 4 işlem gerekmez · 4 – 50 incelenir · > 50 önlem gerekir (× 10⁻³; işletmedeki PE / XLPE)", der(t10, 4, 50), "IEEE 400.2 (0,1 Hz tan δ değerlendirme ölçütleri)", IK),
                   C("tan δ'nın gerilimle artışı (1,5·U0 − 0,5·U0)", f"{fnum(fark, 2)} × 10⁻³", "< 5 işlem gerekmez · 5 – 80 incelenir · > 80 önlem gerekir (× 10⁻³)", der(fark, 5, 80), "IEEE 400.2", IK),
                   C("Kararlılık (U0'da standart sapma)", f"{fnum(sd, 2)} × 10⁻³", "< 0,1 işlem gerekmez · 0,1 – 0,5 incelenir · > 0,5 önlem gerekir (× 10⁻³)", der(sd, 0.1, 0.5), "IEEE 400.2", IK)]
            graf.append({"baslik": "tan δ — gerilim basamakları", "x_ad": "gerilim (U / U0)", "y_ad": "tan δ (× 10⁻³)", "ymin": 0,
                         "seriler": [{"ad": "ölçülen", "renk": "#dc2626" if any(k["ok"] is False for k in kt) else "#1a4d8f", "pts": [[0.5, t05], [1.0, t10], [1.5, t15]]}, {"ad": "ölçülen noktalar", "renk": "#111827", "nokta": True, "r": 4, "pts": [[0.5, t05], [1.0, t10], [1.5, t15]]}],
                         "yatay": [{"y": 4, "etiket": "incelenir (4)", "renk": "#d97706"}] + ([{"y": 50, "etiket": "önlem gerekir (50)"}] if max(t05, t10, t15) > 20 else [])})
            sema = _sema(True, deney, f"tan δ {fnum(t10, 2)} × 10⁻³", "0,1 Hz + tan δ ölçer", all(k["ok"] is not False for k in kt))
        else:                                                    # fabrika
            pd = num(p, "pd_pc", 3); ur = num(p, "u_rutin", 71); ug = 3.5 * u0
            an += ["Fabrikada her makara üç rutin deneyden geçer: iletkenin direnci ölçülür, kısmi boşalma ölçülür, gerilim deneyi yapılır. Sonuçlar makara seri numarasıyla kaydedilir ve kabulde alıcıya verilir.",
                   f"Kısmi boşalma: şartname 2·U0 = {fnum(2 * u0, 1)} kV'ta en çok 5 pC ister (standarttaki 1,73·U0 / 10 pC'den sıkı). Yalıtımda 0,05 mm'den büyük boşluk ve yabancı madde bulunmayacağı da şartname koşuludur; kısmi boşalma deneyi bunu elektriksel olarak doğrular.",
                   f"Gerilim deneyi: iletken ile ekran arasına 5 dakika süreyle 3,5·U0 = {fnum(ug, 0)} kV (50 Hz). Tip deneylerinde ayrıca 4 saat süreli deney (4·U0 = {fnum(4 * u0, 0)} kV), ısıtma çevrimleri, bükme ve yıldırım darbe deneyi ({bil} kV tepe) yapılır."]
            kt += [k_direnc,
                   C("Kısmi boşalma (2·U0'da)", f"{fnum(pd, 1)} pC ({fnum(2 * u0, 1)} kV)", "≤ 5 pC", pd <= 5 + 1e-9, S96 + " m.3 (kısmi boşalma genliği 2·U0 gerilimde 5 pC'u geçmeyecektir)", "resmi"),
                   C("Rutin gerilim deneyi", f"{fnum(ur, 1)} kV, 5 dk", f"3,5·U0 = {fnum(ug, 1)} kV, 5 dakika, delinme yok", abs(ur - ug) <= 0.03 * ug, S96 + " m.3.3 (rutin: gerilim deneyi) — değer: TS IEC 60502-2 m.16.4", D),
                   C("Yıldırım darbe dayanımı (tip deneyi)", f"{bil} kV tepe", "20,3/35 kV kablolarda 190 kV tepe" if u0u == "20.3/35" else "TS IEC 60502-2 çizelgesindeki değer", None, (S96 + " m.3") if u0u == "20.3/35" else "TS IEC 60502-2 m.18.1.7", "resmi" if u0u == "20.3/35" else D)]
            sema = _sema(True, "megger", f"{fnum(ur, 0)} kV · 5 dk · {fnum(pd, 1)} pC", "deney trafosu + PD", all(k["ok"] is not False for k in kt))
        ds = ["Megger kabloyu “kuru ve bütün” diye sınar; dayanım deneyi “bugün delinir mi” diye; tan δ ve kısmi boşalma “ne kadar yaşlandı, nerede kusur var” diye. Biri öbürünün yerini tutmaz.",
              "XLPE kabloda saha deneyi için sıra: dış kılıf deneyi → yalıtım direnci → 0,1 Hz (ya da rezonans) dayanım → gerekiyorsa tan δ / kısmi boşalma. Doğru gerilim yalnız dış kılıfa uygulanır.",
              "Deneyden önce kablo her iki uçta ayrılır; uzak uç çevrilir ve gözetlenir. Gerilim trafoları ve parafudrlar deney devresinden çıkarılır. Deneyden sonra kablo topraklama çubuğuyla boşaltılır ve topraklı bırakılır.",
              "Ekran deney sırasında (dış kılıf deneyi dışında) topraklı kalır: ekran topraklanmazsa gerilim yalıtım ile kılıf arasında bölünür, kılıf delinir.",
              "Kablonun en zayıf yerleri ekler ve başlıklardır; saha deneylerinde bulunan kusurların çoğu kablonun kendisinde değil, montajındadır."]
        tab.append({"baslik": "OG XLPE kablo — şartnamedeki deneyler", "cols": ["Tür", "Deney", "Değer / ölçüt", "Dayanak", "Durum"],
                    "rows": [["Rutin (her makara)", "İletken direncinin ölçülmesi", f"≤ {fnum(r20_max, 4)} Ω/km (20 °C)", S96 + " m.3.3; TS EN 60228", "resmi / dogrulanacak"], ["Rutin", "Kısmi boşalma", f"2·U0 = {fnum(2 * u0, 1)} kV'ta ≤ 5 pC", S96 + " m.3", "resmi"],
                             ["Rutin", "Gerilim deneyi", f"3,5·U0 = {fnum(3.5 * u0, 0)} kV, 5 dk", S96 + " m.3.3; TS IEC 60502-2 m.16.4", "resmi (deney) / dogrulanacak (değer)"],
                             ["Numune", "4 saat süreli gerilim deneyi", f"4·U0 = {fnum(4 * u0, 0)} kV, 4 saat", S96 + " m.3.2; TS IEC 60502-2 m.17.9", "resmi / dogrulanacak"],
                             ["Tip (A grubu, sırayla)", "Kısmi boşalma → bükme + kısmi boşalma → tan δ → ısıtma çevrimi + kısmi boşalma → darbe + gerilim → 4 saat gerilim", f"darbe {bil} kV tepe", S96 + " m.3.1.1", "resmi"],
                             ["Yapı", "Yalıtım kalınlığı", f"{fnum(t, 1)} mm (anma)", S96 + " m.2.2.2.2", "resmi"], ["Yapı", "Yalıtımda boşluk / yabancı madde", "≤ 0,05 mm ; nem ≤ 200 ppm", S96 + " m.2.2.2.2", "resmi"]]})
        tab.append({"baslik": "Tesis sonrası (saha) deneyleri — gerilimler", "cols": ["Deney", "Gerilim", "Süre", "Nereye", "Dayanak", "Durum"],
                    "rows": [["Dış kılıf (d.a.)", "4 kV/mm, en çok 10 kV", "1 dk", "ekran – toprak", "TS EN 60229; TS IEC 60502-2 m.20.3.1", D], ["Yalıtım direnci", "2500 – 5000 V d.a.", "1 dk okuma", "iletken – ekran", "Elektrik Tesisleri Kabul Yön. m.28-D-5", "resmi (deney)"],
                             ["0,1 Hz dayanım", f"3·U0 = {fnum(3 * u0, 1)} kV (bakımda ≈ 2·U0)", "15 – 60 dk", "iletken – ekran", "TS HD 620; IEEE 400.2", D], ["50 Hz — yüksüz bekletme", f"U0 = {fnum(u0, 1)} kV", "24 saat", "şebekeden", "TS IEC 60502-2 m.20.3.2", D],
                             ["50 Hz — faz arası gerilim", f"U = {fnum(u, 1)} kV", "5 dk", "iletken – ekran", "TS IEC 60502-2 m.20.3.2", D], ["Doğru gerilim", f"4·U0 = {fnum(4 * u0, 0)} kV", "15 dk", "iletken – ekran", "TS IEC 60502-2 m.20.3.2; Kabul Yön. m.28-D-5", "dogrulanacak; XLPE'de önerilmez"],
                             ["Güç katsayısı / kapasite / d.a. direnci", "—", "—", "iletken – ekran", "Elektrik Tesisleri Kabul Yön. m.28-D-5", "resmi (deney)"]]})
        oz = [K("Kapasite", f"{fnum(c_top, 3)} µF", "info", f"{fnum(Gm['c'], 3)} µF/km"), K("Şarj akımı (U0, 50 Hz)", f"{fnum(i50, 2)} A", "info", f"{fnum(s50, 0)} kVA"), K("Alan şiddeti (U0)", f"{fnum(Gm['emax'], 2)} kV/mm", "info", "iletken yüzeyinde"),
              K("Deney", DOG[deney].split(" (")[0], "info", "yaşlanmış kablo" if yasli and deney in ("vlf", "dc", "tand", "megger") else ""), K("Sonuç", "uygun" if all(k["ok"] is not False for k in kt) else "uygun değil", "ok" if all(k["ok"] is not False for k in kt) else "bad", f"{sum(1 for k in kt if k['ok'] is False)} kırmızı satır")]
    else:
        tip = "n2xy" if p.get("ag_tip") == "n2xy" else "nyy"
        yal = "xlpe" if tip == "n2xy" else "pvc"
        deney = p.get("deney_ag") if p.get("deney_ag") in DAG else "megger"
        t = T_AG[tip][kes]; d = D_ILET[kes]
        lg = math.log10((d + 2 * t) / d)
        rmin = r_yalitim_min(yal, lg, L)
        an.append(f"Kablo: 0,6/1 kV {'N2XY (XLPE)' if tip == 'n2xy' else 'NYY (PVC)'}, {kes} mm² {'bakır' if ilet == 'cu' else 'alüminyum'}, yalıtım kalınlığı {fnum(t, 1)} mm, {fnum(L, 0)} m.")
        if deney == "megger":
            r = num(p, "r_ag", 200); um_ = num(p, "u_megger_ag", 500)
            an += ["AG kablosunda yalıtım direnci her damar ile diğer damarlar + toprak arasında ölçülür; kablo iki uçta da ayrılmış, yük ve cihazlar sökülmüş olmalıdır. Nötr topraktan ayrılır; PEN ayrılmaz.",
                   f"Yönetmelik sınırı uzunluktan bağımsızdır: 500 V'a kadar devrelerde 500 V doğru gerilimle en az 0,5 MΩ. Kablonun kendisinden beklenen değer ise uzunlukla ters orantılıdır: R = Ki·log10(D/d)/L. {'XLPE' if yal == 'xlpe' else 'PVC'} için Ki ≈ {fnum(KI[yal], 1 if yal == 'pvc' else 0)} MΩ·km (20 °C) → {fnum(L, 0)} m için ≈ {fnum(rmin, 1)} MΩ.",
                   "PVC'nin yalıtım direnci XLPE'den yaklaşık yüz kat küçüktür ve sıcaklıkla hızla düşer (70 °C'de bin kat). Sıcak bir yaz günü uzun bir PVC kabloda birkaç megaohm okumak olağandır; aynı değer XLPE kabloda nem ya da hasar belirtisidir."]
            kt += [C("Yalıtım direnci", f"{fnum(r, 1)} MΩ", "≥ 0,5 MΩ (500 V'a kadar devre, 500 V d.a. ile)", r >= 0.5 - 1e-9, "Topraklamalar Yön. m.10, Çizelge-9", "resmi"),
                   C("Ölçüm gerilimi", f"{fnum(um_, 0)} V d.a.", "500 V'a kadar devrelerde 500 V (SELV / PELV: 250 V; 500 V üstü: 1000 V)", um_ == 500, "Topraklamalar Yön. m.10, Çizelge-9", "resmi"),
                   C("Kablodan beklenen değer", f"{fnum(r, 1)} MΩ ölçüldü", f"≥ Ki·log10(D/d)/L = {fnum(rmin, 1)} MΩ ; altındaysa nem, ezilme ya da ek hatası aranır", True if r >= rmin else None, "TS IEC 60502-1 (yalıtım direnci sabiti Ki)", D)]
            graf.append({"baslik": "Kablodan beklenen yalıtım direnci — uzunluğa göre (20 °C)", "x_ad": "uzunluk (m)", "y_ad": "yalıtım direnci (MΩ)", "logx": True, "logy": True,
                         "seriler": [{"ad": "PVC", "renk": "#d97706", "pts": [[x, round(r_yalitim_min('pvc', math.log10((d + 2 * T_AG['nyy'][kes]) / d), x), 2)] for x in (20, 50, 100, 200, 500, 1000, 2000, 5000)]},
                                     {"ad": "XLPE", "renk": "#1a4d8f", "pts": [[x, round(r_yalitim_min('xlpe', math.log10((d + 2 * T_AG['n2xy'][kes]) / d), x), 1)] for x in (20, 50, 100, 200, 500, 1000, 2000, 5000)]}],
                         "isaretler": [{"x": L, "etiket": f"ölçülen {fnum(r, 1)} MΩ"}], "yatay": [{"y": 0.5, "etiket": "yönetmelik sınırı 0,5 MΩ"}]})
            sema = _sema(False, "megger", f"{fnum(r, 1)} MΩ", f"megger {fnum(um_, 0)} V", r >= 0.5)
        elif deney == "direnc":
            r_cev = 2 * num(p, "r_ilet", 0.190) * L / 1000
            an += [f"Uzak uçta iki damar köprülenir, yakın uçtan çevrim direnci ölçülür: iki damar için 2 × {fnum(num(p, 'r_ilet', 0.190), 4)} Ω/km × {fnum(L / 1000, 3)} km = {fnum(r_cev * 1000, 1)} mΩ. Ölçüm dört uçlu (Kelvin) yapılır; değer 20 °C'ye indirgenip iletkenin standart direnciyle karşılaştırılır.",
                   "Yüksek direnç: kesit eksik, iletken alüminyum (bakır sanılıyor), gevşek pabuç ya da kötü ek. Aynı ölçüm damar sürekliliğini, uzak uçta sırayla köprü değiştirilerek faz sırasını ve damar işaretlemesini de doğrular.",
                   "Koruma iletkeninin sürekliliği ayrıca en az 0,2 A verebilen, 4 – 24 V'luk kaynakla denenir."]
            kt += [k_direnc, C("Koruma iletkeni sürekliliği deneyi", "en az 0,2 A, 4 – 24 V kaynakla", "koruma iletkenleri ve dengeleme bağlantıları için zorunlu", None, "Topraklamalar Yön. m.10-2", "resmi")]
            sema = _sema(False, "direnc", f"{fnum(r_cev * 1000, 1)} mΩ (çevrim)", "mikro-ohmmetre", k_direnc["ok"] is not False)
        else:
            ur = num(p, "u_rutin_ag", 3.5)
            an += ["0,6/1 kV kablonun fabrika rutin deneyleri ikidir: iletken direnci ve gerilim deneyi. Tip deneylerinde ayrıca ortam ve çalışma sıcaklığında yalıtım direnci ile 4 saat süreli gerilim deneyi yapılır.",
                   "Gerilim deneyi: 2,5·U0 + 2 kV = 3,5 kV (50 Hz), 5 dakika; damarlar arasına ve damar ile (varsa) zırh / eş merkezli iletken arasına. 4 saat süreli tip deneyi 4·U0 = 2,4 kV'tur.",
                   "Sahada AG kablosuna yüksek gerilim deneyi yapılmaz; döşendikten sonra yalıtım direnci, süreklilik ve faz sırası denetlenir."]
            kt += [k_direnc, C("Rutin gerilim deneyi", f"{fnum(ur, 1)} kV, 5 dk", "2,5·U0 + 2 kV = 3,5 kV (a.a.), 5 dakika, delinme yok", abs(ur - 3.5) <= 0.1, "TEDAŞ-MLZ/96-015.A m.4.2 (rutin: gerilim deneyi) — değer: TS IEC 60502-1 m.15.3", D)]
            sema = _sema(False, "megger", f"{fnum(ur, 1)} kV · 5 dk", "deney trafosu", all(k["ok"] is not False for k in kt))
        ds = ["AG kablosunda saha denetimi üç şeydir: yalıtım direnci (damarlar arası ve toprağa), süreklilik / iletken direnci, faz sırası ve işaretleme.",
              "Megger takılmadan önce kablonun iki ucu da ayrılır: bağlı kalan bir cihaz, sayaç ya da parafudr düşük değer gösterir; elektronik cihazlar 500 V'tan zarar görür.",
              "Düşük yalıtım direnci çoğu kez kablonun değil, uçların sorunudur: nemli pano, yalıtımı soyulmuş ve birbirine yakın damarlar, su almış ek kutusu.",
              "Paralel çekilen kablolarda her kablo ayrı ölçülür; uzunluk ve kesit eşit değilse akım eşit bölünmez — iletken dirençlerinin birbirine yakın olması bunun denetimidir.",
              "Değerler sıcaklıkla birlikte yazılır: PVC'de yalıtım direnci her 10 °C'de yaklaşık yarıya iner."]
        tab.append({"baslik": "0,6/1 kV AG kablosu — şartnamedeki deneyler", "cols": ["Tür", "Deney", "Değer / ölçüt", "Dayanak", "Durum"],
                    "rows": [["Rutin", "İletkenlerin elektriksel direnci", f"≤ {fnum(r20_max, 4)} Ω/km (20 °C)", "TEDAŞ-MLZ/96-015.A m.4.2; TS EN 60228", "resmi / dogrulanacak"], ["Rutin", "Gerilim deneyi", "3,5 kV a.a., 5 dk", "TEDAŞ-MLZ/96-015.A m.4.2; TS IEC 60502-1 m.15.3", "resmi (deney) / dogrulanacak (değer)"],
                             ["Tip", "Ortam sıcaklığında yalıtım direnci", f"Ki ≥ {fnum(KI[yal], 1 if yal == 'pvc' else 0)} MΩ·km (20 °C)", "TEDAŞ-MLZ/96-015.A m.4.1.1; TS IEC 60502-1 m.17.1", "resmi / dogrulanacak"],
                             ["Tip", "En büyük iletken sıcaklığında yalıtım direnci", "Ki ≥ " + ("3,67" if yal == "xlpe" else "0,037") + " MΩ·km", "TEDAŞ-MLZ/96-015.A m.4.1.1; TS IEC 60502-1 m.17.2", "resmi / dogrulanacak"],
                             ["Tip", "4 saat süreli gerilim deneyi", "4·U0 = 2,4 kV", "TEDAŞ-MLZ/96-015.A m.4.1.1; TS IEC 60502-1 m.17.3", "resmi / dogrulanacak"],
                             ["Saha", "Yalıtım direnci", "500 V d.a. ile ≥ 0,5 MΩ", "Topraklamalar Yön. m.10, Çizelge-9", "resmi"], ["Saha", "Koruma iletkeni sürekliliği", "≥ 0,2 A, 4 – 24 V kaynak", "Topraklamalar Yön. m.10-2", "resmi"]]})
        oz = [K("Beklenen yalıtım direnci", f"{fnum(rmin, 1)} MΩ", "info", f"{fnum(L, 0)} m, 20 °C"), K("İletken direnci sınırı", f"{fnum(r20_max, 4)} Ω/km", "info", f"{kes} mm² {'Cu' if ilet == 'cu' else 'Al'}"),
              K("Deney", DAG[deney].split(" (")[0], "info", ""), K("Sonuç", "uygun" if all(k["ok"] is not False for k in kt) else "uygun değil", "ok" if all(k["ok"] is not False for k in kt) else "bad", f"{sum(1 for k in kt if k['ok'] is False)} kırmızı satır")]
    sema.yazi(450, 308, " · ".join(k["ad"] + (": ✓" if k["ok"] else ": ✗" if k["ok"] is False else ": bilgi") for k in kt)[:118], "ok" if all(k["ok"] is not False for k in kt) else "ariza", 11, True, "middle")
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sema.sahne(), "grafikler": graf, "tablolar": tab}
