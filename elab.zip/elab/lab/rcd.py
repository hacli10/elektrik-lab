"""Laboratuvar konusu — kaçak akım rölesi (artık akım koruma düzeni, RCD): çalışma ilkesi, tip seçimi, seçicilik, istenmeyen açma, test.

Model: röle, içinden geçen iletkenlerin akımlarının anlık toplamını (artık akım) ölçer. Tip, hangi dalga biçimini algılayabildiğini belirler;
düz doğru akım bileşeni tip AC/A/F çekirdeğini doyurup duyarlılığı düşürür (körleşme)."""
from __future__ import annotations

import math

from .core import C, K, ctl, fnum, fsure, num, opt, rcd_sure, rules, vucut_akimi, etki

ID = "rcd"
BASLIK = "Kaçak akım rölesi"
IKON = "🛡"
GIRIS = ("Rölenin içinden geçen akımların toplamı sıfır değilse bir yerde kaçak vardır. Yükü, rölenin tipini ve eşiğini seçin; rölenin arızayı görüp görmediğini, "
         "ne kadar sürede açtığını, üst röleyle seçiciliğini, boşta kaçak yüzünden gereksiz açıp açmayacağını ve test cihazında ne okumanız gerektiğini görün.")
SIRA = ["AC", "A", "F", "B"]
BICIM = {"ac": "Sinüs biçimli alternatif akım (50 Hz)", "darbeli": "Darbeli doğru akım (yarım dalga doğrultulmuş)", "karma": "Karma frekanslı (50 Hz + sürücü çıkış frekansı)", "duz_dc": "Düz doğru akım (DC bara arızası)"}
ALGI = {"AC": ("ac",), "A": ("ac", "darbeli"), "F": ("ac", "darbeli", "karma"), "B": ("ac", "darbeli", "karma", "duz_dc")}


def _yukler() -> dict:
    return rules()["rcd"]["yukler"]


KONTROLLER = [
    ctl("yuk", "Korunan yük", "sec", "direncli", secenek=opt(*[(k, v["ad"]) for k, v in rules()["rcd"]["yukler"].items()])),
    ctl("tip", "Röle tipi", "sec", "AC", secenek=opt(("AC", "AC — yalnız sinüs"), ("A", "A — sinüs + darbeli DC"), ("F", "F — A + karma frekans"), ("B", "B — hepsi + düz DC"))),
    ctl("rdc_dd", "6 mA DC algılama düzeni var (şarj ünitesinde)", "onay", False, goster={"yuk": ["ev_sarj"]}),
    ctl("idn_ma", "Anma artık akımı IΔn", "sec", 30, secenek=opt(*[(v, f"{v} mA") for v in (10, 30, 100, 300, 500)])),
    ctl("s_tipi", "Seçici (S) tip", "onay", False, goster={"idn_ma": [100, 300, 500]}),
    ctl("n_cihaz", "Bu rölenin arkasındaki cihaz sayısı", "sayi", 4, min=1, max=60, adim=1, birim="adet"),
    ctl("kacak_ma", "Cihaz başına boşta kaçak akım", "sayi", 0, min=0, max=50, adim=0.5, birim="mA", yardim="0 bırakılırsa yük tipinin tipik değeri alınır (üretici verisi esastır)"),
    ctl("ariza_ma", "Arıza (ya da test) akımı", "sayi", 60, min=0, max=3000, adim=5, birim="mA"),
    ctl("bicim", "Arıza akımının biçimi", "sec", "ac", secenek=opt(*BICIM.items())),
    ctl("dc_ma", "Devrede sürekli düz DC kaçak bileşeni", "sayi", 0, min=0, max=200, adim=1, birim="mA", yardim="Sürücü, EV şarj, PV evirici arızasında oluşur; tip AC/A/F çekirdeğini doyurur"),
    ctl("sistem", "Şebeke sistemi", "sec", "TN-S", secenek=opt(("TN-S", "TN-S / TN-C-S"), ("TT", "TT"))),
    ctl("ra_ohm", "Topraklama direnci RA", "sayi", 50, min=0.5, max=5000, adim=5, birim="Ω", goster={"sistem": ["TT"]}),
    ctl("ust_idn_ma", "Üst kademedeki röle", "sec", 0, secenek=opt((0, "yok"), (100, "100 mA"), (300, "300 mA"), (500, "500 mA"))),
    ctl("ust_s", "Üst röle seçici (S) tip", "onay", True, goster={"ust_idn_ma": [100, 300, 500]}),
]


def _dalga(bicim: str, n: int = 80) -> list:
    """Artık akımın bir periyotluk örnek dalga biçimi (birim tepe)."""
    out = []
    for k in range(n + 1):
        th = 2 * math.pi * k / n
        if bicim == "ac":
            y = math.sin(th)
        elif bicim == "darbeli":
            y = max(0.0, math.sin(th))
        elif bicim == "karma":
            y = 0.6 * math.sin(th) + 0.4 * math.sin(7.3 * th + 0.6)
        else:
            y = 0.9 + 0.05 * math.sin(6 * th)
        out.append([round(k / n * 20, 2), round(y, 3)])
    return out


def _egri(idn: float, s: bool) -> list:
    """Açma süresi – akım katı basamak eğrisi (en geç açma)."""
    r = rules()["rcd"]["acma_suresi"]; tab = r["S_max"] if s else r["genel"]
    pts = []
    for k0, k1, t in ((1, 2, tab["1"]), (2, 5, tab["2"]), (5, 100, tab["5"])):
        pts += [[k0 * idn, t * 1000], [k1 * idn, t * 1000]]
    return pts


def run(p: dict) -> dict:
    R = rules()["rcd"]
    yk = p.get("yuk") if p.get("yuk") in _yukler() else "direncli"
    Y = _yukler()[yk]
    tip = p.get("tip") if p.get("tip") in SIRA else "AC"
    idn = num(p, "idn_ma", 30); s = bool(p.get("s_tipi")) and idn >= 100
    n = int(num(p, "n_cihaz", 4)); kc = num(p, "kacak_ma", 0) or Y["kacak_ma"]
    ariza = num(p, "ariza_ma", 60); bicim = p.get("bicim") if p.get("bicim") in BICIM else "ac"
    dc = num(p, "dc_ma", 0)
    sistem = "TT" if p.get("sistem") == "TT" else "TN-S"; ra = num(p, "ra_ohm", 50)
    ust = num(p, "ust_idn_ma", 0); ust_s = bool(p.get("ust_s", True)) and ust > 0
    T = R["tipler"]
    kt, an, ds = [], [], []

    # 1) tip uygun mu
    gerek = Y["gerekli"]
    tip_ok = SIRA.index(tip) >= SIRA.index(gerek) or (yk == "ev_sarj" and tip in ("A", "F") and bool(p.get("rdc_dd")))
    kt.append(C("Röle tipi yüke uygun mu", f"tip {tip}", f"en az tip {gerek}" + (f" (ya da {Y['alternatif']})" if Y.get("alternatif") else ""), tip_ok, R["tip_kaynak"], R["tip_durum"]))
    # 2) algılama ve körleşme
    algilar = bicim in ALGI[tip]
    kor = dc > T[tip]["dc_tolerans_ma"]
    kacak_top = n * kc
    art = ariza + (0 if bicim == "duz_dc" else 0)            # artık akım: arıza akımı (boşta kaçak ayrıca değerlendirilir)
    t = rcd_sure(idn, art, s) if (algilar and not kor) else math.inf
    belirsiz = algilar and not kor and 0.5 * idn <= art < idn
    an.append("Röle bir akım trafosudur: faz ve nötr (üç fazlıda dört iletken) aynı çekirdeğin içinden geçer. Sağlam devrede giden akım dönen akıma eşittir, manyetik akılar birbirini götürür, sargıda gerilim oluşmaz.")
    an.append(f"Arıza: {fnum(ariza, 0)} mA, yükten sonra gövdeye/toprağa kaçıyor ve rölenin içinden geçmeden dönüyor. Çekirdek {fnum(ariza, 0)} mA'lik farkı görür ({fnum(ariza / idn, 1)} × IΔn). Biçimi: {BICIM[bicim].lower()}.")
    if not algilar:
        an.append(f"Tip {tip} bu dalga biçimini algılayamaz ({T[tip]['algilar']}). " + ("Düz doğru akım çekirdekte değişen akı üretmez; sargıda gerilim oluşmaz." if bicim == "duz_dc" else "Çekirdeğin malzemesi ve devresi bu biçime göre tasarlanmamıştır.") + " Röle açmaz.")
    elif kor:
        an.append(f"Devrede {fnum(dc, 0)} mA düz doğru akım bileşeni var. Tip {tip} en çok {fnum(T[tip]['dc_tolerans_ma'], 0)} mA'e dayanır; çekirdek doymuş durumda, alternatif arızayı da göremez (körleşme). Röle açmayabilir.")
    elif math.isinf(t):
        an.append(f"Arıza akımı IΔn'in altında. " + ("0,5·IΔn ile IΔn arası belirsiz bölgedir: röle açabilir de açmayabilir de." if belirsiz else "0,5·IΔn'in altında röle açmamalıdır (gereksiz açmayı önlemek için)."))
    else:
        an.append(f"Röle arızayı görür ve en geç {fsure(t)} içinde açar ({'S tipi: bilerek gecikmeli' if s else 'genel tip: gecikmesiz'}).")
    kt.append(C("Arıza akımının biçimini algılar mı", f"{BICIM[bicim].split(' (')[0]} → tip {tip} " + ("algılar" if algilar else "algılamaz"), T[tip]["algilar"], algilar, R["tip_kaynak"], R["tip_durum"]))
    kt.append(C("Düz DC bileşene dayanım (körleşme)", f"{fnum(dc, 0)} mA DC", "tip B: sınırsız" if tip == "B" else f"≤ {fnum(T[tip]['dc_tolerans_ma'], 0)} mA", not kor, R["tip_kaynak"], R["tip_durum"]))
    lim_t = (R["acma_suresi"]["S_max"] if s else R["acma_suresi"]["genel"])
    if art >= idn:
        kt.append(C("Açma süresi", fsure(t), f"≤ {fsure(lim_t['5'] if art >= 5 * idn else lim_t['2'] if art >= 2 * idn else lim_t['1'])}  ({fnum(art / idn, 1)} × IΔn)", not math.isinf(t), R["acma_suresi"]["kaynak"], R["acma_suresi"]["durum"]))
    # 3) boşta kaçak (istenmeyen açma)
    pay = R["kacak_payi"]["deger"]
    kt.append(C("Boşta kaçak akımların toplamı", f"{n} × {fnum(kc, 1)} mA = {fnum(kacak_top, 1)} mA", f"≤ {fnum(pay, 1)} · IΔn = {fnum(pay * idn, 0)} mA", kacak_top <= pay * idn + 1e-9, R["kacak_payi"]["kaynak"], R["kacak_payi"]["durum"]))
    if kacak_top > pay * idn:
        an.append(f"Arıza olmasa bile cihazların filtre kondansatörlerinden {fnum(kacak_top, 0)} mA sürekli kaçak akıyor ({fnum(kacak_top / idn * 100, 0)} % IΔn). " +
                  ("Röle 0,5·IΔn'den sonra açabildiği için sebepsiz açmalar beklenir." if kacak_top >= 0.5 * idn else "Açma eşiğine yakın: ilk çalıştırma darbesinde ya da nemli havada açar.") +
                  " Çare: devreleri birden çok röleye bölmek ya da (can güvenliği devresi değilse) eşiği büyütmek.")
    # 4) TT
    if sistem == "TT":
        lim = 50.0 / (idn / 1000.0) / (2 if s else 1)
        kt.append(C("TT: topraklama direnci", f"RA = {fnum(ra, 0)} Ω → RA · IΔn = {fnum(ra * idn / 1000, 1)} V", f"RA ≤ {fnum(lim, 0)} Ω  (50 V / {'2·' if s else ''}IΔn)", ra <= lim + 1e-9, R["ra_max"]["kaynak"], R["ra_max"]["durum"]))
        an.append(f"TT'de arıza akımı küçük olduğundan koruma yalnız bu röleye bağlıdır: RA = {fnum(ra, 0)} Ω iken gövde gerilimi rölenin açma eşiğinde {fnum(ra * idn / 1000, 1)} V olur (sınır 50 V).")
    # 5) seçicilik
    secici = None
    if ust:
        oran = R["secicilik"]["oran"]
        kural = ust_s and ust >= oran * idn
        kt.append(C("Üst röleyle seçicilik", f"üst {fnum(ust, 0)} mA{' S' if ust_s else ' genel tip'} / alt {fnum(idn, 0)} mA{' S' if s else ''}", f"üst S tipi ve IΔn(üst) ≥ {oran} × IΔn(alt)", kural, R["secicilik"]["kaynak"], R["secicilik"]["durum"]))
        t_ust_max = rcd_sure(ust, art, ust_s)
        if art < ust:
            secici = True; an.append(f"Üst röle ({fnum(ust, 0)} mA) bu arızayı görmez (akım kendi eşiğinin altında): yalnız alt röle açar.")
        elif math.isinf(t):
            secici = False; an.append(f"Alt röle açmadığı için arızayı üst röle ({fnum(ust, 0)} mA) temizler: en geç {fsure(t_ust_max)}. Bütün pano enerjisiz kalır.")
        else:
            k = art / ust
            tmin = (R["acma_suresi"]["S_min"]["5"] if k >= 5 else R["acma_suresi"]["S_min"]["2"] if k >= 2 else R["acma_suresi"]["S_min"]["1"]) if ust_s else 0.0
            secici = tmin > t
            an.append((f"Üst röle S tipidir: bu akımda en az {fsure(tmin)} bekler; alt röle {fsure(t)} içinde açtığı için üst röle açmaz (seçicilik var)." if secici
                       else "İki röle de genel tiptir ve ikisi de arızayı görür: hangisinin önce açacağı belli değildir, çoğu zaman ikisi birden açar (seçicilik yok)." if not ust_s
                       else f"Üst röle en az {fsure(tmin)} bekler ama alt röle {fsure(t)} içinde açıyor: seçicilik sınırda."))
    # 6) kişi (doğrudan temas: 30 mA ek koruma)
    i_b, _ = vucut_akimi(230.0, 0.0)
    d_k, e_k = etki(i_b, rcd_sure(idn, i_b * 1000, s))
    kt.append(C("Ek koruma (doğrudan temas)", f"IΔn = {fnum(idn, 0)} mA" + ("" if idn <= 30 else " — ek koruma sağlamaz; yangın / dolaylı temas koruması içindir"), "≤ 30 mA  (prizler ≤ 32 A, ıslak hacimler)", True if idn <= 30 else None, rules_ic()["kaynak"], rules_ic()["durum"]))
    ds += ["Röle “toprağa akan akımı” değil, giden ile dönen akımın farkını ölçer. Fark hangi yoldan kaçarsa kaçsın (PE, su borusu, insan) açar; kaçak yoksa (faz–nötr kısa devresi, aşırı yük) açmaz.",
           "Tip seçimi akımın büyüklüğüyle değil biçimiyle ilgilidir: elektronik yük varsa tip AC yetersizdir; düz DC olasılığı varsa (üç fazlı sürücü, araç şarjı, trafosuz evirici) tip B gerekir.",
           "30 mA can güvenliği (ek koruma), 300 mA yangın koruması içindir. 300 mA röle insanı doğrudan temasta korumaz.",
           "Seçicilik için üstteki röle S tipi ve en az 3 kat büyük olmalıdır; iki genel tip röle seri bağlanırsa ikisi birden açar.",
           "Test düğmesi yalnız mekanizmanın çalıştığını gösterir; açma akımı ve süresi test cihazıyla ölçülür."]
    # test çizelgesi
    r_t = R["acma_suresi"]
    test = {"baslik": f"Test cihazında beklenen sonuçlar — {fnum(idn, 0)} mA {'S tipi' if s else 'genel tip'}", "cols": ["Test", "Uygulanan akım", "Beklenen", "Neden"], "rows": [
        ["½ × IΔn", f"{fnum(idn / 2, 0)} mA", "açmamalı", "Gereksiz açmaya karşı: röle 0,5·IΔn altında çalışmamalı"],
        ["1 × IΔn", f"{fnum(idn, 0)} mA", (f"{fnum(r_t['S_min']['1'] * 1000, 0)} – {fnum(r_t['S_max']['1'] * 1000, 0)} ms" if s else f"≤ {fnum(r_t['genel']['1'] * 1000, 0)} ms"), "Anma akımında en geç açma süresi"],
        ["5 × IΔn", f"{fnum(5 * idn, 0)} mA", (f"{fnum(r_t['S_min']['5'] * 1000, 0)} – {fnum(r_t['S_max']['5'] * 1000, 0)} ms" if s else f"≤ {fnum(r_t['genel']['5'] * 1000, 0)} ms"), "Can güvenliği: 30 mA rölede 150 mA'de 40 ms"],
        ["Rampa (artan akım)", f"{fnum(idn / 2, 0)} → {fnum(idn, 0)} mA", f"açma akımı {fnum(idn / 2, 0)} – {fnum(idn, 0)} mA arasında", "Gerçek açma eşiği; boşta kaçak varsa ölçülen değer düşük çıkar"],
        ["Test düğmesi (T)", "iç direnç üzerinden", "açmalı", "Yalnız mekanik kontrol; 6 ayda bir (üretici önerisi)"]],
        "not": f"{r_t['kaynak']} — durum: {r_t['durum']}. Tip A'da darbeli DC ile açma akımı 0,35 – 1,4·IΔn, tip B'de düz DC ile 0,5 – 2·IΔn aralığındadır (TS EN 61008-1, TS EN 62423 — dogrulanacak)."}
    tipler = {"baslik": "Röle tipleri — neyi algılar?", "cols": ["Tip", "Algıladığı kaçak akım", "Düz DC dayanımı", "Tipik kullanım"],
              "rows": [[k, v["algilar"], "sınırsız" if k == "B" else f"{fnum(v['dc_tolerans_ma'], 0)} mA", v["not"]] for k, v in T.items()], "not": f"{R['tip_kaynak']} — durum: {R['tip_durum']}"}
    yukler = {"baslik": "Yüke göre en az hangi tip?", "cols": ["Yük", "En az", "Neden"], "rows": [[v["ad"], "tip " + v["gerekli"] + (f" / {v['alternatif']}" if v.get("alternatif") else ""), v["neden"]] for v in _yukler().values()],
              "not": f"TS HD 60364-5-53 m.531.3.3; -7-712; -7-722 — durum: {R['tip_durum']}. Cihaz başına kaçak akımlar: {R['yuk_durum']}"}
    acti = not math.isinf(t)
    oz = [K("Artık (fark) akım", f"{fnum(ariza, 0)} mA", "info", f"{fnum(ariza / idn, 1)} × IΔn"), K("Röle", "açar" if acti else ("belirsiz" if belirsiz else "açmaz"), "ok" if acti else ("warn" if belirsiz else "bad"), fsure(t) if acti else ("algılamaz" if not algilar else "körleşti" if kor else "eşiğin altında")),
          K("Tip uygunluğu", f"tip {tip}", "ok" if tip_ok else "bad", f"gereken: en az {gerek}"), K("Boşta kaçak", f"{fnum(kacak_top, 1)} mA", "ok" if kacak_top <= pay * idn else ("bad" if kacak_top >= 0.5 * idn else "warn"), f"{fnum(kacak_top / idn * 100, 0)} % IΔn")]
    if ust:
        oz.append(K("Seçicilik", "var" if secici else "yok", "ok" if secici else "bad", f"üst {fnum(ust, 0)} mA{' S' if ust_s else ''}"))
    seriler = [{"ad": f"alt: {fnum(idn, 0)} mA{' S' if s else ''}", "renk": "#1a4d8f", "pts": _egri(idn, s)}]
    if ust:
        seriler.append({"ad": f"üst: {fnum(ust, 0)} mA{' S' if ust_s else ''}", "renk": "#b45309", "pts": _egri(ust, ust_s)})
        if ust_s:
            sm = R["acma_suresi"]["S_min"]
            seriler.append({"ad": "üst S: en erken açma", "renk": "#b45309", "kesik": True, "pts": [[ust, sm["1"] * 1000], [2 * ust, sm["1"] * 1000], [2 * ust, sm["2"] * 1000], [5 * ust, sm["2"] * 1000], [5 * ust, sm["5"] * 1000], [100 * ust, sm["5"] * 1000]]})
    graf = [{"baslik": "Açma süresi – artık akım", "x_ad": "artık akım (mA)", "y_ad": "en geç açma süresi (ms)", "logx": True, "logy": True, "seriler": seriler,
             "isaretler": [{"x": max(ariza, 1), "etiket": f"arıza {fnum(ariza, 0)} mA"}]}]
    sahne = {"tip": "rcd", "tip_rcd": tip, "idn": idn, "s": s, "ariza_ma": ariza, "bicim": bicim, "dalga": _dalga(bicim), "algilar": algilar, "kor": kor, "acti": acti, "belirsiz": belirsiz, "t": fsure(t),
             "kacak_ma": round(kacak_top, 1), "dc_ma": dc, "yuk": Y["ad"], "ust": {"var": ust > 0, "idn": ust, "s": ust_s, "acti": bool(ust and art >= ust and not secici)}}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "grafikler": graf, "tablolar": [test, tipler, yukler]}


def rules_ic() -> dict:
    from .core import ruleset
    return ruleset().ictesisler["rcd"]
