"""Laboratuvar konusu — akım trafosu: ölçme ve koruma sınıfları, yük (bürden), doyma, sekonderin açık kalması.

Gerçek doğruluk sınır katsayısı (koruma) ya da emniyet katsayısı (ölçme), bağlı yüke göre değişir:
    n′ = n · (Sn + Rct·Is²) / (Sb + Rct·Is²)        (n: ALF ya da FS, Sn: anma gücü, Sb: bağlı yük, Rct: sekonder sargı direnci)
Primer akım n′ · In'i geçince çekirdek doyar: sekonder akım primeri izleyemez. Diz gerilimi yaklaşık Vk ≈ n · Is · (Rct + Sn/Is²).
Dayanak: TS EN 61869-2; TEDAŞ-MLZ/96-010.B; TEDAŞ-MLZ/95-007.E (hücrelerdeki akım trafoları)."""
from __future__ import annotations

import math

from . import zaman
from .cizim import Cizim
from .core import C, K, RHO_CU, ctl, fnum, num, opt

ID = "at"
BASLIK = "Akım trafosu"
IKON = "🧲"
GIRIS = ("Akım trafosunun sınıfı ne için kullanılacağını söyler: ölçme çekirdeği kısa devrede doyup sayacı korumalı, koruma çekirdeği ise doymadan röleye doğru akımı vermelidir. "
         "Sınıfı, yükü ve primer akımı değiştirin; doymayı, hatayı ve sekonder açık kalırsa ne olduğunu görün.")
# sınıf: (tür, n = FS ya da ALF, oran hatası sınırı anma akımında %, bileşik hata %)
SINIF = {"0.2S FS5": ("olcme", 5, 0.2, None), "0.5 FS5": ("olcme", 5, 0.5, None), "0.5S FS5": ("olcme", 5, 0.5, None), "1 FS5": ("olcme", 5, 1.0, None), "1 FS10": ("olcme", 10, 1.0, None),
         "5P10": ("koruma", 10, 1.0, 5.0), "5P20": ("koruma", 20, 1.0, 5.0), "10P10": ("koruma", 10, 3.0, 10.0)}
# ölçme sınıflarında oran hatası sınırları: anma akımının yüzdesine göre (%)
HATA = {"0.2": [(5, 0.75), (20, 0.35), (100, 0.2), (120, 0.2)], "0.5": [(5, 1.5), (20, 0.75), (100, 0.5), (120, 0.5)], "1": [(5, 3.0), (20, 1.5), (100, 1.0), (120, 1.0)],
        "0.2S": [(1, 0.75), (5, 0.35), (20, 0.2), (100, 0.2), (120, 0.2)], "0.5S": [(1, 1.5), (5, 0.75), (20, 0.5), (100, 0.5), (120, 0.5)]}
D = "dogrulanacak"

KONTROLLER = [
    ctl("gorev", "Çekirdeğin bağlandığı devre", "sec", "koruma", secenek=opt(("olcme", "Ölçme (sayaç, analizör, ampermetre)"), ("koruma", "Koruma (röle)"))),
    ctl("sinif", "Çekirdeğin sınıfı", "sec", "5P10", secenek=opt(*[(k, k) for k in SINIF])),
    ctl("ip_a", "Primer anma akımı", "sec", 100, secenek=opt(*[(v, f"{v} A") for v in (20, 30, 50, 75, 100, 150, 200, 300, 400, 600, 800, 1000, 1250)])),
    ctl("is_a", "Sekonder anma akımı", "sec", 5, secenek=opt((5, "5 A"), (1, "1 A"))),
    ctl("sn_va", "Anma gücü", "sec", 15, secenek=opt(*[(v, f"{v:g} VA") for v in (2.5, 5, 10, 15, 30)])),
    ctl("rct", "Sekonder sargı direnci Rct", "sayi", 0.3, min=0.05, max=10, adim=0.05, birim="Ω"),
    ctl("l_m", "Sekonder kablo uzunluğu (tek yön)", "sayi", 15, min=1, max=300, adim=1, birim="m"),
    ctl("s_mm2", "Sekonder kablo kesiti", "sec", 2.5, secenek=opt((1.5, "1,5 mm²"), (2.5, "2,5 mm²"), (4, "4 mm²"), (6, "6 mm²"), (10, "10 mm²"))),
    ctl("cihaz_va", "Bağlı cihazların tüketimi (anma akımında)", "sayi", 1.0, min=0.05, max=30, adim=0.05, birim="VA", yardim="Sayısal röle / sayaç: 0,1–0,5 VA; eski elektromekanik röle: 5–15 VA"),
    ctl("kat", "Primer akım (anma akımının katı)", "sayi", 1, min=0.01, max=40, adim=0.01, yardim="işletme: 0,05–1,2 · kısa devre: 5–40"),
    ctl("dc", "Arıza akımının biçimi", "sec", "sim", secenek=opt(("sim", "Simetrik (doğru akım bileşeni yok)"), ("dc", "Tam doğru akım bileşenli (arıza gerilimin sıfır geçişinde başlıyor)")), yardim="kısa devrenin ilk periyotlarında akım, sönen bir doğru akım bileşeni taşır"),
    ctl("xr", "Şebekenin X/R oranı (arıza yerinde)", "sayi", 10, min=2, max=40, adim=1, goster={"dc": ["dc"]}, yardim="doğru akım bileşeninin zaman sabiti T1 = (X/R)/ω : X/R 10 → 32 ms ; 20 → 64 ms"),
    ctl("rem", "Çekirdekte kalıcı akı (remanans)", "sayi", 0, min=0, max=80, adim=5, birim="%", goster={"dc": ["dc"]}, yardim="önceki arızadan ya da d.a. ile yapılan ölçümden kalan mıknatıslanma"),
    ctl("acik", "Sekonder devre açık (klemens gevşek, kablo kopuk, cihaz sökülmüş)", "onay", False),
]


def hata_siniri(sinif: str, yuzde: float) -> float | None:
    tab = HATA.get(sinif.split()[0])
    if not tab:
        return None
    if yuzde < tab[0][0]:
        return None
    for a, e in tab:
        if yuzde <= a:
            return e
    return tab[-1][1] if yuzde <= 120 else None


def run(p: dict) -> dict:
    sn_ad = p.get("sinif") if p.get("sinif") in SINIF else "5P10"
    tur, n, e_oran, e_bil = SINIF[sn_ad]
    gorev = "olcme" if p.get("gorev") == "olcme" else "koruma"
    ip = num(p, "ip_a", 100); is_ = num(p, "is_a", 5); sn = num(p, "sn_va", 15); rct = num(p, "rct", 0.3)
    r_kablo = 2 * RHO_CU * num(p, "l_m", 15) / num(p, "s_mm2", 2.5)
    sb = is_ ** 2 * r_kablo + num(p, "cihaz_va", 1.0)
    n_g = n * (sn + rct * is_ ** 2) / (sb + rct * is_ ** 2)
    kat = num(p, "kat", 1); acik = bool(p.get("acik"))
    doymus = kat > n_g
    vk = n * is_ * (rct + sn / is_ ** 2)
    # zaman bölgesi çözümü: doymaya giren mıknatıslanma kolu ile sekonder devre
    dc = p.get("dc") == "dc"; xr = num(p, "xr", 10) if dc else 0.0; rem = num(p, "rem", 0) / 100 if dc else 0.0
    r2 = rct + sb / is_ ** 2
    rc_kayip = vk / (0.02 * n * is_)                       # çekirdek kayıp direnci (açık devrede gerilimi sınırlayan) — tahmini
    S = zaman.at_sim(round(kat * is_, 4), round(r2, 5), round(vk, 4), round(n * is_, 4), float(xr), float(rem), acik, round(rc_kayip, 4))
    i_sek = S["oran"][-1] * kat * is_                      # sürekli rejimde rölenin / sayacın gördüğü temel bileşen
    t_doy = S["t_doy"]
    k_td = 1 + xr                                          # tam DC bileşende doymamak için gereken büyütme: 1 + ω·T1 = 1 + X/R
    an = [f"Çekirdek {sn_ad}, {fnum(ip, 0)}/{fnum(is_, 0)} A, {fnum(sn, 1)} VA. Bağlı yük: kablo 2 × {fnum(num(p, 'l_m', 15), 0)} m × {fnum(num(p, 's_mm2', 2.5), 1)} mm² = {fnum(r_kablo, 3)} Ω → {fnum(is_ ** 2 * r_kablo, 2)} VA, cihazlar {fnum(num(p, 'cihaz_va', 1.0), 2)} VA; toplam Sb = {fnum(sb, 2)} VA (anma gücünün %{fnum(sb / sn * 100, 0)}'i).",
          f"Etikette yazan {'emniyet katsayısı FS' if tur == 'olcme' else 'doğruluk sınır katsayısı ALF'} = {n}, anma yükü içindir. Gerçek yükte: n′ = n · (Sn + Rct·Is²) / (Sb + Rct·Is²) = {fnum(n_g, 1)}. Çekirdek primer akım {fnum(n_g, 1)} × In = {fnum(n_g * ip, 0)} A'i geçince doyar."]
    kt = []
    if acik:
        an += ["Sekonder devre açık. Akım trafosu bir akım kaynağıdır: primerden geçen akımın amper-sarımını dengeleyecek sekonder akım akamayınca primer akımın tamamı çekirdeği mıknatıslar.",
               f"Çekirdek her yarım periyotta derin doymaya girer; akının yön değiştirdiği kısa anlarda sekonder uçlarında çok dik gerilim darbeleri oluşur. Diz gerilimi {fnum(vk, 0)} V olan bu çekirdekte hesaplanan tepe değer ≈ {fnum(S['u_tepe'], 0)} V; primer akım büyüdükçe ve çekirdek büyüdükçe kilovoltlara çıkar.",
               "Sonuç: klemenste ark, yalıtım delinmesi, çekirdekte aşırı ısınma ve kalıcı mıknatıslanma (sonraki ölçümler hatalı); dokunan kişi için ölüm tehlikesi. Enerjili primerde sekonder devre asla açılmaz: önce kısa devre klemensi kapatılır."]
        kt.append(C("Sekonder devrenin sürekliliği", "açık devre", "sekonder hiçbir zaman açık bırakılmaz; kullanılmayan çekirdekler kısa devre edilir ve topraklanır", False, "TS EN 61869-2; Elektrik Kuvvetli Akım Tesisleri Yön. (ölçü trafoları sekonder devreleri)", D))
    else:
        an.append(f"Primer akım {fnum(kat, 2)} × In = {fnum(kat * ip, 0)} A. " + (f"Çekirdek her yarım periyodun sonunda doyuyor: sekonder akım kırpılır; rölenin ölçtüğü temel bileşen {fnum(kat * is_, 1)} A yerine ≈ {fnum(i_sek, 1)} A." if doymus else f"Çekirdek doğrusal bölgede: sekonder akım {fnum(i_sek, 2)} A."))
        if dc:
            an.append(f"Arıza gerilimin sıfır geçişinde başlarsa akım tam doğru akım bileşeni taşır; bu bileşen T1 = (X/R)/ω = {fnum(xr / (2 * math.pi * 50) * 1000, 0)} ms zaman sabitiyle söner. Doğru akım bileşeni çekirdekte akıyı tek yönde biriktirir: doymamak için çekirdeğin simetrik duruma göre "
                      f"1 + X/R = {fnum(k_td, 0)} kat büyük olması gerekir (üst sınır; sekonder çevrimin zaman sabiti kısaldıkça azalır, kalıcı akı varsa artar). Bu çekirdek için gereken n′ = {fnum(kat * k_td / max(1e-9, 1 - rem), 0)}, mevcut n′ = {fnum(n_g, 1)}.")
            an.append((f"Zaman bölgesi çözümü: çekirdek arızanın {fnum(t_doy, 1)}. milisaniyesinde doyuyor. Periyot periyot rölenin gördüğü temel bileşen (gerçek akımın yüzdesi): " + " · ".join(f"{j + 1}. %{fnum(o * 100, 0)}" for j, o in enumerate(S["oran"])) + ". Doğru akım bileşeni söndükçe çekirdek doymadan çıkar.")
                      if t_doy is not None else "Zaman bölgesi çözümü: çekirdek doğru akım bileşenine rağmen doymuyor; sekonder akım primeri bütün süre boyunca izliyor.")
    # yük
    kt.append(C("Bağlı yük (bürden)", f"Sb = {fnum(sb, 2)} VA = %{fnum(sb / sn * 100, 0)} Sn", "≤ anma gücü" + (" ; ölçme sınıfında doğruluk %25 – %100 Sn arasında garanti edilir" if tur == "olcme" else ""), sb <= sn + 1e-9 and (tur != "olcme" or sb >= 0.25 * sn - 1e-9),
                "TS EN 61869-2 (doğruluk sınıfları ve yük aralığı)", D))
    # sınıf – görev uyumu
    kt.append(C("Sınıfın göreve uygunluğu", f"{sn_ad} çekirdek, {'ölçme' if gorev == 'olcme' else 'koruma'} devresinde", "ölçme devresine ölçme sınıfı (0,2S – 1, FS5/10); koruma devresine koruma sınıfı (5P, 10P)", tur == gorev,
                "TEDAŞ-MLZ/95-007.E m.2.2 (hücre akım trafoları: ölçü 0,5 / 0,5S FS5; koruma 5P, 10P, ALF 10–20)", "resmi"))
    if not acik:
        if gorev == "koruma":
            an.append("Koruma çekirdeği arıza akımını doymadan aktarmalıdır; doyarsa röle akımı olduğundan küçük görür: ters zamanlı röle geç açar, ani eleman hiç çalışmayabilir, diferansiyel koruma yanlış açar." if tur == "koruma" else
                      "Ölçme çekirdeği kısa devrede bilerek erken doyar (FS küçük). Röle bu çekirdeğe bağlanırsa arıza akımını göremez.")
            kt.append(C("Arıza akımında doymama", f"primer {fnum(kat, 1)} × In ; çekirdek {fnum(n_g, 1)} × In'e kadar doğrusal", "n′ ≥ arıza akımı / In", not doymus, "TS EN 61869-2 (ALF, bileşik hata)", D))
            if dc and tur == "koruma":
                kt.append(C("Geçici rejimde doyma (doğru akım bileşenli arıza)", ("doymuyor" if t_doy is None else f"{fnum(t_doy, 1)} ms sonra doyuyor ; 2. periyotta röle akımın %{fnum(S['oran'][1] * 100, 0)}'ini görüyor"),
                            f"doymama: n′ ≥ (1 + X/R) × arıza akımı / In = {fnum(kat * k_td, 0)} ; sağlanamıyorsa doymaya kadar geçen süre rölenin karar süresinden uzun olmalı (ani ve diferansiyel elemanlar için ≈ 25 ms)",
                            True if t_doy is None else (None if t_doy >= 25 else False), "TS EN 61869-2 (geçici rejim boyutlandırma katsayısı, TPX / TPY sınıfları); koruma rölesi üreticilerinin akım trafosu koşulları", D))
        else:
            hs = hata_siniri(sn_ad, kat * 100)
            an.append((f"İşletme akımı anma akımının %{fnum(kat * 100, 0)}'i: bu sınıfın oran hatası sınırı ± %{fnum(hs, 2)}." if hs is not None else
                       ("Primer akım sınıfın doğruluk aralığının altında (çok küçük): hata sınırı tanımlı değil; oran çok büyük seçilmiş." if kat < 1.2 else
                        "Primer akım anma akımının %120'sinin üstünde: ölçme doğruluğu garanti edilmez; kısa devrede çekirdeğin doyması ise istenen davranıştır — sekonderdeki sayaç ve ölçü aletleri FS × In'den büyük akım görmez.")))
            if kat <= 1.2:
                kt.append(C("İşletme akımının doğruluk aralığında olması", f"%{fnum(kat * 100, 0)} In", "sınıf 0,2 / 0,5 / 1: %5 – %120 In ; S sınıfları: %1 – %120 In", hs is not None, "TS EN 61869-2 Çizelge 201, 202", D))
            else:
                kt.append(C("Kısa devrede ölçü aletinin korunması", f"gerçek emniyet katsayısı FS′ = {fnum(n_g, 1)}", "FS′ küçük kalmalı (≤ ≈ 10): yük çok küçükse çekirdek geç doyar ve cihaz büyük akım görür", n_g <= 10 + 1e-9 if tur == "olcme" else False, "TS EN 61869-2 (FS)", D))
    ds = ["Ölçme çekirdeği: küçük hata, erken doyma (FS 5). Koruma çekirdeği: kaba hata, geç doyma (ALF 10–20). İkisi aynı gövdede ayrı çekirdeklerdir ve birbirinin yerine kullanılmaz.",
          "Yük küçüldükçe çekirdek daha geç doyar. Koruma için iyidir; ölçme için kötüdür (sayaç kısa devrede daha büyük akım görür). Sayısal cihazlarla yük çok küçük kaldığı için 5 VA yerine 2,5 VA çekirdek seçilir.",
          "Sekonder kablo uzunsa 1 A sekonder seçilir: kablodaki kayıp akımın karesiyle orantılıdır, 5 A'e göre 25 kat küçülür.",
          "“S” sınıfı (0,2S, 0,5S) doğruluğu anma akımının %1'ine kadar garanti eder; yükü geniş aralıkta değişen sayaç devrelerinde bu sınıf kullanılır.",
          "Her sekonder devre tek bir noktadan topraklanır; iki noktadan topraklanırsa toprak potansiyel farkı röleden akım geçirir. Sekonder asla açık bırakılmaz."]
    # dalga biçimi: zaman bölgesi çözümünden
    if acik:
        graf = [{"baslik": "Sekonder uçlarındaki gerilim — sekonder açık", "x_ad": "zaman (ms)", "y_ad": "gerilim (V)", "zaman": True, "seriler": [{"ad": "sekonder uç gerilimi", "renk": "#dc2626", "pts": [[t, round(v, 1)] for t, v in zip(S["t"], S["u"])]}],
                 "yatay": [{"y": math.sqrt(2) * vk, "etiket": f"diz geriliminin tepe değeri {fnum(math.sqrt(2) * vk, 0)} V", "renk": "#64748b"}]}]
    else:
        graf = [{"baslik": "Sekonder akım — zaman bölgesi çözümü", "x_ad": "zaman (ms)", "y_ad": "akım (A)", "zaman": True,
                 "seriler": [{"ad": "olması gereken (primer / oran)", "renk": "#94a3b8", "kesik": True, "pts": [[t, round(v, 2)] for t, v in zip(S["t"], S["ideal"])]},
                             {"ad": "sekonder akım", "renk": "#dc2626" if t_doy is not None else "#15803d", "pts": [[t, round(v, 2)] for t, v in zip(S["t"], S["gercek"])]}],
                 "isaretler": ([{"x": t_doy, "etiket": f"doyma {fnum(t_doy, 1)} ms"}] if t_doy is not None and dc else [])},
                {"baslik": "Çekirdekteki akı", "x_ad": "zaman (ms)", "y_ad": "akı / diz akısı", "zaman": True, "seriler": [{"ad": "akı", "renk": "#7c3aed", "pts": [[t, round(v, 3)] for t, v in zip(S["t"], S["aki"])]}],
                 "yatay": [{"y": 1.0, "etiket": "doyma", "renk": "#dc2626"}, {"y": -1.0, "etiket": "", "renk": "#dc2626"}]}]
        if dc:
            graf.append({"baslik": "Rölenin gördüğü akım (periyot periyot temel bileşen)", "x_ad": "arızadan sonraki periyot", "y_ad": "gerçek akımın yüzdesi (%)", "ymin": 0, "ymax": 110,
                         "seriler": [{"ad": "ölçülen / gerçek", "renk": "#1a4d8f", "pts": [[j + 1, round(o * 100, 1)] for j, o in enumerate(S["oran"])]}], "yatay": [{"y": 100, "etiket": "doymasız", "renk": "#15803d"}]})
    tablo = {"baslik": "Akım trafosu doğruluk sınıfları", "cols": ["Sınıf", "Kullanım", "Oran hatası sınırı", "Doğruluğun geçerli olduğu aralık", "Kısa devrede"], "rows": [
        ["0,2S / 0,5S", "Faturalamaya esas sayaç", "± %0,2 / ± %0,5 (%20 – %120 In)", "%1 In'e kadar (%1'de ± %0,75 / ± %1,5)", "FS 5: 5 × In'de doyar"],
        ["0,2 / 0,5", "Sayaç, hassas ölçme", "± %0,2 / ± %0,5 (%100 – %120 In)", "%5 In'e kadar (%5'te ± %0,75 / ± %1,5)", "FS 5 ya da 10"],
        ["1 / 3", "Ampermetre, gösterge", "± %1 / ± %3", "%5 – %120 In (sınıf 3: %50 – %120)", "FS 5 ya da 10"],
        ["5P10, 5P20", "Aşırı akım, toprak, mesafe, diferansiyel koruma", "± %1 (In'de); bileşik hata ≤ %5", "ALF × In'e kadar (10 ya da 20 kat)", "ALF × In'e kadar doymaz"],
        ["10P10", "Basit aşırı akım koruması", "± %3 (In'de); bileşik hata ≤ %10", "ALF × In'e kadar", "ALF × In'e kadar doymaz"],
        ["PX / PR / TPY", "Yüksek empedanslı diferansiyel, hızlı koruma", "diz gerilimi, mıknatıslanma akımı ve Rct ile tanımlanır", "geçici rejim başarımı", "tasarıma göre"]],
        "not": "TS EN 61869-2 Çizelge 201–205 — durum: dogrulanacak. TEDAŞ-MLZ/95-007.E: ölçü sargısı akım ölçü için 1, enerji ölçü için 0,5 ya da 0,5S, FS 5; koruma sargısı 5P ya da 10P, ALF 10 ya da 20; en az 2,5 VA; sürekli ısıl akım 1,2 × In (resmi)."}
    c = Cizim(900, 300)
    c.hat("M40,90 H860", "L1", hot=True, w=4).yazi(850, 80, f"primer: {fnum(kat * ip, 0)} A ({fnum(kat, 2)} × In)", "ariza", 12, True, "end")
    c.toroid(260, 90, 16, 46, "ariza" if (doymus or acik) else "#1e293b").yazi(234, 158, "çekirdek DOYMUŞ" if (doymus or acik) else "çekirdek", "ariza" if (doymus or acik) else "#334155", 11, True, "end").yazi(234, 174, sn_ad + f" · {fnum(ip, 0)}/{fnum(is_, 0)} A", "#475569", 10.5, False, "end")
    if acik:
        c.hat("M276,60 H520", "cizgi").hat("M276,120 H520", "cizgi").simsek(520, 70, 1.4).yazi(540, 146, "AÇIK UÇLAR — tehlikeli gerilim", "ariza", 13, True).yazi(540, 164, f"diz gerilimi {fnum(vk, 0)} V; darbeler bunun birkaç katı", "ariza", 11)
    else:
        c.hat("M276,60 H620 V200 H276 V120", "cizgi", hot=True, hot_renk="ok" if not doymus else "ariza").direnc(430, 60, f"kablo {fnum(r_kablo, 3)} Ω", False, True, 50)
        c.kutu(600, 110, 120, 54, "RÖLE" if gorev == "koruma" else "SAYAÇ", f"{fnum(i_sek, 2)} A görüyor", "acti" if not doymus else ("gecersiz" if gorev == "koruma" else "acti"))
        c.hat("M360,200 V240").toprak(360, 240).yazi(372, 232, "tek noktadan topraklı", "PE", 10.5)
        c.yazi(730, 130, f"olması gereken {fnum(kat * is_, 2)} A", "#475569", 10.5)
    c.yazi(450, 284, f"yük {fnum(sb, 2)} VA · gerçek {'FS' if tur == 'olcme' else 'ALF'}′ = {fnum(n_g, 1)} · doyma {fnum(n_g * ip, 0)} A'de", "#334155", 12, True, "middle")
    oz = [K("Bağlı yük", f"{fnum(sb, 2)} VA", "ok" if sb <= sn else "bad", f"anma {fnum(sn, 1)} VA"), K("Gerçek " + ("FS′" if tur == "olcme" else "ALF′"), fnum(n_g, 1), "info", f"etikette {n}"),
          K("Doyma akımı", f"{fnum(n_g * ip, 0)} A", "info", f"{fnum(n_g, 1)} × In"), K("Sekonder akım", "açık devre" if acik else f"{fnum(i_sek, 2)} A", "bad" if (acik or (doymus and gorev == "koruma")) else "ok", "doymuş (temel bileşen)" if doymus and not acik else (f"tepe ≈ {fnum(S['u_tepe'], 0)} V" if acik else "doğrusal")),
          K("Diz gerilimi (yaklaşık)", f"{fnum(vk, 0)} V", "info", "n · Is · (Rct + Sn/Is²)")]
    if dc and not acik:
        oz.append(K("Doymaya kadar süre", "doymuyor" if t_doy is None else f"{fnum(t_doy, 1)} ms", "ok" if t_doy is None else ("warn" if t_doy >= 25 else "bad"), f"X/R = {fnum(xr, 0)} · gereken n′ = {fnum(kat * k_td, 0)}"))
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "grafikler": graf, "tablolar": [tablo]}
