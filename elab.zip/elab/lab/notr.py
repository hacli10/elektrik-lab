"""Laboratuvar konusu — trafo (OG) yıldız noktasının topraklanması: yalıtılmış, rezonans (Petersen), direnç üzerinden, doğrudan.

Model: tek faz–toprak arızası, simetrili bileşenler. Doğrudan topraklamada I0 = E / (Z1 + Z2 + Z0 + 3·Rf); diğerlerinde kaynak empedansı
ihmal edilir ve arıza akımı, yıldız noktası elemanı ile şebeke kapasitesinin paralel admitansından bulunur.
Dayanak: Topraklamalar Yön. m.5 (Çizelge-1), Şekil-4."""
from __future__ import annotations

import math

from .core import A120, C, K, ctl, fazor, fnum, num, opt, rules, utp

ID = "notr"
BASLIK = "Trafo yıldız noktası (OG)"
IKON = "✳"
GIRIS = ("Orta gerilim şebekesinde yıldız noktasının toprağa nasıl bağlandığı, bir faz toprağa değdiğinde ne kadar akım akacağını, sağlam fazların gerilimini, "
         "korumanın nasıl yapılacağını ve trafo merkezlerinin topraklamasının hangi akıma göre boyutlandırılacağını belirler.")
TIPLER = {"yalitilmis": "Yalıtılmış", "bobin": "Rezonans (Petersen bobini)", "direnc": "Direnç üzerinden", "dogrudan": "Doğrudan (etkin) topraklı"}

KONTROLLER = [
    ctl("tip", "Yıldız noktası", "sec", "direnc", secenek=opt(*TIPLER.items())),
    ctl("un_kv", "Şebeke gerilimi", "sec", 34.5, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (34.5, "34,5 kV"))),
    ctl("rn_ohm", "Yıldız noktası direnci RN", "sayi", 20, min=1, max=2000, adim=1, birim="Ω", yardim="34,5 kV'ta 20 Ω → ≈ 1000 A; 200 Ω → ≈ 100 A", goster={"tip": ["direnc"]}),
    ctl("ayar_pct", "Bobin ayarı (IL / IC)", "sayi", 100, min=50, max=150, adim=1, birim="%", yardim="%100 tam rezonans; uygulamada hafif aşırı kompanzasyon (%105–110) tercih edilir", goster={"tip": ["bobin"]}),
    ctl("kayip_pct", "Artık (aktif) akım oranı IRes / IC", "sayi", 5, min=1, max=15, adim=1, birim="%", yardim="Bobin ve şebeke kayıpları; bobinle götürülemez", goster={"tip": ["bobin"]}),
    ctl("x0_x1", "Kaynağın X0 / X1 oranı", "sayi", 1.0, min=0.5, max=5, adim=0.1, yardim="Trafo çıkışında ≈ 1; hat boyunca 3'e doğru artar", goster={"tip": ["dogrudan"]}),
    ctl("sk_mva", "Baradaki kısa devre gücü Sk″", "sayi", 500, min=20, max=5000, adim=10, birim="MVA", goster={"tip": ["dogrudan"]}),
    ctl("kablo_km", "Şebekedeki toplam kablo uzunluğu", "sayi", 10, min=0, max=300, adim=1, birim="km"),
    ctl("havai_km", "Şebekedeki toplam havai hat uzunluğu", "sayi", 20, min=0, max=1000, adim=5, birim="km"),
    ctl("rf_ohm", "Arıza noktası direnci Rf", "sayi", 0, min=0, max=5000, adim=5, birim="Ω", yardim="0 = metalik; kuru toprak, ağaç dalı, beton için yüzlerce – binlerce Ω"),
    ctl("r_azalma", "Azalma katsayısı r", "sayi", 0.6, min=0.1, max=1, adim=0.05, yardim="Arıza akımının toprağa geçen payı: tek damarlı XLPE kablo ekranı 0,5–0,6; toprak telsiz havai hat 1 (Ek-J)"),
    ctl("re_ohm", "Trafo merkezinin topraklama direnci RE", "sayi", 0.6, min=0.05, max=50, adim=0.05, birim="Ω"),
    ctl("tf_s", "Arızanın temizlenme süresi tF", "sayi", 0.5, min=0.05, max=10, adim=0.05, birim="s", goster={"tip": ["direnc", "dogrudan"]}),
]


def _coz(tip: str, p: dict) -> dict:
    """Tek faz–toprak arızası çözümü: akımlar (A, karmaşık), faz–toprak gerilimleri (V, karmaşık)."""
    R = rules()["og_notr"]
    un = num(p, "un_kv", 34.5) * 1000.0
    e = un / math.sqrt(3)
    rf = num(p, "rf_ohm", 0)
    ka = R["kapasitif_akim"]
    ic = (num(p, "kablo_km", 10) * ka["kablo_a_per_km_per_kv"] + num(p, "havai_km", 20) * ka["havai_a_per_km_per_kv"]) * un / 1000.0     # tam kayma altında kapasitif akım (A)
    yc = 1j * ic / e
    out = {"e": e, "un": un, "ic_tam": ic, "il": 0.0, "ires": 0.0}
    if tip == "dogrudan":
        z1 = 1j * un ** 2 / (num(p, "sk_mva", 500) * 1e6)
        z0 = num(p, "x0_x1", 1.0) * z1
        i0 = e / (2 * z1 + z0 + 3 * rf)
        v0, v1, v2 = -i0 * z0, e - i0 * z1, -i0 * z1
        va, vb, vc = v0 + v1 + v2, v0 + A120 ** 2 * v1 + A120 * v2, v0 + A120 * v1 + A120 ** 2 * v2
        out.update({"if": 3 * i0, "vn": v0, "va": va, "vb": vb, "vc": vc, "i_c": 0j, "i_n": 3 * i0})
        return out
    if tip == "direnc":
        yn = 1.0 / num(p, "rn_ohm", 20)
    elif tip == "bobin":
        il = num(p, "ayar_pct", 100) / 100.0 * ic; ires = num(p, "kayip_pct", 5) / 100.0 * ic
        yn = (-1j * il + ires) / e
        out.update({"il": il, "ires": ires})
    else:
        yn = 0j
    y = yc + yn
    i_f = e / (rf + 1 / y) if abs(y) > 0 else 0j
    va = i_f * rf                       # arızalı fazın toprağa göre gerilimi
    vn = va - e                         # yıldız noktasının toprağa göre gerilimi (kayma)
    out.update({"if": i_f, "vn": vn, "va": va, "vb": A120 ** 2 * e + vn, "vc": A120 * e + vn, "i_c": -yc * vn, "i_n": -yn * vn})
    return out


def _koruma(tip: str) -> str:
    return {"yalitilmis": "yönlü toprak koruması (67N, sinφ bağlantı) ve sıfır bileşen gerilimi (59N); akım küçük olduğu için basit aşırı akım rölesi görmez",
            "bobin": "wattmetrik yönlü toprak koruması (67N, cosφ) ya da geçici olay röleleri; çoğu arıza kendiliğinden söndüğü için açma yerine alarm",
            "direnc": "toprak aşırı akım koruması (50N/51N), fider seçiciliği zaman kademesiyle",
            "dogrudan": "faz ve toprak aşırı akım koruması (50/51, 50N/51N); akım büyük, hızlı açma"}[tip]


def run(p: dict) -> dict:
    R = rules()["og_notr"]
    tip = p.get("tip") if p.get("tip") in TIPLER else "direnc"
    s = _coz(tip, p)
    e = s["e"]; i_f = abs(s["if"])
    vmax = max(abs(s["vb"]), abs(s["vc"]))
    kat = vmax / e
    r_az = num(p, "r_azalma", 0.6); re_ = num(p, "re_ohm", 0.6)
    uzun = tip in ("yalitilmis", "bobin")
    tf = 10.0 if uzun else num(p, "tf_s", 0.5)
    ie = r_az * (math.hypot(s["il"], s["ires"]) if tip == "bobin" else i_f)
    ue = re_ * ie
    u_tp = utp(tf)
    an = [f"L1 fazı toprağa değdi (arıza direnci {fnum(num(p, 'rf_ohm', 0), 0)} Ω). Faz–nötr gerilimi E = {fnum(s['un'] / 1000, 1)} kV / √3 = {fnum(e / 1000, 2)} kV."]
    kt, ds = [], []
    if tip == "yalitilmis":
        an += ["Yıldız noktası toprağa bağlı olmadığından akımın dönebileceği tek yol şebekedeki bütün kablo ve hatların toprağa olan kapasitesidir.",
               f"Şebekenin kapasitif akımı IC ≈ {fnum(s['ic_tam'], 1)} A (kablo {fnum(num(p, 'kablo_km', 10), 0)} km, havai hat {fnum(num(p, 'havai_km', 20), 0)} km). Arıza noktasından {fnum(i_f, 1)} A akar; gerilime göre 90° ileridedir.",
               f"Arızalı faz toprak potansiyeline çekilir; yıldız noktası {fnum(abs(s['vn']) / 1000, 2)} kV kayar ve sağlam iki faz toprağa göre {fnum(vmax / 1000, 1)} kV'a ({fnum(kat, 2)} × E) çıkar. Faz arası gerilimler değişmez: yükler çalışmaya devam eder.",
               "Sakıncası: ark sönüp yeniden tutuşursa (aralıklı ark) kapasiteler her seferinde yeniden dolar ve aşırı gerilimler birikir; şebeke büyüdükçe akım artar ve ark kendiliğinden sönmez."]
        lim = R["ark_sonme"]["yalitilmis_a"]
        kt.append(C("Arkın kendiliğinden sönmesi", f"If = {fnum(i_f, 1)} A", f"≲ {lim} A (mertebe)", i_f <= lim, R["ark_sonme"]["kaynak"], R["ark_sonme"]["durum"]))
        ds += ["Yalıtılmış şebeke küçükken iyidir: akım birkaç amperdir ve işletme sürer. Kablo şebekesi büyüdükçe kapasitif akım onlarca–yüzlerce ampere çıkar.",
               "Sağlam fazlar saatlerce faz arası gerilimde kalabileceği için kablo ve teçhizat yalıtımı buna göre seçilir (ör. 20,3/35 kV kablo)."]
    elif tip == "bobin":
        an += [f"Yıldız noktasına bağlı bobin, kapasitif akımın tam tersi yönde endüktif akım akıtır: IL = {fnum(s['il'], 1)} A, IC = {fnum(s['ic_tam'], 1)} A. İkisi arıza noktasında birbirini götürür.",
               f"Geriye bobinle götürülemeyen aktif (kayıp) bileşen ve ayar farkı kalır: arıza noktasındaki artık akım {fnum(i_f, 1)} A.",
               "Akım bu kadar küçük olunca havai hatlardaki arkların çoğu kendiliğinden söner; tüketici hiçbir şey fark etmez.",
               f"Sağlam fazlar yine toprağa göre {fnum(vmax / 1000, 1)} kV'a çıkar ({fnum(kat, 2)} × E)."]
        ds += ["Bobin şebekenin kapasitesine ayarlanır; fider devreye girip çıktıkça ayar bozulur. Modern şebekelerde otomatik ayarlı bobin kullanılır.",
               "Tam rezonansta nötr kayması arızasız durumda da büyüyebildiği için bobin genellikle %5–10 aşırı kompanzasyona ayarlanır.",
               "Trafo merkezi topraklaması, bobinin bulunduğu merkezde bobin akımına (IL), diğerlerinde yalnız artık akıma göre boyutlandırılır (Çizelge-1)."]
    elif tip == "direnc":
        rn = num(p, "rn_ohm", 20)
        an += [f"Yıldız noktası {fnum(rn, 0)} Ω direnç üzerinden topraklı. Metalik arızada akım E / RN = {fnum(e / rn, 0)} A ile sınırlanır; kapasitif akım ({fnum(s['ic_tam'], 1)} A) buna dik eklenir.",
               f"Bu arızada If = {fnum(i_f, 0)} A. Akım hem sınırlı hem de röleyle rahat algılanacak büyüklüktedir: arızalı fider seçilip açılır.",
               f"Arıza sürdüğü sürece sağlam fazlar toprağa göre {fnum(vmax / 1000, 1)} kV'a çıkar ({fnum(kat, 2)} × E), ama arıza {fnum(tf, 2)} s içinde temizlenir.",
               "Direnç değeri bir dengedir: küçük seçilirse akım büyür (topraklama ve dokunma gerilimi zorlaşır), büyük seçilirse yüksek dirençli arızalar algılanamaz."]
        ds += ["Türkiye'de 34,5 kV dağıtım şebekesinin alışılmış düzeni budur; trafo merkezi topraklaması bu akıma (IE) göre tasarlanır.",
               "Arıza direnci büyüdükçe akım hızla düşer: kuru zemine düşen iletkende akım röle eşiğinin altında kalabilir (yüksek empedanslı arıza).",
               "Direncin akımı aktif olduğu için aralıklı ark aşırı gerilimlerini de söndürür; kural olarak IR ≥ IC seçilir."]
        kt.append(C("Direnç akımı kapasitif akımı karşılıyor mu", f"IR = {fnum(e / rn, 0)} A ; IC = {fnum(s['ic_tam'], 1)} A", "IR ≥ IC (aşırı gerilimleri sınırlamak için)", e / rn >= s["ic_tam"], "Genel uygulama kuralı", "ikincil"))
    else:
        an += [f"Yıldız noktası doğrudan topraklı. Arıza akımını yalnız kaynak ve hat empedansları sınırlar: If = 3·E / (Z1 + Z2 + Z0 + 3·Rf) = {fnum(i_f / 1000, 2)} kA.",
               f"Sağlam fazların toprağa göre gerilimi {fnum(vmax / 1000, 1)} kV'ta kalır ({fnum(kat, 2)} × E): yalıtım faz–nötr gerilimine göre seçilebilir.",
               "Bedeli büyük akımdır: arıza noktasında ve trafo merkezinde yüksek toprak potansiyel yükselmesi, büyük dokunma ve adım gerilimleri. Hızlı açma şarttır."]
        lim = R["toprak_ariza_katsayisi"]["etkin_sinir"]
        kt.append(C("Etkin topraklama (toprak arıza katsayısı)", f"Umax / E = {fnum(kat, 2)}", f"≤ {fnum(lim, 1)}", kat <= lim + 1e-9, R["toprak_ariza_katsayisi"]["kaynak"], R["toprak_ariza_katsayisi"]["durum"]))
        ds += ["Yüksek gerilim iletim şebekeleri ve bütün AG şebekeleri (TN, TT) doğrudan topraklıdır: yalıtım maliyeti düşer, koruma basittir.",
               "X0/X1 oranı büyüdükçe (kaynaktan uzaklaştıkça) sağlam faz gerilimi yükselir ve şebeke “etkin topraklı” olmaktan çıkar."]
    an.append(f"Koruma: {_koruma(tip)}.")
    # topraklama tasarım akımı ve dokunma gerilimi bağlantısı
    ta = R["tasarim_akimi"]
    an.append(f"Trafo merkezi topraklaması için tasarım akımı: {ta[tip]} → IE = {fnum(ie, 1)} A (r = {fnum(r_az, 2)}). RE = {fnum(re_, 2)} Ω ile topraklama gerilimi UE = RE · IE = {fnum(ue, 0)} V.")
    kt.append(C("Topraklama gerilimi (trafo merkezi)", f"UE = {fnum(re_, 2)} Ω × {fnum(ie, 1)} A = {fnum(ue, 0)} V", f"≤ 2 · UTp = {fnum(2 * u_tp, 0)} V  (tF = {'> 5 s, kalıcı' if uzun else fnum(tf, 2) + ' s'} → UTp = {fnum(u_tp, 0)} V)", ue <= 2 * u_tp + 1e-9,
                "Topraklamalar Yön. m.5 (Çizelge-1), m.11 (Çizelge-13), Ek-C (Çizelge-C.3)"))
    if uzun:
        ds.append("Arıza saatlerce kalabildiği için izin verilen dokunma gerilimi uzun süre değeridir (80 V); buna karşılık akım küçük olduğundan koşul çoğu zaman kolay sağlanır.")
    # dört yöntemin aynı şebekede karşılaştırması
    rows = []
    for t in TIPLER:
        q = _coz(t, p); vm = max(abs(q["vb"]), abs(q["vc"]))
        rows.append([TIPLER[t] + (" ◀" if t == tip else ""), f"{fnum(abs(q['if']), 1)} A" if abs(q["if"]) < 2000 else f"{fnum(abs(q['if']) / 1000, 2)} kA", f"{fnum(vm / 1000, 1)} kV ({fnum(vm / q['e'], 2)} × E)",
                     "sürer" if t in ("yalitilmis", "bobin") else "fider açar", _koruma(t).split(";")[0].split(",")[0]])
    kars = {"baslik": "Aynı şebekede dört yöntem (aynı arıza)", "cols": ["Yıldız noktası", "Arıza akımı", "Sağlam faz gerilimi", "İşletme", "Koruma"], "rows": rows,
            "not": f"Kapasitif akım: {R['kapasitif_akim']['formul']} — durum: {R['kapasitif_akim']['durum']}"}
    ku = R["kullanim"]
    kul = {"baslik": "Hangi yöntem nerede kullanılır?", "cols": ["Yöntem", "Tanım", "Nerede", "Güçlü yanı", "Zayıf yanı"], "rows": ku["satirlar"],
           "not": f"{ku['kaynak']} — durum: {ku['durum']}. Türkiye: {R['turkiye']['deger']} ({R['turkiye']['kaynak']} — durum: {R['turkiye']['durum']})"}
    ea, eb, ec = e + 0j, e * A120 ** 2, e * A120
    fz_u = {"baslik": "Faz – toprak gerilimleri (V)", "not": "kesik: arızadan önce · düz: arıza sırasında",
            "vektorler": [fazor("L1 (önce)", ea, "#d6b48f", True), fazor("L2 (önce)", eb, "#9ca3af", True), fazor("L3 (önce)", ec, "#cbd5e1", True),
                          fazor("L1", s["va"], "#8a4b12"), fazor("L2", s["vb"], "#111827"), fazor("L3", s["vc"], "#6b7280"), fazor("yıldız noktası kayması", s["vn"], "#dc2626")]}
    vek_i = [fazor("If (arıza noktası)", s["if"], "#dc2626")]
    if tip != "dogrudan":
        if abs(s["i_c"]) > 1e-6:
            vek_i.append(fazor("IC (kapasitif)", s["i_c"], "#1d4ed8"))
        if abs(s["i_n"]) > 1e-6:
            vek_i.append(fazor("IL + IRes (bobin)" if tip == "bobin" else "IR (direnç)", s["i_n"], "#15803d"))
    fz_i = {"baslik": "Akımlar (A)", "not": "arıza akımı = yıldız noktası elemanının akımı + kapasitif akım", "vektorler": vek_i}
    oz = [K("Arıza akımı If", f"{fnum(i_f, 1)} A" if i_f < 2000 else f"{fnum(i_f / 1000, 2)} kA", "info", TIPLER[tip]),
          K("Sağlam faz gerilimi", f"{fnum(vmax / 1000, 1)} kV", "warn" if kat > 1.4 else "ok", f"{fnum(kat, 2)} × faz–nötr gerilimi"),
          K("Şebeke kapasitif akımı", f"{fnum(s['ic_tam'], 1)} A", "info", "kablo ve hat uzunluğundan"),
          K("İşletme", "sürer" if uzun else "fider açar", "ok" if uzun else "info", "ilk arızada kesinti yok" if uzun else f"{fnum(tf, 2)} s içinde"),
          K("Topraklama gerilimi UE", f"{fnum(ue, 0)} V", "ok" if ue <= 2 * u_tp else "bad", f"IE = {fnum(ie, 1)} A ; sınır 2·UTp = {fnum(2 * u_tp, 0)} V")]
    sahne = {"tip": "notr", "tip_notr": tip, "tip_ad": TIPLER[tip], "if_txt": f"{fnum(i_f, 1)} A" if i_f < 2000 else f"{fnum(i_f / 1000, 2)} kA", "ic_txt": f"{fnum(abs(s['i_c']), 1)} A",
             "in_txt": f"{fnum(abs(s['i_n']), 1)} A", "vn_txt": f"{fnum(abs(s['vn']) / 1000, 2)} kV", "vmax_txt": f"{fnum(vmax / 1000, 1)} kV", "un_txt": f"{fnum(s['un'] / 1000, 1)} kV",
             "eleman": {"yalitilmis": "", "bobin": "Petersen bobini", "direnc": f"RN = {fnum(num(p, 'rn_ohm', 20), 0)} Ω", "dogrudan": "doğrudan"}[tip], "fazorler": [fz_u, fz_i]}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "tablolar": [kars, kul]}
