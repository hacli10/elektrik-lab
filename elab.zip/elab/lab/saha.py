"""Laboratuvar aracı — saha ölçüm formu: sahada okunan değerler girilir, her biri sınırıyla ve dayanağıyla değerlendirilir.

Proje hesabının yerine geçmez; ölçüm tutanağını doldururken “bu değer geçer mi?” sorusuna hızlı cevap içindir.
Dayanak: Topraklamalar Yön. m.8, m.10 (Çizelge-9, Çizelge-12), m.11, Ek-P."""
from __future__ import annotations

from .cizim import Cizim
from .core import C, K, cihaz_adi, cihaz_ia, ctl, fnum, num, opt, rules, ruleset, utp

ID = "saha"
BASLIK = "Saha ölçüm formu"
IKON = "📝"
GIRIS = ("Sahada ölçtüğünüz değerleri girin: süreklilik, yalıtım, çevrim empedansı ya da topraklama direnci, kaçak akım rölesi açma süreleri. "
         "Her değer sınırıyla karşılaştırılır; dayanağı ve bir sonraki ölçümün ne zaman yapılacağı gösterilir.")
TESIS = {"konut_tn": "Konut / işyeri — TN", "konut_tt": "Konut / işyeri — TT", "sanayi": "Sanayi tesisi — TN (AG)", "tm": "Trafo merkezi (YG topraklaması)", "hastane": "Hastane — grup 2 mahal"}

KONTROLLER = [
    ctl("tesis", "Tesis", "sec", "konut_tn", secenek=opt(*TESIS.items())),
    ctl("sureklilik", "Koruma iletkeni sürekliliği (en uzak nokta)", "sayi", 0.4, min=0.01, max=20, adim=0.01, birim="Ω"),
    ctl("l_m", "O noktaya kadar hat uzunluğu", "sayi", 30, min=1, max=300, adim=1, birim="m"),
    ctl("s_pe", "Koruma iletkeni kesiti", "sec", 2.5, secenek=opt(*[(v, f"{v:g} mm²") for v in (1.5, 2.5, 4, 6, 10, 16, 25, 35, 50)])),
    ctl("yalitim", "Yalıtım direnci (500 V d.a.)", "sayi", 50, min=0.01, max=1000, adim=0.1, birim="MΩ"),
    ctl("zs", "Çevrim empedansı Zs (en uzak nokta)", "sayi", 0.9, min=0.02, max=50, adim=0.01, birim="Ω", goster={"tesis": ["konut_tn", "sanayi", "hastane"]}),
    ctl("cihaz", "Koruma cihazı", "sec", "MCB", secenek=opt(("MCB", "Otomat (MCB)"), ("gG", "NH gG sigorta")), goster={"tesis": ["konut_tn", "sanayi", "hastane"]}),
    ctl("egri", "Otomat eğrisi", "sec", "C", secenek=opt(("B", "B"), ("C", "C"), ("D", "D")), goster={"tesis": ["konut_tn", "sanayi", "hastane"]}),
    ctl("in_a", "Anma akımı", "sec", 16, secenek=opt(*[(v, f"{v} A") for v in (6, 10, 16, 20, 25, 32, 40, 50, 63, 80, 100)]), goster={"tesis": ["konut_tn", "sanayi", "hastane"]}),
    ctl("ra", "Topraklama direnci RA", "sayi", 60, min=0.1, max=5000, adim=1, birim="Ω", goster={"tesis": ["konut_tt"]}),
    ctl("idn", "Kaçak akım rölesi IΔn", "sec", 30, secenek=opt((0, "yok"), (30, "30 mA"), (100, "100 mA"), (300, "300 mA")), goster={"tesis": ["konut_tn", "konut_tt", "sanayi", "hastane"]}),
    ctl("t1", "RCD açma süresi (1 × IΔn)", "sayi", 40, min=1, max=1000, adim=1, birim="ms", goster={"tesis": ["konut_tn", "konut_tt", "sanayi", "hastane"]}),
    ctl("t5", "RCD açma süresi (5 × IΔn)", "sayi", 20, min=1, max=500, adim=1, birim="ms", goster={"tesis": ["konut_tn", "konut_tt", "sanayi", "hastane"]}),
    ctl("re", "Topraklama direnci RE", "sayi", 0.8, min=0.02, max=50, adim=0.01, birim="Ω", goster={"tesis": ["tm"]}),
    ctl("ie", "Toprağa geçen arıza akımı IE", "sayi", 300, min=5, max=5000, adim=5, birim="A", goster={"tesis": ["tm"]}),
    ctl("tf", "Arıza temizleme süresi tF", "sayi", 0.5, min=0.05, max=10, adim=0.05, birim="s", goster={"tesis": ["tm"]}),
    ctl("esp", "Gövde – eşpotansiyel bara arası direnç", "sayi", 0.1, min=0.01, max=5, adim=0.01, birim="Ω", goster={"tesis": ["hastane"]}),
]


def run(p: dict) -> dict:
    R = rules()["rcd"]["acma_suresi"]; per = ruleset().topraklama["periyodik_olcum"]
    t = p.get("tesis") if p.get("tesis") in TESIS else "konut_tn"
    kt, an = [], []
    # süreklilik: ölçülen değer, iletkenin hesaplanan direncinden çok büyük olmamalı
    r_hesap = 0.0225 * num(p, "l_m", 30) / num(p, "s_pe", 2.5)
    sur = num(p, "sureklilik", 0.4)
    kt.append(C("Koruma iletkeni sürekliliği", f"{fnum(sur, 2)} Ω ölçüldü ; iletkenin hesaplanan direnci {fnum(r_hesap, 2)} Ω", f"kesintisiz; ölçülen ≲ hesaplanan + bağlantı payı ({fnum(r_hesap * 1.3 + 0.1, 2)} Ω)", sur <= r_hesap * 1.3 + 0.1,
                "Topraklamalar Yön. m.10; TS HD 60364-6 (ölçüm akımı ≥ 0,2 A)", "dogrulanacak"))
    yal = num(p, "yalitim", 50)
    kt.append(C("Yalıtım direnci", f"{fnum(yal, 2)} MΩ (500 V d.a.)", "≥ 0,5 MΩ", yal >= 0.5 - 1e-9, "Topraklamalar Yön. m.10, Çizelge-9"))
    if yal < 2:
        an.append("Yalıtım direnci sınırın üstünde olsa bile birkaç megaohmun altı yeni tesiste beklenmez: nem, zedelenmiş kılıf ya da bağlı kalmış bir cihaz aranır.")
    idn = num(p, "idn", 30)
    if t in ("konut_tn", "sanayi", "hastane"):
        zs = num(p, "zs", 0.9); ia = cihaz_ia(p, 0.4); lim = 230 / ia * 2 / 3
        ok = zs <= lim + 1e-9
        kt.append(C("Çevrim empedansı", f"Zs = {fnum(zs, 2)} Ω ; {cihaz_adi(p)} için Ia = {fnum(ia, 0)} A" + ("" if ok or not idn else " — aşırı akım cihazıyla sağlanmıyor; koruma kaçak akım rölesiyle"), f"≤ ⅔ · U0 / Ia = {fnum(lim, 2)} Ω",
                    True if ok else (None if idn else False), "Topraklamalar Yön. m.8-a3.3, a3.6; TS HD 60364-6", "dogrulanacak"))
    if t == "konut_tt":
        ra = num(p, "ra", 60)
        if idn:
            kt.append(C("TT: topraklama direnci", f"RA = {fnum(ra, 0)} Ω → RA · IΔn = {fnum(ra * idn / 1000, 1)} V", f"RA ≤ 50 V / IΔn = {fnum(50000 / idn, 0)} Ω", ra <= 50000 / idn + 1e-9, "Topraklamalar Yön. m.8-a4, Çizelge-12"))
        else:
            kt.append(C("TT: kaçak akım rölesi", "yok", "TT'de koruma kaçak akım rölesiyle sağlanır", False, "Topraklamalar Yön. m.8-a4"))
    if idn and t != "tm":
        t1, t5 = num(p, "t1", 40), num(p, "t5", 20)
        kt.append(C("RCD açma süresi (1 × IΔn)", f"{fnum(t1, 0)} ms", f"≤ {fnum(R['genel']['1'] * 1000, 0)} ms", t1 <= R["genel"]["1"] * 1000, R["kaynak"], R["durum"]))
        kt.append(C("RCD açma süresi (5 × IΔn)", f"{fnum(t5, 0)} ms", f"≤ {fnum(R['genel']['5'] * 1000, 0)} ms", t5 <= R["genel"]["5"] * 1000, R["kaynak"], R["durum"]))
    if t == "tm":
        re_, ie, tf = num(p, "re", 0.8), num(p, "ie", 300), num(p, "tf", 0.5)
        ue = re_ * ie; u = utp(tf)
        kt.append(C("Topraklama gerilimi", f"UE = RE · IE = {fnum(re_, 2)} × {fnum(ie, 0)} = {fnum(ue, 0)} V", f"≤ 2 · UTp = {fnum(2 * u, 0)} V (tF = {fnum(tf, 2)} s)", ue <= 2 * u + 1e-9, "Topraklamalar Yön. m.5, m.11 (Çizelge-13), Ek-C"))
        if ue > 2 * u:
            an.append(f"UE sınırı aşıyor. Seçenekler: RE'yi {fnum(2 * u / ie, 2)} Ω'un altına indirmek; ya da dokunma gerilimini akım–gerilim yöntemiyle ölçüp UT ≤ UTp = {fnum(u, 0)} V olduğunu göstermek (Ek-G); ya da M önlemleri (Ek-D).")
    if t == "hastane":
        e = num(p, "esp", 0.1)
        kt.append(C("Ek eşpotansiyel dengeleme", f"{fnum(e, 2)} Ω", "≤ 0,2 Ω", e <= 0.2 + 1e-9, "TS HD 60364-7-710 (grup 2 tıbbi mahaller)", "dogrulanacak"))
    yil = {"konut_tn": per["is_ekipmanlari_yil"], "konut_tt": per["is_ekipmanlari_yil"], "sanayi": per["sanayi_direnc_yil"], "tm": per["uretim_iletim_dagitim_yil"], "hastane": per["is_ekipmanlari_yil"]}[t]
    nbad = sum(1 for k in kt if k["ok"] is False); nok = sum(1 for k in kt if k["ok"] is True); nbilgi = len(kt) - nbad - nok
    an.insert(0, f"{TESIS[t]} için {len(kt)} ölçüm değerlendirildi: {nok} uygun" + (f", {nbilgi} açıklamalı (koşul başka bir önlemle sağlanıyor)" if nbilgi else "") + (f", {nbad} uygun değil." if nbad else ". Tutanağa işlenebilir."))
    an.append(f"Bir sonraki muayene ve ölçme: en geç {yil} yıl sonra ({per['kaynak']}). Sanayi tesislerinde topraklama dirençleri yılda bir, diğer kontroller iki yılda bir yapılır; işyerlerinde elektrik tesisatı yıllık periyodik kontrole tabidir.")
    ds = ["Tutanağa yalnız sayı değil, ölçüm koşulu da yazılır: yöntem, cihaz ve seri numarası, kalibrasyon tarihi, hava ve zemin durumu, ölçüm noktası.",
          "Sınırı kıl payı geçen bir değer güvence değildir: çevrim empedansında sıcaklık, topraklama direncinde mevsim payı bırakılır.",
          "Değerler bir öncekiyle karşılaştırılır. Yıldan yıla artan topraklama direnci ya da düşen yalıtım direnci, sınır aşılmadan önce uyarıdır.",
          "Bu form bir ön denetimdir; resmi uygunluk, yetkili kişinin düzenlediği ölçüm raporuyla belgelenir."]
    c = Cizim(900, 60 + 34 * len(kt))
    c.yazi(30, 28, f"ÖLÇÜM FORMU — {TESIS[t]}", "#1a4d8f", 13, True)
    for j, k in enumerate(kt):
        y = 50 + j * 34
        c.dikdortgen(30, y, 840, 28, "soluk", "#f8fafc" if k["ok"] is not False else "#fee2e2", 1, r=3)
        c.yazi(42, y + 19, k["ad"], "#334155", 11.5, True).yazi(360, y + 19, k["hesap"][:62], "#334155", 10.5).yazi(858, y + 19, "✓ uygun" if k["ok"] else "✗ uygun değil" if k["ok"] is False else "açıklamalı", "ok" if k["ok"] else "ariza" if k["ok"] is False else "#64748b", 11.5, True, "end")
    oz = [K("Değerlendirilen ölçüm", f"{len(kt)}", "info", TESIS[t]), K("Uygun", f"{nok}", "ok", f"{nbilgi} açıklamalı" if nbilgi else ""), K("Uygun değil", f"{nbad}", "bad" if nbad else "ok", ""), K("Sonraki ölçüm", f"en geç {yil} yıl", "info", "Ek-P")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne()}
