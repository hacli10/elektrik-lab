"""Laboratuvar konusu — kuru (gerilimsiz) ve ıslak (gerilimli) kontak; ikili girişler, ıslatma akımı, uzun kabloda yanlış sinyal,
d.a. kumanda devresinde toprak kaçağı.

Model: ikili giriş bir dirençtir (Rg). Kapalı kontakta giriş gerilimi U·Rg/(Rg + Rkablo + Rkontak). Açık kontakta, a.a. kumandada
kablonun damarlar arası kapasitesi üzerinden kaçak akar: Ug = U·Rg/√(Rg² + Xc²). D.a. kumandada sistem topraktan yalıtılmıştır;
bir kutup toprağa kaçarsa bir şey olmaz, ikinci kaçak bir kontağı köprüleyebilir."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, OMEGA, RHO_CU, ctl, fnum, num, opt

ID = "kontak"
BASLIK = "Kuru ve ıslak kontak"
IKON = "🔘"
GIRIS = ("Kuru kontak yalnızca bir anahtardır: gerilimi onu okuyan cihaz verir. Islak kontak ise gerilimi kendisi taşır. Hangisinin kullanıldığı, "
         "iki cihazın birbirine nasıl bağlanacağını, uzun kabloda sinyalin doğru okunup okunmayacağını ve bir toprak kaçağının yanlış açmaya yol açıp açmayacağını belirler.")
D = "dogrulanacak"

KONTROLLER = [
    ctl("tip", "Kontak türü", "sec", "kuru", secenek=opt(("kuru", "Kuru kontak (gerilimsiz; besleme alıcıdan)"), ("islak", "Islak kontak (gerilimi gönderen taraf veriyor)"))),
    ctl("alici", "Alıcı cihazın girişi", "sec", "gerilimli", secenek=opt(("gerilimli", "Kendi beslemesi olan giriş (kuru kontak bekler)"), ("gerilimsiz", "Pasif giriş (dışarıdan gerilim bekler)"))),
    ctl("u", "Kumanda gerilimi", "sec", 110, secenek=opt((24, "24 V"), (48, "48 V"), (110, "110 V"), (220, "220 V"))),
    ctl("ac", "Kumanda gerilimi alternatif (a.a.)", "onay", False),
    ctl("l_m", "Kontak ile giriş arasındaki kablo", "sayi", 100, min=1, max=3000, adim=10, birim="m"),
    ctl("rg_kohm", "İkili girişin direnci", "sayi", 50, min=1, max=500, adim=1, birim="kΩ", yardim="Sayısal röle girişleri yüksek dirençlidir (birkaç mA çeker)"),
    ctl("esik_pct", "Girişin çekme eşiği", "sec", 70, secenek=opt((20, "%20 Un (duyarlı)"), (50, "%50 Un"), (70, "%70 Un"), (80, "%80 Un"))),
    ctl("r_kontak", "Kontağın geçiş direnci (kirli / oksitli kontak)", "sayi", 0.1, min=0.01, max=100000, adim=0.1, birim="Ω"),
    ctl("i_min_ma", "Kontağın gerektirdiği en küçük (ıslatma) akımı", "sec", 1, secenek=opt((1, "1 mA (altın kaplama sinyal kontağı)"), (10, "10 mA"), (100, "100 mA (güç kontağı, yardımcı kontak)"))),
    ctl("kacak", "D.a. kumanda devresinde toprak kaçağı", "sec", "yok", secenek=opt(("yok", "yok"), ("bir", "bir kaçak (artı kutup toprağa)"), ("iki", "iki kaçak (artı kutup ve kontak ile giriş arasındaki iletken)")), goster={"ac": [False]}),
]
C_NF_M = 0.12        # kumanda kablosunda damarlar arası kapasite (nF/m) — tipik


def run(p: dict) -> dict:
    kuru = p.get("tip") != "islak"; al_ger = p.get("alici") != "gerilimsiz"
    u = num(p, "u", 110); ac = bool(p.get("ac")); L = num(p, "l_m", 100)
    rg = num(p, "rg_kohm", 50) * 1000; esik = num(p, "esik_pct", 70) / 100; rk = num(p, "r_kontak", 0.1); imin = num(p, "i_min_ma", 1) / 1000
    kacak = p.get("kacak") if (p.get("kacak") in ("yok", "bir", "iki") and not ac) else "yok"
    r_kablo = 2 * RHO_CU * L / 1.5
    uyum = kuru == al_ger
    u_kapali = u * rg / (rg + r_kablo + rk)
    i_kapali = u / (rg + r_kablo + rk)
    cc = C_NF_M * 1e-9 * L
    u_acik = (u * rg / math.hypot(rg, 1 / (OMEGA * cc))) if ac else 0.0
    if kacak == "iki":
        u_acik = u
    an = ["Kuru kontak: iki ucu arasında gerilim olmayan, yalnız açılıp kapanan kontak (röle çıkışı, yardımcı kontak, sınır anahtarı). Okuyan cihaz kendi geriliminin bir ucunu kontağa gönderir, öbür ucundan dönüşünü okur."
          if kuru else "Islak kontak: gerilimi gönderen taraf verir; kontak kapandığında hatta gerilim görünür. Alıcı yalnız bu gerilimi algılar (pasif giriş).",
          ("Kontak ile giriş birbirine uygun." if uyum else
           ("Uyumsuz: kontak gerilimsiz, giriş de gerilim bekliyor — devrede kaynak yok, giriş hiçbir zaman “1” okumaz. Araya besleme eklenmelidir." if kuru else
            "Uyumsuz: kontak gerilim veriyor, giriş de kendi gerilimini veriyor — iki ayrı kaynak aynı devreye bağlanıyor. Kutuplar ve topraklamalar farklıysa kaynaklar arasında kısa devre ya da dolaşan akım oluşur; giriş kartı yanabilir.")),
          f"Kontak kapalıyken girişe {fnum(u_kapali, 1)} V ulaşır (kablo {fnum(r_kablo, 1)} Ω, kontak {fnum(rk, 1)} Ω, giriş {fnum(rg / 1000, 0)} kΩ); devreden {fnum(i_kapali * 1000, 2)} mA geçer. Girişin çekme eşiği %{fnum(esik * 100, 0)} = {fnum(esik * u, 0)} V."]
    kt = [C("Kontak – giriş uyumu", ("kuru kontak" if kuru else "ıslak kontak") + " → " + ("beslemeli giriş" if al_ger else "pasif giriş"), "kuru kontak ↔ beslemeli giriş ; ıslak kontak ↔ pasif giriş", uyum, "Koruma rölesi ve otomasyon cihazı üreticilerinin bağlantı kuralları", "ikincil"),
          C("Kapalı kontakta giriş gerilimi", f"{fnum(u_kapali, 1)} V", f"≥ çekme eşiği {fnum(esik * u, 0)} V", u_kapali >= esik * u - 1e-9, "TS EN 60255-1 (ölçme röleleri: ikili girişler)", D),
          C("Islatma akımı", f"{fnum(i_kapali * 1000, 2)} mA", f"≥ kontağın en küçük akımı {fnum(imin * 1000, 0)} mA", i_kapali >= imin - 1e-12, "TS EN 60947-5-1 / TS EN 61810 (kontakların en küçük anahtarlama yükü)", D)]
    if i_kapali < imin:
        an.append("Devreden geçen akım kontağın gerektirdiği en küçük akımın altında: kontak yüzeyindeki oksit ve film tabakası delinemez, geçiş direnci zamanla artar ve sinyal kesik kesik gelir. Güç kontağını birkaç miliamperlik sayısal girişle okumak bu yüzden sorun çıkarır; "
                  "çözüm altın kaplamalı sinyal kontağı ya da girişe paralel bir yük direncidir.")
    if ac:
        an.append(f"Kumanda alternatif gerilimli ve kablo {fnum(L, 0)} m: gidiş–dönüş damarları arasındaki kapasite {fnum(cc * 1e9, 0)} nF. Kontak açıkken bu kapasiteden akım sızar ve girişte {fnum(u_acik, 1)} V görünür.")
        kt.append(C("Açık kontakta giriş gerilimi (kapasitif kaçak)", f"{fnum(u_acik, 1)} V", f"< bırakma eşiği (çekme eşiğinin altında güvenli pay: {fnum(0.6 * esik * u, 0)} V)", u_acik < 0.6 * esik * u, "Uygulama kuralı; cihaz üreticileri (uzun a.a. kumanda kablolarında d.a. kullanımı)", "ikincil"))
        if u_acik >= 0.6 * esik * u:
            an.append("Bu gerilim girişin eşiğine yakın ya da üstünde: kontak açıkken de giriş “1” okur (ya da bırakmaz). Çare: d.a. kumanda, daha düşük dirençli giriş, girişe paralel yük direnci ya da ekranlı / kısa kablo.")
    if kacak != "yok":
        an.append("D.a. kumanda sistemi (akü) topraktan yalıtılmıştır. Bir kutup toprağa kaçarsa devre tamamlanmaz, hiçbir şey olmaz; toprak kaçağı izleme rölesi alarm verir ve kaçak aranır." if kacak == "bir" else
                  "İki ayrı noktada toprak kaçağı var: artı kutup ile kontaktan sonraki iletken toprak üzerinden birleşiyor ve kontağı köprülüyor. Kontak açıkken girişe tam gerilim gelir: açma bobiniyse kesici kendiliğinden açar. İlk kaçağın hemen giderilmesi bu yüzden zorunludur.")
        kt.append(C("D.a. kumanda devresinde toprak kaçağı", {"bir": "bir kaçak (alarm)", "iki": "iki kaçak: kontak köprülendi"}[kacak], "ilk kaçak izlenir ve giderilir; ikinci kaçak yanlış çalışmaya yol açar", kacak == "bir",
                    "Elektrik Kuvvetli Akım Tesisleri Yön. (yardımcı servis d.a. sistemleri); TS EN 61557-8 (yalıtım izleme)", D))
    ds = ["“Kuru” ve “ıslak” kontağın kendisiyle değil, gerilimin nereden geldiğiyle ilgilidir. İki cihazı bağlarken ilk soru: besleme kimde?",
          "Kuru kontak iki sistemi birbirinden ayırır (galvanik yalıtım): gönderen tarafın gerilimi, toprağı, arızası alıcıya taşınmaz. Farklı panolar, farklı firmaların cihazları arasında kural olarak kuru kontak kullanılır.",
          "Sayısal rölelerin girişleri çok az akım çeker; kirlenmiş kontağı temizleyecek akım yoktur ve uzun kablodaki kaçağa duyarlıdır. Eşiği yüksek (%70–80 Un) girişler yanlış sinyale karşı daha dayanıklıdır.",
          "Uzun mesafede alternatif akım kumandadan kaçınılır: kablo kapasitesi kontak açıkken de akım geçirir. Trafo merkezlerinde kumanda bu yüzden 110 V ya da 220 V d.a. iledir.",
          "D.a. kumanda sistemi topraklanmaz ve toprak kaçağı izlenir: böylece tek bir kaçak ne kısa devreye ne yanlış açmaya yol açar. Aynı mantık IT şebekesinin mantığıdır."]
    okur = (u_kapali >= esik * u) and uyum
    c = Cizim(900, 290)
    c.dikdortgen(40, 46, 200, 160, "#334155", "#f8fafc").yazi(140, 66, "GÖNDEREN CİHAZ", "#0f172a", 11.5, True, "middle").yazi(140, 194, "ıslak: gerilim burada" if not kuru else "kuru: yalnız kontak", "#475569", 10.5, False, "middle")
    c.dikdortgen(660, 46, 200, 160, "#334155", "#f8fafc").yazi(760, 66, "ALICI CİHAZ", "#0f172a", 11.5, True, "middle").yazi(760, 194, "ikili giriş" + (" + besleme" if al_ger else " (pasif)"), "#475569", 10.5, False, "middle")
    c.hat("M240,100 H176", "cizgi").hat("M150,100 H100 V160 H240", "cizgi").hat("M660,100 H700 V115", "cizgi").hat("M700,145 V160 H660", "cizgi")
    c.hat("M240,100 H660", "L1", hot=uyum, hot_renk="ok" if okur else "ariza").hat("M240,160 H660", "N", hot=uyum, hot_renk="ok" if okur else "ariza")
    c.hat("M150,100 L172,86", "cizgi", w=2.6).daire(150, 100, 4, "cizgi", "#fff").daire(176, 100, 4, "cizgi", "#fff").yazi(163, 122, "kontak", "#475569", 10.5, False, "middle")
    if not kuru:
        c.yazi(112, 146, f"{fnum(u, 0)} V {'a.a.' if ac else 'd.a.'}", "ariza", 11.5, True)
    if al_ger:
        c.yazi(850, 176, f"{fnum(u, 0)} V {'a.a.' if ac else 'd.a.'}", "ariza", 11.5, True, "end")
    c.direnc(700, 115, f"giriş {fnum(rg / 1000, 0)} kΩ", False, False, 30).kap(450, 100, 160, "soluk" if not ac else "uyari", False, f"kablo {fnum(cc * 1e9, 0)} nF").yazi(450, 86, f"kablo {fnum(L, 0)} m", "#475569", 10.5, False, "middle")
    if kacak != "yok":
        c.hat("M300,100 V230", "ariza", hot=kacak == "iki").toprak(300, 230).yazi(310, 220, "kaçak 1", "ariza", 10.5)
    if kacak == "iki":
        c.hat("M560,100 V230", "ariza", hot=True).toprak(560, 230).yazi(570, 220, "kaçak 2", "ariza", 10.5).hat("M300,246 H560", "toprak", hot=True)
    c.yazi(450, 276, ("kontak kapalı: giriş " + ("“1” okuyor" if okur else "OKUYAMIYOR")) + (f" · kontak açıkken girişte {fnum(u_acik, 1)} V" if (ac or kacak == "iki") else ""), "ok" if (okur and all(k["ok"] is not False for k in kt)) else "ariza", 12, True, "middle")
    oz = [K("Kontak – giriş", "uyumlu" if uyum else "uyumsuz", "ok" if uyum else "bad", ("kuru" if kuru else "ıslak") + " → " + ("beslemeli" if al_ger else "pasif")), K("Kapalı kontakta giriş", f"{fnum(u_kapali, 1)} V", "ok" if u_kapali >= esik * u else "bad", f"eşik {fnum(esik * u, 0)} V"),
          K("Devre akımı", f"{fnum(i_kapali * 1000, 2)} mA", "ok" if i_kapali >= imin else "bad", f"en az {fnum(imin * 1000, 0)} mA"), K("Açık kontakta giriş", f"{fnum(u_acik, 1)} V", "ok" if u_acik < 0.6 * esik * u else "bad", "olması gereken 0 V")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne()}
