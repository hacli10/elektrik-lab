"""Laboratuvar — zaman bölgesi çözücüleri (doğrusal olmayan devreler). Konu modülleri (at, rezonans, bobin) bunları kullanır.

1) Akım trafosu: sekonder devre R2 (sargı + yük) ve doymaya giren mıknatıslanma kolu.
     is = ip′ − im(λ) ;  dλ/dt = R2·is ;  im(λ): diz akısına kadar doğrusal (Lm), ötesinde hava çekirdekli (Ls)
   Parça parça doğrusal olduğundan her adım kapalı biçimde (üstel) çözülür: kararlıdır.
2) Ferrorezonans: kaynak E — seri kapasite Xc — (doymaya giren endüktans ∥ kayıp direnci), birim değerlerle:
     dλ/dθ = e − uC ;  duC/dθ = Xc·(im(λ) + (e − uC)/Rp)        (θ = ω·t) — dördüncü mertebe Runge–Kutta
3) Bobinin kesilmesi: L–R bobin, sargı kapasitesi Cp, söndürme elemanı ve açılan kontağın artan delinme dayanımı
     (söndürmesiz kontakta ark söndükçe yeniden tutuşur: olay güdümlü çözüm)."""
from __future__ import annotations

import math
from functools import lru_cache

W = 2 * math.pi * 50


# ---------------- 1) akım trafosu ----------------
@lru_cache(maxsize=256)
def at_sim(i_ef: float, r2: float, vk: float, n_is: float, xr: float, rem: float, acik: bool = False, rc: float = 0.0, cevrim: int = 5) -> dict:
    """i_ef: ideal sekonder akımın etkin değeri (A) ; r2: sekonder devre direnci (Ω) ; vk: diz gerilimi (V etken) ; n_is: ALF × Is (A)
    xr: şebekenin X/R oranı (0 → simetrik akım) ; rem: kalıcı akı (diz akısının oranı) ; acik: sekonder açık (yük = çekirdek kayıp direnci rc).
    Dönen: t (ms), ideal ve gerçek sekonder akım (A), uç gerilimi (V), akı (pu), doyma anı (ms ya da None), periyot bazında temel bileşen oranı."""
    lam_s = math.sqrt(2) * vk / W                            # diz (doyma) akısı
    i_diz = 0.03 * n_is * math.sqrt(2)                      # diz noktasında mıknatıslanma akımı (tepe) — ALF akımının %3'ü
    lm = lam_s / i_diz
    ls = lm / 400.0
    r = rc if acik else r2
    t1 = xr / W if xr > 0 else 0.0
    dt = 0.02 / 400
    # başlangıç akısı: DC bileşenli arızada kalıcı akı; simetrik akımda sürekli rejim değeri (akım sıfırken akı tepe değerindedir)
    lam = rem * lam_s if (t1 > 0 or acik) else -min(math.sqrt(2) * i_ef * r / W, lam_s)
    ts, ideal, gercek, gerilim, aki = [], [], [], [], []
    t_doy = None
    n = int(cevrim * 400)
    for k in range(n + 1):
        t = k * dt
        ip = math.sqrt(2) * i_ef * (math.sin(W * t) if t1 == 0 else (math.exp(-t / t1) - math.cos(W * t)))
        doy = abs(lam) > lam_s
        im = lam / lm if not doy else math.copysign(i_diz + (abs(lam) - lam_s) / ls, lam)
        is_ = ip - im
        if k % 4 == 0:
            ts.append(round(t * 1000, 2)); ideal.append(ip); gercek.append(0.0 if acik else is_); gerilim.append(r * is_); aki.append(lam / lam_s)
        if doy and t_doy is None:
            t_doy = t * 1000
        # bir adım: dλ/dt = r·(ip_orta − a − λ/L), bölge içinde doğrusal → üstel çözüm
        tm = t + dt / 2
        ipm = math.sqrt(2) * i_ef * (math.sin(W * tm) if t1 == 0 else (math.exp(-tm / t1) - math.cos(W * tm)))
        if not doy:
            L, a = lm, 0.0
        else:
            L = ls; a = (1.0 if lam > 0 else -1.0) * (i_diz - lam_s / ls)
        lam_d = L * (ipm - a)
        lam = lam_d + (lam - lam_d) * math.exp(-dt * r / L)
    # periyot bazında temel bileşen (rölenin gördüğü) / ideal
    oran = []
    m = 100                                                  # kaydedilen örnek / periyot
    for c in range(cevrim):
        seg_g = gercek[c * m:(c + 1) * m]; seg_i = ideal[c * m:(c + 1) * m]
        if len(seg_g) < m:
            break
        def temel(x):
            a = sum(v * math.cos(2 * math.pi * j / m) for j, v in enumerate(x)) * 2 / m
            b = sum(v * math.sin(2 * math.pi * j / m) for j, v in enumerate(x)) * 2 / m
            return math.hypot(a, b) / math.sqrt(2)
        oran.append(temel(seg_g) / max(i_ef, 1e-9))
    return {"t": ts, "ideal": ideal, "gercek": gercek, "u": gerilim, "aki": aki, "t_doy": t_doy, "oran": oran, "u_tepe": max(abs(v) for v in gerilim), "lam_s": lam_s}


# ---------------- 2) ferrorezonans ----------------
@lru_cache(maxsize=256)
def ferro_sim(xc: float, i0: float, rp: float, e: float = 0.5, aci: float = 0.0, lam_k: float = 1.2, xs: float = 0.3, cevrim: int = 30, adim: int = 600) -> dict:
    """Birim değerler: xc seri kapasitif reaktans, i0 boşta akım (→ Xm = 1/i0), rp kayıp ∥ yük direnci, e kaynağın tepe değeri (faz gerilimi tepesi = 1),
    aci kapama anındaki gerilim açısı (°). Dönen: θ/2π (periyot), sargı gerilimi u (pu), akı, son 8 periyottaki tepe gerilim ve akı."""
    xm = 1.0 / i0
    a0 = math.radians(aci)

    def im(lam: float) -> float:
        al = abs(lam)
        return lam / xm if al <= lam_k else math.copysign(lam_k / xm + (al - lam_k) / xs, lam)

    def f(th: float, lam: float, uc: float) -> tuple[float, float]:
        ul = e * math.sin(th + a0) - uc
        return ul, xc * (im(lam) + ul / rp)

    h = 2 * math.pi / adim
    lam, uc = 0.0, 0.0
    ts, us, ls = [], [], []
    u_son = l_son = 0.0
    for k in range(cevrim * adim + 1):
        th = k * h
        ul = e * math.sin(th + a0) - uc
        if k % 6 == 0:
            ts.append(round(th / (2 * math.pi), 3)); us.append(ul); ls.append(lam)
        if k >= (cevrim - 8) * adim:
            u_son = max(u_son, abs(ul)); l_son = max(l_son, abs(lam))
        k1 = f(th, lam, uc)
        k2 = f(th + h / 2, lam + h / 2 * k1[0], uc + h / 2 * k1[1])
        k3 = f(th + h / 2, lam + h / 2 * k2[0], uc + h / 2 * k2[1])
        k4 = f(th + h, lam + h * k3[0], uc + h * k3[1])
        lam += h / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0])
        uc += h / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])
        if abs(lam) > 50 or abs(uc) > 500:                 # ıraksama (sayısal) — kes
            break
    return {"t": ts, "u": us, "aki": ls, "u_tepe": u_son, "aki_tepe": l_son, "doyuyor": l_son > lam_k, "u_dogrusal": abs(e * xm / (xm - xc)) if abs(xm - xc) > 1e-9 else 99.0}


# ---------------- 3) bobinin kesilmesi ----------------
def bobin_sim(u: float, r: float, L: float, i0: float, sond: str, vc: float, cp: float, anahtar: str, dayanim: float, rs: float = 100.0, cs: float = 0.1e-6) -> dict:
    """Anahtar t = 0'da açılır. Dönen: t (ms), anahtarın uçlarındaki gerilim (V), bobin akımı (mA), en büyük anahtar gerilimi,
    yeniden tutuşma sayısı (söndürmesiz kontak), akımın %30'a indiği an (ms)."""
    ts, us, is_ = [-1.0, 0.0], [0.0, 0.0], [i0 * 1000, i0 * 1000]
    tut = 0; t_b = None; u_max = 0.0
    if sond in ("diyot", "zener", "varistor"):               # gerilim vc'de tutulur: i(t) = (I0 + vc/R)·e^(−t/τ) − vc/R
        tau = L / r
        t_son = tau * math.log((i0 + vc / r) / (vc / r)) if vc > 0 else 5 * tau
        n = 160
        for k in range(1, n + 1):
            t = 1.25 * t_son * k / n
            i = max(0.0, (i0 + vc / r) * math.exp(-t / tau) - vc / r)
            ts.append(round(t * 1000, 3)); is_.append(i * 1000); us.append(u + vc if i > 0 else u)
            if t_b is None and i <= 0.3 * i0:
                t_b = t * 1000
        u_max = u + vc
    elif sond == "rc":                                       # seri RLC: L·di/dt = ucs − (R + Rs)·i ; Cs·ducs/dt = −i ; bobin uç gerilimi uc = ucs − Rs·i
        w0 = 1 / math.sqrt(L * cs)
        dt = 2 * math.pi / w0 / 200
        i, ucs = i0, u
        n = int(min(6 * 2 * L / (r + rs), 0.25) / dt)
        for k in range(1, n + 1):
            def g(i_, u_):
                return (u_ - (r + rs) * i_) / L, -i_ / cs
            k1 = g(i, ucs); k2 = g(i + dt / 2 * k1[0], ucs + dt / 2 * k1[1]); k3 = g(i + dt / 2 * k2[0], ucs + dt / 2 * k2[1]); k4 = g(i + dt * k3[0], ucs + dt * k3[1])
            i += dt / 6 * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0]); ucs += dt / 6 * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])
            usw = u - (ucs - rs * i)
            u_max = max(u_max, abs(usw))
            if t_b is None and abs(i) <= 0.3 * i0:
                t_b = k * dt * 1000
            if k % max(1, n // 400) == 0:
                ts.append(round(k * dt * 1000, 3)); is_.append(i * 1000); us.append(usw)
    else:                                                    # söndürme yok
        serbest = i0 * math.sqrt(L / cp)                     # hiçbir şey sınırlamazsa sargı kapasitesinin dolacağı gerilim
        if anahtar == "transistor":                          # yarı iletken çığ bölgesine girer ve gerilimi orada tutar; enerjiyi kendisi yutar
            vz = max(1.2 * dayanim - u, 1.0)
            tau = L / r
            t_son = tau * math.log((i0 + vz / r) / (vz / r))
            for k in range(1, 121):
                t = 1.3 * t_son * k / 120
                i = max(0.0, (i0 + vz / r) * math.exp(-t / tau) - vz / r)
                ts.append(round(t * 1000, 4)); is_.append(i * 1000); us.append(u + vz if i > 0 else u)
                if t_b is None and i <= 0.3 * i0:
                    t_b = t * 1000
            u_max = u + vz
        else:                                                # kontak: aralığın delinme dayanımı açıldıkça artar; gerilim ona ulaştıkça ark yeniden tutuşur
            v0, kv = 320.0, 1.5e6                            # hava aralığının en küçük delinme gerilimi (V) ve artış hızı (V/s): ≈ 0,5 mm/ms × 3 kV/mm
            t, i = 0.0, i0
            while i > 1e-4 and tut < 60000:
                egim = i / cp
                if egim <= kv * 1.02:                        # gerilim artık aralığın dayanımına yetişemiyor: son salınım
                    break
                d = (v0 - 15.0 + kv * t) / (egim - kv)
                t += d
                vbd = v0 + kv * t
                e_kayip = 0.5 * cp * vbd ** 2 + r * i * i * d
                i = math.sqrt(max(0.0, i * i - 2 * e_kayip / L))
                tut += 1
                u_max = max(u_max, vbd)
                if tut % 40 == 1:
                    ts.append(round(t * 1000, 4)); is_.append(i * 1000); us.append(vbd)
                if t_b is None and i <= 0.3 * i0:
                    t_b = t * 1000
            if tut:
                ts.append(round(t * 1000, 4)); is_.append(i * 1000); us.append(u_max)      # son yeniden tutuşma
            # son serbest salınım (sönümlü): tepe ≈ i·√(L/Cp)
            vs = i * math.sqrt(L / cp)
            u_max = max(u_max, vs + u)
            w0 = 1 / math.sqrt(L * cp); al = r / (2 * L)
            for k in range(1, 61):
                tt = k * (2 * math.pi / w0) * 3 / 60
                ts.append(round((t + tt) * 1000, 4)); is_.append(i * 1000 * math.exp(-al * tt) * math.cos(w0 * tt)); us.append(u + vs * math.exp(-al * tt) * math.sin(w0 * tt))
            if t_b is None:
                t_b = t * 1000
        return {"t": ts, "u": us, "i": is_, "u_max": u_max, "tut": tut, "t_b": t_b or 0.0, "serbest": serbest + u}
    return {"t": ts, "u": us, "i": is_, "u_max": u_max, "tut": 0, "t_b": t_b or 0.0, "serbest": u_max}
