"""Topraklama laboratuvarı: öğretici, etkileşimli topraklama simülasyonları.

Proje verisi okumaz, yazmaz. Her konu bir modüldür: ID, BASLIK, IKON, GIRIS, KONTROLLER ve run(params)."""
from __future__ import annotations

import importlib

# gruplar ve sıra (arayüzdeki menü bu sırayla kurulur); dağıtım trafosu deneyleri (trafo_test) güç sistemi laboratuvarında gösterilir (elab/guc)
GRUPLAR = [
    ("Temeller", ["sebeke", "rcd", "harmonik", "multimetre", "esp"]),
    ("Topraklama tesisi", ["dokunma", "ayrim", "tasarim", "kesit", "olcum", "saha", "yildirim"]),
    ("OG ve ölçü trafoları", ["notr", "rezonans", "ekran", "toroid", "at", "gt"]),
    ("Koruma", ["yonlu", "diferansiyel"]),
    ("Deneyler", ["hucre_test", "yalitim", "pd", "tandelta", "kablo_test", "kontak"]),
    ("Makine ve kumanda", ["motor", "surucu", "bobin", "jenerator", "ges_dc", "emc"]),
    ("Araçlar", ["hatalar", "alistirma"]),
]
KONU_MODULLERI = [k for _, ks in GRUPLAR for k in ks]
GRUP_OF = {k: g for g, ks in GRUPLAR for k in ks}


def _mods() -> list:
    out = []
    for name in KONU_MODULLERI:
        try:
            out.append(importlib.import_module(f"{__name__}.{name}"))
        except ModuleNotFoundError as e:
            if e.name != f"{__name__}.{name}":
                raise
    return out


def spec() -> list[dict]:
    """Arayüzün kuracağı konu listesi: başlık, giriş metni, ayarlar."""
    return [{"id": m.ID, "baslik": m.BASLIK, "ikon": m.IKON, "giris": m.GIRIS, "kontroller": m.KONTROLLER, "grup": GRUP_OF.get(m.ID, "")} for m in _mods()]


def defaults(topic: str) -> dict:
    m = _find(topic)
    return {c["key"]: c["vars"] for c in m.KONTROLLER}


def _find(topic: str):
    for m in _mods():
        if m.ID == topic:
            return m
    raise KeyError(f"Bilinmeyen laboratuvar konusu: {topic}")


def run(topic: str, params: dict | None = None) -> dict:
    m = _find(topic)
    p = defaults(topic)
    p.update({k: v for k, v in (params or {}).items() if v is not None})
    out = m.run(p)
    for k in ("ozet", "kontroller", "anlatim", "dersler", "grafikler", "tablolar"):
        out.setdefault(k, [])
    out.setdefault("sahne", {})
    out["konu"] = topic
    out["params"] = p
    return out
