"""Laboratuvar konusu — rezonans ve ferrorezonans.

(1) Kompanzasyon – trafo paralel rezonansı: şebeke endüktansı ile kondansatör, harmonik akım kaynağına göre paralel devredir.
    Rezonans mertebesi h_r = √(Sk / Qc); reaktörlü kademede (p = XL/XC) seri rezonans 1/√p, paralel rezonans 1/√(p + Qc/Sk).
    Büyütme: şebekeye akan harmonik akım / üretilen harmonik akım = |Z_kol| / |Z_kol + Z_şebeke| (yük direnci sönümler).
(2) Ferrorezonans: doymaya giren demir çekirdek (boşta trafo, gerilim trafosu) + kapasite (kablo, bara). Doğrusal değildir;
    burada risk ölçütü olarak kapasitif reaktansın mıknatıslanma reaktansına oranı Xc / Xm kullanılır (mertebe)."""
from __future__ import annotations

import math

from . import zaman
from .cizim import Cizim
from .core import C, K, OMEGA, ctl, fnum, num, opt

ID = "rezonans"
BASLIK = "Rezonans ve ferrorezonans"
IKON = "🎵"
GIRIS = ("Endüktans ile kapasite aynı frekansta buluşursa küçük bir akım büyük gerilimlere yol açar. Kompanzasyon panosunda bu, harmoniklerin büyümesi demektir; "
         "boşta trafoda ya da gerilim trafosunda ise demir çekirdeğin doymasıyla kendiliğinden başlayan ve sönmeyen aşırı gerilimler (ferrorezonans).")
MOD = {"paralel": "Kompanzasyon – trafo rezonansı (harmonik büyütme)", "ferro_trafo": "Ferrorezonans: tek kutuplu anahtarlama, kablo + boşta trafo", "ferro_gt": "Ferrorezonans: gerilim trafosu, yalıtılmış nötrlü şebeke"}

KONTROLLER = [
    ctl("mod", "Olay", "sec", "paralel", secenek=opt(*MOD.items())),
    ctl("trafo_kva", "Trafo gücü", "sec", 1000, secenek=opt(*[(v, f"{v} kVA") for v in (160, 250, 400, 630, 800, 1000, 1250, 1600, 2000, 2500)]), goster={"mod": ["paralel", "ferro_trafo"]}),
    ctl("uk_pct", "Kısa devre gerilimi uk", "sayi", 6, min=4, max=8, adim=0.5, birim="%", goster={"mod": ["paralel"]}),
    ctl("qc_kvar", "Devredeki kondansatör gücü", "sayi", 350, min=25, max=1500, adim=25, birim="kvar", goster={"mod": ["paralel"]}),
    ctl("p_pct", "Kademe reaktörü", "sec", 7, secenek=opt((0, "reaktörsüz"), (5.67, "%5,67 (210 Hz)"), (7, "%7 (189 Hz)"), (14, "%14 (134 Hz)")), goster={"mod": ["paralel"]}),
    ctl("yuk_pct", "Trafonun aktif yükü", "sayi", 40, min=0, max=100, adim=5, birim="%", yardim="Dirençli yük rezonansı sönümler; gece ve hafta sonu (az yük) en kötü durumdur", goster={"mod": ["paralel"]}),
    ctl("kablo_m", "Ayırıcı ile trafo arasındaki kablo", "sayi", 300, min=5, max=3000, adim=5, birim="m", goster={"mod": ["ferro_trafo"]}),
    ctl("i0_pct", "Trafonun boşta akımı", "sayi", 1.0, min=0.2, max=3, adim=0.1, birim="%", goster={"mod": ["ferro_trafo"]}),
    ctl("anahtar", "Anahtarlama", "sec", "tek", secenek=opt(("tek", "Tek kutuplu (sigortalı ayırıcı, sigorta atması)"), ("uc", "Üç kutuplu (kesici / yük ayırıcısı)")), goster={"mod": ["ferro_trafo"]}),
    ctl("acik_faz", "Açık kalan faz sayısı", "sec", "bir", secenek=opt(("bir", "Bir faz açık, iki faz enerjili"), ("iki", "İki faz açık, bir faz enerjili")), goster={"mod": ["ferro_trafo"], "anahtar": ["tek"]}),
    ctl("sek_yuk_pct", "Sekonderdeki yük", "sayi", 0, min=0, max=30, adim=1, birim="%", goster={"mod": ["ferro_trafo"]}),
    ctl("notr", "Şebekenin yıldız noktası", "sec", "yalitilmis", secenek=opt(("yalitilmis", "yalıtılmış"), ("direnc", "direnç üzerinden topraklı"), ("dogrudan", "doğrudan topraklı")), goster={"mod": ["ferro_gt"]}),
    ctl("sonum", "Açık üçgen sargıda sönümleme direnci var", "onay", False, goster={"mod": ["ferro_gt"]}),
]
UN_OG = 34500.0
C_KABLO_UF_KM = 0.2


def buyutme(h: float, sk: float, qc: float, p: float, pyuk: float) -> float:
    """Harmonik akım kaynağından şebekeye (trafoya) akan akımın büyütme katsayısı. Birim: 400 V barada ohm."""
    u2 = 400.0 ** 2
    xs = u2 / sk; xc = u2 / qc
    zs = complex(0.06 * xs * math.sqrt(h), h * xs)                     # şebeke + trafo (direnç frekansla artar)
    zk = complex(0.004 * xc, h * p * xc - xc / h)                      # kondansatör (+ reaktör) kolu
    if pyuk > 0:
        r = u2 / pyuk
        zs = zs * r / (zs + r)                                         # yük direnci şebekeye paralel
    return abs(zk) / abs(zk + zs)


def run(p: dict) -> dict:
    mod = p.get("mod") if p.get("mod") in MOD else "paralel"
    return {"paralel": _paralel, "ferro_trafo": _ferro_trafo, "ferro_gt": _ferro_gt}[mod](p)


def _paralel(p: dict) -> dict:
    sn = num(p, "trafo_kva", 1000) * 1000; uk = num(p, "uk_pct", 6) / 100; qc = num(p, "qc_kvar", 350) * 1000; pp = num(p, "p_pct", 7) / 100
    pyuk = num(p, "yuk_pct", 40) / 100 * sn * 0.9
    sk = sn / uk
    h_r = 1 / math.sqrt(pp + qc / sk)
    h_s = 1 / math.sqrt(pp) if pp > 0 else None
    b = {h: buyutme(h, sk, qc, pp, pyuk) for h in (5, 7, 11, 13)}
    yakin = min((5, 7, 11, 13), key=lambda h: abs(h - h_r))
    risk = abs(h_r - yakin) / yakin <= 0.10
    an = [f"Trafonun kısa devre gücü Sk = Sn / uk = {fnum(sk / 1e6, 1)} MVA; devrede {fnum(qc / 1000, 0)} kvar kondansatör var. Harmonik üreten yüke (sürücü, doğrultucu) göre trafo endüktansı ile kondansatör paralel bağlıdır.",
          f"Paralel rezonans mertebesi h_r = " + (f"1/√(p + Qc/Sk) = {fnum(h_r, 2)}" if pp else f"√(Sk / Qc) = {fnum(h_r, 2)}") + f" ({fnum(h_r * 50, 0)} Hz). Bu frekansta paralel devrenin empedansı çok büyür: küçük bir harmonik akım büyük bir harmonik gerilim yaratır.",
          f"Büyütme katsayıları — 5. harmonik: {fnum(b[5], 1)} kat, 7.: {fnum(b[7], 1)} kat, 11.: {fnum(b[11], 1)} kat, 13.: {fnum(b[13], 1)} kat. 1'den büyükse yükün ürettiği harmonik akım trafoya büyüyerek gider; aynı akım kondansatörde de dolaşır."]
    if pp:
        an.append(f"Reaktörlü kademe, kondansatörle birlikte {fnum(h_s, 2)}. mertebeye ({fnum(h_s * 50, 0)} Hz) ayarlı bir seri devredir: bu frekansın üstündeki bütün harmoniklere endüktif görünür, yani 5. ve üstü harmoniklerle rezonansa giremez. Paralel rezonans {fnum(h_r, 2)}. mertebeye, harmoniksiz bölgeye iner.")
    else:
        an.append("Kademeler devreye girip çıktıkça Qc, dolayısıyla rezonans mertebesi değişir: gündüz sorunsuz çalışan pano, gece az yükte ve farklı kademede rezonansa girebilir. Kondansatör sigortalarının sebepsiz atması, kondansatörlerin şişmesi bunun belirtisidir.")
    kt = [C("Rezonans mertebesinin harmoniklerden uzaklığı", f"h_r = {fnum(h_r, 2)} ; en yakın harmonik {yakin}.", "5., 7., 11., 13. harmoniklerin ± %10'u dışında", not risk, "TS EN 61642 (harmoniklerden etkilenen şebekelerde kondansatör uygulaması)", "dogrulanacak"),
          C("5. ve 7. harmoniğin büyütülmesi", f"{fnum(b[5], 1)} kat / {fnum(b[7], 1)} kat", "≤ 1,5 kat (büyütme yok denecek kadar)", max(b[5], b[7]) <= 1.5 + 1e-9, "Uygulama ölçütü", "ikincil")]
    if pp:
        kt.append(C("Reaktörlü kademenin ayar frekansı", f"{fnum(h_s * 50, 0)} Hz ({fnum(h_s, 2)}. mertebe)", "en düşük baskın harmoniğin (5. → 250 Hz) altında", h_s < 4.9, "TS EN 61642", "dogrulanacak"))
    ds = ["Kompanzasyon panosu harmonik üretmez; var olan harmoniği büyütür. Harmonik yük oranı yüksekse (yaklaşık %15–20'nin üstü) kademeler reaktörlü seçilir.",
          "Rezonans mertebesi için pratik hesap: h_r = √(Sk / Qc). 1000 kVA, uk %6 trafoda 350 kvar → h ≈ 6,9: tam 7. harmoniğin üstü.",
          "%7 reaktör 189 Hz'e ayarlıdır ve 5. harmoniğin altında kalır; şebekede 3. harmonik baskınsa (tek fazlı elektronik yük) %14 (134 Hz) seçilir.",
          "Reaktörlü kademede kondansatör uçlarındaki gerilim yükselir (U / (1 − p)); bu yüzden 440 V ya da 480 V'luk kondansatör kullanılır.",
          "Az yük, rezonansın en tehlikeli olduğu zamandır: dirençli yük sönümleme sağlar; boşta trafo ve tam devredeki kondansatör en kötü birleşimdir."]
    hs = [1 + 0.1 * j for j in range(0, 191)]
    graf = [{"baslik": "Harmonik akımın büyütülmesi (şebekeye akan / üretilen)", "x_ad": "harmonik mertebesi", "y_ad": "büyütme katsayısı", "logy": True,
             "seriler": [{"ad": "bu ayarlar", "renk": "#dc2626", "pts": [[round(h, 1), round(max(buyutme(h, sk, qc, pp, pyuk), 0.01), 3)] for h in hs]},
                         {"ad": "kondansatör yokken", "renk": "#94a3b8", "kesik": True, "pts": [[1, 1], [20, 1]]}],
             "isaretler": [{"x": 5, "etiket": "5."}, {"x": 7, "etiket": "7."}, {"x": 11, "etiket": "11."}, {"x": 13, "etiket": "13."}]}]
    c = Cizim(900, 300, zemin=255)
    c.kutu(40, 90, 100, 60, "ŞEBEKE + TRAFO", f"Sk {fnum(sk / 1e6, 1)} MVA", "normal").bobin(150, 120, 5, True, "cizgi", "L (trafo)").hat("M140,120 H150").hat("M200,120 H760", "L1", w=3).yazi(450, 108, "AG ana bara 400 V", "#475569", 10.5, False, "middle")
    c.hat("M380,120 V150", "cizgi", hot=max(b.values()) > 1.5)
    if pp:
        c.bobin(380, 150, 3, False, "cizgi", f"reaktör %{fnum(pp * 100, 2).rstrip('0').rstrip(',')}").hat("M380,180 V190")
    c.kap(380, 190 if pp else 150, 240, "cizgi", False, f"Qc = {fnum(qc / 1000, 0)} kvar").hat("M380,240 V255").toprak(380, 255)
    c.hat("M560,120 V160").direnc(560, 160, "yük (sönümleme)", False, False, 40).hat("M560,200 V255").toprak(560, 255)
    c.hat("M700,120 V160", "ariza", hot=True).kutu(660, 160, 80, 44, "harmonik", "kaynağı", "gecersiz").hat("M700,204 V255").toprak(700, 255)
    c.yazi(300, 70, f"rezonans mertebesi h_r = {fnum(h_r, 2)} ({fnum(h_r * 50, 0)} Hz)", "ariza" if risk else "ok", 13, True, "middle")
    c.yazi(450, 288, f"5. harmonik {fnum(b[5], 1)} kat · 7. harmonik {fnum(b[7], 1)} kat büyüyor" if max(b[5], b[7]) > 1.5 else "5. ve 7. harmonik büyütülmüyor", "ariza" if max(b[5], b[7]) > 1.5 else "ok", 12, True, "middle")
    oz = [K("Rezonans mertebesi", fnum(h_r, 2), "bad" if risk else "ok", f"{fnum(h_r * 50, 0)} Hz"), K("5. harmonik büyütmesi", f"{fnum(b[5], 1)} kat", "ok" if b[5] <= 1.5 else "bad", ""), K("7. harmonik büyütmesi", f"{fnum(b[7], 1)} kat", "ok" if b[7] <= 1.5 else "bad", ""),
          K("Kısa devre gücü", f"{fnum(sk / 1e6, 1)} MVA", "info", "Sn / uk"), K("Kademe", f"%{fnum(pp * 100, 2)} reaktörlü" if pp else "reaktörsüz", "info", f"seri ayar {fnum(h_s * 50, 0)} Hz" if pp else "")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "grafikler": graf}


def _ferro_trafo(p: dict) -> dict:
    sn = num(p, "trafo_kva", 1000) * 1000; i0 = num(p, "i0_pct", 1.0) / 100; L = num(p, "kablo_m", 300)
    tek = p.get("anahtar") != "uc"; yuk = num(p, "sek_yuk_pct", 0)
    xm = UN_OG ** 2 / (sn * i0)                       # mıknatıslanma reaktansı (faz başına, Ω)
    cc = C_KABLO_UF_KM * 1e-6 * L / 1000
    xc = 1 / (OMEGA * cc)
    oran = xc / xm
    bolge = 0.03 <= oran <= 40
    risk = tek and bolge and yuk < 10
    an = [f"Trafo boşta ({fnum(sn / 1000, 0)} kVA, boşta akım %{fnum(i0 * 100, 1)}): mıknatıslanma reaktansı Xm = U² / (Sn · i0) = {fnum(xm / 1000, 0)} kΩ. Ayırıcı ile trafo arasında {fnum(L, 0)} m kablo: kapasitesi {fnum(cc * 1e9, 0)} nF, Xc = {fnum(xc / 1000, 0)} kΩ. Oran Xc / Xm = {fnum(oran, 2)}."]
    if tek:
        an += ["Tek kutuplu anahtarlamada (sigortalı ayırıcının tek tek açılması, bir sigortanın atması) bir ya da iki faz enerjili, diğeri açık kalır. Açık fazın kablosu, trafonun sargıları üzerinden enerjili fazlara seri bağlı bir kapasiteye dönüşür.",
               "Trafo çekirdeği doğrusal değildir: gerilim biraz yükselince doyar, endüktansı düşer, akım sıçrar; devre kapasiteyle birlikte kendiliğinden başka bir çalışma noktasına atlar ve orada kalır. Buna ferrorezonans denir.",
               ("Bu oranda ferrorezonans beklenir: açık fazda anma geriliminin 2–4 katına varan, bozuk biçimli ve sönmeyen gerilimler; trafodan uğultu, parafudrların patlaması, gerilim trafolarının yanması." if risk else
                "Bu ayarlarda ferrorezonans beklenmez: " + ("sekonderdeki yük salınımı sönümlüyor." if yuk >= 10 else "kapasite ile mıknatıslanma reaktansı oranı riskli aralığın dışında."))]
    else:
        an.append("Üç kutuplu anahtarlamada üç faz aynı anda açılır ve kapanır; kablonun kapasitesi sargılarla seri duruma gelmez. Ferrorezonansın bu türü oluşmaz.")
    # zaman bölgesi çözümü (birim değerler): kaynak E — seri Xc — (doymaya giren Xm ∥ kayıp ve yük direnci)
    S = None
    if tek:
        e_pu = 0.5 if p.get("acik_faz") != "iki" else 1.0
        rp = 1.0 / (0.0015 + yuk / 100)                  # boşta kayıp ≈ %0,15 Sn + sekonder yük
        S = max((zaman.ferro_sim(round(oran / i0, 4), round(i0, 5), round(rp, 4), e_pu, a) for a in (0.0, 90.0)), key=lambda s_: (s_["doyuyor"], s_["u_tepe"]))
        an.append(f"Zaman bölgesi çözümü (eşdeğer tek fazlı devre: açık fazı süren gerilim {fnum(e_pu, 1)} pu, seri kapasite Xc = {fnum(oran / i0, 0)} pu, mıknatıslanma reaktansı {fnum(1 / i0, 0)} pu ve diz akısı 1,2 pu, kayıp ve yük direnci {fnum(rp, 0)} pu): "
                  + (f"çekirdek her periyotta doyuyor ve salınım sönmüyor; açık fazdaki gerilimin tepe değeri {fnum(S['u_tepe'], 2)} pu (anma faz geriliminin tepe değerinin katı). Doğrusal hesap {fnum(S['u_dogrusal'], 2)} pu verirdi: fark, çekirdeğin doymasıyla devrenin başka bir çalışma noktasına atlamasıdır."
                     if S["doyuyor"] else f"salınım sönüyor, çekirdek doymada kalmıyor; açık fazda {fnum(S['u_tepe'], 2)} pu gerilim kalıyor (kapasite üzerinden endüklenen gerilim). Bu, yalnız denenen iki kapama anı ve bu eşdeğer devre için geçerlidir."))
    kt = [C("Anahtarlama biçimi", "tek kutuplu" if tek else "üç kutuplu", "kablo ile beslenen trafoda üç kutuplu anahtarlama (kesici, yük ayırıcısı) tercih edilir", (not tek) or not bolge or yuk >= 10, "IEEE C57.105; genel teknik literatür", "ikincil"),
          C("Kapasite / mıknatıslanma reaktansı oranı", f"Xc / Xm = {fnum(oran, 2)}", "ferrorezonans yaklaşık 0,03 – 40 aralığında beklenir (mertebe)", (not bolge) or not tek or yuk >= 10, "Genel teknik literatür (doğrusal olmayan olay; kesin sınır yoktur)", "tahmini"),
          C("Sekonderde sönümleyici yük", f"%{fnum(yuk, 0)}", "anma gücünün ≈ %10'u kadar dirençli yük salınımı söndürür", yuk >= 10 or not (tek and bolge), "Genel teknik literatür", "ikincil")]
    if S is not None:
        kt.append(C("Zaman bölgesi çözümü: açık fazdaki gerilim", f"tepe {fnum(S['u_tepe'], 2)} pu ; çekirdek " + ("sürekli doyuyor" if S["doyuyor"] else "doymada kalmıyor"), "kalıcı doyma olmamalı; gerilim ≤ ≈ 1,25 pu",
                    not S["doyuyor"] and S["u_tepe"] <= 1.25, "Doğrusal olmayan devre çözümü (öğretim modeli: parça parça doğrusal mıknatıslanma eğrisi, iki kapama anı)", "tahmini"))
    ds = ["Ferrorezonans üç şey bir araya gelince olur: doymaya girebilen demir çekirdek (boşta ya da az yüklü trafo), kapasite (kablo) ve tek ya da iki fazın açık kalması.",
          "Direk tipi trafoda sigortalı ayırıcı ile trafo arası kısa ve havai olduğundan kapasite küçüktür; köşk ve bina tipi merkezlerde kablo uzadıkça risk doğar.",
          "Önlemler: üç kutuplu anahtarlama; anahtarlama elemanını trafonun yanına koymak (kabloyu ayırıcının kaynak tarafında bırakmak); anahtarlama sırasında sekonderde yük bulundurmak.",
          "Belirtiler: trafodan alışılmadık yüksek ses, enerjisiz sanılan fazda gerilim, parafudr ve gerilim trafosu arızaları, ölçü aletlerinde anlamsız değerler.",
          "Ferrorezonans doğrusal olmayan bir olaydır: aynı devre, kapama anına ve çekirdekteki kalıcı akıya göre sönebilir ya da kalıcı salınıma geçebilir. Buradaki çözüm tek fazlı bir eşdeğer devredir; oran riskin mertebesini, çözüm ise olayın biçimini gösterir."]
    c = Cizim(900, 300, zemin=255)
    for k, (yy, col) in enumerate(((70, "L1"), (100, "L2"), (130, "L3"))):
        acik = tek and k == 2
        c.hat(f"M40,{yy} H200", col).yazi(22, yy + 4, f"L{k + 1}", col, 11, True)
        c.hat(f"M200,{yy} L{232 if acik else 240},{yy - (16 if acik else 0)}", col).hat(f"M240,{yy} H620", col, hot=risk and acik, hot_renk="mor")
        c.kap(330 + k * 40, yy, 255, "cizgi")
    c.yazi(215, 52, "ayırıcı", "#475569", 10.5, False, "middle").yazi(460, 190, f"kablo {fnum(L, 0)} m · {fnum(cc * 1e9, 0)} nF / faz", "#475569", 10.5)
    c.kutu(620, 40, 130, 70, "TRAFO (boşta)", f"Xm {fnum(xm / 1000, 0)} kΩ", "gecersiz" if risk else "normal").dikdortgen(620, 110, 130, 50, "#334155", None, 1.6).sarim(685, 140, "ucgen", "#334155", 14)
    c.yazi(450, 288, ("L3 açık: kablo kapasitesi sargılarla seri → ferrorezonans riski, açık fazda 2–4 kat gerilim" if risk else "ferrorezonans beklenmez"), "ariza" if risk else "ok", 12, True, "middle")
    oz = [K("Xc / Xm", fnum(oran, 2), "bad" if (bolge and tek) else "ok", "riskli aralık ≈ 0,03 – 40"), K("Kablo kapasitesi", f"{fnum(cc * 1e9, 0)} nF", "info", f"{fnum(L, 0)} m"), K("Mıknatıslanma reaktansı", f"{fnum(xm / 1000, 0)} kΩ", "info", f"boşta akım %{fnum(i0 * 100, 1)}"),
          K("Ferrorezonans", "beklenir" if risk else "beklenmez", "bad" if risk else "ok", "tek kutuplu anahtarlama" if tek else "üç kutuplu anahtarlama")]
    graf = []
    if S is not None:
        oz.append(K("Açık fazda gerilim (çözüm)", f"{fnum(S['u_tepe'], 2)} pu", "bad" if (S["doyuyor"] or S["u_tepe"] > 1.25) else "ok", "çekirdek doyuyor" if S["doyuyor"] else "sönüyor"))
        graf = [{"baslik": "Açık fazdaki gerilim — zaman bölgesi çözümü", "x_ad": "zaman (periyot)", "y_ad": "gerilim (pu, tepe)", "zaman": True, "seriler": [{"ad": "açık faz – toprak gerilimi", "renk": "#dc2626" if S["doyuyor"] else "#15803d", "pts": [[t, round(v, 3)] for t, v in zip(S["t"], S["u"])]}],
                 "yatay": [{"y": 1.0, "etiket": "anma faz gerilimi (tepe)", "renk": "#64748b"}, {"y": -1.0, "etiket": "", "renk": "#64748b"}]},
                {"baslik": "Çekirdekteki akı", "x_ad": "zaman (periyot)", "y_ad": "akı (pu)", "zaman": True, "seriler": [{"ad": "akı", "renk": "#7c3aed", "pts": [[t, round(v, 3)] for t, v in zip(S["t"], S["aki"])]}],
                 "yatay": [{"y": 1.2, "etiket": "doyma (diz akısı)", "renk": "#dc2626"}, {"y": -1.2, "etiket": "", "renk": "#dc2626"}]}]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "grafikler": graf}


def _ferro_gt(p: dict) -> dict:
    notr = p.get("notr") if p.get("notr") in ("yalitilmis", "direnc", "dogrudan") else "yalitilmis"
    sonum = bool(p.get("sonum"))
    risk = notr == "yalitilmis" and not sonum
    an = ["Gerilim trafoları faz ile toprak arasına bağlıdır; her birinin primeri, doymaya girebilen bir endüktanstır. Şebekenin (baraların, kısa kabloların) toprağa kapasitesi bu endüktanslarla paralel durur.",
          ("Yıldız noktası yalıtılmış şebekede yıldız noktasını toprağa bağlayan başka bir şey yoktur: bir anahtarlama ya da geçici toprak teması gerilim trafolarından birini doyurur ve yıldız noktası salınmaya başlar. Faz–toprak gerilimleri bozulur ve yükselir; "
           "gerilim trafosunun primeri aşırı akımla ısınır, sigortası atar ya da yanar." if notr == "yalitilmis" else
           "Yıldız noktası topraklı şebekede (direnç ya da doğrudan) yıldız noktasının potansiyeli sabittir; gerilim trafolarının doyması salınıma yol açamaz. Bu tür ferrorezonans oluşmaz."),
          ("Önlem: gerilim trafolarının üçüncü sargıları açık üçgen bağlanır ve bu açık üçgenin uçlarına bir sönümleme direnci konur. Normalde açık üçgende gerilim yoktur (direnç akım çekmez); yıldız noktası kaydığında 3·U0 gerilimi dirençten akım geçirir ve salınımın enerjisini tüketir."
           if notr == "yalitilmis" else "Açık üçgen sargı bu şebekede toprak arızasının algılanması (3·U0) için kullanılır.")]
    kt = [C("Açık üçgen sargıda sönümleme direnci", "var" if sonum else "yok", "yalıtılmış (ve kompanze) şebekede faz–toprak bağlı gerilim trafolarında gerekir", (sonum or notr != "yalitilmis"), "TS EN 61869-3; üretici uygulama kılavuzları (tipik 25–60 Ω, birkaç yüz W)", "ikincil"),
          C("Gerilim faktörü", "1,9 · Un / 8 h" if notr == "yalitilmis" else "1,9 · Un / 30 s" if notr == "direnc" else "1,5 · Un / 30 s", "şebekenin yıldız noktası durumuna göre seçilir", None, "TS EN 61869-3 (anma gerilim faktörleri)", "dogrulanacak")]
    ds = ["Bu olay küçük, yalıtılmış şebekelerde görülür: sanayi iç dağıtımı, boşta enerjilenen bara, jeneratör barası. Fiderler devreye girince kapasite büyür ve olay kendiliğinden kaybolabilir.",
          "Belirtisi: toprak arızası yokken “toprak arızası” alarmı, faz–toprak gerilimlerinin dengesiz ve oynak okunması, gerilim trafosu primer sigortalarının sebepsiz atması.",
          "Sönümleme direnci açık üçgene bağlanır, yıldız bağlı ölçü sargısına değil; gücü sürekli toprak arızasında (3·U0 = 100 V) yanmayacak biçimde seçilir.",
          "Faz–faz bağlı (V bağlı) gerilim trafoları toprağa bağlı olmadığı için bu olaya girmez; ama toprak arızası gerilimini de ölçemez."]
    c = Cizim(900, 300, zemin=255)
    for k, (yy, col) in enumerate(((60, "L1"), (85, "L2"), (110, "L3"))):
        c.hat(f"M40,{yy} H820", col).yazi(22, yy + 4, f"L{k + 1}", col, 11, True)
        x = 200 + k * 70
        c.hat(f"M{x},{yy} V150").bobin(x, 150, 4, False, "ariza" if risk else "cizgi").hat(f"M{x},190 V255")
        c.kap(560 + k * 60, yy, 255, "cizgi")
    c.toprak(270, 255).yazi(200, 232, "gerilim trafoları (faz–toprak)", "#475569", 10.5).yazi(620, 232, "baraların toprağa kapasitesi", "#475569", 10.5, False, "middle")
    c.kutu(360, 150, 150, 46, "açık üçgen sargı", "sönümleme direnci " + ("VAR" if sonum else "YOK"), "acti" if sonum else ("gecersiz" if notr == "yalitilmis" else "normal"))
    c.yazi(450, 288, "yıldız noktası salınıyor: ferrorezonans" if risk else "kararlı", "ariza" if risk else "ok", 12, True, "middle")
    oz = [K("Şebekenin yıldız noktası", {"yalitilmis": "yalıtılmış", "direnc": "dirençli", "dogrudan": "doğrudan"}[notr], "info", ""), K("Sönümleme direnci", "var" if sonum else "yok", "ok" if (sonum or notr != "yalitilmis") else "bad", "açık üçgende"),
          K("Ferrorezonans", "beklenir" if risk else "beklenmez", "bad" if risk else "ok", "gerilim trafosu + bara kapasitesi")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne()}
