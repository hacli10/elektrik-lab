"""Laboratuvar konusu — frekans konvertörü (sürücü): motor ucundaki gerilim yükselmesi, yüksek frekanslı kaçak akım, koruma iletkeni,
kaçak akım rölesi, ekran bağlantısı.

Mertebe modelleri: (1) yansıma — kritik kablo boyu l_kr = v · tr / 2 (v ≈ 150 m/µs); L ≥ l_kr ise motor ucunda Upk ≈ (1 + Γ)·Udc, Γ ≈ 0,9.
(2) ortak mod kaçak akımı — her anahtarlamada kablo kapasitesi Udc/3 basamağıyla dolar: I(ort) ≈ 2 · C · Udc · fsw.
Değerler üretici verisinin yerini tutmaz."""
from __future__ import annotations

import math

from .core import C, K, ctl, fnum, num, opt

ID = "surucu"
BASLIK = "Sürücü (frekans konvertörü)"
IKON = "🎚"
GIRIS = ("Sürücü motora sinüs değil, saniyede binlerce kez anahtarlanan dik kenarlı darbeler verir. Bu darbeler uzun kabloda yansıyıp motor ucunda gerilimi "
         "ikiye katlar, kablonun kapasitesi üzerinden koruma iletkenine yüksek frekanslı akım akıtır. Kabloyu, filtreyi, röleyi ve koruma iletkenini seçip sonucu görün.")

KONTROLLER = [
    ctl("pn_kw", "Motor gücü", "sec", 22, secenek=opt(*[(v, f"{v:g} kW") for v in (1.5, 4, 7.5, 11, 15, 22, 37, 55, 75, 110, 160, 250)])),
    ctl("l_m", "Motor kablosu uzunluğu", "sayi", 50, min=2, max=400, adim=1, birim="m"),
    ctl("kablo", "Motor kablosu", "sec", "ekranli", secenek=opt(("ekranli", "Ekranlı (simetrik, 3 faz + PE + ekran)"), ("ekransiz", "Ekransız"))),
    ctl("ekran", "Ekranın bağlanışı", "sec", "360", secenek=opt(("360", "İki uçta 360° kelepçeyle"), ("pigtail", "Uzun örgü kuyruğuyla (pigtail)"), ("tek", "Yalnız bir uçta")), goster={"kablo": ["ekranli"]}),
    ctl("fsw_khz", "Anahtarlama frekansı", "sayi", 4, min=1, max=16, adim=0.5, birim="kHz"),
    ctl("tr_us", "Darbe yükselme süresi", "sayi", 0.1, min=0.05, max=1, adim=0.05, birim="µs", yardim="IGBT: 0,05–0,2 µs"),
    ctl("filtre", "Çıkış filtresi", "sec", "yok", secenek=opt(("yok", "yok"), ("dvdt", "du/dt filtresi (çıkış reaktörü)"), ("sinus", "sinüs filtresi"))),
    ctl("motor_yalitim", "Motor yalıtımı", "sec", "surucu", secenek=opt(("standart", "Standart motor"), ("surucu", "Sürücüyle çalışmaya uygun (güçlendirilmiş yalıtım)"))),
    ctl("emc", "Girişte EMC (RFI) filtresi var", "onay", True),
    ctl("rcd_ma", "Kaçak akım rölesi", "sec", 0, secenek=opt((0, "yok"), (30, "30 mA"), (300, "300 mA"))),
    ctl("rcd_tip", "Röle tipi", "sec", "A", secenek=opt(("AC", "AC"), ("A", "A"), ("F", "F"), ("B", "B")), goster={"rcd_ma": [30, 300]}),
    ctl("spe", "Koruma iletkeni kesiti", "sec", 10, secenek=opt(*[(v, f"{v:g} mm² Cu") for v in (2.5, 4, 6, 10, 16, 25, 35)])),
    ctl("cift_pe", "İkinci (paralel) koruma iletkeni var", "onay", False),
]
UDC = 1.35 * 400
V_YAYILMA = 150.0       # m/µs
GAMMA = 0.9
C_NF_M = {"ekranli": 0.25, "ekransiz": 0.08}       # faz–toprak kapasitesi, nF/m (tipik; tahmini)
EMC_KACAK_MA = 25.0                                  # girişteki EMC filtresinin 50 Hz kaçak akımı (tipik; üretici verisi esastır)
LIM = {"standart": 1000.0, "surucu": 1560.0}


def run(p: dict) -> dict:
    L = num(p, "l_m", 50); fsw = num(p, "fsw_khz", 4) * 1000; tr = num(p, "tr_us", 0.1)
    kablo = p.get("kablo") if p.get("kablo") in C_NF_M else "ekranli"
    filtre = p.get("filtre") if p.get("filtre") in ("yok", "dvdt", "sinus") else "yok"
    tr_e = tr if filtre == "yok" else max(tr, 1.5)                   # du/dt filtresi kenarı yumuşatır
    l_kr = V_YAYILMA * tr_e / 2
    if filtre == "sinus":
        upk = math.sqrt(2) * 400
    else:
        upk = UDC * (1 + GAMMA * min(1.0, L / l_kr))
    dvdt = 0.8 * (upk if filtre != "sinus" else 0) / tr_e if filtre != "sinus" else 0.0      # V/µs (yaklaşık)
    lim = LIM[p.get("motor_yalitim") if p.get("motor_yalitim") in LIM else "surucu"]
    c_tot = C_NF_M[kablo] * L * 1e-9
    i_hf = 0.0 if filtre == "sinus" else 2 * c_tot * UDC * fsw                 # A, ortalama (mertebe)
    i_50 = EMC_KACAK_MA / 1000.0 if p.get("emc", True) else 0.002
    i_top = i_hf + i_50
    rcd = int(num(p, "rcd_ma", 0)); tip = p.get("rcd_tip", "A")
    spe = num(p, "spe", 10); cift = bool(p.get("cift_pe"))
    an = [f"Sürücünün ara devre gerilimi Udc ≈ 1,35 × 400 = {fnum(UDC, 0)} V. Çıkıştaki her darbe 0 → {fnum(UDC, 0)} V'a {fnum(tr, 2)} µs'de çıkar; saniyede {fnum(fsw, 0)} kez.",
          f"Darbe kabloda ≈ 150 m/µs hızla ilerler. Motorun dalga empedansı kablonunkinden çok büyük olduğu için darbe motor ucunda yansır ve üstüne biner. Kablo, kritik boydan (v · tr / 2 = {fnum(l_kr, 1)} m) uzunsa yansıma tamdır.",
          (f"Sinüs filtresi darbeleri süzer: motor ucunda neredeyse sinüs biçimli gerilim vardır, tepe ≈ {fnum(upk, 0)} V." if filtre == "sinus" else
           f"Bu kabloda ({fnum(L, 0)} m) motor ucundaki tepe gerilim ≈ {fnum(upk, 0)} V'tur ({fnum(upk / UDC, 2)} × Udc)" + (" — du/dt filtresi kenarı yumuşattığı için kritik boy uzadı." if filtre == "dvdt" else ".")),
          f"Kablonun faz–toprak kapasitesi ≈ {fnum(c_tot * 1e9, 0)} nF ({'ekranlı kabloda ekran her faza çok yakındır' if kablo == 'ekranli' else 'ekransız kabloda kapasite küçük ama dağınık ve denetimsizdir'}). "
          f"Her anahtarlamada bu kapasite dolup boşalır: koruma iletkeni / ekran üzerinden sürücüye dönen yüksek frekanslı akım ≈ {fnum(i_hf * 1000, 0)} mA (ortalama, mertebe).",
          f"Buna girişteki EMC filtresinin 50 Hz kaçak akımı eklenir (≈ {fnum(i_50 * 1000, 0)} mA). Sağlam, arızasız bir sürücü koruma iletkeninden sürekli ≈ {fnum(i_top * 1000, 0)} mA akıtır."]
    kt = [C("Motor ucundaki tepe gerilim", f"≈ {fnum(upk, 0)} V", f"≤ {fnum(lim, 0)} V  ({'standart motor' if lim < 1100 else 'sürücüye uygun motor'})", upk <= lim + 1e-9,
            "TS EN 60034-17 (standart motor ≈ 1000 V tepe) ; TS EN 60034-25 (güçlendirilmiş yalıtım, eğri A ≈ 1560 V)", "dogrulanacak")]
    # koruma iletkeni: dokunma akımı > 3,5 mA
    pe_ok = spe >= 10 or cift
    kt.append(C("Koruma iletkeni (kaçak akım > 3,5 mA)", f"{fnum(spe, 1)} mm² Cu" + (" + ikinci PE" if cift else "") + f" ; koruma iletkeni akımı ≈ {fnum(i_top * 1000, 0)} mA", "≥ 10 mm² Cu (16 mm² Al) ya da ikinci koruma iletkeni", pe_ok if i_top > 0.0035 else True,
                "TS EN 61800-5-1 m.4.3.5.5 ; TS HD 60364-5-54 m.543.7", "dogrulanacak"))
    if i_top > 0.0035 and not pe_ok:
        an.append("Koruma iletkeni koparsa bu akımın tamamı gövdeye dokunan kişiden geçer. Bu yüzden kaçak akımı 3,5 mA'i geçen cihazlarda koruma iletkeni güçlendirilir: kopması olasılığı azaltılır ya da yedeklenir.")
    if rcd:
        tip_ok = tip == "B"
        kt.append(C("Kaçak akım rölesi tipi", f"tip {tip}", "tip B (üç fazlı sürücüde DC bara arızası düz DC kaçak üretir)", tip_ok, "TS EN 62423 ; TS HD 60364-5-53 m.531.3.3 ; sürücü üreticisi", "dogrulanacak"))
        kt.append(C("Röle eşiği – boşta kaçak", f"boşta kaçak ≈ {fnum(i_top * 1000, 0)} mA", f"≤ 0,3 · IΔn = {fnum(0.3 * rcd, 0)} mA", i_top * 1000 <= 0.3 * rcd, "TS HD 60364-5-53 m.531.3.2", "dogrulanacak"))
        if i_top * 1000 > 0.3 * rcd:
            an.append(f"{rcd} mA röle bu boşta kaçakla sebepsiz açar. Sürücü devresinde 30 mA röle çoğu zaman kullanılamaz; yangın koruması için 300 mA tip B seçilir, can güvenliği koruma iletkeni ve eşpotansiyel dengelemeyle sağlanır.")
    if kablo == "ekranli":
        ek = p.get("ekran", "360")
        kt.append(C("Ekran bağlantısı", {"360": "iki uçta 360° kelepçe", "pigtail": "örgü kuyruğu (pigtail)", "tek": "yalnız bir uçta"}[ek], "iki uçta, geniş yüzeyli (360°) bağlantı", ek == "360", "TS EN 61800-3 (EMC) ; sürücü üreticisi montaj kuralları", "dogrulanacak"))
        if ek != "360":
            an.append("Yüksek frekanslı akım için önemli olan direnç değil endüktanstır: birkaç santimetrelik örgü kuyruğu megahertz düzeyinde onlarca ohm eder. Ekran iki uçta, kablonun bütün çevresini saran kelepçeyle bağlanmazsa akım kendine başka yol arar: "
                      "motor yatakları, makine gövdesi, sinyal kabloları.")
    else:
        kt.append(C("Motor kablosu", "ekransız", "ekranlı simetrik kablo (EMC ve yatak akımları için)", False, "TS EN 61800-3 (EMC) ; sürücü üreticisi montaj kuralları", "dogrulanacak"))
        an.append("Ekransız kabloda yüksek frekanslı akımın dönüş yolu belirsizdir: yapı çeliği, kablo tavası, komşu kablolar. Parazit yayılır, ölçü ve haberleşme devreleri etkilenir.")
    if num(p, "pn_kw", 22) >= 100:
        an.append("Büyük motorlarda (≈ 100 kW ve üstü) ortak mod gerilimi mil ile gövde arasında gerilim oluşturur; akım yataklardan geçip yüzeyi oyar. Önlem: yalıtılmış yatak (tahrik karşı tarafı), mil topraklama fırçası, ortak mod filtresi.")
    ds = ["Sürücülü motorda üç ayrı “topraklama” sorunu vardır: can güvenliği (koruma iletkeni), yüksek frekanslı akımın dönüş yolu (ekran ve eşpotansiyel) ve motor yalıtımı (yansıyan gerilim).",
          "Koruma iletkeninin kesiti 50 Hz için, ekranın bağlanış biçimi megahertz için önemlidir. İkisi birbirinin yerini tutmaz.",
          "Kablo uzadıkça hem motor ucundaki gerilim hem kaçak akım artar. Uzun kabloda çıkış reaktörü ya da sinüs filtresi ikisini birden çözer.",
          "Sürücü devresine 30 mA tip AC röle koymak iki kez yanlıştır: boşta kaçakla sebepsiz açar, gerçek DC arızada ise körleşip açmaz.",
          "Motorun topraklaması yalnız sarı-yeşil iletkenle bırakılmaz; gövde, tava ve makine şasesi kısa ve geniş bağlantılarla eşpotansiyel yapılır."]
    # motor ucundaki gerilim (gösterim): basamak + sönümlü salınım
    f_ring = V_YAYILMA / (4 * max(L, 1.0))            # MHz
    asim = (upk - UDC) if filtre != "sinus" else 0.0
    tmax = max(6 * tr_e, 6.0 / max(f_ring, 0.05))
    pts_s, pts_m = [], []
    for j in range(0, 201):
        t = j * tmax / 200
        vs = UDC * min(1.0, t / tr)
        td = t - L / V_YAYILMA
        vm = 0.0 if td < 0 else UDC * min(1.0, td / tr_e) + asim * math.exp(-td * f_ring * 1.6) * math.cos(2 * math.pi * f_ring * td) * min(1.0, td / tr_e)
        pts_s.append([round(t, 3), round(vs, 0)]); pts_m.append([round(t, 3), round(vm, 0)])
    graf = [] if filtre == "sinus" else [{"baslik": "Bir darbenin sürücü çıkışında ve motor ucunda görünüşü (gösterim)", "x_ad": "zaman (µs)", "y_ad": "gerilim (V)", "seriler": [{"ad": "sürücü çıkışı", "renk": "#94a3b8", "kesik": True, "pts": pts_s}, {"ad": "motor ucu", "renk": "#dc2626", "pts": pts_m}],
             "yatay": [{"y": lim, "etiket": f"motor yalıtım sınırı {fnum(lim, 0)} V", "renk": "#15803d"}], "ymin": 0}]
    oz = [K("Motor ucunda tepe gerilim", f"{fnum(upk, 0)} V", "ok" if upk <= lim else "bad", f"sınır {fnum(lim, 0)} V ; kritik boy {fnum(l_kr, 1)} m"),
          K("Gerilim yükselme hızı", f"{fnum(dvdt / 1000, 1)} kV/µs" if dvdt else "düşük", "info", "motor ucunda, yaklaşık"),
          K("Yüksek frekanslı kaçak akım", f"{fnum(i_hf * 1000, 0)} mA", "warn" if i_hf > 0.03 else "ok", f"kablo kapasitesi {fnum(c_tot * 1e9, 0)} nF"),
          K("Koruma iletkeninde sürekli akım", f"{fnum(i_top * 1000, 0)} mA", "bad" if (i_top > 0.0035 and not pe_ok) else "ok", "3,5 mA üstü: güçlendirilmiş PE"),
          K("Kaçak akım rölesi", f"{rcd} mA tip {tip}" if rcd else "yok", ("ok" if (tip == "B" and i_top * 1000 <= 0.3 * rcd) else "bad") if rcd else "info", "sebepsiz açma / körleşme" if rcd else "")]
    sahne = {"tip": "surucu", "ekranli": kablo == "ekranli", "ekran": p.get("ekran", "360"), "filtre": filtre, "emc": bool(p.get("emc", True)), "rcd": rcd, "rcd_tip": tip, "rcd_ok": (not rcd) or (tip == "B" and i_top * 1000 <= 0.3 * rcd),
             "i_hf": f"{fnum(i_hf * 1000, 0)} mA", "i_top": f"{fnum(i_top * 1000, 0)} mA", "upk": f"{fnum(upk, 0)} V", "upk_ok": upk <= lim, "pe_ok": pe_ok or i_top <= 0.0035, "l": L, "spe": spe, "cift": cift}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "grafikler": graf}
