"""Laboratuvar konusu — kısmi boşalma ölçümü: deney devresi (varyak, deney trafosu, blokaj empedansı, kuplaj kondansatörü, ölçme
empedansı / kuplör, ölçü cihazı, kalibratör), ölçme yöntemi ve faz çözümlü boşalma desenleri.

Devre (TS EN 60270): deney nesnesi Ca ile kuplaj kondansatörü Ck paraleldir. Nesnenin içinde bir boşalma olduğunda uçlardaki gerilim
çok kısa süre çöker; eksilen yükü Ck tamamlar. Bu yük darbesi Ck'ya seri ölçme empedansından (kuplör) geçer ve ölçülür.
  görünür yük            q  = Cb·ΔUc                 (Cb: boşlukla seri yalıtımın kapasitesi, ΔUc: boşluk gerilimindeki çöküş)
  kuplöre ulaşan pay     qm = q · Ck / (Ca + Ck)     (Ck küçükse duyarlılık düşer; kalibrasyon ölçeği düzeltir, gürültüyü düzeltmez)
  boşlukta alan          Uc = U / (1 + (t − d) / (εr·d))        (düz boşluk, alana dik)
  boşluğun delinmesi     Paschen (hava, 1 bar): Ud ≈ 24,22·(p·d) + 6,08·√(p·d)  kV tepe  (p·d: bar·cm)
Desenler, boşluk gerilimi başlama değerini her aştığında bir boşalma üreten kapasitif model ile zaman bölgesinde hesaplanır.
Dayanak: TS EN 60270; TS EN 62271-200 m.7.101; kabul düzeyleri TEDAŞ-MLZ/96-018.B, 99-031.B (resmi)."""
from __future__ import annotations

import math
import random

from .cizim import Cizim
from .core import C, K, OMEGA, ctl, fnum, num, opt

ID = "pd"
BASLIK = "Kısmi boşalma — devre ve desenler"
IKON = "✨"
GIRIS = ("Kısmi boşalma ölçümü bir devre işidir: varyak gerilimi ayarlar, deney trafosu yükseltir, kuplaj kondansatörü boşalma darbesine yol verir, kuplör onu ölçü cihazına taşır. "
         "Devreyi kurun, kalibre edin, gerilimi yükseltin; sonra kusurun türüne göre ekranda oluşan deseni okuyun.")

EPS0 = 8.854e-12
KUSUR = {"yok": "Kusur yok", "bosluk": "Katı yalıtım içinde boşluk (hava kabarcığı, ayrılma)", "yuzey": "Yüzey boşalması (yalıtkan yüzeyi boyunca)",
         "korona_yg": "Korona — gerilimli tarafta sivri uç", "korona_toprak": "Korona — topraklı tarafta sivri uç", "yuzen": "Yüzen potansiyelli metal parça", "kontak": "Gevşek bağlantı / kötü kontak"}
DEVRE = {"kuplaj": "Ölçme empedansı kuplaj kondansatörüyle seri (nesnenin bir ucu topraklı)", "nesne": "Ölçme empedansı deney nesnesiyle seri (nesne topraktan yalıtılmış)", "kopru": "Dengeli (köprü) devre — iki kolda ölçme empedansı"}
# başlama gerilimleri: işletme faz–toprak geriliminin katı (boşluk için geometriden hesaplanır)
UI = {"yuzey": 0.60, "korona_yg": 0.70, "korona_toprak": 0.80, "yuzen": 0.50, "kontak": 0.05}

KONTROLLER = [
    ctl("asama", "Deney aşaması", "sec", "olcme", secenek=opt(("kalibrasyon", "Kalibrasyon (gerilim yok, kalibratör bağlı)"), ("on", "Ön gerilim"), ("olcme", "Ölçme"))),
    ctl("ur_kv", "Deney nesnesinin anma gerilimi Ur", "sec", 36.0, secenek=opt((12.0, "12 kV"), (17.5, "17,5 kV"), (36.0, "36 kV"))),
    ctl("nesne", "Deney nesnesi", "sec", "hucre", secenek=opt(("hucre", "Hücre fazı (gövde topraklı)"), ("bilesen", "Topraktan yalıtılabilen bileşen (mesnet izolatörü, ölçü trafosu)"))),
    ctl("devre", "Ölçme devresi", "sec", "kuplaj", secenek=opt(*DEVRE.items())),
    ctl("ca_pf", "Deney nesnesinin kapasitesi Ca", "sayi", 300, min=20, max=5000, adim=10, birim="pF"),
    ctl("ck_pf", "Kuplaj kondansatörü Ck", "sec", 1000, secenek=opt((100, "100 pF"), (500, "500 pF"), (1000, "1000 pF"), (2000, "2000 pF"))),
    ctl("trafo_kv", "Deney trafosu (0,4 kV / …)", "sec", 100, secenek=opt((50, "50 kV"), (100, "100 kV"))),
    ctl("trafo_kva", "Deney trafosunun gücü", "sec", 5, secenek=opt((2, "2 kVA"), (5, "5 kVA"), (10, "10 kVA"), (20, "20 kVA"))),
    ctl("variak", "Varyak konumu", "sayi", 22.9, min=0, max=100, adim=0.1, birim="%", yardim="çıkış gerilimi = konum × deney trafosunun anma gerilimi"),
    ctl("kalibre", "Devre bu bağlantıyla kalibre edildi", "onay", True),
    ctl("q0_pc", "Kalibratörün verdiği yük q0", "sec", 20, secenek=opt((5, "5 pC"), (10, "10 pC"), (20, "20 pC"), (50, "50 pC"), (100, "100 pC"))),
    ctl("sinir_pc", "Kabul sınırı", "sec", 20, secenek=opt((5, "5 pC"), (10, "10 pC"), (20, "20 pC"), (50, "50 pC"))),
    ctl("kusur", "Deney nesnesindeki kusur", "sec", "yok", secenek=opt(*KUSUR.items())),
    ctl("d_mm", "Boşluğun kalınlığı (alan yönünde)", "sayi", 0.5, min=0.05, max=2, adim=0.05, birim="mm", goster={"kusur": ["bosluk"]}),
    ctl("a_mm", "Boşluğun çapı", "sayi", 2, min=0.5, max=8, adim=0.5, birim="mm", goster={"kusur": ["bosluk"]}),
    ctl("t_mm", "Yalıtımın kalınlığı", "sayi", 10, min=3, max=30, adim=1, birim="mm", goster={"kusur": ["bosluk"]}),
    ctl("er", "Yalıtkanın bağıl dielektrik sabiti εr", "sec", 4.0, secenek=opt((2.3, "2,3 (XLPE)"), (4.0, "4 (epoksi)"), (6.0, "6 (porselen)")), goster={"kusur": ["bosluk"]}),
    ctl("gurultu_pc", "Ortamın taban gürültüsü", "sayi", 2, min=0.5, max=50, adim=0.5, birim="pC", yardim="ekranlı odada 1–2 pC; açık atölyede 10 pC ve üstü"),
    ctl("filtre", "Varyak çıkışında filtre ve blokaj empedansı var", "onay", True),
    ctl("korona_onlem", "Yüksek gerilim bağlantıları korona halkalı / kalın borulu", "onay", True),
]


def paschen_kv(d_mm: float, p_bar: float = 1.0) -> float:
    """Hava boşluğunun delinme gerilimi (kV tepe)."""
    pd = p_bar * d_mm / 10.0
    return 24.22 * pd + 6.08 * math.sqrt(pd)


def bosluk(u_kv: float, d: float, a: float, t: float, er: float) -> dict:
    """Katı yalıtımdaki düz boşluk: başlama gerilimi (kV etken), boşluk gerilimi tepe değeri, görünür yük (pC)."""
    oran = 1.0 / (1.0 + (t - d) / (er * d))                 # Uc / U
    ud = paschen_kv(d)
    pdiv = ud / oran / math.sqrt(2)
    cb = EPS0 * er * math.pi * (a / 2e3) ** 2 / ((t - d) / 1e3) * 1e12      # pF
    du = 0.8 * ud                                           # boşalmada gerilim artık değere (≈ %20) düşer
    return {"oran": oran, "ud": ud, "pdiv": pdiv, "pdev": 0.8 * pdiv, "cb": cb, "q": cb * du * 1000, "uc_tepe": u_kv * math.sqrt(2) * oran}


def desen(kusur: str, u_kv: float, u0_kv: float, B: dict | None, rng: random.Random, cevrim: int = 40) -> list[tuple[float, float]]:
    """Faz çözümlü desen: (faz açısı °, yük pC) listesi."""
    pts: list[tuple[float, float]] = []
    if kusur == "bosluk" and B:
        vq = 0.0; ui = B["ud"]; ur = 0.2 * B["ud"]
        if B["uc_tepe"] < ui:                                # boşluk gerilimi delinme değerine ulaşmıyor: boşalma yok
            return pts
        for _ in range(cevrim):
            for k in range(0, 360, 2):
                v = B["uc_tepe"] * math.sin(math.radians(k)) + vq
                if abs(v) >= ui * (1 + 0.10 * rng.gauss(0, 1)):
                    sg = 1 if v > 0 else -1
                    dv = abs(v) - ur
                    vq -= sg * dv
                    pts.append((k + rng.uniform(0, 2), sg * B["cb"] * dv * 1000))
        return pts
    ui = UI.get(kusur, 9e9) * u0_kv
    if u_kv < ui:
        return pts
    k = u_kv / ui
    if kusur == "yuzey":                                    # eşikler iki yarım dalgada farklı: bir yanda seyrek ve büyük, öbür yanda sık ve küçük
        vq = 0.0; tepe = k
        for _ in range(cevrim):
            for ph in range(0, 360, 2):
                v = tepe * math.sin(math.radians(ph)) + vq
                esik = (1.0 if v > 0 else 0.55) * (1 + 0.25 * rng.gauss(0, 1))
                if abs(v) >= abs(esik):
                    sg = 1 if v > 0 else -1
                    dv = abs(v) - 0.15
                    vq -= sg * dv
                    pts.append((ph + rng.uniform(0, 2), sg * 55 * dv * (1 + 0.3 * rng.gauss(0, 1))))
        return pts
    if kusur in ("korona_yg", "korona_toprak"):
        merkez = 270 if kusur == "korona_yg" else 90
        yari = math.degrees(math.acos(min(1.0, 1 / k)))
        n = int(8 * (k - 1) * 10) + 2
        for _ in range(cevrim // 4):
            for j in range(n):
                ph = merkez + rng.uniform(-yari, yari)
                pts.append((ph, (-1 if merkez == 270 else 1) * 12 * (1 + 0.07 * rng.gauss(0, 1))))
            if k > 1.8:                                     # yüksek gerilimde karşı yarım dalgada seyrek, büyük boşalmalar
                for j in range(2):
                    pts.append(((merkez + 180) % 360 + rng.uniform(-20, 20), (1 if merkez == 270 else -1) * 160 * (1 + 0.3 * rng.gauss(0, 1))))
        return pts
    if kusur == "yuzen":
        n = min(4, 1 + int(k))
        for _ in range(cevrim // 2):
            for j in range(n):
                kay = (j - (n - 1) / 2) * 16 + rng.uniform(-3, 3)
                pts.append((kay % 360, 260 * (1 + 0.03 * rng.gauss(0, 1))))
                pts.append((180 + kay, -260 * (1 + 0.03 * rng.gauss(0, 1))))
        return pts
    if kusur == "kontak":
        for _ in range(cevrim * 3):
            ph = rng.choice((0, 180)) + rng.gauss(0, 9)
            pts.append((ph % 360, rng.choice((-1, 1)) * rng.uniform(15, 280)))
    return pts


def run(p: dict) -> dict:
    asama = p.get("asama") if p.get("asama") in ("kalibrasyon", "on", "olcme") else "olcme"
    ur = num(p, "ur_kv", 36.0); u0 = ur / math.sqrt(3)
    u_on, u_olc = 1.3 * u0, 1.1 * u0
    ca, ck = num(p, "ca_pf", 300), num(p, "ck_pf", 1000)
    tkv, tkva = num(p, "trafo_kv", 100), num(p, "trafo_kva", 5)
    u = num(p, "variak", 22.9) / 100 * tkv
    u_prim = num(p, "variak", 22.9) / 100 * 400
    dev = p.get("devre") if p.get("devre") in DEVRE else "kuplaj"
    kus = p.get("kusur") if p.get("kusur") in KUSUR else "yok"
    sinir = num(p, "sinir_pc", 20); q0 = num(p, "q0_pc", 20)
    oran = ck / (ca + ck)
    i_yg = OMEGA * (ca + ck) * 1e-12 * u * 1000              # A
    s_kva = u * i_yg
    gur = num(p, "gurultu_pc", 2) / max(oran, 0.02) * (1 if p.get("filtre") else 4)
    rng = random.Random(17)
    B = bosluk(u, num(p, "d_mm", 0.5), num(p, "a_mm", 2), num(p, "t_mm", 10), num(p, "er", 4.0)) if kus == "bosluk" else None
    pts = desen(kus, u, u0, B, rng) if asama != "kalibrasyon" else []
    dis = []                                                 # deney devresinin kendi koronası (nesneden değil)
    if asama != "kalibrasyon" and not p.get("korona_onlem") and u > 15:
        dis = desen("korona_yg", u, 15 / 0.70, None, rng)
    hepsi = [abs(q) for _, q in pts + dis]
    hepsi.sort()
    q_olc = hepsi[int(0.9 * (len(hepsi) - 1))] if hepsi else 0.0
    okuma = max(q_olc, gur if asama != "kalibrasyon" else 0.0)
    if kus == "bosluk":
        pdiv, pdev = B["pdiv"], B["pdev"]
    elif kus in UI:
        pdiv, pdev = UI[kus] * u0, 0.85 * UI[kus] * u0
    else:
        pdiv = pdev = None
    kt, an = [], []
    an.append(f"Devre: şebeke → varyak (%{fnum(num(p, 'variak', 22.9), 1)} → {fnum(u_prim, 0)} V) → deney trafosu (0,4 / {fnum(tkv, 0)} kV) → yüksek gerilim barası {fnum(u, 1)} kV. Baraya paralel iki kol bağlı: deney nesnesi (Ca = {fnum(ca, 0)} pF) ve kuplaj kondansatörü (Ck = {fnum(ck, 0)} pF).")
    an.append(f"Nesnenin içinde bir boşalma olduğunda eksilen yükü kuplaj kondansatörü tamamlar; bu yük darbesi ölçme empedansından (kuplör) geçer. Yükün kuplöre ulaşan payı Ck / (Ca + Ck) = %{fnum(oran * 100, 0)}. "
              f"Deney trafosu bu hızlı darbeye yol veremez (sargı endüktansı ve blokaj empedansı): trafo yalnız 50 Hz gerilimi sağlar, darbe Ck üzerinden kapanır.")
    an.append(f"Deney trafosunun yükü kapasitiftir: I = ω·(Ca + Ck)·U = {fnum(i_yg * 1000, 2)} mA, S = {fnum(s_kva, 2)} kVA (trafo {fnum(tkva, 0)} kVA).")
    if asama == "kalibrasyon":
        an.append(f"Kalibrasyon: gerilim yokken kalibratör deney nesnesinin uçlarına bağlanır ve bilinen bir yük verir (q0 = {fnum(q0, 0)} pC). Kuplöre bunun %{fnum(oran * 100, 0)}'i ulaşır ({fnum(q0 * oran, 1)} pC); cihazın ölçeği, gösterge {fnum(q0, 0)} pC okuyacak biçimde ayarlanır. "
                  "Böylece devrenin bütün zayıflatması (Ck / Ca oranı, kablolar, kuplör) ölçeğe işlenmiş olur. Kalibrasyon o bağlantı için geçerlidir: nesne, Ck ya da kablo değişirse yenilenir. Kalibratör gerilim verilmeden önce sökülür.")
    else:
        an.append(f"Yöntem: gerilim önce ön gerilime ({fnum(u_on, 1)} kV = 1,3·Ur/√3) çıkarılıp en az 10 s tutulur, sonra ölçme gerilimine ({fnum(u_olc, 1)} kV = 1,1·Ur/√3) indirilir ve boşalma düzeyi okunur. "
                  f"Şu an {'ön gerilim' if asama == 'on' else 'ölçme'} aşaması; bara gerilimi {fnum(u, 1)} kV.")
        if kus == "bosluk":
            an.append(f"Boşluk: {fnum(num(p, 'd_mm', 0.5), 2)} mm kalınlık, εr = {fnum(num(p, 'er', 4.0), 1)} olan {fnum(num(p, 't_mm', 10), 0)} mm yalıtımın içinde. Alternatif gerilimde alan kapasitelere göre bölünür: boşluk, toplam gerilimin %{fnum(B['oran'] * 100, 1)}'ini alır "
                      f"(kalınlık payının εr katı). Bu kalınlıkta hava {fnum(B['ud'], 2)} kV tepe değerde delinir → boşalma {fnum(B['pdiv'], 1)} kV'ta (etken) başlar. Her boşalmada görünür yük q = Cb·ΔU = {fnum(B['cb'] * 1000, 1)} fF × {fnum(0.8 * B['ud'] * 1000, 0)} V ≈ {fnum(B['q'], 0)} pC.")
        if pts:
            an.append(f"Ekranda {len(pts)} darbe ({'40' if kus in ('bosluk', 'yuzey') else 'birçok'} çevrim üst üste). Göstergenin okuduğu, yinelenen en büyük darbe: {fnum(q_olc, 0)} pC. Desenin faz üzerindeki yeri kusurun türünü söyler (aşağıdaki tablo).")
        elif kus != "yok":
            an.append(f"Bu gerilimde kusur henüz boşalmıyor: başlama gerilimi {fnum(pdiv, 1)} kV. Ekranda yalnız taban gürültüsü ({fnum(gur, 1)} pC) görülür.")
        if dis:
            an.append("Yüksek gerilim bağlantıları ince tel ya da keskin köşeli: deney devresinin kendisi korona yapıyor. Desen negatif yarım dalganın tepesinde toplanır ve nesnedeki kusurla karışır; bağlantılar kalın boruyla ve korona halkalarıyla yapılır.")
    # kontroller
    kt.append(C("Ölçme devresinin nesneye uygunluğu", DEVRE[dev].split(" (")[0], "gövdesi topraklı nesnede ölçme empedansı kuplaj kondansatörü kolundadır; nesne kolunda ölçüm yalnız topraktan yalıtılabilen nesnede", not (dev == "nesne" and p.get("nesne") != "bilesen"),
                "TS EN 60270 (temel deney devreleri)", "dogrulanacak"))
    kt.append(C("Kalibrasyon", ("yapıldı" if p.get("kalibre") else "yapılmadı") + f" (q0 = {fnum(q0, 0)} pC)", "her deney düzeni için, nesne bağlıyken, kabul sınırı mertebesinde bir yükle (≈ 0,5 – 2 × sınır)", bool(p.get("kalibre")) and 0.5 * sinir <= q0 <= 2 * sinir + 1e-9,
                "TS EN 60270 (kalibrasyon)", "dogrulanacak"))
    kt.append(C("Kuplaj kondansatörü / nesne kapasitesi", f"Ck / (Ca + Ck) = %{fnum(oran * 100, 0)}", "Ck, Ca'dan küçük olmamalı (pay ≥ %50); küçükse duyarlılık ve gürültü payı bozulur", oran >= 0.5 - 1e-9, "TS EN 60270; ölçü sistemi üreticisi kuralları", "ikincil"))
    kt.append(C("Deney trafosunun yükü", f"{fnum(s_kva, 2)} kVA ({fnum(i_yg * 1000, 1)} mA)", f"≤ {fnum(tkva, 0)} kVA", s_kva <= tkva + 1e-9, "Hesap: S = ω·(Ca + Ck)·U²", "ikincil"))
    if asama == "kalibrasyon":
        kt.append(C("Kalibrasyon sırasında gerilim", f"{fnum(u, 1)} kV", "0 kV — kalibratör alçak gerilim cihazıdır, gerilim verilmeden önce sökülür", u < 0.5, "TS EN 60270 (kalibrasyon); iş güvenliği", "dogrulanacak"))
    elif asama == "on":
        kt.append(C("Ön gerilim", f"{fnum(u, 1)} kV", f"1,3·Ur/√3 = {fnum(u_on, 1)} kV, en az 10 s", abs(u - u_on) <= 0.03 * u_on, "TS EN 62271-200 m.7.101 ve Ek B", "dogrulanacak"))
    else:
        kt.append(C("Ölçme gerilimi", f"{fnum(u, 1)} kV", f"1,1·Ur/√3 = {fnum(u_olc, 1)} kV", abs(u - u_olc) <= 0.03 * u_olc, "TS EN 62271-200 m.7.101 ve Ek B", "dogrulanacak"))
    if asama != "kalibrasyon":
        kt.append(C("Arka plan gürültüsü", f"{fnum(gur, 1)} pC", f"kabul sınırının yarısından küçük (< {fnum(sinir / 2, 0)} pC)", gur < sinir / 2, "TS EN 60270 (arka plan gürültüsü)", "dogrulanacak"))
        kt.append(C("Deney devresinin kendi boşalması", "bağlantılarda korona var" if dis else "yok", "deney gerilimine kadar devre boşalmasız olmalı (nesne yerine boşalmasız kondansatörle denenir)", not dis, "TS EN 60270 (deney devresi)", "dogrulanacak"))
    if asama == "olcme":
        kt.append(C("Kısmi boşalma düzeyi", f"{fnum(okuma, 0)} pC" + ("" if p.get("kalibre") else " (kalibrasyonsuz: değer güvenilir değil)"), f"≤ {fnum(sinir, 0)} pC", okuma <= sinir and bool(p.get("kalibre")), "Şartname / anlaşma değeri (aşağıdaki tablo); TS EN 62271-200 m.7.101", "dogrulanacak"))
    ds = ["Görünür yük, boşluktaki gerçek yük değildir; uçlarda ölçülen karşılığıdır (Cb / Cc oranında küçüktür). Aynı boşluk, kalın yalıtımda daha küçük pC verir. Bu yüzden sınır değerler donanım türüne göre değişir.",
          "Kalibrasyon ölçeği düzeltir, gürültüyü düzeltmez. Ck küçük ya da nesne kapasitesi büyükse boşalmanın kuplöre ulaşan payı düşer; küçük boşalmalar gürültünün içinde kaybolur.",
          "Desen faz açısına göre okunur: gerilimin yükselen kenarlarında iki yarım dalgada simetrik darbeler iç boşluğu; yalnız negatif tepe çevresinde eşit boylu darbeler gerilimli taraftaki sivri ucu; sıfır geçişlerinde düzensiz darbeler kötü kontağı gösterir.",
          "Boşalmanın başladığı (PDIV) ve söndüğü (PDEV) gerilimler kaydedilir. Sönme gerilimi işletme faz–toprak geriliminin altındaysa, bir aşırı gerilimle başlayan boşalma işletmede sönmez.",
          "Varyakın fırça teması ve şebeke kaynaklı darbeler en sık gürültü kaynağıdır: varyaktan sonra alçak geçiren filtre, yüksek gerilim tarafında blokaj empedansı kullanılır. Yüksek gerilim bağlantıları kalın boru ve korona halkasıyla yapılır; yakındaki topraksız metal parçalar topraklanır."]
    # şema
    c = Cizim(900, 340, zemin=300)
    c.yazi(24, 150, "400 V", "#334155", 11, True).hat("M24,160 H70", "L1", hot=u > 0.5, hot_renk="ok")
    c.kutu(70, 132, 80, 56, "VARYAK", f"%{fnum(num(p, 'variak', 22.9), 1)} · {fnum(u_prim, 0)} V", "acti" if u > 0.5 else "normal").hat("M150,160 H170", "L1", hot=u > 0.5, hot_renk="ok")
    c.kutu(170, 138, 60, 44, "filtre", "", "normal" if p.get("filtre") else "gecersiz").hat("M230,160 H250", "L1", hot=u > 0.5, hot_renk="ok")
    c.kutu(250, 120, 110, 80, "DENEY TRAFOSU", f"0,4 / {fnum(tkv, 0)} kV · {fnum(tkva, 0)} kVA", "gecersiz" if s_kva > tkva else "acti").hat("M305,200 V300", "PE", kesik=True).toprak(305, 300)
    c.hat("M360,140 H380 V70 H400", "ariza", hot=u > 0.5).direnc(400, 70, "Z (blokaj)", False, True, 40, "cizgi" if p.get("filtre") else "soluk").hat("M440,70 H800", "ariza", hot=u > 0.5, w=3)
    c.yazi(620, 58, f"yüksek gerilim barası · {fnum(u, 1)} kV", "ariza", 12, True, "middle")
    olc_kol = dev in ("kuplaj", "kopru"); nes_kol = dev in ("nesne", "kopru")
    # kuplaj kondansatörü kolu
    c.kap(540, 70, 170, "mavi", False, f"Ck {fnum(ck, 0)} pF")
    if olc_kol:
        c.kutu(505, 180, 70, 40, "Zm", "kuplör", "vurgu").hat("M540,170 V180", "mavi").hat("M540,220 V300", "mavi")
    else:
        c.hat("M540,170 V300", "mavi")
    # deney nesnesi kolu
    c.kap(720, 70, 170, "ariza" if pts else "cizgi", False, f"Ca {fnum(ca, 0)} pF").dikdortgen(676, 96, 118, 50, "#334155", "rgba(148,163,184,.10)", 1.6, True, 6).yazi(728, 162, "deney nesnesi", "#334155", 10.5, True)
    if pts:
        c.simsek(704, 112, 0.9)
    if nes_kol:
        c.kutu(685, 180, 70, 40, "Zm", "kuplör", "vurgu").hat("M720,170 V180", "cizgi").hat("M720,220 V300", "cizgi")
    else:
        c.hat("M720,170 V300", "cizgi")
    c.toprak(540, 300).toprak(720, 300)
    # boşalma darbesinin yolu: nesne → bara → Ck → kuplör → toprak → nesne
    if pts or asama == "kalibrasyon":
        c.hat("M712,104 V78 H548 V104", "uyari", hot=True, hot_renk="uyari", w=1.6, kesik=True).yazi(630, 96, "darbenin yolu", "uyari", 10, False, "middle")
    xm = 505 if olc_kol else 685
    c.hat(f"M{xm},200 H{xm - 30} V250 H{'430' if olc_kol else '640'}", "mavi", kesik=True)
    c.cihaz(300 if olc_kol else 510, 226, f"{fnum(okuma if asama != 'kalibrasyon' else q0, 0)} pC", "kısmi boşalma ölçü cihazı", (okuma <= sinir and bool(p.get("kalibre"))) if asama == "olcme" else True, 130)
    if asama == "kalibrasyon":
        c.kutu(806, 100, 84, 44, "kalibratör", f"q0 = {fnum(q0, 0)} pC", "acti").hat("M806,110 H800 V78", "ok").hat("M848,144 V300", "ok")
    c.yazi(450, 328, {"kalibrasyon": f"kalibrasyon: kuplöre ulaşan pay %{fnum(oran * 100, 0)} — gösterge {fnum(q0, 0)} pC'ye ayarlanır", "on": f"ön gerilim: hedef {fnum(u_on, 1)} kV, en az 10 s", "olcme": f"ölçme: hedef {fnum(u_olc, 1)} kV · okunan {fnum(okuma, 0)} pC · sınır {fnum(sinir, 0)} pC"}[asama],
           "ok" if all(k["ok"] is not False for k in kt) else "ariza", 12, True, "middle")
    # grafikler
    graf = []
    if asama != "kalibrasyon":
        ymax = max([sinir * 1.9, gur * 2] + [abs(q) * 1.45 for _, q in pts + dis])
        sec = (pts + dis)[:: max(1, len(pts + dis) // 420)]
        gn = [(rng.uniform(0, 360), rng.gauss(0, gur / 2.5)) for _ in range(120)]
        graf.append({"baslik": "Faz çözümlü boşalma deseni", "x_ad": "gerilimin faz açısı (°)", "y_ad": "görünür yük (pC)", "ymin": -ymax, "ymax": ymax,
                     "seriler": [{"ad": "deney gerilimi (ölçeksiz)", "renk": "#94a3b8", "kesik": True, "pts": [[k, round(0.6 * ymax * math.sin(math.radians(k)), 2)] for k in range(0, 361, 6)]},
                                 {"ad": "boşalma darbeleri", "renk": "#dc2626", "nokta": True, "pts": [[round(a % 360, 1), round(q, 1)] for a, q in sec]},
                                 {"ad": "gürültü", "renk": "#64748b", "nokta": True, "r": 1.6, "pts": [[round(a, 1), round(q, 2)] for a, q in gn]}],
                     "yatay": [{"y": sinir, "etiket": f"kabul sınırı {fnum(sinir, 0)} pC"}, {"y": -sinir, "etiket": ""}]})
    prog = [[0, 0], [10, u_on], [22, u_on], [28, u_olc], [88, u_olc], [98, 0]]
    yat = [{"y": u0, "etiket": f"işletme faz–toprak {fnum(u0, 1)} kV", "renk": "#15803d"}]
    if pdiv is not None:
        yat += [{"y": pdiv, "etiket": f"başlama (PDIV) {fnum(pdiv, 1)} kV", "renk": "#dc2626"}, {"y": pdev, "etiket": f"sönme (PDEV) {fnum(pdev, 1)} kV", "renk": "#d97706"}]
    graf.append({"baslik": "Gerilim programı", "x_ad": "zaman (s)", "y_ad": "gerilim (kV)", "zaman": True, "ymin": 0, "ymax": u_on * 1.3, "seriler": [{"ad": "uygulanan gerilim: ön gerilim (≥ 10 s) → ölçme gerilimi", "renk": "#1a4d8f", "pts": prog}], "yatay": yat})
    xs = [0.05 * 1.3 ** k for k in range(0, 24)]
    graf.append({"baslik": "Kuplaj kondansatörünün duyarlılığa etkisi", "x_ad": "Ck / Ca", "y_ad": "kuplöre ulaşan pay (%)", "logx": True, "ymin": 0, "ymax": 100,
                 "seriler": [{"ad": "Ck / (Ca + Ck)", "renk": "#1a4d8f", "pts": [[round(x, 3), round(100 * x / (1 + x), 1)] for x in xs]}], "isaretler": [{"x": ck / ca, "etiket": "bu devre"}], "yatay": [{"y": 50, "etiket": "%50", "renk": "#64748b"}]})
    tab_desen = {"baslik": "Desen tanıma: boşalma nerede görünür?", "cols": ["Kusur", "Faz üzerindeki yeri", "Görünüş", "Ayırt edici özellik"],
                 "rows": [["İç boşluk (katı yalıtımda)" + (" ◀" if kus == "bosluk" else ""), "gerilimin yükselen kenarları: ≈ 0–90° ve 180–270°", "iki yarım dalgada benzer boyda ve sayıda darbe", "gerilim artınca darbe sayısı artar, boyu az değişir; sönme gerilimi başlamanın altındadır"],
                          ["Yüzey boşalması" + (" ◀" if kus == "yuzey" else ""), "yükselen kenarlar; iki yarım dalga farklı", "bir yarım dalgada seyrek ve büyük, öbüründe sık ve küçük", "nem ve kirle değişir; temizlenince azalır"],
                          ["Korona — gerilimli tarafta sivri uç" + (" ◀" if kus == "korona_yg" else ""), "negatif tepe çevresi (≈ 270°)", "eşit boylu, sık darbeler", "gerilim artınca darbe sayısı artar, boyu değişmez; çok yüksek gerilimde pozitif tepede büyük darbeler"],
                          ["Korona — topraklı tarafta sivri uç" + (" ◀" if kus == "korona_toprak" else ""), "pozitif tepe çevresi (≈ 90°)", "eşit boylu, sık darbeler", "yukarıdakinin ayna görüntüsü"],
                          ["Yüzen potansiyelli metal" + (" ◀" if kus == "yuzen" else ""), "sıfır geçişleri çevresi, iki yarım dalga", "çok büyük, eşit boylu, eşit aralıklı az sayıda darbe", "gerilimle boyu değişmez; parça topraklanınca kaybolur"],
                          ["Kötü kontak" + (" ◀" if kus == "kontak" else ""), "sıfır geçişleri (akımın tepesi)", "düzensiz boyda, iki işaretli darbeler", "akıma bağlıdır; bağlantı sıkılınca kaybolur"],
                          ["Dış gürültü", "faza bağlı değil", "bütün açılara yayılmış küçük darbeler", "gerilim kapalıyken de vardır"]],
                 "not": "Desenler kapasitif boşalma modeliyle üretilmiştir; gerçek ölçümde aynı kusur, biçimine ve yaşına göre farklı görünebilir (durum: tahmini)."}
    tab_devre = {"baslik": "Deney devresinin elemanları", "cols": ["Eleman", "Görevi", "Dikkat edilecek"],
                 "rows": [["Varyak (ayarlı trafo)", "deney trafosunun primer gerilimini sıfırdan başlayarak ayarlar", "fırça teması darbe üretir: çıkışına filtre; gerilim sıfırdan başlatılır ve sıfıra indirilerek kapatılır"],
                          ["Alçak geçiren filtre", "şebekeden ve varyaktan gelen darbeleri keser", "yoksa gürültü birkaç kat artar"],
                          ["Deney trafosu", "gerilimi deney düzeyine yükseltir; kendisi boşalmasız olmalı", f"gücü kapasitif yükü karşılamalı: S = ω·(Ca + Ck)·U² = {fnum(s_kva, 2)} kVA"],
                          ["Blokaj empedansı Z", "boşalma darbesinin trafoya kaçmasını, trafo tarafı gürültüsünün ölçüye girmesini önler", "yüksek gerilim tarafında, trafo ile kuplaj kolu arasında"],
                          ["Kuplaj kondansatörü Ck", "darbeye düşük empedanslı yol verir; 50 Hz'i ölçü cihazından uzak tutar", "boşalmasız olmalı; Ck ≥ Ca önerilir"],
                          ["Ölçme empedansı Zm (kuplör, dörtuçlu)", "yük darbesini gerilim darbesine çevirir; 50 Hz akımı toprağa geçirir", "Ck'nın ya da nesnenin toprak ucuna; ölçü cihazına eş eksenli kabloyla"],
                          ["Ölçü cihazı", "darbeleri toplar (görünür yük, pC), faz açısına göre gösterir", "geniş bant: 100–400 kHz bant genişliği; dar bant: 9–30 kHz"],
                          ["Kalibratör", "nesnenin uçlarına bilinen yük (q0) verir", "her düzen için; gerilim verilmeden önce sökülür"]],
                 "not": "Bant genişlikleri TS EN 60270'ten (durum: dogrulanacak)."}
    tab_sinir = {"baslik": "Donanıma göre deney gerilimi ve kabul düzeyi", "cols": ["Donanım", "Ölçme gerilimi", "Kabul düzeyi", "Dayanak", "Durum"],
                 "rows": [["OG XLPE kablo (rutin deney)", "2·U0", "≤ 5 pC", "TEDAŞ-MLZ/96-018.B m.3", "resmi"], ["Kuru tip dağıtım trafosu", "ön gerilim 1,8·Ur → ölçme 1,3·Ur", "≤ 10 pC", "TEDAŞ-MLZ/99-031.B m.2.2.15; TS EN 60076-11", "resmi (sınır) / dogrulanacak (gerilimler)"],
                          ["OG hücre bileşenleri", "ön gerilim 1,3·Ur/√3 → ölçme 1,1·Ur/√3", "şartname / anlaşma değeri", "TEDAŞ-MLZ/95-007.E m.4.2 (rutin deney listesi); TS EN 62271-200 m.7.101", "resmi (deney istenir) / dogrulanacak (gerilimler)"],
                          ["Ölçü trafoları (katı yalıtım)", "1,2·Um/√3 ve Um", "≤ 20 pC ve ≤ 50 pC", "TS EN 61869-1", "dogrulanacak"]]}
    tab_adim = {"baslik": "Ölçme yöntemi — adım adım", "cols": ["Adım", "Yapılan", "Neden"],
                "rows": [["1", "Deney alanı çevrilir; nesne, deney trafosu, Ck ve kuplörün toprakları tek noktada birleştirilir", "toprak çevrimleri gürültü taşır"],
                         ["2", "Yüksek gerilim bağlantıları kalın boruyla yapılır; yakındaki metal parçalar topraklanır", "korona ve yüzen potansiyel deney devresinin kendi boşalmasıdır"],
                         ["3", "Gerilim yokken kalibratör nesnenin uçlarına bağlanır, gösterge q0'a ayarlanır", "devrenin zayıflatması ölçeğe işlenir"],
                         ["4", "Kalibratör sökülür; gerilimsiz gürültü okunur", "gürültü, sınırın yarısından küçük olmalı"],
                         ["5", "Gerilim sıfırdan yükseltilir; boşalmanın başladığı gerilim (PDIV) yazılır", "kusurun ne kadar pay bıraktığını gösterir"],
                         ["6", "Ön gerilimde en az 10 s beklenir", "işletmedeki aşırı gerilimin başlatacağı boşalmalar uyarılır"],
                         ["7", "Ölçme gerilimine inilir; boşalma düzeyi ve desen kaydedilir", "kabul ölçütü bu okumadır"],
                         ["8", "Gerilim indirilirken sönme gerilimi (PDEV) yazılır; gerilim sıfırlanır, devre topraklanır", "PDEV işletme geriliminin üstünde olmalı"]]}
    oz = [K("Bara gerilimi", f"{fnum(u, 1)} kV", "info", f"varyak %{fnum(num(p, 'variak', 22.9), 1)}"), K("Okunan boşalma", f"{fnum(okuma if asama != 'kalibrasyon' else q0, 0)} pC", ("ok" if okuma <= sinir and p.get("kalibre") else "bad") if asama == "olcme" else "info", f"sınır {fnum(sinir, 0)} pC"),
          K("Kuplöre ulaşan pay", f"%{fnum(oran * 100, 0)}", "ok" if oran >= 0.5 else "warn", "Ck / (Ca + Ck)"), K("Gürültü", f"{fnum(gur, 1)} pC", "ok" if gur < sinir / 2 else "bad", "nesne uçlarına indirgenmiş"),
          K("Başlama / sönme", f"{fnum(pdiv, 1)} / {fnum(pdev, 1)} kV" if pdiv is not None else "—", "info" if pdiv is None else ("ok" if pdev > u0 else "warn"), f"işletme {fnum(u0, 1)} kV"), K("Deney trafosu yükü", f"{fnum(s_kva, 2)} kVA", "ok" if s_kva <= tkva else "bad", f"{fnum(i_yg * 1000, 1)} mA")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "grafikler": graf, "tablolar": [tab_desen, tab_adim, tab_devre, tab_sinir]}
