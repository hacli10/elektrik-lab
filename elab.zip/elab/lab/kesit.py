"""Laboratuvar konusu — topraklama ve koruma iletkeni kesiti: ısıl dayanım (adyabatik), en küçük kesitler, korozyon.

Model: arıza süresince iletken ısıyı çevreye veremez (adyabatik). S ≥ I·√t / k ; son sıcaklık
θf = (β + θi)·exp(I²·t / (K²·S²)) − β   (Cu: K = 226, β = 234,5 · Al: 148, 228 · çelik: 78, 202).
Dayanak: Topraklamalar Yön. m.5, m.9, Ek-B; TS HD 60364-5-54."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, ctl, fnum, num, opt, ruleset

ID = "kesit"
BASLIK = "İletken kesiti ve ısıl dayanım"
IKON = "🔥"
GIRIS = ("Topraklama ve koruma iletkeni, arıza akımını koruma açana kadar erimeden ve yalıtımını yakmadan taşımalıdır. Akımı, süreyi ve iletkeni seçin; "
         "gereken en küçük kesiti ve seçtiğiniz kesitin arıza sonunda kaç dereceye çıktığını görün.")
# tip: (ad, K sabiti, β, başlangıç sıcaklığı, izin verilen son sıcaklık, k (kural dosyası anahtarı ya da değer))
TIP = {
    "cu_ciplak": ("Çıplak bakır (toprak içinde / açıkta)", 226.0, 234.5, 30.0, 300.0, "cu_pe_ciplak"),
    "cu_pvc": ("PVC yalıtımlı bakır (ayrı çekilmiş koruma iletkeni)", 226.0, 234.5, 30.0, 160.0, "cu_pe_pvc_kilifli"),
    "cu_kablo": ("Kablo içinde bakır damar (PVC)", 226.0, 234.5, 70.0, 160.0, "cu_pvc"),
    "al_kablo": ("Kablo içinde alüminyum damar (PVC)", 148.0, 228.0, 70.0, 160.0, "al_pvc"),
    "celik": ("Galvanizli çelik şerit / lama", 78.0, 202.0, 30.0, 300.0, 78.0),
}
KESITLER = (2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95, 120, 150, 185, 240)

KONTROLLER = [
    ctl("kullanim", "İletkenin görevi", "sec", "topraklama", secenek=opt(("topraklama", "Topraklama iletkeni (YG tesisi / trafo merkezi)"), ("koruma", "Koruma iletkeni (AG devresi)"))),
    ctl("tip", "İletken", "sec", "cu_ciplak", secenek=opt(*[(k, v[0]) for k, v in TIP.items()])),
    ctl("i_a", "Arıza akımı", "sayi", 8000, min=100, max=40000, adim=100, birim="A", yardim="YG: tasarım akımı (Çizelge-1); AG: devre başındaki kısa devre akımı"),
    ctl("t_s", "Arızanın temizlenme süresi", "sayi", 0.5, min=0.02, max=5, adim=0.02, birim="s"),
    ctl("s_mm2", "Seçilen kesit", "sec", 50, secenek=opt(*[(v, f"{v:g} mm²") for v in KESITLER])),
    ctl("s_faz", "Devrenin faz iletkeni kesiti", "sec", 35, secenek=opt(*[(v, f"{v:g} mm²") for v in KESITLER]), goster={"kullanim": ["koruma"]}),
]


def kval(tip: str) -> float:
    k = TIP[tip][5]
    return float(k) if not isinstance(k, str) else float(ruleset().topraklama["adyabatik"]["k"][k])


def son_sicaklik(tip: str, i: float, t: float, s: float) -> float:
    _, kk, beta, th0, *_ = TIP[tip]
    return (beta + th0) * math.exp(min(50.0, i * i * t / (kk * kk * s * s))) - beta


def run(p: dict) -> dict:
    T = ruleset().topraklama
    tip = p.get("tip") if p.get("tip") in TIP else "cu_ciplak"
    ad, kk, beta, th0, thf, _ = TIP[tip]
    i = num(p, "i_a", 8000); t = num(p, "t_s", 0.5); s = num(p, "s_mm2", 50)
    koruma = p.get("kullanim") == "koruma"
    k = kval(tip)
    s_isil = i * math.sqrt(t) / k
    s_std = next((v for v in KESITLER if v >= s_isil - 1e-9), None)
    th = son_sicaklik(tip, i, t, s)
    an = [f"Arıza akımı {fnum(i, 0)} A, {fnum(t, 2)} s sürüyor. Bu kadar kısa sürede iletken ısısını çevreye veremez; I²·t = {fnum(i * i * t / 1e6, 1)} × 10⁶ A²s enerjinin tamamı iletkeni ısıtır.",
          f"Gereken en küçük kesit: S = I·√t / k = {fnum(i, 0)} × √{fnum(t, 2)} / {fnum(k, 0)} = {fnum(s_isil, 1)} mm² → standart kesit {fnum(s_std, 0) if s_std else '> 240'} mm². (k = {fnum(k, 0)}: {ad.lower()}, {fnum(th0, 0)} °C'den {fnum(thf, 0)} °C'ye.)",
          f"Seçtiğiniz {fnum(s, 1)} mm² iletken arıza sonunda ≈ {fnum(min(th, 2000), 0)} °C'ye çıkar" + (" — erime sıcaklığına yaklaşır/aşar; iletken kopar." if th > 1000 else f"; izin verilen son sıcaklık {fnum(thf, 0)} °C.")]
    kt = [C("Isıl dayanım (adyabatik)", f"S = {fnum(s, 1)} mm² ; gereken {fnum(s_isil, 1)} mm²", "S ≥ I·√t / k", s >= s_isil - 1e-9, "Topraklamalar Yön. Ek-B; TS HD 60364-5-54 m.543.1.2", T["adyabatik"]["durum"]),
          C("Arıza sonu sıcaklığı", f"{fnum(min(th, 2000), 0)} °C", f"≤ {fnum(thf, 0)} °C", th <= thf + 0.5, "Topraklamalar Yön. Ek-B (izin verilen son sıcaklıklar); TS HD 60364-5-54 Çizelge A.54", "dogrulanacak")]
    if koruma:
        sf = num(p, "s_faz", 35)
        s_tablo = sf if sf <= 16 else 16 if sf <= 35 else sf / 2
        an.append(f"Koruma iletkeni hesap yapılmadan çizelgeden de seçilebilir: faz {fnum(sf, 0)} mm² → koruma iletkeni en az {fnum(s_tablo, 1)} mm² (aynı malzemeden). Çizelge kesiti her zaman hesapla bulunandan büyük ya da eşittir; hesap yapılırsa daha küçüğü seçilebilir.")
        kt.append(C("Çizelgeye göre koruma iletkeni", f"faz {fnum(sf, 0)} mm² → en az {fnum(s_tablo, 1)} mm² ; seçilen {fnum(s, 1)} mm²", "S ≤ 16: S · 16 < S ≤ 35: 16 mm² · S > 35: S / 2",
                    True if s >= s_tablo - 1e-9 else (None if s >= s_isil else False), "Topraklamalar Yön. m.9, Çizelge-8", "resmi"))
    else:
        mn = T["topraklama_iletkeni_min_mm2"]
        s_min = mn["celik"] if tip == "celik" else mn["al"] if tip.startswith("al") else mn["cu"]
        an.append(f"Isıl hesap küçük çıksa bile topraklama iletkeni mekanik dayanım ve korozyon için en küçük kesitin altına inemez: bakır {mn['cu']} mm², alüminyum {mn['al']} mm², çelik {mn['celik']} mm².")
        kt.append(C("En küçük kesit (mekanik dayanım, korozyon)", f"{fnum(s, 1)} mm²", f"≥ {s_min} mm² ({'çelik' if tip == 'celik' else 'alüminyum' if tip.startswith('al') else 'bakır'})", s >= s_min - 1e-9, mn["kaynak"], mn["durum"]))
    ds = ["Kesiti belirleyen akımın karesi ile süredir: süre dört katına çıkarsa kesit iki katına çıkar. Hızlı koruma ince iletken demektir.",
          "Çıplak iletken 300 °C'ye kadar ısınabilir (k büyük); yalıtımlı iletkende sınırı yalıtım koyar (PVC 160 °C). Aynı akım için yalıtımlı iletken daha kalın olmalıdır.",
          "Bağlantı noktaları iletkenden önce bozulur: pabuç, klemens ve kaynak yerleri aynı akıma dayanmalıdır (vidalı bağlantıların akım taşıma kapasitesi ayrıca dikkate alınır).",
          "Toprak içinde bakır ile galvanizli çelik doğrudan birleştirilirse çelik anot olur ve hızla çürür. Ek yerleri toprak üstünde yapılır ya da yalıtılır; betonda çelik, toprakta bakır kullanılır.",
          "Trafo merkezinde kesiti çoğu zaman ısıl hesap değil en küçük kesit belirler; AG ana panolarında ise kısa devre akımı büyük olduğundan ısıl hesap belirleyicidir."]
    ts = [0.02 * 1.12 ** j for j in range(50)]
    seriler = [{"ad": f"{fnum(s, 1)} mm² (seçilen)", "renk": "#dc2626", "pts": [[round(x, 3), round(min(son_sicaklik(tip, i, x, s), 1200), 1)] for x in ts if x <= 5.2]}]
    if s_std and s_std != s:
        seriler.append({"ad": f"{fnum(s_std, 0)} mm² (gereken)", "renk": "#15803d", "pts": [[round(x, 3), round(min(son_sicaklik(tip, i, x, s_std), 1200), 1)] for x in ts if x <= 5.2]})
    graf = [{"baslik": "Arıza süresine göre iletken sıcaklığı", "x_ad": "arıza süresi (s)", "y_ad": "sıcaklık (°C)", "logx": True, "seriler": seriler, "yatay": [{"y": thf, "etiket": f"izin verilen {fnum(thf, 0)} °C", "renk": "#334155"}],
             "isaretler": [{"x": t, "etiket": f"{fnum(t, 2)} s"}], "ymin": 0, "ymax": 1200}]
    kts = {"baslik": "k katsayıları ve en küçük kesitler", "cols": ["İletken", "k (A·√s / mm²)", "Başlangıç → son sıcaklık"], "rows": [[v[0], fnum(kval(key), 0), f"{fnum(v[3], 0)} → {fnum(v[4], 0)} °C"] for key, v in TIP.items()],
           "not": f"{T['adyabatik']['kaynak']} — durum: {T['adyabatik']['durum']}. Çelik için k = 78 ve sıcaklık sınırları: dogrulanacak. En küçük topraklama iletkeni kesitleri: {T['topraklama_iletkeni_min_mm2']['kaynak']} (resmi)."}
    kor = {"baslik": "Toprak içinde malzeme seçimi ve korozyon", "cols": ["Malzeme", "Davranış", "Not"], "rows": [
        ["Bakır (çıplak, kalaylı)", "Toprakta çok dayanıklı; soy metal", "Yakınındaki çeliği (boru, temel demiri, galvaniz şerit) çürütür"],
        ["Sıcak daldırma galvanizli çelik", "Çinko kaplama bitene kadar korunur; asitli ve tuzlu toprakta ömrü kısalır", "Betona gömülü çelikle birleşirse toprak içindeki bölüm anot olur"],
        ["Betona gömülü çelik (temel topraklayıcı)", "Beton içinde pasiftir, bakıra yakın potansiyelde", "Toprağa çıkan bağlantı filizi korozyona karşı korunur (kılıf, bant)"],
        ["Paslanmaz çelik (V4A)", "Dayanıklı; bakırla birlikte kullanılabilir", "Pahalı; bağlantı filizlerinde tercih edilir"]],
        "not": "Topraklamalar Yön. m.5-b, Ek-A (malzeme ve en küçük boyutlar) ve genel korozyon bilgisi — durum: ikincil"}
    c = Cizim(900, 250)
    w = max(4.0, min(60.0, s / 3))
    ok_ = s >= s_isil
    c.yazi(40, 30, "Arıza akımının geçtiği iletken", "#334155", 12, True)
    c.dikdortgen(120, 110 - w / 2, 600, w, "ariza" if not ok_ else "ok", "#fde68a" if th < 200 else "#fb923c" if th < thf + 1 else "#ef4444", 2, r=3)
    c.ok(40, 110, 116, 110, "ariza", 3).ok(724, 110, 800, 110, "ariza", 3)
    c.yazi(40, 96, f"{fnum(i, 0)} A", "ariza", 12, True).yazi(420, 110 - w / 2 - 10, f"{fnum(s, 1)} mm² · {ad}", "#334155", 11.5, True, "middle")
    c.yazi(420, 110 + w / 2 + 22, f"arıza sonunda ≈ {fnum(min(th, 2000), 0)} °C (sınır {fnum(thf, 0)} °C)", "ok" if th <= thf else "ariza", 13, True, "middle")
    c.yazi(420, 110 + w / 2 + 44, f"ısıl olarak gereken en küçük kesit {fnum(s_isil, 1)} mm²", "#475569", 11.5, False, "middle")
    oz = [K("Isıl olarak gereken", f"{fnum(s_isil, 1)} mm²", "info", f"standart {fnum(s_std, 0) if s_std else '> 240'} mm²"), K("Seçilen kesit", f"{fnum(s, 1)} mm²", "ok" if all(x["ok"] is not False for x in kt) else "bad", ad.split(" (")[0]),
          K("Arıza sonu sıcaklığı", f"{fnum(min(th, 2000), 0)} °C", "ok" if th <= thf else "bad", f"sınır {fnum(thf, 0)} °C"), K("I²·t", f"{fnum(i * i * t / 1e6, 1)} MA²s", "info", f"k = {fnum(k, 0)}")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "grafikler": graf, "tablolar": [kts, kor]}
