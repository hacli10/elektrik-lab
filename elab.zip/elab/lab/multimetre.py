"""Laboratuvar konusu — multimetreyle gerilim ölçümleri: faz–nötr, faz–faz, faz–toprak, nötr–toprak; sağlıklı ve sorunlu şebeke.

Model: üç fazlı kaynak (boşta gerilim U), her fazda hat direnci, ortak nötr direnci, tüketicide üç tek fazlı dirençli yük.
Yük yıldız noktasının (tüketici nötr klemensi) kayması: U(N′) = Σ(Uᵢ·Yᵢ) / (ΣYᵢ + Yn). Koruma iletkeni akım taşımadığı için
tüketicideki PE klemensi kaynak nötrünün (toprağın) potansiyelindedir; nötr–toprak okuması nötrdeki gerilim düşümüdür."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import A120, C, K, RHO_CU, ctl, fnum, num, opt

ID = "multimetre"
BASLIK = "Multimetreyle ölçümler"
IKON = "🔍"
GIRIS = ("Prizde ya da panoda dört ölçüm yapılır: faz–nötr, faz–faz, faz–toprak, nötr–toprak. Bu dört sayı birlikte okunursa arızanın yeri çoğu zaman bulunur. "
         "Bir durum seçin; multimetrenin ne okuyacağını ve bu okumaların ne anlama geldiğini görün.")
DURUM = {
    "saglikli": "Sağlıklı şebeke",
    "sebeke_dusuk": "Şebeke gerilimi düşük (trafo kademesi / uzak hat sonu)",
    "uzun_hat": "Uzun ve ince hat (yük altında gerilim düşümü)",
    "gevsek_faz": "Faz bağlantısı gevşek (L1'de yüksek dirençli ek)",
    "notr_gevsek": "Nötr bağlantısı gevşek (yüksek dirençli nötr)",
    "notr_kopuk": "Nötr kopuk",
    "faz_yok": "Bir faz yok (L2 sigortası atık)",
    "pe_yok": "Koruma iletkeni bağlı değil",
    "ln_ters": "Prizde faz ile nötr yer değiştirmiş",
    "npe_ters": "Prizde nötr ile koruma iletkeni yer değiştirmiş",
}
KONTROLLER = [
    ctl("durum", "Şebekenin durumu", "sec", "saglikli", secenek=opt(*DURUM.items())),
    ctl("u_kaynak", "Trafo çıkışında faz–nötr gerilimi (boşta)", "sayi", 232, min=180, max=250, adim=1, birim="V", goster={"durum": [k for k in DURUM if k != "sebeke_dusuk"]}),
    ctl("u_dusuk", "Trafo çıkışında faz–nötr gerilimi (boşta)", "sayi", 204, min=180, max=250, adim=1, birim="V", goster={"durum": ["sebeke_dusuk"]}),
    ctl("p1_kw", "L1'deki yük", "sayi", 3, min=0, max=10, adim=0.5, birim="kW"),
    ctl("p2_kw", "L2'deki yük", "sayi", 1, min=0, max=10, adim=0.5, birim="kW"),
    ctl("p3_kw", "L3'teki yük", "sayi", 2, min=0, max=10, adim=0.5, birim="kW"),
    ctl("l_m", "Hat uzunluğu (panodan ölçüm noktasına)", "sayi", 30, min=1, max=300, adim=1, birim="m", goster={"durum": [k for k in DURUM if k != "uzun_hat"]}),
    ctl("s_mm2", "İletken kesiti (faz ve nötr)", "sec", 6, secenek=opt(*[(v, f"{v:g} mm²") for v in (1.5, 2.5, 4, 6, 10, 16, 25)]), goster={"durum": [k for k in DURUM if k != "uzun_hat"]}),
    ctl("l_uzun", "Hat uzunluğu (panodan ölçüm noktasına)", "sayi", 170, min=1, max=300, adim=1, birim="m", goster={"durum": ["uzun_hat"]}),
    ctl("s_ince", "İletken kesiti (faz ve nötr)", "sec", 2.5, secenek=opt(*[(v, f"{v:g} mm²") for v in (1.5, 2.5, 4, 6, 10, 16, 25)]), goster={"durum": ["uzun_hat"]}),
    ctl("r_ek", "Gevşek bağlantının direnci", "sayi", 2, min=0.1, max=20, adim=0.1, birim="Ω", goster={"durum": ["gevsek_faz", "notr_gevsek"]}),
]
ALT, UST = 207.0, 253.0
SINIR_NPE = 5.0


def coz(p: dict) -> dict:
    d = p.get("durum") if p.get("durum") in DURUM else "saglikli"
    u = num(p, "u_dusuk", 204) if d == "sebeke_dusuk" else num(p, "u_kaynak", 232)
    L = num(p, "l_uzun", 170) if d == "uzun_hat" else num(p, "l_m", 30)
    s = num(p, "s_ince", 2.5) if d == "uzun_hat" else num(p, "s_mm2", 6)
    rh = RHO_CU * L / s
    rek = num(p, "r_ek", 2)
    ps = [num(p, "p1_kw", 3), num(p, "p2_kw", 1), num(p, "p3_kw", 2)]
    rl = [(230.0 ** 2 / (pk * 1000) if pk > 0 else 1e12) for pk in ps]
    rf = [rh + (rek if d == "gevsek_faz" else 0), rh, rh]
    v = [u + 0j, u * A120 ** 2, u * A120]
    acik = [False, d == "faz_yok", False]
    y = [0.0 if acik[i] else 1 / (rl[i] + rf[i]) for i in range(3)]
    yn = 0.0 if d == "notr_kopuk" else 1 / (rh + (rek if d == "notr_gevsek" else 0))
    vn = sum(vi * yi for vi, yi in zip(v, y)) / (sum(y) + yn) if (sum(y) + yn) > 0 else 0j
    i = [(v[k] - vn) * y[k] for k in range(3)]
    vt = [vn if acik[k] else v[k] - i[k] * rf[k] for k in range(3)]          # açık fazın ucu yük üzerinden N′ potansiyelinde
    i_n = -vn * yn
    return {"d": d, "u": u, "rh": rh, "vn": vn, "vt": vt, "i": i, "i_n": i_n, "ps": ps,
            "ln": [abs(vt[k] - vn) for k in range(3)], "ll": [abs(vt[0] - vt[1]), abs(vt[1] - vt[2]), abs(vt[2] - vt[0])], "lpe": [abs(x) for x in vt], "npe": abs(vn)}


TESHIS = {
    "saglikli": "Bütün okumalar anma değerinin ±%10'u içinde, nötr–toprak birkaç voltun altında: şebeke sağlıklı.",
    "sebeke_dusuk": "Üç faz da aynı oranda düşük, faz–faz gerilimleri de düşük, nötr–toprak küçük ve yük kapatılınca değişmiyor: sorun tesisatta değil besleme tarafında (trafo kademesi, uzun dağıtım hattının sonu, şebeke yüklenmesi). Dağıtım şirketine bildirilir.",
    "uzun_hat": "Yük açıkken faz–nötr düşük, yük kapatılınca normale dönüyor; nötr–toprak belirgin biçimde yükselmiş: gerilim hem faz hem nötr iletkeninde düşüyor. Hat bu yük için uzun ya da kesit küçük.",
    "gevsek_faz": "Yalnız bir fazda, yalnız yük altında düşüm var; aynı fazın faz–toprak okuması da düşük, nötr–toprak küçük: düşüm faz iletkeninde. Gevşek klemens, oksitlenmiş ek, yanık sigorta yuvası aranır (ısınır: termal kamerayla görülür).",
    "notr_gevsek": "Yüklü fazda gerilim düşük, az yüklü fazda yüksek; faz–faz gerilimleri normal; nötr–toprak yüksek: nötrde yüksek dirençli bir bağlantı var. Tehlikelidir: yük dağılımı değişince 230 V'luk cihazlar aşırı gerilim görür.",
    "notr_kopuk": "Faz–faz gerilimleri normal, faz–nötr gerilimleri birbirinden çok farklı ve yük değiştikçe oynuyor, nötr–toprak onlarca volt: nötr kopuk. Derhal enerji kesilir.",
    "faz_yok": "Bir fazda faz–nötr sıfıra yakın; o fazın diğer fazlara göre gerilimi 400 V değil 230 V dolayında: faz yok (sigorta atık, kontak yanık). Üç fazlı motor ya da iki faza bağlı bir yük varsa kopuk fazda geri besleme yüzünden 100–200 V okunabilir; bu faz var demek değildir.",
    "pe_yok": "Faz–nötr normal, ama faz–toprak ve nötr–toprak okumaları kararsız ve anlamsız: koruma iletkeni bir yerde bağlı değil. Yüksek iç dirençli multimetre kablolar arası kapasiteden “hayalet gerilim” okur; düşük empedans (LoZ) konumunda okuma sıfıra düşer.",
    "ln_ters": "Faz–nötr normal; “faz” sanılan uçla toprak arasında gerilim yok, “nötr” sanılan uçla toprak arasında 230 V var: faz ve nötr yer değiştirmiş. Cihaz çalışır ama anahtar nötrü keser; cihaz kapalıyken içi gerilimlidir.",
    "npe_ters": "Gerilim ölçümleriyle fark edilmez: bütün okumalar normaldir. Yük akımı koruma iletkeninden döner. Belirtisi: kaçak akım rölesi yük bağlanınca açar; röle yoksa pens ampermetreyle koruma iletkeninde yük akımı okunur.",
}


def run(p: dict) -> dict:
    q = coz(p)
    d = q["d"]
    ln, ll, lpe, npe = q["ln"], q["ll"], q["lpe"], q["npe"]
    ozel = d in ("pe_yok", "ln_ters", "npe_ters")
    def fmtv(x): return f"{fnum(x, 0)} V"
    oku = {"L1–N": fmtv(ln[0]), "L2–N": fmtv(ln[1]), "L3–N": fmtv(ln[2]), "N–PE": f"{fnum(npe, 1)} V", "L1–L2": fmtv(ll[0]), "L2–L3": fmtv(ll[1]), "L3–L1": fmtv(ll[2]), "L1–PE": fmtv(lpe[0])}
    iyi = {"L1–N": ALT <= ln[0] <= UST, "L2–N": ALT <= ln[1] <= UST, "L3–N": ALT <= ln[2] <= UST, "N–PE": npe <= SINIR_NPE, "L1–L2": 360 <= ll[0] <= 440, "L2–L3": 360 <= ll[1] <= 440, "L3–L1": 360 <= ll[2] <= 440, "L1–PE": ALT <= lpe[0] <= UST}
    if d == "pe_yok":
        oku["N–PE"] = "kararsız"; oku["L1–PE"] = "≈ 40–120 V"; iyi["N–PE"] = iyi["L1–PE"] = False
    if d == "ln_ters":
        oku["L1–PE"] = f"{fnum(npe, 1)} V"; oku["N–PE"] = fmtv(lpe[0]); iyi["L1–PE"] = iyi["N–PE"] = False
    dus = [(q["u"] - x) / 230 * 100 for k_, x in enumerate(ln) if not (d == "faz_yok" and k_ == 1)]
    an = [f"Trafo çıkışında boşta faz–nötr gerilimi {fnum(q['u'], 0)} V. Hattın her iletkeninin direnci {fnum(q['rh'], 2)} Ω. Yükler: L1 {fnum(q['ps'][0], 1)} kW, L2 {fnum(q['ps'][1], 1)} kW, L3 {fnum(q['ps'][2], 1)} kW.",
          f"Ölçüm noktasında multimetre şunları okur — faz–nötr: {oku['L1–N']} / {oku['L2–N']} / {oku['L3–N']}; faz–faz: {oku['L1–L2']} / {oku['L2–L3']} / {oku['L3–L1']}; L1–toprak: {oku['L1–PE']}; nötr–toprak: {oku['N–PE']}.",
          "Teşhis: " + TESHIS[d]]
    if d in ("uzun_hat", "gevsek_faz", "notr_gevsek", "saglikli") and not ozel:
        an.append(f"Nötr iletkeninden {fnum(abs(q['i_n']), 1)} A geçiyor (fazlardaki yük farkı). Bu akımın nötr direncinde düşürdüğü gerilim nötr–toprak okumasıdır: {fnum(npe, 1)} V. Koruma iletkeni akım taşımadığı için toprak potansiyelinde kalır; fark buradan doğar.")
    an.append("Ayırt etme yöntemi: (1) aynı ölçümü yük kapalıyken ve açıkken tekrarlayın — yük kapanınca düzeliyorsa sorun bir iletkendeki gerilim düşümüdür; (2) panonun girişinde ve prizde ölçün — düşümün nerede oluştuğunu gösterir; "
              "(3) nötr–toprağı mutlaka ölçün — düşümün fazda mı nötrde mi olduğunu söyler.")
    kt = [C(f"{k} gerilimi", oku[k], "207 – 253 V (230 V ± %10)", iyi[k], "TS EN 50160; TS 83 (IEC 60038)", "dogrulanacak") for k in ("L1–N", "L2–N", "L3–N")]
    kt.append(C("Faz–faz gerilimleri", f"{oku['L1–L2']} / {oku['L2–L3']} / {oku['L3–L1']}", "360 – 440 V (400 V ± %10)", iyi["L1–L2"] and iyi["L2–L3"] and iyi["L3–L1"], "TS EN 50160; TS 83 (IEC 60038)", "dogrulanacak"))
    kt.append(C("Nötr – toprak gerilimi", oku["N–PE"], f"birkaç volt (≤ {fnum(SINIR_NPE, 0)} V); daha yükseği nötrde aşırı düşüm ya da kopukluk belirtisi", iyi["N–PE"], "Uygulama ölçütü (nötr iletkenindeki gerilim düşümü)", "ikincil"))
    kt.append(C("Tesisat içi gerilim düşümü (en kötü faz)", f"%{fnum(max(dus), 1)}", "aydınlatma ve priz devrelerinde ≤ %3, motor devrelerinde ≤ %5 (işletme gerilimine göre)", (max(dus) <= 5.0) if d != "sebeke_dusuk" else None,
                "Elektrik İç Tesisleri Yön. (gerilim düşümü sınırları)", "ikincil"))
    if d == "pe_yok":
        kt.append(C("Koruma iletkeni sürekliliği", "faz–toprak okuması kararsız", "koruma iletkeni kesintisiz bağlı olmalı (süreklilik ölçümü ≥ 0,2 A ile)", False, "Topraklamalar Yön. m.10; TS HD 60364-6"))
    if d == "ln_ters":
        kt.append(C("Kutup doğruluğu", "faz ucu–toprak ≈ 0 V, nötr ucu–toprak 230 V", "tek kutuplu anahtar ve sigortalar faz iletkenindedir", False, "TS HD 60364-6 (kutup deneyi); Elektrik İç Tesisleri Yön.", "dogrulanacak"))
    if d == "npe_ters":
        kt.append(C("Nötr ve koruma iletkeni ayrımı", "yük akımı koruma iletkeninden dönüyor", "koruma iletkeni işletme akımı taşımaz", False, "Topraklamalar Yön. m.8-a3.8, m.9"))
    ds = ["Tek bir okuma teşhis koymaz. Faz–nötr düşükse sırayla sorun: faz–faz de düşük mü (besleme), yük kapanınca düzeliyor mu (hat), nötr–toprak yüksek mi (nötr).",
          "“Evde 200 V” en sık üç nedenden olur: besleme tarafında düşük gerilim, uzun/ince kolon ya da hat, gevşek bir faz ya da nötr bağlantısı. İlk ikisi rahatsız eder; üçüncüsü yangın çıkarır.",
          "Bir fazda düşük, başka fazda yüksek gerilim varsa önce nötrden şüphelenilir. Nötr kopukluğu cihaz yakar; gevşek nötr bunu arada bir yapar ve bulunması daha zordur.",
          "Nötr–toprak gerilimi sıfır değildir ve olması da gerekmez; nötr yük akımı taşır. Sıfıra çok yakınsa (yük varken) nötr ile toprak yakında bir yerde birleştirilmiş olabilir.",
          "Dijital multimetrenin iç direnci çok yüksektir (10 MΩ): bağlı olmayan bir iletkende komşu kablolardan kapasiteyle geçen gerilimi okur. Şüpheli okumada düşük empedans (LoZ) konumu ya da kontrol kalemi yerine iki kutuplu gerilim denetleyici kullanılır."]
    belirti = {"baslik": "Belirti → olası neden", "cols": ["Okuma", "Olası neden", "Sonraki adım"], "rows": [
        ["Faz–nötr düşük (ör. 200 V), üç fazda birden; faz–faz de düşük; yük kapanınca değişmiyor", "Besleme gerilimi düşük: trafo kademesi, uzun dağıtım hattı, şebeke aşırı yüklü", "Sayaç girişinde boşta ölçüp dağıtım şirketine bildirin"],
        ["Faz–nötr yalnız yük altında düşük; nötr–toprak 5 V'un üstünde", "Hat uzun ya da kesit küçük; faz ve nötrde gerilim düşümü", "Gerilim düşümü hesabı; kesit büyütme ya da yük bölme"],
        ["Tek fazda, yük altında düşük; o fazın faz–toprağı da düşük", "O fazda gevşek / oksitli bağlantı, yanık sigorta yuvası, zayıf kontak", "Enerjiyi kesip bağlantıları sıkın; ısınan nokta aranır"],
        ["Bir fazda düşük, başka fazda yüksek; faz–faz normal; nötr–toprak yüksek", "Nötr gevşek ya da kopuk", "Derhal yükleri ayırın; nötr bağlantılarını panodan sayaca kadar izleyin"],
        ["Faz–nötr ≈ 0 V, o faz ile diğer fazlar arası ≈ 230 V", "Faz yok (sigorta, kontak); okunan gerilim yük üzerinden geri besleme", "Sigorta ve kontakları ölçün; üç fazlı motorlar durdurulur"],
        ["Faz–nötr 400 V", "Nötr yerine ikinci bir faz bağlanmış ya da nötr kopuk ve tek yük kalmış", "Enerjiyi kesin; bağlantıyı düzeltin"],
        ["Faz–toprak ve nötr–toprak kararsız, anlamsız değerler", "Koruma iletkeni bağlı değil (hayalet gerilim)", "Süreklilik ölçümü; düşük empedans konumunda yeniden ölçün"],
        ["Faz–toprak ≈ 0 V, nötr–toprak 230 V", "Faz ve nötr yer değiştirmiş", "Priz ve pano bağlantısını düzeltin"],
        ["Bütün gerilimler normal ama kaçak akım rölesi yük bağlanınca açıyor", "Nötr ile koruma iletkeni yer değiştirmiş ya da bir yerde birleştirilmiş", "Devreleri ayırarak yalıtım ve süreklilik ölçümü"],
        ["Nötr–toprak tam 0 V (yük varken)", "Nötr ve toprak ölçüm noktasına yakın bir yerde köprülü (TN-S'de hata)", "N–PE köprüsü aranır; kaçak akım rölesi çalışmaz"]],
        "not": "Sınırlar: 230/400 V ± %10 (TS EN 50160 — dogrulanacak); nötr–toprak için kesin bir yönetmelik sınırı yoktur, verilen değer uygulama ölçütüdür (ikincil)."}
    # şema
    c = Cizim(900, 330)
    c.yazi(20, 22, "Ölçüm noktasındaki klemensler ve multimetre okumaları", "#334155", 12, True)
    for k, (ad, renk) in enumerate((("L1", "L1"), ("L2", "L2"), ("L3", "L3"), ("N", "N"), ("PE", "PE"))):
        x = 110 + k * 170
        c.daire(x, 62, 16, renk, "#fff", 3).yazi(x, 67, ad, renk, 12, True, "middle")
        if k < 3:
            c.yazi(x, 98, f"{fnum(abs(q['i'][k]), 1)} A", "#64748b", 10.5, False, "middle")
    c.yazi(620, 98, f"{fnum(abs(q['i_n']), 1)} A", "#64748b", 10.5, False, "middle")
    for j, key in enumerate(("L1–N", "L2–N", "L3–N", "N–PE", "L1–L2", "L2–L3", "L3–L1", "L1–PE")):
        x = 40 + (j % 4) * 215; yy = 122 + (j // 4) * 92
        c.cihaz(x, yy, oku[key], key, iyi[key], 180)
    c.yazi(450, 318, DURUM[d], "ok" if all(iyi.values()) and not ozel else "ariza", 12, True, "middle")
    oz = [K("Faz–nötr (L1 / L2 / L3)", f"{fnum(ln[0], 0)} / {fnum(ln[1], 0)} / {fnum(ln[2], 0)} V", "ok" if all(ALT <= x <= UST for x in ln) else "bad", "sınır 207 – 253 V"),
          K("Faz–faz", f"{fnum(ll[0], 0)} / {fnum(ll[1], 0)} / {fnum(ll[2], 0)} V", "ok" if all(360 <= x <= 440 for x in ll) else "bad", "sınır 360 – 440 V"),
          K("Nötr–toprak", oku["N–PE"], "ok" if iyi["N–PE"] else "bad", f"nötr akımı {fnum(abs(q['i_n']), 1)} A"),
          K("Gerilim düşümü (en kötü faz)", f"%{fnum(max(dus), 1)}", "ok" if max(dus) <= 5 else "bad", "trafo çıkışına göre")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "tablolar": [belirti]}
