"""Laboratuvar konusu — yıldız–üçgen yol verme: sargı ve hat gerilimleri/akımları, altı kablodaki akım, geçiş anı.

Model öğretim amaçlı sadeleştirilmiştir: doğrudan yol vermede akımın hıza bağlılığı I(n) = In + (Ia − In)·(1 − n³) alınır; yıldızda akım ve
moment bunun üçte biridir. Açık geçişte (kontaktörler arası boşluk) motorun artık gerilimi şebekeyle ters faza düşebildiği için geçiş
darbesi, o hızdaki üçgen akımının iki katına kadar çıkabilir (en kötü durum)."""
from __future__ import annotations

import math

from .core import C, K, ctl, fnum, num, opt

ID = "motor"
BASLIK = "Yıldız–üçgen yol verme"
IKON = "⚙"
GIRIS = ("Motor önce yıldız bağlanır: her sargı 400 V yerine 230 V görür, şebekeden çekilen akım ve moment üçte bire iner. Hızlanınca üçgene geçilir. "
         "Altı kablonun her birinden ne geçtiğini, termiğin nereye ve kaça ayarlanacağını, geçiş anındaki darbeyi ve yöntemin hangi yükte işe yaramadığını görün.")
AN = {"yildiz": "Yıldız (kalkış)", "gecis": "Geçiş anı", "ucgen": "Üçgen (çalışma)"}

KONTROLLER = [
    ctl("an", "Gösterilen an", "sec", "yildiz", secenek=opt(*AN.items())),
    ctl("pn_kw", "Motor gücü", "sec", 22, secenek=opt(*[(v, f"{v:g} kW") for v in (5.5, 7.5, 11, 15, 18.5, 22, 30, 37, 45, 55, 75, 90, 110, 132, 160)])),
    ctl("etiket", "Motor etiketi", "sec", "400_690", secenek=opt(("400_690", "400 V Δ / 690 V Y"), ("230_400", "230 V Δ / 400 V Y"))),
    ctl("kalkis", "Doğrudan kalkış akımı Ia / In", "sayi", 6.5, min=4, max=9, adim=0.1),
    ctl("m_kalkis", "Doğrudan kalkış momenti Ma / Mn", "sayi", 2.2, min=1, max=3.5, adim=0.1),
    ctl("yuk", "Yük türü", "sec", "fan", secenek=opt(("fan", "Fan / santrifüj pompa (moment hızın karesiyle artar)"), ("sabit", "Sabit momentli (konveyör, pistonlu kompresör, kırıcı)"))),
    ctl("m_yuk", "Yükün anma hızdaki momenti / Mn", "sayi", 0.8, min=0.1, max=1.2, adim=0.05),
    ctl("gecis_hiz", "Üçgene geçiş anındaki hız", "sayi", 85, min=30, max=98, adim=1, birim="%"),
    ctl("gecis", "Geçiş biçimi", "sec", "acik", secenek=opt(("acik", "Açık geçiş (kısa süre enerjisiz)"), ("kapali", "Kapalı geçiş (geçiş dirençli)"))),
    ctl("termik", "Termik rölenin yeri", "sec", "faz", secenek=opt(("faz", "Motor kolunda (sargıyla seri)"), ("hat", "Şebeke kolunda (ana kontaktörden önce)"))),
    ctl("termik_a", "Termik ayarı", "sayi", 24, min=1, max=400, adim=0.5, birim="A"),
]
U = 400.0


def _i_dol(n: float, in_a: float, ia: float) -> float:
    return in_a + (ia - in_a) * (1 - n ** 3)


def run(p: dict) -> dict:
    pn = num(p, "pn_kw", 22)
    cosphi, eta = 0.85, 0.91
    in_a = pn * 1000 / (math.sqrt(3) * U * cosphi * eta)
    k = num(p, "kalkis", 6.5); ia = k * in_a
    mk = num(p, "m_kalkis", 2.2); my = num(p, "m_yuk", 0.8); sabit = p.get("yuk") == "sabit"
    ng = num(p, "gecis_hiz", 85) / 100.0
    an_ = p.get("an") if p.get("an") in AN else "yildiz"
    acik = p.get("gecis") != "kapali"
    etiket_ok = p.get("etiket", "400_690") == "400_690"
    # yıldızda motorun hızlanabildiği en yüksek hız: yıldız momenti = yük momenti
    m_y = lambda n: mk / 3 * (1 + 0.6 * n) * (1 - n ** 6)             # noqa: E731 — yıldızda moment eğrisi (basitleştirilmiş: devrilme tümseği, senkron hızda sıfır)
    m_l = lambda n: my * (1.0 if sabit else (0.15 + 0.85 * n * n))    # noqa: E731
    n_max = 0.0
    for j in range(1, 100):
        if m_y(j / 100) <= m_l(j / 100):
            break
        n_max = j / 100
    hizlanir = n_max >= ng - 1e-9
    i_y0 = ia / 3; i_d_g = _i_dol(ng, in_a, ia); i_y_g = i_d_g / 3
    pik = i_d_g * (2.0 if acik else 1.0)
    i_sargi = in_a / math.sqrt(3)
    t_ok_yer = p.get("termik") == "faz"
    t_ayar = num(p, "termik_a", 24); t_hedef = i_sargi if t_ok_yer else in_a
    an = [f"Motor {fnum(pn, 1)} kW, anma akımı In = {fnum(in_a, 1)} A (400 V, cosφ 0,85, verim 0,91). Doğrudan yol verilseydi şebekeden {fnum(k, 1)} × In = {fnum(ia, 0)} A çeker, {fnum(mk, 1)} × Mn momentle kalkardı.",
          f"Yıldızda her sargının uçlarında 400 / √3 = 230 V vardır. Sargı akımı 1/√3'üne, hat akımı üçte birine iner: kalkışta {fnum(i_y0, 0)} A. Moment de gerilimin karesiyle düşer: {fnum(mk / 3, 2)} × Mn.",
          f"Üçgende her sargı 400 V görür. Hat akımı In = {fnum(in_a, 1)} A iken sargıdan ve motora giden altı kablonun her birinden In / √3 = {fnum(i_sargi, 1)} A geçer. Kablolar ve üçgen kolundaki cihazlar bu akıma göre seçilir.",
          f"Kontaktörler: ana ve üçgen kontaktörü 0,58 × In = {fnum(i_sargi, 1)} A, yıldız kontaktörü 0,33 × In = {fnum(in_a / 3, 1)} A taşır."]
    if not etiket_ok:
        an.append("Bu motorun etiketi 230 V Δ / 400 V Y: sargıları 230 V içindir. 400 V şebekede yalnız yıldız çalışabilir; üçgene geçildiği anda sargılar 400 V görür ve yanar. Yıldız–üçgen için etikette “400 V Δ” yazmalıdır.")
    if hizlanir:
        an.append(f"Yıldızda motor momenti yük momentinin üstünde kaldığı için motor geçiş hızına (%{fnum(ng * 100, 0)}) ulaşır. Geçişte üçgen akımı {fnum(i_d_g, 0)} A ({fnum(i_d_g / in_a, 1)} × In) olur.")
    else:
        an.append(f"Yıldızda moment üçte bire indiği için motor yükü ancak %{fnum(n_max * 100, 0)} hıza kadar hızlandırabilir; orada takılır. Zaman rölesi dolunca üçgene bu düşük hızda geçilir ve akım neredeyse doğrudan kalkış akımına sıçrar: "
                  f"{fnum(_i_dol(n_max, in_a, ia), 0)} A. Yıldız–üçgenin faydası kalmaz.")
    an.append((f"Açık geçişte motor birkaç on milisaniye enerjisiz kalır; rotorun mıknatıslanması sürdüğü için uçlarında gerilim vardır. Yeniden bağlandığında bu gerilim şebekeyle ters fazdaysa darbe, o hızdaki üçgen akımının iki katına kadar çıkar: ≈ {fnum(pik, 0)} A ({fnum(pik / in_a, 1)} × In, en kötü durum). "
               "Bu darbe kısa sürelidir ama manyetik açtırıcıyı çalıştırabilir, kontakları yıpratır, mile darbe verir.") if acik else
              f"Kapalı geçişte sargılar geçiş dirençleri üzerinden kesintisiz beslenir; darbe o hızdaki üçgen akımıyla ({fnum(i_d_g, 0)} A) sınırlı kalır. Bedeli dördüncü kontaktör ve dirençlerdir.")
    kt = [C("Motor etiketi", "400 V Δ / 690 V Y" if etiket_ok else "230 V Δ / 400 V Y", "üçgen gerilimi = şebeke gerilimi (400 V Δ)", etiket_ok, "TS EN 60034-1 (anma gerilimi ve bağlantı)", "dogrulanacak"),
          C("Yıldızda hızlanma", f"ulaşılan hız %{fnum(n_max * 100, 0)}", f"≥ geçiş hızı %{fnum(ng * 100, 0)}  (yıldız momenti > yük momenti)", hizlanir, "Yıldız–üçgen yol verme ilkesi: M ∝ U²", "ikincil"),
          C("Geçiş hızı", f"%{fnum(ng * 100, 0)}", "≥ %80 – 85 (akım düşmeden geçilirse fayda kalmaz)", ng >= 0.8 - 1e-9, "Uygulama kuralı", "ikincil"),
          C("Geçiş darbesi – kısa devre açtırıcısı", f"≈ {fnum(pik, 0)} A ({fnum(pik / in_a, 1)} × In)", f"manyetik eşik > darbe  (motor kesicisi ≈ 13 × In = {fnum(13 * in_a, 0)} A)", pik <= 13 * in_a, "TS EN 60947-4-1 (motor yol vericileri)", "dogrulanacak"),
          C("Termik rölenin ayarı", f"{fnum(t_ayar, 1)} A ({'motor kolunda' if t_ok_yer else 'şebeke kolunda'})", f"{'0,58 × In' if t_ok_yer else 'In'} = {fnum(t_hedef, 1)} A (± %5)", abs(t_ayar - t_hedef) <= 0.05 * t_hedef + 0.26,
            "TS EN 60947-4-1; Elektrik İç Tesisleri Yön. (motor koruması)", "dogrulanacak")]
    ds = ["Yıldız–üçgen akımı üçte bire indirir ama momenti de üçte bire indirir: yalnız boşta ya da hafif yükle kalkan makinelerde (fan, santrifüj pompa, boşta kompresör) işe yarar.",
          "Motora altı iletken gider ve her biri 0,58 × In taşır. Termik sargıyla seri bağlıysa 0,58 × In'e, şebeke kolundaysa In'e ayarlanır; karıştırılırsa motor ya korumasız kalır ya da sürekli açar.",
          "Üçgen bağlantıda uçların sırası önemlidir (U1–W2, V1–U2, W1–V2). Yanlış sıra geçişte faz kaymasını büyütür ve darbeyi artırır.",
          "Geçiş süresi yüke göre ayarlanır: erken geçiş doğrudan kalkış kadar akım çeker, geç geçiş motoru yıldızda aşırı ısıtır (yıldızda sürekli çalışmada akım artar).",
          "Topraklama açısından motor gövdesine tek koruma iletkeni gider; altı faz iletkeni iki ayrı kabloyla çekiliyorsa koruma iletkeni her iki kabloyla birlikte götürülür."]
    # akım – zaman (gösterim): hız yumuşak bir eğriyle artar; akım I(n) = I_yük + (Ia − I_yük)·(1 − n³)
    t1, t2 = 5.0, 6.5
    i_son = my * in_a
    i_g = lambda n: i_son + (ia - i_son) * (1 - n ** 3)             # noqa: E731
    yuks = lambda x: (1 - math.exp(-3 * x)) / (1 - math.exp(-3))     # noqa: E731 — 0 → 1
    n_end = ng if hizlanir else n_max
    pts_h, pts_d = [], []
    for j in range(0, 161):
        t = j * 0.05
        if t <= t1:
            i = i_g(n_end * yuks(t / t1)) / 3
        else:
            i = i_g(n_end + (1.0 - n_end) * yuks(min(1.0, (t - t1) / (t2 - t1))))
        pts_h.append([round(t, 2), round(i, 1)])
        pts_d.append([round(t, 2), round(i_g(yuks(min(1.0, t / 2.5))), 1)])
    k_g = int(t1 / 0.05) + 1
    pts_h[k_g:k_g] = [[t1 + 0.005, round(i_g(n_end), 1)], [t1 + 0.01, round(pik, 1)], [t1 + 0.03, round(i_g(n_end), 1)]]
    graf = [{"baslik": "Şebekeden çekilen akım (gösterim)", "x_ad": "zaman (s)", "y_ad": "hat akımı (A)", "seriler": [{"ad": "yıldız–üçgen", "renk": "#1a4d8f", "pts": pts_h}, {"ad": "doğrudan yol verme", "renk": "#94a3b8", "kesik": True, "pts": pts_d}],
             "yatay": [{"y": round(in_a, 1), "etiket": f"In = {fnum(in_a, 1)} A", "renk": "#15803d"}], "isaretler": [{"x": t1, "etiket": "üçgene geçiş"}], "ymin": 0}]
    tablo = {"baslik": "Yıldız ve üçgende büyüklükler", "cols": ["Büyüklük", "Yıldız (kalkış)", "Üçgen (çalışma)", "Oran"], "rows": [
        ["Sargı gerilimi", "230 V (400 / √3)", "400 V", "1 / √3"], ["Sargı akımı (kalkışta)", f"{fnum(ia / math.sqrt(3) / math.sqrt(3), 0)} A", f"{fnum(ia / math.sqrt(3), 0)} A", "1 / √3"],
        ["Şebekeden çekilen akım (kalkışta)", f"{fnum(i_y0, 0)} A", f"{fnum(ia, 0)} A", "1 / 3"], ["Kalkış momenti", f"{fnum(mk / 3, 2)} × Mn", f"{fnum(mk, 1)} × Mn", "1 / 3"],
        ["Altı kablonun her birindeki akım (anma yükte)", "—", f"{fnum(i_sargi, 1)} A (0,58 × In)", ""], ["Ana ve üçgen kontaktörü", f"{fnum(i_sargi, 1)} A", f"{fnum(i_sargi, 1)} A", "0,58 × In"],
        ["Yıldız kontaktörü", f"{fnum(in_a / 3, 1)} A", "açık", "0,33 × In"]], "not": "Kontaktör boyutlandırma oranları: TS EN 60947-4-1 ve üretici seçim çizelgeleri — durum: dogrulanacak"}
    cur = {"yildiz": i_y0, "gecis": pik, "ucgen": in_a}[an_]
    oz = [K("Anma akımı In", f"{fnum(in_a, 1)} A", "info", f"{fnum(pn, 1)} kW"), K("Kalkış akımı (yıldız)", f"{fnum(i_y0, 0)} A", "ok", f"doğrudan: {fnum(ia, 0)} A"),
          K("Kalkış momenti (yıldız)", f"{fnum(mk / 3, 2)} × Mn", "ok" if hizlanir else "bad", "yükü hızlandırıyor" if hizlanir else f"%{fnum(n_max * 100, 0)} hızda takılıyor"),
          K("Geçiş darbesi", f"{fnum(pik, 0)} A", "warn" if pik > 8 * in_a else "ok", f"{fnum(pik / in_a, 1)} × In, {'açık' if acik else 'kapalı'} geçiş"),
          K("Kablo başına akım (üçgen)", f"{fnum(i_sargi, 1)} A", "info", "0,58 × In, altı iletken")]
    sahne = {"tip": "motor", "an": an_, "an_ad": AN[an_], "i_hat": round(cur, 1), "i_sargi": round(cur / math.sqrt(3) if an_ != "yildiz" else cur, 1), "u_sargi": 230 if an_ == "yildiz" else 400,
             "in_a": round(in_a, 1), "etiket_ok": etiket_ok, "acik": acik, "termik_faz": t_ok_yer, "k_yildiz": an_ == "yildiz", "k_ucgen": an_ == "ucgen" or (an_ == "gecis" and not acik), "k_ana": True}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "grafikler": graf, "tablolar": [tablo]}
