"""Laboratuvar konusu — eşpotansiyel (potansiyel) dengeleme: ana ve tamamlayıcı dengeleme; banyo, kazan dairesi, hastane.

Model: arıza sürerken gövde, koruma iletkenindeki gerilim düşümü kadar yükselir. Aynı anda dokunulabilen ikinci bir iletken bölüm
(su borusu, radyatör, başka bir gövde) dengelemeye bağlı değilse toprak potansiyelinde kalır: iki nokta arasındaki fark kişinin
üzerine düşer. Tamamlayıcı dengeleme bu iki noktayı R dirençli bir iletkenle birleştirir. Dayanak: Topraklamalar Yön. m.8-a2, m.8-b, Çizelge-4b."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, cihaz_adi, cihaz_ia, ctl, etki, fnum, num, opt, vucut_akimi

ID = "esp"
BASLIK = "Eşpotansiyel dengeleme"
IKON = "🔗"
GIRIS = ("Çarpılma, bir gövdenin gerilimli olmasından değil, aynı anda dokunulan iki nokta arasında gerilim farkı olmasından doğar. "
         "Dengeleme bu noktaları birbirine bağlar. Bağlantıyı kaldırın, direncini değiştirin; iki nokta arasındaki gerilimi ve kişiden geçen akımı görün.")
MAHAL = {"banyo": "Banyo / duş (ıslak hacim)", "kazan": "Kazan dairesi / mekanik oda", "hastane": "Hastane — grup 2 mahal (ameliyathane, yoğun bakım)", "genel": "Bina girişi (ana dengeleme)"}

KONTROLLER = [
    ctl("mahal", "Mahal", "sec", "banyo", secenek=opt(*MAHAL.items())),
    ctl("ana", "Ana potansiyel dengeleme yapılmış (su, gaz, ısıtma boruları, yapı çeliği → ana topraklama barası)", "onay", True),
    ctl("tamamlayici", "Tamamlayıcı (yerel) potansiyel dengeleme yapılmış", "onay", True),
    ctl("r_bag", "Dengeleme bağlantısının direnci (iki nokta arası)", "sayi", 0.05, min=0.005, max=5, adim=0.005, birim="Ω", goster={"tamamlayici": [True]}),
    ctl("cihaz", "Koruma cihazı", "sec", "MCB", secenek=opt(("MCB", "Otomat (MCB)"), ("gG", "NH gG sigorta"))),
    ctl("egri", "Otomat eğrisi", "sec", "C", secenek=opt(("B", "B"), ("C", "C"), ("D", "D")), goster={"cihaz": ["MCB"]}),
    ctl("in_a", "Anma akımı", "sec", 16, secenek=opt(*[(v, f"{v} A") for v in (6, 10, 16, 20, 25, 32, 40, 63)])),
    ctl("rcd_ma", "Kaçak akım rölesi", "sec", 30, secenek=opt((0, "yok"), (30, "30 mA"), (300, "300 mA"))),
    ctl("u_govde", "Arıza sırasında gövdenin gerilimi (ana baraya göre)", "sayi", 100, min=10, max=230, adim=5, birim="V", yardim="TN'de faz ve koruma iletkeni aynı kesitteyse ≈ U0/2 = 115 V"),
    ctl("s_pe", "Devrenin koruma iletkeni kesiti", "sec", 2.5, secenek=opt(*[(v, f"{v:g} mm²") for v in (1.5, 2.5, 4, 6, 10, 16, 25, 35, 50)])),
    ctl("s_esp", "Tamamlayıcı dengeleme iletkeni kesiti", "sec", 4, secenek=opt(*[(v, f"{v:g} mm² Cu") for v in (1.5, 2.5, 4, 6, 10, 16)]), goster={"tamamlayici": [True]}),
    ctl("korumali", "Dengeleme iletkeni mekanik olarak korunmuş (boru / kanal içinde)", "onay", False, goster={"tamamlayici": [True]}),
]
KAYNAK = "Topraklamalar Yön. m.8-a2, m.8-b"


def run(p: dict) -> dict:
    mahal = p.get("mahal") if p.get("mahal") in MAHAL else "banyo"
    ana = bool(p.get("ana", True)); tam = bool(p.get("tamamlayici", True))
    r = num(p, "r_bag", 0.05); rcd = int(num(p, "rcd_ma", 30)); ug = num(p, "u_govde", 100)
    ia = rcd / 1000.0 if rcd else cihaz_ia(p, 5.0)                    # koruma düzenini 5 s içinde çalıştıran akım
    r_lim = 50.0 / ia
    # iki nokta arasındaki gerilim: bağlantı yoksa gövde geriliminin tamamı; varsa dengeleme iletkenindeki düşüm (en çok Ia·R)
    u_fark = min(ug, ia * r) if tam else (ug if ana else ug)
    hast = mahal == "hastane"
    i_b, _ = vucut_akimi(u_fark, 0.0)
    d_k, e_k = etki(i_b, math.inf)
    s_esp = num(p, "s_esp", 4); s_pe = num(p, "s_pe", 2.5); kor = bool(p.get("korumali"))
    s_min = max(2.5 if kor else 4.0, 0.5 * s_pe)
    an = [f"Mahaldeki bir cihazda yalıtım arızası oldu; koruma cihazı açana kadar gövde, ana topraklama barasına göre {fnum(ug, 0)} V'a çıktı. Aynı anda dokunulabilen ikinci nokta: "
          + {"banyo": "musluk / metal küvet / radyatör", "kazan": "boru hattı / kazan gövdesi", "hastane": "hasta yatağı, başka bir tıbbi cihaz", "genel": "su ve gaz borusu, yapı çeliği"}[mahal] + "."]
    if tam:
        an += [f"Tamamlayıcı dengeleme iki noktayı {fnum(r, 3)} Ω'luk iletkenle birleştiriyor. Aralarındaki gerilim, bu iletkenden geçebilecek en büyük akımın yarattığı düşümü geçemez: en çok Ia · R = {fnum(ia, 2 if ia < 1 else 0)} A × {fnum(r, 3)} Ω = {fnum(ia * r, 1)} V.",
               f"Yönetmeliğin ölçütü de budur: R ≤ 50 V / Ia = {fnum(r_lim, 2)} Ω (Ia: koruma düzenini çalıştıran akım — {'kaçak akım rölesinde IΔn' if rcd else cihaz_adi(p) + ', 5 s'})."]
    else:
        an += ["Tamamlayıcı dengeleme yok: ikinci nokta ana baranın potansiyelinde kalıyor, gövde ise yükselmiş durumda. Bir eli gövdede, diğeri muslukta olan kişi farkın tamamını üzerine alır.",
               "Islak hacimde vücut direnci düşüktür ve kişi çoğu zaman bırakamaz. Koruma cihazı izin verilen sürede açsa bile bu mahallerde yerel dengeleme ayrıca istenir."]
    if not ana:
        an.append("Ana potansiyel dengeleme de yapılmamış: binaya dışarıdan giren su ve gaz boruları uzak toprağın potansiyelini içeri taşır. Tesisatın koruma iletkeni arızada yükseldiğinde bütün gövdelerle borular arasında fark oluşur — yalnız bu mahalde değil, bütün binada.")
    if hast:
        an.append("Grup 2 tıbbi mahallerde hasta, kalbine yakın elektrotlarla cihazlara bağlı olabilir; birkaç on mikroamper bile tehlikelidir. Bu yüzden bütün gövdeler ve iletken bölümler eşpotansiyel baraya bağlanır ve bağlantı dirençleri çok küçük tutulur.")
    an.append(f"Bu durumda iki nokta arasındaki gerilim {fnum(u_fark, 1)} V; kişiden {fnum(i_b * 1000, 1)} mA geçer: {e_k}.")
    kt = [C("Ana potansiyel dengeleme", "yapılmış" if ana else "yapılmamış", "her binada: ana koruma iletkeni, ana topraklama iletkeni, su/gaz/ısıtma boruları, yapısal metal bölümler", ana, "Topraklamalar Yön. m.8-a2/i")]
    if tam:
        kt.append(C("Tamamlayıcı dengelemenin etkinliği", f"R = {fnum(r, 3)} Ω → Ia · R = {fnum(ia * r, 1)} V", f"R ≤ 50 V / Ia = {fnum(r_lim, 2)} Ω", r <= r_lim + 1e-9, "Topraklamalar Yön. m.8-b"))
        kt.append(C("Tamamlayıcı dengeleme iletkeni kesiti", f"{fnum(s_esp, 1)} mm² Cu ({'mekanik korumalı' if kor else 'korumasız'})",
                    f"≥ {fnum(s_min, 1)} mm²  (gövde ile yabancı iletken bölüm arasında 0,5 × koruma iletkeni; en az {'2,5' if kor else '4'} mm² Cu)", s_esp >= s_min - 1e-9, "Topraklamalar Yön. m.9, Çizelge-4b"))
    else:
        kt.append(C("Tamamlayıcı (yerel) potansiyel dengeleme", "yapılmamış", "ıslak hacimlerde ve otomatik ayırma koşulu tam sağlanamayan yerlerde uygulanır" if not hast else "grup 2 mahallerde zorunlu",
                    False if mahal in ("banyo", "hastane") else None, "Topraklamalar Yön. m.8-a2/ii; TS HD 60364-7-701 / -7-710", "dogrulanacak" if mahal != "kazan" else "resmi"))
    if hast:
        kt.append(C("Hastane: gövdeler ile eşpotansiyel bara arası direnç", f"{fnum(r, 3)} Ω" if tam else "bağlantı yok", "≤ 0,2 Ω", tam and r <= 0.2 + 1e-9, "TS HD 60364-7-710 (grup 2 tıbbi mahaller)", "dogrulanacak"))
    if mahal == "banyo":
        kt.append(C("Islak hacim devrelerinde ek koruma", f"{rcd} mA kaçak akım rölesi" if rcd else "kaçak akım rölesi yok", "30 mA", rcd == 30, "TS HD 60364-7-701; Elektrik İç Tesisleri Yön.", "dogrulanacak"))
    kt.append(C("İki nokta arasındaki gerilim", f"{fnum(u_fark, 1)} V", "≤ 50 V a.a. (kalıcı)", u_fark <= 50 + 1e-9, KAYNAK))
    ds = ["Topraklama gövdeyi toprağa bağlar; dengeleme gövdeleri birbirine bağlar. İkisi farklı işlerdir ve biri diğerinin yerini tutmaz.",
          "Dengeleme, koruma cihazı açmasa bile iki nokta arasındaki gerilimi sınırlar: bu yüzden “otomatik ayırma tam sağlanamıyorsa tamamlayıcı dengeleme yapılır” denir.",
          "Dengeleme iletkeni akım taşımak için değil, potansiyel eşitlemek için vardır; kesiti ısıl hesapla değil mekanik dayanımla belirlenir (Çizelge-4b).",
          "Plastik boru tesisatında musluk yabancı iletken bölüm olmaktan çıkabilir; ama metal küvet, radyatör, yapı demiri ve iletken zemin hâlâ oradadır.",
          "Ana dengeleme bina girişinde, borular binaya girdiği yerde yapılır: dışarıdan gelen potansiyel içeri girmeden tesisin potansiyeline bağlanmış olur."]
    kesit = {"baslik": "Potansiyel dengeleme iletkenlerinin kesitleri", "cols": ["", "Ana potansiyel dengeleme", "Tamamlayıcı potansiyel dengeleme"], "rows": [
        ["Normal", "0,5 × tesisin en büyük koruma iletkeninin kesiti", "iki gövde arasında: 1 × en küçük koruma iletkeni kesiti · gövde ile yabancı iletken bölüm arasında: 0,5 × koruma iletkeni kesiti"],
        ["En az", "6 mm² Cu", "mekanik olarak korunmuş: 2,5 mm² Cu · korunmamış: 4 mm² Cu"], ["Yapılabilecek sınırlama", "25 mm² Cu ya da eşdeğer iletkenlikte", "—"]],
        "not": "Topraklamalar Yön. m.9, Çizelge-4b — durum: resmi"}
    c = Cizim(900, 330, zemin=280)
    c.dikdortgen(60, 110, 190, 120, "ariza", "rgba(220,38,38,.07)", 3).yazi(155, 165, "CİHAZ (gövde)", "ariza", 12, True, "middle").yazi(155, 185, f"{fnum(ug, 0)} V", "ariza", 14, True, "middle").simsek(120, 120)
    c.hat("M155,110 V60 H40", "PE", kesik=True).yazi(46, 52, "koruma iletkeni → ana topraklama barası", "PE", 10.5)
    c.dikdortgen(620, 110, 190, 120, "ok" if (tam or not ana) is False else "cizgi", "rgba(148,163,184,.10)", 2)
    c.yazi(715, 165, {"banyo": "MUSLUK / KÜVET", "kazan": "BORU HATTI", "hastane": "HASTA YATAĞI", "genel": "SU / GAZ BORUSU"}[mahal], "#334155", 12, True, "middle")
    c.yazi(715, 185, f"{fnum(ug - u_fark, 0)} V", "ok" if u_fark <= 50 else "#334155", 14, True, "middle")
    if ana:
        c.hat("M715,230 V280", "PE", kesik=True).yazi(725, 262, "ana dengeleme", "PE", 10.5)
    else:
        c.yazi(715, 250, "ana dengelemeye bağlı değil (uzak toprak potansiyeli)", "ariza", 10.5, False, "middle")
    if tam:
        c.hat("M250,128 H620", "PE", hot=u_fark > 0.5, w=3, hot_renk="ok" if r <= r_lim else None).yazi(435, 120, f"tamamlayıcı dengeleme · {fnum(r, 3)} Ω · {fnum(s_esp, 1)} mm²", "ok" if r <= r_lim else "ariza", 11, True, "middle")
    else:
        c.hat("M250,128 H620", "soluk", kesik=True).yazi(435, 120, "dengeleme bağlantısı yok", "ariza", 11, True, "middle")
    c.kisi(435, 280, 252, 170, d_k, [f"{fnum(i_b * 1000, 1)} mA"]).hat("M435,220 L618,170", "ariza" if d_k == "bad" else "uyari" if d_k == "warn" else "#334155", w=2.2)
    c.yazi(435, 312, f"iki nokta arasında {fnum(u_fark, 1)} V", "ok" if u_fark <= 50 else "ariza", 12, True, "middle")
    oz = [K("İki nokta arasındaki gerilim", f"{fnum(u_fark, 1)} V", "ok" if u_fark <= 50 else "bad", "aynı anda dokunulan iki bölüm"), K("Kişiden geçen akım", f"{fnum(i_b * 1000, 1)} mA", d_k, e_k),
          K("İzin verilen bağlantı direnci", f"{fnum(r_lim, 2)} Ω", "info", f"50 V / Ia ; Ia = {fnum(ia, 2 if ia < 1 else 0)} A"), K("Dengeleme iletkeni", f"{fnum(s_esp, 1)} mm²" if tam else "yok", "ok" if tam and s_esp >= s_min else "bad", f"en az {fnum(s_min, 1)} mm²")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "tablolar": [kesit]}
