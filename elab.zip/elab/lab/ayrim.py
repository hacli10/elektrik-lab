"""Laboratuvar konusu — koruma ve işletme topraklaması: birleşik mi, ayrı mı? YG arızasının AG tesisine taşınması.

Model: trafo merkezinin YG koruma topraklaması (RE) üzerinden IE akımı akar → UE = RE·IE. Birleşik düzende AG nötrü bu potansiyele çıkar.
Ayrı düzende AG işletme topraklayıcısı d uzaklıktadır; YG topraklayıcısı eşdeğer yarım küre sayılarak (r = ρ / (2π·RE)) o noktadaki
zemin potansiyeli φ(d) = UE · r / d bulunur. Dayanak: Topraklamalar Yön. m.11 (Çizelge-13), m.12 (Çizelge-14)."""
from __future__ import annotations

import math

from .core import C, K, ctl, fnum, num, opt, utp

ID = "ayrim"
BASLIK = "Koruma ve işletme topraklaması"
IKON = "⏚"
GIRIS = ("Trafo merkezinde iki ayrı görev vardır: YG gövdelerinin topraklanması (koruma) ve AG yıldız noktasının topraklanması (işletme). "
         "İkisi aynı topraklayıcıya bağlanırsa YG tarafındaki bir toprak arızası AG nötrü üzerinden bütün tüketicilere taşınır. Ne zaman birleştirilir, ne zaman ayrılır?")

KONTROLLER = [
    ctl("duzen", "Topraklama düzeni", "sec", "birlesik", secenek=opt(("birlesik", "Birleşik: koruma ve işletme aynı topraklayıcıda"), ("ayri", "Ayrı: işletme topraklaması ayrı topraklayıcıda"))),
    ctl("ag", "AG şebekesi", "sec", "tn_cok", secenek=opt(("tn_tek", "TN — PEN yalnız trafo merkezinde topraklı"), ("tn_cok", "TN — PEN şebeke boyunca birçok noktada topraklı"), ("tt", "TT — tüketici gövdeleri ayrı topraklı"))),
    ctl("re_ohm", "YG koruma topraklaması direnci RE", "sayi", 2, min=0.1, max=30, adim=0.1, birim="Ω"),
    ctl("ie_a", "Toprağa akan akım IE (r · arıza akımı)", "sayi", 200, min=5, max=3000, adim=5, birim="A", yardim="34,5 kV, 1000 A sınırlı şebeke, kablo beslemesi r = 0,6 → 600 A; 100 A sınırlı OSB → 60 A"),
    ctl("tf_s", "YG arızasının temizlenme süresi tF", "sayi", 0.5, min=0.05, max=10, adim=0.05, birim="s"),
    ctl("rho", "Toprak özdirenci ρ", "sayi", 100, min=10, max=3000, adim=10, birim="Ω·m", goster={"duzen": ["ayri"]}),
    ctl("d_m", "İki topraklayıcı arasındaki uzaklık", "sayi", 20, min=2, max=100, adim=1, birim="m", goster={"duzen": ["ayri"]}),
    ctl("rb_ohm", "AG işletme topraklaması direnci RB", "sayi", 2, min=0.2, max=30, adim=0.1, birim="Ω", goster={"duzen": ["ayri"]}),
]
U0 = 230.0
K11 = "Topraklamalar Yön. m.11, Çizelge-13"


def run(p: dict) -> dict:
    birlesik = p.get("duzen") != "ayri"
    ag = p.get("ag") if p.get("ag") in ("tn_tek", "tn_cok", "tt") else "tn_cok"
    re_ = num(p, "re_ohm", 2); ie = num(p, "ie_a", 200); tf = num(p, "tf_s", 0.5); rho = num(p, "rho", 100); d = num(p, "d_m", 20)
    ue = re_ * ie
    u_tp = utp(tf)
    r_eq = rho / (2 * math.pi * re_)
    phi = lambda x: ue * min(1.0, r_eq / max(x, 1e-6))          # noqa: E731
    u_ag = ue if birlesik else phi(d)                            # AG nötrünün (işletme topraklamasının) yükseldiği gerilim
    tn = ag.startswith("tn")
    x_kat = 1 if ag == "tn_tek" else 2
    zorl_lim = 1200.0 if tf <= 5 else 250.0
    an = [f"YG tarafında bir faz trafo merkezinde gövdeye değdi. Arıza akımının toprağa geçen bölümü IE = {fnum(ie, 0)} A, koruma topraklamasından (RE = {fnum(re_, 1)} Ω) akar: "
          f"merkezin bütün topraklı kısımları UE = RE · IE = {fnum(ue, 0)} V'a çıkar ({fnum(tf, 2)} s boyunca)."]
    kt, ds = [], []
    if birlesik:
        an.append("Birleşik düzende AG yıldız noktası da aynı topraklayıcıya bağlıdır: nötr (ve TN'de PEN / PE) aynı anda UE'ye çıkar.")
        if tn:
            an.append(f"TN şebekede tüketicilerin bütün gövdeleri koruma iletkeniyle nötre bağlıdır. Yani kilometrelerce uzaktaki bir evin çamaşır makinesi de {fnum(ue, 0)} V'a çıkar — YG arızası tüketiciye taşınmıştır.")
            an.append("PEN şebeke boyunca birçok noktada topraklıysa bu gerilim yol boyunca bölünür ve tüketiciye daha küçüğü ulaşır; yönetmelik bu durumda iki kat UE'ye izin verir." if ag == "tn_cok"
                      else "PEN yalnız trafo merkezinde topraklıysa gerilimin tamamı tüketiciye ulaşır; bu en elverişsiz durumdur.")
            kt.append(C("Birleşik topraklama koşulu (dokunma gerilimi)", f"UE = {fnum(ue, 0)} V", f"≤ {x_kat if x_kat > 1 else ''}{' · ' if x_kat > 1 else ''}UTp = {fnum(x_kat * u_tp, 0)} V  (tF = {fnum(tf, 2)} s → UTp = {fnum(u_tp, 0)} V)",
                        ue <= x_kat * u_tp + 1e-9, K11 + (" (dipnot 7: X = 2)" if x_kat > 1 else " (dipnot 6)")))
        else:
            an.append(f"TT şebekede tüketici gövdeleri nötre bağlı değildir, kendi topraklayıcılarındadır: gövdeler yükselmez, kimse çarpılmaz. Ama cihazların yalıtımı faz ile gövde arasında U0 + UE = {fnum(U0 + ue, 0)} V görür.")
            kt.append(C("Birleşik topraklama koşulu (yalıtımın zorlanması)", f"UE = {fnum(ue, 0)} V", f"≤ {fnum(zorl_lim, 0)} V  (tF {'≤' if tf <= 5 else '>'} 5 s)", ue <= zorl_lim + 1e-9, K11 + "; m.12 Çizelge-14"))
        kt.append(C("Trafo merkezi içi", "YG ve AG gövdeleri aynı topraklayıcıda", "merkez içindeki bütün işletme ve koruma topraklamaları ortak sisteme bağlanır", True, "Topraklamalar Yön. m.11-b"))
        ds += ["Birleşik topraklama daha basit ve daha güvenlidir (tek, düşük dirençli sistem; merkez içinde potansiyel farkı yok) — ama yalnız UE yeterince küçükse.",
               "Koşulu sağlamanın yolları: RE'yi küçültmek (halka + kazıklar, bina temeli), arıza akımını ya da süresini küçültmek (dağıtım şirketi verisi), kablo ekranlarıyla akımın toprağa geçen payını (r) azaltmak.",
               "Bina içi ya da OSB'deki merkezlerde komşu topraklamalarla birleşen “global topraklama” koşulu kendiliğinden sağlar (m.11-c)."]
    else:
        an += [f"Ayrı düzende AG yıldız noktası, {fnum(d, 0)} m uzaktaki ayrı bir topraklayıcıya (RB) yalıtılmış iletkenle bağlanır. YG topraklayıcısının çevresindeki potansiyel hunisi oraya kadar uzanır: "
               f"o noktada zemin φ(d) ≈ UE · r / d = {fnum(ue, 0)} × {fnum(r_eq, 1)} / {fnum(d, 0)} = {fnum(u_ag, 0)} V'tadır (YG topraklayıcısı {fnum(r_eq, 1)} m yarıçaplı yarım küreye eşdeğer).",
               f"AG nötrü UE yerine yalnız bu {fnum(u_ag, 0)} V'a çıkar. Uzaklık arttıkça taşınan gerilim düşer.",
               f"Trafo merkezinin içinde ise AG panosunun gövdesi YG topraklamasında (UE), içindeki nötr ve fazlar ayrı topraklamadadır: aralarında ≈ {fnum(ue - u_ag, 0)} V oluşur. Merkezdeki AG teçhizatının yalıtımı buna dayanmalıdır."]
        if tn:
            kt.append(C("AG nötrüne taşınan gerilim", f"φ(d) = {fnum(u_ag, 0)} V", f"≤ {x_kat if x_kat > 1 else ''}{' · ' if x_kat > 1 else ''}UTp = {fnum(x_kat * u_tp, 0)} V", u_ag <= x_kat * u_tp + 1e-9, "Topraklamalar Yön. m.11-d, Çizelge-13"))
        else:
            kt.append(C("AG nötrüne taşınan gerilim (zorlanma)", f"φ(d) = {fnum(u_ag, 0)} V", f"≤ {fnum(zorl_lim, 0)} V", u_ag <= zorl_lim + 1e-9, "Topraklamalar Yön. m.11-d, Çizelge-13"))
        kt.append(C("Topraklayıcılar arası en küçük uzaklık", f"d = {fnum(d, 0)} m", "≥ 20 m  (işletme gerilimi < 50 kV)", d >= 20 - 1e-9, "Topraklamalar Yön. m.11-d"))
        kt.append(C("Merkezdeki AG teçhizatının zorlanması", f"UE − φ(d) = {fnum(ue - u_ag, 0)} V → yalıtım üzerinde U0 + {fnum(ue - u_ag, 0)} = {fnum(U0 + ue - u_ag, 0)} V", f"≤ U0 + {fnum(zorl_lim, 0)} = {fnum(U0 + zorl_lim, 0)} V",
                    ue - u_ag <= zorl_lim + 1e-9, "Topraklamalar Yön. m.12, Çizelge-14"))
        ds += ["Ayırma, UE küçültülemediğinde başvurulan çözümdür; direk tipi trafolarda ve yüksek özdirençli arazide olağandır.",
               "Ayrı topraklamanın bedeli: iki topraklayıcının gerçekten ayrı kalması gerekir. Aradaki bir su borusu, kablo zırhı ya da çit ikisini fark ettirmeden birleştirir.",
               "20 m alt sınırdır; gerçek uzaklık potansiyel hunisinin o noktadaki değerine göre belirlenir. Büyük topraklayıcının hunisi de büyüktür.",
               "Nötr iletkeni merkezden ayrı topraklayıcıya kadar yalıtılmış olarak götürülür; yol boyunca toprağa değmemelidir."]
    an.append("Sözlük — koruma topraklaması: gövdelerin (aktif olmayan metal kısımların) topraklanması. İşletme topraklaması: işletme akım devresinin bir noktasının (yıldız noktası) topraklanması. "
              "Fonksiyon topraklaması: bir cihazın çalışması için gereken topraklama (haberleşme, ölçü). Yıldırım topraklaması: yıldırım akımının toprağa iletilmesi.")
    prof = [[round(x, 1), round(phi(x), 1)] for x in [0.5 * k for k in range(1, 201)]]
    graf = [{"baslik": "YG topraklayıcısından uzaklaştıkça zemin potansiyeli", "x_ad": "YG topraklayıcısından uzaklık (m)", "y_ad": "zemin potansiyeli (V)", "seriler": [{"ad": "φ(x)", "renk": "#b45309", "pts": prof}],
             "yatay": [{"y": round(x_kat * u_tp if tn else zorl_lim, 1), "etiket": ("izin verilen: " + (f"{x_kat}·UTp" if x_kat > 1 else "UTp") + f" = {fnum(x_kat * u_tp, 0)} V") if tn else f"izin verilen {fnum(zorl_lim, 0)} V", "renk": "#15803d"}],
             "isaretler": ([] if birlesik else [{"x": d, "etiket": f"AG topraklayıcısı {fnum(d, 0)} m"}]), "ymin": 0}]
    tanim = {"baslik": "Topraklama çeşitleri", "cols": ["Çeşit", "Neyi topraklar", "Amacı", "Örnek"], "rows": [
        ["Koruma topraklaması", "Gövdeler: işletme akım devresine ait olmayan iletken kısımlar", "Yalıtım arızasında gövdede tehlikeli gerilimin kalmasını önlemek", "Pano gövdesi, motor gövdesi, trafo kazanı, hücre"],
        ["İşletme topraklaması", "İşletme akım devresinin bir noktası", "Şebekenin toprağa göre gerilimini belirlemek, arızanın algılanmasını sağlamak", "AG yıldız noktası (TN, TT), OG nötr direnci, gerilim trafosu primer yıldız noktası"],
        ["Fonksiyon topraklaması", "Bir cihazın ya da sistemin referans noktası", "Cihazın işlevini yerine getirmesi (koruma amacı yoktur)", "Haberleşme, ölçü ve kumanda referansı, parafudr, ekran"],
        ["Yıldırıma karşı topraklama", "Yakalama ucu ve iniş iletkenleri", "Yıldırım akımını toprağa iletmek", "Yıldırımlık, hava hattı toprak teli ve direk"]],
        "not": "Topraklamalar Yön. m.4 (tanımlar) — durum: resmi"}
    kos = {"baslik": "Birleşik topraklama ne zaman yapılabilir?", "cols": ["AG şebekesi", "Arıza süresi", "Dokunma gerilimi açısından", "Zorlanma gerilimi açısından"], "rows": [
        ["TT", "tF ≤ 5 s", "uygulanmaz", "UE ≤ 1200 V"], ["TT", "tF > 5 s", "uygulanmaz", "UE ≤ 250 V"],
        ["TN — PEN yalnız merkezde topraklı", "—", "UE ≤ UTp", "uygulanmaz"], ["TN — PEN birçok noktada topraklı", "—", "UE ≤ X · UTp ; X = 2 (özel durumlarda 5'e kadar)", "uygulanmaz"]],
        "not": "Topraklamalar Yön. m.11, Çizelge-13 — durum: resmi. Koşul sağlanmazsa topraklamalar ayrılır (m.11-d) ve topraklayıcılar arasında en az 20 m bırakılır."}
    ok = all(k["ok"] is not False for k in kt)
    oz = [K("Topraklama gerilimi UE", f"{fnum(ue, 0)} V", "info", f"RE {fnum(re_, 1)} Ω × IE {fnum(ie, 0)} A"),
          K("AG nötrüne taşınan", f"{fnum(u_ag, 0)} V", "ok" if (kt[0]["ok"]) else "bad", "tamamı (birleşik)" if birlesik else f"{fnum(d, 0)} m uzakta"),
          K("İzin verilen", f"{fnum(x_kat * u_tp if tn else zorl_lim, 0)} V", "info", (f"{x_kat}·UTp" if x_kat > 1 else "UTp") + f", tF {fnum(tf, 2)} s" if tn else "yalıtım zorlanması"),
          K("Tüketici gövdeleri", f"{fnum(u_ag if tn else 0, 0)} V", ("ok" if u_ag <= x_kat * u_tp else "bad") if tn else "ok", "nötrle birlikte yükselir (TN)" if tn else "etkilenmez (TT)"),
          K("Sonuç", "uygun" if ok else "uygun değil", "ok" if ok else "bad", "birleşik" if birlesik else "ayrı")]
    sahne = {"tip": "ayrim", "birlesik": birlesik, "tn": tn, "ue": round(ue), "u_ag": round(u_ag), "d": d, "r_eq": round(r_eq, 1), "govde": round(u_ag if tn else 0), "ok": ok,
             "ag_ad": {"tn_tek": "TN (PEN tek noktada)", "tn_cok": "TN (PEN çok noktada)", "tt": "TT"}[ag], "merkez_fark": round(0 if birlesik else ue - u_ag)}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "grafikler": graf, "tablolar": [kos, tanim]}
