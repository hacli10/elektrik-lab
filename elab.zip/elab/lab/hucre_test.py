"""Laboratuvar konusu — OG hücre deneyleri: şebeke frekanslı dayanım (70 kV), kısmi boşalma, yalıtım direnci, ana devre direnci;
bağlantı biçimleri (hangi faz gerilimde, hangileri topraklı).

Yalıtım düzeyleri TEDAŞ-MLZ/95-007.E'den (resmi): Ur 7,2 / 12 / 17,5 / 36 kV için 1 dakikalık şebeke frekanslı dayanım gerilimi
toprağa göre ve fazlar arası 20 / 28 / 38 / 70 kV, ayırma uzaklığında 23 / 32 / 45 / 80 kV; yardımcı devreler 2 kV.
Kısmi boşalma: TS EN 62271-200 m.7.101 (bileşenler için) ve TS EN 60270 — gerilim değerleri ve sınırlar doğrulanacak."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, ctl, fnum, num, opt

ID = "hucre_test"
BASLIK = "OG hücre deneyleri"
IKON = "⚡"
GIRIS = ("Hücrenin yalıtımı, işletme geriliminin çok üstünde bir gerilimle sınanır. Önemli olan yalnız gerilimin değeri değil, nereye uygulandığıdır: "
         "bir faz gerilimdeyken diğer fazlar ve gövde topraklanır, böylece hem faz–toprak hem faz–faz yalıtımı aynı anda zorlanır.")
DUZEY = {7.2: (20, 23, 60, 70), 12.0: (28, 32, 75, 85), 17.5: (38, 45, 95, 110), 36.0: (70, 80, 170, 195)}       # (pf, pf ayırma, darbe, darbe ayırma)
DENEY = {"pf": "Şebeke frekanslı dayanım gerilimi deneyi (1 dakika)", "pd": "Kısmi boşalma ölçümü", "megger": "Yalıtım direnci ölçümü (megger)", "direnc": "Ana devre direncinin ölçülmesi", "yardimci": "Yardımcı ve kontrol devreleri dayanım deneyi"}
BAG = {"faz_toprak": "Bir faz gerilimde; diğer iki faz ve gövde topraklı (her faz sırayla)", "uc_faz": "Üç faz birleştirilip gerilimde; gövde topraklı", "ayirma": "Açık kontaklar arası (ayırma aralığı): bir taraf gerilimde, karşı taraf ve gövde topraklı"}
K95 = "TEDAŞ-MLZ/95-007.E (anma yalıtım düzeyleri; rutin deneyler m.4.2)"
D = "dogrulanacak"

KONTROLLER = [
    ctl("deney", "Deney", "sec", "pf", secenek=opt(*DENEY.items())),
    ctl("ur_kv", "Hücrenin anma gerilimi Ur", "sec", 36.0, secenek=opt((7.2, "7,2 kV"), (12.0, "12 kV"), (17.5, "17,5 kV"), (36.0, "36 kV"))),
    ctl("baglanti", "Bağlantı biçimi", "sec", "faz_toprak", secenek=opt(*BAG.items()), goster={"deney": ["pf", "pd", "megger"]}),
    ctl("faz", "Gerilim uygulanan faz", "sec", "L1", secenek=opt(("L1", "L1"), ("L2", "L2"), ("L3", "L3")), goster={"deney": ["pf", "pd", "megger"], "baglanti": ["faz_toprak", "ayirma"]}),
    ctl("yer", "Deneyin yapıldığı yer", "sec", "fabrika", secenek=opt(("fabrika", "Fabrika (rutin deney)"), ("saha", "Saha (montaj sonrası)")), goster={"deney": ["pf"]}),
    ctl("u_kv", "Uygulanan gerilim", "sayi", 70, min=1, max=100, adim=0.5, birim="kV", goster={"deney": ["pf"]}),
    ctl("sure_s", "Süre", "sayi", 60, min=5, max=120, adim=5, birim="s", goster={"deney": ["pf", "yardimci"]}),
    ctl("atlama", "Deney sırasında atlama / delinme oldu", "onay", False, goster={"deney": ["pf", "yardimci"]}),
    ctl("sebeke", "Hücrenin kullanılacağı şebeke", "sec", "toprakli", secenek=opt(("toprakli", "Yıldız noktası topraklı (doğrudan / direnç)"), ("yalitilmis", "Yıldız noktası yalıtılmış / rezonans topraklı")), goster={"deney": ["pd"]}),
    ctl("u_on", "Ön gerilim (en az 10 s)", "sayi", 27, min=1, max=60, adim=0.1, birim="kV", goster={"deney": ["pd"]}),
    ctl("u_olc", "Ölçme gerilimi", "sayi", 22.9, min=1, max=50, adim=0.1, birim="kV", goster={"deney": ["pd"]}),
    ctl("pd_pc", "Ölçülen kısmi boşalma", "sayi", 8, min=0, max=500, adim=1, birim="pC", goster={"deney": ["pd"]}),
    ctl("gurultu_pc", "Arka plan gürültüsü (deney nesnesi bağlıyken, gerilimsiz)", "sayi", 3, min=0, max=200, adim=1, birim="pC", goster={"deney": ["pd"]}),
    ctl("sinir_pc", "Kabul sınırı (şartname / anlaşma)", "sec", 20, secenek=opt((10, "10 pC"), (20, "20 pC"), (50, "50 pC")), goster={"deney": ["pd"]}),
    ctl("u_megger", "Megger gerilimi", "sec", 5000, secenek=opt((2500, "2500 V d.a."), (5000, "5000 V d.a.")), goster={"deney": ["megger"]}),
    ctl("r15", "15. saniyede okunan", "sayi", 8, min=0.001, max=500, adim=0.1, birim="GΩ", goster={"deney": ["megger"]}),
    ctl("r60", "60. saniyede okunan", "sayi", 14, min=0.001, max=500, adim=0.1, birim="GΩ", goster={"deney": ["megger"]}),
    ctl("r600", "10. dakikada okunan", "sayi", 40, min=0.001, max=1000, adim=0.5, birim="GΩ", goster={"deney": ["megger"]}),
    ctl("r_olc", "Ölçülen ana devre direnci", "sayi", 85, min=5, max=1000, adim=1, birim="µΩ", goster={"deney": ["direnc"]}),
    ctl("r_tip", "Tip deneyinde (ısınma deneyinden önce) ölçülen değer", "sayi", 80, min=5, max=1000, adim=1, birim="µΩ", goster={"deney": ["direnc"]}),
    ctl("i_dc", "Ölçme akımı (d.a.)", "sayi", 100, min=1, max=600, adim=1, birim="A", goster={"deney": ["direnc"]}),
    ctl("u_yard", "Uygulanan gerilim", "sayi", 2, min=0.2, max=3, adim=0.1, birim="kV", goster={"deney": ["yardimci"]}),
]


def _sema(ur: float, bag: str, faz: str, etiket: str, kaynak_ad: str, ok: bool) -> Cizim:
    c = Cizim(900, 320, zemin=280)
    c.dikdortgen(300, 40, 420, 210, "#334155", "rgba(148,163,184,.08)", 2.2, False, 6).yazi(510, 32, f"HÜCRE (metal mahfaza) · Ur {fnum(ur, 1)} kV", "#334155", 11.5, True, "middle")
    c.hat("M720,250 H760 V280", "PE", kesik=True).toprak(760, 280).yazi(770, 268, "gövde topraklı", "PE", 10.5)
    c.kutu(20, 96, 210, 64, kaynak_ad, etiket, "gecersiz" if not ok else "acti")
    xs = {"L1": 380, "L2": 510, "L3": 640}
    for f, x in xs.items():
        gerilimde = (bag == "uc_faz") or (f == faz)
        col = "ariza" if gerilimde else "PE"
        if bag == "ayirma":
            c.hat(f"M{x},70 V118", "ariza" if f == faz else "PE", w=5).hat(f"M{x},160 V215", "PE", w=5).hat(f"M{x - 12},128 L{x},118", "cizgi", w=2.4)
            c.yazi(x + 16, 142, "açık", "#64748b", 10)
            c.hat(f"M{x},215 V250", "PE", kesik=True)
            if f == faz:
                c.hat(f"M230,128 H256 V70 H{x}", "ariza", hot=True)
            else:
                c.hat(f"M{x},70 H{x + 40} V250", "PE", kesik=True)
        else:
            c.hat(f"M{x},70 V215", col, w=5)
            if gerilimde:
                c.hat(f"M230,128 H256 V{60 if bag == 'uc_faz' else 70} H{x}" + (" V70" if bag == "uc_faz" else ""), "ariza", hot=True)
            else:
                c.hat(f"M{x},215 V250", "PE", kesik=True)
        c.yazi(x - 10, 88, f, col, 12, True, "end")
        if not gerilimde or bag == "ayirma":
            c.yazi(x - 8, 238, "topraklı", "PE", 10, False, "end")
    c.hat("M300,250 H720", "PE", w=2.4)
    if bag == "faz_toprak":
        c.yazi(510, 300, f"{faz} gerilimde: {faz}–toprak ve {faz}–diğer fazlar yalıtımı birlikte zorlanır (üç faz için üç deney)", "#334155", 11.5, True, "middle")
    elif bag == "uc_faz":
        c.yazi(510, 300, "üç faz birlikte gerilimde: yalnız faz–toprak yalıtımı zorlanır; faz–faz yalıtımı denenmez", "#334155", 11.5, True, "middle")
    else:
        c.yazi(510, 300, f"anahtar açık: {faz} üst tarafı gerilimde, alt taraf topraklı → ayırma aralığı zorlanır", "#334155", 11.5, True, "middle")
    return c


def run(p: dict) -> dict:
    deney = p.get("deney") if p.get("deney") in DENEY else "pf"
    ur = float(num(p, "ur_kv", 36.0)); ur = ur if ur in DUZEY else 36.0
    pf, pf_a, lw, lw_a = DUZEY[ur]
    bag = p.get("baglanti") if p.get("baglanti") in BAG else "faz_toprak"
    faz = p.get("faz") if p.get("faz") in ("L1", "L2", "L3") else "L1"
    kt, an, ds, graf = [], [], [], []
    duzey = {"baslik": "Anma yalıtım düzeyleri", "cols": ["Ur (kV)", "İşletme gerilimi (kV)", "Şebeke frekanslı dayanım, 1 dk — toprağa ve fazlar arası (kV)", "— ayırma uzaklığında (kV)", "Yıldırım darbe — toprağa ve fazlar arası (kV tepe)", "— ayırma uzaklığında (kV tepe)"],
             "rows": [[fnum(k, 1), i, str(v[0]), str(v[1]), str(v[2]), str(v[3])] for (k, v), i in zip(DUZEY.items(), ("6,3", "10,5", "15,8", "33"))],
             "not": f"{K95} — durum: resmi. Yardımcı donanım için şebeke frekanslı dayanım gerilimi 2 kV."}
    if deney == "pf":
        saha = p.get("yer") == "saha"
        gerek = (pf_a if bag == "ayirma" else pf) * (0.8 if saha else 1.0)
        u = num(p, "u_kv", 70); sure = num(p, "sure_s", 60); atl = bool(p.get("atlama"))
        an = [f"Ur = {fnum(ur, 1)} kV hücre için 1 dakikalık şebeke frekanslı dayanım gerilimi: toprağa göre ve fazlar arası {pf} kV, ayırma uzaklığında {pf_a} kV (etken)." + (" Sahada, montajdan sonra yapılan deneyde bu değerin %80'i uygulanır." if saha else ""),
              {"faz_toprak": f"Bağlantı: {faz} fazına gerilim uygulanır; diğer iki faz birbirine ve topraklı gövdeye bağlanır. Böylece {faz} ile toprak arası ve {faz} ile komşu fazlar arası yalıtım aynı anda {fnum(u, 1)} kV görür. Deney üç faz için tekrarlanır.",
               "uc_faz": "Bağlantı: üç faz birbirine bağlanıp gerilim uygulanır; gövde topraklıdır. Fazlar aynı potansiyelde olduğundan aralarındaki yalıtım zorlanmaz: bu bağlantı tek başına yeterli değildir.",
               "ayirma": f"Bağlantı: anahtarlama elemanı açık; {faz} fazının bir tarafına gerilim uygulanır, karşı taraf ve gövde topraklanır. Açık kontaklar arasındaki ayırma aralığı {pf_a} kV ile sınanır (bakımda güvenliği sağlayan aralık)."}[bag],
              "Gerilim sıfırdan başlatılıp hızla deney değerine çıkarılır, 60 saniye tutulur ve hızla indirilir. Kabul ölçütü tektir: yıkıcı boşalma (delinme, atlama) olmaması. Kaçak akımın değeri ölçüt değildir."]
        kt = [C("Deney gerilimi", f"{fnum(u, 1)} kV", f"= {fnum(gerek, 1)} kV ({'ayırma uzaklığında' if bag == 'ayirma' else 'toprağa göre ve fazlar arası'}{', saha: %80' if saha else ''})", abs(u - gerek) <= 0.03 * gerek, K95 + ("; TS EN 62271-200 (saha deneyi %80)" if saha else ""), "resmi" if not saha else D),
              C("Deney süresi", f"{fnum(sure, 0)} s", "60 s", abs(sure - 60) < 1, K95),
              C("Deney sonucu", "atlama / delinme oldu" if atl else "yıkıcı boşalma yok", "yıkıcı boşalma olmamalı", not atl, "TS EN 62271-200 m.7.1; TS EN 62271-1", D),
              C("Bağlantı biçimi", BAG[bag].split(";")[0], "her faz sırayla gerilimde, diğer fazlar ve gövde topraklı; ayrıca ayırma aralığı", bag != "uc_faz", "TS EN 62271-1 (dielektrik deneylerde bağlantı düzenleri)", D)]
        if u > gerek * 1.03:
            an.append("Uygulanan gerilim gerekenden yüksek: yalıtım gereksiz yere yaşlandırılır. Dayanım deneyi yalıtımı yıpratan bir deneydir; tekrarlarda da %80 ile sınırlanır.")
        ds = ["Gerilim trafoları ve parafudrlar bu deneyden önce ayrılır (ya da primerleri sökülür): 70 kV gerilim trafosunu doyurur, parafudru iletime sokar. Akım trafolarının sekonderleri kısa devre edilip topraklanır.",
              "Kapasitif gerilim göstergeleri ve bağlı kablolar deney devresine dahil edilmez; kablo başlıkları ayrılır.",
              "Dayanım deneyi “geçti / kaldı” deneyidir. Yalıtımın durumunu (nem, kirlenme, boşluk) göstermez; onu kısmi boşalma ve yalıtım direnci ölçümleri gösterir.",
              "Deney alanı çevrilir, topraklama çubuğu hazır tutulur; deneyden sonra faz önce toprak çubuğuyla boşaltılır, sonra dokunulur."]
        gecerli = abs(u - gerek) <= 0.03 * gerek and abs(sure - 60) < 1
        sema = _sema(ur, bag, faz, f"{fnum(u, 1)} kV · {fnum(sure, 0)} s", "Deney trafosu", gecerli and not atl)
        oz = [K("Gereken deney gerilimi", f"{fnum(gerek, 1)} kV", "info", "1 dk, 50 Hz"), K("Uygulanan", f"{fnum(u, 1)} kV", "ok" if abs(u - gerek) <= 0.03 * gerek else "bad", f"{fnum(u / (ur / math.sqrt(3)), 1)} × faz–toprak işletme gerilimi"),
              K("Sonuç", "kaldı" if atl else ("geçti" if gecerli else "geçersiz"), "bad" if atl else ("ok" if gecerli else "warn"), ("yıkıcı boşalma " + ("var" if atl else "yok")) if (atl or gecerli) else "gerilim ya da süre gerekenden farklı: deney sayılmaz"), K("Yıldırım darbe düzeyi", f"{lw} kV tepe", "info", "tip deneyi")]
    elif deney == "pd":
        topr = p.get("sebeke") != "yalitilmis"
        g_olc = 1.1 * ur / (math.sqrt(3) if topr else 1.0); g_on = 1.3 * ur / (math.sqrt(3) if topr else 1.0)
        u_on = num(p, "u_on", 27); u_olc = num(p, "u_olc", 22.9); pd = num(p, "pd_pc", 8); gur = num(p, "gurultu_pc", 3); lim = num(p, "sinir_pc", 20)
        an = [f"Kısmi boşalma, yalıtımın içindeki küçük bir boşlukta ya da keskin bir kenarda yalıtımı tam delmeden oluşan küçük kıvılcımlardır; pC (pikokulon) ile ölçülür. Dayanım deneyini geçen bir parçada da olabilir ve yıllar içinde yalıtımı içeriden oyar.",
              f"Yöntem: gerilim önce ön gerilim değerine çıkarılır ve en az 10 saniye tutulur (bu sırada boşalmalar dikkate alınmaz), sonra ölçme gerilimine indirilir ve boşalma düzeyi okunur. Ur = {fnum(ur, 1)} kV için: işletme faz–toprak gerilimi Ur/√3 = {fnum(ur / math.sqrt(3), 1)} kV; "
              f"ölçme gerilimi {'1,1·Ur/√3' if topr else '1,1·Ur'} = {fnum(g_olc, 1)} kV; ön gerilim {'1,3·Ur/√3' if topr else '1,3·Ur'} = {fnum(g_on, 1)} kV ({'yıldız noktası topraklı' if topr else 'yalıtılmış / rezonans topraklı'} şebeke).",
              f"Deneyden önce devre kalibre edilir (bilinen bir yük enjekte edilir) ve arka plan gürültüsü ölçülür: {fnum(gur, 0)} pC. Gürültü, kabul sınırının yarısından küçük olmalıdır; değilse ölçülen değerin ne kadarının deney nesnesinden geldiği bilinemez.",
              f"Ölçülen değer {fnum(pd, 0)} pC, kabul sınırı {fnum(lim, 0)} pC.",
              "Uygulamada 36 kV sınıfında 23 kV (1,1·Ur/√3) ve 21 kV (Ur/√3) değerleri sık geçer: ilki standardın ölçme gerilimi, ikincisi işletme faz–toprak gerilimidir. Hangi gerilimde hangi sınırın isteneceği şartname ve imalatçı–alıcı anlaşmasıyla belirlenir."]
        kt = [C("Ön gerilim", f"{fnum(u_on, 1)} kV", f"{'1,3·Ur/√3' if topr else '1,3·Ur'} = {fnum(g_on, 1)} kV, en az 10 s", abs(u_on - g_on) <= 0.05 * g_on, "TS EN 62271-200 m.7.101 ve Ek B", D),
              C("Ölçme gerilimi", f"{fnum(u_olc, 1)} kV", f"{'1,1·Ur/√3' if topr else '1,1·Ur'} = {fnum(g_olc, 1)} kV", abs(u_olc - g_olc) <= 0.05 * g_olc, "TS EN 62271-200 m.7.101 ve Ek B", D),
              C("Arka plan gürültüsü", f"{fnum(gur, 0)} pC", f"kabul sınırının yarısından küçük (< {fnum(lim / 2, 0)} pC)", gur < lim / 2, "TS EN 60270 (kısmi boşalma ölçmeleri)", D),
              C("Kısmi boşalma düzeyi", f"{fnum(pd, 0)} pC", f"≤ {fnum(lim, 0)} pC (şartname / anlaşma)", pd <= lim + 1e-9, "TS EN 62271-200 m.7.101 (bileşenler için; sınır anlaşmayla); ölçü trafoları: TS EN 61869-1; kuru trafo: 10 pC (TEDAŞ-MLZ/99-031.B)", D),
              C("Bağlantı biçimi", BAG[bag].split(";")[0], "tek fazlı devre: her faz sırayla gerilimde, diğer fazlar ve gövde topraklı", bag == "faz_toprak", "TS EN 62271-200 Ek B", D)]
        ds = ["Kısmi boşalma ölçümü dayanım deneyinin göremediğini görür: reçine içindeki hava kabarcığı, gevşek ekranlama, keskin kenar, kirli yüzey. Katı yalıtımlı (reçine) bileşenlerde en önemli kalite deneyidir.",
              "Ölçüm çok küçük akım darbelerine bakar; yakındaki kaynak makinesi, sürücü, floresan lamba, gevşek bir topraklama ölçümü bozar. Bu yüzden ekranlı deney odasında ve filtrelenmiş beslemeyle yapılır.",
              "Boşalmanın başladığı (PDIV) ve söndüğü (PDEV) gerilimler de kaydedilir: sönme gerilimi işletme faz–toprak geriliminin üstündeyse boşalma işletmede sürmez.",
              "Tek başına pC değeri yetmez; boşalmaların gerilim dalgasının hangi açısında toplandığı (faz çözümlemeli desen) kaynağın türünü söyler: iç boşluk, yüzey boşalması, korona."]
        sema = _sema(ur, bag, faz, f"{fnum(u_olc, 1)} kV · {fnum(pd, 0)} pC", "Deney trafosu + kuplaj kondansatörü", pd <= lim and gur < lim / 2)
        graf = [{"baslik": "Kısmi boşalma deneyinde gerilim (gösterim)", "x_ad": "zaman (s)", "y_ad": "gerilim (kV)", "zaman": True,
                 "seriler": [{"ad": "uygulanan gerilim", "renk": "#1a4d8f", "pts": [[0, 0], [10, u_on], [22, u_on], [28, u_olc], [60, u_olc], [68, 0]]}],
                 "yatay": [{"y": round(ur / math.sqrt(3), 1), "etiket": f"işletme faz–toprak gerilimi {fnum(ur / math.sqrt(3), 1)} kV", "renk": "#15803d"}], "isaretler": [{"x": 10, "etiket": "ön gerilim ≥ 10 s"}, {"x": 28, "etiket": "ölçme"}], "ymin": 0}]
        oz = [K("Ölçme gerilimi", f"{fnum(g_olc, 1)} kV", "info", "1,1·Ur/√3" if topr else "1,1·Ur"), K("Ön gerilim", f"{fnum(g_on, 1)} kV", "info", "en az 10 s"),
              K("Ölçülen boşalma", f"{fnum(pd, 0)} pC", "ok" if pd <= lim else "bad", f"sınır {fnum(lim, 0)} pC"), K("Arka plan gürültüsü", f"{fnum(gur, 0)} pC", "ok" if gur < lim / 2 else "bad", f"< {fnum(lim / 2, 0)} pC olmalı"),
              K("İşletme faz–toprak gerilimi", f"{fnum(ur / math.sqrt(3), 1)} kV", "info", "Ur/√3")]
    elif deney == "megger":
        r15, r60, r600 = num(p, "r15", 8), num(p, "r60", 14), num(p, "r600", 40)
        dar = r60 / r15; pi = r600 / r60; r_min = (ur + 1) / 1000.0            # GΩ: (kV + 1) MΩ
        an = [f"Megger, yalıtıma {fnum(num(p, 'u_megger', 5000), 0)} V doğru gerilim uygular ve geçen akımdan direnci bulur. Okuma zamanla artar: başta kapasiteyi dolduran ve yalıtımı kutuplayan akımlar da akar, sonunda yalnız gerçek kaçak akım kalır.",
              f"Okumalar: 15 s'de {fnum(r15, 1)} GΩ, 60 s'de {fnum(r60, 1)} GΩ, 10 dk'da {fnum(r600, 1)} GΩ. Soğurma oranı (DAR) = R60 / R15 = {fnum(dar, 2)}; kutuplanma indisi (PI) = R10dk / R1dk = {fnum(pi, 2)}.",
              "Kuru ve temiz yalıtımda direnç zamanla belirgin biçimde artar (PI ≥ 2). Nemli ya da kirli yalıtımda kaçak akım baskındır: direnç düşüktür ve zamanla artmaz (PI ≈ 1).",
              "Bağlantı dayanım deneyindeki gibidir: ölçülen faz megger'in gerilim ucuna, diğer fazlar ve gövde toprak ucuna bağlanır. Yüzey kaçağı ölçümü bozuyorsa izolatörün yüzeyine sarılan bir tel koruma (guard) ucuna bağlanır."]
        kt = [C("Yalıtım direnci (1. dakika)", f"{fnum(r60, 1)} GΩ", f"en az ≈ (Ur + 1) MΩ = {fnum(r_min * 1000, 0)} MΩ; yeni hücrede GΩ düzeyi beklenir", r60 >= r_min, "IEEE 43 kuralının genel kullanımı; üretici değerleri", "ikincil"),
              C("Kutuplanma indisi (PI)", fnum(pi, 2), "≥ 2 iyi · 1–2 şüpheli · < 1 kötü", pi >= 2.0 - 1e-9, "IEEE 43 (yorum ölçütleri)", "ikincil"),
              C("Soğurma oranı (DAR)", fnum(dar, 2), "≥ 1,25 kabul edilebilir · ≥ 1,6 iyi", dar >= 1.25 - 1e-9, "IEEE 43 (yorum ölçütleri)", "ikincil"),
              C("Ölçüm gerilimi", f"{fnum(num(p, 'u_megger', 5000), 0)} V d.a.", "OG devresi için 2500 – 5000 V d.a.", True, "TEDAŞ-MLZ/99-032.E (trafolarda: AG–tank 2500 V, YG–tank ve YG–AG 5000 V)", "resmi")]
        ds = ["Yalıtım direnci sıcaklığa çok duyarlıdır (yaklaşık her 10 °C'de yarıya iner); değerler 20 °C'ye indirgenerek karşılaştırılır. PI ve DAR oran oldukları için sıcaklıktan az etkilenir.",
              "Tek bir değer az şey söyler; önemli olan eğilimdir: bir önceki ölçüme göre düşüş, sınır aşılmadan önce nem ya da kirlenmeyi haber verir.",
              "Megger ölçümü dayanım deneyinden önce yapılır: nemli bir hücreye 70 kV uygulamak yalıtımı kalıcı biçimde bozar.",
              "Ölçümden sonra faz toprağa boşaltılır: uzun kablo ya da büyük kapasite megger gerilimini dakikalarca tutar."]
        sema = _sema(ur, bag, faz, f"{fnum(r60, 1)} GΩ · PI {fnum(pi, 2)}", f"Megger {fnum(num(p, 'u_megger', 5000), 0)} V", pi >= 2 and r60 >= r_min)
        graf = [{"baslik": "Yalıtım direncinin zamanla değişimi", "x_ad": "zaman (s)", "y_ad": "direnç (GΩ)", "logx": True, "zaman": True,
                 "seriler": [{"ad": "ölçülen", "renk": "#1a4d8f", "pts": [[15, r15], [30, r15 + (r60 - r15) * 0.55], [60, r60], [180, r60 + (r600 - r60) * 0.5], [600, r600]]},
                             {"ad": "nemli yalıtım (örnek: artmaz)", "renk": "#dc2626", "kesik": True, "pts": [[15, r15 * 0.5], [60, r15 * 0.52], [600, r15 * 0.53]]}], "ymin": 0}]
        oz = [K("R (60 s)", f"{fnum(r60, 1)} GΩ", "ok" if r60 >= r_min else "bad", f"{fnum(num(p, 'u_megger', 5000), 0)} V d.a."), K("Kutuplanma indisi PI", fnum(pi, 2), "ok" if pi >= 2 else "warn" if pi >= 1 else "bad", "R10dk / R1dk"),
              K("Soğurma oranı DAR", fnum(dar, 2), "ok" if dar >= 1.25 else "bad", "R60 / R15"), K("Yorum", "kuru ve temiz" if pi >= 2 else "nem / kirlenme şüphesi", "ok" if pi >= 2 else "bad", "")]
    elif deney == "direnc":
        r, rt, i = num(p, "r_olc", 85), num(p, "r_tip", 80), num(p, "i_dc", 100)
        an = [f"Ana devrenin (baralar, kesici / ayırıcı kontakları, bağlantılar) direnci doğru akımla ölçülür: {fnum(i, 0)} A geçirilir, giriş ve çıkış uçları arasındaki gerilim düşümünden direnç bulunur: {fnum(r, 0)} µΩ → {fnum(r * i / 1000, 1)} mV.",
              f"Ölçülen değer, aynı tip hücrenin ısınma (tip) deneyinden önce ölçülen değeriyle karşılaştırılır: {fnum(rt, 0)} µΩ. Rutin deneyde bunun 1,2 katını geçmemelidir.",
              "Direnç yüksekse bir bağlantı gevşektir ya da bir kontak tam oturmamıştır: anma akımında o nokta ısınır. 630 A'de 100 µΩ fazlalık 40 W ısı demektir."]
        kt = [C("Ana devre direnci", f"{fnum(r, 0)} µΩ", f"≤ 1,2 × tip deneyi değeri = {fnum(1.2 * rt, 0)} µΩ", r <= 1.2 * rt + 1e-9, "TS EN 62271-200 m.7.3; TS EN 62271-1", D),
              C("Ölçme akımı", f"{fnum(i, 0)} A d.a.", "50 A ile anma akımı arasında (küçük akımda kontak filmi yanıltır)", i >= 50, "TS EN 62271-1 (ana devre direncinin ölçülmesi)", D)]
        ds = ["Dört uçlu (Kelvin) ölçüm yapılır: akım ve gerilim uçları ayrıdır, ölçü kablolarının direnci sonuca girmez.",
              "Üç fazın değerleri birbirine yakın olmalıdır; birinin belirgin yüksek çıkması o fazdaki bir bağlantıyı işaret eder.",
              "Saha montajından sonra bara ek yerleri tork anahtarıyla sıkılır ve bu ölçüm tekrarlanır; termal kamerayla yapılan ilk yük denetimi bunu tamamlar."]
        c = Cizim(900, 260)
        c.hat("M80,120 H820", "L1", hot=True, w=5).kutu(380, 96, 140, 48, "kesici / ayırıcı", "kontaklar", "normal").cihaz(380, 180, f"{fnum(r, 0)} µΩ", "mikro-ohmmetre", r <= 1.2 * rt, 140)
        c.hat("M120,120 V205 H380", "ariza").hat("M780,120 V205 H520", "ariza").yazi(100, 100, f"{fnum(i, 0)} A d.a.", "ariza", 12, True).hat("M200,120 V230 H400", "mavi", kesik=True).hat("M700,120 V230 H500", "mavi", kesik=True)
        c.yazi(450, 250, "kırmızı: akım uçları · mavi: gerilim uçları (dört uçlu ölçüm)", "#475569", 11, False, "middle")
        sema = c
        oz = [K("Ölçülen direnç", f"{fnum(r, 0)} µΩ", "ok" if r <= 1.2 * rt else "bad", f"sınır {fnum(1.2 * rt, 0)} µΩ"), K("Gerilim düşümü", f"{fnum(r * i / 1000, 1)} mV", "info", f"{fnum(i, 0)} A'de"), K("630 A'de kayıp", f"{fnum(r * 1e-6 * 630 ** 2, 0)} W", "info", "faz başına")]
    else:
        u = num(p, "u_yard", 2); sure = num(p, "sure_s", 60); atl = bool(p.get("atlama"))
        an = ["Yardımcı ve kontrol devreleri (kumanda, sinyal, ısıtıcı, motor devreleri) gövdeye karşı 2 kV şebeke frekanslı gerilimle 1 dakika sınanır. Devrelerin bütün uçları birbirine bağlanır, gerilim bunlarla topraklı gövde arasına uygulanır.",
              "Elektronik cihazlar (röleler, ölçü cihazları, güç kaynakları) kendi standartlarına göre daha düşük gerilimle sınanmışsa bu deneyde ayrılır ya da uçları köprülenir.",
              "Deneyden önce şemaya göre kablo bağlantıları ve fonksiyonlar (kilitlemeler, açma–kapama, sinyaller) denetlenir."]
        kt = [C("Deney gerilimi", f"{fnum(u, 1)} kV", "2 kV, 1 dakika", abs(u - 2.0) <= 0.1 and abs(sure - 60) < 1, K95), C("Deney sonucu", "atlama oldu" if atl else "yıkıcı boşalma yok", "yıkıcı boşalma olmamalı", not atl, "TS EN 62271-200 m.7.2", D)]
        ds = ["Akım trafosu sekonderleri bu deneyde kısa devre edilmiş ve gövdeden ayrılmış olmalıdır; deneyden sonra sekonder topraklaması yeniden yapılır.",
              "Yardımcı devre deneyi, ana devre deneylerinden ayrıdır: 70 kV'luk deney trafosuyla değil, küçük bir deney cihazıyla yapılır."]
        c = Cizim(900, 220, zemin=190)
        c.dikdortgen(300, 40, 420, 120, "#334155", "rgba(148,163,184,.08)", 2.2).yazi(510, 32, "HÜCRE — AG kumanda bölmesi", "#334155", 11.5, True, "middle").kutu(40, 70, 150, 56, "Deney cihazı", f"{fnum(u, 1)} kV · {fnum(sure, 0)} s", "acti" if not atl else "gecersiz")
        c.hat("M190,98 H360", "ariza", hot=True).kutu(360, 76, 300, 44, "yardımcı devrelerin bütün uçları köprülü", "", "normal").hat("M720,150 H760 V190", "PE", kesik=True).toprak(760, 190)
        sema = c
        oz = [K("Deney gerilimi", f"{fnum(u, 1)} kV", "ok" if abs(u - 2.0) <= 0.1 else "bad", "gereken 2 kV"), K("Süre", f"{fnum(sure, 0)} s", "ok" if abs(sure - 60) < 1 else "bad", "60 s"), K("Sonuç", "kaldı" if atl else "geçti", "bad" if atl else "ok", "")]
    rutin = {"baslik": "Hücrelerde rutin deneyler", "cols": ["Deney", "Standart maddesi"], "rows": [
        ["Ana devrede dielektrik deneyler (şebeke frekanslı dayanım)", "TS EN 62271-200 m.7.1"], ["Yardımcı ve kontrol devrelerindeki deneyler (şema denetimi, fonksiyon deneyleri, elektrik çarpmasına karşı korumanın doğrulanması, 2 kV dayanım)", "TS EN 62271-200 m.7.2"],
        ["Ana devre direncinin ölçülmesi", "TS EN 62271-200 m.7.3"], ["Sızdırmazlık deneyi (bileşenler için)", "TS EN 62271-200 m.7.4"], ["Kısmi boşalmanın ölçülmesi (bileşenler için)", "TS EN 62271-200 m.7.101"],
        ["Mekanik çalışma deneyleri", "TS EN 62271-200 m.7.102"], ["Yardımcı elektrik cihazlarının deneyleri", "TS EN 62271-200 m.7.104"], ["Tasarım ve gözle muayene", "TS EN 62271-200 m.7.5"]],
        "not": "TEDAŞ-MLZ/95-007.E m.4.2 — durum: resmi. Kısmi boşalma ve sızdırmazlık deneyleri anlaşmayla fonksiyonel birim montajından önce de yapılabilir."}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sema.sahne(), "grafikler": graf, "tablolar": [duzey, rutin]}
