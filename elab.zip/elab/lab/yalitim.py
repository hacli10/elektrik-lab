"""Laboratuvar konusu — yalıtım direnci: doğru gerilimde (megger) ve alternatif gerilimde yalıtımdan geçen akımın bileşenleri;
hava, katı ve gaz (SF6) yalıtımlı OG hücrede neyin ölçüldüğü.

Doğru gerilim uygulanınca yalıtımdan üç akım birlikte geçer:
  kapasitif şarj akımı   iC(t) = (U/Ri)·e^(−t/(Ri·C))       — cihazın iç direnci Ri üzerinden kapasitenin dolması; saniyeler içinde biter
  soğurma (kutuplanma)   iA(t) = U·C·D·t^(−n)                — katı yalıtımın moleküllerinin yönlenmesi; dakikalarca sürer
  iletim / kaçak akımı   iL    = U·(1/Rhacim + 1/Ryüzey)     — zamanla değişmez; yalıtım direncini belirleyen budur
Megger'in gösterdiği R(t) = U / (iC + iA + iL). R15, R60, R600 okumaları ve oranları (DAR, PI) bu üç akımın payını ayırmak içindir.
Alternatif gerilimde kapasitif akım hiç sönmez: IC = ω·C·U, kayıp akımı IR = IC·tan δ. Bu yüzden a.a. deneyi kapasiteyi ve kaybı,
d.a. ölçümü iletkenliği (nem, kir, çatlak) gösterir.

Kapasiteler geometri bağıntılarından hesaplanır (düzlem üstünde silindir, eş eksenli silindir); direnç ve soğurma katsayıları
öğretim amaçlı mertebe değerleridir (tahmini). Dayanak: Elektrik Tesisleri Kabul Yön. m.28-D; TEDAŞ-MLZ/95-007.E, 2006-002.D; IEEE 43 (yorum)."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, OMEGA, ctl, fazor, fnum, num, opt

ID = "yalitim"
BASLIK = "Yalıtım direnci — DC ve AC bileşenler"
IKON = "🧲"
GIRIS = ("Megger tek bir sayı gösterir ama o sayı üç ayrı akımın toplamından çıkar ve zamanla değişir. Hava, katı ve SF6 gazı yalıtımlı hücrede "
         "tam olarak neyin ölçüldüğünü, hangi bileşenin sonucu belirlediğini ve alternatif gerilimde tablonun nasıl değiştiğini görün.")

EPS0 = 8.854e-12
# yalıtım tipi: ad, bağıl dielektrik sabiti, faz–toprak kapasitesi (pF, hücre başına), hacim direnci (GΩ, 20 °C), soğurma katsayısı D, tan δ (%), yüzey direnci (GΩ) kuru / nemli / kirli+nemli
TIP = {
    "hava": {"ad": "Hava yalıtımlı (metal mahfazalı, mesnet ve geçit izolatörlü)", "er": 1.0, "rv": 120.0, "d": 0.02, "td": 0.5, "ry": {"kuru": 300.0, "nemli": 6.0, "kirli": 0.25}},
    "kati": {"ad": "Katı yalıtımlı (epoksi / kalıplanmış bara, ekranlı)", "er": 4.0, "rv": 3000.0, "d": 0.15, "td": 0.8, "ry": {"kuru": 5000.0, "nemli": 300.0, "kirli": 20.0}},
    "gaz": {"ad": "SF6 gazı yalıtımlı (mühürlü tank)", "er": 1.0, "rv": 500.0, "d": 0.03, "td": 0.1, "ry": {"kuru": 3000.0, "nemli": 800.0, "kirli": 150.0}},
}
NEM = {"kuru": "Kuru ve temiz", "nemli": "Nemli (yoğuşma)", "kirli": "Kirli ve nemli (toz + yoğuşma)"}
KUSUR = {"yok": "yok", "nem": "Katı yalıtım nem almış (rutubetli epoksi / reçine)", "catlak": "Bir mesnet / geçit izolatöründe çatlak"}
L_BARA = 1.5          # bir hücredeki bara + bağlantı boyu (m), faz başına
ISC = 3e-3            # megger'in kısa devre akımı (A) — tipik 5 kV cihaz
N_SOG = 0.8           # soğurma akımı üssü
P_ANMA, P_MIN = 0.4, 0.3      # SF6 beyan doldurma ve en küçük çalışma basıncı (bar, bağıl) — tipik; gerçek değer imalatçı etiketinden

KONTROLLER = [
    ctl("yalitim", "Hücrenin yalıtımı", "sec", "hava", secenek=opt(*[(k, v["ad"]) for k, v in TIP.items()])),
    ctl("ur_kv", "Anma gerilimi Ur", "sec", 36.0, secenek=opt((12.0, "12 kV"), (17.5, "17,5 kV"), (36.0, "36 kV"))),
    ctl("n_hucre", "Barası birleşik hücre sayısı (birlikte ölçülen)", "sayi", 1, min=1, max=12, adim=1),
    ctl("baglanti", "Megger bağlantısı", "sec", "faz_toprak", secenek=opt(("faz_toprak", "Bir faz ölçülüyor; diğer iki faz ve gövde toprak ucunda"), ("uc_faz", "Üç faz köprülü; gövde toprak ucunda"))),
    ctl("u_dc", "Megger gerilimi", "sec", 5000, secenek=opt((1000, "1000 V"), (2500, "2500 V"), (5000, "5000 V"), (10000, "10 000 V"))),
    ctl("nem", "Yüzey durumu", "sec", "kuru", secenek=opt(*NEM.items())),
    ctl("guard", "Koruma (guard) ucu izolatör yüzeyine bağlı", "onay", False, yardim="yüzeyden akan akım ölçü devresinin dışından döner"),
    ctl("sicaklik", "Yalıtım sıcaklığı", "sayi", 20, min=0, max=60, adim=1, birim="°C"),
    ctl("kusur", "Yalıtım kusuru", "sec", "yok", secenek=opt(*KUSUR.items())),
    ctl("gt", "Gerilim trafosu bağlı bırakılmış (primeri faz–toprak)", "onay", False),
    ctl("parafudr", "Parafudr bağlı bırakılmış", "onay", False),
    ctl("kablo", "OG kablosu bağlı bırakılmış", "onay", False),
    ctl("kablo_m", "Bağlı kablonun uzunluğu", "sayi", 200, min=10, max=3000, adim=10, birim="m", goster={"kablo": [True]}),
    ctl("gaz_bar", "SF6 basıncı (bağıl)", "sayi", 0.4, min=0.0, max=0.6, adim=0.02, birim="bar", goster={"yalitim": ["gaz"]}, yardim=f"beyan doldurma {P_ANMA} bar, en küçük çalışma {P_MIN} bar (tipik)"),
]


def kapasite_pf(tip: str) -> tuple[float, str]:
    """Bir hücrede faz–toprak kapasitesi (pF) ve nasıl hesaplandığı."""
    if tip == "hava":       # topraklı düzlem üstünde silindir: C' = 2πε0 / ln(2h/r) ; h = 0,30 m, r = 0,02 m ; + 4 izolatör × 8 pF
        c1 = 2 * math.pi * EPS0 / math.log(2 * 0.30 / 0.02) * 1e12
        return c1 * L_BARA + 4 * 8.0, f"bara–gövde: C′ = 2πε0 / ln(2h/r) = {fnum(c1, 1)} pF/m (h = 0,30 m, r = 20 mm) × {fnum(L_BARA, 1)} m + 4 izolatör × 8 pF"
    if tip == "kati":       # eş eksenli: C' = 2πε0εr / ln(D/d) ; εr = 4, D/d = 2
        c1 = 2 * math.pi * EPS0 * 4.0 / math.log(2.0) * 1e12
        return c1 * L_BARA, f"ekranlı katı yalıtım, eş eksenli: C′ = 2πε0εr / ln(D/d) = {fnum(c1, 0)} pF/m (εr = 4, D/d = 2) × {fnum(L_BARA, 1)} m"
    c1 = 2 * math.pi * EPS0 / math.log(3.0) * 1e12          # gaz: eş eksenli, εr = 1, D/d = 3 ; + 3 geçit izolatörü × 10 pF
    return c1 * L_BARA + 3 * 10.0, f"tank içinde eş eksenli: C′ = 2πε0 / ln(D/d) = {fnum(c1, 1)} pF/m (εr ≈ 1, D/d = 3) × {fnum(L_BARA, 1)} m + 3 geçit izolatörü × 10 pF"


def devre(p: dict) -> dict:
    """Ölçülen devrenin eşdeğeri: C (F), hacim iletkenliği Gv (S), yüzey iletkenliği Gy (S), soğurma katsayısı D, tan δ, bileşen listesi."""
    tip = p.get("yalitim") if p.get("yalitim") in TIP else "hava"
    T = TIP[tip]
    n = max(1, int(num(p, "n_hucre", 1)))
    nem = p.get("nem") if p.get("nem") in NEM else "kuru"
    kus = p.get("kusur") if p.get("kusur") in KUSUR else "yok"
    kt = 0.5 ** ((num(p, "sicaklik", 20) - 20) / 10)          # hacim direnci her 10 °C'de yarıya iner
    c_fe, c_not = kapasite_pf(tip)
    uc = p.get("baglanti") == "uc_faz"
    carp = 3.0 if uc else 1.6                                 # faz–toprak + (tek fazda) komşu iki faza olan yollar (her biri ≈ 0,3 × faz–toprak)
    rv = T["rv"] * kt * (0.001 if kus == "nem" else 1.0)
    d_sog = T["d"] * (0.25 if kus == "nem" else 1.0)          # nemli yalıtımda iletim baskın olur, soğurmanın payı küçülür
    parca = [{"ad": f"Hücre yalıtımı ({'üç faz' if uc else 'bir faz'}, {n} hücre)", "c": c_fe * carp * n, "gv": carp * n / rv, "gy": carp * n / T["ry"][nem], "d": d_sog, "td": T["td"] * (4 if kus == "nem" else 1)}]
    if kus == "catlak":
        parca.append({"ad": "Çatlak izolatör", "c": 8.0, "gv": 1 / 0.02, "gy": 0.0, "d": 0.0, "td": 20.0})
    if p.get("parafudr"):
        parca.append({"ad": "Parafudr (metal oksit)", "c": 40.0 * (3 if uc else 1), "gv": (3 if uc else 1) / 8.0, "gy": 0.0, "d": 0.01, "td": 3.0})
    if p.get("kablo"):
        L = num(p, "kablo_m", 200) / 1000
        ckm = 0.15e6 if num(p, "ur_kv", 36) >= 30 else 0.25e6      # pF/km (XLPE, 95 mm²)
        parca.append({"ad": f"OG kablosu (XLPE, {fnum(L * 1000, 0)} m)", "c": ckm * L * (3 if uc else 1), "gv": (3 if uc else 1) * L / (50.0 * kt), "gy": 0.0, "d": 0.10, "td": 0.1})
    if p.get("gt"):
        parca.append({"ad": "Gerilim trafosu primer sargısı", "c": 30.0, "gv": 1 / 2.0e-5, "gy": 0.0, "d": 0.0, "td": 0.0, "dc": True})       # sargının d.a. direnci ≈ 20 kΩ: faz doğrudan toprağa bağlı
    c = sum(x["c"] for x in parca) * 1e-12
    gv = sum(x["gv"] for x in parca) * 1e-9
    gy = sum(x["gy"] for x in parca) * 1e-9
    d_es = sum(x["d"] * x["c"] for x in parca) / sum(x["c"] for x in parca)
    td = sum(x["td"] * x["c"] for x in parca) / sum(x["c"] for x in parca) / 100
    gv_ac = sum(x["gv"] for x in parca if not x.get("dc")) * 1e-9          # gerilim trafosu a.a.'da büyük bir endüktanstır; d.a. direnci a.a. kaybına katılmaz
    return {"tip": tip, "c": c, "gv": gv, "gv_ac": gv_ac, "gy": gy, "d": d_es, "td": td, "parca": parca, "c_not": c_not, "c_fe": c_fe}


def akimlar(u: float, c: float, g: float, d: float, t: float) -> tuple[float, float, float]:
    """t anında (s) şarj, soğurma ve iletim akımları (A)."""
    ri = u / ISC
    return u / ri * math.exp(-t / (ri * c)), u * c * d * max(t, 0.05) ** (-N_SOG), u * g


def r_olc(u: float, c: float, g: float, d: float, t: float) -> float:
    return u / sum(akimlar(u, c, g, d, t))


def run(p: dict) -> dict:
    E = devre(p)
    tip = E["tip"]; T = TIP[tip]
    ur = num(p, "ur_kv", 36.0); u = num(p, "u_dc", 5000)
    guard = bool(p.get("guard"))
    g = E["gv"] + (0.0 if guard else E["gy"])
    r15, r30, r60, r600 = (r_olc(u, E["c"], g, E["d"], t) for t in (15, 30, 60, 600))
    dar = r60 / r30; pi = r600 / r60
    ic60, ia60, il = akimlar(u, E["c"], g, E["d"], 60)
    r_son = 1 / g
    kt, an, ds = [], [], []
    G = lambda x: fnum(x / 1e9, 2 if x < 1e10 else 1) + " GΩ" if x >= 1e8 else fnum(x / 1e6, 2 if x < 1e7 else 1) + " MΩ" if x >= 1e5 else fnum(x / 1e3, 1) + " kΩ"  # noqa: E731
    uA = lambda i: (fnum(i * 1e3, 2) + " mA") if i >= 1e-3 else (fnum(i * 1e6, 3 if i < 1e-7 else 2 if i < 1e-5 else 1) + " µA")  # noqa: E731
    an.append(f"Ölçülen devre: {('üç faz birlikte' if p.get('baglanti') == 'uc_faz' else 'bir faz')} ile toprak ucuna bağlı her şey arasındaki yalıtım. Kapasitesi {fnum(E['c'] * 1e12, 0)} pF ({E['c_not']}).")
    an.append(f"Megger {fnum(u, 0)} V doğru gerilim uygular. İlk anda kapasite dolar (şarj akımı, {fnum(u / ISC * E['c'] * 1000, 2)} ms'lik zaman sabitiyle söner). Sonra iki akım kalır: zamanla azalan soğurma akımı "
              f"ve sabit iletim akımı. 60. saniyede: soğurma {uA(ia60)}, iletim {uA(il)} → gösterge {G(r60)}. Soğurma tümüyle bittiğinde okuma {G(r_son)} olurdu.")
    if tip == "hava":
        an.append("Hava yalıtımlı hücrede fazlar arasında ve toprağa karşı asıl yalıtkan havadır; hava soğurma göstermez ve iletkenliği yok sayılır. Megger'in ölçtüğü, baraları taşıyan mesnet ve geçit izolatörlerinin hacim direnci ile "
                  "bunların yüzeyinden akan kaçaktır. Sonuç bu yüzden hava nemine ve toza çok bağlıdır; okuma birkaç saniyede oturur, 1 ve 10 dakika değerleri hemen hemen aynıdır.")
    elif tip == "kati":
        an.append("Katı yalıtımlı hücrede bara epoksi ya da kalıplanmış yalıtkanla sarılı, dışı topraklı ekranla kaplıdır. Kapasite büyüktür (εr ≈ 4, ince yalıtım), yalıtkan belirgin soğurma gösterir: okuma dakikalarca yükselir. "
                  "Yüzey kaçağı yalnız uç bağlantılarda vardır; sonucu yalıtkanın hacim direnci belirler. Kutuplanma indisi bu yapıda anlamlıdır.")
    else:
        an.append("SF6 gazlı hücrede gerilimli bölümler mühürlü tankın içindedir. Gazın kendisi megger'de sonsuz direnç gibi görünür ve soğurma göstermez; ölçülen, geçit izolatörleri ile tank içi epoksi mesnetlerin direncidir. "
                  "Tankın içi kuru ve kapalı olduğundan hava nemi sonucu az etkiler. Önemli: megger gaz kaçağını göstermez — gaz basıncı düşse de okuma GΩ düzeyinde kalır; düşen, a.a. dayanım gerilimidir.")
    if p.get("gt"):
        an.append("Gerilim trafosunun primer sargısı faz ile toprak arasına bağlıdır. Doğru gerilimde sargı yalnız bakır direncidir (≈ 20 kΩ): megger yalıtımı değil sargıyı ölçer ve “yalıtım sıfır” sonucu verir. Ölçümden önce gerilim trafosu ayrılır.")
    if p.get("kablo"):
        an.append("Bağlı kablonun kapasitesi hücreninkinden yüzlerce kat büyüktür: şarj uzun sürer, soğurma akımı büyür ve okuma kablonun yalıtımını gösterir. Hücreyi değerlendirmek için kablo başlıkları ayrılır; deneyden sonra kablo uzun süre boşaltılır.")
    if E["gy"] > E["gv"] and not guard:
        an.append(f"Bu durumda akımın çoğu yalıtkanın içinden değil yüzeyinden geçiyor (yüzey {G(1 / E['gy'])}, hacim {G(1 / E['gv'])}). Koruma (guard) ucu izolatör yüzeyine sarılan bir tele bağlanırsa yüzey akımı ölçünün dışında kalır ve hacim direnci tek başına okunur.")
    # alternatif gerilim
    u_ac = ur * 1000 / math.sqrt(3)
    i_c = OMEGA * E["c"] * u_ac
    g_ac = OMEGA * E["c"] * E["td"] + E["gv_ac"] + E["gy"]
    i_r = g_ac * u_ac
    td_top = i_r / i_c
    ud = {12.0: 28, 17.5: 38, 36.0: 70}.get(ur, 70) * 1000.0
    s_deney = OMEGA * E["c"] * ud ** 2
    an.append(f"Aynı yalıtıma işletme gerilimi (a.a., {fnum(u_ac / 1000, 1)} kV) uygulandığında kapasitif akım sönmez: IC = ω·C·U = {uA(i_c)}; kayıp akımı IR = {uA(i_r)}; tan δ = IR / IC = %{fnum(td_top * 100, 2)}. "
              f"Doğru gerilimde ölçülen iletim akımı {uA(il)} idi: a.a.'da akımı kapasite, d.a.'da iletkenlik belirler.")
    an.append(f"Dayanım deneyinde ({fnum(ud / 1000, 0)} kV, 50 Hz) deney trafosunun vermesi gereken güç S = ω·C·U² = {fnum(s_deney / 1000, 2)} kVA." + (" Kablo bağlı kalırsa bu güç deney trafosunun çok üstüne çıkar: kablolar ayrı, düşük frekanslı (0,1 Hz) ya da rezonans cihazıyla denenir." if p.get("kablo") else ""))
    # kontroller
    alt_sinir = (ur + 1) * 1e6
    kt.append(C("Yalıtım direnci (60. saniye)", G(r60), f"yeni ve kuru OG donanımında ≥ 1 GΩ beklenir; kabul edilebilir alt değer ≈ (Ur + 1) MΩ = {fnum(ur + 1, 0)} MΩ", True if r60 >= 1e9 else (None if r60 >= alt_sinir else False),
                "Elektrik Tesisleri Kabul Yön. m.28-D (yalıtım direnci deneyi istenir); sayısal değerler: uygulama ve IEEE 43 yaklaşımı", "ikincil"))
    kt.append(C("Ölçüm gerilimi", f"{fnum(u, 0)} V d.a.", "OG ana devresi için 2500 – 5000 V d.a. (yardımcı devreler 500 V)", 2500 <= u <= 5000, "TEDAŞ-MLZ/99-032.E m.3.2 (YG–tank 5000 V, AG–tank 2500 V); TEDAŞ-MLZ/96-030 (yardımcı devre 500 V)", "resmi"))
    kt.append(C("Ölçüme karışmaması gereken donanım", ", ".join(x for x, v in (("gerilim trafosu bağlı", p.get("gt")), ("parafudr bağlı", p.get("parafudr")), ("kablo bağlı", p.get("kablo"))) if v) or "hepsi ayrılmış",
                "gerilim trafoları, parafudrlar ve kablolar ayrılır; akım trafosu sekonderleri kısa devre edilip topraklanır", not (p.get("gt") or p.get("parafudr") or p.get("kablo")), "TS EN 62271-200 (dielektrik deneylerde donanımın ayrılması); imalatçı devreye alma kuralları", "dogrulanacak"))
    if tip == "kati" or p.get("kablo"):
        anlamli = r60 < 5e9
        kt.append(C("Kutuplanma indisi PI = R600 / R60", fnum(pi, 2), "≥ 2 iyi · 1 – 2 şüpheli · < 1 kötü ; R60 > 5 GΩ ise indis güvenilir değildir", (True if pi >= 2 else (None if pi >= 1.25 else False)) if anlamli else None, "IEEE 43 (yorum ölçütü)", "ikincil"))
    else:
        kt.append(C("Kutuplanma indisi PI = R600 / R60", fnum(pi, 2), "hava ve gaz yalıtımında soğurma yoktur: PI ≈ 1 olağandır, ölçüt değildir; mutlak değere ve önceki ölçüme bakılır", None, "IEEE 43 (soğurma göstermeyen yalıtımda indis kullanılmaz)", "ikincil"))
    if p.get("nem") in ("nemli", "kirli") and E["gy"] > 0.5 * E["gv"]:
        kt.append(C("Yüzey kaçağının ölçüden ayrılması", "koruma (guard) ucu bağlı" if guard else "koruma ucu kullanılmıyor", "yüzey akımı hacim akımıyla aynı mertebedeyse koruma ucu kullanılır ya da yüzey kurutulup temizlenir", guard, "Yalıtım direnci ölçme cihazı kullanım kuralları (üç uçlu ölçüm)", "ikincil"))
    if tip == "gaz":
        pb = num(p, "gaz_bar", P_ANMA)
        oran = ((pb + 1.0) / (P_ANMA + 1.0)) ** 0.9
        kt.append(C("SF6 basıncı", f"{fnum(pb, 2)} bar (bağıl) → a.a. dayanımı anma değerinin ≈ %{fnum(oran * 100, 0)}'i", f"≥ en küçük çalışma basıncı ({fnum(P_MIN, 2)} bar); gösterge yeşil bölgede", pb >= P_MIN - 1e-9,
                    "TEDAŞ-MLZ/2006-002.D (gaz basıncı göstergesi, en küçük çalışma basıncı; mühürlü basınç sistemi); Elektrik Tesisleri Kabul Yön. m.28-D-6b (GIS: basınç, sızdırmazlık, nem)", "resmi"))
        if pb < P_MIN:
            an.append("Gaz basıncı en küçük çalışma basıncının altında. Megger yine yüksek değer okur; ama gazın delinme dayanımı basınçla orantılıdır: hücre dayanım deneyini geçemez ve yük altında anahtarlama yapılamaz.")
    ds = ["Megger iletkenliği görür: nem, kir, karbonlaşmış yüzey, çatlak. Göremediği: kuru bir boşluk ya da keskin kenar (bunlar kısmi boşalma ölçümüyle bulunur) ve gazlı hücrede düşük basınç.",
          "Tek bir okuma az şey söyler. Sıcaklık (her 10 °C'de direnç yarıya iner), nem ve ölçüm gerilimi yazılır; değer önceki ölçümle ve diğer iki fazla karşılaştırılır. Fazlar arasında birkaç kattan büyük fark aranır.",
          "Paralel bağlı her parça toplam direnci düşürür: sekiz hücrelik bir sıranın barası, tek hücrenin sekizde biri kadar direnç gösterir. Düşük okuma bulunduğunda devre bölünerek kusurlu parça aranır.",
          "Doğru gerilimde gerilim dağılımını dirençler, alternatif gerilimde kapasiteler belirler. Katı yalıtım içindeki hava boşluğu a.a.'da εr katı kadar fazla alan şiddeti görür ve kısmi boşalma başlar; d.a.'da aynı boşluk fark edilmez.",
          "Ölçümden sonra devre en az ölçüm süresinin dört katı kadar boşaltılır: soğurulan yük geri döner ve uçlarda yeniden gerilim oluşturur."]
    # şema
    c = Cizim(900, 330, zemin=292)
    c.cihaz(30, 60, G(r60), f"megger {fnum(u, 0)} V", r60 >= alt_sinir, 150).yazi(40, 130, "L (hat)", "ariza", 10.5, True).yazi(40, 148, "E (toprak)", "PE", 10.5, True).yazi(40, 166, "G (koruma)", "mavi", 10.5, True)
    c.dikdortgen(330, 40, 400, 212, "#334155", "rgba(148,163,184,.08)", 2.2, False, 6).yazi(530, 32, f"HÜCRE — {T['ad'].split(' (')[0]} · Ur {fnum(ur, 1)} kV", "#334155", 11.5, True, "middle")
    if tip == "gaz":
        c.dikdortgen(370, 62, 320, 120, "mavi", "rgba(29,78,216,.07)", 1.6, True, 10).yazi(378, 56, "SF6 tankı", "mavi", 10.5, True)
    uc = p.get("baglanti") == "uc_faz"
    for k, x in enumerate((420, 530, 640)):
        ger = uc or k == 0
        col = "ariza" if ger else "PE"
        c.hat(f"M{x},84 V168", col, w=6 if tip != "kati" else 5).yazi(x - 12, 100, f"L{k + 1}", col, 12, True, "end")
        if tip == "kati":
            c.dikdortgen(x - 11, 84, 22, 84, "uyari", "rgba(217,119,6,.18)", 1.4, False, 3)
        # mesnet izolatörü: baradan gövdeye
        c.dikdortgen(x - 7, 176, 14, 62, "#64748b", "#e2e8f0", 1.4, False, 3).hat(f"M{x},168 V176", col, w=2).hat(f"M{x},238 V252", "PE", w=2)
        if ger:
            c.hat(f"M{x - 3},180 V236", "ariza", hot=True, w=1.6, kesik=True)                                        # hacim akımı
            if E["gy"] > 0.2 * E["gv"]:
                c.hat(f"M{x + 9},178 V236" + (f" H{x + 26} V262" if guard else ""), "uyari", hot=True, w=1.6, hot_renk="mavi" if guard else "uyari")
        else:
            c.hat(f"M{x},84 V70 H{x + 30} V252", "PE", kesik=True)
    c.yazi(678, 214, "izolatör", "#475569", 10)
    c.hat("M180,82 H260 V70 H420" + (" H640" if uc else ""), "ariza", hot=True).hat("M180,100 H300 V252", "PE", w=2).hat("M330,252 H730", "PE", w=2.4).hat("M300,252 H330", "PE", w=2).hat("M730,252 H770 V292", "PE", kesik=True).toprak(770, 292)
    if guard:
        c.hat("M180,118 H280 V262 H680", "mavi", kesik=True).yazi(520, 276, "koruma ucu: yüzey akımı ölçünün dışından döner", "mavi", 10.5, True, "middle")
    if p.get("gt"):
        c.hat("M420,120 H470", "ariza", hot=True).bobin(470, 124, 5, False, "ariza").hat("M470,174 V252", "ariza", hot=True).yazi(478, 196, "GT", "ariza", 10.5, True)
    if p.get("kablo"):
        c.hat("M640,168 H700 V230" if uc else "M420,150 H386 V230", "uyari", w=4).yazi(706 if uc else 380, 210, "kablo", "uyari", 10.5, True, "start" if uc else "end")
    if p.get("parafudr"):
        c.dikdortgen(563, 120, 14, 40, "mor", "#ede9fe", 1.4).hat("M570,160 V252", "mor").hat("M570,120 V112 H530" if uc else "M570,120 V104 H420", "mor").yazi(581, 144, "parafudr", "mor", 10)
    c.yazi(760, 96, "60. saniyede", "#334155", 11, True).yazi(760, 114, f"soğurma {uA(ia60)}", "uyari", 10.5).yazi(760, 130, f"iletim {uA(il)}", "ariza", 10.5).yazi(760, 146, f"toplam {uA(ia60 + il + ic60)}", "#334155", 10.5, True)
    c.yazi(450, 318, f"R15 {G(r15)} · R60 {G(r60)} · R600 {G(r600)} · PI {fnum(pi, 2)}", "#334155", 12, True, "middle")
    # grafikler
    ts = [0.2 * 1.25 ** k for k in range(0, 37) if 0.2 * 1.25 ** k <= 620]
    ak = [akimlar(u, E["c"], g, E["d"], t) for t in ts]
    alt = max(1e-12, min(il, ak[-1][1]) * 0.3)
    graf = [{"baslik": "Megger okumasının zamanla değişimi", "x_ad": "zaman (s)", "y_ad": "gösterge (GΩ)", "logx": True, "logy": True, "zaman": True,
             "seriler": [{"ad": "R(t) = U / (iC + iA + iL)", "renk": "#1a4d8f", "pts": [[round(t, 2), r_olc(u, E["c"], g, E["d"], t) / 1e9] for t in ts]}],
             "isaretler": [{"x": 15, "etiket": "15 s"}, {"x": 60, "etiket": "60 s"}, {"x": 600, "etiket": "10 dk"}], "yatay": [{"y": r_son / 1e9, "etiket": "soğurma bittiğinde", "renk": "#64748b"}]},
            {"baslik": "Yalıtımdan geçen akımın bileşenleri (doğru gerilim)", "x_ad": "zaman (s)", "y_ad": "akım (µA)", "logx": True, "logy": True,
             "seriler": [{"ad": "şarj akımı iC", "renk": "#7c3aed", "kesik": True, "pts": [[round(t, 2), max(a[0], alt) * 1e6] for t, a in zip(ts, ak) if a[0] > alt]},
                         {"ad": "soğurma akımı iA", "renk": "#d97706", "pts": [[round(t, 2), max(a[1], alt) * 1e6] for t, a in zip(ts, ak)]},
                         {"ad": "iletim akımı iL", "renk": "#dc2626", "pts": [[round(t, 2), max(a[2], alt) * 1e6] for t, a in zip(ts, ak)]},
                         {"ad": "toplam", "renk": "#111827", "pts": [[round(t, 2), sum(a) * 1e6] for t, a in zip(ts, ak)]}]}]
    fz = {"baslik": f"Alternatif gerilimde ({fnum(u_ac / 1000, 1)} kV) akım", "not": f"δ = {fnum(math.degrees(math.atan(td_top)), 2)}° · tan δ = %{fnum(td_top * 100, 2)} (kayıp akımı çizimde büyütülmüştür)",
          "vektorler": [fazor("U", complex(1, 0), "#334155"), fazor("IC", complex(0, 1), "#1d4ed8"), fazor("IR (kayıp)", complex(max(td_top, 0.02) * 4, 0), "#dc2626", False, complex(0, 1)), fazor("I (toplam)", complex(max(td_top, 0.02) * 4, 1), "#111827", True)]}
    for v, ger in zip(fz["vektorler"], (u_ac / 1000, i_c * 1e6, i_r * 1e6, math.hypot(i_c, i_r) * 1e6)):
        v["mod"] = round(ger, 2)
    fz["vektorler"][2]["aci"] = 0.0; fz["vektorler"][3]["aci"] = round(90 - math.degrees(math.atan(td_top)), 2)
    tab_parca = {"baslik": "Ölçülen devredeki parçalar (paralel)", "cols": ["Parça", "Kapasite", "Hacim direnci", "Yüzey direnci", "Soğurma", "tan δ"],
                 "rows": [[x["ad"], f"{fnum(x['c'], 0)} pF", G(1e9 / x["gv"]) if x["gv"] else "—", G(1e9 / x["gy"]) if x["gy"] else "—", "belirgin" if x["d"] >= 0.08 else "az" if x["d"] > 0 else "yok", f"%{fnum(x['td'], 1)}"] for x in E["parca"]],
                 "not": "Paralel dirençlerde en küçüğü sonucu belirler. Direnç ve soğurma değerleri öğretim amaçlı mertebelerdir (durum: tahmini); kapasiteler geometri bağıntısından hesaplanmıştır."}
    tab_okuma = {"baslik": "Okumalar ve oranlar", "cols": ["Büyüklük", "Değer", "Ne söyler"],
                 "rows": [["R15", G(r15), "şarj bitmiş, soğurma akımı hâlâ büyük"], ["R30", G(r30), ""], ["R60", G(r60), "raporlanan yalıtım direnci"], ["R600", G(r600), "soğurma büyük ölçüde bitmiş"],
                          ["DAR = R60 / R30", fnum(dar, 2), "≥ 1,25 kabul edilebilir · ≥ 1,6 iyi (soğurma gösteren yalıtımda)"], ["PI = R600 / R60", fnum(pi, 2), "≥ 2 iyi · < 1 kötü (soğurma gösteren yalıtımda)"],
                          ["Zaman sabiti R·C", fnum(r_son * E["c"], 1) + " s", "yalıtımın boyutundan bağımsız kalite göstergesi; boşaltma süresi için de ölçü"]]}
    tab_tip = {"baslik": "Hava, katı ve gaz yalıtımında ölçüm nasıl değişir?", "cols": ["", "Hava yalıtımlı", "Katı yalıtımlı", "SF6 gazlı"],
               "rows": [["Fazı topraktan ayıran", "hava aralığı + mesnet / geçit izolatörleri", "epoksi / kalıplanmış yalıtkan, dışı topraklı ekran", "SF6 gazı + tank içi epoksi mesnetler, geçit izolatörleri"],
                        ["Megger'in ölçtüğü", "izolatörlerin hacim ve yüzey direnci", "yalıtkanın hacim direnci", "geçit izolatörleri ve mesnetlerin direnci"],
                        ["Faz–toprak kapasitesi (hücre başına)", f"≈ {fnum(kapasite_pf('hava')[0], 0)} pF", f"≈ {fnum(kapasite_pf('kati')[0], 0)} pF", f"≈ {fnum(kapasite_pf('gaz')[0], 0)} pF"],
                        ["Okumanın oturması", "saniyeler", "dakikalar (soğurma)", "saniyeler"], ["PI / DAR", "≈ 1; ölçüt değil", "anlamlı; ≥ 2 beklenir", "≈ 1; ölçüt değil"],
                        ["Nem ve kirin etkisi", "çok büyük (yüzey kaçağı)", "küçük (yalnız uç bağlantılar)", "çok küçük (kapalı tank)"],
                        ["Delinme dayanımı (mertebe)", "≈ 3 kV/mm (1 bar)", "20 – 30 kV/mm (tasarımda 3 – 5)", "≈ 8,9 kV/mm·bar (havanın ≈ 3 katı; basınçla artar)"],
                        ["Megger'in göremediği", "keskin kenar, yetersiz açıklık", "iç boşluk, ayrılma (delaminasyon)", "gaz kaçağı, tank içi serbest parçacık"],
                        ["Tamamlayıcı ölçüm", "a.a. dayanım, gözle muayene", "kısmi boşalma, tan δ", "gaz basıncı / nemi, sızdırmazlık, a.a. dayanım, kısmi boşalma"]],
               "not": "Kapasiteler bu sayfadaki geometri varsayımlarıyla hesaplanmıştır; delinme dayanımları yaklaşık kaynak değerleridir (durum: tahmini)."}
    tab_dcac = {"baslik": "Doğru ve alternatif gerilimde aynı yalıtım", "cols": ["", "Doğru gerilim (megger)", "Alternatif gerilim (dayanım, tan δ, kısmi boşalma)"],
                "rows": [["Sürekli akım", f"iletim akımı {uA(il)}", f"kapasitif akım {uA(i_c)} ({fnum(u_ac / 1000, 1)} kV'ta)"], ["Gerilim dağılımını belirleyen", "dirençler (iletkenlik)", "kapasiteler (εr)"],
                         ["Ölçülen", "R (GΩ), zamanla değişimi", "C (pF), tan δ (%), boşalma (pC)"], ["Bulduğu kusur", "nem, kir, karbon izi, çatlak", "boşluk, ayrılma, keskin kenar, yaşlanma"],
                         ["Kaynaktan istenen güç", "çok küçük (mA)", f"S = ω·C·U² ({fnum(s_deney / 1000, 2)} kVA, {fnum(ud / 1000, 0)} kV'ta)"]]}
    oz = [K("R60", G(r60), "ok" if r60 >= 1e9 else ("warn" if r60 >= alt_sinir else "bad"), f"{fnum(u, 0)} V d.a."), K("PI (R600 / R60)", fnum(pi, 2), "info", "soğurma payı"),
          K("İletim akımı", uA(il), "info", "yüzey dahil" if not guard and E["gy"] else "hacim"), K("Kapasite", f"{fnum(E['c'] * 1e12, 0)} pF", "info", "ölçülen devre"),
          K("a.a. kapasitif akım", uA(i_c), "info", f"{fnum(u_ac / 1000, 1)} kV, 50 Hz"), K("tan δ (a.a.)", f"%{fnum(td_top * 100, 2)}", "info", "kayıp / kapasitif")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(fazor=fz), "grafikler": graf, "tablolar": [tab_okuma, tab_parca, tab_tip, tab_dcac]}
