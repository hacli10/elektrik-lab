"""Laboratuvar şemaları için ortak çizim tarifi: konu modülü şemayı basit öğelerle (hat, kutu, yazı, sembol) tarif eder,
arayüzdeki tek bir bileşen (ui/src/lab/Cizim.tsx) çizer. Böylece her yeni konu aynı görünüşte, hareketli akım yollu şema alır.

Renk adları: L1 L2 L3 N PE PEN ariza toprak cizgi soluk ok uyari mavi mor — ya da doğrudan #rrggbb."""
from __future__ import annotations


class Cizim:
    def __init__(self, w: int = 900, h: int = 330, zemin: float | None = None):
        self.w, self.h, self.zemin = w, h, zemin
        self.o: list[dict] = []

    def _add(self, t: str, **kw) -> "Cizim":
        self.o.append({"t": t, **{k: v for k, v in kw.items() if v is not None and v is not False}})
        return self

    def hat(self, d: str, renk: str = "cizgi", hot: bool = False, kesik: bool = False, w: float = 2, hot_renk: str | None = None) -> "Cizim":
        """d: SVG yol tarifi (ör. "M40,60 H300 V120"). hot: akım taşıyor (hareketli, kırmızı ya da hot_renk)."""
        return self._add("hat", d=d, renk=renk, hot=hot, kesik=kesik, w=w, hot_renk=hot_renk)

    def kutu(self, x, y, w, h, ad: str, alt: str = "", durum: str = "normal") -> "Cizim":
        """durum: normal | acti (yeşil) | gecersiz (kırmızı) | pasif (soluk) | vurgu (mavi)."""
        return self._add("kutu", x=x, y=y, w=w, h=h, ad=ad, alt=alt or None, durum=durum)

    def yazi(self, x, y, t: str, renk: str = "#334155", boyut: float = 11, kalin: bool = False, anchor: str = "start") -> "Cizim":
        return self._add("yazi", x=x, y=y, s=t, renk=renk, boyut=boyut, kalin=kalin, anchor=anchor)

    def toprak(self, x, y, renk: str = "toprak") -> "Cizim":
        return self._add("toprak", x=x, y=y, renk=renk)

    def direnc(self, x, y, ad: str = "", hot: bool = False, yatay: bool = False, h: float = 30, renk: str = "cizgi") -> "Cizim":
        return self._add("direnc", x=x, y=y, ad=ad or None, hot=hot, yatay=yatay, h=h, renk=renk)

    def kap(self, x, y1, y2, renk: str = "cizgi", yatay: bool = False, ad: str = "") -> "Cizim":
        """Kondansatör: (x, y1)–(x, y2) arasında (yatay ise x=y sabit, y1–y2 x aralığı)."""
        return self._add("kap", x=x, y1=y1, y2=y2, renk=renk, yatay=yatay, ad=ad or None)

    def bobin(self, x, y, n: int = 4, yatay: bool = False, renk: str = "cizgi", ad: str = "") -> "Cizim":
        return self._add("bobin", x=x, y=y, n=n, yatay=yatay, renk=renk, ad=ad or None)

    def simsek(self, x, y, s: float = 1.0) -> "Cizim":
        return self._add("simsek", x=x, y=y, s=s)

    def kisi(self, x, yg, hx, hy, durum: str = "ok", etiket: list | None = None) -> "Cizim":
        return self._add("kisi", x=x, yg=yg, hx=hx, hy=hy, durum=durum, etiket=etiket)

    def daire(self, cx, cy, r, renk: str = "cizgi", dolgu: str | None = None, w: float = 2, kesik: bool = False) -> "Cizim":
        return self._add("daire", cx=cx, cy=cy, r=r, renk=renk, dolgu=dolgu, w=w, kesik=kesik)

    def dikdortgen(self, x, y, w, h, renk: str = "cizgi", dolgu: str | None = None, kw: float = 1.6, kesik: bool = False, r: float = 4) -> "Cizim":
        return self._add("dik", x=x, y=y, w=w, h=h, renk=renk, dolgu=dolgu, kw=kw, kesik=kesik, r=r)

    def cihaz(self, x, y, deger: str, ad: str, ok: bool = True, w: float = 130) -> "Cizim":
        """Ölçü aleti: ekranında `deger` yazan kutu (üst-sol köşe x, y)."""
        return self._add("cihaz", x=x, y=y, deger=deger, ad=ad, ok=1 if ok else 0, w=w)

    def ok(self, x1, y1, x2, y2, renk: str = "ariza", w: float = 2) -> "Cizim":
        return self._add("ok", x1=x1, y1=y1, x2=x2, y2=y2, renk=renk, w=w)

    def sarim(self, x, y, tip: str = "yildiz", renk: str = "#334155", r: float = 22) -> "Cizim":
        """Sargı bağlantı sembolü: yildiz | ucgen (merkez x, y)."""
        return self._add("sarim", x=x, y=y, tip=tip, renk=renk, r=r)

    def toroid(self, x, y, rx: float = 14, ry: float = 34, renk: str = "#1e293b") -> "Cizim":
        return self._add("toroid", x=x, y=y, rx=rx, ry=ry, renk=renk)

    def alan(self, d: str, dolgu: str = "ok", opak: float = 0.15, renk: str | None = None) -> "Cizim":
        """Dolu bölge (SVG yol tarifi d; kapalı olmalı): çalışma bölgesi, yalıtım kesiti gibi yüzeyler."""
        return self._add("alan", d=d, dolgu=dolgu, opak=opak, renk=renk)

    def sahne(self, **ek) -> dict:
        d = {"tip": "cizim", "w": self.w, "h": self.h, "zemin": self.zemin, "ogeler": self.o}
        d.update(ek)
        return d
