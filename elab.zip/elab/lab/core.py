"""Topraklama laboratuvarı — ortak yardımcılar.

Laboratuvar proje hesabından bağımsızdır: proje verisi okumaz, yazmaz. Her konu `run(p) -> dict` döndürür:
  ozet       : [{ad, deger, durum(ok|bad|warn|info), alt}]        — üstteki sonuç kutuları
  kontroller : [{ad, hesap, sinir, ok(True|False|None), kaynak, durum}]
  anlatim    : [str]  — "ne oluyor" adım adım
  dersler    : [str]  — akılda kalacaklar
  sahne      : {tip, ...}  — çizimin verisi
  grafikler  : [{baslik, x_ad, y_ad, logx, logy, seriler:[{ad, renk, kesik, pts}], isaretler:[{x, etiket}], yatay:[{y, etiket}]}]
  tablolar   : [{baslik, cols, rows, not}]
"""
from __future__ import annotations

import json
import math
from functools import lru_cache
from pathlib import Path

RULES_PATH = Path(__file__).resolve().parents[1] / "rules" / "lab_topraklama.json"
RHO_CU = 0.0225      # Ω·mm²/m — bakır, işletme sıcaklığında (≈ 1,25 × 20 °C değeri); çevrim empedansı hesabında kullanılan alışılmış değer
OMEGA = 2 * math.pi * 50


@lru_cache(maxsize=1)
def rules() -> dict:
    return json.loads(RULES_PATH.read_text(encoding="utf-8"))


@lru_cache(maxsize=1)
def ruleset():
    from ..kurallar import load_rules
    return load_rules()


# ---------------- sonuç kalıpları ----------------
def K(ad: str, deger: str, durum: str = "info", alt: str = "") -> dict:
    return {"ad": ad, "deger": deger, "durum": durum, "alt": alt}


def C(ad: str, hesap: str, sinir: str, ok, kaynak: str, durum: str = "resmi") -> dict:
    return {"ad": ad, "hesap": hesap, "sinir": sinir, "ok": ok, "kaynak": kaynak, "durum": durum}


def ctl(key: str, label: str, tip: str, vars, **kw) -> dict:
    """Ayar tanımı. tip: sec | sayi | onay. kw: secenek, min, max, adim, birim, yardim, goster={anahtar: [değerler]}."""
    d = {"key": key, "label": label, "tip": tip, "vars": vars}
    d.update(kw)
    return d


def opt(*pairs) -> list[dict]:
    return [{"id": a, "ad": b} for a, b in pairs]


def fnum(x: float, n: int = 1) -> str:
    """Türkçe ondalık virgülle sayı."""
    if x is None or (isinstance(x, float) and (math.isnan(x) or math.isinf(x))):
        return "∞" if (x is not None and isinstance(x, float) and math.isinf(x)) else "—"
    s = f"{x:,.{n}f}"
    if s.startswith("-") and not any(ch in "123456789" for ch in s):
        s = s[1:]                                    # «−0,0» yazılmaz (eksi sıfır ve sıfıra yuvarlanan küçük eksi sayılar)
    return s.replace(",", "§").replace(".", ",").replace("§", ".")


def fsure(t: float) -> str:
    if t is None or math.isinf(t):
        return "açmaz"
    if t < 1:
        return f"{fnum(t * 1000, 0)} ms"
    if t < 120:
        return f"{fnum(t, 1)} s"
    return f"{fnum(t / 60, 0)} dk"


def num(p: dict, key: str, default: float) -> float:
    try:
        v = p.get(key, default)
        return float(default if v is None or v == "" else v)
    except (TypeError, ValueError):
        return float(default)


# ---------------- ara değer ----------------
def interp(tab: list, x: float, logx: bool = False, logy: bool = False) -> float:
    """Sıralı (x, y) çizelgesinde ara değer; uçların dışında uç değer."""
    pts = sorted((float(a), float(b)) for a, b in tab)
    if x <= pts[0][0]:
        return pts[0][1]
    if x >= pts[-1][0]:
        return pts[-1][1]
    fx = math.log if logx else (lambda v: v)
    fy = math.log if logy else (lambda v: v)
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if x0 <= x <= x1:
            k = (fx(x) - fx(x0)) / (fx(x1) - fx(x0))
            y = fy(y0) + k * (fy(y1) - fy(y0))
            return math.exp(y) if logy else y
    return pts[-1][1]


# ---------------- insan vücudu (Topraklamalar Yön. Ek-C) ----------------
def utp(t_s: float) -> float:
    """İzin verilen dokunma gerilimi UTp (V) — Çizelge-C.3 / Şekil-6; hata süresi tF (s)."""
    return interp(rules()["vucut"]["utp_v"], max(t_s, 1e-3), logx=True, logy=True)


def ib_c1_ma(t_s: float) -> float:
    """Çizelge-C.1'deki izin verilen en yüksek vücut akımı (mA; c2 eğrisi: sol el – iki ayak, fibrilasyon olasılığı < %5)."""
    return interp(rules()["vucut"]["ib_izin_ma"], max(t_s, 1e-3), logx=True, logy=True)


def ib_izin_ma(t_s: float) -> float:
    """İzin verilen vücut akımı (mA), izin verilen dokunma gerilimi eğrisinden: IB = UTp(t) / ZB(UTp). Yönetmeliğin Çizelge-C.1 ve
    Çizelge-C.3 değerleri arasında birkaç puanlık yuvarlama farkı vardır; gerilim ve akım hükmü birbiriyle çelişmesin diye
    kişi değerlendirmesinde de UTp eğrisi (Şekil-6) esas alınır."""
    u = utp(t_s)
    return u / zb_ohm(u) * 1000.0


def zb_ohm(ut_v: float, el_iki_ayak: bool = True) -> float:
    """Toplam vücut empedansı (Ω) — Çizelge-C.2; elden iki ayağa akım yolunda 0,75 düzeltme."""
    v = rules()["vucut"]
    z = interp(v["zb_ohm"], max(ut_v, 1.0))
    return z * (v["zb_el_iki_ayak_katsayi"] if el_iki_ayak else 1.0)


def vucut_akimi(u_kaynak_v: float, ra_ek_ohm: float = 0.0, seri_ohm: float = 0.0) -> tuple[float, float]:
    """Kaynak (beklenen) dokunma gerilimi altında vücuttan geçen akım (A) ve vücut üzerinde düşen gerilim (V).
    Vücut empedansı gerilime bağlı olduğundan yinelemeyle bulunur. seri_ohm: devrede seri başka direnç (ör. yük)."""
    if u_kaynak_v <= 0:
        return 0.0, 0.0
    z = 1000.0
    i = 0.0
    for _ in range(30):
        i = u_kaynak_v / (z + ra_ek_ohm + seri_ohm)
        z_new = zb_ohm(i * z)
        if abs(z_new - z) < 0.5:
            z = z_new
            break
        z = 0.5 * (z + z_new)
    i = u_kaynak_v / (z + ra_ek_ohm + seri_ohm)
    return i, i * z


def ustp(t_s: float, ra_ek_ohm: float) -> float:
    """Ek dirençler (ayakkabı, yüzey tabakası) hesaba katıldığında izin verilen kaynak dokunma gerilimi USTp (V) — Ek-C.2."""
    u = utp(t_s)
    return u * (1.0 + ra_ek_ohm / zb_ohm(u))


def etki(i_a: float, t_s: float) -> tuple[str, str]:
    """Vücut akımının etkisi → (durum, açıklama). Süre sonsuzsa 10 s'lik sınır kullanılır."""
    ma = i_a * 1000
    v = rules()["vucut"]
    t = 10.0 if (t_s is None or math.isinf(t_s)) else max(t_s, 0.01)
    lim = ib_izin_ma(t)
    if ma < v["algi_esigi_ma"]:
        return "ok", "hissedilmez (AC-1)"
    if ma < v["birakma_esigi_ma"]:
        return "ok", "hissedilir, genellikle zararsız (AC-2)"
    if ma < lim:
        return "warn", f"kas kasılması, bırakamama; bu sürede fibrilasyon sınırının ({fnum(lim, 0)} mA) altında (AC-3)"
    return "bad", f"ölümcül: kalp fibrilasyonu sınırı ({fnum(lim, 0)} mA, {fsure(t)}) aşıldı (AC-4)"


# ---------------- koruma cihazlarının açma süresi ----------------
MCB_IM = {"B": (3, 5), "C": (5, 10), "D": (10, 20)}


def mcb_sure(in_a: float, egri: str, i_a: float) -> float:
    """Otomatın (TS EN 60898-1) en geç açma süresi (s): bandın üst sınırı. Manyetik açma Im_max·In'de kesindir."""
    m = i_a / in_a
    if m >= MCB_IM.get(egri, MCB_IM["C"])[1]:
        return 0.01
    if m <= 1.13 * 1.005:
        return math.inf
    return max(0.5, min(7200.0, 100.0 / ((m / 1.13) ** 2 - 1)))          # ısıl bölge: manyetik eşiğin altında 0,4 s'lik açma sayılmaz


def mcb_ia(in_a: float, egri: str, t_s: float) -> float:
    """Verilen sürede açmayı sağlayan en küçük akım Ia (A)."""
    im = MCB_IM.get(egri, MCB_IM["C"])[1]
    if t_s < 0.5:
        return im * in_a
    m_th = 1.13 * math.sqrt(100.0 / t_s + 1)          # ısıl bölgede t süresini veren akım
    return min(im, m_th) * in_a


def gg_sure(in_a: float, i_a: float) -> float:
    """NH gG sigortanın erime + ark süresi (s): IEC 60269-1 kapı değerleri (5 s ve 0,1 s) arasında log-log ara değer."""
    from ..kurallar import fuse_ia
    rs = ruleset()
    try:
        i5 = fuse_ia(rs, in_a, 5.0); i01 = fuse_ia(rs, in_a, 0.1)
    except Exception:
        i5, i01 = 5.0 * in_a, 12.0 * in_a
    if i_a < 1.6 * in_a:
        return math.inf
    k = (math.log(0.1) - math.log(5.0)) / (math.log(i01) - math.log(i5))        # eğim (negatif)
    t = math.exp(math.log(5.0) + k * (math.log(i_a) - math.log(i5)))
    return max(0.004, min(t, 7200.0))


def gg_ia(in_a: float, t_s: float) -> float:
    from ..kurallar import fuse_ia
    try:
        return fuse_ia(ruleset(), in_a, t_s)
    except Exception:
        return (5.0 if t_s >= 5 else 9.0) * in_a


def rcd_sure(idn_ma: float, i_ma: float, s_tipi: bool = False) -> float:
    """Artık akım koruma düzeninin en geç açma süresi (s). 0,5·IΔn altında açmamalıdır; 0,5–1·IΔn arası belirsizdir (açma garanti değil)."""
    r = rules()["rcd"]["acma_suresi"]
    if idn_ma <= 0 or i_ma < idn_ma:
        return math.inf
    tab = r["S_max"] if s_tipi else r["genel"]
    k = i_ma / idn_ma
    return tab["5"] if k >= 5 else tab["2"] if k >= 2 else tab["1"]


def cihaz_sure(p: dict, i_a: float) -> float:
    in_a = num(p, "in_a", 16)
    return gg_sure(in_a, i_a) if p.get("cihaz") == "gG" else mcb_sure(in_a, str(p.get("egri") or "B"), i_a)


def cihaz_ia(p: dict, t_s: float) -> float:
    in_a = num(p, "in_a", 16)
    return gg_ia(in_a, t_s) if p.get("cihaz") == "gG" else mcb_ia(in_a, str(p.get("egri") or "B"), t_s)


def cihaz_adi(p: dict) -> str:
    in_a = num(p, "in_a", 16)
    return f"NH gG {in_a:g} A" if p.get("cihaz") == "gG" else f"otomat {p.get('egri') or 'B'}{in_a:g}"


# ---------------- fazör yardımcıları ----------------
def fazor(ad: str, z: complex, renk: str = "#1a4d8f", kesik: bool = False, bas: complex = 0j) -> dict:
    return {"ad": ad, "re": round(z.real, 3), "im": round(z.imag, 3), "renk": renk, "kesik": kesik, "bas_re": round(bas.real, 3), "bas_im": round(bas.imag, 3),
            "mod": round(abs(z), 2), "aci": round(math.degrees(math.atan2(z.imag, z.real)), 1) if abs(z) > 1e-12 else 0.0}      # sıfır vektörün açısı tanımsızdır: 0 yazılır (±0 işaretine bağlı kalmasın)


A120 = complex(-0.5, math.sqrt(3) / 2)       # a = 1∠120°
