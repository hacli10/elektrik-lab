"""Laboratuvar konusu — AG'de harmonikler ve nötr akımı.

Model: her yük grubunun akımı tipik harmonik spektrumundan zaman bölgesinde kurulur (bir periyot, 720 örnek); fazlar 120° kaydırılır.
Nötr akımı tek fazlı yüklerin anlık akımlarının toplamıdır. 3'ün katı harmonikler (sıfır bileşen) üç fazda aynı fazda olduğundan nötrde
toplanır. Üç fazlı doğrultucular (6 darbeli) nötre bağlı değildir."""
from __future__ import annotations

import math

from .core import C, K, ctl, fnum, num, opt, rules

ID = "harmonik"
BASLIK = "Harmonikler ve nötr akımı"
IKON = "〰"
GIRIS = ("Fazlar dengeli olsa bile nötrden akım geçebilir: elektronik yüklerin ürettiği 3., 9., 15. harmonikler nötrde birbirini götürmez, toplanır. "
         "Yükleri karıştırın; faz ve nötr akımının dalga biçimini, nötr kesitine, kabloya, trafoya ve yıldız noktası topraklamasına etkisini görün.")
N = 720
HS = (1, 3, 5, 7, 9, 11, 13, 15)

KONTROLLER = [
    ctl("i_dogrusal", "Doğrusal yük (faz başına)", "sayi", 20, min=0, max=400, adim=1, birim="A"),
    ctl("i_led", "LED aydınlatma (faz başına)", "sayi", 10, min=0, max=400, adim=1, birim="A"),
    ctl("i_smps", "Bilgisayar / elektronik (faz başına)", "sayi", 10, min=0, max=400, adim=1, birim="A"),
    ctl("i_inv1f", "Tek fazlı sürücülü cihaz (faz başına)", "sayi", 0, min=0, max=400, adim=1, birim="A"),
    ctl("i_vfd6", "Üç fazlı sürücü (6 darbeli)", "sayi", 0, min=0, max=400, adim=1, birim="A"),
    ctl("vfd_reaktor", "Sürücülerde %3 şok bobini var", "onay", True),
    ctl("dengesiz_pct", "Tek fazlı yüklerde dengesizlik", "sayi", 0, min=0, max=50, adim=5, birim="%", yardim="L1 bu kadar fazla, L3 bu kadar az yüklü"),
    ctl("iz_a", "Kablonun akım taşıma kapasitesi Iz", "sayi", 63, min=10, max=800, adim=1, birim="A", yardim="Dört damarlı kablonun üç yüklü iletken için çizelge değeri"),
    ctl("notr", "Nötr iletkeni kesiti", "sec", "esit", secenek=opt(("esit", "faz kesitine eşit"), ("yarim", "faz kesitinin yarısı"))),
    ctl("trafo_kva", "Trafo gücü", "sec", 400, secenek=opt(*[(v, f"{v} kVA") for v in (100, 160, 250, 400, 630, 800, 1000, 1250, 1600)])),
    ctl("uk_pct", "Trafo kısa devre gerilimi uk", "sayi", 4, min=3, max=8, adim=0.5, birim="%"),
    ctl("kopru", "Nötr ikinci bir noktada da PE'ye bağlı (hatalı N–PE köprüsü)", "onay", False),
    ctl("pe_orani", "Koruma iletkeni yolunun nötr akımından aldığı pay", "sayi", 30, min=5, max=90, adim=5, birim="%", goster={"kopru": [True]}),
]


def _spektrum(key: str) -> dict:
    return {int(h): v / 100.0 for h, v in rules()["harmonik"]["spektrum"]["yukler"][key]["h"].items()}


def _dalga(i1: float, sp: dict, uc_faz: bool, kayma: float) -> list[float]:
    """i1: temel bileşen etkin değeri. Tek fazlı doğrultucu: gerilim tepesinde dar darbe (bütün katsayılar aynı işaretli);
    üç fazlı köprü: 5. ve 11. ters işaretli (yarı kare dalga)."""
    out = []
    for k in range(N):
        th = 2 * math.pi * k / N - kayma
        y = math.cos(th)
        for h, a in sp.items():
            sgn = (-1.0 if h in (5, 11) else 1.0) if uc_faz else 1.0
            y += sgn * a * math.cos(h * th)
        out.append(math.sqrt(2) * i1 * y)
    return out


def _rms(x: list[float]) -> float:
    return math.sqrt(sum(v * v for v in x) / len(x))


def _harm(x: list[float], h: int) -> float:
    """h. harmoniğin etkin değeri (ayrık Fourier)."""
    a = sum(v * math.cos(2 * math.pi * h * k / N) for k, v in enumerate(x)) * 2 / N
    b = sum(v * math.sin(2 * math.pi * h * k / N) for k, v in enumerate(x)) * 2 / N
    return math.hypot(a, b) / math.sqrt(2)


def run(p: dict) -> dict:
    R = rules()["harmonik"]
    d = num(p, "dengesiz_pct", 0) / 100.0
    carp = [1 + d, 1.0, 1 - d]
    tek = [("dogrusal", num(p, "i_dogrusal", 20)), ("led", num(p, "i_led", 10)), ("smps", num(p, "i_smps", 10)), ("inv1f", num(p, "i_inv1f", 0))]
    vkey = "vfd6_r" if p.get("vfd_reaktor", True) else "vfd6"
    i_v = num(p, "i_vfd6", 0)
    faz = [[0.0] * N for _ in range(3)]
    notr = [0.0] * N
    for ph in range(3):
        kay = ph * 2 * math.pi / 3
        for key, i1 in tek:
            if i1 <= 0:
                continue
            w = _dalga(i1 * carp[ph], _spektrum(key), False, kay)
            for k in range(N):
                faz[ph][k] += w[k]; notr[k] += w[k]
        if i_v > 0:
            w = _dalga(i_v, _spektrum(vkey), True, kay)
            for k in range(N):
                faz[ph][k] += w[k]
    if all(_rms(f) < 1e-9 for f in faz):
        faz[0][0] = 1e-9
    irms = [_rms(f) for f in faz]
    i_faz = max(irms)
    f0 = faz[0]
    hf = {h: _harm(f0, h) for h in HS}
    hn = {h: _harm(notr, h) for h in HS}
    i1 = max(hf[1], 1e-9)
    thd = math.sqrt(sum(v * v for h, v in hf.items() if h > 1)) / i1 * 100
    i_n = _rms(notr)
    h3 = hf[3] / i1 * 100
    oran = i_n / i_faz if i_faz > 0 else 0
    kt, an, ds = [], [], []
    an.append(f"L1 fazının akımı {fnum(irms[0], 1)} A (etkin); temel bileşeni {fnum(hf[1], 1)} A, toplam harmonik bozulması THDi = %{fnum(thd, 0)}. 3. harmoniğin temel bileşene oranı %{fnum(h3, 0)}.")
    if d == 0:
        an.append("Fazlar tam dengeli: 50 Hz bileşenleri nötrde birbirini götürür (aralarında 120° var). Doğrusal yükte nötr akımı sıfır olurdu.")
    else:
        an.append(f"Fazlar dengesiz (%{fnum(d * 100, 0)}): nötrden hem dengesizlik akımı (50 Hz) hem harmonik akımı geçer.")
    an.append(f"3. harmonik bir periyotta üç kez salınır; fazlar arasındaki 120° kayma 3. harmonik için 360° eder. Yani üç fazın 3. harmonikleri aynı fazdadır ve nötrde toplanır: nötrdeki 150 Hz bileşeni {fnum(hn[3], 1)} A ≈ 3 × {fnum(hf[3], 1)} A.")
    an.append(f"Nötr akımı {fnum(i_n, 1)} A; faz akımına oranı %{fnum(oran * 100, 0)}" + (". Nötr, fazlardan fazla akım taşıyor." if oran > 1 else "."))
    if i_v > 0:
        an.append("Üç fazlı sürücüler 5., 7., 11., 13. harmonikleri üretir; nötre bağlı olmadıkları ve 3'ün katı harmonik üretmedikleri için nötr akımını artırmaz, ama faz akımını, trafoyu ve gerilim bozulmasını etkiler.")
    # kablo — TS HD 60364-5-52 Ek E
    kab = R["kablo"]
    row = next(r for r in kab["satirlar"] if h3 <= r[0])
    esas = i_n if row[1] == "notr" else i_faz
    gerek = esas / row[2]
    kt.append(C("Kablo seçimi (harmonik düzeltmesi)", f"3. harmonik %{fnum(h3, 0)} → seçim {'nötr' if row[1] == 'notr' else 'faz'} akımına göre, katsayı {fnum(row[2], 2)}: gereken Iz ≥ {fnum(esas, 1)} / {fnum(row[2], 2)} = {fnum(gerek, 1)} A",
                f"Iz = {fnum(num(p, 'iz_a', 63), 0)} A", num(p, "iz_a", 63) >= gerek - 1e-9, kab["kaynak"], kab["durum"]))
    yarim = p.get("notr") == "yarim"
    nk = R["notr_kesiti"]
    kt.append(C("Nötr iletkeni kesiti", ("faz kesitinin yarısı" if yarim else "faz kesitine eşit") + f" ; nötr akımı {fnum(i_n, 1)} A, faz akımı {fnum(i_faz, 1)} A",
                "3. harmonik > %15 ise nötr ≥ faz kesiti ; > %33 ise nötr akımına göre", not (yarim and h3 > 15) and not (yarim and i_n > i_faz / 2 + 1e-9), nk["kaynak"], nk["durum"]))
    if yarim and h3 > 15:
        an.append("Nötr kesiti fazın yarısı seçilmiş. Nötrde aşırı akım koruması genellikle bulunmadığı için bu iletken kimse fark etmeden aşırı ısınır.")
    # trafo
    T = R["trafo"]
    sn = num(p, "trafo_kva", 400)
    s_yuk = math.sqrt(3) * 400 * (sum(irms) / 3) / 1000
    kf = sum((hf[h] / irms[0]) ** 2 * h * h for h in HS) if irms[0] > 0 else 1.0
    kd = math.sqrt(1 + T["e"] / (1 + T["e"]) * (i1 / irms[0]) ** 2 * sum(h ** T["q"] * (hf[h] / i1) ** 2 for h in HS if h > 1)) if irms[0] > 0 else 1.0
    izin = sn / kd
    kt.append(C("Trafo yüklenmesi (harmonikli yük)", f"yük {fnum(s_yuk, 0)} kVA ; K = {fnum(kd, 2)} → izin verilen {fnum(sn, 0)} / {fnum(kd, 2)} = {fnum(izin, 0)} kVA  (K-faktörü {fnum(kf, 1)})", f"yük ≤ {fnum(izin, 0)} kVA", s_yuk <= izin + 1e-9, T["kaynak"], T["durum"]))
    in_tr = sn * 1000 / (math.sqrt(3) * 400)
    thdu = math.sqrt(sum((h * num(p, "uk_pct", 4) * hf[h] / in_tr) ** 2 for h in HS if h > 1))
    TU = R["thdu"]
    kt.append(C("Gerilim bozulması (yalnız trafo reaktansından, yaklaşık)", f"THDu ≈ √Σ(h · uk · Ih / In)² = %{fnum(thdu, 1)}", f"≤ %{TU['sinir_pct']}", thdu <= TU["sinir_pct"] + 1e-9, TU["kaynak"], "tahmini"))
    an.append(f"Trafo: Dyn bağlı trafoda nötrdeki 3'ün katı akımlar yıldız (AG) sargıdan geçer ve üçgen (OG) sargının içinde dolaşır; OG şebekesine çıkmaz ama sargıları ısıtır. Bu yük için trafonun kullanılabilir gücü {fnum(izin, 0)} kVA'ya düşer.")
    # N–PE köprüsü
    kopru = bool(p.get("kopru"))
    i_pe = i_n * num(p, "pe_orani", 30) / 100.0 if kopru else 0.0
    kt.append(C("Nötr ile koruma iletkeni tek noktada birleşir (TN-S)", "ikinci bir N–PE bağlantısı var" if kopru else "yalnız kaynakta", "ayrımdan sonra N ile PE birleştirilmez", not kopru, "Topraklamalar Yön. m.8-a3.8, m.9-h; TS HD 60364-4-44 m.444.4", "dogrulanacak"))
    if kopru:
        an.append(f"Hatalı N–PE köprüsü: nötr akımı iki paralel yol bulur. {fnum(i_pe, 1)} A koruma iletkeninden, kablo tavalarından, yapı çeliğinden ve trafonun yıldız noktası topraklama iletkeninden döner. "
                  "Bu akım süreklidir: pens ampermetreyle topraklama iletkeninde okunur, kaçak akım rölelerini açtırır, ekranlı kablolarda ve ölçü devrelerinde bozulmaya yol açar.")
    else:
        an.append("Nötr yalnız kaynakta topraklı olduğu sürece nötr akımının tamamı nötr iletkeninden döner; trafonun yıldız noktası topraklama iletkeninden sürekli akım geçmez. Orada akım ölçülüyorsa tesiste bir yerde ikinci bir N–PE bağlantısı vardır.")
    ds += ["Nötr akımını yaratan dengesizlik değil, 3'ün katı harmoniklerdir: dengeli ama elektronik yük ağırlıklı bir panoda nötr akımı faz akımını geçebilir (kuramsal üst sınır √3 kat).",
           "Bu yüzden büro, veri merkezi, LED aydınlatma panolarında nötr en az faz kesitinde seçilir ve dört kutuplu cihazlarda nötr kutbu da korunur.",
           "Üç fazlı sürücüler nötrü yüklemez; onların sorunu 5. ve 7. harmoniktir: trafo ısınması, gerilim bozulması, kompanzasyonla rezonans.",
           "Trafo yıldız noktası topraklama iletkeninde sürekli akım görmek normal değildir: N ile PE'nin birden çok noktada bağlı olduğunu gösterir."]
    # grafikler
    adim = 4
    ms = [round(k * 20.0 / N, 3) for k in range(0, N + 1, adim)]
    def pts(x):
        return [[ms[j], round(x[(j * adim) % N], 2)] for j in range(len(ms))]
    graf = [{"baslik": "Akımların dalga biçimi (bir periyot)", "x_ad": "zaman (ms)", "y_ad": "akım (A)", "seriler": [
        {"ad": f"L1 {fnum(irms[0], 1)} A", "renk": "#8a4b12", "pts": pts(faz[0])}, {"ad": f"L2 {fnum(irms[1], 1)} A", "renk": "#111827", "pts": pts(faz[1])},
        {"ad": f"L3 {fnum(irms[2], 1)} A", "renk": "#9ca3af", "pts": pts(faz[2])}, {"ad": f"NÖTR {fnum(i_n, 1)} A", "renk": "#1d4ed8", "pts": pts(notr)}]}]
    cubuk = [{"baslik": "Harmonik spektrumu (etkin değer)", "y_ad": "A", "kategoriler": [f"{h}." for h in HS], "alt": [f"{h * 50} Hz" for h in HS],
              "seriler": [{"ad": "faz (L1)", "renk": "#8a4b12", "deger": [round(hf[h], 2) for h in HS]}, {"ad": "nötr", "renk": "#1d4ed8", "deger": [round(hn[h], 2) for h in HS]}]}]
    S = R["spektrum"]
    kim = {"baslik": "Kim harmonik üretir?", "cols": ["Yük", "3.", "5.", "7.", "9.", "11.", "13.", "Not"],
           "rows": [[v["ad"]] + [(f"%{v['h'][str(h)]}" if str(h) in v["h"] else "—") for h in (3, 5, 7, 9, 11, 13)] + [v["not"]] for v in S["yukler"].values()],
           "not": f"Temel bileşenin yüzdesi. {S['kaynak']} — durum: {S['durum']}"}
    E = R["etkiler"]
    etk = {"baslik": "Harmoniklerin sonuçları", "cols": ["Nerede", "Ne olur", "Sonuç"], "rows": E["satirlar"], "not": f"{E['kaynak']} — durum: {E['durum']}"}
    oz = [K("Faz akımı (etkin)", f"{fnum(i_faz, 1)} A", "info", f"THDi %{fnum(thd, 0)} ; 3. harmonik %{fnum(h3, 0)}"),
          K("Nötr akımı", f"{fnum(i_n, 1)} A", "bad" if oran > 1 else "warn" if oran > 0.5 else "ok", f"faz akımına oranı %{fnum(oran * 100, 0)} ; baskın {150 if hn[3] >= hn[1] else 50} Hz"),
          K("Kablo için gereken Iz", f"{fnum(gerek, 1)} A", "ok" if num(p, "iz_a", 63) >= gerek else "bad", f"seçilen {fnum(num(p, 'iz_a', 63), 0)} A"),
          K("Trafonun kullanılabilir gücü", f"{fnum(izin, 0)} kVA", "ok" if s_yuk <= izin else "bad", f"anma {fnum(sn, 0)} kVA ; yük {fnum(s_yuk, 0)} kVA"),
          K("Topraklama iletkeninde akım", f"{fnum(i_pe, 1)} A", "bad" if kopru else "ok", "N–PE köprüsü üzerinden" if kopru else "nötr tek noktada topraklı")]
    sahne = {"tip": "harmonik", "i_faz": [round(v, 1) for v in irms], "i_n": round(i_n, 1), "i_n3": round(hn[3], 1), "i_pe": round(i_pe, 1), "kopru": kopru, "oran": round(oran, 2),
             "ucgen": round(hn[3] / 3 if hn[3] else 0, 1), "yarim": yarim}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "grafikler": graf, "cubuklar": cubuk, "tablolar": [kim, etk]}
