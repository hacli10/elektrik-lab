"""Laboratuvar konusu — topraklayıcı tasarımı: hedef dirence ulaşmak için kaç kazık, hangi aralıkla? Karşılıklı etki.

Model: tek kazık R1 = ρ/(2π·l)·ln(4·l/d). İki kazık arasındaki karşılıklı direnç, birinin diğerinin bulunduğu yerde oluşturduğu
potansiyelden: Rm(s) = ρ/(2π·l)·ln((l + √(l² + s²)) / s)  (s ≫ l için ρ/(2π·s)). n eş kazık, eşit akım: R = (1/n²)·ΣΣ Rij.
Kazıklar birbirine yaklaştıkça hunileri örtüşür ve her yeni kazığın katkısı azalır. Dayanak: Topraklamalar Yön. Ek-T."""
from __future__ import annotations

import math

from .core import C, K, ctl, fnum, num, opt, utp

ID = "tasarim"
BASLIK = "Topraklayıcı tasarımı"
IKON = "📐"
GIRIS = ("İki kazık bir kazığın yarısı kadar direnç vermez: yakın çakılan kazıkların potansiyel hunileri örtüşür. Özdirenci, kazık boyunu, sayısını ve aralığını değiştirin; "
         "toplam direnci, her kazığın ne kadar işe yaradığını ve hedef için gereken sayıyı görün.")
D_KAZIK = 0.02

KONTROLLER = [
    ctl("rho", "Toprak özdirenci ρ", "sayi", 100, min=10, max=3000, adim=10, birim="Ω·m"),
    ctl("hedef", "Hedef topraklama direnci", "sayi", 10, min=0.5, max=100, adim=0.5, birim="Ω", yardim="TT 30 mA: ≤ 1666 Ω · trafo merkezi: 2·UTp / IE · yıldırım: 10 Ω · şartname/müellif: 2–5 Ω"),
    ctl("l_m", "Kazık boyu", "sayi", 3, min=1, max=12, adim=0.5, birim="m"),
    ctl("n", "Kazık sayısı", "sayi", 4, min=1, max=40, adim=1),
    ctl("a_m", "Kazıklar arası uzaklık", "sayi", 6, min=0.5, max=30, adim=0.5, birim="m"),
    ctl("dizilim", "Diziliş", "sec", "sira", secenek=opt(("sira", "Tek sıra (doğru üzerinde)"), ("halka", "Kapalı halka / çokgen"), ("kare", "Kare ağ"))),
    ctl("serit", "Kazıkları bağlayan gömülü şerit de topraklayıcı sayılsın", "onay", False),
    ctl("mevsim", "Mevsim", "sec", "nemli", secenek=opt(("nemli", "Nemli mevsim (ölçüm koşulu)"), ("kuru", "Kuru / donmuş üst tabaka (direnç ≈ 2 kat)"))),
    ctl("ie_a", "Toprağa akan akım (gösterim için)", "sayi", 10, min=1, max=2000, adim=5, birim="A"),
]


def r1(rho: float, l: float) -> float:
    return rho / (2 * math.pi * l) * math.log(4 * l / D_KAZIK)


def rm(rho: float, l: float, s: float) -> float:
    return rho / (2 * math.pi * l) * math.log((l + math.hypot(l, s)) / s)


def konumlar(n: int, a: float, dizilim: str) -> list[tuple[float, float]]:
    if n == 1:
        return [(0.0, 0.0)]
    if dizilim == "halka":
        rad = a / (2 * math.sin(math.pi / n)) if n > 2 else a / 2
        return [(rad * math.cos(2 * math.pi * k / n), rad * math.sin(2 * math.pi * k / n)) for k in range(n)]
    if dizilim == "kare":
        m = math.ceil(math.sqrt(n))
        pts = [((i - (m - 1) / 2) * a, (j - (m - 1) / 2) * a) for j in range(m) for i in range(m)]
        return pts[:n]
    return [((k - (n - 1) / 2) * a, 0.0) for k in range(n)]


def grup(rho: float, l: float, pos: list[tuple[float, float]]) -> float:
    n = len(pos)
    tot = 0.0
    for i in range(n):
        for j in range(n):
            tot += r1(rho, l) if i == j else rm(rho, l, math.hypot(pos[i][0] - pos[j][0], pos[i][1] - pos[j][1]))
    return tot / (n * n)


def run(p: dict) -> dict:
    rho = num(p, "rho", 100); hedef = num(p, "hedef", 10); l = num(p, "l_m", 3); n = max(1, int(num(p, "n", 4))); a = num(p, "a_m", 6)
    diz = p.get("dizilim") if p.get("dizilim") in ("sira", "halka", "kare") else "sira"
    kuru = p.get("mevsim") == "kuru"
    kat = 2.0 if kuru else 1.0
    pos = konumlar(n, a, diz)
    r_tek = r1(rho, l)
    r_k = grup(rho, l, pos)
    l_serit = (n * a if diz == "halka" and n > 2 else (n - 1) * a) if n > 1 else 0.0
    r_s = (rho / (2 * math.pi * l_serit) * math.log(l_serit ** 2 / (0.015 * 0.6))) if (p.get("serit") and l_serit > 1) else None
    r_top = (1.15 * r_k * r_s / (r_k + r_s)) if r_s else r_k
    r_top *= kat
    eta = (r_tek / n) / r_k
    # hedef için gereken sayı (aynı aralık ve dizilişle)
    gerek = next((m for m in range(1, 81) if grup(rho, l, konumlar(m, a, diz)) * kat <= hedef), None)
    an = [f"Tek kazık ({fnum(l, 1)} m, Ø 20 mm): R1 = ρ/(2π·l)·ln(4·l/d) = {fnum(r_tek, 1)} Ω. Kazıklar birbirini hiç etkilemeseydi {n} kazık R1/n = {fnum(r_tek / n, 2)} Ω verirdi.",
          f"Kazıklar {fnum(a, 1)} m aralıkla ({'tek sıra' if diz == 'sira' else 'halka' if diz == 'halka' else 'kare ağ'}) çakılı. Her kazık, komşusunun potansiyel hunisinin içinde kalıyor; gerçek direnç {fnum(r_k, 2)} Ω.",
          f"Fayda oranı %{fnum(eta * 100, 0)}: {n} kazık, birbirinden bağımsız {fnum(n * eta, 1)} kazık kadar iş görüyor. Aralık büyüdükçe oran %100'e yaklaşır."]
    if r_s:
        an.append(f"Kazıkları bağlayan {fnum(l_serit, 0)} m gömülü şerit de toprağa akım verir (tek başına {fnum(r_s, 2)} Ω). Kazıklarla birlikte toplam ≈ {fnum(r_top / kat, 2)} Ω (karşılıklı etki payı %15 alınmıştır).")
    if kuru:
        an.append(f"Kuru ya da donmuş mevsimde üst tabakanın özdirenci artar; kısa kazıklar ve yüzeysel şeritler en çok etkilenir. Burada kaba bir kabulle direnç iki katı alınmıştır: {fnum(r_top, 2)} Ω. Derin kazık mevsimden daha az etkilenir.")
    an.append(f"Hedef {fnum(hedef, 1)} Ω için bu aralık ve dizilişle " + (f"en az {gerek} kazık gerekir." if gerek else "80 kazık bile yetmez: kazık boyu, aralık ya da yöntem (derin kazık, halka, toprak iyileştirme) değiştirilmelidir."))
    kt = [C("Topraklama direnci", f"R = {fnum(r_top, 2)} Ω", f"≤ {fnum(hedef, 1)} Ω (hedef)", r_top <= hedef + 1e-9, "Topraklamalar Yön. Ek-T (hesap); hedef değer tesisin koşulundan (m.8, m.11) ya da şartnameden"),
          C("Kazıklar arası uzaklık", f"{fnum(a, 1)} m = {fnum(a / l, 1)} × kazık boyu", f"≥ 2 × kazık boyu = {fnum(2 * l, 1)} m", a >= 2 * l - 1e-9 if n > 1 else None, "Topraklamalar Yön. Ek-T (b: derin topraklayıcı)"),
          C("Ölçümle doğrulama", "hesap ön tasarımdır", "tesis edildikten sonra ölçülür; kuru mevsim payı bırakılır", None, "Topraklamalar Yön. m.10, Ek-N, Ek-P")]
    ds = ["Kazık sayısını ikiye katlamak direnci yarıya indirmez. Aralık kazık boyundan kısaysa ikinci kazığın katkısı %30–40'ta kalır.",
          "Aynı malzemeyle en çok kazanç: kazıkları birbirinden uzaklaştırmak (en az 2 × boy) ve dizilişi yaymak. Tek sıra, aynı sayıdaki sık bir kare ağdan daha verimlidir.",
          "Direnç özdirençle doğru orantılıdır; kazık boyu ise logaritmik etkiler. Üst tabaka dirençli, alt tabaka iletkense uzun kazık; tersi ise yüzeye yakın uzun şerit ya da halka daha iyidir.",
          "Kazıkları bağlayan çıplak şerit yalnızca bağlantı değil, kendisi de topraklayıcıdır; çoğu zaman kazıklardan daha fazla katkı yapar.",
          "Hedef değer tesise göre değişir: TT'de birkaç yüz ohm yeterken trafo merkezinde 1 Ω'un altı gerekebilir. “Her yerde 5 Ω” diye bir kural yoktur."]
    ns = list(range(1, 21))
    seriler = [{"ad": f"aralık = {k:g} × boy", "renk": col, "pts": [[m, round(grup(rho, l, konumlar(m, k * l, diz)) * kat, 3)] for m in ns]} for k, col in ((0.5, "#dc2626"), (1, "#d97706"), (2, "#15803d"), (4, "#1a4d8f"))]
    seriler.append({"ad": "etkileşim yok (R1 / n)", "renk": "#94a3b8", "kesik": True, "pts": [[m, round(r_tek * kat / m, 3)] for m in ns]})
    graf = [{"baslik": "Kazık sayısına göre toplam direnç", "x_ad": "kazık sayısı", "y_ad": "direnç (Ω)", "logy": True, "seriler": seriler, "yatay": [{"y": hedef, "etiket": f"hedef {fnum(hedef, 1)} Ω", "renk": "#334155"}], "isaretler": [{"x": n, "etiket": f"{n} kazık"}]}]
    # 3B: zemin potansiyeli (kazıklar eşit akım paylaşır)
    ie = num(p, "ie_a", 10)
    pts = [(x, y, (k + 0.5) * l / 8, 1.0 / (8 * n)) for x, y in pos for k in range(8)]
    ue = r_k * ie
    half = max(8.0, max(max(abs(x), abs(y)) for x, y in pos) + 6.0)
    def phi(xx, yy):
        s = 0.0
        for sx, sy, sz, w in pts:
            s += w / max(0.05, math.sqrt((xx - sx) ** 2 + (yy - sy) ** 2 + sz * sz))
        return min(ue, rho * ie / (2 * math.pi) * s)
    ng = 33
    grid = [round(phi(-half + 2 * half * i / (ng - 1), -half + 2 * half * j / (ng - 1)) / ue, 3) for j in range(ng) for i in range(ng)]
    x0 = pos[-1][0] + 1.0
    f_x = phi(x0, pos[-1][1]); u_st = ue - f_x; u_ss = abs(f_x - phi(x0 + 1, pos[-1][1]))
    sahne = {"tip": "dokunma", "n": ng, "half": round(half, 2), "grid": grid, "ue": round(ue, 1), "cizgiler": [[[x, y, 0], [x, y, l]] for x, y in pos], "kisi_x": round(min(x0, half - 0.5), 2), "phi_x": round(f_x, 1), "ust": round(u_st, 1), "uss": round(u_ss, 1),
             "durum": "ok" if ue <= 2 * utp(0.5) else "bad", "elektrot": f"{n} kazık · {fnum(a, 1)} m aralık"}
    oz = [K("Toplam direnç", f"{fnum(r_top, 2)} Ω", "ok" if r_top <= hedef else "bad", f"hedef {fnum(hedef, 1)} Ω"), K("Tek kazık", f"{fnum(r_tek, 1)} Ω", "info", f"{fnum(l, 1)} m, ρ = {fnum(rho, 0)} Ω·m"),
          K("Fayda oranı", f"%{fnum(eta * 100, 0)}", "ok" if eta >= 0.75 else "warn" if eta >= 0.5 else "bad", f"{n} kazık ≈ {fnum(n * eta, 1)} bağımsız kazık"),
          K("Hedef için gereken", f"{gerek} kazık" if gerek else "> 80", "ok" if gerek and gerek <= n else "bad", "bu aralık ve dizilişle")]
    tablo = {"baslik": "Topraklayıcı tipleri ve yaklaşık formüller", "cols": ["Tip", "Yayılma direnci", "Ne zaman"], "rows": [
        ["Derin (çubuk) topraklayıcı", "R = ρ/(2π·l)·ln(4·l/d) ≈ ρ / l", "Alt tabaka iletkense; yer darsa. Aralık ≥ 2 × boy"],
        ["Yüzeysel (şerit) topraklayıcı", "R = ρ/(π·l)·ln(2·l/d) ≈ 2·ρ / l  (0,5–1 m derinde)", "Üst tabaka iletkense; kaya zeminde"],
        ["Halka (ring) topraklayıcı", "R = ρ/(π²·D)·ln(2π·D/d) ≈ 2·ρ / (3·D)", "Bina ve trafo merkezi çevresi; potansiyel düzenleme de sağlar"],
        ["Gözlü (ağ) topraklayıcı", "R = ρ/(2·D) + ρ/L  (D: eş alanlı dairenin çapı, L: toplam iletken)", "Trafo merkezleri, şalt sahaları"],
        ["Temel topraklayıcı", "R ≈ 2·ρ / (π·D)  (D: temel alanına eş alanlı dairenin çapı)", "Yeni binalarda; betonun nemi sayesinde kararlı"]],
        "not": "Topraklamalar Yön. Ek-T — durum: resmi (formüller ön tasarım içindir; tesis ölçümle doğrulanır). Kuru mevsim katsayısı: tahmini."}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "grafikler": graf, "tablolar": [tablo]}
