"""Laboratuvar konusu 1 — AG şebeke tipleri (TN-S, TN-C, TN-C-S, TT, IT) ve arıza simülatörü.

Model: tek faz–toprak arıza çevrimi, kararlı durum. Çevrim = kaynak+üst devre empedansı (Zk, pano barasına kadar) + hat faz iletkeni
+ dönüş yolu (PE / PEN ya da toprak: RA + RB). Dayanak: Topraklamalar Yön. m.8 (Çizelge-2, Çizelge-3), Ek-C."""
from __future__ import annotations

import math

from .core import (A120, C, K, OMEGA, RHO_CU, cihaz_adi, cihaz_ia, cihaz_sure, ctl, etki, fazor, fnum, fsure, ib_izin_ma, num, opt, rcd_sure, rules, vucut_akimi)

ID = "sebeke"
BASLIK = "Şebeke tipleri ve arıza"
IKON = "🔌"
GIRIS = ("TN-S, TN-C, TN-C-S, TT ve IT sistemlerinde aynı arızayı koyun; akımın hangi yoldan döndüğünü, gövdede hangi gerilimin oluştuğunu, "
         "hangi cihazın ne kadar sürede açtığını ve yönetmelik koşulunun sağlanıp sağlanmadığını görün.")

SISTEMLER = ("TN-S", "TN-C-S", "TN-C", "TT", "IT")
ARIZALAR = {
    "faz_govde": "Faz – gövde kısa devresi (yalıtım arızası)",
    "pen_kopuk": "PEN iletkeni kopması (yük altında)",
    "notr_kopuk": "Nötr kopması (üç fazlı dengesiz yük)",
    "faz_toprak": "Faz iletkeninin doğrudan toprağa teması (havai hat kopması)",
    "ikinci_ariza": "IT'de ikinci arıza (başka fazda, başka cihazda)",
}
GECERLI = {"TN-S": ("faz_govde", "notr_kopuk", "faz_toprak"), "TN-C-S": ("faz_govde", "pen_kopuk", "notr_kopuk", "faz_toprak"),
           "TN-C": ("faz_govde", "pen_kopuk", "faz_toprak"), "TT": ("faz_govde", "notr_kopuk", "faz_toprak"), "IT": ("faz_govde", "ikinci_ariza")}

KONTROLLER = [
    ctl("sistem", "Şebeke (topraklama) sistemi", "sec", "TN-S", secenek=opt(*[(s, s) for s in SISTEMLER])),
    ctl("ariza", "Arıza", "sec", "faz_govde", secenek=opt(*ARIZALAR.items()), yardim="Seçilen sistemde anlamı olmayan arıza seçilirse faz–gövde arızası gösterilir"),
    ctl("devre", "Devre türü", "sec", "nihai", secenek=opt(("nihai", "Nihai devre (priz, elde kullanılan cihaz) — 0,4 s"), ("dagitim", "Dağıtım devresi / sabit cihaz — 5 s")),
        goster={"ariza": ["faz_govde", "ikinci_ariza"]}),
    ctl("cihaz", "Aşırı akım koruma cihazı", "sec", "MCB", secenek=opt(("MCB", "Otomat (MCB)"), ("gG", "NH gG sigorta")), goster={"ariza": ["faz_govde", "ikinci_ariza", "pen_kopuk", "faz_toprak"]}),
    ctl("egri", "Otomat eğrisi", "sec", "B", secenek=opt(("B", "B (3–5·In)"), ("C", "C (5–10·In)"), ("D", "D (10–20·In)")), goster={"cihaz": ["MCB"]}),
    ctl("in_a", "Anma akımı In", "sec", 16, secenek=opt(*[(v, f"{v} A") for v in (6, 10, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125)]), goster={"ariza": ["faz_govde", "ikinci_ariza", "pen_kopuk", "faz_toprak"]}),
    ctl("rcd_ma", "Kaçak akım rölesi (RCD)", "sec", 0, secenek=opt((0, "yok"), (30, "30 mA"), (100, "100 mA"), (300, "300 mA"), (500, "500 mA"))),
    ctl("rcd_s", "RCD seçici (S) tip", "onay", False, goster={"rcd_ma": [100, 300, 500]}),
    ctl("zk_mohm", "Pano barasına kadar çevrim empedansı Zk", "sayi", 80, min=5, max=2000, adim=5, birim="mΩ", yardim="Trafo + üst kablolar (faz + dönüş). Büyük trafoya yakın pano ≈ 20–50 mΩ; şebeke ucundaki ev ≈ 300–800 mΩ",
        goster={"ariza": ["faz_govde", "ikinci_ariza"]}),
    ctl("l_m", "Hat uzunluğu", "sayi", 30, min=1, max=300, adim=1, birim="m", goster={"ariza": ["faz_govde", "ikinci_ariza"]}),
    ctl("s_mm2", "Faz iletkeni kesiti", "sec", 2.5, secenek=opt(*[(v, f"{v:g} mm²") for v in (1.5, 2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95)]), goster={"ariza": ["faz_govde", "ikinci_ariza"]}),
    ctl("spe_mm2", "Koruma iletkeni (PE / PEN) kesiti", "sec", 2.5, secenek=opt(*[(v, f"{v:g} mm²") for v in (1.5, 2.5, 4, 6, 10, 16, 25, 35, 50)]), goster={"ariza": ["faz_govde", "ikinci_ariza"]}),
    ctl("rf_ohm", "Arıza noktası direnci", "sayi", 0, min=0, max=5000, adim=1, birim="Ω", yardim="0 = metalik (tam) kısa devre; nemli yalıtım, kömürleşme için 10–1000 Ω deneyin", goster={"ariza": ["faz_govde"]}),
    ctl("ra_ohm", "Tüketici topraklama direnci RA", "sayi", 20, min=0.1, max=2000, adim=1, birim="Ω", yardim="TT ve IT'de gövdelerin bağlı olduğu topraklayıcı; TN-C-S'de bina girişindeki ek topraklama"),
    ctl("yerel_toprak", "Bina girişinde PEN yerel olarak topraklı (temel topraklayıcı)", "onay", True, goster={"ariza": ["pen_kopuk"]}),
    ctl("rb_ohm", "Kaynak (işletme) topraklama direnci RB", "sayi", 2, min=0.05, max=100, adim=0.5, birim="Ω"),
    ctl("re_ohm", "Kopan iletkenin toprağa temas direnci RE", "sayi", 10, min=0.5, max=1000, adim=1, birim="Ω", goster={"ariza": ["faz_toprak"]}),
    ctl("p_yuk_kw", "Çalışan yük (PEN koptuğu anda)", "sayi", 2, min=0.05, max=30, adim=0.5, birim="kW", goster={"ariza": ["pen_kopuk"]}),
    ctl("p1_kw", "L1 fazındaki yük", "sayi", 3, min=0.05, max=30, adim=0.5, birim="kW", goster={"ariza": ["notr_kopuk"]}),
    ctl("p2_kw", "L2 fazındaki yük", "sayi", 0.3, min=0.05, max=30, adim=0.1, birim="kW", goster={"ariza": ["notr_kopuk"]}),
    ctl("p3_kw", "L3 fazındaki yük", "sayi", 1.5, min=0.05, max=30, adim=0.5, birim="kW", goster={"ariza": ["notr_kopuk"]}),
    ctl("c_uf", "Şebekenin toprağa kapasitesi (faz başına)", "sayi", 1.0, min=0.01, max=50, adim=0.1, birim="µF", yardim="IT: kablo ne kadar uzunsa o kadar büyük (≈ 0,2–0,5 µF/km)", goster={"sistem": ["IT"]}),
    ctl("zemin_ohm", "Kişinin ek direnci (ayakkabı + zemin)", "sec", 0, secenek=opt((0, "yok — ıslak zemin, çıplak ayak (en kötü durum)"), (1000, "nemli ayakkabı ≈ 1 kΩ"), (3000, "kuru ayakkabı + kuru zemin ≈ 3 kΩ"))),
]
U0 = 230.0
KAYNAK_M8 = "Topraklamalar Yön. m.8"


def _kisi(u_kaynak: float, ra_ek: float, t: float, seri: float = 0.0) -> dict:
    i, ut = vucut_akimi(u_kaynak, ra_ek, seri)
    d, txt = etki(i, t)
    return {"var": True, "ib_ma": round(i * 1000, 1), "ut_v": round(ut, 1), "u_kaynak_v": round(u_kaynak, 1), "durum": d, "etki": txt,
            "sinir_ma": round(ib_izin_ma(10.0 if math.isinf(t) else max(t, 0.01)), 0)}


def _kullanim_tablosu() -> dict:
    k = rules()["kullanim"]
    return {"baslik": "Hangi sistem nerede kullanılır?", "cols": ["Sistem", "Tanım", "Nerede", "Güçlü yanı", "Zayıf yanı"], "rows": k["satirlar"], "not": f"{k['kaynak']} — durum: {k['durum']}"}


def _ozet_tablosu() -> dict:
    return {"baslik": "Sistemlere göre faz–gövde arızasında ne olur?", "cols": ["Sistem", "Arıza akımı", "Kim açar", "Koşul", "Dayanak"], "rows": [
        ["TN-S / TN-C-S", "Kısa devre mertebesinde (yüzlerce – binlerce A)", "Aşırı akım cihazı; yetmezse RCD", "Zs · Ia ≤ U0 ; 230 V'ta 0,4 s (dağıtım devresi 5 s)", "m.8-a3.3, Çizelge-2"],
        ["TN-C", "Kısa devre mertebesinde", "Yalnız aşırı akım cihazı", "Zs · Ia ≤ U0 ; RCD kullanılamaz", "m.8-a3.8"],
        ["TT", "Küçük: U0 / (RA + RB) — çoğu zaman 5–30 A", "Kaçak akım rölesi", "RA · IΔn ≤ 50 V", "m.8-a4"],
        ["IT (ilk arıza)", "Çok küçük: şebeke kapasitesinden (mA – birkaç A)", "Kimse açmaz; yalıtım izleme cihazı alarm verir", "RA · Id ≤ 50 V", "m.8-a5.3, a5.4"],
        ["IT (ikinci arıza)", "Faz–faz kısa devresi mertebesinde", "Aşırı akım cihazı (ya da RCD)", "Zs ≤ √3·U0 / (2·Ia) ; 0,4 s", "m.8-a5.6, Çizelge-3"]],
        "not": "Kaynak: Elektrik Tesislerinde Topraklamalar Yönetmeliği m.8 — durum: resmi"}


def run(p: dict) -> dict:
    sistem = p.get("sistem") if p.get("sistem") in SISTEMLER else "TN-S"
    ariza = p.get("ariza") if p.get("ariza") in GECERLI[sistem] else "faz_govde"
    uyari = None if p.get("ariza", "faz_govde") == ariza else f"“{ARIZALAR.get(p.get('ariza'), p.get('ariza'))}” {sistem} sisteminde tanımlı değil; faz–gövde arızası gösteriliyor."
    f = {"faz_govde": _faz_govde, "ikinci_ariza": _ikinci_ariza, "pen_kopuk": _pen_kopuk, "notr_kopuk": _notr_kopuk, "faz_toprak": _faz_toprak}[ariza]
    out = f(p, sistem)
    out["sahne"].update({"tip": "sebeke", "sistem": sistem, "ariza": ariza})
    if uyari:
        out["anlatim"].insert(0, uyari)
    out["tablolar"] = [_ozet_tablosu(), _kullanim_tablosu()]
    return out


# ---------------- faz – gövde ----------------
def _hat(p: dict) -> tuple[float, float, float]:
    zk = num(p, "zk_mohm", 80) / 1000.0
    r_l = RHO_CU * num(p, "l_m", 30) / num(p, "s_mm2", 2.5)
    r_pe = RHO_CU * num(p, "l_m", 30) / num(p, "spe_mm2", 2.5)
    return zk, r_l, r_pe


def _faz_govde(p: dict, sistem: str) -> dict:
    zk, r_l, r_pe = _hat(p)
    rf = num(p, "rf_ohm", 0); ra = num(p, "ra_ohm", 20); rb = num(p, "rb_ohm", 2)
    rcd = int(num(p, "rcd_ma", 0)); s_tip = bool(p.get("rcd_s")) and rcd >= 100
    t_izin = 0.4 if p.get("devre", "nihai") == "nihai" else 5.0
    ra_ek = num(p, "zemin_ohm", 0)
    ad = cihaz_adi(p)
    oz, kt, an, ds = [], [], [], []
    sahne: dict = {"kopuk": None, "imd": sistem == "IT"}

    if sistem.startswith("TN"):
        zs = zk + r_l + r_pe + rf
        i_f = U0 / zs
        # gövdenin ana eşpotansiyel baraya göre gerilimi: arıza akımının hat koruma iletkeninde düşürdüğü gerilim
        u_govde = i_f * r_pe
        t_oc = cihaz_sure(p, i_f)
        rcd_gecerli = rcd > 0 and sistem != "TN-C"
        t_rcd = rcd_sure(rcd, i_f * 1000, s_tip) if rcd_gecerli else math.inf
        t = min(t_oc, t_rcd)
        ia = cihaz_ia(p, t_izin)
        yol = ["L", "ariza", "govde", "pen" if sistem == "TN-C" else "pe"] + (["pen"] if sistem == "TN-C-S" else [])
        an += [f"Faz iletkeni gövdeye değdi. {sistem} sisteminde gövde koruma iletkeniyle ({'PEN' if sistem == 'TN-C' else 'PE'}) doğrudan trafonun yıldız noktasına bağlıdır; arıza akımı toprağa değil, bu iletken üzerinden kaynağa döner.",
               f"Çevrim empedansı Zs = Zk + R(faz) + R({'PEN' if sistem == 'TN-C' else 'PE'}) + R(arıza) = {fnum(zk * 1000, 0)} + {fnum(r_l * 1000, 0)} + {fnum(r_pe * 1000, 0)} + {fnum(rf * 1000, 0)} mΩ = {fnum(zs, 3)} Ω.",
               f"Arıza akımı If = U0 / Zs = 230 / {fnum(zs, 3)} = {fnum(i_f, 0)} A.",
               f"Arıza sürerken gövde, ana eşpotansiyel baraya göre If · R(PE) = {fnum(u_govde, 0)} V'a çıkar. Faz ve koruma iletkeni aynı kesitteyse bu yaklaşık U0/2'dir; açma süresi sınırı bu yüzden vardır."]
        if t_oc <= t_rcd:
            an.append(f"{ad} bu akımda en geç {fsure(t_oc)} içinde açar" + (" (manyetik açma)." if t_oc <= 0.02 else " (ısıl bölge: akım manyetik eşiğin altında kaldı)." if not math.isinf(t_oc) else "."))
        if rcd_gecerli and not math.isinf(t_rcd):
            an.append(f"{rcd} mA kaçak akım rölesi de bu akımı fark eder ve en geç {fsure(t_rcd)} içinde açar" + (" — aşırı akım cihazından önce." if t_rcd < t_oc else "."))
        if sistem == "TN-C" and rcd > 0:
            an.append("TN-C'de kaçak akım rölesi çalışmaz: gövde PEN'e bağlı olduğu için arıza akımı yine rölenin içinden geçen PEN iletkeniyle döner, giden ve dönen akım eşit görünür.")
            kt.append(C("TN-C'de artık akım koruma düzeni", "RCD seçildi", "kullanılmamalı", False, f"{KAYNAK_M8}-a3.8"))
        rcd_kurtarir = zs * ia > U0 and rcd_gecerli and t <= t_izin
        kt.append(C("Çevrim empedansı koşulu", f"Zs · Ia = {fnum(zs, 3)} Ω × {fnum(ia, 0)} A = {fnum(zs * ia, 0)} V" + (" — aşırı akım cihazıyla sağlanmıyor; koruma kaçak akım rölesiyle (m.8-a3.6)" if rcd_kurtarir else ""),
                    f"≤ U0 = 230 V  (Ia: {ad}, {fsure(t_izin)} içinde açtıran akım)", None if rcd_kurtarir else zs * ia <= U0 + 1e-9, f"{KAYNAK_M8}-a3.3"))
        kt.append(C("Açma süresi", fsure(t), f"≤ {fsure(t_izin)}", t <= t_izin + 1e-9, f"{KAYNAK_M8}-a3.3, Çizelge-2" + (" ; m.8-a3.5" if t_izin > 1 else "")))
        if zs * ia > U0 and rcd_gecerli and t <= t_izin:
            an.append("Aşırı akım cihazı tek başına koşulu sağlamıyor; korumayı kaçak akım rölesi sağlıyor (m.8-a3.6).")
        ds += ["TN'de arıza akımı bir kısa devredir; korumayı çevrim empedansı belirler. Hat uzadıkça ya da kesit küçüldükçe Zs büyür, akım düşer, otomat geç açar.",
               "Aynı hatta eğriyi B'den C'ye ya da D'ye almak gereken akımı 2–4 kat büyütür: uzun hatlarda koşulu bozan en sık neden budur.",
               "Koşul sağlanmıyorsa çare: kesiti büyütmek, eğriyi/anma akımını küçültmek ya da kaçak akım rölesi eklemek (TN-C hariç)."]
        sahne.update({"yol": yol, "etiket": {"if": f"If = {fnum(i_f, 0)} A", "zs": f"Zs = {fnum(zs, 3)} Ω", "govde": f"gövde ≈ {fnum(u_govde, 0)} V"}})
        oz += [K("Arıza akımı If", f"{fnum(i_f, 0)} A", "info", f"Zs = {fnum(zs, 3)} Ω"), K("Gövde gerilimi", f"{fnum(u_govde, 0)} V", ("warn" if t <= t_izin else "bad") if u_govde > 50 else "ok", "ana eşpotansiyel baraya göre, açana kadar")]
    elif sistem == "TT":
        z = zk + r_l + r_pe + rf + ra + rb
        i_f = U0 / z
        u_govde = i_f * (ra + r_pe)
        u_notr = i_f * rb
        t_oc = cihaz_sure(p, i_f)
        t_rcd = rcd_sure(rcd, i_f * 1000, s_tip) if rcd else math.inf
        t = min(t_oc, t_rcd)
        ia = rcd / 1000.0 if rcd else cihaz_ia(p, 5.0)
        an += ["Faz iletkeni gövdeye değdi. TT sisteminde gövde tüketicinin kendi topraklayıcısına (RA) bağlıdır; arıza akımı toprak üzerinden trafonun işletme topraklamasına (RB) döner.",
               f"Çevrim direnci ≈ RA + RB + iletkenler = {fnum(ra, 1)} + {fnum(rb, 1)} + {fnum(zk + r_l + r_pe + rf, 2)} = {fnum(z, 1)} Ω → If = 230 / {fnum(z, 1)} = {fnum(i_f, 1)} A.",
               f"Bu akım bir kısa devre değil, bir yük akımı kadardır. Gövde referans toprağa göre If · RA = {fnum(u_govde, 0)} V'a çıkar; aynı anda trafo nötrü de If · RB = {fnum(u_notr, 0)} V yükselir."]
        if math.isinf(t):
            an.append(f"{ad} bu akımı arıza olarak görmez (açma eşiğinin altında). Kaçak akım rölesi yoksa gövde gerilimi kalıcıdır.")
        elif t_rcd <= t_oc:
            an.append(f"{rcd} mA kaçak akım rölesi arıza akımını ({fnum(i_f * 1000 / rcd, 0)} × IΔn) fark eder ve en geç {fsure(t_rcd)} içinde açar.")
        else:
            an.append(f"{ad} en geç {fsure(t_oc)} içinde açar.")
        kt.append(C("TT koşulu", f"RA · Ia = {fnum(ra, 1)} Ω × {fnum(ia, 3 if ia < 1 else 1)} A = {fnum(ra * ia, 1)} V", "≤ 50 V  (Ia = IΔn" + ("" if rcd else f" yok → {ad} 5 s akımı") + ")", ra * ia <= 50 + 1e-9, f"{KAYNAK_M8}-a4/ii"))
        if rcd:
            lim = 50.0 / (rcd / 1000.0) / (2 if s_tip else 1)
            kt.append(C("İzin verilen en büyük RA", f"RA = {fnum(ra, 1)} Ω", f"≤ {fnum(lim, 0)} Ω  ({rcd} mA{' S tipi' if s_tip else ''})", ra <= lim + 1e-9, "Topraklamalar Yön. m.10, Çizelge-12"))
        kt.append(C("Gövde gerilimi kalıcı olmamalı", f"{fnum(u_govde, 0)} V, {fsure(t)}", "50 V üstü gerilim açılmalı (S tipinde ≤ 1 s)", (u_govde <= 50) or t <= (1.0 if s_tip else 0.4) + 1e-9, f"{KAYNAK_M8}-a1/i, a4/ii"))
        ds += ["TT'de arıza akımı RA + RB ile sınırlıdır; otomat ya da sigorta bu akımla açmaz. Koruma kaçak akım rölesidir.",
               "RA ne kadar küçük olursa olsun gövde geriliminin büyük kısmı RA üzerinde düşer (RB küçük olduğu için). Güvenliği sağlayan RA'nın küçüklüğü değil, rölenin açmasıdır.",
               "RA · IΔn ≤ 50 V: 30 mA için 1666 Ω, 300 mA için 166 Ω yeter — ama topraklama kuruyabilir, bağlantı gevşeyebilir; düzenli ölçüm bu yüzden şarttır."]
        sahne.update({"yol": ["L", "ariza", "govde", "ra", "toprak", "rb"], "etiket": {"if": f"If = {fnum(i_f, 1)} A", "govde": f"gövde ≈ {fnum(u_govde, 0)} V", "notr": f"nötr ≈ {fnum(u_notr, 0)} V"}})
        oz += [K("Arıza akımı If", f"{fnum(i_f, 1)} A", "info", f"çevrim {fnum(z, 1)} Ω"), K("Gövde gerilimi", f"{fnum(u_govde, 0)} V", ("warn" if t <= 1.0 else "bad") if u_govde > 50 else "ok", "referans toprağa göre" + ("" if math.isinf(t) else ", açana kadar"))]
    else:  # IT — ilk arıza
        c = num(p, "c_uf", 1.0) * 1e-6
        zc = 1 / (1j * 3 * OMEGA * c)
        i_d = U0 / abs(rf + ra + zc)
        u_govde = i_d * ra
        t = math.inf
        an += ["Faz iletkeni gövdeye değdi. IT sisteminde kaynağın topraklı noktası yoktur; akımın dönebileceği tek yol, sağlam iki fazın kablolarının toprağa olan kapasitesidir.",
               f"İlk arıza akımı Id ≈ 3·ω·C·U0 = 3 × 314 × {fnum(c * 1e6, 2)} µF × 230 V = {fnum(3 * OMEGA * c * U0 * 1000, 0)} mA (arıza ve RA dirençleriyle {fnum(i_d * 1000, 0)} mA).",
               f"Gövde gerilimi RA · Id = {fnum(u_govde, 1)} V. Hiçbir cihaz açmaz, tesis çalışmaya devam eder; yalıtım izleme cihazı alarm verir.",
               "Bedeli: arızalı faz toprak potansiyeline çekildiği için sağlam iki faz toprağa göre 230 V'tan 400 V'a çıkar. Yalıtım bu gerilime göre seçilmiş olmalıdır."]
        kt.append(C("IT ilk arıza koşulu", f"RA · Id = {fnum(ra, 1)} Ω × {fnum(i_d, 3)} A = {fnum(u_govde, 1)} V", "≤ 50 V", u_govde <= 50 + 1e-9, f"{KAYNAK_M8}-a5.3"))
        kt.append(C("Yalıtım izleme düzeni", "var (sesli ve ışıklı alarm)", "zorunlu", True, f"{KAYNAK_M8}-a5.4"))
        ds += ["IT'nin amacı süreklilik: ilk arızada enerji kesilmez (ameliyathane, süreç tesisi, maden).",
               "İlk arıza alarmı görmezden gelinirse ikinci arıza faz–faz kısa devresine döner; “ikinci arıza” senaryosuna bakın.",
               "Şebeke büyüdükçe (kablo uzadıkça) kapasite ve ilk arıza akımı artar; büyük IT şebekelerinde RA · Id ≤ 50 V koşulu zorlaşır."]
        sahne.update({"yol": ["L", "ariza", "govde", "ra", "toprak", "cap"], "etiket": {"if": f"Id = {fnum(i_d * 1000, 0)} mA", "govde": f"gövde ≈ {fnum(u_govde, 1)} V", "saglam": "sağlam fazlar toprağa göre 400 V"}})
        oz += [K("İlk arıza akımı Id", f"{fnum(i_d * 1000, 0)} mA", "info", "kapasitif"), K("Gövde gerilimi", f"{fnum(u_govde, 1)} V", "bad" if u_govde > 50 else "ok", "referans toprağa göre")]
        i_f = i_d; t_oc = t_rcd = math.inf

    kisi = _kisi(u_govde, ra_ek, t)
    oz += [K("Açma süresi", fsure(t), "ok" if (not math.isinf(t) and all(k["ok"] is not False for k in kt)) else ("ok" if sistem == "IT" and u_govde <= 50 else "bad"),
             ("RCD" if t_rcd < t_oc else ad) if not math.isinf(t) else ("IT: açma gerekmez" if sistem == "IT" else "hiçbir cihaz açmıyor")),
           K("Gövdeye dokunan kişi", f"{fnum(kisi['ib_ma'], 0)} mA", kisi["durum"], kisi["etki"])]
    an.append(f"Bu sırada gövdeye dokunan kişiden {fnum(kisi['ib_ma'], 0)} mA geçer ({fsure(t)} boyunca): {kisi['etki']}.")
    sahne.update({"kisi": kisi, "cihaz": {"ad": ad, "acti": (not math.isinf(t_oc)) and t_oc <= t_rcd, "t": fsure(t_oc)},
                  "rcd": {"var": rcd > 0, "ad": f"RCD {rcd} mA{' S' if s_tip else ''}", "acti": (not math.isinf(t_rcd)) and t_rcd < t_oc, "t": fsure(t_rcd), "gecersiz": sistem == "TN-C" and rcd > 0}})
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne}


# ---------------- IT ikinci arıza ----------------
def _ikinci_ariza(p: dict, sistem: str) -> dict:
    zk, r_l, r_pe = _hat(p)
    zs = zk + r_l + r_pe
    u_ll = math.sqrt(3) * U0
    i_f = u_ll / (2 * zs)
    t_izin = 0.4 if p.get("devre", "nihai") == "nihai" else 5.0
    rcd = int(num(p, "rcd_ma", 0)); s_tip = bool(p.get("rcd_s")) and rcd >= 100
    t_oc = cihaz_sure(p, i_f); t_rcd = rcd_sure(rcd, i_f * 1000, s_tip) if rcd else math.inf
    t = min(t_oc, t_rcd)
    ia = cihaz_ia(p, t_izin)
    lim = u_ll / (2 * ia)
    u_govde = i_f * r_pe
    kisi = _kisi(u_govde, num(p, "zemin_ohm", 0), t)
    ad = cihaz_adi(p)
    an = ["İlk arıza (L1 – gövde A) giderilmeden ikinci bir cihazda başka bir faz (L2 – gövde B) gövdeye değdi. İki gövde koruma iletkeniyle birbirine bağlı olduğundan iki faz bu iletken üzerinden kısa devre olur.",
          f"Devreyi faz arası gerilim sürer ve akım iki hattın çevriminden geçer: If = √3·U0 / (2·Zs) = 400 / (2 × {fnum(zs, 3)}) = {fnum(i_f, 0)} A.",
          f"{ad} en geç {fsure(t_oc)} içinde açar. İki devreden hangisinin önce açacağı belli değildir; koşul her ikisi için ayrı ayrı sağlanmalıdır.",
          f"Arıza sürerken iki gövde arasında ve gövde–eşpotansiyel bara arasında ≈ {fnum(u_govde, 0)} V vardır; dokunan kişiden {fnum(kisi['ib_ma'], 0)} mA geçer: {kisi['etki']}."]
    kt = [C("IT ikinci arıza koşulu (nötr dağıtılmamış)", f"Zs = {fnum(zs, 3)} Ω", f"≤ √3·U0 / (2·Ia) = 400 / (2 × {fnum(ia, 0)}) = {fnum(lim, 3)} Ω", zs <= lim + 1e-9, f"{KAYNAK_M8}-a5.6"),
          C("Açma süresi", fsure(t), f"≤ {fsure(t_izin)}", t <= t_izin + 1e-9, f"{KAYNAK_M8}-a5.6, Çizelge-3")]
    ds = ["IT'de izin verilen çevrim empedansı TN'dekinin yaklaşık yarısıdır (√3/2 ≈ 0,87 kat gerilim, iki kat çevrim): aynı kablo TN'de uygunken IT'de uygun olmayabilir.",
          "Gövdeler ortak koruma iletkenine değil ayrı topraklayıcılara bağlıysa ikinci arıza TT gibi davranır ve kaçak akım rölesi gerekir (m.8-a5.5/i).",
          "İlk arıza alarmı mümkün olan en kısa sürede giderilmelidir (m.8-a5.4 notu)."]
    sahne = {"kopuk": None, "imd": True, "yol": ["L", "ariza", "govde", "pe", "govde2", "ariza2", "L2"], "kisi": kisi,
             "etiket": {"if": f"If = {fnum(i_f, 0)} A", "govde": f"gövde ≈ {fnum(u_govde, 0)} V", "zs": f"Zs = {fnum(zs, 3)} Ω"},
             "cihaz": {"ad": ad, "acti": not math.isinf(t_oc) and t_oc <= t_rcd, "t": fsure(t_oc)}, "rcd": {"var": rcd > 0, "ad": f"RCD {rcd} mA", "acti": not math.isinf(t_rcd) and t_rcd < t_oc, "t": fsure(t_rcd), "gecersiz": False}}
    oz = [K("İkinci arıza akımı", f"{fnum(i_f, 0)} A", "info", "faz–faz, iki hat üzerinden"), K("Gövde gerilimi", f"{fnum(u_govde, 0)} V", "bad" if u_govde > 50 else "ok", "eşpotansiyel baraya göre"),
          K("Açma süresi", fsure(t), "ok" if t <= t_izin else "bad", ad), K("Gövdeye dokunan kişi", f"{fnum(kisi['ib_ma'], 0)} mA", kisi["durum"], kisi["etki"])]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne}


# ---------------- PEN kopması ----------------
def _pen_kopuk(p: dict, sistem: str) -> dict:
    p_kw = num(p, "p_yuk_kw", 2); r_y = U0 ** 2 / (p_kw * 1000.0)
    ra = num(p, "ra_ohm", 20); rb = num(p, "rb_ohm", 2)
    yerel = bool(p.get("yerel_toprak", True)) and sistem == "TN-C-S"
    ra_ek = num(p, "zemin_ohm", 0)
    rcd = int(num(p, "rcd_ma", 0))
    if yerel:
        i_y = U0 / (r_y + ra + rb)
        u_govde = i_y * ra
    else:
        i_y = 0.0
        u_govde = U0
    # kişi gövdeye dokunuyor: yerel topraklama yoksa akım yük direnci üzerinden kişiye akar
    kisi = _kisi(u_govde, ra_ek, math.inf, seri=0.0 if yerel else r_y)
    an = [f"Dağıtım hattındaki PEN iletkeni koptu (gevşek bağlantı, korozyon, kazı hasarı). Kopuğun tüketici tarafında {fnum(p_kw, 1)} kW'lık yük çalışıyor (direnci {fnum(r_y, 1)} Ω).",
          "Yük akımı faz iletkeninden gelir, yükten geçer ve nötre çıkar; ama nötr artık kaynağa dönemiyor. Nötr ile koruma iletkeni aynı noktadan (PEN) geldiği için bütün gövdeler yük üzerinden faza bağlanmış olur."]
    if yerel:
        an += [f"Bina girişinde PEN temel topraklayıcıya bağlı olduğundan akım kendine toprak üzerinden yol bulur: I = 230 / (R(yük) + RA + RB) = 230 / ({fnum(r_y, 1)} + {fnum(ra, 1)} + {fnum(rb, 1)}) = {fnum(i_y, 1)} A.",
               f"Gövdeler referans toprağa göre I · RA = {fnum(u_govde, 0)} V'a çıkar. Yük ne kadar büyükse (direnci ne kadar küçükse) bu gerilim 230 V'a o kadar yaklaşır.",
               "Bina içinde ana eşpotansiyel dengeleme varsa su borusu, kalorifer, yapı demiri de aynı gerilime çıkar: içeride iki nokta arasında fark oluşmaz. Tehlike binanın dışındadır: bahçe musluğu, dış priz, araç şarj ünitesi."]
    else:
        an += ["Yerel topraklama olmadığından akımın döneceği yol yoktur; gövdeler yük direnci üzerinden doğrudan faz gerilimine (230 V) çıkar. Cihazlar durur, ama gövdeleri gerilimlidir.",
               f"Gövdeye dokunan kişi devreyi kendi üzerinden tamamlar: akımı yük direnci ({fnum(r_y, 1)} Ω) ve kendi vücut empedansı sınırlar."]
    an.append(f"Hiçbir koruma açmaz: akım yük akımından küçüktür, otomat görmez. Kaçak akım rölesi{' (' + str(rcd) + ' mA)' if rcd else ''} de görmez, çünkü faz ve nötr akımları rölenin içinden eşit geçer; kaçak, rölenin kaynak tarafındaki PE–PEN bağlantısından sonra oluşur.")
    an.append(f"Dokunan kişiden {fnum(kisi['ib_ma'], 0)} mA geçer ve kesilmez: {kisi['etki']}.")
    kt = [C("Gövde gerilimi (kalıcı)", f"{fnum(u_govde, 0)} V", "≤ 50 V", u_govde <= 50 + 1e-9, f"{KAYNAK_M8}-a1/i"),
          C("PEN iletkeni en küçük kesiti (sabit tesisat)", "mekanik dayanım için", "≥ 10 mm² Cu / 16 mm² Al", None, "Topraklamalar Yön. m.9-h; TS HD 60364-5-54 m.543.4", "dogrulanacak"),
          C("PEN'in bina girişinde topraklanması", "yapılmış" if yerel else "yapılmamış", "istenir", yerel, f"{KAYNAK_M8}-a3.1 Not 2")]
    ds = ["PEN kopması TN-C ve TN-C-S'nin en tehlikeli arızasıdır: ne otomat ne kaçak akım rölesi görür.",
          "Önlemi tasarımdadır: PEN kesitini büyük tutmak, bina girişinde topraklamak ve ana eşpotansiyel dengelemeyi eksiksiz yapmak; PEN'i ayrımdan sonra bir daha N ile birleştirmemek.",
          "Bina dışındaki noktalarda (bahçe, şantiye, araç şarjı) bu yüzden TT bağlantı ya da PEN kopma algılama düzeni tercih edilir."]
    sahne = {"kopuk": "pen", "imd": False, "yol": ["L", "yuk", "n_tuketici", "pe", "govde"] + (["ra", "toprak", "rb"] if yerel else []), "kisi": kisi,
             "etiket": {"if": f"I = {fnum(i_y, 1)} A" if yerel else "gövde yük üzerinden faza bağlı", "govde": f"gövde ≈ {fnum(u_govde, 0)} V"},
             "cihaz": {"ad": cihaz_adi(p), "acti": False, "t": "açmaz"}, "rcd": {"var": rcd > 0, "ad": f"RCD {rcd} mA", "acti": False, "t": "görmez", "gecersiz": False}}
    oz = [K("Gövde gerilimi", f"{fnum(u_govde, 0)} V", "bad" if u_govde > 50 else "ok", "referans toprağa göre, kalıcı"), K("Toprak üzerinden akım", f"{fnum(i_y, 1)} A", "info", "yerel topraklama üzerinden" if yerel else "yol yok"),
          K("Açma", "hiçbir cihaz açmaz", "bad", "otomat ve RCD görmez"), K("Gövdeye dokunan kişi", f"{fnum(kisi['ib_ma'], 0)} mA", kisi["durum"], kisi["etki"])]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne}


# ---------------- nötr kopması ----------------
def _notr_kopuk(p: dict, sistem: str) -> dict:
    ps = [max(num(p, k, d), 0.01) for k, d in (("p1_kw", 3), ("p2_kw", 0.3), ("p3_kw", 1.5))]
    y = [pk * 1000.0 / U0 ** 2 for pk in ps]
    v = [U0 + 0j, U0 * A120 ** 2, U0 * A120]                       # L1, L2, L3 (kaynak yıldız noktasına göre)
    vn = sum(vi * yi for vi, yi in zip(v, y)) / sum(y)             # yük yıldız noktasının kayması
    ul = [abs(vi - vn) for vi in v]
    an = ["Üç fazlı panonun nötr iletkeni koptu (ya da nötr klemensi yandı). Fazlar yerinde, tek fazlı yükler çalışmaya devam ediyor; ama artık yüklerin ortak noktası kaynağın yıldız noktasına bağlı değil.",
          "Üç yük, fazlar arasına yıldız bağlı üç direnç gibi davranır. Ortak nokta, en büyük yükün (en küçük direncin) fazına doğru kayar.",
          f"Yıldız noktası kayması: U(N′) = Σ(U·Y) / ΣY = {fnum(abs(vn), 0)} V. Yük gerilimleri: L1 {fnum(ul[0], 0)} V, L2 {fnum(ul[1], 0)} V, L3 {fnum(ul[2], 0)} V.",
          "Az yüklü fazdaki cihazlar faz arası gerilime (400 V) yaklaşan bir gerilim görür ve yanar; çok yüklü fazdakiler düşük gerilimde kalır. Hiçbir koruma açmaz, çünkü akımlar anma değerinin altındadır."]
    if sistem == "TN-C-S":
        an.append("TN-C-S'de kopan iletken ayrım noktasından önceki PEN ise aynı anda gövdeler de gerilim altında kalır (“PEN kopması” senaryosu).")
    kt = [C(f"L{k + 1} fazındaki yükün gerilimi", f"{fnum(ul[k], 0)} V", "207 – 253 V (230 V ± %10)", 207 <= ul[k] <= 253, "TS EN 50160; TS 83 (IEC 60038)", "dogrulanacak") for k in range(3)]
    ds = ["Nötr kopması elektrik çarpması değil, aşırı gerilim arızasıdır: en çok zarar az yüklü fazdaki elektronik cihazlarda olur.",
          "Yükler dengeli olsaydı yıldız noktası kaymazdı; dengesizlik ne kadar büyükse aşırı gerilim o kadar büyüktür.",
          "Önlem: nötr bağlantılarının sıkılığı ve kesiti (nötr tek başına anahtarlanmaz ve sigortalanmaz), gerekirse gerilim izleme rölesi."]
    sahne = {"kopuk": "notr", "imd": False, "yol": ["L", "yuk"], "kisi": {"var": False}, "etiket": {"if": f"U(N′) = {fnum(abs(vn), 0)} V"},
             "yukler": [{"faz": f"L{k + 1}", "p_kw": ps[k], "u_v": round(ul[k], 0), "durum": "ok" if 207 <= ul[k] <= 253 else "bad"} for k in range(3)],
             "fazor": {"baslik": "Yük gerilimleri (nötr kopuk)", "vektorler": [fazor("L1", v[0], "#b45309"), fazor("L2", v[1], "#111827"), fazor("L3", v[2], "#6b7280"), fazor("N′ kayması", vn, "#b00020"),
                                                                           fazor(f"U1 {ul[0]:.0f} V", v[0] - vn, "#b45309", True, vn), fazor(f"U2 {ul[1]:.0f} V", v[1] - vn, "#111827", True, vn), fazor(f"U3 {ul[2]:.0f} V", v[2] - vn, "#6b7280", True, vn)]},
             "cihaz": {"ad": "", "acti": False, "t": "açmaz"}, "rcd": {"var": False, "ad": "", "acti": False, "t": "", "gecersiz": False}}
    oz = [K("Yıldız noktası kayması", f"{fnum(abs(vn), 0)} V", "bad" if abs(vn) > 23 else "ok", "kaynak nötrüne göre")] + \
         [K(f"L{k + 1} yük gerilimi", f"{fnum(ul[k], 0)} V", "ok" if 207 <= ul[k] <= 253 else "bad", f"{fnum(ps[k], 1)} kW") for k in range(3)]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne}


# ---------------- faz – toprak (doğrudan) ----------------
def _faz_toprak(p: dict, sistem: str) -> dict:
    rb = num(p, "rb_ohm", 2); re_ = num(p, "re_ohm", 10)
    i_f = U0 / (rb + re_)
    u_n = i_f * rb
    tn = sistem.startswith("TN")
    lim = re_ * 50.0 / (U0 - 50.0)
    kisi = _kisi(u_n if tn else 0.0, num(p, "zemin_ohm", 0), math.inf)
    t_oc = cihaz_sure(p, i_f)
    an = [f"Bir faz iletkeni koptu ve toprağa (ya da topraklanmamış bir metale) değdi; temas direnci RE = {fnum(re_, 1)} Ω. Akım toprak üzerinden trafonun işletme topraklamasına (RB = {fnum(rb, 1)} Ω) döner: If = 230 / (RB + RE) = {fnum(i_f, 1)} A.",
          f"Bu akım RB üzerinde {fnum(u_n, 0)} V düşürür: trafonun yıldız noktası ve ona bağlı nötr bu kadar yükselir. Hat sigortası çoğu zaman açmaz ({fsure(t_oc)})."]
    if tn:
        an += [f"TN sisteminde bütün gövdeler koruma iletkeniyle yıldız noktasına bağlıdır. Bu yüzden arızayla hiç ilgisi olmayan binalardaki bütün gövdeler de referans toprağa göre {fnum(u_n, 0)} V'a çıkar.",
               f"Koşul: gövde gerilimi 50 V'u geçmemeli → RB / RE ≤ 50 / (U0 − 50) → RB ≤ {fnum(lim, 2)} Ω. Şebekenin işletme topraklamasının küçük tutulmasının nedeni budur."]
    else:
        an += [f"TT sisteminde tüketici gövdeleri nötre değil kendi topraklayıcısına bağlıdır; nötr {fnum(u_n, 0)} V yükselse de gövdeler toprak potansiyelinde kalır. TT'nin bu arızaya karşı üstünlüğü budur.",
               "Nötr gerilimi yine de yükselir: sağlam fazların toprağa göre gerilimi artar, yalıtım zorlanır."]
    kt = [C("Gövde / nötr geriliminin sınırlanması", f"RB / RE = {fnum(rb / re_, 3)}", f"≤ 50 / (U0 − 50) = {fnum(50 / 180, 3)}  (RB ≤ {fnum(lim, 2)} Ω)", (rb / re_ <= 50 / 180 + 1e-9) if tn else None, f"{KAYNAK_M8}-a3.7")]
    ds = ["Bu arızada tehlike arızanın olduğu yerde değil, şebekenin tamamındadır (TN): nötr ne kadar yükselirse bütün gövdeler o kadar yükselir.",
          "RB'yi küçültmenin en etkili yolu PEN'i şebeke boyunca birçok noktada topraklamaktır (m.8-a3.1 Not 1).",
          "TT'de gövdeler bu arızadan etkilenmez; bu, kırsal havai hat şebekelerinde TT'nin tercih nedenlerinden biridir."]
    sahne = {"kopuk": None, "imd": False, "yol": ["L", "re", "toprak", "rb"], "kisi": kisi if tn else {"var": True, "ib_ma": 0, "ut_v": 0, "u_kaynak_v": 0, "durum": "ok", "etki": "gövde toprak potansiyelinde", "sinir_ma": 50},
             "etiket": {"if": f"If = {fnum(i_f, 1)} A", "notr": f"nötr ≈ {fnum(u_n, 0)} V", "govde": f"gövde ≈ {fnum(u_n if tn else 0, 0)} V"},
             "cihaz": {"ad": cihaz_adi(p), "acti": not math.isinf(t_oc) and t_oc < 5, "t": fsure(t_oc)}, "rcd": {"var": False, "ad": "", "acti": False, "t": "", "gecersiz": False}}
    oz = [K("Toprak akımı If", f"{fnum(i_f, 1)} A", "info", "RB + RE üzerinden"), K("Nötr gerilimi", f"{fnum(u_n, 0)} V", "bad" if u_n > 50 else "ok", "referans toprağa göre"),
          K("Bütün gövdeler", f"{fnum(u_n if tn else 0, 0)} V", "bad" if (tn and u_n > 50) else "ok", "TN: nötrle birlikte yükselir" if tn else "TT: etkilenmez"),
          K("Gövdeye dokunan kişi", f"{fnum(kisi['ib_ma'], 0)} mA", kisi["durum"] if tn else "ok", kisi["etki"] if tn else "gövde toprak potansiyelinde")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne}
