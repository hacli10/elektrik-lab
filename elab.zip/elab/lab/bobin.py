"""Laboratuvar konusu — bobinli elemanlarda (kontaktör, röle, selenoid valf) kesilme anındaki ters EMK ve söndürme elemanları.

Model: bobin R–L devresidir; I = U/R, L = τ·R, depolanan enerji ½·L·I². Akım kesilince bobin akımı sürdürmek ister: u = −L·di/dt.
Söndürme elemanı akıma bir yol verir ve gerilimi Vc düzeyinde tutar; akımın bırakma değerine inme süresi
t = τ · ln((Vc + I·R) / (Vc + Ib·R))  (Ib: bırakma akımı ≈ 0,3·I). Söndürme yoksa gerilimi bobinin sargı kapasitesi sınırlar:
Upk ≈ I·√(L/Cp) — kilovoltlar. Değerler mertebedir."""
from __future__ import annotations

import math

from . import zaman
from .cizim import Cizim
from .core import C, K, ctl, fnum, num, opt

ID = "bobin"
BASLIK = "Bobin EMK'sı ve söndürme"
IKON = "🌀"
GIRIS = ("Bir kontaktörün bobinini besleyen kontak ya da transistör açıldığında bobin, içindeki enerjiyi boşaltacak yol arar ve uçlarında besleme geriliminin onlarca katı gerilim üretir. "
         "Bu darbe kontağı yakar, PLC çıkışını deler, komşu sinyal kablolarına parazit olarak geçer. Söndürme elemanını seçin; gerilimi ve bırakma gecikmesini görün.")
SOND = {"yok": "Söndürme yok", "diyot": "Ters paralel diyot (d.a.)", "zener": "Diyot + zener (d.a.)", "varistor": "Varistör (a.a. / d.a.)", "rc": "RC eleman (a.a. / d.a.)"}
D = "dogrulanacak"

KONTROLLER = [
    ctl("u", "Bobin gerilimi", "sec", "dc24", secenek=opt(("dc24", "24 V d.a."), ("dc110", "110 V d.a."), ("ac230", "230 V a.a."))),
    ctl("p_w", "Bobinin tutma gücü", "sayi", 6, min=0.5, max=100, adim=0.5, birim="W"),
    ctl("tau_ms", "Bobinin zaman sabiti L/R", "sayi", 30, min=2, max=200, adim=1, birim="ms"),
    ctl("sond", "Söndürme elemanı", "sec", "zener", secenek=opt(*SOND.items())),
    ctl("anahtar", "Bobini anahtarlayan eleman", "sec", "transistor", secenek=opt(("transistor", "PLC / röle transistör çıkışı"), ("kontak", "Röle ya da buton kontağı"))),
    ctl("dayanim_v", "Anahtarın gerilim dayanımı", "sayi", 60, min=30, max=2000, adim=10, birim="V", yardim="24 V transistör çıkışı ≈ 50–60 V; yardımcı röle kontağı 250–400 V"),
]
CP = 300e-12      # sargı + kablo kapasitesi (tahmini)


def run(p: dict) -> dict:
    ub = p.get("u") if p.get("u") in ("dc24", "dc110", "ac230") else "dc24"
    u = {"dc24": 24.0, "dc110": 110.0, "ac230": 230.0}[ub]; ac = ub == "ac230"
    upk = u * math.sqrt(2) if ac else u
    pw = num(p, "p_w", 6); tau = num(p, "tau_ms", 30) / 1000
    r = u * u / pw; i = (upk / r) if not ac else (math.sqrt(2) * pw / u)
    L = tau * r
    e = 0.5 * L * i * i
    s = p.get("sond") if p.get("sond") in SOND else "zener"
    uygun = not ((s in ("diyot", "zener")) and ac)
    ib = 0.3 * i
    if s == "yok" or not uygun:
        vc = min(i * math.sqrt(L / CP), 6000.0); t_b = 0.002
    elif s == "diyot":
        vc = 0.7; t_b = tau * math.log((vc + i * r) / (vc + ib * r))
    elif s == "zener":
        vc = u + 0.7; t_b = tau * math.log((vc + i * r) / (vc + ib * r))
    elif s == "varistor":
        vc = 2.0 * upk; t_b = tau * math.log((vc + i * r) / (vc + ib * r))
    else:
        c_rc = 0.1e-6
        vc = min(i * math.sqrt(L / c_rc) + i * 100, 6000.0); t_b = max(0.003, 0.4 * tau)
    day = num(p, "dayanim_v", 60)
    anh = p.get("anahtar") if p.get("anahtar") in ("transistor", "kontak") else "transistor"
    if ac:
        anh = "kontak"                                    # a.a. bobin kontakla (ya da triyakla) anahtarlanır
    # zaman bölgesi çözümü: söndürme elemanlı durumda kapalı çözüm, RC'de seri RLC, söndürmesizde anahtarın davranışı (çığ ya da yeniden tutuşan ark)
    S = zaman.bobin_sim(upk, r, L, i, s if uygun else "yok", vc, CP, anh, day)
    if s in ("yok", "rc") or not uygun:
        vc = S["u_max"] - upk; t_b = S["t_b"] / 1000
    u_anahtar = upk + vc                                  # anahtarın uçlarındaki gerilim: besleme + bobinin ürettiği
    an = [f"Bobin {fnum(u, 0)} V {'a.a.' if ac else 'd.a.'}, {fnum(pw, 1)} W: direnci {fnum(r, 0)} Ω, akımı {fnum(i * 1000, 0)} mA, endüktansı L = τ·R = {fnum(L, 1)} H. Çekili durumda manyetik alanda {fnum(e * 1000, 1)} mJ enerji depolanmıştır.",
          "Anahtar açıldığında bu enerji bir yere gitmek zorundadır. Bobin, akımı sürdürecek yönde gerilim üretir (u = −L·di/dt): akım ne kadar hızlı kesilirse gerilim o kadar yükselir."]
    if not uygun:
        an.append("Diyot yalnız doğru akımda kullanılır: alternatif akımda her yarım periyotta iletime geçer ve bobini kısa devre eder. Bu bobin için varistör ya da RC eleman gerekir.")
    elif s == "yok":
        an.append(f"Söndürme yok: akımın kapanacağı yol yoktur. Hiçbir şey sınırlamasaydı gerilim sargının kendi kapasitesini ({fnum(CP * 1e12, 0)} pF) dolduracak kadar, I·√(L/Cp) ≈ {fnum(S['serbest'] / 1000, 1)} kV'a yükselirdi. Gerçekte anahtar buna izin vermez.")
        an.append((f"Transistör çıkışı: gerilim transistörün delinme düzeyine (≈ {fnum(S['u_max'], 0)} V) ulaşınca transistör çığ bölgesinde iletime geçer ve bobinin {fnum(e * 1000, 0)} mJ enerjisini kendisi yutar. Küçük bir çıkış transistörünün dayanabildiği enerji birkaç milijuldür: çıkış delinir ya da her açmada biraz daha yıpranır."
                   if anh == "transistor" else
                   f"Kontak: aralık açıldıkça delinme dayanımı artar (≈ 320 V'tan başlayıp milisaniyede ≈ 1,5 kV). Gerilim her seferinde bu dayanıma ulaşır, aralık delinir, ark söner, gerilim yeniden yükselir. Çözümde {S['tut']} yeniden tutuşma var; gerilim {fnum(S['u_max'], 0)} V'a kadar tırmanıyor. "
                   "Her tutuşma kontak malzemesini aşındırır ve geniş bantlı bir parazit darbesi yayar (yağmurlama arkı)."))
    elif s == "diyot":
        an.append(f"Ters paralel diyot akıma bobinin içinden dönen bir yol verir; gerilim 0,7 V'ta tutulur, anahtar yalnız besleme gerilimini görür. Bedeli: akım yavaş söner (τ ile), kontaktör {fnum(t_b * 1000, 0)} ms geç bırakır — söndürmesiz duruma göre 5–10 kat.")
    elif s == "zener":
        an.append(f"Diyotla seri zener, gerilimin {fnum(vc, 0)} V'a çıkmasına izin verir: enerji daha hızlı boşalır, bırakma {fnum(t_b * 1000, 0)} ms'ye iner. Anahtar besleme + zener gerilimini görür.")
    elif s == "varistor":
        an.append(f"Varistör belirli bir gerilimin üstünde iletken olur ve gerilimi ≈ {fnum(vc, 0)} V'ta tutar; a.a. ve d.a.'da çalışır, bırakma gecikmesi küçüktür ({fnum(t_b * 1000, 0)} ms). Her darbede biraz yaşlanır.")
    else:
        an.append(f"RC eleman (0,1 µF + 100 Ω) bobinin enerjisini kondansatöre aktarır ve dirençte söndürür; gerilim ≈ {fnum(vc, 0)} V'a çıkar, salınarak söner. Yükselme hızını düşürdüğü için parazit bastırmada iyidir; a.a.'da sürekli küçük bir kaçak akım geçirir.")
    an.append(f"Anahtarın uçlarındaki gerilim ≈ {fnum(u_anahtar, 0)} V; dayanımı {fnum(day, 0)} V. Kontaktör {fnum(t_b * 1000, 0)} ms sonra bırakır.")
    kt = [C("Söndürme elemanının bobin gerilimine uygunluğu", SOND[s], "d.a. bobin: diyot, diyot+zener, varistör, RC ; a.a. bobin: varistör, RC", uygun and s != "yok", "TS EN 60947-4-1 / -5-1; kontaktör üreticilerinin söndürme modülleri", D),
          C("Anahtarın uçlarındaki gerilim", f"≈ {fnum(u_anahtar, 0)} V", f"≤ dayanım {fnum(day, 0)} V", u_anahtar <= day + 1e-9, "TS EN 61131-2 (PLC çıkışları); cihaz verisi", D),
          *([C("Söndürmesiz açmada anahtarın yükü", (f"transistör {fnum(e * 1000, 0)} mJ enerjiyi çığ bölgesinde yutuyor" if anh == "transistor" else f"kontakta {S['tut']} ark yeniden tutuşması"), "enerji söndürme elemanında harcanmalı; anahtarda değil", False, "TS EN 61131-2 (endüktif yükte çıkış koruması); kontaktör ve röle üreticilerinin uygulama notları", D)] if (s == "yok" or not uygun) else []),
          C("Bırakma gecikmesi", f"{fnum(t_b * 1000, 0)} ms", "güvenlik ve hızlı ters çevirme devrelerinde kısa olmalı (≈ ≤ 50 ms)", t_b <= 0.05, "Uygulama ölçütü; kontaktör üreticisi verisi", "ikincil")]
    ds = ["Her bobinin yanında bir söndürme elemanı olmalıdır. Söndürmesiz bobin, kumanda panosundaki açıklanamayan arızaların (kendiliğinden reset atan PLC, yanlış sayan sayaç, bozulan haberleşme) en sık nedenidir.",
          "Söndürme elemanı bobinin uçlarına, mümkün olduğunca yakına takılır; anahtarın uçlarına değil. Böylece darbe akımı uzun kablolardan dolaşmaz.",
          "Diyot en iyi gerilim sınırlamasını yapar ama kontaktörü geç bıraktırır; ters–düz çalışan, kilitlemeli ve acil durdurma devrelerinde zener ya da varistörlü tip seçilir.",
          "Darbe yalnız bobini anahtarlayan elemanı değil, aynı kablo kanalındaki sinyal kablolarını da etkiler: güç ve kumanda kabloları ayrı tutulur, analog sinyaller ekranlanır.",
          "Aynı olay motor sargılarında, selenoid valflerde, fren bobinlerinde ve d.a. kesici açma bobinlerinde de vardır; enerji büyüdükçe söndürme elemanının gücü de büyür."]
    yan = " — zarf: ark yeniden tutuşmalarının tepe değerleri" if (S["tut"] > 0) else ""
    graf = [{"baslik": "Anahtar açıldıktan sonra anahtarın uçlarındaki gerilim" + yan, "x_ad": "zaman (ms)", "y_ad": "gerilim (V)", "zaman": True, "seriler": [{"ad": "anahtar gerilimi", "renk": "#dc2626", "pts": [[t, round(v, 1)] for t, v in zip(S["t"], S["u"])]}],
             "yatay": [{"y": day, "etiket": f"anahtarın dayanımı {fnum(day, 0)} V", "renk": "#15803d"}]},
            {"baslik": "Bobin akımı", "x_ad": "zaman (ms)", "y_ad": "akım (mA)", "zaman": True, "seriler": [{"ad": "bobin akımı", "renk": "#1a4d8f", "pts": [[t, round(v, 2)] for t, v in zip(S["t"], S["i"])]}], "yatay": [{"y": round(ib * 1000, 1), "etiket": "bırakma akımı", "renk": "#64748b"}]}]
    tablo = {"baslik": "Söndürme elemanları", "cols": ["Eleman", "Bobin", "Gerilim sınırlaması", "Bırakma gecikmesi", "Not"], "rows": [
        ["Ters paralel diyot", "yalnız d.a.", "en iyi (≈ 0,7 V)", "en uzun (5–10 kat)", "kutup yönüne dikkat; ters takılırsa kısa devre"], ["Diyot + zener", "yalnız d.a.", "iyi (zener gerilimi)", "kısa", "hızlı bırakma gereken d.a. devreleri"],
        ["Varistör", "a.a. ve d.a.", "orta (≈ 2 × U)", "kısa", "kutupsuz; darbelerle yaşlanır"], ["RC eleman", "a.a. ve d.a.", "orta; yükselme hızını düşürür", "orta", "parazit bastırmada iyi; a.a.'da kaçak akım"],
        ["Yok", "—", "yok (kilovoltlar)", "en kısa", "kontak aşınması, elektronik hasarı, parazit"]], "not": "Kontaktör ve röle üreticilerinin uygulama notları; TS EN 60947-4-1 — durum: ikincil"}
    c = Cizim(900, 280)
    c.hat("M60,60 H360", "L1").yazi(60, 48, f"+ {fnum(u, 0)} V" if not ac else f"L {fnum(u, 0)} V", "ariza", 12, True).hat("M60,220 H700", "N").yazi(60, 240, "0 V" if not ac else "N", "N", 12, True)
    c.hat("M360,60 L392,42", "cizgi", w=2.6).daire(360, 60, 4, "cizgi", "#fff").daire(400, 60, 4, "cizgi", "#fff").yazi(380, 30, "anahtar AÇILDI", "ariza", 11, True, "middle").yazi(380, 88, f"≈ {fnum(u_anahtar, 0)} V", "ok" if u_anahtar <= day else "ariza", 13, True, "middle")
    if u_anahtar > day:
        c.simsek(372, 44, 0.9)
    c.hat("M400,60 H600 V100").bobin(600, 100, 6, False, "ariza", f"bobin {fnum(L, 1)} H").hat("M600,160 V220")
    if s != "yok" and uygun:
        c.hat("M600,80 H750 V110", "ok", hot=True, hot_renk="uyari").kutu(720, 110, 60, 40, {"diyot": "diyot", "zener": "D + Z", "varistor": "varistör", "rc": "RC"}[s], "", "acti").hat("M750,150 V180 H600", "ok", hot=True, hot_renk="uyari")
        c.yazi(790, 134, "akım burada dolaşır", "uyari", 10.5)
    else:
        c.yazi(690, 134, "akıma yol yok → gerilim yükselir", "ariza", 11, True)
    c.yazi(450, 268, f"depolanan enerji {fnum(e * 1000, 1)} mJ · bırakma gecikmesi {fnum(t_b * 1000, 0)} ms", "#334155", 12, True, "middle")
    oz = [K("Anahtar üzerindeki gerilim", f"{fnum(u_anahtar, 0)} V", "ok" if u_anahtar <= day else "bad", f"dayanım {fnum(day, 0)} V"), K("Bobinin ürettiği gerilim", f"{fnum(vc, 0)} V", "info", SOND[s]),
          K("Bırakma gecikmesi", f"{fnum(t_b * 1000, 0)} ms", "ok" if t_b <= 0.05 else "warn", "akım %30'a inene kadar"), K("Depolanan enerji", f"{fnum(e * 1000, 1)} mJ", "info", f"L = {fnum(L, 1)} H, I = {fnum(i * 1000, 0)} mA")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "grafikler": graf, "tablolar": [tablo]}
