"""Laboratuvar konusu — gerilim trafosu: ölçme ve koruma sınıfları, yük, gerilim faktörü, açık üçgen (3·U0), sekonder devre kuralları.

Dayanak: TS EN 61869-3; TEDAŞ-MLZ/96-011.B; TEDAŞ-MLZ/95-007.E m.2.2 (hücrelerdeki gerilim trafoları: ölçü 0,5 – koruma 3P/6P, 30–60 VA)."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, ctl, fnum, num, opt

ID = "gt"
BASLIK = "Gerilim trafosu"
IKON = "🔋"
GIRIS = ("Gerilim trafosu sayaca ve röleye şebeke gerilimini küçülterek verir. Sınıfı doğruluğunu, gerilim faktörü toprak arızasında ne kadar süre dayanacağını, "
         "açık üçgen sargısı ise toprak arızasının nasıl görüleceğini belirler. Akım trafosunun tersine, sekonderi asla kısa devre edilmez.")
SINIF = {"0.2": ("olcme", 0.2, 10), "0.5": ("olcme", 0.5, 20), "1": ("olcme", 1.0, 40), "3P": ("koruma", 3.0, 120), "6P": ("koruma", 6.0, 240)}
FAKTOR = {"1.5_30": ("1,5 · Un / 30 s", 1.5, 30), "1.9_30": ("1,9 · Un / 30 s", 1.9, 30), "1.9_8h": ("1,9 · Un / 8 saat", 1.9, 8 * 3600)}
GEREK = {"dogrudan": "1.5_30", "direnc": "1.9_30", "yalitilmis": "1.9_8h", "bobin": "1.9_8h"}
NOTR = {"dogrudan": "doğrudan (etkin) topraklı", "direnc": "direnç üzerinden topraklı (arıza otomatik açılır)", "yalitilmis": "yalıtılmış", "bobin": "rezonans topraklı (Petersen)"}
D = "dogrulanacak"

KONTROLLER = [
    ctl("gorev", "Sargının bağlandığı devre", "sec", "olcme", secenek=opt(("olcme", "Ölçme (sayaç, analizör)"), ("koruma", "Koruma (röle)"))),
    ctl("sinif", "Sargının sınıfı", "sec", "0.5", secenek=opt(("0.2", "0,2"), ("0.5", "0,5"), ("1", "1"), ("3P", "3P"), ("6P", "6P"))),
    ctl("sn_va", "Anma gücü", "sec", 30, secenek=opt(*[(v, f"{v} VA") for v in (10, 15, 30, 50, 60, 100)])),
    ctl("yuk_va", "Bağlı yük", "sayi", 12, min=0.5, max=150, adim=0.5, birim="VA"),
    ctl("notr", "Şebekenin yıldız noktası", "sec", "direnc", secenek=opt(*NOTR.items())),
    ctl("faktor", "Gerilim trafosunun anma gerilim faktörü", "sec", "1.9_30", secenek=opt(*[(k, v[0]) for k, v in FAKTOR.items()])),
    ctl("ariza", "Şebekede faz–toprak arızası var", "onay", False),
    ctl("sek_koruma", "Sekonder devre sigorta / otomatla korunmuş", "onay", True),
    ctl("sek_kisa", "Sekonder uçlar kısa devre (yanlış bağlantı, hasarlı kablo)", "onay", False),
    ctl("sek_toprak", "Sekonder devre tek noktadan topraklı", "onay", True),
]


def run(p: dict) -> dict:
    sn_ad = p.get("sinif") if p.get("sinif") in SINIF else "0.5"
    tur, e_oran, e_faz = SINIF[sn_ad]
    gorev = "koruma" if p.get("gorev") == "koruma" else "olcme"
    sn = num(p, "sn_va", 30); yuk = num(p, "yuk_va", 12)
    notr = p.get("notr") if p.get("notr") in NOTR else "direnc"
    fk = p.get("faktor") if p.get("faktor") in FAKTOR else "1.9_30"
    ariza = bool(p.get("ariza"))
    # toprak arızasında sağlam fazların gerilimi ve açık üçgen gerilimi (sekonder 100/3 V sargılar)
    kat = 1.0 if not ariza else (1.0 if notr == "dogrudan" else math.sqrt(3))
    u0_oran = 0.0 if not ariza else (1 / 3 if notr == "dogrudan" else 1.0)          # U0 / E
    u_acik = 3 * (100 / 3) * u0_oran
    g = FAKTOR[GEREK[notr]]; s = FAKTOR[fk]
    fak_ok = s[1] >= g[1] - 1e-9 and s[2] >= g[2]
    an = [f"Sargı sınıfı {sn_ad.replace('.', ',')}, {fnum(sn, 0)} VA; bağlı yük {fnum(yuk, 1)} VA (anma gücünün %{fnum(yuk / sn * 100, 0)}'i). Sınıfın sınırları: oran hatası ± %{fnum(e_oran, 1)}, faz hatası ± {e_faz} dakika."]
    kt = []
    kt.append(C("Bağlı yük", f"{fnum(yuk, 1)} VA = %{fnum(yuk / sn * 100, 0)} Sn", "anma gücünün %25'i ile %100'ü arasında (doğruluk bu aralıkta garanti edilir)", 0.25 * sn - 1e-9 <= yuk <= sn + 1e-9, "TS EN 61869-3 (doğruluk sınıfları)", D))
    if yuk > sn:
        an.append("Yük anma gücünü aşıyor: sargıdaki gerilim düşümü artar, sayaç gerilimi olduğundan küçük ölçer (eksik tüketim kaydı) ve sargı ısınır.")
    if yuk < 0.25 * sn:
        an.append("Yük anma gücünün dörtte birinden küçük: trafo sınıfının doğrulandığı aralığın dışında çalışıyor; sayısal sayaçlarda sık görülür. Daha küçük anma güçlü sargı seçilir ya da yük direnciyle tamamlanır.")
    kt.append(C("Sınıfın göreve uygunluğu", f"sınıf {sn_ad.replace('.', ',')} sargı, {'ölçme' if gorev == 'olcme' else 'koruma'} devresinde", "ölçme: 0,2 – 0,5 (sayaç), 1 (gösterge) ; koruma: 3P, 6P", tur == gorev or (gorev == "koruma" and tur == "olcme"),
                "TEDAŞ-MLZ/95-007.E m.2.2 (ölçü sargısı 0,5; koruma sargısı 3P, 6P; 30–60 VA)", "resmi"))
    if gorev == "olcme" and tur == "koruma":
        an.append("Koruma sınıfı sargı (3P/6P) sayaç için çok kabadır: ± %3–6 oran hatası doğrudan faturaya yansır.")
    an.append(f"Şebekenin yıldız noktası {NOTR[notr]}. " + ("Faz–toprak arızasında sağlam fazların toprağa göre gerilimi faz arası gerilime (√3 kat) çıkar; faz–toprak bağlı gerilim trafosu bu gerilime, arıza temizlenene kadar dayanmalıdır." if notr != "dogrudan"
              else "Faz–toprak arızasında sağlam fazların gerilimi hemen hemen değişmez ve arıza hızla açılır."))
    kt.append(C("Anma gerilim faktörü", s[0], f"bu şebeke için en az {g[0]}", fak_ok, "TS EN 61869-3 (anma gerilim faktörleri ve süreleri)", D))
    if ariza:
        an.append(f"Arıza sürüyor: sağlam fazlardaki gerilim trafoları {fnum(kat, 2)} × anma gerilimi görüyor. Üçüncü sargılar açık üçgen bağlı; uçlarında 3·U0 = {fnum(u_acik, 0)} V oluşur (arızasız durumda 0 V). Toprak arıza rölesi ve yönlü koruma bu gerilimi kullanır.")
        if not fak_ok:
            an.append("Gerilim faktörü bu şebeke için yetersiz: çekirdek doyar, primer akımı büyür ve trafo izin verilen süreden önce aşırı ısınır.")
    kisa = bool(p.get("sek_kisa")); kor = bool(p.get("sek_koruma", True))
    if kisa:
        an.append("Sekonder kısa devre: gerilim trafosu bir gerilim kaynağıdır ve iç empedansı küçüktür; kısa devre akımı anma akımının onlarca katına çıkar. " + ("Sekonder sigortası atar; ölçme ve koruma gerilimsiz kalır (gerilim yokluğu denetimi alarm vermelidir)." if kor else "Koruma yok: sargı saniyeler içinde yanar; OG tarafındaki sigorta bu akımı çoğu zaman görmez."))
    kt.append(C("Sekonder devrenin korunması", "sigorta / otomat var" if kor else "koruma yok", "sekonder devre kısa devreye karşı korunur; sekonder asla kısa devre edilmez", kor and not kisa, "TS EN 61869-3; Elektrik Kuvvetli Akım Tesisleri Yön. (ölçü trafosu sekonder devreleri)", D))
    kt.append(C("Sekonder devrenin topraklanması", "tek noktadan topraklı" if p.get("sek_toprak", True) else "topraklanmamış", "sekonder sargının bir ucu (yıldız noktası ya da bir faz) tek noktadan topraklanır", bool(p.get("sek_toprak", True)),
                "Topraklamalar Yön. Ek-F (işletme elemanlarının topraklanması); TS EN 61869-3", D))
    if not p.get("sek_toprak", True):
        an.append("Sekonder topraklanmamış: primer–sekonder arası yalıtım delinirse ya da kapasitif kuplajla sekonder devre yüksek gerilime çıkar; röle ve sayaç panosunda dokunma tehlikesi doğar.")
    ds = ["Akım trafosunun sekonderi açık bırakılmaz; gerilim trafosunun sekonderi kısa devre edilmez. Biri akım kaynağı, diğeri gerilim kaynağıdır.",
          "Sayaç devresinde hem sınıf (0,2 / 0,5) hem yük aralığı (%25–100 Sn) hem de sekonder kablodaki gerilim düşümü (genellikle ≤ %0,1–0,2) hesaba katılır.",
          "Yalıtılmış ve rezonans topraklı şebekede toprak arızası saatlerce kalabilir: gerilim trafosu 1,9 · Un'e 8 saat dayanacak biçimde seçilir. Doğrudan topraklı şebekede 1,5 · Un / 30 s yeter.",
          "Açık üçgen sargı normalde 0 V verir; toprak arızasında 3·U0 görünür (yalıtılmış şebekede 100 V). Aynı sargıya bağlanan sönümleme direnci ferrorezonansı önler.",
          "Gerilim trafosu sigortası atarsa mesafe ve düşük gerilim korumaları yanlış çalışabilir; bu yüzden röleler gerilim devresini denetler ve bu durumda ilgili işlevleri kilitler."]
    tablo = {"baslik": "Gerilim trafosu doğruluk sınıfları", "cols": ["Sınıf", "Kullanım", "Oran hatası", "Faz hatası", "Geçerli olduğu gerilim aralığı"], "rows": [
        ["0,2", "Faturalamaya esas sayaç (yüksek doğruluk)", "± %0,2", "± 10′", "%80 – %120 Un ; yük %25 – %100 Sn"], ["0,5", "Sayaç", "± %0,5", "± 20′", "%80 – %120 Un ; yük %25 – %100 Sn"],
        ["1", "Gösterge, ölçme", "± %1", "± 40′", "%80 – %120 Un"], ["3P", "Koruma", "± %3", "± 120′", "%5 Un – (gerilim faktörü) × Un"], ["6P", "Koruma (açık üçgen sargı)", "± %6", "± 240′", "%5 Un – (gerilim faktörü) × Un"]],
        "not": "TS EN 61869-3 — durum: dogrulanacak. TEDAŞ-MLZ/95-007.E: ölçü sargısı 30–60 VA, sınıf 0,5; koruma sargısı 30–60 VA, sınıf 3P / 6P; çevirme oranı ör. 34,5:√3 / 0,1:√3 / 0,1:3 kV (resmi)."}
    fak = {"baslik": "Anma gerilim faktörü — şebekeye göre", "cols": ["Şebekenin yıldız noktası", "Faz–toprak bağlı gerilim trafosu", "Neden"], "rows": [
        ["Doğrudan (etkin) topraklı", "1,5 · Un / 30 s (sürekli 1,2)", "sağlam faz gerilimi az yükselir, arıza hemen açılır"], ["Direnç üzerinden topraklı, arıza otomatik açılır", "1,9 · Un / 30 s", "sağlam fazlar faz arası gerilime çıkar, kısa süre"],
        ["Yalıtılmış ya da rezonans topraklı, arıza otomatik açılmaz", "1,9 · Un / 8 saat", "arıza saatlerce kalabilir"], ["Faz–faz bağlı gerilim trafosu (her şebeke)", "1,2 · Un sürekli", "toprak arızasından etkilenmez"]],
        "not": "TS EN 61869-3 — durum: dogrulanacak"}
    c = Cizim(900, 300, zemin=258)
    for k, (yy, col) in enumerate(((50, "L1"), (72, "L2"), (94, "L3"))):
        c.hat(f"M40,{yy} H860", col, w=2.4).yazi(22, yy + 4, f"L{k + 1}", col, 11, True)
        x = 200 + k * 90
        c.hat(f"M{x},{yy} V120").bobin(x, 120, 4, False, "ariza" if (ariza and not fak_ok and k > 0) else "cizgi").hat(f"M{x},160 V258").bobin(x + 26, 122, 4, False, "mavi").bobin(x + 46, 122, 4, False, "mor")
    c.toprak(290, 258).yazi(196, 244, "primer: faz–toprak", "#475569", 10.5, False, "end")
    if ariza:
        c.simsek(700, 50, 1.0).hat("M704,70 V258", "ariza", hot=True).yazi(716, 150, "L1 – toprak arızası", "ariza", 11.5, True).yazi(716, 168, f"L2, L3 toprağa göre {fnum(kat, 2)} × Un", "ariza", 11)
    c.kutu(470, 120, 150, 46, "ölçme sargısı (yıldız)", f"sınıf {sn_ad.replace('.', ',')} · {fnum(yuk, 1)}/{fnum(sn, 0)} VA", "gecersiz" if kisa else "vurgu")
    c.kutu(470, 180, 150, 46, "açık üçgen sargı", f"3·U0 = {fnum(u_acik, 0)} V", "gecersiz" if ariza else "normal")
    c.yazi(450, 288, ("sekonder KISA DEVRE: " + ("sigorta atar" if kor else "sargı yanar")) if kisa else (f"toprak arızası: açık üçgende {fnum(u_acik, 0)} V" if ariza else "arızasız: açık üçgende 0 V"), "ariza" if (kisa or ariza) else "ok", 12, True, "middle")
    oz = [K("Yük / anma gücü", f"%{fnum(yuk / sn * 100, 0)}", "ok" if 0.25 * sn <= yuk <= sn else "bad", f"{fnum(yuk, 1)} / {fnum(sn, 0)} VA"), K("Sınıf sınırı", f"± %{fnum(e_oran, 1)} · ± {e_faz}′", "info", f"sınıf {sn_ad.replace('.', ',')}"),
          K("Gerilim faktörü", s[0], "ok" if fak_ok else "bad", f"gereken {g[0]}"), K("Açık üçgen gerilimi", f"{fnum(u_acik, 0)} V", "warn" if ariza else "ok", "3·U0"),
          K("Sağlam faz gerilimi", f"{fnum(kat, 2)} × Un", "warn" if kat > 1.2 else "ok", "toprağa göre")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "tablolar": [tablo, fak]}
