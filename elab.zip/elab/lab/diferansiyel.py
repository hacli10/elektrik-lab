"""Laboratuvar konusu — trafo diferansiyel koruması (87T): iki taraftaki akım trafoları, polarite, bağlantı grubu ve oran eşleştirmesi,
sıfır bileşen süzmesi, eğimli (tutuculu) karakteristik, demeraj (2. harmonik) blokajı.

Röle her faz için iki büyüklük hesaplar (trafo anma akımının katı, pu):
  fark akımı   Id = | I1 − I2′ |        (I1: OG tarafı; I2′: AG tarafı, bağlantı grubuna göre döndürülmüş ve orana göre eşleştirilmiş)
  tutucu akım  Ib = ( |I1| + |I2′| ) / 2
  açma:  Id > max( Id> , eğim1·Ib )  (kırılma noktasına kadar) ;  ötesinde  eğim1·Ibk + eğim2·(Ib − Ibk)
Bağlantı grubu (içinden geçen akım için OG hat akımları, AG faz akımlarından):
  Dyn11:  IA = (ia − ic)/√3      Dyn1:  IA = (ia − ib)/√3      Dyn5:  IA = (ic − ia)/√3      Yyn0:  IA = ia − i0
Röle aynı dönüşümü AG akımlarına uygular; yanlış grup, ters polarite, eksik oran eşleştirmesi ya da süzülmeyen sıfır bileşen sahte fark akımıdır.
Resmi: Elektrik Tesisleri Kabul Yön. m.28-D-6c (primer enjeksiyonla oran ve polarite; yük ölçümü; diferansiyel korumada akım trafosu – röle bağlantısı),
TEDAŞ-MLZ/96-027.D Çizelge 6 (2. harmonik demeraj blokajı fonksiyonu). Karakteristik ve ayar değerleri: TS EN 60255-187-1, röle üreticisi belgeleri (dogrulanacak / ikincil)."""
from __future__ import annotations

import cmath
import math

from .cizim import Cizim
from .core import A120, C, K, ctl, fazor, fnum, num, opt

ID = "diferansiyel"
BASLIK = "Diferansiyel koruma (87T)"
IKON = "⚖"
GIRIS = ("Diferansiyel röle trafoya giren ve çıkan akımı karşılaştırır: fark varsa arıza içeridedir. İlke basittir; zor olan, iki taraftaki akımları karşılaştırılabilir hale getirmektir. "
         "Bağlantı grubunu, akım trafosu oranlarını ve polaritelerini değiştirin; yükte, dış arızada, iç arızada ve enerjilendirmede rölenin ne gördüğünü izleyin.")
S3 = math.sqrt(3)
GRUP = {"Dyn11": "Dyn11 (AG, OG'den 30° ileride)", "Dyn5": "Dyn5 (AG 150° geride)", "Dyn1": "Dyn1 (AG 30° geride)", "Yyn0": "Yyn0 (faz kayması yok; OG yıldız noktası yalıtılmış)"}
DURUM = {"yuk": "Normal yük", "dis3": "Dış arıza — AG tarafında üç fazlı kısa devre", "dis1": "Dış arıza — AG tarafında faz–toprak", "ic": "İç arıza (koruma bölgesinin içinde)", "inrush": "Enerjilendirme (mıknatıslanma darbe akımı)"}
KABUL = "Elektrik Tesisleri Kabul Yön. m.28-D-6c (primer enjeksiyon deneyi: oran, polarite, sekonder bağlantılar)"
D, IK = "dogrulanacak", "ikincil"

KONTROLLER = [
    ctl("durum", "İşletme durumu", "sec", "yuk", secenek=opt(*DURUM.items())),
    ctl("grup", "Trafonun bağlantı grubu", "sec", "Dyn11", secenek=opt(*GRUP.items())),
    ctl("sn_mva", "Trafo gücü", "sec", 10.0, secenek=opt((1.6, "1,6 MVA"), (2.5, "2,5 MVA"), (5.0, "5 MVA"), (10.0, "10 MVA"), (25.0, "25 MVA"))),
    ctl("u2_kv", "AG tarafı gerilimi (OG tarafı 34,5 kV)", "sec", 6.3, secenek=opt((0.4, "0,4 kV"), (6.3, "6,3 kV"), (10.5, "10,5 kV"))),
    ctl("ct1", "OG tarafı akım trafosu (… / 1 A)", "sec", 200, secenek=opt(*[(v, f"{v} / 1 A") for v in (50, 75, 100, 150, 200, 300, 400, 600)])),
    ctl("ct2", "AG tarafı akım trafosu (… / 1 A)", "sec", 1000, secenek=opt(*[(v, f"{v} / 1 A") for v in (250, 400, 600, 800, 1000, 1250, 1500, 2000, 2500, 4000)])),
    ctl("p1", "OG tarafı akım trafosunun polaritesi ters", "onay", False),
    ctl("p2", "AG tarafı akım trafosunun polaritesi ters", "onay", False),
    ctl("r_grup", "Rölede ayarlı bağlantı grubu", "sec", "Dyn11", secenek=opt(*[(k, k) for k in GRUP])),
    ctl("r_oran", "Rölede oran eşleştirmesi yapılmış (trafo anma akımlarına göre)", "onay", True),
    ctl("r_i0", "Sıfır bileşen süzmesi etkin", "onay", True, goster={"r_grup": ["Yyn0"]}),
    ctl("yuk_pct", "Yük", "sayi", 80, min=10, max=120, adim=5, birim="%", goster={"durum": ["yuk"]}),
    ctl("kademe", "Kademe değiştirici konumu", "sayi", 0, min=-10, max=10, adim=1.25, birim="%", yardim="röle anma kademesine göre eşleştirilir; diğer kademelerde küçük bir fark akımı kalır"),
    ctl("uk_pct", "Kısa devre gerilimi uk", "sayi", 6, min=4, max=12, adim=0.5, birim="%", goster={"durum": ["dis3", "dis1"]}),
    ctl("doyma", "Dış arızada AG tarafı akım trafosunun doyması (kaybolan akım)", "sayi", 0, min=0, max=70, adim=5, birim="%", goster={"durum": ["dis3", "dis1"]}),
    ctl("ic_pu", "İç arıza akımı (trafo anma akımının katı)", "sayi", 3, min=0.05, max=15, adim=0.05, goster={"durum": ["ic"]}),
    ctl("id_min", "Başlatma değeri Id>", "sayi", 0.3, min=0.1, max=1.0, adim=0.05, birim="pu"),
    ctl("egim1", "1. eğim", "sayi", 30, min=10, max=60, adim=5, birim="%"),
    ctl("kirilma", "Kırılma noktası (tutucu akım)", "sayi", 2.5, min=1, max=6, adim=0.5, birim="pu"),
    ctl("egim2", "2. eğim", "sayi", 70, min=40, max=100, adim=5, birim="%"),
    ctl("id_yuksek", "Yüksek ayarlı kademe Id>> (blokajsız)", "sayi", 8, min=4, max=20, adim=0.5, birim="pu"),
    ctl("h2_blok", "2. harmonik (demeraj) blokajı etkin", "onay", True),
    ctl("h2_ayar", "2. harmonik blokaj eşiği", "sayi", 15, min=5, max=40, adim=1, birim="%", goster={"h2_blok": [True]}),
    ctl("capraz", "Çapraz blokaj (bir fazdaki harmonik üç fazı da tutar)", "onay", True, goster={"h2_blok": [True]}),
]


def og_akimlari(grup: str, ia: complex, ib: complex, ic: complex) -> tuple[complex, complex, complex]:
    """AG faz akımlarından (pu) trafonun OG hat akımları (pu) — yalnız içinden geçen akım için."""
    if grup == "Dyn11":
        return (ia - ic) / S3, (ib - ia) / S3, (ic - ib) / S3
    if grup == "Dyn1":
        return (ia - ib) / S3, (ib - ic) / S3, (ic - ia) / S3
    if grup == "Dyn5":
        return (ic - ia) / S3, (ia - ib) / S3, (ib - ic) / S3
    i0 = (ia + ib + ic) / 3
    return ia - i0, ib - i0, ic - i0


def kompanze(r_grup: str, i0_suz: bool, ia: complex, ib: complex, ic: complex) -> tuple[complex, complex, complex]:
    """Rölenin AG tarafı akımlarına uyguladığı bağlantı grubu dönüşümü (üçgen–yıldız gruplarında sıfır bileşen kendiliğinden düşer)."""
    if r_grup in ("Dyn11", "Dyn1", "Dyn5"):
        return og_akimlari(r_grup, ia, ib, ic)
    if i0_suz:
        i0 = (ia + ib + ic) / 3
        return ia - i0, ib - i0, ic - i0
    return ia, ib, ic


def esik(ib: float, id_min: float, e1: float, kn: float, e2: float) -> float:
    return max(id_min, e1 * ib) if ib <= kn else max(id_min, e1 * kn + e2 * (ib - kn))


def hesap(p: dict) -> dict:
    grup = p.get("grup") if p.get("grup") in GRUP else "Dyn11"
    rg = p.get("r_grup") if p.get("r_grup") in GRUP else "Dyn11"
    dur = p.get("durum") if p.get("durum") in DURUM else "yuk"
    sn = num(p, "sn_mva", 10.0) * 1e6; u1 = 34500.0; u2 = num(p, "u2_kv", 6.3) * 1000
    i1n, i2n = sn / (S3 * u1), sn / (S3 * u2)
    ct1, ct2 = num(p, "ct1", 200), num(p, "ct2", 1000)
    a = A120
    ag = [0j, 0j, 0j]; og = [0j, 0j, 0j]; h2 = [0.0, 0.0, 0.0]
    if dur == "yuk":
        L = num(p, "yuk_pct", 80) / 100
        ia = cmath.rect(L, -math.acos(0.9)); ag = [ia, ia * a ** 2, ia * a]
    elif dur == "dis3":
        ia = cmath.rect(100 / num(p, "uk_pct", 6), -math.radians(80)); ag = [ia, ia * a ** 2, ia * a]
    elif dur == "dis1":
        ag = [cmath.rect(100 / num(p, "uk_pct", 6) * (0.3 if grup == "Yyn0" else 1.0), -math.radians(80)), 0j, 0j]
    if dur in ("yuk", "dis3", "dis1"):
        og = [x / (1 + num(p, "kademe", 0) / 100) for x in og_akimlari(grup, *ag)]
    elif dur == "ic":
        ia = cmath.rect(num(p, "ic_pu", 3), -math.radians(80)); og = [ia, ia * a ** 2, ia * a]
    else:                                                   # enerjilendirme: akım yalnız beslenen taraftan; temel bileşenler ve 2. harmonik oranları (tipik)
        og = [cmath.rect(4.0, -math.radians(90)), cmath.rect(2.4, math.radians(70)), cmath.rect(2.9, math.radians(150))]
        h2 = [0.45, 0.12, 0.60]
    doy = num(p, "doyma", 0) / 100 if dur in ("dis3", "dis1") else 0.0
    ag_olc = [x * (1 - doy) for x in ag]
    # röleye giren büyüklükler (röle anma akımının katı)
    k1 = (i1n / ct1) if not p.get("r_oran") else 1.0
    k2 = (i2n / ct2) if not p.get("r_oran") else 1.0
    s1 = -1.0 if p.get("p1") else 1.0
    s2 = -1.0 if p.get("p2") else 1.0
    I1 = [s1 * k1 * x for x in og]
    if rg == "Yyn0" and p.get("r_i0"):
        i0 = sum(I1) / 3; I1 = [x - i0 for x in I1]
    I2 = [s2 * k2 * x for x in kompanze(rg, bool(p.get("r_i0")), *ag_olc)]
    idf = [abs(x - y) for x, y in zip(I1, I2)]
    ibs = [(abs(x) + abs(y)) / 2 for x, y in zip(I1, I2)]
    par = (num(p, "id_min", 0.3), num(p, "egim1", 30) / 100, num(p, "kirilma", 2.5), num(p, "egim2", 70) / 100)
    thr = [esik(b, *par) for b in ibs]
    ustunde = [d > t + 1e-9 for d, t in zip(idf, thr)]
    blok = [False] * 3
    if p.get("h2_blok"):
        tek = [h >= num(p, "h2_ayar", 15) / 100 for h in h2]
        blok = [any(tek)] * 3 if p.get("capraz") else tek
    yuksek = [d > num(p, "id_yuksek", 8) for d in idf]
    acma = [(u and not b) or y for u, b, y in zip(ustunde, blok, yuksek)]
    return {"grup": grup, "rg": rg, "dur": dur, "i1n": i1n, "i2n": i2n, "ct1": ct1, "ct2": ct2, "og": og, "ag": ag, "I1": I1, "I2": I2, "id": idf, "ib": ibs, "thr": thr, "ustunde": ustunde, "blok": blok,
            "acma": acma, "acar": any(acma), "h2": h2, "par": par, "doy": doy}


def run(p: dict) -> dict:
    H = hesap(p)
    dur, grup, rg = H["dur"], H["grup"], H["rg"]
    beklenen = dur == "ic"
    acar = H["acar"]
    j = max(range(3), key=lambda k: (H["acma"][k], round(H["id"][k], 4), H["ib"][k]))      # gösterilecek faz: açan / fark akımı en büyük / akımı en büyük
    p1, p2 = bool(p.get("p1")), bool(p.get("p2"))
    kt, an = [], []
    an.append(f"Trafo {fnum(num(p, 'sn_mva', 10.0), 1)} MVA, 34,5 / {fnum(num(p, 'u2_kv', 6.3), 1)} kV, {grup}: anma akımları OG {fnum(H['i1n'], 0)} A, AG {fnum(H['i2n'], 0)} A. Akım trafoları {fnum(H['ct1'], 0)}/1 ve {fnum(H['ct2'], 0)}/1: "
              f"anma yükünde röleye OG tarafından {fnum(H['i1n'] / H['ct1'], 3)} A, AG tarafından {fnum(H['i2n'] / H['ct2'], 3)} A gelir. İki değer birbirine eşit değildir; röle her tarafı kendi anma akımına bölerek (oran eşleştirmesi) ikisini de “1 pu” yapar.")
    if grup != "Yyn0":
        an.append(f"{grup} trafoda AG akımları OG akımlarına göre {30 * int(grup[3:])}° döner (saat {grup[3:]}). Üçgen sargı nedeniyle OG hat akımı iki AG faz akımının farkıdır: sıfır bileşen (toprak akımı) üçgenin içinde dolaşır, OG hattına çıkmaz. "
                  "Röle, AG akımlarına aynı dönüşümü sayısal olarak uygular; böylece içinden geçen akım için iki taraf fazca ve genlikçe çakışır.")
    else:
        an.append("Yyn0 trafoda faz kayması yoktur. Ama AG yıldız noktası topraklıdır: AG tarafındaki bir toprak arızasında AG akımlarında sıfır bileşen vardır, OG tarafında (yıldız noktası yalıtılmış) yoktur. Röle sıfır bileşeni iki taraftan da süzmezse bu fark, fark akımı olarak görünür.")
    an.append({"yuk": "Normal yükte trafoya giren akım çıkan akıma eşittir: fark akımı sıfıra yakın, tutucu akım yük kadardır. Devreye almada ilk bakılan budur — yük altında fark akımı okunur.",
               "dis3": "Dış arızada büyük bir akım trafonun içinden geçer; fark yine sıfır olmalıdır. Tutucu akım büyüktür: eğimli karakteristik, akım trafolarının büyük akımdaki hatalarından ve doymasından doğan sahte fark akımına pay bırakır.",
               "dis1": "AG tarafındaki faz–toprak arızasında AG'de tek fazda akım vardır; OG tarafında bu akım iki faza bölünmüş olarak görünür (üçgen sargı). Bağlantı grubu dönüşümü ve sıfır bileşenin süzülmesi doğruysa fark yine sıfırdır.",
               "ic": "İç arızada akım trafoya girer ama öbür taraftan çıkmaz (ya da iki taraftan birden içeri akar): fark akımı arıza akımının kendisidir, tutucu akım yarısıdır. Çalışma noktası karakteristiğin üstüne çıkar.",
               "inrush": "Enerjilendirmede çekirdek doyar ve trafo, beslendiği taraftan anma akımının birkaç katı akım çeker; öbür tarafta akım yoktur. Röle için bu, iç arızayla aynı görüntüdür. Ayırt eden, dalga biçimidir: mıknatıslanma akımı büyük bir 2. harmonik bileşeni taşır, kısa devre akımı taşımaz."}[dur])
    an.append(f"Röledeki değerler (en kritik faz L{j + 1}): fark akımı Id = {fnum(H['id'][j], 2)} pu, tutucu akım Ib = {fnum(H['ib'][j], 2)} pu, bu tutucu akımdaki açma eşiği {fnum(H['thr'][j], 2)} pu → "
              + ("açma" if H["acma"][j] else ("eşiğin üstünde ama 2. harmonik blokajı tutuyor" if H["ustunde"][j] else "açma yok")) + ".")
    if p1 != p2:
        an.append(f"{'OG' if p1 else 'AG'} tarafındaki akım trafosunun polaritesi ters: röle o taraftaki akımı 180° dönmüş görür. İçinden geçen akımda iki taraf birbirini götüreceği yerde toplanır: fark akımı yük akımının iki katı olur. "
                  "Trafo yüklendikçe ya da ilk dış arızada koruma açar.")
    elif p1 and p2:
        an.append("İki taraftaki akım trafosunun polaritesi de ters: iki hata birbirini götürür, diferansiyel koruma doğru çalışır. Ama aynı akım devrelerinden beslenen yönlü koruma, güç ve enerji ölçümü ters çalışır.")
    if rg != grup:
        an.append(f"Rölede {rg} ayarlı, trafo {grup}: röle AG akımlarını yanlış açıyla döndürüyor. İki taraf arasında kalan açı farkı kadar sahte fark akımı oluşur (30° için yük akımının ≈ %52'si, 60° için %100'ü, 180° için %200'ü).")
    if not p.get("r_oran"):
        an.append(f"Oran eşleştirmesi yapılmamış: röle iki taraftan gelen sekonder akımları olduğu gibi karşılaştırıyor ({fnum(H['i1n'] / H['ct1'], 3)} A ve {fnum(H['i2n'] / H['ct2'], 3)} A). Fark, yükle orantılı bir fark akımıdır.")
    if H["doy"] > 0:
        an.append(f"AG tarafındaki akım trafosu dış arızada doyuyor ve akımın %{fnum(H['doy'] * 100, 0)}'ini aktaramıyor: eksik kalan akım fark akımıdır. Bu yüzden iki taraftaki akım trafoları aynı sınıfta ve yeterli doyma payıyla seçilir; 2. eğim bu durum içindir.")
    # kontroller
    kt.append(C("Kararlılık" if not beklenen else "İç arızada açma", f"L{j + 1}: Id = {fnum(H['id'][j], 2)} pu ; Ib = {fnum(H['ib'][j], 2)} pu ; eşik {fnum(H['thr'][j], 2)} pu → {'açıyor' if acar else 'açmıyor'}",
                "iç arızada açmalı" if beklenen else "yükte, dış arızada ve enerjilendirmede açmamalı", acar == beklenen, "Diferansiyel korumanın çalışma ilkesi; TS EN 60255-187-1 (trafo diferansiyel koruması)", D))
    kt.append(C("Bağlantı grubu ayarı", f"rölede {rg} ; trafo {grup}", "rölede ayarlı grup, trafonun etiketindeki grupla aynı olmalı", rg == grup, "TS EN 60076-1 (bağlantı grubu işareti); röle üreticisi belgeleri", D))
    kt.append(C("Akım trafosu polariteleri", ("OG ters" if p1 else "OG doğru") + " · " + ("AG ters" if p2 else "AG doğru"), "iki tarafta da P1 baraya (trafonun dışına) bakar; S1'ler rölenin polarite uçlarına gider. Primer enjeksiyonla doğrulanır", not (p1 or p2), KABUL, "resmi"))
    kt.append(C("Oran eşleştirmesi", "yapılmış" if p.get("r_oran") else "yapılmamış", f"her taraf kendi anma akımına göre eşleştirilir: OG {fnum(H['i1n'] / H['ct1'], 3)} A → 1 pu ; AG {fnum(H['i2n'] / H['ct2'], 3)} A → 1 pu", bool(p.get("r_oran")), "Röle üreticisi belgeleri; TS EN 60255-187-1", D))
    kt.append(C("Akım trafosu anma akımları", f"OG {fnum(H['ct1'], 0)} A (trafo {fnum(H['i1n'], 0)} A) ; AG {fnum(H['ct2'], 0)} A (trafo {fnum(H['i2n'], 0)} A)", "trafo anma akımından küçük olmamalı; en çok ≈ 4 katı (eşleştirme aralığı ve duyarlılık)",
                H["i1n"] <= H["ct1"] <= 4 * H["i1n"] and H["i2n"] <= H["ct2"] <= 4 * H["i2n"], "Röle üreticisi belgeleri (eşleştirme katsayısı aralığı)", IK))
    if rg == "Yyn0":
        kt.append(C("Sıfır bileşen süzmesi", "etkin" if p.get("r_i0") else "kapalı", "yıldız noktası topraklı sargı tarafında sıfır bileşen süzülür (üçgen–yıldız ayarında dönüşümün içindedir)", bool(p.get("r_i0")), "Röle üreticisi belgeleri; TS EN 60255-187-1", D))
    kt.append(C("Demeraj (2. harmonik) blokajı", (f"etkin, eşik %{fnum(num(p, 'h2_ayar', 15), 0)}" + (", çapraz blokajlı" if p.get("capraz") else ", faz bazında")) if p.get("h2_blok") else "kapalı", "etkin; eşik ≈ %15 – 20 (çok düşük eşik iç arızada geciktirir, çok yüksek eşik enerjilendirmede açtırır)",
                bool(p.get("h2_blok")) and 10 <= num(p, "h2_ayar", 15) <= 20, "TEDAŞ-MLZ/96-027.D Çizelge 6 (HBL2: demeraj blokajı, 2. harmonik tutucu); eşik: röle üreticisi belgeleri", "resmi"))
    kt.append(C("Kademe değiştirici ve akım trafosu hatası için pay", f"1. eğim %{fnum(H['par'][1] * 100, 0)} ; kademe konumu %{fnum(num(p, 'kademe', 0), 2)}", "1. eğim ≥ kademe aralığı + akım trafosu hataları (≈ %10) + pay", H["par"][1] * 100 >= abs(num(p, "kademe", 0)) + 10, "Röle üreticisi uygulama kılavuzları", IK))
    kt.append(C("Devreye almada kararlılık deneyi", "yük altında fark akımı okunur; primer enjeksiyonla oran ve polarite", "fark akımı ≈ 0, tutucu akım ≈ yük; bir tarafın akımı ters çevrildiğinde fark akımı iki katına çıkmalı", None, KABUL, "resmi"))
    ds = ["Diferansiyel koruma yalnız kendi bölgesindeki (iki akım trafosu arasındaki) arızayı görür; bu yüzden gecikmesiz açabilir. Bölgenin dışındaki arızada, ne kadar büyük olursa olsun, sessiz kalmalıdır.",
          "Sahte fark akımının beş kaynağı vardır: ters polarite, yanlış bağlantı grubu, eksik oran eşleştirmesi, süzülmeyen sıfır bileşen ve akım trafosu doyması. İlk dördü bağlantı ve ayar hatasıdır, yükte fark akımı okunarak bulunur.",
          "İki taraftaki polarite kuralı aynıdır: P1 her iki tarafta da baraya, yani korunan trafonun dışına bakar. Böylece içinden geçen akım bir tarafta P1'den girer, öbür tarafta P1'den çıkar ve röle farkı alır.",
          "Polarite, akım trafosu gövdesindeki işaretle değil ölçümle doğrulanır: pil ve analog ölçü aletiyle (ibre sıçraması) ya da primer enjeksiyonla. Sonra trafo yüklenir ve fark akımına bakılır.",
          "Enerjilendirme akımı iç arızaya benzer; onu 2. harmonik ayırır. Üç fazdan birinde 2. harmonik düşük kalabilir: çapraz blokaj, bir fazdaki harmoniğin üç fazı birden tutmasını sağlar. Yüksek ayarlı kademe ise hiçbir blokaja bakmadan açar.",
          "Diferansiyel koruma trafonun bütün arızalarını görmez: sarımlar arası küçük kısa devreler ve yağ / çekirdek arızaları için Buchholz, basınç ve sıcaklık korumaları; AG tarafı toprak arızaları için kısıtlı toprak koruması (REF) kullanılır."]
    # şema
    c = Cizim(900, 330, zemin=None)
    ya = 110
    c.alan("M150,60 H750 V160 H150 Z", "ok" if not acar or beklenen else "ariza", 0.06, "ok").yazi(450, 52, "koruma bölgesi (iki akım trafosu arası)", "ok", 10.5, True, "middle")
    c.hat(f"M40,{ya} H380", "L1", w=4, hot=dur != "inrush" or True).hat(f"M520,{ya} H860", "L2", w=4, hot=dur in ("yuk", "dis3", "dis1"))
    c.hat("M40,70 V150", "cizgi", w=5).yazi(40, 62, "34,5 kV", "#334155", 10.5, True, "middle").hat("M860,70 V150", "cizgi", w=5).yazi(860, 62, f"{fnum(num(p, 'u2_kv', 6.3), 1)} kV", "#334155", 10.5, True, "middle")
    c.kutu(380, 76, 140, 68, "TRAFO", f"{grup} · {fnum(num(p, 'sn_mva', 10.0), 1)} MVA", "gecersiz" if dur == "ic" else "normal")
    for x, ters, ad, ct in ((180, p1, "OG AT", H["ct1"]), (720, p2, "AG AT", H["ct2"])):
        c.toroid(x, ya, 9, 22, "ariza" if ters else "#1e293b").yazi(160 if x < 450 else 740, ya - 32, f"{ad} {fnum(ct, 0)}/1", "ariza" if ters else "#334155", 10.5, True, "start" if x < 450 else "end")
        if ters:
            c.yazi(x + (14 if x < 450 else -14), ya + 44, "polarite TERS", "ariza", 10.5, True, "start" if x < 450 else "end")
        px = x - 22 if x < 450 else x + 22                   # P1 baraya (dışa) bakar
        c.daire(px, ya - 12, 3.5, "ariza" if ters else "#111827", "#dc2626" if ters else "#111827").yazi(px, ya + 26, "P1", "#475569", 9.5, False, "middle")
        c.hat(f"M{x},{ya + 22} V230 H{'400' if x < 450 else '500'}", "mavi", hot=True, hot_renk="ariza" if ters else "mavi", w=1.8)
    if dur in ("yuk", "dis3", "dis1"):
        c.ok(90, ya - 14, 140, ya - 14, "ariza").ok(600, ya - 14, 650, ya - 14, "ariza")
    else:
        c.ok(90, ya - 14, 140, ya - 14, "ariza")
    if dur in ("dis3", "dis1"):
        c.simsek(800, ya - 6, 1.1).yazi(798, ya + 44, "dış arıza", "ariza", 11, True, "end")
        if dur == "dis1":
            c.hat(f"M808,{ya + 14} V300", "ariza", hot=True).toprak(808, 300)
    elif dur == "ic":
        c.simsek(444, ya - 44, 1.2)
    elif dur == "inrush":
        c.hat(f"M560,{ya} L584,{ya - 16}", "cizgi", w=2.6).yazi(600, ya + 24, "AG kesicisi açık", "#475569", 10.5, False, "middle").yazi(280, ya + 24, "enerjilendirme akımı", "ariza", 10.5, True, "middle")
    c.kutu(400, 204, 100, 62, "87T", f"Id {fnum(H['id'][j], 2)} · Ib {fnum(H['ib'][j], 2)} pu", ("acti" if acar else "normal") if acar == beklenen else "gecersiz")
    c.yazi(290, 222, f"I1 = {fnum(abs(H['I1'][j]), 2)} pu ∠{fnum(math.degrees(cmath.phase(H['I1'][j])) if abs(H['I1'][j]) > 1e-9 else 0, 0)}°", "mavi", 10.5, False, "middle").yazi(610, 222, f"I2′ = {fnum(abs(H['I2'][j]), 2)} pu ∠{fnum(math.degrees(cmath.phase(H['I2'][j])) if abs(H['I2'][j]) > 1e-9 else 0, 0)}°", "mavi", 10.5, False, "middle")
    c.yazi(450, 300, ("Röle açıyor" if acar else ("2. harmonik blokajı tutuyor" if any(H["ustunde"]) and any(H["blok"]) else "Röle açmıyor")) + " · " + ("olması gereken: açma" if beklenen else "olması gereken: açmama") + (" — doğru" if acar == beklenen else " — YANLIŞ"),
           "ok" if acar == beklenen else "ariza", 12.5, True, "middle")
    # grafik: karakteristik ve çalışma noktaları
    bmax = max(4.0, max(H["ib"]) * 1.25)
    ymax = max(2.0, max(H["id"]) * 1.2, esik(bmax, *H["par"]) * 1.05)
    xs = [bmax * k / 60 for k in range(61)]
    renk = ("#8a4b12", "#111827", "#6b7280")
    graf = [{"baslik": "Karakteristik ve çalışma noktaları", "x_ad": "tutucu akım Ib (pu)", "y_ad": "fark akımı Id (pu)", "ymin": 0, "ymax": ymax,
             "seriler": [{"ad": "açma eşiği", "renk": "#dc2626", "pts": [[round(x, 3), round(esik(x, *H["par"]), 3)] for x in xs]}] +
                        [{"ad": f"L{k + 1}", "renk": renk[k], "nokta": True, "r": 5, "pts": [[round(H["ib"][k], 3), round(min(H["id"][k], ymax), 3)]]} for k in range(3)],
             "yatay": ([{"y": num(p, "id_yuksek", 8), "etiket": "Id>> (blokajsız)", "renk": "#7c3aed"}] if ymax >= num(p, "id_yuksek", 8) else [])}]
    m = max(1e-9, abs(H["I1"][j]), abs(H["I2"][j]), H["id"][j])
    fz = {"baslik": f"Röledeki fazörler — L{j + 1}", "not": "Id = I1 − I2′ ; içinden geçen akımda I1 ve I2′ çakışır",
          "vektorler": [{**fazor("I1", H["I1"][j] / m, "#dc2626"), "mod": round(abs(H["I1"][j]), 2)}, {**fazor("I2′", H["I2"][j] / m, "#1d4ed8"), "mod": round(abs(H["I2"][j]), 2)},
                        {**fazor("Id", (H["I1"][j] - H["I2"][j]) / m, "#7c3aed", True), "mod": round(H["id"][j], 2)}]}
    tab = [{"baslik": "Faz faz röle değerleri", "cols": ["Faz", "I1 (OG)", "I2′ (AG, dönüştürülmüş)", "Fark Id", "Tutucu Ib", "Eşik", "2. harmonik", "Karar"],
            "rows": [[f"L{k + 1}", f"{fnum(abs(H['I1'][k]), 2)} pu", f"{fnum(abs(H['I2'][k]), 2)} pu", f"{fnum(H['id'][k], 2)} pu", f"{fnum(H['ib'][k], 2)} pu", f"{fnum(H['thr'][k], 2)} pu", f"%{fnum(H['h2'][k] * 100, 0)}" if dur == "inrush" else "—",
                      "açma" if H["acma"][k] else ("blokaj" if H["ustunde"][k] else "—")] for k in range(3)]},
           {"baslik": "Bağlantı ve ayar hatalarının yük akımında bıraktığı fark akımı", "cols": ["Hata", "Fark akımı (yük akımının katı)", "Nasıl fark edilir"],
            "rows": [["Bir taraftaki akım trafosunun polaritesi ters", "2,00", "yükle büyüyen fark akımı; tutucu akım = yük"], ["Bağlantı grubu 30° yanlış (ör. Dyn11 yerine Yy0)", "0,52", "fark akımı yükün yarısı kadar"], ["Bağlantı grubu 60° yanlış (ör. Dyn11 yerine Dyn1)", "1,00", "fark akımı yük kadar"],
                     ["Oran eşleştirmesi yok", f"{fnum(abs(H['i1n'] / H['ct1'] - H['i2n'] / H['ct2']), 2)} (bu akım trafolarıyla)", "iki tarafın pu akımları farklı okunur"], ["Kademe değiştirici uç konumda (± %10)", "≈ 0,10", "kademe ile değişen küçük fark; eğim karşılar"],
                     ["Sıfır bileşen süzülmüyor (yıldız noktası topraklı taraf)", "dış toprak arızasında I0 kadar", "yalnız dış toprak arızasında açma"], ["Akım trafosu doyması (dış arıza)", "kaybolan akım kadar", "arıza kaydında bozuk dalga biçimi; 2. eğim karşılar"]]},
           {"baslik": "Polarite nasıl doğrulanır?", "cols": ["Yöntem", "Nasıl", "Ne gösterir"],
            "rows": [["Pil (doğru akım darbe) deneyi", "primerde P1'e pilin artısı anlık dokundurulur; sekonderde S1–S2'ye bağlı analog ölçü aletinin ibresi izlenir", "ibre artı yöne sıçrarsa P1–S1 aynı kutup (çıkarımlı polarite)"],
                     ["Primer enjeksiyon", "primerden bilinen bir akım geçirilir; sekonder akımın değeri ve yönü röle klemensinde ölçülür", "oran, polarite ve bütün sekonder bağlantı birlikte doğrulanır"],
                     ["Sekonder enjeksiyon", "akım trafosu klemensinden röleye akım verilir", "kablaj ve röle ayarı (akım trafosunun kendisi değil)"],
                     ["Yük altında kararlılık", "trafo yüklenir; rölenin fark ve tutucu akımı okunur", "fark ≈ 0 ise polarite, grup ve oran doğru; bir taraf geçici olarak ters çevrilirse fark iki katına çıkmalı"]],
            "not": KABUL + " — durum: resmi (deneylerin yapılması); yöntem ayrıntıları: röle ve akım trafosu üreticisi belgeleri."},
           {"baslik": "Bağlantı grubu dönüşümleri (içinden geçen akım, pu)", "cols": ["Grup", "OG hat akımı", "AG'nin OG'ye göre açısı", "Sıfır bileşen"],
            "rows": [["Dyn11", "IA = (ia − ic) / √3", "30° ileride", "üçgende dolaşır; OG hattına çıkmaz"], ["Dyn1", "IA = (ia − ib) / √3", "30° geride", "aynı"], ["Dyn5", "IA = (ic − ia) / √3", "150° geride", "aynı"], ["Yyn0", "IA = ia − i0", "0°", "AG'de var, OG'de yok: süzülmeli"]]}]
    oz = [K("Fark akımı Id", f"{fnum(H['id'][j], 2)} pu", "ok" if acar == beklenen else "bad", f"L{j + 1}"), K("Tutucu akım Ib", f"{fnum(H['ib'][j], 2)} pu", "info", "(|I1| + |I2′|) / 2"), K("Açma eşiği", f"{fnum(H['thr'][j], 2)} pu", "info", "bu tutucu akımda"),
          K("Röle", "açıyor" if acar else "açmıyor", "ok" if acar == beklenen else "bad", "açmalı" if beklenen else "açmamalı"), K("Anma akımları", f"{fnum(H['i1n'], 0)} / {fnum(H['i2n'], 0)} A", "info", "OG / AG")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(fazor=fz), "grafikler": graf, "tablolar": tab}
