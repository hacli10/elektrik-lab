"""Laboratuvar konusu — EMC ve fonksiyon topraklaması: iki pano arasındaki potansiyel farkı, sinyal kablosu ekranının bağlanışı,
paralel eşpotansiyel iletken, TN-C'nin sakıncası.

Model: iki pano arasındaki koruma iletkeninden I akımı geçiyorsa (hatalı N–PE köprüsü, sürücü kaçak akımı, TN-C'de nötr akımı)
panoların “toprakları” arasında ΔU = I · R fark oluşur. Sinyal kablosunun ekranı iki uçta bağlıysa bu fark ekrandan akım geçirir
(I = ΔU / R ekran, paralel eşpotansiyel iletken varsa onunla bölüşür); tek uçta bağlıysa fark sinyalin ortak mod gerilimi olur.
Dayanak: TS HD 60364-4-444; Topraklamalar Yön. Ek-E — madde ayrıntıları doğrulanacak."""
from __future__ import annotations

from .cizim import Cizim
from .core import C, K, RHO_CU, ctl, fnum, num, opt

ID = "emc"
BASLIK = "EMC ve fonksiyon topraklaması"
IKON = "📡"
GIRIS = ("“Toprak” her yerde aynı potansiyelde değildir: koruma iletkeninden akım geçen her tesiste iki pano arasında birkaç volt fark vardır. "
         "Sinyal kabloları bu farkı ya ekranlarında akım olarak ya da sinyalin üstünde gerilim olarak taşır. Bağlantı biçimini değiştirip sonucu görün.")
SINYAL = {"analog": ("4–20 mA analog (yalıtımsız giriş)", 1.0), "rs485": ("RS-485 / Modbus", 7.0), "ethernet": ("Ethernet (trafolu, yalıtımlı)", 1500.0), "izole": ("Yalıtıcı (izolatör) üzerinden analog", 500.0)}
D = "dogrulanacak"

KONTROLLER = [
    ctl("sistem", "Tesisin sistemi", "sec", "TN-S", secenek=opt(("TN-S", "TN-S (nötr ve koruma ayrı)"), ("TN-C", "TN-C (PEN: nötr akımı koruma iletkeninde)"))),
    ctl("i_pe", "İki pano arasındaki koruma iletkeninden geçen akım", "sayi", 3, min=0, max=200, adim=0.5, birim="A", yardim="TN-S'de ideal olarak sıfır; N–PE köprüsü, sürücü ve filtre kaçak akımlarıyla birkaç amper", goster={"sistem": ["TN-S"]}),
    ctl("i_n", "Nötr akımı (dengesizlik + harmonik)", "sayi", 60, min=0, max=400, adim=5, birim="A", goster={"sistem": ["TN-C"]}),
    ctl("l_m", "İki pano arasındaki uzaklık", "sayi", 80, min=2, max=500, adim=2, birim="m"),
    ctl("s_pe", "Koruma iletkeni (PE / PEN) kesiti", "sec", 16, secenek=opt(*[(v, f"{v:g} mm²") for v in (2.5, 4, 6, 10, 16, 25, 35, 50, 70, 95)])),
    ctl("sinyal", "Sinyal türü", "sec", "rs485", secenek=opt(*[(k, v[0]) for k, v in SINYAL.items()])),
    ctl("ekran", "Sinyal kablosu ekranı", "sec", "iki", secenek=opt(("iki", "İki uçta bağlı"), ("tek", "Tek uçta bağlı"), ("yok", "Ekransız kablo"))),
    ctl("pec", "Sinyal kablosuna paralel eşpotansiyel iletken var (16 mm² Cu, aynı güzergâh)", "onay", False),
    ctl("ayri", "Güç ve sinyal kabloları ayrı tavada / ayrı kanalda", "onay", True),
]
R_EKRAN_M = 0.015     # sinyal kablosu ekran direnci (Ω/m) — tipik örgü ekran


def run(p: dict) -> dict:
    tnc = p.get("sistem") == "TN-C"
    i = num(p, "i_n", 60) if tnc else num(p, "i_pe", 3)
    L = num(p, "l_m", 80); s = num(p, "s_pe", 16)
    r_pe = RHO_CU * L / s
    du = i * r_pe
    sk = p.get("sinyal") if p.get("sinyal") in SINYAL else "rs485"
    sad, dayan = SINYAL[sk]
    ekran = p.get("ekran") if p.get("ekran") in ("iki", "tek", "yok") else "iki"
    pec = bool(p.get("pec"))
    r_e = R_EKRAN_M * L
    r_pec = RHO_CU * L / 16.0
    if ekran == "iki":
        # ekran, koruma iletkenine (ve varsa paralel eşpotansiyel iletkene) paralel bir yol olur
        r_par = r_e * r_pec / (r_e + r_pec) if pec else r_e
        i_ek_toplam = i * r_pe / (r_pe + r_par)
        i_ekran = i_ek_toplam * (r_pec / (r_e + r_pec) if pec else 1.0)
        u_cm = i_ekran * r_e * 0.05                       # ekran akımının sinyale kuplajı (transfer empedansı ≈ ekran direncinin küçük bir bölümü)
    else:
        i_ekran = 0.0
        u_cm = du * (r_pec / (r_pe + r_pec) if pec else 1.0)
    an = [(f"TN-C: nötr ve koruma tek iletkendir (PEN). {fnum(i, 0)} A'lik nötr akımı koruma iletkeninden akar." if tnc else f"İki pano arasındaki koruma iletkeninden {fnum(i, 1)} A geçiyor (hatalı bir N–PE köprüsü, sürücü ve filtre kaçak akımları).")
          + f" {fnum(L, 0)} m, {fnum(s, 0)} mm² iletkenin direnci {fnum(r_pe * 1000, 0)} mΩ: iki panonun toprak baraları arasında ΔU = {fnum(du, 2)} V fark oluşur."]
    if ekran == "iki":
        an += [f"Sinyal kablosunun ekranı iki uçta bağlı: iki barayı birleştiren ikinci bir iletken gibi davranır. Farkın sürdüğü akımın bir bölümü ekrandan geçer: {fnum(i_ekran, 2)} A" + (" (paralel eşpotansiyel iletken akımın çoğunu üstleniyor)." if pec else "."),
               "Yüksek frekanslı parazite karşı en iyi bağlantı budur (ekran iki uçta, geniş yüzeyle); ama ekran, taşımak için tasarlanmadığı şebeke frekanslı akımı taşır: ısınır, sinyale uğultu bindirir."]
    elif ekran == "tek":
        an += [f"Ekran tek uçta bağlı: ekrandan akım geçmez. Buna karşılık iki pano arasındaki fark, sinyalin gönderen ve alan uçları arasında ortak mod gerilimi olarak görünür: {fnum(u_cm, 2)} V.",
               "Tek uçtan bağlı ekran düşük frekanslı elektrik alanına karşı korur, ama yüksek frekansta (sürücü, haberleşme) anten gibi davranır."]
    else:
        an.append(f"Ekransız kablo: iki pano arasındaki fark doğrudan sinyalin ortak mod gerilimi olur ({fnum(u_cm, 2)} V); ayrıca komşu güç kablolarının alanına açıktır.")
    an.append(f"Sinyal: {sad}. Dayanabildiği ortak mod gerilimi ≈ {fnum(dayan, 0)} V. Sinyalin gördüğü ≈ {fnum(u_cm, 2)} V.")
    kt = [C("Bina içi sistem", "TN-C" if tnc else "TN-S", "bilgi teknolojisi ve otomasyon donanımı bulunan binalarda TN-S (TN-C kullanılmaz)", not tnc, "TS HD 60364-4-444 m.444.4.3", D),
          C("Panolar arası potansiyel farkı", f"ΔU = {fnum(i, 1)} A × {fnum(r_pe * 1000, 0)} mΩ = {fnum(du, 2)} V", "≤ ≈ 1 V (uygulama ölçütü; sinyal dayanımına göre)", du <= 1.0 + 1e-9, "Uygulama ölçütü; TS EN 50310 (eşpotansiyel bağlama)", "ikincil"),
          C("Sinyalin ortak mod gerilimi", f"≈ {fnum(u_cm, 2)} V", f"≤ {fnum(dayan, 0)} V ({sad})", u_cm <= dayan + 1e-9, "Arayüz standardı / cihaz verisi (RS-485: −7 … +12 V)", "ikincil")]
    if ekran == "iki":
        kt.append(C("Ekrandan geçen şebeke frekanslı akım", f"{fnum(i_ekran, 2)} A", "≤ ≈ 0,5 A (ekran akım taşıyıcı değildir); aşıyorsa paralel eşpotansiyel iletken", i_ekran <= 0.5 + 1e-9, "TS HD 60364-4-444 m.444.4.2; TS EN 50174-2", D))
    if ekran == "yok":
        kt.append(C("Sinyal kablosu", "ekransız", "güç devrelerinin yakınında ekranlı ya da bükümlü çift kablo", False, "TS HD 60364-4-444; TS EN 50174-2", D))
    kt.append(C("Güç ve sinyal kablolarının ayrılması", "ayrı" if p.get("ayri", True) else "aynı tavada, yan yana", "ayrı tava / bölmeli kanal; kesişmeler dik açıyla", bool(p.get("ayri", True)), "TS HD 60364-4-444 m.444.6; TS EN 50174-2", D))
    ds = ["Koruma iletkeninden akım geçmemesi gerekir. Geçiyorsa neden aranır: nötrün ikinci bir noktada toprağa bağlanması en sık nedendir ve TN-C bunun kalıcı biçimidir.",
          "Ekranı iki uçta bağlamak yüksek frekans için doğrudur; düşük frekanslı dolaşan akım sorunsa çare ekranı ayırmak değil, ekrana paralel kalın bir eşpotansiyel iletken çekmek (ve nedeni gidermek)tir.",
          "Yalıtımlı arayüzler (Ethernet trafosu, fiber, yalıtıcı röle, optokuplör) potansiyel farkını sinyalden ayırır: binalar arası ve uzak panolar arası haberleşmede fiber bu yüzden tercih edilir.",
          "“Temiz toprak” için ayrı bir topraklama kazığı çakmak sorunu büyütür: iki ayrı topraklama arasında arıza ve yıldırım anında binlerce volt oluşur. Doğrusu tek topraklama tesisi ve yoğun eşpotansiyel bağlamadır (ağ biçimli).",
          "Yıldız (tek nokta) topraklama düşük frekanslı, küçük sistemlerde; ağ biçimli (çok noktalı) topraklama yüksek frekanslı ve büyük sistemlerde kullanılır. Sürücülü tesislerde ağ biçimli olan seçilir."]
    c = Cizim(900, 300, zemin=262)
    c.kutu(60, 60, 150, 120, "PANO A", "sürücü / PLC", "normal").kutu(690, 60, 150, 120, "PANO B", "saha cihazı / PLC", "normal")
    c.hat("M135,180 V230 H765 V180", "PEN" if tnc else "PE", hot=i > 0.2, w=3).yazi(450, 248, f"{'PEN' if tnc else 'koruma iletkeni'} · {fnum(i, 1)} A · {fnum(r_pe * 1000, 0)} mΩ → ΔU = {fnum(du, 2)} V", "ariza" if du > 1 else "#334155", 11.5, True, "middle")
    c.hat("M210,100 H690", "mavi", w=2.4).yazi(450, 76, sad, "mavi", 11, True, "middle")
    if ekran != "yok":
        c.dikdortgen(230, 86, 440, 28, "PE", "rgba(21,128,61,.08)", 1.6, True, 12)
        c.hat("M232,114 V150 H180", "PE", hot=(ekran == "iki" and i_ekran > 0.05), hot_renk="uyari")
        if ekran == "iki":
            c.hat("M668,114 V150 H720", "PE", hot=i_ekran > 0.05, hot_renk="uyari").yazi(450, 134, f"ekran iki uçta bağlı · {fnum(i_ekran, 2)} A", "uyari" if i_ekran > 0.5 else "PE", 11, True, "middle")
        else:
            c.daire(668, 122, 4, "ariza", "#fff").yazi(450, 134, "ekran tek uçta bağlı · akım yok", "PE", 11, True, "middle")
    if pec:
        c.hat("M160,180 V205 H740 V180", "PE", hot=i > 0.2, w=4, hot_renk="ok").yazi(450, 200, "paralel eşpotansiyel iletken 16 mm²", "ok", 10.5, True, "middle")
    c.toprak(135, 262).hat("M135,230 V262", "PE", kesik=True)
    c.yazi(450, 290, f"sinyalin gördüğü ortak mod gerilimi ≈ {fnum(u_cm, 2)} V (dayanım {fnum(dayan, 0)} V)", "ok" if u_cm <= dayan else "ariza", 12, True, "middle")
    oz = [K("Panolar arası fark ΔU", f"{fnum(du, 2)} V", "ok" if du <= 1 else "bad", f"{fnum(i, 1)} A × {fnum(r_pe * 1000, 0)} mΩ"), K("Ekran akımı", f"{fnum(i_ekran, 2)} A", "ok" if i_ekran <= 0.5 else "bad", {"iki": "iki uçta bağlı", "tek": "tek uçta bağlı", "yok": "ekransız"}[ekran]),
          K("Ortak mod gerilimi", f"{fnum(u_cm, 2)} V", "ok" if u_cm <= dayan else "bad", f"dayanım {fnum(dayan, 0)} V"), K("Sistem", "TN-C" if tnc else "TN-S", "bad" if tnc else "ok", "nötr akımı koruma iletkeninde" if tnc else "")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne()}
