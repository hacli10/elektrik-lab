"""Laboratuvar konusu — dağıtım transformatörü deneyleri (yağlı hermetik ve kuru tip): hangi deney, hangi bağlantı, ne ölçülür, sınır ne.

Resmi dayanak (metinden): TEDAŞ-MLZ/99-032.E (hermetik) ve TEDAŞ-MLZ/99-031.B (kuru tip) — rutin deney listesi, yalıtım düzeyleri
(OG sargı 20/28/38/70 kV; AG sargı 3 kV), toleranslar (çevirme oranı ± %0,5; kısa devre empedansı ± %10; boştaki akım + %30; kayıplar + %0),
kuru tipte kısmi boşalma ≤ 10 pC, yalıtım direnci ölçüm gerilimleri (AG–tank 2500 V; YG–tank ve YG–AG 5000 V; 0/15/30/45/60 s).
Yöntemler: TS EN 60076-1, -3, -11 — madde ayrıntıları doğrulanacak."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, ctl, fnum, num, opt

ID = "trafo_test"
BASLIK = "Dağıtım trafosu deneyleri"
IKON = "🏭"
GIRIS = ("Fabrikadan çıkan her trafo aynı deneylerden geçer; kabulde bunların bir bölümü sizin gözetiminizde tekrarlanır. Her deney için kaynağın nereye bağlandığını, "
         "hangi uçların kısa devre edildiğini ya da topraklandığını, ne ölçüldüğünü ve değerin hangi sınırla karşılaştırıldığını görün.")
DENEY = {"direnc": "Sargı direncinin ölçülmesi", "oran": "Çevirme oranı ve bağlantı grubu", "kisa": "Kısa devre empedansı ve yük kaybı", "bosta": "Boştaki kayıp ve akım",
         "uygulanan": "Ayrı kaynaklı (uygulanan) a.a. dayanım gerilimi", "enduklenen": "Endüklenmiş a.a. gerilim deneyi", "megger": "Yalıtım direnci", "pd": "Kısmi boşalma (kuru tip)", "yag": "Yalıtım yağı delinme gerilimi (yağlı tip)"}
YALITIM = {6.3: 20, 10.5: 28, 15.8: 38, 33.0: 70, 34.5: 70}
KH, KK = "TEDAŞ-MLZ/99-032.E", "TEDAŞ-MLZ/99-031.B"
D = "dogrulanacak"

KONTROLLER = [
    ctl("deney", "Deney", "sec", "oran", secenek=opt(*DENEY.items())),
    ctl("tip", "Trafo tipi", "sec", "yagli", secenek=opt(("yagli", "Yağlı — hermetik"), ("kuru", "Kuru tip — dökme reçineli"))),
    ctl("sn_kva", "Anma gücü", "sec", 630, secenek=opt(*[(v, f"{v} kVA") for v in (50, 100, 160, 250, 400, 630, 800, 1000, 1250, 1600, 2000, 2500)])),
    ctl("un_og", "OG anma gerilimi", "sec", 33.0, secenek=opt((6.3, "6,3 kV"), (10.5, "10,5 kV"), (15.8, "15,8 kV"), (33.0, "33 kV"), (34.5, "34,5 kV"))),
    ctl("uk_g", "Garanti edilen kısa devre gerilimi uk", "sayi", 4.5, min=3, max=8, adim=0.1, birim="%", goster={"deney": ["kisa"]}),
    ctl("pk_g", "Garanti edilen yük kaybı Pk", "sayi", 6500, min=500, max=30000, adim=50, birim="W", goster={"deney": ["kisa"]}),
    ctl("uk_o", "Ölçülen kısa devre gerilimi", "sayi", 4.6, min=2, max=10, adim=0.05, birim="%", goster={"deney": ["kisa"]}),
    ctl("pk_o", "Ölçülen yük kaybı (referans sıcaklığa indirgenmiş)", "sayi", 6400, min=500, max=35000, adim=50, birim="W", goster={"deney": ["kisa"]}),
    ctl("p0_g", "Garanti edilen boştaki kayıp P0", "sayi", 800, min=50, max=5000, adim=10, birim="W", goster={"deney": ["bosta"]}),
    ctl("i0_g", "Garanti edilen boştaki akım", "sayi", 1.0, min=0.1, max=4, adim=0.05, birim="%", goster={"deney": ["bosta"]}),
    ctl("p0_o", "Ölçülen boştaki kayıp", "sayi", 790, min=50, max=6000, adim=10, birim="W", goster={"deney": ["bosta"]}),
    ctl("i0_o", "Ölçülen boştaki akım", "sayi", 1.1, min=0.1, max=6, adim=0.05, birim="%", goster={"deney": ["bosta"]}),
    ctl("oran_sapma", "Ölçülen oranın anma oranından sapması", "sayi", 0.2, min=-3, max=3, adim=0.05, birim="%", goster={"deney": ["oran"]}),
    ctl("grup", "Ölçülen bağlantı grubu", "sec", "Dyn11", secenek=opt(("Dyn11", "Dyn11"), ("Dyn5", "Dyn5"), ("Dyn1", "Dyn1"), ("Yzn11", "Yzn11")), goster={"deney": ["oran"]}),
    ctl("r_uv", "OG sargı direnci 1U–1V", "sayi", 12.40, min=0.01, max=500, adim=0.01, birim="Ω", goster={"deney": ["direnc"]}),
    ctl("r_vw", "OG sargı direnci 1V–1W", "sayi", 12.45, min=0.01, max=500, adim=0.01, birim="Ω", goster={"deney": ["direnc"]}),
    ctl("r_wu", "OG sargı direnci 1W–1U", "sayi", 12.38, min=0.01, max=500, adim=0.01, birim="Ω", goster={"deney": ["direnc"]}),
    ctl("sicaklik", "Ölçüm sırasında sargı sıcaklığı", "sayi", 22, min=-10, max=60, adim=1, birim="°C", goster={"deney": ["direnc", "megger"]}),
    ctl("iletken", "Sargı iletkeni", "sec", "al", secenek=opt(("cu", "bakır"), ("al", "alüminyum")), goster={"deney": ["direnc"]}),
    ctl("sargi", "Deney edilen sargı", "sec", "og", secenek=opt(("og", "OG sargısı"), ("ag", "AG sargısı")), goster={"deney": ["uygulanan"]}),
    ctl("u_kv", "Uygulanan gerilim", "sayi", 70, min=1, max=100, adim=0.5, birim="kV", goster={"deney": ["uygulanan"]}),
    ctl("f_hz", "Deney frekansı", "sec", 150, secenek=opt((100, "100 Hz"), (150, "150 Hz"), (200, "200 Hz"), (50, "50 Hz")), goster={"deney": ["enduklenen"]}),
    ctl("sure_s", "Deney süresi", "sayi", 40, min=5, max=120, adim=1, birim="s", goster={"deney": ["enduklenen"]}),
    ctl("sure_u", "Deney süresi", "sayi", 60, min=5, max=120, adim=1, birim="s", goster={"deney": ["uygulanan"]}),
    ctl("r15", "15. saniyede okunan (OG – tank)", "sayi", 9, min=0.001, max=500, adim=0.1, birim="GΩ", goster={"deney": ["megger"]}),
    ctl("r60", "60. saniyede okunan (OG – tank)", "sayi", 15, min=0.001, max=500, adim=0.1, birim="GΩ", goster={"deney": ["megger"]}),
    ctl("pd_pc", "Ölçülen kısmi boşalma", "sayi", 6, min=0, max=200, adim=1, birim="pC", goster={"deney": ["pd"]}),
    ctl("bdv", "Ölçülen delinme gerilimi (2,5 mm aralık, altı ölçümün ortalaması)", "sayi", 65, min=5, max=100, adim=1, birim="kV", goster={"deney": ["yag"]}),
]


def _trafo(c: Cizim, og: str = "", ag: str = "", tip: str = "yagli") -> Cizim:
    """Ortadaki trafo: solda OG uçları (1U 1V 1W), sağda AG uçları (2u 2v 2w 2n)."""
    c.dikdortgen(330, 60, 240, 170, "#334155", "rgba(148,163,184,.10)", 2.2, False, 8).yazi(450, 52, "TRAFO — " + ("yağlı (tank)" if tip == "yagli" else "kuru tip (şase)"), "#334155", 11.5, True, "middle")
    c.sarim(400, 150, "ucgen", "#334155", 26).sarim(500, 152, "yildiz", "#334155", 26).yazi(400, 200, "OG (Δ)", "#475569", 10.5, False, "middle").yazi(500, 200, "AG (yn)", "#475569", 10.5, False, "middle")
    for k, ad in enumerate(("1U", "1V", "1W")):
        c.daire(330, 95 + k * 45, 6, "ariza", "#fff", 2).yazi(318, 82 + k * 45, ad, "#334155", 10.5, True, "end")
    for k, ad in enumerate(("2u", "2v", "2w", "2n")):
        c.daire(570, 85 + k * 38, 6, "mavi", "#fff", 2).yazi(582, 76 + k * 38, ad, "#334155", 10.5, True)
    c.hat("M450,230 V262", "PE", kesik=True).toprak(450, 262)
    if og:
        c.yazi(170, 250, og, "#475569", 10.5, False, "middle")
    if ag:
        c.yazi(750, 250, ag, "#475569", 10.5, False, "middle")
    return c


def run(p: dict) -> dict:
    deney = p.get("deney") if p.get("deney") in DENEY else "oran"
    tip = "kuru" if p.get("tip") == "kuru" else "yagli"
    sn = num(p, "sn_kva", 630) * 1000; uog = float(num(p, "un_og", 33.0)) * 1000; uag = 400.0
    i_og = sn / (math.sqrt(3) * uog); i_ag = sn / (math.sqrt(3) * uag)
    KS = KH if tip == "yagli" else KK
    kt, an, ds, graf = [], [], [], []
    c = Cizim(900, 290, zemin=262)
    if deney == "direnc":
        r = [num(p, "r_uv", 12.40), num(p, "r_vw", 12.45), num(p, "r_wu", 12.38)]
        ort = sum(r) / 3; fark = (max(r) - min(r)) / ort * 100
        th = num(p, "sicaklik", 22); beta = 235.0 if p.get("iletken") == "cu" else 225.0
        tref = 75.0 if tip == "yagli" else 120.0
        r_ref = ort * (beta + tref) / (beta + th)
        an = ["Sargıdan doğru akım geçirilir ve uçlar arasındaki gerilim ölçülür (dört uçlu ölçüm). OG tarafında uçlar arası üç ölçüm (1U–1V, 1V–1W, 1W–1U), AG tarafında faz–nötr üç ölçüm yapılır; kademe değiştiricinin her konumunda tekrarlanır.",
              f"Ölçülenler: {fnum(r[0], 2)} / {fnum(r[1], 2)} / {fnum(r[2], 2)} Ω; ortalama {fnum(ort, 2)} Ω; en büyük fark %{fnum(fark, 2)}. Fazlar arasında belirgin fark, gevşek bir bağlantıyı, kademe değiştirici kontağını ya da kısa devre olmuş sarımları gösterir.",
              f"Direnç sıcaklıkla değişir; kayıp hesabı için referans sıcaklığa ({fnum(tref, 0)} °C) çevrilir: R = {fnum(ort, 2)} × ({fnum(beta, 0)} + {fnum(tref, 0)}) / ({fnum(beta, 0)} + {fnum(th, 0)}) = {fnum(r_ref, 2)} Ω. Bu yüzden ölçümle birlikte sargı sıcaklığı da kaydedilir.",
              "Ölçme akımı, çekirdeği doyuracak kadar büyük (akım çabuk otursun) ama sargıyı ısıtmayacak kadar küçük seçilir (anma akımının %10–15'ini geçmez). Okuma, akım oturduktan sonra alınır; büyük trafolarda bu dakikalar sürer."]
        kt = [C("Fazlar arası direnç farkı", f"%{fnum(fark, 2)}", "≤ %2 (uçlar arası ölçümde; yorum ölçütü)", fark <= 2.0, "TS EN 60076-1 m.11.2 (yöntem); kabul ölçütü üretici / uygulama", "ikincil"),
              C("Sıcaklık kaydı ve indirgeme", f"{fnum(th, 0)} °C'de ölçüldü → {fnum(tref, 0)} °C'de {fnum(r_ref, 2)} Ω", f"referans sıcaklık: yağlı 75 °C; kuru tip, yalıtım sınıfının sıcaklık artışı + 20 °C (F: 120 °C)", None, "TS EN 60076-1 m.11.2; TS EN 60076-11", D)]
        ds = ["Sargı direnci, bütün diğer deneylerin temelidir: yük kaybının sıcaklık düzeltmesi ve ısınma deneyinde sargı sıcaklığının bulunması bu ölçüme dayanır.",
              "Ölçümden sonra çekirdekte kalıcı mıknatıslanma kalır; ardından yapılacak boşta ve oran ölçümlerini etkileyebilir. Gerekirse mıknatıslığı giderme işlemi yapılır.",
              "Akım kesilirken sargının endüktansı yüksek gerilim üretir: cihazın boşaltma devresi bitmeden kablolar sökülmez."]
        _trafo(c, "DC kaynak + voltmetre (1U–1V)", "AG uçları açık", tip).cihaz(60, 110, f"{fnum(r[0], 2)} Ω", "sargı direnci ölçer", fark <= 2, 150).hat("M210,125 H260 V95 H324", "ariza", hot=True).hat("M210,150 H260 V140 H324", "ariza", hot=True)
        oz = [K("Ortalama direnç", f"{fnum(ort, 2)} Ω", "info", f"{fnum(th, 0)} °C'de"), K("Fazlar arası fark", f"%{fnum(fark, 2)}", "ok" if fark <= 2 else "bad", "sınır %2"), K(f"{fnum(tref, 0)} °C'ye indirgenmiş", f"{fnum(r_ref, 2)} Ω", "info", "kayıp hesabı için")]
    elif deney == "oran":
        sapma = num(p, "oran_sapma", 0.2); grup = p.get("grup") or "Dyn11"
        oran = uog / uag; oran_sarim = uog / (uag / math.sqrt(3))
        an = [f"Anma çevirme oranı {fnum(uog / 1000, 1)} kV / 0,4 kV = {fnum(oran, 2)}. Dyn bağlı trafoda bir OG sargısı (hat gerilimi) ile bir AG sargısının (faz gerilimi) sarım oranı {fnum(oran_sarim, 1)}'dir; oran ölçer bunu faz faz ölçer.",
              "Bağlantı: OG sargısına düşük bir alternatif gerilim uygulanır (ör. üç faz 400 V); AG tarafında endüklenen gerilim ölçülür. AG uçları açıktır. Deney her kademede ve her fazda tekrarlanır.",
              f"Ölçülen oranın anma değerinden sapması %{fnum(sapma, 2)}. Sapma büyükse sarım sayısı yanlıştır, kademe yanlış bağlanmıştır ya da sarımlar arasında kısa devre vardır.",
              f"Bağlantı grubu: {grup}. Dyn11'de AG faz gerilimi, OG'ye göre 30° ileridedir (saat 11). Grup yanlışsa trafo tek başına çalışır, ama başka bir trafoyla paralel bağlandığında ya da jeneratörle senkronlandığında kısa devre olur."]
        kt = [C("Çevirme oranı sapması", f"%{fnum(sapma, 2)}", "± %0,5 (ana kademede)", abs(sapma) <= 0.5 + 1e-9, f"{KS} (Toleranslar); TS EN 60076-1 m.11.3", "resmi"),
              C("Bağlantı grubu", grup, "Dyn11 (sipariş edilen grup)", grup == "Dyn11", f"{KS}; TS EN 60076-1 m.11.3", "resmi")]
        ds = ["Oran deneyi en ucuz ve en çok şey söyleyen deneydir: sarım hatası, kademe hatası, sarım kısa devresi ve yanlış bağlantı burada çıkar.",
              "Kademe değiştirici her adımda oranı yaklaşık %2,5 değiştirir; bütün kademelerde ölçülen oranlar eşit adımlarla artmalıdır.",
              "Gerilim OG'ye uygulanır, AG'de ölçülür. Tersi yapılırsa (400 V AG'ye) OG uçlarında anma gerilimi oluşur: öldürücü bir hatadır."]
        _trafo(c, "3 × 400 V a.a. (OG sargısına)", "voltmetre: endüklenen gerilim", tip).kutu(60, 110, 150, 56, "Oran ölçer", f"oran {fnum(oran * (1 + sapma / 100), 2)}", "acti" if abs(sapma) <= 0.5 else "gecersiz")
        for k in range(3):
            c.hat(f"M210,{125 + k * 12} H{250 + k * 12} V{95 + k * 45} H324", "ariza", hot=True)
        c.hat("M576,85 H680 V150", "mavi").hat("M576,199 H700 V180", "mavi").cihaz(640, 150, f"{fnum(400 / oran * (1 - sapma / 100), 2)} V", "AG faz–faz (2u–2v)", True, 130)
        oz = [K("Anma oranı", fnum(oran, 2), "info", f"{fnum(uog / 1000, 1)} / 0,4 kV"), K("Sapma", f"%{fnum(sapma, 2)}", "ok" if abs(sapma) <= 0.5 else "bad", "sınır ± %0,5"), K("Bağlantı grubu", grup, "ok" if grup == "Dyn11" else "bad", "saat 11: AG 30° ileride")]
    elif deney == "kisa":
        ukg, pkg, uko, pko = num(p, "uk_g", 4.5), num(p, "pk_g", 6500), num(p, "uk_o", 4.6), num(p, "pk_o", 6400)
        u_dev = uko / 100 * uog
        an = [f"AG uçları (2u, 2v, 2w) kalın bir köprüyle kısa devre edilir. OG sargısına, içinden anma akımı ({fnum(i_og, 1)} A) geçecek kadar düşük bir gerilim uygulanır. Bu gerilim kısa devre gerilimidir: uk = %{fnum(uko, 2)} → {fnum(u_dev, 0)} V.",
              f"Gerilim küçük olduğu için çekirdek kaybı ihmal edilir; wattmetrelerin ölçtüğü güç sargılardaki bakır kaybıdır (yük kaybı): {fnum(pko, 0)} W. Değer referans sıcaklığa ({'75' if tip == 'yagli' else '120'} °C) indirgenir.",
              f"Garanti değerleri: uk %{fnum(ukg, 2)}, Pk {fnum(pkg, 0)} W. Ölçülen uk sapması %{fnum((uko - ukg) / ukg * 100, 1)}; yük kaybı farkı %{fnum((pko - pkg) / pkg * 100, 1)}.",
              "uk kısa devre akımını belirler (Ik = In / uk): küçük çıkarsa AG panolarının kısa devre dayanımı yetmeyebilir, büyük çıkarsa gerilim düşümü artar ve paralel çalışan trafolarla yük paylaşımı bozulur."]
        kt = [C("Kısa devre empedansı", f"%{fnum(uko, 2)} (garanti %{fnum(ukg, 2)})", "garanti değerinin ± %10'u içinde (ana kademede)", abs(uko - ukg) <= 0.10 * ukg + 1e-9, f"{KS} (Toleranslar); TS EN 60076-1 m.11.4", "resmi"),
              C("Yük kaybı", f"{fnum(pko, 0)} W (garanti {fnum(pkg, 0)} W)", "garanti değerini aşamaz (+ %0)", pko <= pkg + 1e-9, f"{KS} (Toleranslar: kayıplar + %0)", "resmi")]
        ds = ["Kısa devre deneyi anma akımında, düşük gerilimde yapılır: trafo tam yükteki bakır kaybıyla ısınır ama çekirdek neredeyse boştadır.",
              "TEDAŞ şartnamesinde kayıplar için artı tolerans yoktur: ölçülen kayıp garanti değerini geçerse trafo reddedilir. (TS EN 60076-1 genel toleransı daha geniştir.)",
              "Kısa devre köprüsünün kesiti ve bağlantısı önemlidir: binlerce amper geçer; zayıf köprü hem ısınır hem ölçümü bozar."]
        _trafo(c, f"ayarlı kaynak: {fnum(u_dev, 0)} V → {fnum(i_og, 1)} A", f"AG kısa devre: {fnum(i_ag, 0)} A", tip).kutu(60, 110, 150, 56, "Kaynak + W, A, V", f"Pk {fnum(pko, 0)} W", "acti" if pko <= pkg and abs(uko - ukg) <= 0.1 * ukg else "gecersiz")
        for k in range(3):
            c.hat(f"M210,{125 + k * 12} H{250 + k * 12} V{95 + k * 45} H324", "ariza", hot=True)
        c.hat("M576,85 H660 V161 H576", "mavi", hot=True, w=4, hot_renk="mavi").hat("M576,123 H660", "mavi", hot=True, w=4, hot_renk="mavi").yazi(672, 128, "kısa devre köprüsü", "mavi", 11, True)
        oz = [K("Uygulanan gerilim", f"{fnum(u_dev, 0)} V", "info", f"uk %{fnum(uko, 2)}"), K("OG / AG akımı", f"{fnum(i_og, 1)} / {fnum(i_ag, 0)} A", "info", "anma akımı"), K("Yük kaybı", f"{fnum(pko, 0)} W", "ok" if pko <= pkg else "bad", f"garanti {fnum(pkg, 0)} W"),
              K("AG kısa devre akımı (işletmede)", f"{fnum(i_ag / (uko / 100) / 1000, 1)} kA", "info", "In / uk")]
    elif deney == "bosta":
        p0g, i0g, p0o, i0o = num(p, "p0_g", 800), num(p, "i0_g", 1.0), num(p, "p0_o", 790), num(p, "i0_o", 1.1)
        an = [f"AG sargısına anma gerilimi (3 × 400 V, anma frekansında) uygulanır; OG uçları açık bırakılır. Çekilen akım mıknatıslanma akımıdır: anma akımının %{fnum(i0o, 2)}'i = {fnum(i0o / 100 * i_ag, 1)} A.",
              f"Sargılardan çok küçük akım geçtiği için bakır kaybı ihmal edilir; ölçülen güç çekirdek (demir) kaybıdır: {fnum(p0o, 0)} W. Trafo enerjili olduğu sürece, yük olsun olmasın bu kayıp sürer.",
              f"Garanti değerleri: P0 {fnum(p0g, 0)} W, boştaki akım %{fnum(i0g, 2)}. Ölçülen akım garanti değerinin %{fnum((i0o - i0g) / i0g * 100, 0)} üstünde.",
              f"Dikkat: bu deneyde OG uçlarında anma gerilimi ({fnum(uog / 1000, 1)} kV) oluşur. OG tarafı açık ama gerilimlidir; yaklaşma mesafeleri korunur."]
        kt = [C("Boştaki kayıp", f"{fnum(p0o, 0)} W (garanti {fnum(p0g, 0)} W)", "garanti değerini aşamaz (+ %0)", p0o <= p0g + 1e-9, f"{KS} (Toleranslar: kayıplar + %0)", "resmi"),
              C("Boştaki akım", f"%{fnum(i0o, 2)} (garanti %{fnum(i0g, 2)})", "garanti değerinin en çok %30 üstünde", i0o <= 1.30 * i0g + 1e-9, f"{KS} (Toleranslar: boştaki akım + %30); TS EN 60076-1 m.11.5", "resmi")]
        ds = ["Boştaki kayıp trafonun ömrü boyunca ödediğiniz kayıptır (yılda 8760 saat); yük kaybı ise yalnız yük kadar. Az yüklü trafoda toplam kaybın çoğu demir kaybıdır.",
              "Boştaki akım sinüs değildir (çekirdek doyma bölgesine yakın çalışır); bu yüzden gerilim ortalama değer okuyan voltmetreyle ayarlanır ve dalga biçimi düzeltmesi yapılır.",
              "Boştaki akımın ya da kaybın garantiye göre belirgin yüksek çıkması çekirdek saclarında kısa devreyi, hasarlı sac yalıtımını ya da sarım kısa devresini gösterir."]
        _trafo(c, f"OG uçları AÇIK — {fnum(uog / 1000, 1)} kV var!", "3 × 400 V a.a. (AG sargısına)", tip).kutu(690, 110, 150, 56, "Kaynak + W, A, V", f"P0 {fnum(p0o, 0)} W", "acti" if p0o <= p0g and i0o <= 1.3 * i0g else "gecersiz")
        for k in range(3):
            c.hat(f"M690,{125 + k * 12} H{650 - k * 12} V{85 + k * 38} H576", "mavi", hot=True, hot_renk="mavi")
        c.simsek(290, 80, 0.9).yazi(170, 120, "tehlikeli gerilim", "ariza", 12, True, "middle")
        oz = [K("Boştaki kayıp", f"{fnum(p0o, 0)} W", "ok" if p0o <= p0g else "bad", f"garanti {fnum(p0g, 0)} W"), K("Boştaki akım", f"%{fnum(i0o, 2)}", "ok" if i0o <= 1.3 * i0g else "bad", f"{fnum(i0o / 100 * i_ag, 1)} A (AG tarafında)"),
              K("Yıllık demir kaybı", f"{fnum(p0o * 8.76, 0)} kWh", "info", "8760 saat"), K("OG uçlarında", f"{fnum(uog / 1000, 1)} kV", "warn", "deney sırasında gerilimli")]
    elif deney == "uygulanan":
        og = p.get("sargi") != "ag"
        un_kv = float(num(p, "un_og", 33.0)); gerek = YALITIM.get(un_kv, 70) if og else 3.0
        u = num(p, "u_kv", 70); sure = num(p, "sure_u", 60)
        an = [f"Bu deney sargının toprağa ve diğer sargıya karşı ana yalıtımını sınar. {'OG' if og else 'AG'} sargısının bütün uçları birbirine bağlanır ve ayrı bir deney trafosundan {fnum(gerek, 0)} kV, 50 Hz gerilim uygulanır.",
              f"{'AG' if og else 'OG'} sargısının bütün uçları da birbirine bağlanır ve tankla (kuru tipte şase ve çekirdekle) birlikte topraklanır. Sargının bütün noktaları aynı gerilimdedir: sarımlar arasında gerilim yoktur.",
              f"Gerilim 60 saniye tutulur. Kabul: gerilimde çökme ve yıkıcı boşalma olmaması. Uygulanan: {fnum(u, 1)} kV, {fnum(sure, 0)} s.",
              "AG sargısı için deney gerilimi 3 kV'tur; OG sargısı için anma gerilimine göre 20 / 28 / 38 / 70 kV."]
        kt = [C("Deney gerilimi", f"{fnum(u, 1)} kV ({'OG' if og else 'AG'} sargısı)", f"{fnum(gerek, 0)} kV, 1 dakika", abs(u - gerek) <= 0.03 * gerek, f"{KS} (Anma Yalıtım Düzeyleri); TS EN 60076-3", "resmi"),
              C("Deney süresi", f"{fnum(sure, 0)} s", "60 s", abs(sure - 60) < 1, "TS EN 60076-3 (uygulanan gerilim deneyi)", D)]
        ds = ["Uygulanan gerilim deneyi ana yalıtımı (sargı–toprak, sargı–sargı), endüklenen gerilim deneyi ise sarımlar ve fazlar arası yalıtımı sınar. İkisi birbirini tamamlar.",
              "Deneyden önce yalıtım direnci ölçülür; nemli bir trafoya 70 kV uygulanmaz.",
              "Tekrarlanan dayanım deneylerinde (kabulde, sahada) gerilim %80'e indirilir: her deney yalıtımı biraz yaşlandırır."]
        _trafo(c, "", "", tip).kutu(40, 110, 170, 56, "Deney trafosu", f"{fnum(u, 1)} kV · 50 Hz", "acti" if abs(u - gerek) <= 0.03 * gerek else "gecersiz")
        if og:
            c.hat("M210,138 H280 V95 H324", "ariza", hot=True).hat("M330,95 V185", "ariza", w=4).hat("M576,85 V199", "PE", w=4).hat("M576,199 H640 V262", "PE", kesik=True).toprak(640, 262).yazi(650, 150, "AG uçları köprülü + topraklı", "PE", 11, True)
            c.yazi(170, 90, "OG uçları köprülü", "ariza", 11, True, "middle")
        else:
            c.hat("M210,138 H240 V30 H660 V85 H576", "ariza", hot=True).hat("M576,85 V199", "ariza", w=4).hat("M330,95 V185", "PE", w=4).hat("M324,185 H280 V262", "PE", kesik=True).toprak(280, 262).yazi(170, 200, "OG uçları köprülü + topraklı", "PE", 11, True, "middle")
        oz = [K("Gereken gerilim", f"{fnum(gerek, 0)} kV", "info", "OG sargısı" if og else "AG sargısı"), K("Uygulanan", f"{fnum(u, 1)} kV", "ok" if abs(u - gerek) <= 0.03 * gerek else "bad", ""), K("Süre", f"{fnum(sure, 0)} s", "ok" if abs(sure - 60) < 1 else "bad", "60 s")]
    elif deney == "enduklenen":
        f = num(p, "f_hz", 150); sure = num(p, "sure_s", 40)
        t_gerek = max(15.0, 120.0 * 50.0 / f)
        an = [f"AG sargısına anma geriliminin iki katı (2 × 400 = 800 V) uygulanır; OG uçları açıktır. OG sargısında da iki kat gerilim endüklenir: her sarım, her katman ve fazlar arası yalıtım iki kat gerilimle sınanır.",
              f"50 Hz'de iki kat gerilim çekirdeği doyurur. Akı gerilim / frekans ile orantılı olduğundan frekans da en az iki katına çıkarılır: burada {fnum(f, 0)} Hz. " + ("50 Hz'de bu deney yapılamaz: mıknatıslanma akımı çok büyür." if f < 100 else ""),
              f"Deney süresi frekansa göre kısalır: t = 120 × (anma frekansı / deney frekansı) saniye, en az 15 s → {fnum(t_gerek, 0)} s. Uygulanan: {fnum(sure, 0)} s."]
        kt = [C("Deney frekansı", f"{fnum(f, 0)} Hz", "en az 2 × anma frekansı (100 Hz)", f >= 100, "TS EN 60076-3 (endüklenmiş gerilim deneyi)", D),
              C("Deney süresi", f"{fnum(sure, 0)} s", f"120 × fn / f = {fnum(t_gerek, 0)} s (en az 15 s)", abs(sure - t_gerek) <= 1.0, "TS EN 60076-3", D),
              C("Deney gerilimi", "2 × Un (AG'den 800 V)", "anma geriliminin iki katı; OG'de karşılığı " + f"{fnum(2 * uog / 1000, 0)} kV", True, f"{KS} (kısa süreli endüklenmiş a.a. gerilim deneyi)", "resmi")]
        ds = ["Sarımlar arası yalıtım başka hiçbir rutin deneyle sınanmaz; sarım kısa devresi olan trafo bu deneyde akım çekerek kendini belli eder.",
              "Deney için 100–200 Hz'lik bir kaynak (motor–jeneratör grubu ya da statik frekans çevirici) gerekir; her atölyede bulunmaz.",
              "Kuru tip trafoda kısmi boşalma ölçümü çoğu zaman bu deneyle aynı düzenekte, hemen ardından yapılır."]
        _trafo(c, f"OG uçları açık — {fnum(2 * uog / 1000, 0)} kV endüklenir", f"800 V, {fnum(f, 0)} Hz (AG sargısına)", tip).kutu(690, 110, 150, 56, "Frekans çevirici", f"800 V · {fnum(f, 0)} Hz", "acti" if f >= 100 else "gecersiz")
        for k in range(3):
            c.hat(f"M690,{125 + k * 12} H{650 - k * 12} V{85 + k * 38} H576", "mavi", hot=True, hot_renk="mavi")
        oz = [K("Deney frekansı", f"{fnum(f, 0)} Hz", "ok" if f >= 100 else "bad", "≥ 100 Hz"), K("Gereken süre", f"{fnum(t_gerek, 0)} s", "info", "120 · fn / f"), K("OG'de endüklenen", f"{fnum(2 * uog / 1000, 0)} kV", "warn", "2 × Un")]
    elif deney == "megger":
        r15, r60 = num(p, "r15", 9), num(p, "r60", 15); th = num(p, "sicaklik", 22)
        dar = r60 / r15; r20 = r60 * 2 ** ((th - 20) / 10)
        an = ["Üç ölçüm yapılır: OG sargısı – tank ve OG – AG arası 5000 V d.a. ile, AG sargısı – tank 2500 V d.a. ile. Ölçülen sargının uçları köprülenir; diğer sargı ve tank megger'in toprak ucuna bağlanır.",
              f"Okumalar 0, 15, 30, 45 ve 60. saniyelerde alınır: 15 s'de {fnum(r15, 1)} GΩ, 60 s'de {fnum(r60, 1)} GΩ; soğurma oranı R60/R15 = {fnum(dar, 2)}.",
              f"Değerler 20 °C'ye indirgenir (yalıtım direnci yaklaşık her 10 °C'de yarıya iner): {fnum(th, 0)} °C'de {fnum(r60, 1)} GΩ → 20 °C'de ≈ {fnum(r20, 1)} GΩ. 30. ve 60. saniye değerleri işaret plakasına yazılır.",
              "Şartname bir alt sınır vermez; plakadaki fabrika değeri, sahada ve ileriki yıllarda yapılacak ölçümlerin karşılaştırma değeridir."]
        kt = [C("Ölçüm gerilimleri ve süreleri", "OG–tank ve OG–AG: 5000 V ; AG–tank: 2500 V ; 0/15/30/45/60 s", "şartnamedeki gibi; sonuçlar 20 °C'ye indirgenir", True, f"{KH} m.3.2 (yalıtım direncinin ölçülmesi)", "resmi"),
              C("Soğurma oranı R60 / R15", fnum(dar, 2), "≥ 1,3 (kuru yalıtım); 1'e yakınsa nem şüphesi", dar >= 1.3 - 1e-9, "Uygulama yorum ölçütü", "ikincil")]
        ds = ["Fabrika değeriyle karşılaştırma aynı sıcaklığa indirgenerek yapılır; yarıdan fazla düşüş nem alındığını gösterir (hermetik trafoda conta, kuru tipte depolama).",
              "Kuru tip trafo neme açıktır: uzun süre enerjisiz bekleyen kuru trafo, enerjilenmeden önce megger ile ölçülür ve gerekirse kurutulur.",
              "Ölçümden sonra sargı toprağa boşaltılır."]
        _trafo(c, "megger: OG uçları köprülü", "AG köprülü + tank → megger toprak ucu", tip).cihaz(50, 112, f"{fnum(r60, 1)} GΩ", "megger 5000 V d.a.", dar >= 1.3, 150)
        c.hat("M200,130 H280 V95 H324", "ariza", hot=True).hat("M330,95 V185", "ariza", w=4).hat("M576,85 V199", "PE", w=4).hat("M576,199 H610 V262", "PE", kesik=True).toprak(610, 262)
        graf = [{"baslik": "Yalıtım direncinin zamanla değişimi", "x_ad": "zaman (s)", "y_ad": "direnç (GΩ)", "zaman": True, "seriler": [{"ad": "OG – tank", "renk": "#1a4d8f", "pts": [[0, r15 * 0.6], [15, r15], [30, r15 + (r60 - r15) * 0.55], [45, r15 + (r60 - r15) * 0.82], [60, r60]]}], "ymin": 0}]
        oz = [K("R (60 s)", f"{fnum(r60, 1)} GΩ", "info", f"{fnum(th, 0)} °C'de"), K("20 °C'ye indirgenmiş", f"{fnum(r20, 1)} GΩ", "info", "plaka değeriyle karşılaştırılır"), K("R60 / R15", fnum(dar, 2), "ok" if dar >= 1.3 else "bad", "soğurma oranı")]
    elif deney == "pd":
        pd = num(p, "pd_pc", 6); un = float(num(p, "un_og", 33.0))
        um = {6.3: 7.2, 10.5: 12.0, 15.8: 17.5, 33.0: 36.0, 34.5: 36.0}.get(un, 36.0)
        an = ["Dökme reçineli sargıda yalıtım katıdır: içinde kalan bir hava kabarcığı ya da çatlak kendini onarmaz, kısmi boşalma orada yıllarca sürer ve reçineyi oyar. Bu yüzden kuru tip trafoda kısmi boşalma ölçümü rutin deneydir.",
              f"Yöntem: gerilim AG sargısından endüklenerek verilir (yükseltilmiş frekansla). Önce ön gerilim uygulanır (1,8 × Ur, 30 s), sonra ölçme gerilimine inilir (1,3 × Ur, 3 dakika) ve boşalma düzeyi okunur. Ur = {fnum(un, 1)} kV için: {fnum(1.8 * un, 1)} kV ve {fnum(1.3 * un, 1)} kV (faz arası).",
              f"Ölçülen: {fnum(pd, 0)} pC. Şartnamenin sınırı 10 pC'dir.",
              "Yağlı trafoda bu ölçüm dağıtım trafoları için rutin değildir: yağ boşlukları doldurur ve küçük boşalmaların izini siler."]
        kt = [C("Kısmi boşalma düzeyi", f"{fnum(pd, 0)} pC", "≤ 10 pC", pd <= 10 + 1e-9 if tip == "kuru" else None, f"{KK} m.2.2.15 (Kısmi boşalmanın en yüksek değeri 10 pC)", "resmi"),
              C("Deney yöntemi", "ön gerilim 1,8·Ur / 30 s → ölçme 1,3·Ur / 3 dk", "TS EN 60076-11 ve TS EN 60270'e göre; akredite laboratuvarda", None, f"{KK} m.3.2; TS EN 60076-11 m.22", D)]
        if tip != "kuru":
            kt.append(C("Deneyin geçerliliği", "yağlı trafo seçili", "kısmi boşalma ölçümü kuru tip trafoların rutin deneyidir", None, f"{KK} m.3.2", "resmi"))
        ds = ["10 pC çok küçük bir değerdir; ölçüm ekranlı odada, gürültüsüz kaynakla yapılır. Arka plan gürültüsü sınırın yarısından küçük olmalıdır.",
              "Kuru tip trafo taşımada ve montajda darbe almışsa (reçinede çatlak) fabrikadaki değer geçerli olmayabilir; şüphe varsa sahada tekrar ölçülür.",
              "Kısmi boşalması düşük trafo, aynı zamanda nem ve kirden uzak tutulmalıdır: yüzeyde biriken iletken toz, yüzey boşalmasına ve iz oluşumuna yol açar."]
        _trafo(c, "kuplaj kondansatörü + ölçü empedansı (OG ucunda)", "yükseltilmiş frekanslı kaynak (AG sargısına)", tip).cihaz(50, 112, f"{fnum(pd, 0)} pC", "kısmi boşalma ölçer", pd <= 10, 150).hat("M200,130 H280 V95 H324", "ariza", hot=True)
        oz = [K("Ölçülen boşalma", f"{fnum(pd, 0)} pC", "ok" if pd <= 10 else "bad", "sınır 10 pC"), K("Ölçme gerilimi", f"{fnum(1.3 * un, 1)} kV", "info", "1,3 × Ur, 3 dk"), K("Ön gerilim", f"{fnum(1.8 * un, 1)} kV", "info", "1,8 × Ur, 30 s"), K("Um", f"{fnum(um, 1)} kV", "info", "en yüksek sistem gerilimi")]
    else:
        bdv = num(p, "bdv", 65)
        an = ["Yağ numunesi, 2,5 mm aralıklı iki elektrot arasına konur; gerilim saniyede 2 kV hızla atlama olana kadar artırılır. Altı ölçüm yapılır ve ortalaması alınır.",
              f"Ölçülen ortalama delinme gerilimi {fnum(bdv, 0)} kV. Yeni ve işlem görmüş yağda 60 kV ve üstü beklenir; 30 kV'un altı yağın nem ya da parçacıkla kirlendiğini gösterir.",
              "Delinme gerilimini en çok düşüren sudur: milyonda birkaç on parça nem değeri yarıya indirir. Bu yüzden numune kuru, temiz bir şişeye, havayla temas ettirmeden alınır.",
              "Şartnameye göre yağ deneyleri teslimat kapsamından seçilen bir trafodan alınan numunede yapılır: delinme gerilimi, su miktarı, iç yüzey gerilimi, nötralizasyon sayısı ve güç faktörü (25 °C ve 100 °C'de)."]
        kt = [C("Delinme gerilimi (2,5 mm)", f"{fnum(bdv, 0)} kV", "yeni yağ, doldurulmuş trafoda ≥ 55 kV (Um ≤ 72,5 kV); işletmede ≥ 30–40 kV", (bdv >= 55) if tip == "yagli" else None, "TS EN 60156 (yöntem); TS EN 60422 (yorum sınırları); ilgili yağ şartnamesi", D),
              C("Yağ deneylerinin kapsamı", "delinme gerilimi, su miktarı, iç yüzey gerilimi, nötralizasyon sayısı, güç faktörü", "teslimattan seçilen bir trafodan alınan numunede", None, f"{KH} m.3.2 (yalıtım yağı deneyleri)", "resmi")]
        if tip != "yagli":
            kt.append(C("Deneyin geçerliliği", "kuru tip trafo seçili", "yağ deneyi yalnız yağlı trafolarda yapılır", None, f"{KH}", "resmi"))
        ds = ["Hermetik trafoda yağ havayla temas etmez; yağ numunesi almak contayı açmak demektir ve yalnız gerektiğinde yapılır.",
              "Delinme gerilimi yağın o andaki temizliğini gösterir; yaşlanmayı asit sayısı, iç yüzey gerilimi ve güç faktörü gösterir.",
              "Düşük delinme gerilimli yağ filtrelenip kurutularak düzeltilebilir; yüksek asitli yağ değiştirilir ya da rejenere edilir."]
        c.dikdortgen(330, 80, 240, 130, "#334155", "#fef9c3", 2.2).hat("M410,145 H440", "cizgi", w=5).hat("M460,145 H490", "cizgi", w=5).yazi(450, 118, "elektrot aralığı 2,5 mm", "#475569", 10.5, False, "middle").simsek(444, 136, 0.7)
        c.yazi(450, 72, "yağ deney kabı", "#334155", 11.5, True, "middle").cihaz(60, 118, f"{fnum(bdv, 0)} kV", "yağ delinme test cihazı", bdv >= 55, 160).hat("M220,144 H410", "ariza", hot=True).hat("M490,145 H640 V262", "PE", kesik=True).toprak(640, 262)
        oz = [K("Delinme gerilimi", f"{fnum(bdv, 0)} kV", "ok" if bdv >= 55 else "warn" if bdv >= 30 else "bad", "2,5 mm, 6 ölçümün ortalaması"), K("Yorum", "kuru ve temiz" if bdv >= 55 else "nem / parçacık", "ok" if bdv >= 55 else "bad", "")]
    rutin = {"baslik": "Dağıtım trafolarında deneyler — yağlı ve kuru tip", "cols": ["Deney", "Yağlı (hermetik)", "Kuru tip", "Sınır / tolerans"], "rows": [
        ["Sargı direncinin ölçülmesi", "rutin", "rutin", "değer kaydedilir (kayıp ve ısınma hesabının temeli)"], ["Çevirme oranı ve bağlantı grubu", "rutin", "rutin", "± %0,5 (ana kademe); Dyn11"],
        ["Kısa devre empedansı ve yük kaybı", "rutin", "rutin", "uk ± %10; kayıp + %0"], ["Boştaki kayıp ve akım", "rutin", "rutin", "kayıp + %0; akım + %30"],
        ["Ayrı kaynaklı a.a. dayanım gerilimi", "rutin", "rutin", "OG 20 / 28 / 38 / 70 kV; AG 3 kV; 1 dk"], ["Endüklenmiş a.a. gerilim", "rutin", "rutin", "2 × Un, ≥ 100 Hz, 120·fn/f s"],
        ["Yalıtım direnci", "rutin", "—", "AG–tank 2500 V; YG–tank, YG–AG 5000 V; 20 °C'ye indirgenir; plakaya yazılır"], ["Kayıp faktörü (tan δ)", "≥ 630 kVA, istenmişse", "—", "20 °C'ye indirgenir"],
        ["Kısmi boşalma", "—", "rutin", "≤ 10 pC"], ["Basınçla yağ kaçağı (sızdırmazlık)", "rutin", "—", "kaçak olmamalı"], ["Yalıtım yağı deneyleri", "numune üzerinde", "—", "ilgili yağ şartnamesine göre"],
        ["Sıcaklık artışı (ısınma)", "tip", "tip", "kuru: F sınıfı 100 K, H sınıfı 125 K (sargı)"], ["Yıldırım darbe", "tip", "tip", "60 / 75 / 95 / 170 kV tepe"], ["Ses gücü düzeyi", "tip", "tip", "şartname çizelgesi"]],
        "not": f"{KH} m.2.2, m.3 ; {KK} m.2.2, m.3 — durum: resmi. Deney yöntemleri TS EN 60076-1 / -2 / -3 / -11."}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "grafikler": graf, "tablolar": [rutin]}
