"""Laboratuvar konusu — yönlü koruma: faz yönlü aşırı akım (67) ve yönlü toprak (67N).

Faz elemanı (90° bağlantı): her faz akımı, diğer iki fazın arasındaki gerilimle kutuplanır (Ia ↔ Vbc, Ib ↔ Vca, Ic ↔ Vab).
  θ = arg(I) − arg(Vkutup) ;  röle ileri yönü görür  ⇔  cos(θ − RCA) > 0   (RCA: karakteristik açı = en büyük tork açısı)
  hat açısı φ olan ileri yöndeki üç fazlı arızada θ = 90° − φ ; en duyarlı ayar RCA = 90° − φ
Toprak elemanı: kutuplama büyüklüğü −V0 (artık gerilimin tersi). Birim V0 için fiderlerin artık akımları:
  sağlam fider   3I0 = IC,kendi ∠ −90°                              (kendi kapasitif akımı, baradan hatta)
  arızalı fider  3I0 = IC,diğerleri ∠ +90° + IN                     (diğer fiderlerin kapasitif akımı + yıldız noktası akımı)
  IN: direnç → ∠0° ; bobin → ∠ −90° (kapasitifi götürür) + küçük aktif bileşen ∠0° ; doğrudan → ∠ −(hat açısı)
  çalışma büyüklüğü I·cos(θ − RCA): yalıtılmış şebekede RCA = +90° (sin φ), bobinli ve dirençli şebekede 0° (cos φ), doğrudan topraklıda ≈ −60°
Resmi: TEDAŞ-MLZ/96-027.D (fider yönetim rölelerinde 67 / 67N; en büyük tork açısı ±90° ayarlanabilir; yön ileri / geri; akım ve zaman ayar aralıkları),
Elektrik Tesisleri Kabul Yön. m.28-D-6c (primer enjeksiyonla oran ve polarite denetimi). Karakteristik açı önerileri: ikincil (röle üreticisi uygulama kılavuzları)."""
from __future__ import annotations

import cmath
import math

from .cizim import Cizim
from .core import A120, C, K, ctl, fazor, fnum, num, opt

ID = "yonlu"
BASLIK = "Yönlü koruma (67 / 67N)"
IKON = "🧭"
GIRIS = ("Aşırı akım rölesi akımın büyüklüğüne bakar; yönlü röle bir de nereden geldiğine. Paralel fiderlerde, halka şebekede ve üretim bağlı fiderlerde seçiciliği bu sağlar. "
         "Yönü röle, akımı bir gerilimle karşılaştırarak bulur: karakteristik açı, kutuplama gerilimi ve ölçü trafolarının polaritesi doğru değilse röle ters yöne bakar.")
R27 = "TEDAŞ-MLZ/96-027.D"
KABUL = "Elektrik Tesisleri Kabul Yön. m.28-D-6c (primer enjeksiyon deneyi: oran, polarite, sekonder bağlantı)"
NOTR = {"yalitilmis": "Yalıtılmış", "bobin": "Rezonans topraklı (Petersen bobini)", "direnc": "Direnç üzerinden topraklı", "dogrudan": "Doğrudan topraklı"}
KAR = {"sin": "I0·sin φ (kapasitif bileşen; RCA = +90°)", "cos": "I0·cos φ (aktif bileşen; RCA = 0°)", "aci": "Açı ayarlı (RCA aşağıdan)"}
UYGUN = {"yalitilmis": (60, 90), "bobin": (-20, 20), "direnc": (0, 60), "dogrudan": (-80, -30)}      # önerilen RCA aralığı (°)

KONTROLLER = [
    ctl("fonksiyon", "Koruma fonksiyonu", "sec", "faz", secenek=opt(("faz", "Faz yönlü aşırı akım (67)"), ("toprak", "Yönlü toprak (67N)"))),
    # faz
    ctl("uygulama", "Şebeke", "sec", "paralel", secenek=opt(("paralel", "İki paralel fider (röle karşı uçta)"), ("uretim", "Üretim (GES / jeneratör) bağlı fider")), goster={"fonksiyon": ["faz"]}),
    ctl("yon", "Arızanın yeri (röleye göre)", "sec", "ileri", secenek=opt(("ileri", "İleri yönde (korunan hat üzerinde)"), ("geri", "Geri yönde (rölenin arkasında)")), goster={"fonksiyon": ["faz"]}),
    ctl("ariza", "Arıza türü", "sec", "3faz", secenek=opt(("3faz", "Üç fazlı"), ("2faz", "İki fazlı (L2 – L3)")), goster={"fonksiyon": ["faz"]}),
    ctl("hat_acisi", "Arıza çevriminin açısı φ (akım gerilimden geri)", "sayi", 60, min=20, max=85, adim=1, birim="°", goster={"fonksiyon": ["faz"]}, yardim="kablo ≈ 30–45° · havai hat ≈ 60–75° · trafo arkası ≈ 80°"),
    ctl("u_pct", "Arıza sırasında röle yerindeki gerilim", "sayi", 30, min=0, max=100, adim=1, birim="%", goster={"fonksiyon": ["faz"]}, yardim="rölenin hemen önündeki arızada sıfıra yaklaşır"),
    ctl("rca", "Karakteristik açı RCA (en büyük tork açısı)", "sayi", 30, min=-90, max=90, adim=5, birim="°", goster={"fonksiyon": ["faz"]}, yardim="akımın kutuplama geriliminden ileride olduğu açı; 90° bağlantıda tipik +30° / +45°"),
    ctl("ayar_yon", "Rölenin açma yönü ayarı", "sec", "ileri", secenek=opt(("ileri", "İleri (hat yönü)"), ("geri", "Geri (bara yönü)")), goster={"fonksiyon": ["faz"]}),
    ctl("i_kat", "Arıza akımı / akım ayarı", "sayi", 5, min=0.2, max=20, adim=0.1, goster={"fonksiyon": ["faz"]}),
    ctl("at_ters", "Akım trafosu polaritesi ters (S1 – S2 yer değiştirmiş ya da P1 ters yönde)", "onay", False, goster={"fonksiyon": ["faz"]}),
    ctl("gt_ters", "Gerilim trafosu polaritesi ters", "onay", False, goster={"fonksiyon": ["faz"]}),
    ctl("gt_sigorta", "Gerilim trafosu sigortası atık (röleye gerilim gelmiyor)", "onay", False, goster={"fonksiyon": ["faz"]}),
    ctl("hafiza", "Rölede gerilim hafızası var", "onay", True, goster={"fonksiyon": ["faz"]}),
    # toprak
    ctl("notr", "Şebekenin yıldız noktası", "sec", "direnc", secenek=opt(*NOTR.items()), goster={"fonksiyon": ["toprak"]}),
    ctl("kar", "Rölenin yön karakteristiği", "sec", "cos", secenek=opt(*KAR.items()), goster={"fonksiyon": ["toprak"]}),
    ctl("rca_n", "Karakteristik açı RCA", "sayi", 0, min=-90, max=90, adim=5, birim="°", goster={"fonksiyon": ["toprak"], "kar": ["aci"]}),
    ctl("ic_bu", "Sağlam fiderin kapasitif akımı (3·I0)", "sayi", 5, min=0.2, max=60, adim=0.2, birim="A", goster={"fonksiyon": ["toprak"]}),
    ctl("ic_diger", "Diğer bütün fiderlerin kapasitif akımı", "sayi", 40, min=1, max=300, adim=1, birim="A", goster={"fonksiyon": ["toprak"]}),
    ctl("ir_a", "Yıldız noktası direncinin akımı", "sayi", 1000, min=10, max=2000, adim=10, birim="A", goster={"fonksiyon": ["toprak"], "notr": ["direnc"]}),
    ctl("komp", "Bobinin ayarı (bobin akımı / toplam kapasitif akım)", "sayi", 105, min=70, max=130, adim=1, birim="%", goster={"fonksiyon": ["toprak"], "notr": ["bobin"]}),
    ctl("iw_a", "Aktif bileşen (bobin kaybı + paralel direnç)", "sayi", 8, min=0, max=50, adim=0.5, birim="A", goster={"fonksiyon": ["toprak"], "notr": ["bobin"]}),
    ctl("ik1_a", "Faz–toprak kısa devre akımı", "sayi", 2000, min=200, max=16000, adim=100, birim="A", goster={"fonksiyon": ["toprak"], "notr": ["dogrudan"]}),
    ctl("v0_pct", "Artık gerilim (arıza direncine bağlı)", "sayi", 100, min=1, max=100, adim=1, birim="%", goster={"fonksiyon": ["toprak"]}, yardim="madeni arızada %100; dirençli arızada düşer"),
    ctl("i0_ayar", "Toprak akım ayarı (primer)", "sayi", 2, min=0.2, max=200, adim=0.1, birim="A", goster={"fonksiyon": ["toprak"]}),
    ctl("v0_ayar", "Artık gerilim eşiği", "sayi", 10, min=1, max=50, adim=1, birim="%", goster={"fonksiyon": ["toprak"]}),
    ctl("at_ters_n", "Arızalı fiderin toroidi ters takılmış (ya da sekonderi ters bağlı)", "onay", False, goster={"fonksiyon": ["toprak"]}),
    ctl("gt_ters_n", "Açık üçgen sargının polaritesi ters", "onay", False, goster={"fonksiyon": ["toprak"]}),
]


def _ac(z: complex) -> float:
    return math.degrees(cmath.phase(z))


def _norm(a: float) -> float:
    while a > 180:
        a -= 360
    while a <= -180:
        a += 360
    return a


def faz_elemani(ariza: str, yon: str, phi: float, u_pct: float, at_ters: bool = False, gt_ters: bool = False) -> dict:
    """90° bağlantılı faz elemanı: akım, kutuplama gerilimi (Un'in katı) ve aralarındaki açı θ (akım ileride ise +)."""
    k = u_pct / 100
    ea, eb, ec = 1 + 0j, A120 ** 2, A120
    f = cmath.exp(-1j * math.radians(phi))
    if ariza == "2faz":                                     # L2 – L3 arızası; incelenen eleman L2
        va = ea; vb = (1 - k) * (-ea / 2) + k * eb; vc = (1 - k) * (-ea / 2) + k * ec
        i = (eb - ec) / abs(eb - ec) * f
        vp = vc - va; ad_i, ad_v = "I2", "V31"
        onc = ec - ea
    else:
        va, vb, vc = k * ea, k * eb, k * ec
        i = ea * f
        vp = vb - vc; ad_i, ad_v = "I1", "V23"
        onc = eb - ec
    if yon == "geri":
        i = -i
    if at_ters:
        i = -i
    if gt_ters:
        vp = -vp; onc = -onc
    return {"i": i, "vp": vp, "vp_onc": onc, "vp_pct": abs(vp) / math.sqrt(3) * 100, "va": va, "vb": vb, "vc": vc, "ad_i": ad_i, "ad_v": ad_v}


def faz_karar(E: dict, rca: float, hafiza: bool, sigorta: bool, esik_pct: float = 2.0) -> dict:
    """Yön kararı: kutuplama gerilimi yeterliyse ölçülen gerilimle, değilse (hafıza varsa) arıza öncesi gerilimle."""
    vp_pct = 0.0 if sigorta else E["vp_pct"]
    if vp_pct >= esik_pct:
        vp = E["vp"]; kaynak = "olculen"
    elif hafiza and not sigorta:
        vp = E["vp_onc"]; kaynak = "hafiza"
    else:
        return {"var": False, "theta": None, "ileri": None, "kaynak": "yok", "vp_pct": vp_pct}
    th = _norm(_ac(E["i"]) - _ac(vp))
    return {"var": True, "theta": th, "ileri": math.cos(math.radians(th - rca)) > 0, "kaynak": kaynak, "vp_pct": vp_pct, "pay": 90 - abs(_norm(th - rca)), "vp": vp}


def toprak_akimlari(notr: str, ic_bu: float, ic_diger: float, ir: float = 0.0, komp: float = 100.0, iw: float = 0.0, ik1: float = 0.0, v0: float = 1.0) -> tuple[complex, complex]:
    """−V0 referans (∠0°) alınarak arızalı ve sağlam fiderin artık akımları (A)."""
    if notr == "direnc":
        i_n = complex(ir, 0)
    elif notr == "bobin":
        i_n = complex(iw, -komp / 100 * (ic_bu + ic_diger))
    elif notr == "dogrudan":
        i_n = ik1 * cmath.exp(-1j * math.radians(70))
    else:
        i_n = 0j
    return v0 * (complex(0, ic_diger) + i_n), v0 * complex(0, -ic_bu)


def _faz(p: dict) -> dict:
    yon = "geri" if p.get("yon") == "geri" else "ileri"
    ariza = "2faz" if p.get("ariza") == "2faz" else "3faz"
    phi = num(p, "hat_acisi", 60); rca = num(p, "rca", 30); ikat = num(p, "i_kat", 5)
    at_t, gt_t, sig, haf = bool(p.get("at_ters")), bool(p.get("gt_ters")), bool(p.get("gt_sigorta")), bool(p.get("hafiza"))
    ayar = "geri" if p.get("ayar_yon") == "geri" else "ileri"
    uyg = "uretim" if p.get("uygulama") == "uretim" else "paralel"
    E = faz_elemani(ariza, yon, phi, num(p, "u_pct", 30), at_t, gt_t)
    Kr = faz_karar(E, rca, haf, sig)
    ideal = faz_karar(faz_elemani(ariza, "ileri", phi, 100), rca, True, False)     # doğru bağlantıda ileri arızanın açısı ve payı
    gercek_ileri = yon == "ileri"
    beklenen = gercek_ileri and ikat >= 1                    # korunan hat rölenin ileri yönündedir: yalnız ileri arızada açmalı
    acar = bool(Kr["var"]) and ((Kr["ileri"]) == (ayar == "ileri")) and ikat >= 1
    kt, an = [], []
    an.append(f"Röle, {E['ad_i']} akımını {E['ad_v']} gerilimiyle karşılaştırır (90° bağlantı: her faz akımı, diğer iki fazın arasındaki gerilimle kutuplanır). Bu seçimin nedeni: arızalı fazın gerilimi çöker, diğer iki fazın arasındaki gerilim "
              "tek ve iki fazlı arızalarda ayakta kalır.")
    an.append(f"İleri yöndeki arızada akım, kendi faz geriliminden φ = {fnum(phi, 0)}° geridedir; kutuplama gerilimi ise faz geriliminden 90° geridedir. Sonuç: akım, kutuplama geriliminden θ = 90° − φ = {fnum(90 - phi, 0)}° ileridedir"
              + (" (iki fazlı arızada, arızanın uzaklığına göre 30°'ye kadar kayar)." if ariza == "2faz" else ".") + f" Röle, karakteristik açısı RCA = {fnum(rca, 0)}° çevresindeki ± 90°'lik bölgeyi “ileri” sayar.")
    if Kr["var"]:
        an.append(f"Bu durumda ölçülen açı θ = {fnum(Kr['theta'], 0)}°" + (" (kutuplama gerilimi çok düşük: yön, hafızadaki arıza öncesi gerilimle belirlendi)" if Kr["kaynak"] == "hafiza" else "") +
                  f" → röle arızayı {'ileri' if Kr['ileri'] else 'geri'} yönde görüyor; bölge sınırına uzaklık {fnum(Kr['pay'], 0)}°. Arıza gerçekte {'ileri' if gercek_ileri else 'geri'} yönde.")
    else:
        an.append("Röleye kutuplama gerilimi gelmiyor" + (" (gerilim trafosu sigortası atık)" if sig else " (rölenin hemen önünde üç fazlı arıza: üç faz gerilimi de çökmüş) ve gerilim hafızası yok") + ": röle yönü belirleyemez. "
                  "Yönlü eleman bloke olur; gerilim sigortası denetimi (FL) bu durumu ihbar eder ve ayara göre eleman yönsüz çalışmaya geçirilir.")
    if at_t and gt_t:
        an.append("Hem akım hem gerilim trafosunun polaritesi ters: iki hata birbirini götürür ve yön doğru çıkar. Ama aynı röledeki güç ve enerji ölçümü de, başka bir cihaza giden akım devresi de ters kalır; hata gizlenmiştir, giderilmemiştir.")
    elif at_t or gt_t:
        an.append(f"{'Akım' if at_t else 'Gerilim'} trafosunun polaritesi ters: röle akımı 180° dönmüş görür. İleri arızayı geri, geri arızayı ileri sayar: korunan hattaki arızada açmaz, komşu hattaki arızada açar.")
    if uyg == "paralel":
        an.append("İki paralel fiderde yönsüz röleler seçici olamaz: bir fiderdeki arızayı sağlam fider de karşı baradan besler ve iki fiderin karşı uçtaki röleleri aynı akımı görür. Karşı uçtaki röleler yönlü yapılır ve hatta doğru bakar: "
                  "arızalı fiderin rölesi akımı ileri görür ve açar; sağlam fiderin rölesi aynı akımı geri görür ve bekler.")
    else:
        an.append("Üretim bağlı fiderde komşu fiderdeki arızayı üretim tesisi de besler: akım, üretim fiderinin başındaki röleden baraya doğru (geri yönde) akar. Yönsüz röle bu akımla açar ve sağlam fider kaybedilir; "
                  "yönlü eleman yalnız fiderin kendisindeki (ileri yöndeki) arızada açar.")
    kt.append(C("Yön kararı", (f"θ = {fnum(Kr['theta'], 0)}° ; bölge {fnum(rca - 90, 0)}° … {fnum(rca + 90, 0)}° → {'ileri' if Kr['ileri'] else 'geri'}") if Kr["var"] else "kutuplama gerilimi yok: yön belirlenemiyor",
                f"arıza gerçekte {'ileri' if gercek_ileri else 'geri'} yönde", bool(Kr["var"]) and Kr["ileri"] == gercek_ileri, "Yönlü aşırı akım elemanının çalışma ilkesi (90° bağlantı); TS EN 60255-151 ile birlikte röle üreticisi belgeleri", "ikincil"))
    kt.append(C("Açma kararı", ("röle açıyor" if acar else "röle açmıyor") + f" (ayar: {'ileri' if ayar == 'ileri' else 'geri'} yön)", "korunan hattaki (ileri yöndeki) arızada açmalı; arkadaki arızada açmamalı → " + ("açmalı" if beklenen else "açmamalı"), acar == beklenen,
                R27 + " Çizelge 5 (yön: ileri / geri), Çizelge 6 (67 / 67N)", "resmi"))
    kt.append(C("Yön ayarı", "ileri (hat yönü)" if ayar == "ileri" else "geri (bara yönü)", "korunan hat yönü: ileri", ayar == "ileri", R27 + " Çizelge 5 (yön: ileri / geri)", "resmi"))
    kt.append(C("Akım trafosu polaritesi", "ters" if at_t else "doğru", "P1 baraya, P2 hatta bakar; S1 rölenin polarite ucuna gider. Primer enjeksiyonla doğrulanır", not at_t, KABUL, "resmi"))
    kt.append(C("Gerilim trafosu polaritesi ve faz sırası", "ters" if gt_t else "doğru", "sekonder uçlar ve faz sırası şemaya uygun; yük altında P ve Q'nun işaretiyle denetlenir", not gt_t, KABUL + "; Elektrik Tesisleri Kabul Yön. m.28-D-6c (sekonder enjeksiyonla bağlantı denetimi)", "resmi"))
    kt.append(C("Kutuplama gerilimi", f"%{fnum(Kr['vp_pct'], 0)} Un" + (" — hafıza kullanıldı" if Kr["kaynak"] == "hafiza" else ""), "≥ ≈ %2 Un; altındaysa gerilim hafızası gerekir; gerilim trafosu sigortası denetlenir (FL)", bool(Kr["var"]),
                R27 + " Çizelge 6 (FL: gerilim sigortası denetimi); gerilim hafızası: röle üreticisi belgeleri", "ikincil"))
    kt.append(C("Karakteristik açının arıza açısına uygunluğu", f"ileri arızada θ = {fnum(ideal['theta'], 0)}° ; RCA = {fnum(rca, 0)}° ; bölge sınırına pay {fnum(ideal['pay'], 0)}°", "pay ≥ 30° (en duyarlı ayar RCA = 90° − φ; tipik +30° hat, +45° trafo fideri)",
                ideal["pay"] >= 30, R27 + " m.3.1-(60) (en büyük tork açısı ± 90° aralığında ayarlanabilir); ayar önerisi: röle üreticisi uygulama kılavuzları", "ikincil"))
    ds = ["Yönlü röle iki büyüklük ölçer; biri yanlışsa karar yanlıştır. Akım trafosunun polaritesi, gerilim trafosunun polaritesi, faz sırası ve karakteristik açı dördü birden doğru olmalıdır.",
          "Devreye almada yön, yük akımıyla denetlenir: yük baradan hatta akıyorsa röle “ileri” göstermeli, ölçülen aktif güç pozitif olmalıdır. Yük küçük ya da kapasitifse test güvenilmez; primer ya da sekonder enjeksiyon yapılır.",
          "Rölenin hemen önündeki üç fazlı arızada üç gerilim de çöker: kutuplayacak gerilim kalmaz. Röle bu yüzden arıza öncesi gerilimi birkaç periyot hafızasında tutar. Gerilim trafosu sigortası atarsa hafıza da işe yaramaz.",
          "Karakteristik açı arızanın açısına göre seçilir, yükün açısına göre değil. Kablo şebekesinde arıza açısı küçük (30–45°), havai hatta büyüktür (60–75°); trafo arkasındaki arızada 80°'ye yaklaşır.",
          "Yönlü eleman gecikmeli aşırı akım elemanını yalnız serbest bırakır ya da kilitler; açma süresi yine aşırı akım elemanının eğrisinden gelir. Karşı uçtaki yönlü röleye kısa süre verilebilmesi, yalnız kendi hattına bakmasındandır."]
    # şema
    c = Cizim(900, 330, zemin=None)
    y1, y2 = 90, 200
    rol_y = y1 if yon == "ileri" else y2
    if uyg == "paralel":
        c.kutu(24, 120, 70, 50, "KAYNAK", "", "normal").hat("M94,145 H130", "L1", hot=True).hat("M130,70 V220", "cizgi", w=5).yazi(130, 60, "A barası", "#334155", 10.5, True, "middle")
        c.hat("M700,70 V220", "cizgi", w=5).yazi(708, 62, "B barası", "#334155", 10.5, True).hat("M700,145 H760", "L1").kutu(760, 122, 70, 46, "yük", "", "normal")
        c.hat(f"M130,{y1} H400", "L1", hot=True).hat(f"M700,{y1} H440", "L1", hot=True).simsek(408, y1 - 22, 1.2).yazi(420, y1 - 30, "arıza", "ariza", 11, True, "middle")
        c.hat(f"M130,{y2} H700", "L1", hot=True).ok(260, y1 - 10, 320, y1 - 10, "ariza").ok(600, y1 - 10, 540, y1 - 10, "ariza").ok(380, y2 - 10, 460, y2 - 10, "ariza")
        c.yazi(416, y2 + 22, "sağlam fider arızayı B barası üzerinden besliyor", "#475569", 10.5, False, "middle").yazi(180, y1 + 20, "fider 1", "#475569", 10.5).yazi(180, y2 + 20, "fider 2", "#475569", 10.5)
        rx = 640
        c.ok(rx + 26, rol_y - 30, rx - 30, rol_y - 30, "ok", 2.4).yazi(rx - 2, rol_y - 38, "rölenin “ileri” yönü", "ok", 10, True, "middle")
    else:
        c.kutu(24, 120, 80, 50, "TRAFO", "şebeke", "normal").hat("M104,145 H150", "L1", hot=True).hat("M150,70 V220", "cizgi", w=5).yazi(150, 60, "bara", "#334155", 10.5, True, "middle")
        c.hat(f"M150,{y1} H520", "L1", hot=True).simsek(528, y1 - 22, 1.2).yazi(540, y1 - 30, "arıza", "ariza", 11, True, "middle").hat(f"M560,{y1} H760", "L1").kutu(760, y1 - 22, 80, 44, "yük", "", "normal")
        c.hat(f"M150,{y2} H740", "L1", hot=True).kutu(740, y2 - 24, 100, 48, "GES / jeneratör", "arızayı besliyor", "acti").ok(300, y1 - 10, 380, y1 - 10, "ariza").ok(520, y2 - 10, 440, y2 - 10, "ariza")
        c.yazi(300, y1 + 20, "fider 1 (arızalı)", "#475569", 10.5).yazi(300, y2 + 22, "fider 2 (üretim bağlı)", "#475569", 10.5)
        rx = 210
        c.ok(rx - 26, rol_y - 30, rx + 34, rol_y - 30, "ok", 2.4).yazi(rx + 4, rol_y - 38, "rölenin “ileri” yönü", "ok", 10, True, "middle")
    c.kutu(rx - 34, rol_y - 22, 68, 44, "67", ("açıyor" if acar else "açmıyor"), ("acti" if acar else "normal") if acar == beklenen else "gecersiz")
    c.toroid(rx - 52 if uyg == "paralel" else rx + 52, rol_y, 7, 16, "ariza" if at_t else "#1e293b").yazi(rx - 52 if uyg == "paralel" else rx + 52, rol_y + 32, "AT" + (" (ters)" if at_t else ""), "ariza" if at_t else "#475569", 10, at_t, "middle")
    c.hat(f"M{'700' if uyg == 'paralel' else '150'},222 V275 H{rx + 40 if uyg == 'paralel' else rx - 40}", "mavi", kesik=True).kutu(rx - 40, 258, 80, 34, "GT" + (" (ters)" if gt_t else ""), "sigorta atık" if sig else "bara gerilimi", "gecersiz" if (gt_t or sig) else "vurgu").hat(f"M{rx},258 V{rol_y + 22}", "mavi", kesik=True)
    c.yazi(450, 318, ("Röle arızayı " + ("ileri" if Kr["ileri"] else "geri") + " görüyor" if Kr["var"] else "Röle yönü belirleyemiyor") + f" · arıza gerçekte {'ileri' if gercek_ileri else 'geri'} · " + ("karar doğru" if acar == beklenen else "KARAR YANLIŞ"),
           "ok" if acar == beklenen else "ariza", 12.5, True, "middle")
    vref = Kr.get("vp") if Kr["var"] else E["vp_onc"]
    vn = vref / abs(vref)
    fz = {"baslik": f"Röledeki fazörler ({E['ad_i']} elemanı)", "bolge": {"aci": _ac(vn) + rca, "yari": 90, "ad": "ileri bölge"}, "not": "kesik çizgi: karakteristik açı (en büyük tork) doğrultusu",
          "vektorler": [fazor(E["ad_v"] + (" (hafıza)" if Kr["kaynak"] == "hafiza" else ""), vn, "#1d4ed8"), fazor(E["ad_i"], E["i"] / abs(E["i"]) * 0.85, "#dc2626"),
                        fazor("V1", E["va"] * 0.6, "#8a4b12", True), fazor("V2", E["vb"] * 0.6, "#111827", True), fazor("V3", E["vc"] * 0.6, "#6b7280", True)]}
    xs = list(range(20, 86, 5))
    graf = [{"baslik": "Bölge sınırına pay — arıza açısına göre", "x_ad": "arıza açısı φ (°)", "y_ad": "pay (°)", "ymin": 0, "ymax": 95,
             "seriler": [{"ad": f"RCA = {fnum(rca, 0)}°", "renk": "#1a4d8f", "pts": [[x, round(faz_karar(faz_elemani(ariza, 'ileri', x, 100), rca, True, False)["pay"], 1)] for x in xs]},
                         {"ad": "RCA = +45°", "renk": "#94a3b8", "kesik": True, "pts": [[x, round(faz_karar(faz_elemani(ariza, 'ileri', x, 100), 45, True, False)["pay"], 1)] for x in xs]}],
             "isaretler": [{"x": phi, "etiket": "bu arıza"}], "yatay": [{"y": 30, "etiket": "en az 30°", "renk": "#d97706"}]}]
    tab = [{"baslik": "90° bağlantı: hangi akım hangi gerilimle karşılaştırılır", "cols": ["Eleman", "Akım", "Kutuplama gerilimi", "İleri arızada akımın gerilime göre açısı"],
            "rows": [["L1", "I1", "V23 = V2 − V3", "90° − φ"], ["L2", "I2", "V31 = V3 − V1", "90° − φ"], ["L3", "I3", "V12 = V1 − V2", "90° − φ"]],
            "not": "φ: arıza çevriminin açısı. İki fazlı arızada açı, arıza yerine göre 90° − φ ile 120° − φ arasında kalır; ± 90°'lik bölge bu kaymayı karşılar."},
           {"baslik": "Yanlış bağlantı ve ayarların sonucu", "cols": ["Hata", "Röle ne görür", "Sonuç"],
            "rows": [["Akım trafosu polaritesi ters", "akım 180° dönmüş", "ileri arızada açmaz; geri arızada açar"], ["Gerilim trafosu polaritesi ters", "kutuplama 180° dönmüş", "aynı"],
                     ["İkisi birden ters", "açı doğru", "yön doğru çıkar; güç ve enerji ölçümü ters — hata gizli"], ["Faz sırası yanlış (iki faz yer değiştirmiş)", "kutuplama gerilimi 60° / 120° kaymış", "bazı arıza türlerinde yanlış yön"],
                     ["Karakteristik açı arıza açısına uymuyor", "ileri arıza bölge sınırına yakın", "kararsız çalışma; ölçme hatasıyla yön değişir"], ["Gerilim trafosu sigortası atık", "kutuplama yok", "eleman bloke (ya da ayara göre yönsüz)"],
                     ["Yön ayarı ters seçilmiş", "doğru ölçer, ters yönde açar", "seçicilik bozulur"]]},
           {"baslik": "Şartnamedeki ayar aralıkları (fider yönetim rölesi)", "cols": ["Parametre", "Değer"],
            "rows": [["Yönlü koruma (67 / 67N)", "FYR ve FYR-G tiplerinde standart"], ["En büyük tork (karakteristik) açısı", "± 90° aralığında ayarlanabilir"], ["Yön", "ileri / geri"], ["Gecikmeli açma akım ayarı", "(0,05 – 2)·In, adım 0,01·In"],
                     ["Ani açma akım ayarı", "(2 – 20)·Is ve ∞ ; ani açma süresi ≤ 40 ms"], ["Sabit zaman gecikmesi", "0,1 – 5 s, adım 0,01 s"], ["Gerilim sigortası denetimi", "FL fonksiyonu"]],
            "not": R27 + " Çizelge 3, 5, 6 ve m.3.1-(60) — durum: resmi"}]
    oz = [K("Ölçülen açı θ", f"{fnum(Kr['theta'], 0)}°" if Kr["var"] else "—", "info", f"{E['ad_i']} – {E['ad_v']}"), K("Röle arızayı", ("ileri" if Kr["ileri"] else "geri") + " görüyor" if Kr["var"] else "göremiyor", "ok" if (Kr["var"] and Kr["ileri"] == gercek_ileri) else "bad", f"gerçekte {'ileri' if gercek_ileri else 'geri'}"),
          K("Açma", "açıyor" if acar else "açmıyor", "ok" if acar == beklenen else "bad", "açmalı" if beklenen else "açmamalı"), K("Kutuplama gerilimi", f"%{fnum(Kr['vp_pct'], 0)}", "ok" if Kr["var"] else "bad", "hafıza" if Kr["kaynak"] == "hafiza" else "ölçülen"),
          K("Bölge payı (ileri arıza)", f"{fnum(ideal['pay'], 0)}°", "ok" if ideal["pay"] >= 30 else "warn", f"RCA {fnum(rca, 0)}°")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(fazor=fz), "grafikler": graf, "tablolar": tab}


def _toprak(p: dict) -> dict:
    notr = p.get("notr") if p.get("notr") in NOTR else "direnc"
    kar = p.get("kar") if p.get("kar") in KAR else "cos"
    rca = {"sin": 90.0, "cos": 0.0}.get(kar, num(p, "rca_n", 0))
    ic_bu, ic_d = num(p, "ic_bu", 5), num(p, "ic_diger", 40)
    v0 = num(p, "v0_pct", 100) / 100
    i_f, i_h = toprak_akimlari(notr, ic_bu, ic_d, num(p, "ir_a", 1000), num(p, "komp", 105), num(p, "iw_a", 8), num(p, "ik1_a", 2000), v0)
    at_t, gt_t = bool(p.get("at_ters_n")), bool(p.get("gt_ters_n"))
    ayar = num(p, "i0_ayar", 2); v_ayar = num(p, "v0_ayar", 10)
    m_f = -i_f if at_t else i_f                              # arızalı fiderin rölesinin gördüğü
    m_h = i_h
    if gt_t:
        m_f, m_h = -m_f, -m_h
    def el(z: complex) -> tuple[float, float, bool]:
        th = _ac(z) if abs(z) > 1e-9 else 0.0
        iop = abs(z) * math.cos(math.radians(th - rca))
        return th, iop, (iop >= ayar and v0 * 100 >= v_ayar)
    th_f, op_f, ac_f = el(m_f); th_h, op_h, ac_h = el(m_h)
    lo, hi = UYGUN[notr]
    uygun = lo - 1e-9 <= rca <= hi + 1e-9
    kt, an = [], []
    an.append("Toprak arızasında üç faz geriliminin toplamı sıfır olmaz: artık gerilim V0 oluşur (açık üçgen sargıdan ya da röle içinde hesaplanarak ölçülür). Röle, fiderin artık akımını (toroidden) −V0 ile karşılaştırır.")
    an.append(f"Sağlam fider: toprağa akan, fiderin kendi kapasitif akımıdır ({fnum(abs(i_h), 1)} A); baradan hatta doğru akar ve −V0'dan 90° geridedir. Arızalı fider: diğer bütün fiderlerin kapasitif akımı ({fnum(ic_d * v0, 1)} A) arıza yerinden geri döner — "
              "sağlam fiderdekinin tam tersi yönde, −V0'dan 90° ileride. Buna yıldız noktasından gelen akım eklenir.")
    an.append({"yalitilmis": "Yalıtılmış şebekede yıldız noktası akımı yoktur: arızalı fiderin akımı saf kapasitiftir (+90°), sağlam fiderlerinki de saf kapasitiftir ama ters yöndedir (−90°). Ayırt eden büyüklük I0·sin φ'dir; aktif bileşen yok denecek kadar küçüktür.",
               "bobin": f"Bobin, toplam kapasitif akımı götürecek kadar endüktif akım verir (ayar %{fnum(num(p, 'komp', 105), 0)}). Arızalı fiderde kapasitif bileşen bobin akımıyla hemen hemen silinir, hatta aşırı kompanzasyonda yön değiştirir: sin φ ölçümü işe yaramaz. "
                        f"Geriye bobinin kayıpları ve varsa paralel direncin verdiği küçük aktif akım kalır ({fnum(num(p, 'iw_a', 8) * v0, 1)} A): yalnız arızalı fiderde vardır ve −V0 ile aynı fazdadır. Bunu I0·cos φ (vatmetrik) ölçüm yakalar.",
               "direnc": f"Yıldız noktası direnci arızalı fidere büyük bir aktif akım ekler ({fnum(num(p, 'ir_a', 1000) * v0, 0)} A, −V0 ile aynı fazda). Sağlam fiderlerde yalnız küçük kapasitif akım vardır. cos φ ölçümü ya da 0° … +45° karakteristik açı ikisini kesin ayırır.",
               "dogrudan": f"Doğrudan topraklı şebekede arıza akımı kısa devre akımıdır ({fnum(num(p, 'ik1_a', 2000) * v0, 0)} A) ve hat empedansı nedeniyle −V0'dan ≈ 70° geridedir. Karakteristik açı −45° … −60° seçilir. Akım zaten çok büyük olduğundan çoğu fiderde yönsüz toprak koruması yeter; yön, paralel hat ve halka şebekede gerekir."}[notr])
    an.append(f"Röle karakteristiği: {KAR[kar].split(' (')[0]} → çalışma büyüklüğü I·cos(θ − {fnum(rca, 0)}°). Arızalı fider: θ = {fnum(th_f, 0)}°, çalışma büyüklüğü {fnum(op_f, 1)} A → {'açar' if ac_f else 'açmaz'}. "
              f"Sağlam fider: θ = {fnum(th_h, 0)}°, çalışma büyüklüğü {fnum(op_h, 1)} A → {'açar' if ac_h else 'açmaz'}. Akım ayarı {fnum(ayar, 1)} A, artık gerilim eşiği %{fnum(v_ayar, 0)}.")
    if at_t or gt_t:
        an.append(("Açık üçgen sargının polaritesi ters: −V0 yerine +V0 kutuplanıyor; bütün fiderlerin röleleri yönü ters görür — arızalı fider açmaz, sağlam fiderler açabilir." if gt_t else
                   "Arızalı fiderin toroidi ters takılmış: röle akımı 180° dönmüş görür ve arızayı “geri” sayar. Toroidin P1 yüzü baraya bakmalı, S1 rölenin polarite ucuna gitmelidir; ekran topraklama iletkeninin geçişi de aynı ölçüye girer."))
    kt.append(C("Arızalı fiderin rölesi", f"θ = {fnum(th_f, 0)}° ; I·cos(θ − RCA) = {fnum(op_f, 1)} A → {'açıyor' if ac_f else 'açmıyor'}", f"açmalı (≥ {fnum(ayar, 1)} A ve V0 ≥ %{fnum(v_ayar, 0)})", ac_f, R27 + " Çizelge 6 (67N), Çizelge 5 (yön ileri / geri)", "resmi"))
    kt.append(C("Sağlam fiderin rölesi", f"θ = {fnum(th_h, 0)}° ; I·cos(θ − RCA) = {fnum(op_h, 1)} A → {'açıyor' if ac_h else 'açmıyor'}", "açmamalı (kendi kapasitif akımıyla çalışmamalı)", not ac_h, R27 + " Çizelge 6 (67N)", "resmi"))
    kt.append(C("Karakteristiğin yıldız noktasına uygunluğu", f"{NOTR[notr]} şebeke ; RCA = {fnum(rca, 0)}°", f"önerilen RCA {fnum(lo, 0)}° … {fnum(hi, 0)}° ({'sin φ' if notr == 'yalitilmis' else 'cos φ' if notr in ('bobin', 'direnc') else 'açı ayarlı'})", uygun,
                R27 + " m.3.1-(60) (± 90° ayarlanabilir); seçim: röle üreticisi uygulama kılavuzları", "ikincil"))
    kt.append(C("Artık gerilim eşiği", f"V0 = %{fnum(v0 * 100, 0)} ; eşik %{fnum(v_ayar, 0)}", "V0 eşiğin üstünde olmalı; eşik, şebekenin doğal dengesizliğinin üstünde seçilir", v0 * 100 >= v_ayar, "Röle üreticisi uygulama kılavuzları", "ikincil"))
    kt.append(C("Duyarlılık payı", f"çalışma büyüklüğü / ayar = {fnum(op_f / ayar, 1)}", "≥ 1,5 (ölçme hataları ve dirençli arıza için pay)", True if op_f >= 1.5 * ayar else (None if op_f >= ayar else False), "Uygulama ölçütü", "ikincil"))
    kt.append(C("Toroid ve açık üçgen polaritesi", "toroid ters" if at_t else ("açık üçgen ters" if gt_t else "doğru"), "toroid P1 baraya; açık üçgen uçları şemadaki gibi; devreye almada yapay toprak arızası ya da sekonder enjeksiyonla yön doğrulanır", not (at_t or gt_t), KABUL, "resmi"))
    ds = ["Yön karakteristiği yıldız noktasına göre seçilir: yalıtılmış şebekede sin φ, bobinli şebekede cos φ (vatmetrik), dirençli şebekede cos φ ya da 0–45°, doğrudan topraklıda −45 … −60°. Yanlış seçim, rölenin arızayı hiç görmemesi demektir.",
          "Sağlam fiderin kendi kapasitif akımı ayarın üstündeyse yönsüz toprak rölesi başka fiderdeki arızada açar (sempatik açma). Uzun kablolu fiderlerde yönlü toprak koruması bu yüzden gerekir.",
          "Bobinli şebekede arıza akımı birkaç ampere iner; röleye çalışacak akım kalsın diye bobine paralel, kısa süre devreye giren bir direnç konur. Aktif bileşen bu dirençten gelir.",
          "Dirençli arızada V0 düşer; eşik çok yüksekse röle çalışmaz, çok düşükse doğal dengesizlikte çalışır. Kesintili (yanıp sönen) toprak arızaları için ayrı bir fonksiyon (67NIEF) vardır.",
          "Toroidin yönü, sekonder polaritesi, ekran topraklama iletkeninin geçişi ve açık üçgenin polaritesi: dördü de aynı açıyı etkiler. Devreye almada yön, gerçek ya da benzetilmiş bir toprak arızasıyla denenir."]
    c = Cizim(900, 330, zemin=292)
    c.kutu(24, 110, 80, 60, "TRAFO", "yıldız noktası", "normal").hat("M104,140 H160", "L1").hat("M160,60 V230", "cizgi", w=5).yazi(160, 50, "bara", "#334155", 10.5, True, "middle")
    c.hat("M64,170 V200").yazi(76, 196, {"yalitilmis": "yalıtılmış", "bobin": "bobin", "direnc": "direnç", "dogrudan": "doğrudan"}[notr], "#475569", 10.5)
    if notr == "direnc":
        c.direnc(64, 200, "", True).hat("M64,230 V292")
    elif notr == "bobin":
        c.bobin(64, 200, 4, False, "ariza").hat("M64,240 V292")
    elif notr == "dogrudan":
        c.hat("M64,200 V292", hot=True)
    if notr != "yalitilmis":
        c.toprak(64, 292)
    ya, yb = 90, 200
    c.hat(f"M160,{ya} H560", "L1", hot=True).simsek(566, ya - 4, 1.1).hat(f"M572,{ya + 18} V292", "ariza", hot=True).yazi(590, ya + 60, "toprak arızası", "ariza", 11, True)
    c.hat(f"M160,{yb} H740", "L1").kap(640, yb, 292, "mavi", False, "hat kapasitesi").kap(730, yb, 292, "mavi").hat("M640,236 V292", "mavi", hot=True, hot_renk="mavi", kesik=True)
    c.toroid(230, ya, 8, 18, "ariza" if at_t else "#1e293b").toroid(230, yb, 8, 18)
    c.kutu(196, ya - 62, 68, 36, "67N", "açıyor" if ac_f else "açmıyor", "acti" if ac_f else "gecersiz").kutu(196, yb - 62, 68, 36, "67N", "açıyor" if ac_h else "açmıyor", "gecersiz" if ac_h else "normal")
    c.ok(430, ya - 12, 340, ya - 12, "ariza").yazi(386, ya - 20, f"{fnum(abs(i_f), 1)} A ∠{fnum(_ac(i_f), 0)}°", "ariza", 11, True, "middle").ok(340, yb - 12, 430, yb - 12, "mavi").yazi(386, yb - 20, f"{fnum(abs(i_h), 1)} A ∠{fnum(_ac(i_h), 0)}°", "mavi", 11, True, "middle")
    c.yazi(280, ya + 26, "arızalı fider", "#475569", 10.5).yazi(280, yb + 26, "sağlam fider", "#475569", 10.5)
    c.kutu(766, 96, 110, 60, "GT — açık üçgen", f"V0 = %{fnum(v0 * 100, 0)}" + (" (ters)" if gt_t else ""), "gecersiz" if gt_t else "vurgu").hat("M760,125 H740 V46 H264", "mavi", kesik=True)
    c.yazi(450, 318, ("arızalı fider açıyor, sağlam fider bekliyor: seçici" if (ac_f and not ac_h) else ("arızalı fider AÇMIYOR" if not ac_f else "") + (" · " if (not ac_f and ac_h) else "") + ("sağlam fider AÇIYOR" if ac_h else "")),
           "ok" if (ac_f and not ac_h) else "ariza", 12.5, True, "middle")
    def fz(ad: str, z: complex, renk: str) -> dict:
        m = max(abs(z), 1e-9)
        return {"baslik": ad, "bolge": {"aci": rca, "yari": 90, "ad": "çalışma bölgesi"}, "vektorler": [fazor("−V0", complex(1, 0), "#1d4ed8"), {**fazor("3I0", z / m * 0.85, renk), "mod": round(abs(z), 1)}]}
    fzl = [fz("Arızalı fiderin rölesi", m_f, "#dc2626"), fz("Sağlam fiderin rölesi", m_h, "#0f766e")]
    tab = [{"baslik": "Yıldız noktasına göre yönlü toprak koruması", "cols": ["Yıldız noktası", "Arızalı fiderin akımı (−V0'a göre)", "Sağlam fiderin akımı", "Karakteristik", "Not"],
            "rows": [["Yalıtılmış" + (" ◀" if notr == "yalitilmis" else ""), "kapasitif, +90°", "kapasitif, −90°", "I0·sin φ (RCA +90°)", "akım küçük: toroid ve duyarlı ayar gerekir"],
                     ["Rezonans topraklı" + (" ◀" if notr == "bobin" else ""), "küçük aktif bileşen, ≈ 0°", "kapasitif, −90°", "I0·cos φ (vatmetrik, RCA 0°)", "paralel direnç aktif bileşeni artırır"],
                     ["Direnç üzerinden" + (" ◀" if notr == "direnc" else ""), "aktif + kapasitif, 0° … +45°", "kapasitif, −90°", "I0·cos φ ya da RCA 0° … +45°", "dağıtımda en yaygın düzen"],
                     ["Doğrudan" + (" ◀" if notr == "dogrudan" else ""), "endüktif, ≈ −70°", "ihmal edilir", "RCA −45° … −60°", "çoğu fiderde yönsüz koruma yeter"]],
            "not": "Açılar öğretim modelindeki ideal değerlerdir; karakteristik seçimi röle üreticisi uygulama kılavuzlarına dayanır (durum: ikincil)."},
           {"baslik": "Bu durumda iki röle", "cols": ["", "Akım", "Açı θ", "Çalışma büyüklüğü", "Karar", "Olması gereken"],
            "rows": [["Arızalı fider", f"{fnum(abs(m_f), 1)} A", f"{fnum(th_f, 0)}°", f"{fnum(op_f, 1)} A", "açar" if ac_f else "açmaz", "açmalı"], ["Sağlam fider", f"{fnum(abs(m_h), 1)} A", f"{fnum(th_h, 0)}°", f"{fnum(op_h, 1)} A", "açar" if ac_h else "açmaz", "açmamalı"]]}]
    oz = [K("Arızalı fider", "açıyor" if ac_f else "açmıyor", "ok" if ac_f else "bad", f"{fnum(abs(m_f), 1)} A ∠{fnum(th_f, 0)}°"), K("Sağlam fider", "açıyor" if ac_h else "açmıyor", "bad" if ac_h else "ok", f"{fnum(abs(m_h), 1)} A ∠{fnum(th_h, 0)}°"),
          K("Karakteristik açı", f"{fnum(rca, 0)}°", "ok" if uygun else "bad", f"önerilen {fnum(lo, 0)}° … {fnum(hi, 0)}°"), K("Çalışma büyüklüğü", f"{fnum(op_f, 1)} A", "ok" if op_f >= 1.5 * ayar else "warn", f"ayar {fnum(ayar, 1)} A"),
          K("Artık gerilim", f"%{fnum(v0 * 100, 0)}", "ok" if v0 * 100 >= v_ayar else "bad", f"eşik %{fnum(v_ayar, 0)}")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(fazorler=fzl), "tablolar": tab}


def run(p: dict) -> dict:
    return _toprak(p) if p.get("fonksiyon") == "toprak" else _faz(p)
