"""Laboratuvar konusu — toprak arızasının ölçülmesi: homopolar (toroid) akım trafosu, artık akım (Holmgreen) bağlantısı ve
kablo ekranı topraklama iletkeninin toroidden geçirilmesi.

Toroid, içinden geçen bütün iletkenlerin akımlarının toplamını ölçer. Kablo, ekranıyla birlikte toroidin içinden geçiyorsa ekrandan
dönen akım da toplamın içindedir ve ölçümü bozar. Ekran topraklama iletkeni toroidin içinden geri geçirilirse ekran akımı toroidi
iki kez, ters yönlerde keser ve toplamdan çıkar."""
from __future__ import annotations

from .cizim import Cizim
from .core import C, K, ctl, fnum, num, opt

ID = "toroid"
BASLIK = "Toroid akım trafosu ve ekran"
IKON = "⭕"
GIRIS = ("Toprak arıza rölesi, toroidin içinden geçen akımların toplamına bakar. Kablonun ekranı da toroidin içinden geçiyorsa, ekran topraklama iletkeninin "
         "nereden geçirildiği rölenin doğru görmesi ile hiç görmemesi (ya da sağlam fideri açması) arasındaki farktır.")
GECIS = {"dogru": "Ekran toroidin üstünde sonlanıyor; topraklama iletkeni toroidin içinden geri geçirilmiş", "gecmiyor": "Ekran toroidin üstünde sonlanıyor; topraklama iletkeni toroidin dışından toprağa gidiyor",
         "altta": "Ekran toroidin altında sonlanıyor (toroidin içinden yalnız damarlar geçiyor)", "altta_gecmis": "Ekran toroidin altında sonlanıyor ama topraklama iletkeni toroidin içinden geçirilmiş"}

KONTROLLER = [
    ctl("yontem", "Ölçme yöntemi", "sec", "toroid", secenek=opt(("toroid", "Homopolar (toroid) akım trafosu — üç faz tek çekirdekten"), ("holmgreen", "Artık akım bağlantısı — üç faz akım trafosunun toplamı"))),
    ctl("gecis", "Kablo ekranı ve topraklama iletkeni", "sec", "dogru", secenek=opt(*GECIS.items()), goster={"yontem": ["toroid"]}),
    ctl("ariza", "Toprak arızasının yeri", "sec", "bu", secenek=opt(("bu", "Bu fiderde (toroidin ilerisinde)"), ("baska", "Başka bir fiderde (bu fider sağlam)"))),
    ctl("if_a", "Toprak arıza akımı", "sayi", 100, min=1, max=2000, adim=1, birim="A"),
    ctl("ekran_pay", "Arıza akımının bu kablonun ekranından dönen payı", "sayi", 45, min=0, max=90, adim=5, birim="%", yardim="≈ 1 − r (azalma katsayısı): iki uçtan topraklı 16 mm² ekranda %40–50"),
    ctl("ic_a", "Bu fiderin kendi kapasitif akımı", "sayi", 2, min=0, max=50, adim=0.5, birim="A"),
    ctl("i_ayar", "Rölenin toprak arıza ayarı (primer)", "sayi", 20, min=0.5, max=400, adim=0.5, birim="A"),
    ctl("i_faz", "Fiderin yük akımı", "sayi", 300, min=10, max=1250, adim=10, birim="A", goster={"yontem": ["holmgreen"]}),
    ctl("hata_pct", "Faz akım trafolarının oran hatası (birbirinden farkı)", "sayi", 1, min=0.1, max=10, adim=0.1, birim="%", yardim="5P: anma akımında ± %1; kalkış ve kısa devrede doymayla çok daha büyük", goster={"yontem": ["holmgreen"]}),
]


def run(p: dict) -> dict:
    tor = p.get("yontem") != "holmgreen"
    g = p.get("gecis") if p.get("gecis") in GECIS else "dogru"
    bu = p.get("ariza") != "baska"
    i_f = num(p, "if_a", 100); pay = num(p, "ekran_pay", 45) / 100; ic = num(p, "ic_a", 2); ayar = num(p, "i_ayar", 20)
    i_ekran = pay * i_f * (1.0 if bu else 0.25)             # sağlam fiderde ekran, arıza akımının küçük bir bölümüne paralel dönüş yolu olur
    gercek = i_f if bu else ic                              # fiderin gerçek artık akımı (faz iletkenlerinin toplamı)
    an, kt = [], []
    if tor:
        ekran_icinde = g in ("dogru", "gecmiyor")
        geri = g in ("dogru", "altta_gecmis")
        # toroidin gördüğü: faz toplamı − (ekran içindeyse ekran akımı) + (iletken geri geçirilmişse ekran akımı)
        net_ekran = (-(i_ekran) if ekran_icinde else 0.0) + (i_ekran if geri else 0.0)
        olc = abs(gercek + (net_ekran if bu else -net_ekran))
        dogru_bag = g in ("dogru", "altta")
        an.append(f"Üç faz iletkeni aynı çekirdekten geçiyor. Sağlam durumda üç akımın toplamı sıfırdır; toprak arızasında toplam, toprağa kaçan akıma eşittir. Fiderin gerçek artık akımı {fnum(gercek, 1)} A"
                  + (" (arıza bu fiderde)." if bu else " (arıza başka fiderde; bu, fiderin kendi kapasitif akımı)."))
        an.append(f"Arıza akımının bir bölümü kabloların ekranlarından döner; bu kablonun ekranında {fnum(i_ekran, 1)} A var.")
        an.append({"dogru": "Ekran toroidin içinden geçiyor (ekran akımı toplamı bozar) ama topraklama iletkeni toroidin içinden geri getirilmiş: aynı akım çekirdeği bir aşağı bir yukarı keser, etkisi sıfırlanır. Toroid yalnız faz iletkenlerinin toplamını görür.",
                   "gecmiyor": "Ekran toroidin içinden geçiyor ve topraklama iletkeni dışarıdan gidiyor: ekrandan dönen akım, faz toplamından eksilir (arıza bu fiderdeyse) ya da sahte bir artık akım olarak eklenir (arıza başka yerdeyse).",
                   "altta": "Ekran toroidin altında (kablo tarafında) sonlandırılmış; toroidin içinden yalnız üç damar geçiyor. Ekran akımı çekirdeği hiç kesmez; topraklama iletkenini geçirmeye gerek yoktur.",
                   "altta_gecmis": "Ekran toroidin altında sonlanıyor, yani ekran akımı çekirdeği kesmiyor; ama topraklama iletkeni yine de toroidin içinden geçirilmiş: bu kez iletken ekran akımını ölçüme sokuyor."}[g])
        an.append(f"Röle {fnum(olc, 1)} A görür; ayarı {fnum(ayar, 1)} A.")
        kt.append(C("Ekran topraklama iletkeninin geçişi", GECIS[g].split(";")[-1].strip() if ";" in GECIS[g] else GECIS[g], "ekran toroidin içinden geçiyorsa topraklama iletkeni toroidin içinden geri geçirilir (yalıtılmış olarak); ekran toroidin altında sonlanıyorsa geçirilmez", dogru_bag,
                    "Koruma rölesi ve hücre üreticilerinin montaj kuralları; TS EN 61869-2 (toplam akım trafoları)", "ikincil"))
    else:
        hata = num(p, "hata_pct", 1) / 100 * num(p, "i_faz", 300)
        olc = gercek + hata
        an += ["Üç faz akım trafosunun sekonderleri paralel bağlanır; röle üç akımın toplamını görür. Ayrı bir çekirdek gerekmez, ekranın nereden geçtiği de önemli değildir (akım trafoları faz iletkenlerindedir).",
               f"Ama üç akım trafosu birbirinin aynısı değildir: oran hataları arasındaki fark, yük akımının küçük bir yüzdesi kadar sahte artık akım üretir: %{fnum(num(p, 'hata_pct', 1), 1)} × {fnum(num(p, 'i_faz', 300), 0)} A = {fnum(hata, 1)} A.",
               f"Röle en kötü durumda {fnum(olc, 1)} A görür (gerçek {fnum(gercek, 1)} A + sahte {fnum(hata, 1)} A); ayarı {fnum(ayar, 1)} A.",
               "Motor kalkışında ya da faz–faz kısa devrede akım trafoları eşit olmayan ölçüde doyar; sahte artık akım birkaç yüz ampere çıkabilir. Bu yüzden ayar düşük tutulamaz (genellikle anma akımının %10'undan aşağı inilmez) ve zaman gecikmesi eklenir."]
        kt.append(C("Ayarın sahte artık akımın üstünde olması", f"sahte ≈ {fnum(hata, 1)} A ; ayar {fnum(ayar, 1)} A", "ayar > sahte artık akım (yeterli payla)", ayar > 1.5 * hata, "Koruma uygulama kuralı; TS EN 61869-2 (koruma sınıfı oran hatası)", "ikincil"))
    acar = olc >= ayar
    if bu:
        kt.append(C("Arızalı fiderde röle çalışmalı", f"röle {fnum(olc, 1)} A görüyor", f"≥ ayar ({fnum(ayar, 1)} A)", acar, "Koruma seçiciliği; Kuvvetli Akım Tesisleri Yön. (toprak arızasının algılanması)", "ikincil"))
        an.append("Röle arızayı görür ve fideri açar." if acar else "Röle arızayı göremez: akım ayarın altında kalıyor. Arıza temizlenmez; üst kademe (ya da hiçbir şey) açar.")
    else:
        kt.append(C("Sağlam fiderde röle çalışmamalı", f"röle {fnum(olc, 1)} A görüyor", f"< ayar ({fnum(ayar, 1)} A)", not acar, "Koruma seçiciliği", "ikincil"))
        an.append("Röle çalışmaz: sağlam fider serviste kalır." if not acar else "Röle çalışır: arızası olmayan fider açar (yanlış açma). Arızalı fiderle birlikte sağlam fiderler de gider.")
    ds = ["Toroid, toprak arızasını ölçmenin en duyarlı yoludur: tek çekirdek olduğu için oran hatası farkı yoktur, birkaç amperlik arızayı görür. Yalıtılmış ve kompanze şebekelerde, yüksek dirençli arızalarda bu duyarlılık gerekir.",
          "Kural tek cümledir: toroidin içinden geçen her ekran akımı, aynı toroidin içinden bir kez de ters yönde geçmelidir. Ekran toroidin üstünde bitiyorsa iletken geri geçirilir; altında bitiyorsa geçirilmez.",
          "Geri geçirilen topraklama iletkeni yalıtılmış olmalı ve toroide, gövdeye değmeden geçmelidir; kablo başlığının metal gövdesi de toroidden önce toprağa değmemelidir. Aksi halde ekran akımı ikinci bir yoldan kaçar.",
          "Üç akım trafosunun toplamı (Holmgreen) ek çekirdek gerektirmez ama kaba kalır; direnç topraklı şebekede yüzlerce amperlik arızalar için yeterlidir.",
          "Devreye almada denenir: toroidin içinden bilinen bir akım geçirilir (primer enjeksiyon) ve rölenin okuduğu değer karşılaştırılır; ekran iletkeninden akım geçirildiğinde röle sıfır okumalıdır."]
    c = Cizim(900, 320, zemin=270)
    xk = 300
    if tor:
        ekran_icinde = g in ("dogru", "gecmiyor"); geri = g in ("dogru", "altta_gecmis")
        c.yazi(40, 26, "kablo başlığı (hücre tarafı)", "#475569", 10.5)
        for k, col in enumerate(("L1", "L2", "L3")):
            c.hat(f"M{xk - 22 + k * 22},30 V250", col, hot=(bu and k == 0), w=2.6)
        y_ek = 90 if ekran_icinde else 200
        c.dikdortgen(xk - 36, y_ek, 72, 250 - y_ek, "PE", "rgba(21,128,61,.10)", 2, True, 6).yazi(xk - 46, y_ek + 14, "ekran burada sonlanıyor", "PE", 10.5, False, "end")
        c.toroid(xk, 150, 70, 16).yazi(xk - 82, 146, "toroid", "#334155", 11.5, True, "end").yazi(xk - 82, 162, f"röle: {fnum(olc, 1)} A", "ok" if ((bu and acar) or (not bu and not acar)) else "ariza", 12.5, True, "end")
        x_il = xk + 52 if not geri else xk + 52
        if geri:
            c.hat(f"M{xk + 36},{y_ek + 6} H{xk + 52} V{120 if ekran_icinde else 215} H{xk - 52} V270" if not ekran_icinde else f"M{xk + 36},{y_ek + 6} H{xk + 60} V70 H{xk + 6}", "PE", hot=i_ekran > 0.5, hot_renk="uyari")
            if ekran_icinde:
                c.hat(f"M{xk + 6},70 V270", "PE", hot=i_ekran > 0.5, hot_renk="uyari").yazi(xk + 14, 240, "iletken toroidin içinden geri geçiyor", "PE", 10.5)
            else:
                c.yazi(xk - 60, 240, "iletken toroidin içinden geçirilmiş", "ariza", 10.5, False, "end")
        else:
            c.hat(f"M{xk + 36},{y_ek + 6} H{xk + 120} V270", "PE", hot=i_ekran > 0.5, hot_renk="uyari").yazi(xk + 128, 240, "iletken toroidin dışından", "ok" if not ekran_icinde else "ariza", 10.5)
        c.toprak(xk + (6 if (geri and ekran_icinde) else -52 if geri else 120), 270)
        c.yazi(40, 300, f"ekran akımı {fnum(i_ekran, 1)} A · faz iletkenlerinin toplamı {fnum(gercek, 1)} A", "#475569", 11)
    else:
        for k, col in enumerate(("L1", "L2", "L3")):
            y = 70 + k * 50
            c.hat(f"M60,{y} H700", col, hot=(bu and k == 0), w=2.6).daire(250, y, 13, "#334155", "#fff", 2).hat(f"M250,{y + 13} V{y + 26} H430 V230", "cizgi")
        c.kutu(390, 230, 90, 34, "RÖLE (ΣI)", f"{fnum(olc, 1)} A", "acti" if ((bu and acar) or (not bu and not acar)) else "gecersiz").yazi(250, 40, "üç faz akım trafosu", "#475569", 10.5, False, "middle")
        c.yazi(520, 250, "sekonderler paralel: toplam akım röleye", "#475569", 10.5)
    c.kutu(620, 30, 250, 60, "ARIZA: " + ("bu fiderde" if bu else "başka fiderde"), f"toprak arıza akımı {fnum(i_f, 0)} A", "gecersiz" if bu else "normal")
    c.yazi(745, 130, "ayar " + fnum(ayar, 1) + " A", "#334155", 12, True, "middle").yazi(745, 150, ("röle AÇAR" if acar else "röle açmaz"), "ok" if ((bu and acar) or (not bu and not acar)) else "ariza", 13, True, "middle")
    dogru_sonuc = (bu and acar) or (not bu and not acar)
    oz = [K("Fiderin gerçek artık akımı", f"{fnum(gercek, 1)} A", "info", "faz iletkenlerinin toplamı"), K("Rölenin gördüğü", f"{fnum(olc, 1)} A", "ok" if abs(olc - gercek) <= 0.1 * max(gercek, 1) else "bad", f"ayar {fnum(ayar, 1)} A"),
          K("Röle", "açar" if acar else "açmaz", "ok" if dogru_sonuc else "bad", "doğru davranış" if dogru_sonuc else ("arızayı görmüyor" if bu else "yanlış açma")), K("Ekran akımı", f"{fnum(i_ekran, 1)} A", "info", "bu kablonun ekranında")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne()}
