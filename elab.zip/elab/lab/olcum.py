"""Laboratuvar konusu — topraklama ölçümleri: 3 uçlu potansiyel düşümü, Wenner (toprak özdirenci), kazıksız pens yöntemi,
çevrim empedansı ve kaçak akım rölesi testi; tesise göre hangi ölçüm, hangi sınır, hangi periyot.

Modeller: topraklayıcı eşdeğer yarım küre (r = ρ / (2π·RE)); iki tabakalı toprakta Wenner görünür özdirenci (görüntü serisi).
Dayanak: Topraklamalar Yön. m.10, Ek-N, Ek-G, Ek-P."""
from __future__ import annotations

import math

from .core import C, K, cihaz_adi, cihaz_ia, ctl, fnum, num, opt, rules, ruleset

ID = "olcum"
BASLIK = "Ölçümler ve sınır değerleri"
IKON = "📏"
GIRIS = ("Topraklama ölçümü kazıkların yerine çok duyarlıdır: yanlış yere çakılan kazık yanlış ama inandırıcı bir sayı verir. Yöntemi seçin, kazıkları gezdirin, "
         "cihazın ne okuyacağını ve gerçek değerden ne kadar saptığını görün. Altta: tesise göre hangi ölçüm, hangi sınır, hangi periyot.")
YONTEM = {"uc_kazik": "3 uçlu potansiyel düşümü (topraklama direnci)", "wenner": "Wenner — 4 kazık (toprak özdirenci)", "pens": "Kazıksız pens yöntemi", "cevrim": "Çevrim empedansı ve RCD testi"}

KONTROLLER = [
    ctl("yontem", "Ölçüm yöntemi", "sec", "uc_kazik", secenek=opt(*YONTEM.items())),
    # 3 uçlu
    ctl("re_gercek", "Topraklayıcının gerçek direnci", "sayi", 10, min=0.2, max=500, adim=0.5, birim="Ω", goster={"yontem": ["uc_kazik"]}),
    ctl("d_el", "Topraklayıcının en büyük boyutu", "sayi", 3, min=1, max=100, adim=1, birim="m", yardim="kazık boyu, halka çapı ya da ağın köşegeni", goster={"yontem": ["uc_kazik"]}),
    ctl("c_m", "Akım kazığının (yardımcı topraklayıcı) uzaklığı", "sayi", 40, min=5, max=400, adim=5, birim="m", goster={"yontem": ["uc_kazik"]}),
    ctl("p_pct", "Gerilim kazığının (sonda) yeri", "sayi", 62, min=5, max=95, adim=1, birim="% C", goster={"yontem": ["uc_kazik"]}),
    ctl("rho", "Toprak özdirenci ρ", "sayi", 100, min=10, max=3000, adim=10, birim="Ω·m", goster={"yontem": ["uc_kazik"]}),
    # Wenner
    ctl("a_m", "Kazık aralığı a", "sayi", 3, min=0.5, max=50, adim=0.5, birim="m", goster={"yontem": ["wenner"]}),
    ctl("rho1", "Üst tabaka özdirenci ρ1", "sayi", 100, min=10, max=3000, adim=10, birim="Ω·m", goster={"yontem": ["wenner"]}),
    ctl("rho2", "Alt tabaka özdirenci ρ2", "sayi", 400, min=10, max=3000, adim=10, birim="Ω·m", goster={"yontem": ["wenner"]}),
    ctl("h_m", "Üst tabaka kalınlığı", "sayi", 2, min=0.3, max=20, adim=0.1, birim="m", goster={"yontem": ["wenner"]}),
    # pens
    ctl("rx", "Ölçülen topraklayıcının gerçek direnci", "sayi", 10, min=0.5, max=500, adim=0.5, birim="Ω", goster={"yontem": ["pens"]}),
    ctl("n_par", "Buna paralel bağlı diğer topraklayıcı sayısı", "sayi", 12, min=0, max=40, adim=1, goster={"yontem": ["pens"]}),
    ctl("r_diger", "Diğer topraklayıcıların her birinin direnci", "sayi", 10, min=0.5, max=500, adim=0.5, birim="Ω", goster={"yontem": ["pens"]}),
    # çevrim / RCD
    ctl("sistem", "Şebeke sistemi", "sec", "TN", secenek=opt(("TN", "TN"), ("TT", "TT")), goster={"yontem": ["cevrim"]}),
    ctl("zs_olc", "Ölçülen çevrim empedansı Zs (TT'de RA)", "sayi", 0.9, min=0.05, max=2000, adim=0.05, birim="Ω", goster={"yontem": ["cevrim"]}),
    ctl("cihaz", "Koruma cihazı", "sec", "MCB", secenek=opt(("MCB", "Otomat (MCB)"), ("gG", "NH gG sigorta")), goster={"yontem": ["cevrim"]}),
    ctl("egri", "Otomat eğrisi", "sec", "B", secenek=opt(("B", "B"), ("C", "C"), ("D", "D")), goster={"yontem": ["cevrim"]}),
    ctl("in_a", "Anma akımı", "sec", 16, secenek=opt(*[(v, f"{v} A") for v in (6, 10, 16, 20, 25, 32, 40, 50, 63, 80, 100)]), goster={"yontem": ["cevrim"]}),
    ctl("devre", "Devre türü", "sec", "nihai", secenek=opt(("nihai", "nihai devre — 0,4 s"), ("dagitim", "dağıtım devresi — 5 s")), goster={"yontem": ["cevrim"]}),
    ctl("idn_ma", "Kaçak akım rölesi IΔn", "sec", 30, secenek=opt((0, "yok"), (30, "30 mA"), (100, "100 mA"), (300, "300 mA")), goster={"yontem": ["cevrim"]}),
    ctl("t1_ms", "Ölçülen açma süresi (1 × IΔn)", "sayi", 45, min=1, max=1000, adim=1, birim="ms", goster={"yontem": ["cevrim"]}),
    ctl("t5_ms", "Ölçülen açma süresi (5 × IΔn)", "sayi", 18, min=1, max=500, adim=1, birim="ms", goster={"yontem": ["cevrim"]}),
]
EK_N = "Topraklamalar Yön. Ek-N (N.2.2.1)"


def _tablolar() -> list[dict]:
    per = ruleset().topraklama["periyodik_olcum"]
    sinir = {"baslik": "Tesise göre ölçümler ve sınırlar", "cols": ["Tesis", "Ölçüm", "Sınır", "Dayanak", "Durum"], "rows": [
        ["Her AG tesisi (ev, villa, apartman, işyeri)", "Koruma ve eşpotansiyel iletkenlerinin sürekliliği", "kesintisiz, düşük dirençli (ölçüm akımı ≥ 0,2 A)", "Topraklamalar Yön. m.10; TS HD 60364-6", "resmi"],
        ["Her AG tesisi", "Yalıtım direnci (500 V d.a.; SELV/PELV 250 V; > 500 V devrede 1000 V)", "≥ 0,5 MΩ (SELV/PELV ≥ 0,25 MΩ; > 500 V ≥ 1,0 MΩ)", "Topraklamalar Yön. m.10, Çizelge-9", "resmi"],
        ["TN sistemli tesis", "Çevrim empedansı (her devrenin en uzak noktası)", "Zs · Ia ≤ U0 ; ölçüm soğuk iletkende yapıldığından okunan değer ≤ ⅔ · U0 / Ia", "Topraklamalar Yön. m.8-a3.3, m.10; TS HD 60364-6 Ek", "dogrulanacak"],
        ["TT sistemli tesis (villa, köy evi, şantiye)", "Topraklama direnci RA ve RCD testi", "RA ≤ 50 V / IΔn → 30 mA: 1666 Ω · 100 mA: 500 Ω · 300 mA: 166 Ω · 500 mA: 100 Ω (S tipi: yarısı)", "Topraklamalar Yön. m.8-a4, Çizelge-12", "resmi"],
        ["Kaçak akım rölesi bulunan her devre", "Açma akımı ve süresi (test cihazıyla)", "½·IΔn: açmaz · 1·IΔn: ≤ 300 ms · 5·IΔn: ≤ 40 ms (S tipi: 130–500 ms / 50–150 ms)", "Topraklamalar Yön. m.10-6.3; TS EN 61008-1", "dogrulanacak"],
        ["Hastane — grup 2 mahal (ameliyathane, yoğun bakım)", "Ek eşpotansiyel dengeleme; tıbbi IT sistemi", "gövdeler ile eşpotansiyel bara arası ≤ 0,2 Ω ; yalıtım izleme alarmı ≥ 50 kΩ", "TS HD 60364-7-710", "dogrulanacak"],
        ["Trafo merkezi, fabrika (YG tesisi)", "Topraklama direnci RE; gerekirse dokunma gerilimi (akım–gerilim yöntemi)", "UE = RE · IE ≤ 2 · UTp(tF) ; aşılıyorsa UT ≤ UTp ölçümle kanıtlanır (vücut direnci 1 kΩ, ayak elektrodu 400 cm², 500 N)", "Topraklamalar Yön. m.5, m.11, Ek-G, Ek-N", "resmi"],
        ["Yıldırımdan korunma tesisi", "Topraklama direnci (her iniş iletkeni ayrılarak)", "≤ 10 Ω önerilir (düşük frekansta ölçülen)", "TS EN 62305-3", "dogrulanacak"],
        ["GES (çatı / arazi)", "Konstrüksiyon ve panel çerçevesi sürekliliği, DC yalıtım direnci, topraklama direnci", "süreklilik kesintisiz ; yalıtım ≥ 1 MΩ (dizi gerilimine göre 500/1000 V) ; RE tesisin AG / YG koşuluna göre", "TS EN 62446-1; Topraklamalar Yön.", "dogrulanacak"],
        ["Genel (TN, sayısal sınır yok)", "Temel / halka topraklayıcı direnci", "yönetmelikte genel bir Ω sınırı yoktur; belirleyici olan açma koşulu ve UE'dir. Uygulamada hedef ≤ 2–5 Ω (şartname / müellif kararı)", "Topraklamalar Yön. m.8; dağıtım şirketi şartnameleri", "ikincil"]],
        "not": "“Topraklama 2 Ω olmalı”, “5 Ω'u geçmemeli” gibi piyasada dolaşan değerlerin çoğu yönetmelik maddesi değil, şartname ya da alışkanlıktır. Durum sütunu hangisinin resmi olduğunu gösterir."}
    periyot = {"baslik": "Muayene ve ölçme periyotları", "cols": ["Tesis", "En çok"], "rows": [
        ["Elektrik üretim, iletim ve dağıtım tesisleri (ENH hariç)", f"{per['uretim_iletim_dagitim_yil']} yıl"], ["Enerji nakil ve dağıtım hatları", f"{per['enh_yil']} yıl"],
        ["Sanayi tesisleri ve iş merkezleri — topraklama dirençlerinin muayene ve ölçülmesi", f"{per['sanayi_direnc_yil']} yıl"], ["Sanayi tesisleri ve iş merkezleri — topraklama tesisiyle ilgili diğer muayene, ölçme ve kontroller", f"{per['sanayi_diger_yil']} yıl"],
        ["Sabit olmayan tesisler — sabit işletme elemanları", f"{per['sabit_olmayan_yil']} yıl"], ["Sabit olmayan tesisler — yer değiştirebilen işletme elemanları", f"{per['tasinabilir_ay']} ay"],
        ["Parlayıcı, patlayıcı tehlikeli ve ıslak işyerleri", f"{per['patlayici_islak_max_yil']} yıl"], ["İşyerlerinde elektrik tesisatı ve topraklama (iş ekipmanı olarak)", f"{per['is_ekipmanlari_yil']} yıl"]],
        "not": f"{per['kaynak']} — durum: {per['durum']}"}
    cihaz = {"baslik": "Hangi ölçüm hangi cihazla?", "cols": ["Ölçüm", "Cihaz", "Standart", "Dikkat"], "rows": [
        ["Topraklama direnci (3 / 4 uçlu)", "Toprak megeri (topraklama ölçme cihazı), 2 yardımcı kazık", "TS EN 61557-5", "Ölçüm frekansı ≤ 150 Hz; topraklayıcı tesisten ayrılarak ölçülür; kazıklar bir doğru üzerinde"],
        ["Toprak özdirenci", "4 uçlu toprak megeri, 4 kazık (Wenner)", "TS EN 61557-5; Ek-N.1", "Farklı aralıklarla ve iki dik doğrultuda ölçülür; yağıştan hemen sonra ölçülmez"],
        ["Kazıksız (döngü) ölçümü", "Pens tipi topraklama ölçer", "TS EN 61557-5 (pens yöntemi)", "Yalnız paralel dönüş yolu varsa çalışır; tek başına topraklayıcıda ölçmez"],
        ["Çevrim empedansı, kısa devre akımı", "Çok işlevli tesisat test cihazı", "TS EN 61557-3", "RCD'li devrede “açtırmayan” ölçüm modu; panoda ve en uzak prizde"],
        ["Kaçak akım rölesi", "Çok işlevli tesisat test cihazı (RCD testi)", "TS EN 61557-6", "½×, 1×, 5× ve rampa; yükler ayrılarak"],
        ["Süreklilik", "Düşük direnç ölçer (≥ 0,2 A, 4–24 V)", "TS EN 61557-4", "Ölçü kablolarının direnci sıfırlanır"],
        ["Yalıtım direnci", "Megger (yalıtım test cihazı, 250 / 500 / 1000 V d.a.)", "TS EN 61557-2", "Elektronik cihazlar ve parafudrlar ayrılır; faz–nötr köprülenip toprağa karşı"],
        ["Dokunma ve adım gerilimi (YG tesisi)", "Akım enjeksiyon düzeni (≥ 50 A), yüksek iç dirençli voltmetre", "Topraklamalar Yön. Ek-G, Ek-N.2.2.3", "Uzak topraklayıcı mümkünse ≥ 5 km; bozucu gerilimler yok edilir"]],
        "not": "TS EN 61557 serisi (AG dağıtım sistemlerinde koruma önlemlerinin deneyden geçirilmesi için donanım) — durum: dogrulanacak"}
    return [sinir, periyot, cihaz]


def yuzde(h: float) -> str:
    """İşaretli yüzde: +%3,2 / −%8,0."""
    return ("−" if h < 0 else "+") + "%" + fnum(abs(h), 1)


def _uc_kazik(p: dict) -> dict:
    re_ = num(p, "re_gercek", 10); d = num(p, "d_el", 3); c = num(p, "c_m", 40); rho = num(p, "rho", 100)
    pp = num(p, "p_pct", 62) / 100.0
    r = rho / (2 * math.pi * re_)                     # eşdeğer yarım kürenin yarıçapı
    def olc(frac: float) -> float:
        x = max(frac * c, r * 1.02)
        return rho / (2 * math.pi) * (1 / r - 1 / c - 1 / x + 1 / max(c - x, 0.05))
    rm = olc(pp)
    hata = (rm - re_) / re_ * 100
    p_min = max(20.0, 2.5 * d); c_min = max(40.0, 4 * d)
    an = [f"Cihaz, topraklayıcı (E) ile akım kazığı (C) arasından akım geçirir ve topraklayıcı ile gerilim kazığı (P) arasındaki gerilimi ölçer: R = U / I. Akım kazığı {fnum(c, 0)} m, gerilim kazığı {fnum(pp * c, 1)} m uzakta.",
          "Hem topraklayıcının hem akım kazığının çevresinde birer potansiyel hunisi vardır. Gerilim kazığı, iki huninin de etkisinin kalmadığı düz bölgeye (referans toprak) çakılmalıdır.",
          f"Bu yerleşimde cihaz {fnum(rm, 2)} Ω okur; gerçek değer {fnum(re_, 2)} Ω. Sapma {yuzde(hata)}.",
          "Gerilim kazığı topraklayıcıya yaklaştırılırsa değer küçük, akım kazığına yaklaştırılırsa büyük okunur. Homojen toprakta iki etkinin birbirini götürdüğü yer akım kazığı uzaklığının %61,8'idir (“%62 kuralı”).",
          "Doğrulama: gerilim kazığı ±%10 (ör. %52 ve %72) kaydırılıp ölçüm tekrarlanır. Üç değer birbirine yakınsa (plato) ölçüm geçerlidir; değilse akım kazığı daha uzağa çakılır."]
    if c < c_min:
        an.append(f"Akım kazığı çok yakın: topraklayıcının hunisi ile kazığın hunisi iç içe giriyor, arada düz bölge kalmıyor. Bu topraklayıcı için en az {fnum(c_min, 0)} m gerekir.")
    kt = [C("Akım kazığının (yardımcı topraklayıcı) uzaklığı", f"C = {fnum(c, 0)} m", f"≥ {fnum(c_min, 0)} m  (en az 40 m ve topraklayıcı boyutunun 4 katı)", c >= c_min - 1e-9, EK_N),
          C("Gerilim kazığının (sonda) uzaklığı", f"P = {fnum(pp * c, 1)} m", f"≥ {fnum(p_min, 0)} m  (en az 20 m ve topraklayıcı boyutunun 2,5 katı)", pp * c >= p_min - 1e-9, EK_N),
          C("Kazıkların dizilişi", "bir doğru üzerinde, birbirinden olabildiğince uzak", "topraklayıcı, sonda ve yardımcı topraklayıcı bir doğru üzerinde", None, EK_N),
          C("Ölçüm sapması", f"{yuzde(hata)}", "± %5 içinde (plato bölgesi)", abs(hata) <= 5.0, "Uygulama ölçütü; %62 kuralı (homojen toprak varsayımı)", "ikincil")]
    ds = ["Kazıklar yakın çakılırsa okunan değer neredeyse her zaman gerçekten küçüktür: tehlikeli olan budur, çünkü “iyi” görünür.",
          "Büyük topraklayıcı büyük huni demektir: 3 m'lik kazık için 40 m yeter, 30 m'lik bir ağ için 120 m gerekir. Yoğun yerleşimde bu çoğu zaman mümkün değildir (o zaman çevrim ya da pens yöntemi).",
          "Topraklayıcı tesisten ayrılarak ölçülür; ayrılmazsa şebekenin bütün topraklamaları paralel girer ve değer çok küçük çıkar.",
          "Kazıkların kendi dirençleri sonucu etkilemez (cihaz bunu dengeler), ama çok yüksekse cihaz ölçemez: kazığın dibi ıslatılır.",
          "Toprak nemliyken ölçülen değer en iyi durumdur; kuru mevsimde direnç 2–3 kat artabilir."]
    egri = [[round(f * 100, 1), round(olc(f), 3)] for f in [k / 100 for k in range(5, 96)]]
    graf = [{"baslik": "Gerilim kazığının yerine göre okunan direnç", "x_ad": "gerilim kazığının yeri (akım kazığı uzaklığının %'si)", "y_ad": "okunan direnç (Ω)", "seriler": [{"ad": "cihazın okuduğu", "renk": "#1a4d8f", "pts": egri}],
             "yatay": [{"y": re_, "etiket": f"gerçek RE = {fnum(re_, 2)} Ω", "renk": "#15803d"}], "isaretler": [{"x": pp * 100, "etiket": f"sonda %{fnum(pp * 100, 0)}"}], "ymin": 0, "ymax": re_ * 2.2}]
    oz = [K("Cihazın okuduğu", f"{fnum(rm, 2)} Ω", "ok" if abs(hata) <= 5 else "bad", f"gerçek {fnum(re_, 2)} Ω"), K("Sapma", f"{yuzde(hata)}", "ok" if abs(hata) <= 5 else "bad", "küçük okuyor" if hata < 0 else "büyük okuyor"),
          K("Gereken en küçük uzaklıklar", f"C ≥ {fnum(c_min, 0)} m", "ok" if c >= c_min else "bad", f"P ≥ {fnum(p_min, 0)} m"), K("Eşdeğer huni yarıçapı", f"{fnum(r, 1)} m", "info", "ρ / (2π·RE)")]
    sahne = {"tip": "olcum", "yontem": "uc_kazik", "c": c, "p": round(pp * c, 1), "r": round(r, 2), "okunan": f"{fnum(rm, 2)} Ω", "gercek": f"{fnum(re_, 2)} Ω", "ok": abs(hata) <= 5 and c >= c_min, "hata": f"{yuzde(hata)}"}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "grafikler": graf}


def rho_gorunur(a: float, rho1: float, rho2: float, h: float) -> float:
    """İki tabakalı toprakta Wenner görünür özdirenci (görüntü serisi)."""
    k = (rho2 - rho1) / (rho2 + rho1)
    s = 0.0
    for n in range(1, 200):
        t = k ** n * (1 / math.sqrt(1 + (2 * n * h / a) ** 2) - 1 / math.sqrt(4 + (2 * n * h / a) ** 2))
        s += t
        if abs(t) < 1e-9:
            break
    return rho1 * (1 + 4 * s)


def _wenner(p: dict) -> dict:
    a = num(p, "a_m", 3); r1 = num(p, "rho1", 100); r2 = num(p, "rho2", 400); h = num(p, "h_m", 2)
    ra = rho_gorunur(a, r1, r2, h)
    r_olc = ra / (2 * math.pi * a)
    an = [f"Dört kazık bir doğru üzerine eşit aralıklarla ({fnum(a, 1)} m) çakılır. Dıştaki iki kazıktan akım geçirilir, içteki iki kazık arasındaki gerilim ölçülür.",
          f"Cihaz R = {fnum(r_olc, 2)} Ω okur. Özdirenç: ρ = 2π · a · R = 2π × {fnum(a, 1)} × {fnum(r_olc, 2)} = {fnum(ra, 0)} Ω·m.",
          f"Bu değer “görünür” özdirençtir: akımın büyük kısmı yaklaşık kazık aralığı kadar derinlikten geçer. a küçükken üst tabakayı ({fnum(r1, 0)} Ω·m), a büyüdükçe alt tabakayı ({fnum(r2, 0)} Ω·m) görürsünüz.",
          "Bu yüzden ölçüm tek aralıkla yapılmaz: 1, 2, 4, 8, 16 m gibi artan aralıklarla tekrarlanır ve özdirencin derinlikle değişimi çıkarılır. Kazık boyu ve derin topraklayıcı kararı bu eğriye göre verilir."]
    if r2 < r1:
        an.append("Alt tabaka daha iletken: derin kazık işe yarar (kazık iletken tabakaya ulaşır).")
    else:
        an.append("Alt tabaka daha dirençli (kaya): kazığı uzatmak fayda sağlamaz; yüzeye yakın uzun şerit ya da halka daha etkilidir.")
    kt = [C("Kazıkların çakılma derinliği", f"a = {fnum(a, 1)} m için ≤ {fnum(a / 20, 2)} m", "≤ a / 20 (nokta elektrot varsayımı)", None, "Wenner yöntemi; Topraklamalar Yön. Ek-N.1", "ikincil"),
          C("Ölçüm sayısı", "birkaç aralık ve iki dik doğrultu", "özdirencin çeşitli derinlikler için belirlenmesi", None, "Topraklamalar Yön. Ek-N.1")]
    ds = ["Özdirenç, topraklama tasarımının tek gerçek girdisidir: kazık sayısı, şerit boyu, RE tahmini hep ondan çıkar. Tabloya bakarak tahmin etmek %300 yanılabilir.",
          "Wenner'de aralık = bakılan derinlik. Schlumberger düzeninde içteki kazıklar sabit kalır, yalnız dıştakiler açılır; derin araştırmada daha az iş çıkar: ρ = π · (L² − l²) / (2·l) · R.",
          "Ölçüm doğrultusunda gömülü boru, kablo, ray varsa akım oradan geçer ve değer küçük çıkar: ikinci ölçüm dik doğrultuda yapılır."]
    xs = [0.5 * 1.25 ** k for k in range(0, 22)]
    graf = [{"baslik": "Görünür özdirenç – kazık aralığı", "x_ad": "kazık aralığı a (m)", "y_ad": "görünür özdirenç (Ω·m)", "logx": True, "seriler": [{"ad": "ρa(a)", "renk": "#b45309", "pts": [[round(x, 2), round(rho_gorunur(x, r1, r2, h), 1)] for x in xs]}],
             "yatay": [{"y": r1, "etiket": f"üst tabaka {fnum(r1, 0)} Ω·m", "renk": "#15803d"}, {"y": r2, "etiket": f"alt tabaka {fnum(r2, 0)} Ω·m", "renk": "#334155"}], "isaretler": [{"x": a, "etiket": f"a = {fnum(a, 1)} m"}]}]
    oz = [K("Cihazın okuduğu", f"{fnum(r_olc, 2)} Ω", "info", "R = U / I"), K("Görünür özdirenç", f"{fnum(ra, 0)} Ω·m", "info", "ρ = 2π·a·R"), K("Bakılan derinlik", f"≈ {fnum(a, 1)} m", "info", "kazık aralığı kadar"),
          K("Tabakalar", f"{fnum(r1, 0)} / {fnum(r2, 0)} Ω·m", "info", f"sınır {fnum(h, 1)} m derinde")]
    sahne = {"tip": "olcum", "yontem": "wenner", "a": a, "h": h, "rho1": r1, "rho2": r2, "okunan": f"{fnum(r_olc, 2)} Ω", "rho_a": f"{fnum(ra, 0)} Ω·m", "ok": True}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "grafikler": graf}


def _pens(p: dict) -> dict:
    rx = num(p, "rx", 10); n = int(num(p, "n_par", 12)); rd = num(p, "r_diger", 10)
    if n <= 0:
        an = ["Pens, topraklama iletkenine takılır ve iletkende bir gerilim endükler; oluşan akımdan döngünün direncini bulur. Ama bu topraklayıcı tek başına: akımın dolaşacağı kapalı bir döngü yok.",
              "Cihaz ya “açık devre / ölçüm aralığı dışı” gösterir ya da (başka bir metal yoldan kapanan döngü varsa) topraklamayla ilgisi olmayan küçük bir değer okur.",
              "Tek başına duran bir topraklayıcı (TT evin kazığı, tek bir yıldırımlık inişi, yeni tesis edilmiş ve henüz bağlanmamış topraklayıcı) pensle ölçülemez; kazıklı yöntem gerekir."]
        kt = [C("Kapalı dönüş yolu", "yok", "en az bir paralel topraklayıcı / dönüş yolu gerekli", False, "Pens (kazıksız) yönteminin ilkesi; TS EN 61557-5", "ikincil")]
        oz = [K("Cihazın okuduğu", "ölçemez", "bad", "döngü yok"), K("Gerçek değer", f"{fnum(rx, 2)} Ω", "info", "")]
        sahne = {"tip": "olcum", "yontem": "pens", "n": 0, "okunan": "—", "gercek": f"{fnum(rx, 2)} Ω", "ok": False, "hata": "ölçülemez"}
        return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ["Pens yöntemi kazık gerektirmez ama bir döngüye ihtiyaç duyar; döngü yoksa ölçüm de yoktur."], "sahne": sahne}
    rp = rd / n
    rm = rx + rp
    hata = (rm - rx) / rx * 100
    an = [f"Pens topraklama iletkenine takıldı. Cihaz iletkende küçük bir gerilim endükler; akım bu topraklayıcıdan toprağa geçer ve diğer {n} topraklayıcı üzerinden geri döner.",
          f"Cihazın ölçtüğü döngünün direncidir: R = Rx + (diğerlerinin paraleli) = {fnum(rx, 2)} + {fnum(rd, 2)} / {n} = {fnum(rm, 2)} Ω. Gerçek değer {fnum(rx, 2)} Ω; sapma +%{fnum(hata, 0)}.",
          "Paralel topraklayıcı sayısı arttıkça ikinci terim küçülür ve okunan değer gerçeğe yaklaşır. Okunan değer her zaman gerçekten büyüktür: güvenli taraftadır.",
          "TN tesiste pens koruma iletkenine takılırsa döngü toprak üzerinden değil, PE / PEN iletkeni üzerinden kapanır: okunan birkaç on miliohm topraklama direnci değil, iletken döngüsünün direncidir."]
    kt = [C("Kapalı dönüş yolu", f"{n} paralel topraklayıcı", "en az bir paralel topraklayıcı / dönüş yolu gerekli", True, "Pens (kazıksız) yönteminin ilkesi; TS EN 61557-5", "ikincil"),
          C("Ölçüm sapması", f"+%{fnum(hata, 0)}", "≤ %10 (paralel yol sayısı yeterli)", hata <= 10.0, "Uygulama ölçütü", "ikincil")]
    ds = ["Pens yöntemi çok topraklayıcılı sistemlerde hızlıdır: direk topraklamaları, yıldırımlık inişleri, çok noktadan topraklı PEN.",
          "Topraklayıcıyı tesisten ayırmak gerekmez — ama tam da bu yüzden neyi ölçtüğünüzü bilmeniz gerekir: döngü toprak üzerinden mi kapanıyor, bir iletken üzerinden mi?",
          "Çok küçük (< 1 Ω) ve çok kararlı bir değer çoğu zaman topraklama değil, metal bir döngüdür."]
    oz = [K("Cihazın okuduğu", f"{fnum(rm, 2)} Ω", "ok" if hata <= 10 else "warn", f"gerçek {fnum(rx, 2)} Ω"), K("Sapma", f"+%{fnum(hata, 0)}", "ok" if hata <= 10 else "warn", "her zaman büyük okur"),
          K("Dönüş yolu", f"{fnum(rp, 2)} Ω", "info", f"{n} topraklayıcı paralel")]
    sahne = {"tip": "olcum", "yontem": "pens", "n": n, "okunan": f"{fnum(rm, 2)} Ω", "gercek": f"{fnum(rx, 2)} Ω", "ok": hata <= 10, "hata": f"+%{fnum(hata, 0)}"}
    graf = [{"baslik": "Paralel topraklayıcı sayısına göre okunan değer", "x_ad": "paralel topraklayıcı sayısı", "y_ad": "okunan direnç (Ω)", "seriler": [{"ad": "cihazın okuduğu", "renk": "#1a4d8f", "pts": [[k, round(rx + rd / k, 2)] for k in range(1, 41)]}],
             "yatay": [{"y": rx, "etiket": f"gerçek {fnum(rx, 2)} Ω", "renk": "#15803d"}], "isaretler": [{"x": n, "etiket": f"{n} adet"}], "ymin": 0}]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne, "grafikler": graf}


def _cevrim(p: dict) -> dict:
    R = rules()["rcd"]["acma_suresi"]
    tt = p.get("sistem") == "TT"
    zs = num(p, "zs_olc", 0.9); idn = num(p, "idn_ma", 30); t1 = num(p, "t1_ms", 45); t5 = num(p, "t5_ms", 18)
    t_izin = 0.4 if p.get("devre", "nihai") == "nihai" else 5.0
    ia = cihaz_ia(p, t_izin); ad = cihaz_adi(p)
    kt, an = [], []
    if not tt:
        lim = 230.0 / ia; lim_olc = lim * 2 / 3
        an += [f"Test cihazı priz ile koruma iletkeni arasından kısa süreli bir akım çekip gerilim düşümünden çevrim empedansını bulur: Zs = {fnum(zs, 2)} Ω → beklenen arıza akımı 230 / {fnum(zs, 2)} = {fnum(230 / zs, 0)} A.",
               f"{ad} bu devrede {fnum(t_izin, 1)} s içinde açmak için {fnum(ia, 0)} A ister: izin verilen Zs = 230 / {fnum(ia, 0)} = {fnum(lim, 2)} Ω.",
               f"Ölçüm oda sıcaklığındaki iletkende yapılır; arıza anında iletken ısınır ve direnci artar. Bu yüzden okunan değer sınırın üçte ikisini ({fnum(lim_olc, 2)} Ω) geçmemelidir."]
        kt.append(C("Çevrim empedansı (hesap sınırı)", f"Zs · Ia = {fnum(zs, 2)} × {fnum(ia, 0)} = {fnum(zs * ia, 0)} V", "≤ U0 = 230 V", zs * ia <= 230 + 1e-9, "Topraklamalar Yön. m.8-a3.3"))
        kt.append(C("Çevrim empedansı (ölçülen değer için)", f"Zs(ölçülen) = {fnum(zs, 2)} Ω", f"≤ ⅔ · U0 / Ia = {fnum(lim_olc, 2)} Ω", zs <= lim_olc + 1e-9, "TS HD 60364-6 (sıcaklık artışı payı)", "dogrulanacak"))
        if idn and zs * ia > 230:
            an.append(f"Aşırı akım cihazı koşulu sağlamıyor; koruma {fnum(idn, 0)} mA kaçak akım rölesiyle sağlanır (m.8-a3.6). Röle testinin geçmesi şarttır.")
    else:
        lim = 50.0 / (idn / 1000.0) if idn else 0.0
        an += [f"TT'de test cihazı faz ile koruma iletkeni arasındaki çevrimi ölçer; bu değer pratikte RA + RB'dir ve RA'nın üst sınırı olarak kullanılır: {fnum(zs, 1)} Ω.",
               (f"Koşul RA · IΔn ≤ 50 V: {fnum(zs, 1)} Ω × {fnum(idn / 1000, 3)} A = {fnum(zs * idn / 1000, 1)} V. İzin verilen en büyük RA = {fnum(lim, 0)} Ω." if idn else "TT'de kaçak akım rölesi yok: bu direnç değerleriyle aşırı akım cihazı açmaz; koruma yoktur.")]
        kt.append(C("TT koşulu", f"RA · IΔn = {fnum(zs * idn / 1000, 1)} V" if idn else "kaçak akım rölesi yok", "≤ 50 V", bool(idn) and zs * idn / 1000 <= 50 + 1e-9, "Topraklamalar Yön. m.8-a4, Çizelge-12"))
    if idn:
        an.append(f"Röle testi: 1 × IΔn'de {fnum(t1, 0)} ms, 5 × IΔn'de {fnum(t5, 0)} ms ölçüldü. Sınırlar {fnum(R['genel']['1'] * 1000, 0)} ms ve {fnum(R['genel']['5'] * 1000, 0)} ms.")
        kt.append(C("RCD açma süresi (1 × IΔn)", f"{fnum(t1, 0)} ms", f"≤ {fnum(R['genel']['1'] * 1000, 0)} ms", t1 <= R["genel"]["1"] * 1000, R["kaynak"], R["durum"]))
        kt.append(C("RCD açma süresi (5 × IΔn)", f"{fnum(t5, 0)} ms", f"≤ {fnum(R['genel']['5'] * 1000, 0)} ms", t5 <= R["genel"]["5"] * 1000, R["kaynak"], R["durum"]))
    ds = ["Çevrim empedansı ölçümü, hesabın sahadaki sağlamasıdır: gevşek klemens, eksik PE, yanlış kesit burada ortaya çıkar.",
          "Ölçüm her devrenin en uzak noktasında yapılır; panodaki değer yalnız kaynak tarafını gösterir.",
          "Kaçak akım rölesi olan devrede cihazın “açtırmayan” (düşük akımlı) modu kullanılır; bu modun doğruluğu daha düşüktür.",
          "Rölenin test düğmesine basmak ölçüm değildir: açma akımı ve süresi yalnız test cihazıyla görülür."]
    ok = all(k["ok"] is not False for k in kt)
    oz = [K("Ölçülen çevrim", f"{fnum(zs, 2)} Ω", "info", "RA + RB (TT)" if tt else f"Ik ≈ {fnum(230 / zs, 0)} A"), K("Koruma cihazı", ad, "info", f"Ia = {fnum(ia, 0)} A ({fnum(t_izin, 1)} s)"),
          K("Kaçak akım rölesi", f"{fnum(idn, 0)} mA" if idn else "yok", "info", f"{fnum(t1, 0)} / {fnum(t5, 0)} ms" if idn else ""), K("Sonuç", "geçer" if ok else "kalır", "ok" if ok else "bad", "devreye alma ölçümü")]
    sahne = {"tip": "olcum", "yontem": "cevrim", "okunan": f"{fnum(zs, 2)} Ω", "ok": ok, "tt": tt, "ad": ad, "idn": idn, "t1": t1, "t5": t5}
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": sahne}


def run(p: dict) -> dict:
    y = p.get("yontem") if p.get("yontem") in YONTEM else "uc_kazik"
    out = {"uc_kazik": _uc_kazik, "wenner": _wenner, "pens": _pens, "cevrim": _cevrim}[y](p)
    out["tablolar"] = _tablolar()
    return out
