"""Laboratuvar konusu — jeneratör ve UPS ile ada modu: nötrün topraklanması, 3 / 4 kutuplu transfer, küçük arıza akımıyla açma.

Model: şebeke modunda arıza akımını trafo ve hat empedansı belirler. Jeneratör modunda ilk anda (geçici altı) I″ = U0 / √(R² + X″d²),
birkaç periyot sonra jeneratörün sürekli kısa devre akımına (uyartım destekli ≈ 3·In, desteksiz ≈ In'in altı) düşer. UPS eviricisi
≈ 2–3·In ile sınırlar. Otomatın manyetik açtırıcısı ilk andaki akımla, ısıl açtırıcısı sürekli akımla çalışır.
Dayanak: TS HD 60364-5-551; TS HD 60364-4-41; Topraklamalar Yön. m.8 — madde ayrıntıları doğrulanacak."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, RHO_CU, cihaz_adi, cihaz_sure, ctl, fnum, fsure, mcb_ia, num, opt, rcd_sure

ID = "jenerator"
BASLIK = "Jeneratör / UPS — ada modu"
IKON = "🔁"
GIRIS = ("Şebeke gidip jeneratör devreye girdiğinde iki şey değişir: nötrün toprağa bağlandığı nokta ve arıza akımının büyüklüğü. Şebekede anında açan otomat, "
         "jeneratörde hiç açmayabilir; yanlış kurulmuş transfer düzeni ise tesisi fark ettirmeden topraksız bırakır ya da nötr akımını koruma iletkenine taşır.")
DUZEN = {"ayri_4p": "Jeneratör nötrü jeneratörde topraklı; 4 kutuplu transfer (nötr de anahtarlanır)", "ortak_3p": "Nötr yalnız ana panoda topraklı, jeneratör nötrü oraya bağlı; 3 kutuplu transfer",
         "ayri_3p": "Jeneratör nötrü jeneratörde topraklı; 3 kutuplu transfer (iki topraklama noktası sürekli bağlı)", "topraksiz": "Jeneratör nötrü topraklanmamış; 4 kutuplu transfer"}
D = "dogrulanacak"

KONTROLLER = [
    ctl("mod", "Besleme", "sec", "jen", secenek=opt(("sebeke", "Şebeke"), ("jen", "Jeneratör (ada modu)"), ("ups", "UPS (akü, evirici)"))),
    ctl("duzen", "Nötr topraklaması ve transfer", "sec", "ayri_4p", secenek=opt(*DUZEN.items())),
    ctl("gen_kva", "Jeneratör / UPS gücü", "sec", 250, secenek=opt(*[(v, f"{v} kVA") for v in (20, 40, 60, 100, 160, 250, 400, 630, 1000)])),
    ctl("xd2", "Jeneratör geçici altı reaktansı x″d", "sayi", 12, min=6, max=25, adim=1, birim="%", goster={"mod": ["jen"]}),
    ctl("destek", "Uyartım kısa devre desteği var (sürekli ≈ 3·In)", "onay", True, goster={"mod": ["jen"]}),
    ctl("egri", "Otomat eğrisi", "sec", "C", secenek=opt(("B", "B"), ("C", "C"), ("D", "D"))),
    ctl("in_a", "Otomat anma akımı", "sec", 32, secenek=opt(*[(v, f"{v} A") for v in (6, 10, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125)])),
    ctl("l_m", "Hat uzunluğu", "sayi", 40, min=1, max=300, adim=1, birim="m"),
    ctl("s_mm2", "Faz ve koruma iletkeni kesiti", "sec", 6, secenek=opt(*[(v, f"{v:g} mm²") for v in (1.5, 2.5, 4, 6, 10, 16, 25, 35, 50)])),
    ctl("rcd_ma", "Kaçak akım rölesi", "sec", 0, secenek=opt((0, "yok"), (30, "30 mA"), (300, "300 mA"))),
    ctl("i_notr", "Nötrdeki işletme akımı (dengesizlik + harmonik)", "sayi", 40, min=0, max=400, adim=5, birim="A", goster={"duzen": ["ayri_3p"]}),
]


def run(p: dict) -> dict:
    mod = p.get("mod") if p.get("mod") in ("sebeke", "jen", "ups") else "jen"
    duzen = p.get("duzen") if p.get("duzen") in DUZEN else "ayri_4p"
    sn = num(p, "gen_kva", 250) * 1000; in_g = sn / (math.sqrt(3) * 400)
    r_hat = 2 * RHO_CU * num(p, "l_m", 40) / num(p, "s_mm2", 6)
    in_a = num(p, "in_a", 32); egri = str(p.get("egri") or "C"); rcd = int(num(p, "rcd_ma", 0))
    pp = {"cihaz": "MCB", "egri": egri, "in_a": in_a}
    topraksiz = duzen == "topraksiz" and mod != "sebeke"
    if mod == "sebeke":
        i_ilk = i_sur = 230.0 / (0.03 + r_hat)
    elif mod == "jen":
        x2 = num(p, "xd2", 12) / 100 * 400 ** 2 / sn
        i_ilk = 230.0 / math.hypot(r_hat, x2)
        i_sur = min(i_ilk, (3.0 if p.get("destek", True) else 0.8) * in_g)
    else:
        i_ilk = i_sur = min(230.0 / r_hat, 2.5 * in_g)
    if topraksiz:
        i_ilk = i_sur = 0.0
    im = mcb_ia(in_a, egri, 0.1)
    t_oc = 0.01 if i_ilk >= im else cihaz_sure(pp, i_sur) if i_sur > 0 else math.inf
    t_rcd = rcd_sure(rcd, i_sur * 1000) if (rcd and i_sur > 0) else math.inf
    t = min(t_oc, t_rcd)
    an = [{"sebeke": f"Şebeke modu: arıza akımını trafo ve hat belirler. {fnum(num(p, 'l_m', 40), 0)} m, {fnum(num(p, 's_mm2', 6), 1)} mm² hattın sonundaki faz–gövde arızasında If ≈ {fnum(i_ilk, 0)} A.",
           "jen": f"Jeneratör modu: {fnum(sn / 1000, 0)} kVA jeneratörün anma akımı {fnum(in_g, 0)} A. Arızanın ilk periyotlarında akım ≈ {fnum(i_ilk, 0)} A (x″d ile), ardından uyartımın verebildiği sürekli değere düşer: ≈ {fnum(i_sur, 0)} A.",
           "ups": f"UPS modu: evirici çıkış akımını yarı iletkenlerini korumak için sınırlar: ≈ 2,5 × In = {fnum(i_sur, 0)} A, o da 100–200 ms. Bypass şebekesi yoksa arızayı besleyecek başka kaynak yoktur."}[mod]]
    kt = []
    if topraksiz:
        an += ["Jeneratörün nötrü hiçbir yerde topraklı değil ve transfer nötrü şebekeden ayırıyor: ada modunda tesis topraksız (IT gibi) çalışır. Faz gövdeye değdiğinde akımın dönecek yolu yoktur: hiçbir cihaz açmaz, kaçak akım rölesi de görmez.",
               "İlk arıza fark edilmez; gövde toprak potansiyelinde kaldığı için tehlike de görünmez. İkinci bir arızada (başka fazda) iki gövde arasında faz arası gerilim oluşur. Yalıtım izleme düzeni yoksa bu durum kabul edilemez."]
    else:
        an.append(f"{egri}{fnum(in_a, 0)} otomatın manyetik açtırıcısı {fnum(im, 0)} A ister. " + ("İlk andaki akım bunu aşıyor: otomat anında açar." if i_ilk >= im else
                  f"Arıza akımı bu eşiğin altında: otomat ısıl açtırıcısıyla açar ({fsure(t_oc)})" + (" — izin verilen sürenin çok üstünde." if t_oc > 5 else ".")))
        if rcd and not math.isinf(t_rcd):
            an.append(f"{rcd} mA kaçak akım rölesi arıza akımının büyüklüğüne bakmaz; birkaç yüz miliamper yeter: {fsure(t_rcd)} içinde açar. Küçük kaynaklarda koruma bu yüzden kaçak akım rölesine dayandırılır.")
    kt.append(C("Arıza çevriminin tamamlanması (nötrün topraklanması)", "ada modunda kaynak nötrü topraklı değil" if topraksiz else "kaynağın nötrü topraklı; koruma iletkeni nötre bağlı",
                "ada modunda da kaynağın nötrü topraklanır (TN korunur) ya da tesis IT olarak tasarlanır ve yalıtım izlenir", not topraksiz, "TS HD 60364-5-551 m.551.4; Topraklamalar Yön. m.8-a3.1", D))
    kt.append(C("Beslemenin otomatik ayrılması", f"{fsure(t)} ({'RCD' if t_rcd < t_oc else cihaz_adi(pp)})" if not math.isinf(t) else "hiçbir cihaz açmıyor", "≤ 0,4 s (nihai devre, 230 V); kaynak ne olursa olsun",
                t <= 0.4 + 1e-9, "Topraklamalar Yön. m.8-a3.3, Çizelge-2; TS HD 60364-5-551 m.551.4.3", "resmi"))
    if duzen == "ayri_3p":
        i_n = num(p, "i_notr", 40)
        an += ["Nötr hem trafoda hem jeneratörde topraklı ve transfer nötrü kesmiyor: iki topraklama noktası nötr ve koruma iletkeni üzerinden sürekli paralel bağlı. Nötr akımı ikiye bölünür: bir bölümü nötr iletkeninden, bir bölümü koruma iletkeni ve toprak üzerinden döner.",
               f"Nötrdeki {fnum(i_n, 0)} A'in yaklaşık yarısı ({fnum(i_n / 2, 0)} A) koruma iletkeninde dolaşır. Toprak arıza koruması ve kaçak akım röleleri bunu arıza sanar (yanlış açma) ya da gerçek arızayı eksik ölçer; koruma iletkeni sürekli akım taşır."]
        kt.append(C("Nötrün tek noktada topraklanması", f"iki noktada topraklı, sürekli bağlı: koruma iletkeninde ≈ {fnum(i_n / 2, 0)} A", "çok kaynaklı tesiste nötr–koruma bağlantısı tek noktada yapılır ya da 4 kutuplu transfer kullanılır", False,
                    "TS HD 60364-4-444 m.444.4.6 (çok kaynaklı TN sistemler); TS HD 60364-5-551", D))
    else:
        kt.append(C("Nötrün tek noktada topraklanması", DUZEN[duzen].split(";")[0], "çok kaynaklı tesiste nötr–koruma bağlantısı tek noktada yapılır ya da 4 kutuplu transfer kullanılır", duzen in ("ayri_4p", "ortak_3p"),
                    "TS HD 60364-4-444 m.444.4.6 (çok kaynaklı TN sistemler); TS HD 60364-5-551", D))
    ds = ["Küçük kaynak, küçük arıza akımı demektir. Şebekede hesaplanan çevrim empedansı koşulu jeneratör ve UPS modunda yeniden doğrulanır; çoğu zaman eğri küçültülür (C → B), anma akımı düşürülür ya da kaçak akım rölesi eklenir.",
          "Jeneratörün kısa devre akımı sabit değildir: ilk periyotlarda In/x″d (6–10 kat), yarım saniye sonra uyartım desteği yoksa anma akımının altına iner. Seçicilik ve açma hesabı bu düşüşe göre yapılır.",
          "Nötr her çalışma biçiminde bir ve yalnız bir noktada toprağa bağlı olmalıdır. İki doğru çözüm vardır: her kaynak kendi nötründen topraklı + 4 kutuplu transfer; ya da tek ortak topraklama noktası + 3 kutuplu transfer.",
          "UPS çıkışında statik bypass şebekesi varsa arıza akımını bypass besler; bypass yokken (akü modunda) koruma eviricinin sınırlı akımıyla çalışmak zorundadır.",
          "Jeneratör gövdesi, yakıt tankı ve egzoz, tesisin topraklama tesisine bağlanır; ayrı bir “jeneratör toprağı” yapılmaz."]
    c = Cizim(900, 300, zemin=258)
    c.kutu(40, 50, 120, 60, "TRAFO", "şebeke", "acti" if mod == "sebeke" else "pasif").kutu(40, 150, 120, 60, "JENERATÖR" if mod != "ups" else "UPS", f"{fnum(sn / 1000, 0)} kVA", "acti" if mod != "sebeke" else "pasif")
    c.hat("M160,70 H300", "L1", hot=mod == "sebeke").hat("M160,170 H300", "L1", hot=mod != "sebeke" and not topraksiz)
    c.kutu(300, 50, 110, 160, "TRANSFER", "4 kutuplu" if duzen in ("ayri_4p", "topraksiz") else "3 kutuplu", "normal")
    c.hat("M410,130 H640", "L1", hot=not topraksiz).kutu(480, 112, 70, 36, f"{egri}{fnum(in_a, 0)}", "", "acti" if (not math.isinf(t_oc) and t_oc <= 0.4 and t_oc <= t_rcd) else "normal")
    c.dikdortgen(640, 90, 130, 90, "ariza", "rgba(220,38,38,.07)", 3).yazi(705, 140, "cihaz (gövde)", "ariza", 11, True, "middle").simsek(650, 118, 0.9)
    c.hat("M705,180 V230 H130", "PE", hot=not topraksiz, kesik=topraksiz).yazi(440, 224, "koruma iletkeni", "PE", 10.5, False, "middle")
    c.hat("M40,80 H24 V258", "PE", kesik=True).toprak(24, 258).yazi(32, 250, "trafo nötrü", "PE", 10)
    if duzen in ("ayri_4p", "ayri_3p"):
        c.hat("M130,210 V258", "PE", hot=(mod != "sebeke")).toprak(130, 258).yazi(140, 250, "jeneratör nötrü topraklı", "PE", 10)
    elif duzen == "topraksiz":
        c.yazi(140, 250, "jeneratör nötrü TOPRAKSIZ", "ariza", 10.5, True)
    else:
        c.hat("M130,210 V238 H24", "N").yazi(140, 252, "nötr ana panodaki topraklamaya bağlı", "N", 10)
    c.yazi(450, 288, ("arıza akımının dönecek yolu yok: hiçbir cihaz açmaz" if topraksiz else f"arıza akımı: ilk an {fnum(i_ilk, 0)} A, sürekli {fnum(i_sur, 0)} A → {fsure(t)}"), "ok" if t <= 0.4 else "ariza", 12, True, "middle")
    oz = [K("Arıza akımı (ilk an)", f"{fnum(i_ilk, 0)} A", "info", "geçici altı" if mod == "jen" else ""), K("Arıza akımı (sürekli)", f"{fnum(i_sur, 0)} A", "info", f"kaynak In = {fnum(in_g, 0)} A"),
          K("Otomatın manyetik eşiği", f"{fnum(im, 0)} A", "ok" if i_ilk >= im else "warn", f"{egri}{fnum(in_a, 0)}"), K("Açma süresi", fsure(t), "ok" if t <= 0.4 else "bad", "sınır 0,4 s"),
          K("Nötr düzeni", "doğru" if duzen in ("ayri_4p", "ortak_3p") else "hatalı", "ok" if duzen in ("ayri_4p", "ortak_3p") else "bad", "tek noktada topraklı" if duzen in ("ayri_4p", "ortak_3p") else "")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne()}
