"""Laboratuvar aracı — alıştırma modu: hata kütüphanesinden bir durum gösterilir; şema ve ayarlar görünür, sonuç gizlenir.
Soru: “Bu tesiste yanlış olan ne?” Dört seçenekten biri doğrudur. Cevaptan sonra açıklama ve tam çözüm açılır.

Sorular soru numarasından türetilir (aynı numara her zaman aynı soruyu verir); sonuçlar ilgili konunun kendi hesabıdır."""
from __future__ import annotations

import random

from .core import ctl

ID = "alistirma"
BASLIK = "Alıştırma"
IKON = "🎯"
GIRIS = ("Kendinizi deneyin: bir tesis durumu gösterilir, sonucu gizlidir. Şemaya ve verilen değerlere bakıp neyin yanlış olduğunu seçin. "
         "Cevaptan sonra açıklama, kontrol tablosu ve çözüm açılır. “Sonraki soru” ile devam edin.")

KONTROLLER = [
    ctl("soru", "Soru numarası", "sayi", 1, min=1, max=999, adim=1),
]


def run(p: dict) -> dict:
    from . import run as lab_run
    from .hatalar import SENARYOLAR
    no = max(1, int(float(p.get("soru", 1) or 1)))
    rng = random.Random(1000 + no)
    sira = list(range(len(SENARYOLAR)))
    random.Random(7).shuffle(sira)                      # her senaryo bir kez gelsin; sonra yeniden karışır
    s = SENARYOLAR[sira[(no - 1) % len(sira)]]
    ayni = [x for x in SENARYOLAR if x is not s and x[2] == s[2]]                 # çeldiriciler önce aynı konudan
    rng.shuffle(ayni)
    baska = [x for x in SENARYOLAR if x is not s and x[2] != s[2]]
    secenekler = (ayni[:3] + rng.sample(baska, 3))[:3] + [s]
    rng.shuffle(secenekler)
    out = lab_run(s[2], s[3])
    from . import spec
    from .dersnotu import _deger
    sp = next(k for k in spec() if k["id"] == s[2])
    pr = out["params"]
    veriler = [[c["label"], _deger(c, pr.get(c["key"]))] for c in sp["kontroller"]
               if not c.get("goster") or all(any(str(v) == str(pr.get(k)) for v in vals) for k, vals in c["goster"].items())]
    out["soru"] = {"no": no, "konu": sp["baslik"], "metin": "Aşağıdaki tesiste bir şey yanlış. Şemaya ve verilere bakın: yanlış olan hangisi?", "veriler": veriler,
                   "secenekler": [x[1] for x in secenekler], "dogru": secenekler.index(s), "aciklama": s[5] + " " + s[6]}
    out["git"] = {"konu": s[2], "params": out["params"], "baslik": s[1]}
    out["senaryo"] = {"id": s[0], "dogru": False}
    out["dersler"] = [s[6]] + out["dersler"][:3]
    out["tablolar"] = []
    return out
