"""Laboratuvar konusu — OG kablo ekranının topraklanması: tek uç, iki uç; endüklenen gerilim, dolaşan akım, azalma katsayısı r.

Model (tek damarlı kablolar): faz akımı I, ekranda metre başına E = ω·(μ0/2π)·ln(2·S/d)·I gerilim endükler (S: damar eksenleri arası,
d: ekranın ortalama çapı). Tek uçtan topraklı ekranda bu gerilim açık uçta görünür; iki uçtan topraklıda ekrandan akım dolaşır:
Is / I = X / √(R² + X²). Toprak arızasında üç ekran paralel bir dönüş yoludur; toprağa geçen pay r = Re / √(Re² + Xe²)
(Xe: toprak dönüşlü çevrimin reaktansı ≈ 0,6 Ω/km — tahmini). Dayanak: Topraklamalar Yön. Ek-J."""
from __future__ import annotations

import math

from .cizim import Cizim
from .core import C, K, OMEGA, ctl, fnum, num, opt

ID = "ekran"
BASLIK = "OG kablo ekranı"
IKON = "🧵"
GIRIS = ("Tek damarlı OG kablonun bakır ekranı, içinden akım geçen bir iletkenin çevresindeki ikinci bir iletkendir: faz akımı ekranda gerilim endükler. "
         "Ekran bir uçtan mı, iki uçtan mı topraklanmalı? Seçimin endüklenen gerilime, kayıplara ve trafo merkezi topraklamasına etkisini görün.")

KONTROLLER = [
    ctl("baglama", "Ekranın topraklanması", "sec", "iki", secenek=opt(("iki", "İki uçtan"), ("tek", "Tek uçtan (diğer uç açık)"))),
    ctl("l_m", "Kablo uzunluğu", "sayi", 500, min=10, max=5000, adim=10, birim="m"),
    ctl("i_yuk", "Yük akımı", "sayi", 200, min=10, max=630, adim=10, birim="A"),
    ctl("ik_ka", "Kısa devre akımı", "sayi", 12, min=1, max=25, adim=0.5, birim="kA"),
    ctl("dizilis", "Diziliş", "sec", "ucgen", secenek=opt(("ucgen", "Üçgen (birbirine değen)"), ("yan", "Yan yana, aralıklı (7 cm)"))),
    ctl("s_ekran", "Ekran kesiti", "sec", 16, secenek=opt((16, "16 mm² Cu"), (25, "25 mm² Cu"), (35, "35 mm² Cu"))),
    ctl("svl", "Açık uçta ekran gerilim sınırlayıcı (parafudr) var", "onay", False, goster={"baglama": ["tek"]}),
    ctl("if_a", "Toprak arıza akımı (trafo merkezinde)", "sayi", 1000, min=10, max=5000, adim=10, birim="A"),
    ctl("re_ohm", "Trafo merkezi topraklama direnci RE", "sayi", 1.0, min=0.1, max=10, adim=0.1, birim="Ω"),
]
D_EKRAN = 0.032       # ekranın ortalama çapı (m) — 36 kV, 95–240 mm² tek damarlı kablo mertebesi
XE_KM = 0.6           # toprak dönüşlü ekran çevriminin reaktansı (Ω/km) — tahmini
SINIR_SUREKLI = 65.0  # açık uçta sürekli ekran gerilimi (V) — uygulama sınırı


def run(p: dict) -> dict:
    tek = p.get("baglama") == "tek"
    L = num(p, "l_m", 500); i = num(p, "i_yuk", 200); ik = num(p, "ik_ka", 12) * 1000
    s_ek = num(p, "s_ekran", 16)
    S = 0.042 if p.get("dizilis") != "yan" else 0.112
    e = OMEGA * 2e-7 * math.log(2 * S / D_EKRAN)            # V / (A·m)
    x_km = e * 1000                                          # Ω/km
    r_km = 0.0185 * 1000 / s_ek                              # Ω/km (bakır, işletme sıcaklığı)
    u_yuk = e * i * L; u_kd = e * ik * L
    is_oran = x_km / math.hypot(r_km, x_km)
    i_s = is_oran * i
    p_kayip = 3 * i_s ** 2 * r_km * L / 1000                 # W
    re3 = r_km / 3
    r_az = 1.0 if tek else re3 / math.hypot(re3, XE_KM)
    i_f = num(p, "if_a", 1000); re_ = num(p, "re_ohm", 1.0)
    ue = re_ * r_az * i_f
    an = [f"Faz iletkeninden {fnum(i, 0)} A geçiyor. Ekranda metre başına {fnum(e * i * 1000, 1)} mV endüklenir ({'üçgen' if S < 0.1 else 'yan yana'} diziliş; damarlar birbirinden uzaklaştıkça artar)."]
    kt = []
    if tek:
        an += [f"Ekran yalnız bir uçtan topraklı: akım dolaşacak kapalı bir yol yok, ekranda kayıp olmaz. Ama endüklenen gerilim açık uçta birikir: yük akımında {fnum(u_yuk, 0)} V, kısa devrede {fnum(u_kd, 0)} V.",
               "Açık uç ve o uçtaki kablo başlığının dış kılıfı bu gerilime dayanmalıdır; kısa devredeki değer kılıfı delebileceği için açık uca ekran gerilim sınırlayıcı (küçük bir parafudr) konur ve uç dokunmaya karşı korunur.",
               "Toprak arızasında ekran bir dönüş yolu oluşturmaz (öbür ucu açık): arıza akımının tamamı topraktan döner, azalma katsayısı r = 1."]
        kt.append(C("Açık uçta sürekli ekran gerilimi", f"{fnum(u_yuk, 0)} V ({fnum(L, 0)} m, {fnum(i, 0)} A)", f"≤ {fnum(SINIR_SUREKLI, 0)} V (dokunmaya karşı korunmamış uçta)", u_yuk <= SINIR_SUREKLI + 1e-9, "Uygulama sınırı (işletme ve üretici kuralları); TS HD 620 kablo montaj kuralları", "ikincil"))
        kt.append(C("Kısa devrede açık uç gerilimi", f"{fnum(u_kd, 0)} V", "dış kılıfın dayanımını aşmamalı; aşıyorsa ekran gerilim sınırlayıcı", bool(p.get("svl")) or u_kd <= 1000, "Uygulama kuralı; üretici verisi", "ikincil"))
    else:
        an += [f"Ekran iki uçtan topraklı: endüklenen gerilim ekrandan akım dolaştırır. Ekranın direnci {fnum(r_km, 2)} Ω/km, reaktansı {fnum(x_km, 3)} Ω/km → dolaşan akım faz akımının %{fnum(is_oran * 100, 1)}'i = {fnum(i_s, 1)} A.",
               f"Bu akım ekranı ısıtır: üç kabloda toplam {fnum(p_kayip, 0)} W kayıp. Küçük ekran kesitinde (16–25 mm²) ve üçgen dizilişte ihmal edilir; büyük kesitli ekranlarda ve aralıklı dizilişte kablonun akım taşıma kapasitesini düşürür.",
               f"Karşılığında ekranın iki ucu da toprak potansiyelindedir (dokunma tehlikesi yok) ve toprak arızasında üç ekran paralel bir dönüş yolu olur: arıza akımının yalnız r = {fnum(r_az, 2)} katı topraktan döner."]
        kt.append(C("Ekranda dolaşan akım", f"{fnum(i_s, 1)} A (faz akımının %{fnum(is_oran * 100, 1)}'i) ; kayıp {fnum(p_kayip, 0)} W", "ekran kesitinin sürekli akım taşıma kapasitesi içinde", i_s <= 4.0 * s_ek, "Kablo üreticisi verisi; TS IEC 60287 (ekran kayıpları)", "ikincil"))
    an.append(f"Trafo merkezi için sonucu: toprak arızasında topraklama tesisinden geçen akım IE = r · IF = {fnum(r_az, 2)} × {fnum(i_f, 0)} = {fnum(r_az * i_f, 0)} A; topraklama gerilimi UE = RE · IE = {fnum(ue, 0)} V.")
    kt.append(C("Azalma katsayısı", f"r = {fnum(r_az, 2)}", "tek damarlı XLPE, 16 mm² Cu ekran, iki uçtan topraklı: 0,5 – 0,6 ; ekran dönüş yolu oluşturmuyorsa 1", None, "Topraklamalar Yön. Ek-J (J.2)", "resmi"))
    kt.append(C("Dağıtım kablolarında ekran bağlantısı", "iki uçtan" if not tek else "tek uçtan", "OG dağıtım kablolarının ekranı her iki uçta topraklanır; tek uç yalnız kısa, özel bağlantılarda ve önlemleriyle", (not tek) or L <= 100, "TEDAŞ Enerji Kabloları Montaj (Uygulama) Usul ve Esasları", "dogrulanacak"))
    ds = ["İki uçtan topraklama güvenli ve basittir; bedeli ekranda dolaşan akımdır. Dağıtım şebekesinde (küçük ekran kesiti, üçgen diziliş) bu bedel küçüktür.",
          "Tek uçtan topraklama kaybı sıfırlar ama açık uçta gerilim bırakır ve toprak arızasında ekranın sağladığı dönüş yolunu yok eder. Büyük akımlı, kısa bağlantılarda (trafo–hücre arası, jeneratör çıkışı) kullanılır.",
          "Uzun ve büyük kesitli hatlarda üçüncü yol çapraz bağlamadır: ekranlar üç eşit bölümde faz değiştirir, endüklenen gerilimler birbirini götürür.",
          "Azalma katsayısı küçüldükçe trafo merkezinin topraklama gerilimi düşer. Bu yüzden kablo ile beslenen merkezlerde aynı RE ile birleşik topraklama koşulu daha kolay sağlanır; havai hatla beslenen direk tipi trafoda r = 1'dir.",
          "Ekranı toprağa bağlayan iletken en az ekranın kesitinde olmalı ve kısa devre süresince ekran akımını taşımalıdır."]
    ls = [20 * 1.3 ** k for k in range(0, 22)]
    graf = [{"baslik": "Tek uçtan topraklı ekranda açık uç gerilimi", "x_ad": "kablo uzunluğu (m)", "y_ad": "ekran gerilimi (V)", "logx": True, "logy": True,
             "seriler": [{"ad": f"yük akımı {fnum(i, 0)} A", "renk": "#1a4d8f", "pts": [[round(x), round(e * i * x, 1)] for x in ls]}, {"ad": f"kısa devre {fnum(ik / 1000, 1)} kA", "renk": "#dc2626", "pts": [[round(x), round(e * ik * x, 1)] for x in ls]}],
             "yatay": [{"y": SINIR_SUREKLI, "etiket": f"sürekli sınır {fnum(SINIR_SUREKLI, 0)} V", "renk": "#15803d"}], "isaretler": [{"x": L, "etiket": f"{fnum(L, 0)} m"}]}]
    c = Cizim(900, 300, zemin=250)
    c.hat("M60,110 H840", "L1", hot=True, w=3).yazi(450, 100, f"faz iletkeni · {fnum(i, 0)} A", "ariza", 11.5, True, "middle")
    c.dikdortgen(110, 124, 680, 26, "PE", "rgba(21,128,61,.10)", 2, True, 12).yazi(450, 142, "bakır ekran" + (f" · dolaşan {fnum(i_s, 1)} A" if not tek else " · akım yok"), "PE", 11, True, "middle")
    c.hat("M130,150 V250", "PE", hot=not tek, hot_renk="uyari").toprak(130, 250).yazi(140, 205, "topraklı uç", "PE", 10.5)
    if tek:
        c.daire(770, 150, 5, "ariza", "#fff", 2).yazi(770, 180, f"açık uç: {fnum(u_yuk, 0)} V", "ok" if u_yuk <= SINIR_SUREKLI else "ariza", 12, True, "middle").yazi(770, 196, f"kısa devrede {fnum(u_kd, 0)} V", "ariza", 10.5, False, "middle")
        if p.get("svl"):
            c.hat("M770,155 V205", "cizgi").kutu(745, 205, 50, 22, "SVL", "", "acti").hat("M770,227 V250").toprak(770, 250)
    else:
        c.hat("M770,150 V250", "PE", hot=True, hot_renk="uyari").toprak(770, 250).yazi(760, 205, "topraklı uç", "PE", 10.5, False, "end").hat("M130,268 H770", "toprak", hot=True, hot_renk="uyari")
    c.yazi(450, 288, f"toprak arızasında azalma katsayısı r = {fnum(r_az, 2)} → UE = {fnum(ue, 0)} V", "#334155", 12, True, "middle")
    oz = [K("Endüklenen gerilim", f"{fnum(e * i * 1000, 1)} mV/m", "info", f"{fnum(i, 0)} A yükte"), K("Açık uç gerilimi" if tek else "Dolaşan ekran akımı", f"{fnum(u_yuk, 0)} V" if tek else f"{fnum(i_s, 1)} A", ("ok" if u_yuk <= SINIR_SUREKLI else "bad") if tek else "info", f"kısa devrede {fnum(u_kd, 0)} V" if tek else f"kayıp {fnum(p_kayip, 0)} W"),
          K("Azalma katsayısı r", fnum(r_az, 2), "info" if not tek else "warn", "toprağa geçen pay"), K("Topraklama gerilimi UE", f"{fnum(ue, 0)} V", "info", f"IE = {fnum(r_az * i_f, 0)} A")]
    return {"ozet": oz, "kontroller": kt, "anlatim": an, "dersler": ds, "sahne": c.sahne(), "grafikler": graf}
