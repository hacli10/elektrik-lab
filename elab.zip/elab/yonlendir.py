"""Bölümler arası konu bulma: bir sayfa başka bir bölüme taşınmış olabilir (ör. trafo sayfaları güç sistemi laboratuvarındadır).
Vaka ve hata kütüphanesi sayfaları bir konuyu adıyla çalıştırırken bunu kullanır; bağlantı («git») da konunun bulunduğu bölümü taşır."""
from __future__ import annotations

SIRA = ("lab", "role", "guc")


def calistir(konu: str, params: dict | None, once: str) -> tuple[str, dict, dict]:
    """Konuyu önce `once` bölümünde, yoksa öbür bölümlerde çalıştırır. Dönen: (bölüm, sonuç, konu tanımı)."""
    import importlib
    for b in (once,) + tuple(x for x in SIRA if x != once):
        m = importlib.import_module(f"{__package__}.{b}")
        sp = next((k for k in m.spec() if k["id"] == konu), None)
        if sp is not None:
            return b, m.run(konu, params), sp
    raise KeyError(f"Bilinmeyen konu: {konu}")
